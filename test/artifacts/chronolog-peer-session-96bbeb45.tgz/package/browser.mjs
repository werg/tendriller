import {
  putContentBytes,
  readContentBytes
} from "./chunks/chunk-7JXKVFZF.mjs";
import {
  APPLICATION_OWNER_PROTOCOL,
  SessionError,
  acquireApplicationOwnerLock,
  applicationDefinitionDigest,
  canonicalJson,
  createAppClient,
  createLiveView,
  createProjection,
  createScopedApplicationTools,
  createViewStore,
  defineApplication,
  defineCommand,
  defineProjection,
  defineQuery,
  describeApplication,
  forwardSessionEvents,
  submitBatch
} from "./chunks/chunk-JP3L3YUV.mjs";
import {
  parseApplicationInput
} from "./chunks/chunk-HHSRWTA7.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-RIBYWTWK.mjs";
import "./chunks/chunk-PDJLSHX7.mjs";

// packages/peer-session/src/worker-application.ts
var WorkerApplicationOperation = class {
  constructor(id, operationId, session) {
    this.id = id;
    this.operationId = operationId;
    this.session = session;
  }
  id;
  operationId;
  session;
  stored = true;
  inspect() {
    return this.session.request("operation.inspect", [this.id]);
  }
  materialized(options) {
    return this.session.wait(this.id, "materialized", options);
  }
  retained(options) {
    return this.session.wait(this.id, "retained", options);
  }
  finalized(options) {
    return this.session.wait(this.id, "finalized", options);
  }
};
var WorkerApplicationSession = class {
  #endpoint;
  #attachment = crypto.randomUUID();
  #lifetime = new AbortController();
  #pending = /* @__PURE__ */ new Map();
  #statuses = /* @__PURE__ */ new Set();
  #changes = /* @__PURE__ */ new Set();
  #extensions = /* @__PURE__ */ new Set();
  #ownedViews = /* @__PURE__ */ new Set();
  #next = 0;
  #binding;
  #attachmentState = "active";
  #heartbeat;
  #pinging = false;
  #description;
  #status = { canAuthor: false, phase: "ready", database: "idle", connectedPeers: 0, pendingOperations: 0, materializationError: null };
  applicationId = "";
  identity = { publicKey: "" };
  constructor(endpoint) {
    this.#endpoint = endpoint;
    endpoint.addEventListener("message", this.#receive);
    const physical = endpoint;
    physical.addEventListener("close", this.#physicalClose);
    physical.addEventListener("messageerror", this.#physicalClose);
    physical.on?.("close", this.#physicalClose);
    physical.on?.("messageerror", this.#physicalClose);
  }
  #physicalClose = () => {
    this.#detach(Object.assign(new Error("OWNER_UNREACHABLE"), { code: "OWNER_UNREACHABLE" }));
  };
  get signal() {
    return this.#lifetime.signal;
  }
  get status() {
    return { ...this.#status, canAuthor: this.#status.canAuthor && this.#attachmentState === "active" && this.#binding?.capabilities.includes("commands") === true };
  }
  get endpoint() {
    return this.#binding === void 0 ? void 0 : structuredClone(this.#binding);
  }
  get attachmentState() {
    return this.#attachmentState;
  }
  describe() {
    if (this.#description === void 0) throw new Error("ENDPOINT_HANDSHAKE_REQUIRED");
    return structuredClone(this.#description);
  }
  get boundedRequest() {
    const requests = [...this.#pending.values()].filter((request2) => request2.method !== "operation.wait" && request2.method !== "signals.next").sort((a, b) => a.startedAt - b.startedAt);
    const request = requests[0];
    return request === void 0 ? null : { startedAt: request.startedAt, deadline: request.deadline };
  }
  #receive = (event) => {
    const message = event.data;
    if (message?.protocol !== APPLICATION_OWNER_PROTOCOL || message.attachment !== this.#attachment) return;
    if (message.kind === "response") {
      const response = message, pending = this.#pending.get(response.id);
      if (pending === void 0) return;
      this.#pending.delete(response.id);
      clearTimeout(pending.timer);
      pending.cleanup();
      if (response.error !== void 0) pending.reject(Object.assign(new Error(response.error), { code: response.error }));
      else pending.resolve(response.value);
    } else if (message.kind === "notice") {
      const notice = message;
      if (notice.topic === "closed") {
        this.#detach(new Error(String(notice.value)));
        return;
      }
      if (notice.topic === "status") {
        this.#status = notice.value;
        for (const listener of this.#statuses) {
          try {
            listener(this.status);
          } catch {
          }
        }
      }
      if (notice.topic === "extension") for (const listener of this.#extensions) {
        try {
          listener(notice.value);
        } catch {
        }
      }
      if (notice.topic === "change") for (const listener of this.#changes) {
        try {
          listener(notice.value);
        } catch {
        }
      }
    }
  };
  request(method, args, options = {}) {
    if (this.signal.aborted) return Promise.reject(this.signal.reason);
    if (options.signal?.aborted) return Promise.reject(options.signal.reason);
    const control = ["close", "attachment.ping", "attachment.suspend", "attachment.resume", "view.release", "content.cancel", "signals.close", "upload.discard"].includes(method);
    if ([...this.#pending.values()].filter((request) => ["close", "attachment.ping", "attachment.suspend", "attachment.resume", "view.release", "content.cancel", "signals.close", "upload.discard"].includes(request.method) === control).length >= (control ? 8 : 32)) return Promise.reject(new Error("ENDPOINT_REQUEST_LIMIT"));
    const timeoutMs = options.timeoutMs ?? 3e4;
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 12e4) return Promise.reject(new Error("ENDPOINT_TIMEOUT_LIMIT"));
    const id = ++this.#next, startedAt = performance.now();
    return new Promise((resolve, reject) => {
      const cancel = () => {
        try {
          this.#endpoint.postMessage({ protocol: APPLICATION_OWNER_PROTOCOL, attachment: this.#attachment, kind: "cancel", id });
        } catch {
        }
      };
      const abort = () => {
        const pending = this.#pending.get(id);
        if (pending === void 0) return;
        this.#pending.delete(id);
        clearTimeout(pending.timer);
        pending.cleanup();
        cancel();
        reject(options.signal?.reason);
      };
      const cleanup = () => options.signal?.removeEventListener("abort", abort);
      const timer = setTimeout(() => {
        this.#pending.delete(id);
        cleanup();
        cancel();
        reject(Object.assign(new Error("ENDPOINT_REQUEST_TIMEOUT"), { code: "ENDPOINT_REQUEST_TIMEOUT" }));
      }, timeoutMs);
      this.#pending.set(id, { method, startedAt, deadline: startedAt + timeoutMs, resolve: (value) => resolve(value), reject, timer, cleanup });
      options.signal?.addEventListener("abort", abort, { once: true });
      try {
        this.#endpoint.postMessage({ protocol: APPLICATION_OWNER_PROTOCOL, attachment: this.#attachment, kind: "request", id, method, args });
      } catch (error) {
        this.#pending.delete(id);
        clearTimeout(timer);
        cleanup();
        reject(error);
      }
    });
  }
  async initialize(options) {
    const value = await this.request("hello", [options]);
    this.applicationId = value.applicationId;
    this.identity = value.identity;
    this.#status = value.status;
    this.#binding = value.binding;
    this.#description = value.definition;
    this.#heartbeat = setInterval(() => {
      if (this.#pinging || this.signal.aborted || this.#attachmentState === "suspended") return;
      this.#pinging = true;
      void this.request("attachment.ping", [], { timeoutMs: 2e4 }).catch((error) => this.#detach(error)).finally(() => {
        this.#pinging = false;
      });
    }, 5e3);
    this.#heartbeat.unref?.();
  }
  async suspendAttachment() {
    await this.request("attachment.suspend", []);
    this.#attachmentState = "suspended";
    this.#ownedViews.clear();
  }
  suspend() {
    return this.suspendAttachment();
  }
  async resumeAttachment() {
    this.#status = await this.request("attachment.resume", []);
    this.#attachmentState = "active";
    return this.endpoint ?? null;
  }
  detach() {
    return this.close();
  }
  async submit(input) {
    const value = await this.request("submit", [input]);
    return new WorkerApplicationOperation(value.id, value.operationId, this);
  }
  async command(name, input, options = {}) {
    const value = await this.request("command", [name, input, options]);
    return new WorkerApplicationOperation(value.id, value.operationId, this);
  }
  query(name, input) {
    return this.request("query", [name, input]);
  }
  wait(id, fact, options = {}) {
    const timeoutMs = options.timeoutMs ?? 3e4;
    return this.request("operation.wait", [id, fact, timeoutMs], { ...options, timeoutMs: Math.min(12e4, timeoutMs + 1e3) });
  }
  async readView(options = {}) {
    const captured = await this.request("readView", [options]);
    this.#ownedViews.add(captured.id);
    let released = false, releasing;
    return { applicationId: this.applicationId, revision: captured.revision, query: (sql, parameters = []) => {
      if (released) return Promise.reject(new Error("READ_VIEW_RELEASED"));
      return this.request("view.query", [captured.id, sql, parameters]);
    }, readEvents: (options2) => {
      if (released) return Promise.reject(new Error("READ_VIEW_RELEASED"));
      return this.request("view.events", [captured.id, options2 ?? {}]);
    }, release: () => {
      if (releasing !== void 0) return releasing;
      released = true;
      this.#ownedViews.delete(captured.id);
      return releasing = this.request("view.release", [captured.id]);
    } };
  }
  get operations() {
    const session = this;
    return { async retry(id) {
      const value = await session.request("operation.retry", [id]);
      return new WorkerApplicationOperation(value.id, value.operationId, session);
    }, async get(id) {
      const value = await session.request("operation.get", [id]);
      return value === null ? null : new WorkerApplicationOperation(value.id, value.operationId, session);
    }, async *subscribe(options) {
      const signal = options.signal === void 0 ? session.signal : AbortSignal.any([session.signal, options.signal]);
      let dirty = true, wake;
      const invalidate = () => {
        dirty = true;
        wake?.();
      };
      const stop = session.onChange(invalidate), stopStatus = session.onStatus(invalidate);
      signal.addEventListener("abort", invalidate);
      try {
        while (!signal.aborted) {
          if (!dirty) await new Promise((resolve) => {
            wake = resolve;
          });
          if (signal.aborted) break;
          dirty = false;
          const operation = await session.operations.get(options.operationId);
          if (operation !== null) yield await operation.inspect();
        }
      } finally {
        stop();
        stopStatus();
        signal.removeEventListener("abort", invalidate);
      }
    } };
  }
  onStatus(listener) {
    this.#statuses.add(listener);
    listener(this.status);
    return () => {
      this.#statuses.delete(listener);
    };
  }
  onChange(listener) {
    this.#changes.add(listener);
    return () => {
      this.#changes.delete(listener);
    };
  }
  async *changes(options = {}) {
    const signal = options.signal === void 0 ? this.signal : AbortSignal.any([this.signal, options.signal]), queue = [];
    let wake;
    const stop = this.onChange((value) => {
      queue.splice(0, queue.length, value);
      wake?.();
    }), abort = () => {
      wake?.();
    };
    signal.addEventListener("abort", abort);
    try {
      while (!signal.aborted) {
        if (queue.length === 0) await new Promise((resolve) => {
          wake = resolve;
        });
        while (queue.length > 0 && !signal.aborted) yield queue.shift();
      }
    } finally {
      stop();
      signal.removeEventListener("abort", abort);
    }
  }
  diagnostics() {
    return this.request("diagnostics.peers", []);
  }
  readAuthority() {
    return this.request("authority.read", []);
  }
  endpoints() {
    return this.request("endpoints.list", []);
  }
  mergeAuthority(bundle) {
    return this.request("authority.merge", [bundle]);
  }
  /** The owner's authenticated operation-set facts (signed envelopes, retention and finality evidence). */
  exportFacts() {
    return this.request("facts.export", []);
  }
  /** Verify and merge facts from another replica; ordering remains signed author time, never arrival order. */
  mergeFacts(facts) {
    return this.request("facts.merge", [facts]);
  }
  finality = {
    closeAuthorTime: (options) => this.request("finality.closeAuthorTime", [options]),
    voteAuthorTime: (options) => this.request("finality.voteAuthorTime", [options]),
    submitProofs: (proofs) => this.request("finality.submitProofs", [proofs])
  };
  /** Owner-composed named actions and notices; requires the `extensions` capability. */
  extensions = {
    call: (name, args = [], options = {}) => this.request("extension.call", [name, args], options),
    subscribe: (listener) => {
      this.#extensions.add(listener);
      return () => {
        this.#extensions.delete(listener);
      };
    }
  };
  signals = {
    delivery: "application",
    send: (topic, payload, options = {}) => {
      const { signal, ...rest } = options;
      return this.request("signals.send", [topic, payload, rest], signal === void 0 ? {} : { signal });
    },
    subscribe: (options = {}) => {
      const session = this, { signal: external, ...rest } = options, signal = external === void 0 ? this.signal : AbortSignal.any([this.signal, external]);
      return { async *[Symbol.asyncIterator]() {
        const id = await session.request("signals.open", [rest], { signal });
        try {
          while (!signal.aborted) {
            const next = await session.request("signals.next", [id], { signal, timeoutMs: 25e3 });
            if (next.done) return;
            if (next.value !== void 0) yield next.value;
          }
        } finally {
          if (!session.signal.aborted) await session.request("signals.close", [id]).catch(() => void 0);
        }
      } };
    }
  };
  content = {
    retain: (reference) => this.request("content.retain", [reference]),
    retention: (reference) => this.request("content.retention", [reference]),
    retained: (reference) => this.request("content.retained", [reference]),
    discard: (reference) => this.request("content.discard", [reference]),
    stage: async (options) => {
      const id = await this.request("content.stage", [options]);
      return { id, write: (index, bytes) => this.request("upload.write", [id, index, bytes]), progress: () => this.request("upload.progress", [id]), commit: () => this.request("upload.commit", [id]), discard: () => this.request("upload.discard", [id]) };
    },
    read: (reference, options = {}) => {
      const session = this;
      return { async *[Symbol.asyncIterator]() {
        const id = await session.request("content.openRead", [reference], options);
        try {
          while (!options.signal?.aborted) {
            const chunk = await session.request("content.next", [id], options);
            if (chunk === null) return;
            yield chunk;
          }
        } finally {
          void session.request("content.cancel", [id]).catch(() => void 0);
        }
      } };
    },
    putBytes: (bytes, options) => putContentBytes(this.content, bytes, options),
    readBytes: (reference, options) => readContentBytes(this.content, reference, options)
  };
  readEvents(options = {}) {
    return this.request("events.read", [options]);
  }
  #detach(reason) {
    if (this.signal.aborted) return;
    this.#attachmentState = "detached";
    clearInterval(this.#heartbeat);
    this.#status = { ...this.#status, phase: "closed", database: "closed", canAuthor: false };
    for (const listener of this.#statuses) {
      try {
        listener(this.status);
      } catch {
      }
    }
    ;
    this.#lifetime.abort(reason);
    this.#endpoint.removeEventListener("message", this.#receive);
    const physical = this.#endpoint;
    physical.removeEventListener("close", this.#physicalClose);
    physical.removeEventListener("messageerror", this.#physicalClose);
    physical.off?.("close", this.#physicalClose);
    physical.off?.("messageerror", this.#physicalClose);
    for (const pending of this.#pending.values()) {
      clearTimeout(pending.timer);
      pending.cleanup();
      pending.reject(reason);
    }
    ;
    this.#pending.clear();
    this.#statuses.clear();
    this.#changes.clear();
    this.#extensions.clear();
    this.#endpoint.close?.();
  }
  async close() {
    if (this.signal.aborted) return;
    for (const id of this.#ownedViews) void this.request("view.release", [id]).catch(() => void 0);
    try {
      await this.request("close", [], { timeoutMs: 1e3 });
    } finally {
      this.#detach(new Error("ENDPOINT_CLOSED"));
    }
  }
};
async function connectApplicationOwner(endpoint, options) {
  const session = new WorkerApplicationSession(endpoint);
  endpoint.start?.();
  try {
    await session.initialize(options);
    return session;
  } catch (error) {
    await session.close().catch(() => void 0);
    throw error;
  }
}
export {
  SessionError,
  WorkerApplicationOperation,
  WorkerApplicationSession,
  acquireApplicationOwnerLock,
  applicationDefinitionDigest,
  canonicalJson,
  connectApplicationOwner,
  createAppClient,
  createLiveView,
  createProjection,
  createScopedApplicationTools,
  createViewStore,
  defineApplication,
  defineCommand,
  defineProjection,
  defineQuery,
  describeApplication,
  forwardSessionEvents,
  parseApplicationInput,
  submitBatch
};
