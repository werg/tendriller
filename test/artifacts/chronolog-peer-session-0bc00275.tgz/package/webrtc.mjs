import {
  awaitOwnedTask
} from "./chunks/chunk-KSC4KBWO.mjs";
import {
  PEER_MESSAGE_LIMITS,
  framePeerMessageChannels
} from "./chunks/chunk-PFEHSVTG.mjs";

// packages/transport-webrtc/src/live.ts
function requireRtcLiveChannel(channel) {
  if (channel.ordered || channel.maxPacketLifeTime !== null || channel.maxRetransmits !== 0)
    throw new Error("WEBRTC_LIVE_CHANNEL_REQUIRED");
}

// packages/transport-webrtc/src/channel.ts
var WEBRTC_LIMITS = Object.freeze({ ...PEER_MESSAGE_LIMITS, sdpBytes: 64 * 1024 });
function requireReliable(channel) {
  if (!channel.ordered || channel.maxPacketLifeTime !== null || channel.maxRetransmits !== null)
    throw new Error("WEBRTC_RELIABLE_ORDERED_REQUIRED");
}
function frameRtcPeerChannels(channels, options = {}) {
  requireReliable(channels.reliable);
  requireRtcLiveChannel(channels.live);
  return framePeerMessageChannels(channels, options);
}

// packages/transport-webrtc/src/route.ts
async function observeWebRtcRoute(connection) {
  const unknown = { route: "unknown", localCandidateType: null, remoteCandidateType: null };
  if (connection.connectionState !== "connected" || connection.getStats === void 0) return unknown;
  try {
    const report = await connection.getStats(), stats = /* @__PURE__ */ new Map();
    report.forEach((value) => {
      if (typeof value === "object" && value !== null && "id" in value && typeof value.id === "string") {
        stats.set(value.id, value);
      }
    });
    const selected = [...stats.values()].filter((value) => value.type === "transport" && typeof value.selectedCandidatePairId === "string");
    let pair;
    if (selected.length === 1) pair = stats.get(selected[0].selectedCandidatePairId);
    else if (selected.length === 0) {
      const pairs = [...stats.values()].filter((value) => value.type === "candidate-pair" && value.selected === true);
      if (pairs.length === 1) pair = pairs[0];
    }
    if (connection.connectionState !== "connected" || pair?.type !== "candidate-pair" || pair.state !== "succeeded") return unknown;
    const local = typeof pair.localCandidateId === "string" ? stats.get(pair.localCandidateId) : void 0;
    const remote = typeof pair.remoteCandidateId === "string" ? stats.get(pair.remoteCandidateId) : void 0;
    const localCandidateType = local?.type === "local-candidate" ? candidateType(local.candidateType) : null;
    const remoteCandidateType = remote?.type === "remote-candidate" ? candidateType(remote.candidateType) : null;
    const route2 = localCandidateType === "relay" || remoteCandidateType === "relay" ? "relay" : localCandidateType !== null && remoteCandidateType !== null ? "direct" : "unknown";
    return { route: route2, localCandidateType, remoteCandidateType };
  } catch {
    return unknown;
  }
}
function candidateType(value) {
  return value === "host" || value === "srflx" || value === "prflx" || value === "relay" ? value : null;
}

// packages/transport-webrtc/src/negotiation.ts
var PROTOCOL = "chronolog.peer.v2";
async function negotiateWebRtc(options) {
  const timeoutMs = options.timeoutMs ?? 3e4;
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 12e4) throw new Error("WEBRTC_TIMEOUT_INVALID");
  let connection;
  try {
    options.signal?.throwIfAborted();
    const factory = options.createPeerConnection ?? ((configuration) => new RTCPeerConnection(configuration));
    connection = factory(structuredClone(options.configuration ?? {}));
  } catch (error) {
    void Promise.resolve().then(() => options.signaling.close()).catch(() => void 0);
    throw error;
  }
  const controller = new AbortController(), signal = controller.signal;
  let negotiationFailed = false;
  let closing, outcome;
  let negotiationError;
  let sentMessages = 0, receivedMessages = 0, sentBytes = 0, receivedBytes = 0;
  const close = () => {
    if (closing !== void 0) return closing;
    controller.abort(new Error("WEBRTC_CONNECTION_CLOSED"));
    options.signal?.removeEventListener("abort", abort);
    connection.removeEventListener("datachannel", dataChannel);
    connection.removeEventListener("connectionstatechange", failed);
    closing = Promise.resolve().then(() => connection.close());
    return closing;
  };
  const abort = () => {
    controller.abort(options.signal?.reason);
    void close().catch(() => void 0);
  };
  options.signal?.addEventListener("abort", abort, { once: true });
  const failed = () => {
    if (["failed", "closed"].includes(connection.connectionState)) {
      controller.abort(new Error("WEBRTC_CONNECTION_FAILED"));
      void close().catch(() => void 0);
    }
  };
  connection.addEventListener("connectionstatechange", failed);
  const dataChannel = (event) => {
    const unexpected = event.channel;
    unexpected.close();
    controller.abort(new Error("WEBRTC_CHANNEL_UNEXPECTED"));
    void close().catch(() => void 0);
  };
  connection.addEventListener("datachannel", dataChannel);
  if (options.signal?.aborted === true) abort();
  const timeout = setTimeout(() => controller.abort(new Error("WEBRTC_NEGOTIATION_TIMEOUT")), timeoutMs);
  let descriptions;
  const receivedDescription = async (type) => {
    const item = await interruptible(descriptions.next(), signal);
    if (item.done) throw new Error("WEBRTC_SIGNALING_ENDED");
    const description2 = validateDescription(item.value, type);
    receivedMessages += 1;
    receivedBytes += new TextEncoder().encode(description2.sdp).length;
    return description2;
  };
  const publish = async (type) => {
    await waitFor(connection, "icegatheringstatechange", () => connection.iceGatheringState === "complete", signal);
    const description2 = validateDescription(connection.localDescription, type);
    await interruptible(options.signaling.send(description2), signal);
    sentMessages += 1;
    sentBytes += new TextEncoder().encode(description2.sdp).length;
  };
  try {
    const channels = {
      reliable: connection.createDataChannel("chronolog.reliable", { negotiated: true, id: 0, ordered: true, protocol: PROTOCOL }),
      live: connection.createDataChannel("chronolog.live", { negotiated: true, id: 1, ordered: false, maxRetransmits: 0, protocol: PROTOCOL })
    };
    const returned = options.onDataChannels(channels);
    if (typeof returned === "object" && returned !== null && "then" in returned) {
      void Promise.resolve(returned).catch(() => void 0);
      throw new Error("WEBRTC_CHANNEL_HANDOFF_MUST_BE_SYNCHRONOUS");
    }
    descriptions = options.signaling.messages[Symbol.asyncIterator]();
    if (options.role === "offerer") {
      await interruptible(connection.setLocalDescription(await interruptible(connection.createOffer(), signal)), signal);
      await publish("offer");
      await interruptible(connection.setRemoteDescription(await receivedDescription("answer")), signal);
    } else {
      await interruptible(connection.setRemoteDescription(await receivedDescription("offer")), signal);
      await interruptible(connection.setLocalDescription(await interruptible(connection.createAnswer(), signal)), signal);
      await publish("answer");
    }
    await waitFor(connection, "connectionstatechange", () => connection.connectionState === "connected", signal);
    signal.throwIfAborted();
    outcome = {
      connection,
      signal,
      signaling: { sentMessages, receivedMessages, sentBytes, receivedBytes },
      getRoute: () => observeWebRtcRoute(connection),
      close
    };
  } catch (error) {
    negotiationFailed = true;
    negotiationError = error;
    await close().catch(() => void 0);
  }
  try {
    await interruptible(Promise.resolve().then(() => options.signaling.close()), signal);
  } catch (error) {
    await close().catch(() => void 0);
    if (!negotiationFailed) {
      negotiationFailed = true;
      negotiationError = error;
    }
  }
  clearTimeout(timeout);
  void Promise.resolve().then(() => descriptions?.return?.()).catch(() => void 0);
  if (negotiationFailed) throw negotiationError;
  if (outcome === void 0) throw new Error("WEBRTC_NEGOTIATION_INCOMPLETE");
  return outcome;
}
async function openWebRtcConnection(options) {
  const deadline = Date.now() + (options.timeoutMs ?? 3e4);
  let framed;
  const session = await negotiateWebRtc({ ...options, onDataChannels(channels) {
    framed = frameRtcPeerChannels(channels);
  } });
  if (framed === void 0) {
    await session.close();
    throw new Error("WEBRTC_CHANNEL_MISSING");
  }
  const selected = framed;
  const retire = () => {
    void session.close().catch(() => void 0);
  };
  selected.signal.addEventListener("abort", retire, { once: true });
  if (selected.signal.aborted) retire();
  const handshake = new AbortController();
  const timer = setTimeout(() => handshake.abort(new Error("WEBRTC_HANDSHAKE_TIMEOUT")), Math.max(1, deadline - Date.now()));
  try {
    await interruptible(selected.ready, AbortSignal.any([handshake.signal, session.signal]));
  } catch (error) {
    await selected.close();
    await session.close();
    throw error;
  } finally {
    clearTimeout(timer);
  }
  return {
    ready: selected.ready,
    signal: selected.signal,
    session,
    live: selected.live,
    get stats() {
      return selected.stats;
    },
    send: (bytes, sendOptions) => selected.send(bytes, sendOptions),
    frames: (signal) => selected.frames(signal),
    async close() {
      await selected.close();
      await session.close();
    }
  };
}
function validateDescription(value, type) {
  if (typeof value !== "object" || value === null || !("type" in value) || value.type !== type || !("sdp" in value) || typeof value.sdp !== "string" || value.sdp.length < 1 || new TextEncoder().encode(value.sdp).length > WEBRTC_LIMITS.sdpBytes) {
    throw new Error("WEBRTC_DESCRIPTION_INVALID");
  }
  return { type, sdp: value.sdp };
}
function interruptible(operation, signal) {
  if (signal.aborted) {
    void operation.catch(() => void 0);
    return Promise.reject(signal.reason);
  }
  return new Promise((resolve, reject) => {
    const abort = () => {
      reject(signal.reason);
    };
    signal.addEventListener("abort", abort, { once: true });
    void operation.then(resolve, reject).finally(() => {
      signal.removeEventListener("abort", abort);
    });
  });
}
function waitFor(connection, event, complete, signal) {
  signal.throwIfAborted();
  if (complete()) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      connection.removeEventListener(event, check);
      signal.removeEventListener("abort", abort);
    };
    const check = () => {
      if (complete()) {
        cleanup();
        resolve();
      }
    };
    const abort = () => {
      cleanup();
      reject(signal.reason);
    };
    connection.addEventListener(event, check);
    signal.addEventListener("abort", abort, { once: true });
    check();
  });
}

// packages/transport-webrtc/src/http.ts
var WEBRTC_HTTP_LIMITS = Object.freeze({ messageBytes: 128 * 1024, pending: 8, connections: 32, timeoutMs: 3e4 });

// packages/peer-session/src/worker-transport.ts
var NEGOTIATE = "chronolog/peer-session/rtc-negotiation/v1";
var MAX_CONNECTIONS = 8;
function serveWorkerWebRtcConnections(endpoint, options = {}) {
  const active = /* @__PURE__ */ new Set();
  let closing, closed = false;
  const receive = (event) => {
    const data = message(event.data);
    if (data?.type !== NEGOTIATE) return;
    const port = data.port;
    if (port === void 0 || typeof port.postMessage !== "function") return;
    const reject = (error) => {
      try {
        port.postMessage({ type: "ended", error });
      } finally {
        port.close();
      }
    };
    if (closed || active.size >= MAX_CONNECTIONS) {
      reject(closed ? "APPLICATION_WORKER_CLOSED" : "APPLICATION_PEER_LIMIT");
      return;
    }
    if (!["offerer", "answerer"].includes(String(data.role)) || !validTimeout(data.timeoutMs) || !validConfiguration(data.configuration)) {
      reject("APPLICATION_WORKER_OPTIONS_INVALID");
      return;
    }
    const lifetime = new AbortController(), received = deferred(), sent = deferred(), signalingClosed = deferred();
    let rtc, stopping;
    let remoteSeen = false, sendRequested = false, sendAcknowledged = false, closeRequested = false, closeAcknowledged = false;
    let lastRoute = 0, routePending = false;
    const end = (reason = new Error("APPLICATION_RTC_CLOSED")) => {
      if (stopping !== void 0) return stopping;
      stopping = Promise.resolve().then(async () => {
        try {
          await rtc?.close();
        } finally {
          port.close();
        }
      });
      void stopping.catch(() => void 0);
      lifetime.abort(reason);
      received.reject(reason);
      sent.reject(reason);
      signalingClosed.reject(reason);
      active.delete(end);
      port.removeEventListener("message", request);
      try {
        port.postMessage({ type: "ended", error: errorMessage(reason) });
      } catch {
      }
      return stopping;
    };
    const request = (event2) => {
      try {
        const input = message(event2.data);
        if (input?.type === "close") {
          void end();
          return;
        }
        if (input?.type === "description" && !remoteSeen) {
          remoteSeen = true;
          received.resolve(description(input.description, data.role === "offerer" ? "answer" : "offer"));
          return;
        }
        if (input?.type === "sent" && sendRequested && !sendAcknowledged) {
          sendAcknowledged = true;
          sent.resolve();
          return;
        }
        if (input?.type === "signaling-closed" && closeRequested && !closeAcknowledged) {
          closeAcknowledged = true;
          signalingClosed.resolve();
          return;
        }
        if (input?.type === "route" && rtc !== void 0 && !routePending && Number.isSafeInteger(input.id) && Number(input.id) > lastRoute) {
          lastRoute = Number(input.id);
          routePending = true;
          void awaitOwnedTask(lifetime.signal, () => rtc.getRoute()).then((value) => {
            lifetime.signal.throwIfAborted();
            port.postMessage({ type: "route", id: input.id, value });
          }, (error) => {
            if (!lifetime.signal.aborted) port.postMessage({ type: "route", id: input.id, error: errorMessage(error) });
          }).catch((error) => {
            void end(error);
          }).finally(() => {
            routePending = false;
          });
          return;
        }
        throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
      } catch (error) {
        void end(error);
      }
    };
    active.add(end);
    port.addEventListener("message", request);
    port.start();
    void (async () => {
      try {
        const candidate = await negotiateWebRtc({
          role: data.role,
          ...data.configuration === void 0 ? {} : { configuration: data.configuration },
          ...options.createPeerConnection === void 0 ? {} : { createPeerConnection: options.createPeerConnection },
          timeoutMs: data.timeoutMs,
          signal: lifetime.signal,
          signaling: {
            messages: { async *[Symbol.asyncIterator]() {
              yield await awaitOwnedTask(lifetime.signal, () => received.promise);
            } },
            async send(value) {
              lifetime.signal.throwIfAborted();
              if (sendRequested) throw new Error("APPLICATION_WORKER_DESCRIPTION_REPEATED");
              sendRequested = true;
              port.postMessage({ type: "send", description: value });
              await awaitOwnedTask(lifetime.signal, () => sent.promise);
            },
            async close() {
              lifetime.signal.throwIfAborted();
              if (!closeRequested) {
                closeRequested = true;
                port.postMessage({ type: "close-signaling" });
              }
              await awaitOwnedTask(lifetime.signal, () => signalingClosed.promise);
            }
          },
          onDataChannels(channels) {
            lifetime.signal.throwIfAborted();
            port.postMessage(
              { type: "channels", reliable: channels.reliable, live: channels.live },
              [channels.reliable, channels.live]
            );
          }
        });
        rtc = candidate;
        if (lifetime.signal.aborted) {
          await candidate.close();
          return;
        }
        candidate.signal.addEventListener("abort", () => {
          void end(candidate.signal.reason);
        }, { once: true });
        if (candidate.signal.aborted) {
          await end(candidate.signal.reason);
          return;
        }
        port.postMessage({ type: "ready" });
      } catch (error) {
        await end(error);
      }
    })().catch(() => void 0);
  };
  const abort = () => {
    void close();
  };
  const close = () => {
    if (closing !== void 0) return closing;
    closed = true;
    endpoint.removeEventListener("message", receive);
    options.signal?.removeEventListener("abort", abort);
    closing = Promise.allSettled([...active].map((end) => end(new Error("APPLICATION_WORKER_CLOSED")))).then(() => void 0);
    return closing;
  };
  endpoint.addEventListener("message", receive);
  options.signal?.addEventListener("abort", abort, { once: true });
  if (options.signal?.aborted === true) abort();
  return { close };
}
async function openWorkerWebRtcConnection(endpoint, options) {
  const timeoutMs = options.timeoutMs ?? 3e4;
  if (!validTimeout(timeoutMs) || !["offerer", "answerer"].includes(options.role)) throw new Error("APPLICATION_WORKER_OPTIONS_INVALID");
  options.signal?.throwIfAborted();
  const channel = new MessageChannel(), port = channel.port1, lifetime = new AbortController();
  const negotiated = deferred();
  let framed, closing;
  let signalingClose, sendSeen = false, readySeen = false, closeSeen = false;
  let routeId = 0, routePending;
  const stopSignaling = () => {
    signalingClose ??= Promise.resolve().then(() => options.signaling.close());
    void signalingClose.catch(() => void 0);
    return signalingClose;
  };
  const close = (reason = new Error("APPLICATION_RTC_CLOSED")) => {
    if (closing !== void 0) return closing;
    closing = Promise.resolve().then(async () => {
      try {
        await framed?.close();
      } finally {
        port.close();
        channel.port2.close();
      }
    });
    void closing.catch(() => void 0);
    lifetime.abort(reason);
    clearTimeout(timer);
    options.signal?.removeEventListener("abort", abort);
    negotiated.reject(reason);
    if (routePending !== void 0) {
      clearTimeout(routePending.timer);
      routePending.result.reject(reason);
      routePending = void 0;
    }
    try {
      port.postMessage({ type: "close" });
    } catch {
    }
    port.removeEventListener("message", receive);
    void stopSignaling();
    return closing;
  };
  const fail = (error) => {
    void close(error);
  };
  const abort = () => {
    fail(options.signal?.reason);
  };
  const receive = (event) => {
    const value = message(event.data);
    try {
      if (value?.type === "ended") throw new Error(typeof value.error === "string" ? value.error : "APPLICATION_RTC_CLOSED");
      if (value?.type === "channels") {
        if (framed !== void 0 || lifetime.signal.aborted) {
          retireTransferred(value);
          throw new Error("APPLICATION_WORKER_CHANNELS_REPEATED");
        }
        try {
          framed = frameRtcPeerChannels({ reliable: value.reliable, live: value.live });
        } catch (error) {
          retireTransferred(value);
          throw error;
        }
        framed.signal.addEventListener("abort", () => fail(framed.signal.reason), { once: true });
        if (framed.signal.aborted) fail(framed.signal.reason);
        return;
      }
      if (value?.type === "send" && !sendSeen) {
        sendSeen = true;
        const outgoing = description(value.description, options.role === "offerer" ? "offer" : "answer");
        void awaitOwnedTask(lifetime.signal, () => options.signaling.send(outgoing)).then(() => {
          lifetime.signal.throwIfAborted();
          port.postMessage({ type: "sent" });
        }).catch(fail);
        return;
      }
      if (value?.type === "close-signaling" && !closeSeen && sendSeen) {
        closeSeen = true;
        void awaitOwnedTask(lifetime.signal, stopSignaling).then(() => {
          lifetime.signal.throwIfAborted();
          port.postMessage({ type: "signaling-closed" });
        }).catch(fail);
        return;
      }
      if (value?.type === "ready" && !readySeen && framed !== void 0 && closeSeen) {
        readySeen = true;
        negotiated.resolve();
        return;
      }
      if (value?.type === "route" && routePending !== void 0 && value.id === routePending.id) {
        const pending = routePending;
        const selected = value.error === void 0 ? route(value.value) : void 0;
        routePending = void 0;
        clearTimeout(pending.timer);
        if (selected !== void 0) pending.result.resolve(selected);
        else pending.result.reject(new Error(typeof value.error === "string" ? value.error : "APPLICATION_WORKER_ROUTE_INVALID"));
        return;
      }
      throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
    } catch (error) {
      fail(error);
    }
  };
  const timer = setTimeout(() => fail(new Error("APPLICATION_WORKER_CONNECTION_TIMEOUT")), timeoutMs);
  port.addEventListener("message", receive);
  port.start();
  options.signal?.addEventListener("abort", abort, { once: true });
  let descriptions;
  try {
    descriptions = options.signaling.messages[Symbol.asyncIterator]();
    lifetime.signal.throwIfAborted();
    endpoint.postMessage({ type: NEGOTIATE, role: options.role, timeoutMs, configuration: options.configuration, port: channel.port2 }, [channel.port2]);
    void awaitOwnedTask(lifetime.signal, () => descriptions.next()).then((item) => {
      lifetime.signal.throwIfAborted();
      if (item.done) throw new Error("APPLICATION_WORKER_SIGNALING_ENDED");
      port.postMessage({ type: "description", description: description(item.value, options.role === "offerer" ? "answer" : "offer") });
    }).catch(fail);
    await awaitOwnedTask(lifetime.signal, () => negotiated.promise);
    const connection = framed;
    await awaitOwnedTask(lifetime.signal, () => connection.ready);
    lifetime.signal.throwIfAborted();
    clearTimeout(timer);
    return {
      signal: lifetime.signal,
      live: connection.live,
      send: (bytes, sendOptions) => connection.send(bytes, sendOptions),
      frames: (signal) => connection.frames(signal),
      close: () => close(),
      getRoute() {
        lifetime.signal.throwIfAborted();
        if (routePending !== void 0) return routePending.result.promise;
        const id = ++routeId;
        if (!Number.isSafeInteger(id)) throw new Error("APPLICATION_WORKER_REQUEST_ID_EXHAUSTED");
        const result = deferred();
        const timer2 = setTimeout(() => fail(new Error("APPLICATION_WORKER_ROUTE_TIMEOUT")), timeoutMs);
        routePending = { id, result, timer: timer2 };
        port.postMessage({ type: "route", id });
        return result.promise;
      }
    };
  } catch (error) {
    await close(error);
    throw error;
  } finally {
    void Promise.resolve().then(() => descriptions?.return?.()).catch(() => void 0);
  }
}
function validTimeout(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 1 && value <= 12e4;
}
function validConfiguration(value) {
  if (value === void 0) return true;
  try {
    return value !== null && typeof value === "object" && !Array.isArray(value) && JSON.stringify(value).length <= 16384;
  } catch {
    return false;
  }
}
function message(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function description(value, expected) {
  const input = message(value);
  if (input?.type !== expected || typeof input.sdp !== "string" || input.sdp.length < 1 || new TextEncoder().encode(input.sdp).length > WEBRTC_LIMITS.sdpBytes) throw new Error("APPLICATION_WORKER_DESCRIPTION_INVALID");
  return { type: expected, sdp: input.sdp };
}
function route(value) {
  const input = message(value), candidates = [null, "host", "srflx", "prflx", "relay"];
  if (input === null || !["direct", "relay", "unknown"].includes(String(input.route)) || !candidates.includes(input.localCandidateType) || !candidates.includes(input.remoteCandidateType)) {
    throw new Error("APPLICATION_WORKER_ROUTE_INVALID");
  }
  return {
    route: input.route,
    localCandidateType: input.localCandidateType,
    remoteCandidateType: input.remoteCandidateType
  };
}
function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => {
    resolve = yes;
    reject = no;
  });
  void promise.catch(() => void 0);
  return { promise, resolve, reject };
}
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}
function retireTransferred(value) {
  for (const key of ["reliable", "live"]) {
    const channel = value[key];
    try {
      channel?.close?.();
    } catch {
    }
  }
}

// packages/peer-session/src/webrtc.ts
async function connectApplicationWebRtc(session, options) {
  const connection = await openWebRtcConnection({ ...options, signal: options.signal === void 0 ? session.signal : AbortSignal.any([session.signal, options.signal]) });
  try {
    const link = await session.connectPeer({
      connection,
      ...options.peerIdentity === void 0 ? {} : { peerIdentity: options.peerIdentity },
      ...options.signal === void 0 ? {} : { signal: options.signal },
      ...options.timeoutMs === void 0 ? {} : { handshakeTimeoutMs: options.timeoutMs }
    });
    await link.synchronize();
    return Object.assign(link, { rtc: connection.session });
  } catch (error) {
    await connection.close();
    throw error;
  }
}
export {
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
