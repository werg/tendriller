import type { PeerDataChannelConnection } from './channel.js';
import type { WebRtcChannels, WebRtcOptions, WebRtcSession } from './types.js';
/**
 * Both fixed negotiated channels are created synchronously on each endpoint.
 * The callback transfers them together to their owning Worker before either
 * ceases to be transferable. Only negotiation remains on the page.
 */
export declare function negotiateWebRtc(options: WebRtcOptions & {
    readonly onDataChannels: (channels: WebRtcChannels) => void;
}): Promise<WebRtcSession>;
export declare function openWebRtcConnection(options: WebRtcOptions): Promise<PeerDataChannelConnection & {
    readonly session: WebRtcSession;
}>;
