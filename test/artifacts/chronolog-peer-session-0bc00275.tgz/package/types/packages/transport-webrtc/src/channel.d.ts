import { frameMessageChannel, type MessageConnection, type PeerMessageConnection, type MessageChannelStats } from '../../records/src/index.js';
import type { RtcDataChannel, WebRtcChannels } from './types.js';
export declare const WEBRTC_LIMITS: Readonly<{
    sdpBytes: number;
    frameBytes: number;
    packetBytes: number;
    queueBytes: number;
    queueFrames: 16;
    bufferedBytes: number;
}>;
export type DataChannelStats = MessageChannelStats;
export type DataChannelConnection = MessageConnection;
export type PeerDataChannelConnection = PeerMessageConnection;
/** RTC supplies ordered history and disposable SCTP lanes to the shared framing owner. */
export declare function frameRtcPeerChannels(channels: WebRtcChannels, options?: Parameters<typeof frameMessageChannel>[1]): PeerDataChannelConnection;
export declare function frameRtcDataChannel(channel: RtcDataChannel, options?: Parameters<typeof frameMessageChannel>[1]): DataChannelConnection;
