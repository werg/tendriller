import type { BytesStore } from '../../records/src/index.js';
import { type ApplicationDescription, type AuthorityBundle, type ParticipantRequest, type ParticipantExchangeOptions, type SignedApplicationDescriptor, type SignedApplicationSchema, type SignedGeneration, type SignedTransitionRequest, type SignedPublication, type PublicationFile } from '../../peer-generation/src/control.js';
import type { ApplicationControlHost } from './recovery.js';
import type { ApplicationParticipant } from './participant-types.js';
type ControlOwner = Pick<ApplicationParticipant, 'device' | 'descriptor' | 'authority' | 'adoptAuthority'>;
export interface ControlParticipantOptions {
    readonly exchange: (request: ParticipantRequest, options: ParticipantExchangeOptions) => Promise<unknown>;
    readonly timeoutMs?: number;
}
export interface ApplicationPublication {
    readonly publication: SignedPublication;
    readonly version: number;
}
export interface PublishedApplicationDefinition {
    readonly descriptor: SignedApplicationDescriptor;
    readonly definition: ApplicationDescription;
    readonly schema: SignedApplicationSchema | null;
}
/**
 * The host is a control participant attached to this device's session. It has a
 * distinct delivery policy and never attaches as an application-data reader.
 * Attaching performs no I/O; explicit lifecycle actions are its only requests.
 */
export declare class ApplicationControlParticipant implements ApplicationControlHost {
    #private;
    readonly role: "control";
    constructor(participant: ControlOwner, store: BytesStore, signal: AbortSignal, options: ControlParticipantOptions);
    get signal(): AbortSignal;
    get policy(): import("../../peer-generation/src/control.js").ParticipantPolicy;
    /** Learn and durably fence newer authority even while its selected data is still missing. */
    application(options?: {
        readonly signal?: AbortSignal;
    }): Promise<AuthorityBundle>;
    selectGeneration(input: SignedTransitionRequest, options?: {
        readonly signal?: AbortSignal;
    }): Promise<SignedGeneration>;
    definition(): Promise<PublishedApplicationDefinition>;
    /** Verify the selected code chain and remember its head outside lossy application history. */
    publication(): Promise<ApplicationPublication | null>;
    /** Save the exact signed code update before returning; retrying its identity never signs new intent. */
    preparePublication(input: {
        readonly operationId: string;
        readonly entry: string;
        readonly files: readonly PublicationFile[];
    }): Promise<SignedPublication>;
    publish(input: SignedPublication, assets: readonly {
        readonly hash: string;
        readonly bytes: string;
    }[]): Promise<ApplicationPublication>;
    close(): Promise<void>;
}
export {};
