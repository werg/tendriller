import { type RtcPeerConnection, type WebRtcOptions, type WebRtcRoute } from '../../transport-webrtc/src/index.js';
import type { FramedPeerConnection } from '../../records/src/index.js';
/** A DedicatedWorker or its owning global scope; application RPC has its own namespace. */
export interface ApplicationWorkerEndpoint {
    postMessage(message: unknown, transfer: Transferable[]): void;
    addEventListener(type: 'message', listener: (event: MessageEvent) => void): void;
    removeEventListener(type: 'message', listener: (event: MessageEvent) => void): void;
}
export interface WorkerWebRtcConnection extends FramedPeerConnection {
    /** Selected ICE pair without exposing addresses to the application. */
    getRoute(): Promise<WebRtcRoute>;
}
/**
 * Page-side RTC mechanics. The Worker chooses peers, owns signaling and policy,
 * and receives both channels before they cease to be transferable. The page
 * never attaches an application peer, authenticates history or chooses recovery.
 */
export declare function serveWorkerWebRtcConnections(endpoint: ApplicationWorkerEndpoint, options?: {
    readonly createPeerConnection?: (configuration: RTCConfiguration) => RtcPeerConnection;
    readonly signal?: AbortSignal;
}): {
    close(): Promise<void>;
};
/**
 * Worker-side raw transport for session.participate(). Only bounded SDP crosses
 * the control port. Framing, peer authentication, history and live data all stay
 * beside the owned session and use its ordinary connectPeer path.
 */
export declare function openWorkerWebRtcConnection(endpoint: ApplicationWorkerEndpoint, options: Omit<WebRtcOptions, 'createPeerConnection'>): Promise<WorkerWebRtcConnection>;
