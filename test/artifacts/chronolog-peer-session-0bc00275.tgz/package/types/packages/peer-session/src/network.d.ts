import type { PeerRevision, SignedAttempt } from '../../peer-generation/src/index.js';
import { type SignalChannel } from '../../signals/src/index.js';
import type { ApplicationParticipant } from './participant-types.js';
import { type FramedPeerConnection } from './network-wire.js';
export { APPLICATION_NETWORK_LIMITS, createFramedPeerConnectionPair } from './network-wire.js';
export type { FramedPeerConnection, PeerLiveLane } from './network-wire.js';
export interface ApplicationPeerLink {
    readonly peerId: string;
    /** Availability of the remote data facet; independent of authenticated live/control traffic. */
    readonly data: 'idle' | 'active' | 'unavailable';
    readonly signal: AbortSignal;
    readonly completion: Promise<void>;
    readonly stats: {
        readonly sentBytes: number;
        readonly receivedBytes: number;
        readonly sentRequests: number;
        readonly receivedRequests: number;
    };
    synchronize(): Promise<void>;
    close(): Promise<void>;
}
/** Internal owner port: every attachment has already proved the remote key. */
export interface ApplicationPeerPort {
    readonly participant: ApplicationParticipant;
    readonly signals: SignalChannel;
    readonly signal: AbortSignal;
    attach(peerId: string, submit: (attempt: SignedAttempt) => Promise<void>, link: {
        close(): Promise<void>;
    }): () => void;
    resume(): Promise<void>;
    /** A complete head received through this authenticated coordinator link. */
    observeHead?(peerId: string, revision: PeerRevision, requestedAt: number): void;
}
export interface ApplicationPeerConnectOptions {
    readonly connection: FramedPeerConnection;
    readonly peerIdentity?: string;
    readonly signal?: AbortSignal;
    readonly handshakeTimeoutMs?: number;
    readonly requestTimeoutMs?: number;
    readonly transferTimeoutMs?: number;
}
declare class PeerDataUnavailableError extends Error {
    constructor();
}
/** A data-resource failure must not retire an otherwise authenticated participant. */
export declare function isPeerDataUnavailable(error: unknown): error is PeerDataUnavailableError;
export declare function connectedApplicationPeers(port: ApplicationPeerPort): readonly ApplicationPeerLink[];
export declare function connectApplicationPeer(port: ApplicationPeerPort, input: ApplicationPeerConnectOptions): Promise<ApplicationPeerLink>;
export declare function connectApplicationPeerPair(left: ApplicationPeerPort, right: ApplicationPeerPort): Promise<{
    synchronize(): Promise<void>;
    close(): Promise<void>;
}>;
