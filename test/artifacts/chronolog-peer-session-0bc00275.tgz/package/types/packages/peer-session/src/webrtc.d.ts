import { type WebRtcOptions, type WebRtcSession } from '../../transport-webrtc/src/index.js';
import type { ApplicationPeerLink } from './network.js';
import type { ApplicationSession } from './session.js';
export type { WebRtcOptions, PeerSignaling, PeerDescription, RtcPeerConnection } from '../../transport-webrtc/src/index.js';
export { openWebRtcConnection } from '../../transport-webrtc/src/index.js';
export { serveWorkerWebRtcConnections, openWorkerWebRtcConnection, type ApplicationWorkerEndpoint, type WorkerWebRtcConnection } from './worker-transport.js';
/** The maintained browser/native composition owns both RTC lanes and peer authentication. */
export declare function connectApplicationWebRtc(session: ApplicationSession, options: WebRtcOptions & {
    readonly peerIdentity?: string;
}): Promise<ApplicationPeerLink & {
    readonly rtc: WebRtcSession;
}>;
