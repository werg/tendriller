import {
  eventExecutionManifest
} from "./chunk-RCDYELQW.mjs";
import {
  APPLICATION_EVENT_CURSOR_LIMIT,
  APPLICATION_PROJECTION_LIMITS,
  ApplicationOperation,
  createPeerReplica
} from "./chunk-5C2UDZJY.mjs";
import {
  AbandonedOperationError,
  ApplicationControlConflictError,
  RecoveredViewError
} from "./chunk-TLZH7OYA.mjs";
import {
  awaitOwnedTask
} from "./chunk-KSC4KBWO.mjs";
import "./chunk-PFEHSVTG.mjs";
import {
  generateX25519KeyPair,
  hpkeOpenBase,
  hpkeSealBase,
  signTransitionRequest,
  validateHistoryPoint,
  validatePeerRevision,
  verifyAuthorityBundle
} from "./chunk-4SXHXSRR.mjs";
import {
  bytesDigest,
  decodePeerValue,
  encodePeerValue,
  peerDigest,
  samePeerValue
} from "./chunk-TF4JHBDD.mjs";
import {
  assertCanonicalCbor,
  assertEventTopic,
  assertValidChangeProgram,
  bytesToHex as bytesToHex2,
  canonicalJson,
  decodeTransactionCore,
  encodeTransactionCore,
  executionManifestArtifacts,
  hexToBytes as hexToBytes2,
  importEd25519PublicKey,
  isEmitStep,
  transactionDigest,
  transactionOrderKey
} from "./chunk-Q44B5CP6.mjs";
import {
  bytesToHex,
  encodeCanonicalCbor,
  equalBytes,
  hexToBytes,
  sha256
} from "./chunk-DACCYORU.mjs";

// packages/materializer/src/runtime.ts
function publicationRequestForRevision(revision) {
  return {
    publicationKey: `revision:${revision.revision}:${revision.contentHash}`,
    expectedRevision: revision.previousRevision,
    targetRevision: revision.revision,
    targetOrderLength: revision.orderLength,
    candidateIdentity: revision.contentHash
  };
}

// packages/materializer/src/event-store.ts
var EventHistoryStore = class {
  constructor(store, key, digest, quota) {
    this.store = store;
    this.key = key;
    this.digest = digest;
    this.quota = quota;
  }
  store;
  key;
  digest;
  quota;
  #anchors = [];
  #prefixBytes = [];
  async load() {
    const bytes = await this.store.get(this.key);
    if (bytes === null) return null;
    if (bytes.length > 1024 || bytes.length > this.quota) throw new Error("EVENT_EXECUTION_STORE_INVALID");
    const value = assertCanonicalCbor(bytes, { maxBytes: 1024, maxItems: 32 });
    if (!Array.isArray(value) || value.length !== 8 || value[0] !== "chronolog/event-head/v2" || !(value[1] instanceof Uint8Array) || !equalBytes(value[1], this.digest) || typeof value[2] !== "bigint" || typeof value[3] !== "bigint" || typeof value[4] !== "bigint" || typeof value[5] !== "bigint" || value[2] < 0n || value[3] < 0n || value[3] > value[5] || value[4] < 0n || value[5] < 0n || value[5] > 100000n || typeof value[7] !== "bigint" || value[7] < 0n || value[7] + BigInt(bytes.length) > BigInt(this.quota) || value[5] > value[7] / 64n || value[6] !== null && (!(value[6] instanceof Uint8Array) || value[6].length !== 32)) throw new Error("EVENT_EXECUTION_STORE_INVALID");
    const count = Number(value[5]), order = new Array(count), sizes = new Array(count);
    const anchors = new Array(count);
    let tail = value[6], used = bytes.length;
    for (let index = count - 1; index >= 0; index--) {
      if (!(tail instanceof Uint8Array)) throw new Error("EVENT_EXECUTION_STORE_INVALID");
      const hash = bytesToHex(tail), node = await this.store.get(`${this.key}/node/${hash}`);
      if (node === null || node.length > this.quota - used || !equalBytes(await sha256(node), tail)) throw new Error("EVENT_EXECUTION_HISTORY_INCOMPLETE");
      used += node.length;
      if (used > this.quota) throw new Error("EVENT_EXECUTION_QUOTA_EXCEEDED");
      const row = assertCanonicalCbor(node, { maxBytes: this.quota, maxByteStringBytes: this.quota, maxItems: 32 });
      if (!Array.isArray(row) || row.length !== 6 || row[0] !== "chronolog/event-record/v1" || row[1] !== BigInt(index) || row[2] !== null && (!(row[2] instanceof Uint8Array) || row[2].length !== 32) || !(row[3] instanceof Uint8Array) || !(row[4] instanceof Uint8Array) || !(row[5] instanceof Uint8Array)) throw new Error("EVENT_EXECUTION_STORE_INVALID");
      order[index] = { txId: row[3], candidateDigest: row[4], canonicalCandidate: row[5], core: decodeTransactionCore(row[5]) };
      anchors[index] = hash;
      sizes[index] = node.length;
      tail = row[2];
    }
    if (tail !== null || sizes.reduce((sum, size) => sum + size, 0) !== Number(value[7])) throw new Error("EVENT_EXECUTION_STORE_INVALID");
    this.#anchors = anchors;
    let total = 0;
    this.#prefixBytes = sizes.map((size) => total += size);
    return { order, revision: value[2], finalLength: Number(value[3]), finalRevision: value[4] };
  }
  async commit(state, difference) {
    if (!Number.isSafeInteger(difference) || difference < 0 || difference > this.#anchors.length || difference > state.order.length || state.order.length > 1e5) throw new Error("EVENT_EXECUTION_STORE_INVALID");
    const anchors = this.#anchors.slice(0, difference), sizes = this.#prefixBytes.slice(0, difference);
    let tail = anchors.at(-1) ?? null, used = sizes.at(-1) ?? 0;
    for (let index = difference; index < state.order.length; index++) {
      const entry = state.order[index];
      const node = encodeCanonicalCbor([
        "chronolog/event-record/v1",
        BigInt(index),
        tail === null ? null : hexToBytes(tail),
        entry.txId,
        entry.candidateDigest,
        entry.canonicalCandidate
      ]);
      used += node.length;
      if (used > this.quota) throw new Error("EVENT_EXECUTION_QUOTA_EXCEEDED");
      const hash = bytesToHex(await sha256(node)), key = `${this.key}/node/${hash}`;
      const existing = await this.store.get(key);
      if (existing === null) await this.store.put(key, node);
      else if (!equalBytes(existing, node)) throw new Error("EVENT_EXECUTION_RECORD_CORRUPT");
      anchors.push(hash);
      sizes.push(used);
      tail = hash;
    }
    const head = encodeCanonicalCbor([
      "chronolog/event-head/v2",
      this.digest,
      state.revision,
      BigInt(state.finalLength),
      state.finalRevision,
      BigInt(state.order.length),
      tail === null ? null : hexToBytes(tail),
      BigInt(used)
    ]);
    if (used + head.length > this.quota) throw new Error("EVENT_EXECUTION_QUOTA_EXCEEDED");
    await this.store.put(this.key, head);
    this.#anchors = anchors;
    this.#prefixBytes = sizes;
    return bytesToHex(await sha256(head));
  }
};

// packages/materializer/src/events.ts
async function createEventMaterializationRuntime(options) {
  if (options.namespace.length === 0) throw new Error("EVENT_EXECUTION_NAMESPACE_REQUIRED");
  const manifest = await eventExecutionManifest();
  const artifacts = await executionManifestArtifacts(manifest);
  const digest = artifacts.executionManifestDigest;
  const key = `event-execution/${options.namespace}`;
  const quota = options.maxHistoryBytes ?? 64 * 1024 * 1024;
  if (!Number.isSafeInteger(quota) || quota < 1024) throw new Error("EVENT_EXECUTION_QUOTA_INVALID");
  let revision = 0n, finalRevision = 0n, finalLength = 0;
  let order = [];
  let outcomes = [];
  let closed = false;
  let tail = Promise.resolve();
  const subscribers = /* @__PURE__ */ new Set();
  const snapshot = () => ({ revision, orderLength: order.length, executionManifestDigest: digest.slice() });
  const serial = async (task) => {
    const previous = tail;
    let release;
    tail = new Promise((resolve) => {
      release = resolve;
    });
    await previous;
    try {
      if (closed) throw new Error("EVENT_EXECUTION_CLOSED");
      return await task();
    } finally {
      release();
    }
  };
  const storage = new EventHistoryStore(options.store, key, digest, quota);
  const evaluate = async (next) => {
    const operations = /* @__PURE__ */ new Set(), transactions = /* @__PURE__ */ new Set(), proposals = /* @__PURE__ */ new Set();
    const result = [];
    for (const [index, entry] of next.entries()) {
      const core = entry.core;
      if (entry.txId.length === 0) {
        throw new Error("EVENT_EXECUTION_INPUT_INVALID");
      }
      if (!equalBytes(core.executionManifestDigest, digest)) throw new Error("EVENT_EXECUTION_PROFILE_UNAVAILABLE");
      if (!equalBytes(encodeTransactionCore(core), entry.canonicalCandidate) || !equalBytes(await transactionDigest(entry.canonicalCandidate), entry.candidateDigest)) throw new Error("EVENT_EXECUTION_INPUT_INVALID");
      assertValidChangeProgram(core.program);
      const transactionId = bytesToHex(entry.txId), proposalId = bytesToHex(entry.candidateDigest);
      if (transactions.has(transactionId)) throw new Error("EVENT_EXECUTION_DUPLICATE_TRANSACTION");
      if (proposals.has(proposalId)) throw new Error("EVENT_EXECUTION_DUPLICATE_PROPOSAL");
      transactions.add(transactionId);
      proposals.add(proposalId);
      const orderKey = transactionOrderKey(core, entry.txId);
      const operation = `${bytesToHex(core.authorId)}/${core.operationId}`;
      const failing = core.program.steps.findIndex((step) => !isEmitStep(step));
      const code = operations.has(operation) ? "operation_conflict" : failing >= 0 ? "profile:sql-disabled" : null;
      operations.add(operation);
      result.push({
        txId: entry.txId.slice(),
        orderKey,
        orderIndex: index,
        outcome: code === null ? "accepted" : "rejected",
        rejectionCode: code,
        failingStatementIndex: code === "profile:sql-disabled" ? failing : null
      });
    }
    return result;
  };
  const persisted = await storage.load();
  if (persisted !== null) {
    revision = persisted.revision;
    finalLength = persisted.finalLength;
    finalRevision = persisted.finalRevision;
    order = [...persisted.order];
    outcomes = await evaluate(order);
  }
  let outcomeIndex = new Map(outcomes.map((outcome) => [bytesToHex(outcome.txId), outcome]));
  const persist = async (state, difference) => {
    try {
      return await storage.commit(state, difference);
    } catch (error) {
      closed = true;
      subscribers.clear();
      throw error;
    }
  };
  const captureApplication = (input = {}) => {
    if (closed) throw new Error("EVENT_EXECUTION_CLOSED");
    const view = input.view ?? "local";
    const length = view === "final" ? finalLength : order.length;
    const selected = order, selectedOutcomes = outcomes;
    return {
      view,
      revision: view === "final" ? finalRevision : revision,
      orderLength: length,
      finalRevision,
      finalOrderLength: finalLength,
      transactionAt(index) {
        if (!Number.isSafeInteger(index) || index < 0 || index >= length) return null;
        const entry = selected[index];
        return { txId: entry.txId.slice(), canonicalCandidate: entry.canonicalCandidate.slice(), outcome: selectedOutcomes[index].outcome };
      }
    };
  };
  return {
    coordinator: {
      materialize: async (input) => {
        const next = structuredClone(input);
        return serial(async () => {
          const nextOutcomes = await evaluate(next);
          for (let i = 0; i < finalLength; i++) if (next[i] === void 0 || !sameIdentity(order[i], next[i])) throw new Error("EVENT_EXECUTION_FINAL_PREFIX_CHANGED");
          const previousById = new Map(order.map((entry) => [bytesToHex(entry.txId), entry]));
          for (const entry of next) {
            const previous = previousById.get(bytesToHex(entry.txId));
            if (previous !== void 0 && !sameIdentity(previous, entry)) throw new Error("EVENT_EXECUTION_IDENTITY_CONFLICT");
          }
          let difference = 0;
          while (difference < order.length && difference < next.length && sameIdentity(order[difference], next[difference])) difference++;
          if (difference === order.length && difference === next.length) return null;
          const previousRevision = revision;
          const nextRevision = revision + 1n;
          const changes = nextOutcomes.flatMap((current) => {
            const before = outcomeIndex.get(bytesToHex(current.txId));
            return before?.outcome === current.outcome && before.rejectionCode === current.rejectionCode ? [] : [{
              txId: current.txId.slice(),
              previous: before?.outcome ?? null,
              current: current.outcome,
              previousRejectionCode: before?.rejectionCode ?? null,
              currentRejectionCode: current.rejectionCode
            }];
          });
          const selected = new Set(next.map((entry) => bytesToHex(entry.txId)));
          for (const removed of outcomes) if (!selected.has(bytesToHex(removed.txId))) changes.push({
            txId: removed.txId.slice(),
            previous: removed.outcome,
            current: null,
            previousRejectionCode: removed.rejectionCode,
            currentRejectionCode: null
          });
          const contentHash = await persist({ order: next, revision: nextRevision, finalLength, finalRevision }, difference);
          order = next;
          outcomes = nextOutcomes;
          revision = nextRevision;
          outcomeIndex = new Map(outcomes.map((outcome) => [bytesToHex(outcome.txId), outcome]));
          const result = {
            revision,
            previousRevision,
            orderLength: order.length,
            replayFromIndex: difference,
            replayedTransactions: order.length - difference,
            checkpointPrefix: difference,
            contentHash,
            manifestDigest: digest.slice(),
            earliestChangedOrderIndex: difference,
            outcomeChanges: changes
          };
          for (const subscriber of [...subscribers]) {
            try {
              subscriber(snapshot());
            } catch {
            }
          }
          return { revision: result, publication: publicationRequestForRevision(result) };
        });
      },
      publishFinal: (length) => serial(async () => {
        if (!Number.isSafeInteger(length) || length < finalLength || length > order.length) throw new Error("EVENT_EXECUTION_FINAL_PREFIX_INVALID");
        if (length === finalLength) return;
        await persist({ order, revision, finalLength: length, finalRevision: finalRevision + 1n }, order.length);
        finalLength = length;
        finalRevision++;
      })
    },
    queries: {
      capabilities: Object.freeze({ sql: false }),
      get revision() {
        return revision;
      },
      get orderLength() {
        return order.length;
      },
      get finalRevision() {
        return finalRevision;
      },
      get finalOrderLength() {
        return finalLength;
      },
      get executionManifestDigest() {
        return digest.slice();
      },
      proposalIdAt(index) {
        return order[index]?.txId.slice() ?? null;
      },
      localSql() {
        throw new Error("SQL_DISABLED_FOR_EVENT_PROFILE");
      },
      outcome(id) {
        return structuredClone(outcomeIndex.get(bytesToHex(id)) ?? null);
      },
      subscribe(subscriber) {
        subscribers.add(subscriber);
        return () => {
          subscribers.delete(subscriber);
        };
      },
      captureApplication,
      captureRead(input = {}) {
        const application = captureApplication(input);
        let released = false;
        return {
          ...application,
          query() {
            if (released) throw new Error("VIEW_RELEASED");
            throw new Error("SQL_DISABLED_FOR_EVENT_PROFILE");
          },
          release() {
            released = true;
          }
        };
      }
    },
    publications: {
      async publish(request) {
        if (closed) throw new Error("EVENT_EXECUTION_CLOSED");
        if (request.targetRevision !== revision || request.targetOrderLength !== order.length) throw new Error("EVENT_EXECUTION_PUBLICATION_MISMATCH");
        return { status: "already_current", publicationKey: request.publicationKey, ...snapshot() };
      },
      async reconcile(expected) {
        if (closed) throw new Error("EVENT_EXECUTION_CLOSED");
        if (expected.targetOrderLength !== order.length || expected.targetRevision !== void 0 && expected.targetRevision !== revision) throw new Error("EVENT_EXECUTION_RECONCILIATION_MISMATCH");
        return { status: "reconciled", publicationKey: null, ...snapshot() };
      }
    },
    close() {
      closed = true;
      subscribers.clear();
    }
  };
}
function sameIdentity(left, right) {
  return equalBytes(left.txId, right.txId) && equalBytes(left.candidateDigest, right.candidateDigest) && equalBytes(left.canonicalCandidate, right.canonicalCandidate);
}

// packages/peer-session/src/recovery.ts
function isControlConflict(error) {
  return error !== null && typeof error === "object" && "code" in error && error.code === "peer_generation_conflict";
}
var ApplicationRecovery = class {
  #replica;
  #store;
  #adoptAuthority;
  #signal;
  #lifetime = new AbortController();
  #key;
  #tail = Promise.resolve();
  constructor(options) {
    this.#replica = options.replica;
    this.#store = options.store;
    this.#adoptAuthority = options.adoptAuthority;
    this.#signal = AbortSignal.any([options.signal, this.#lifetime.signal]);
    this.#key = `peer-session/transitions/v1/${options.replica.descriptor.applicationId}`;
  }
  async inspect() {
    await this.#tail;
    return structuredClone(await this.#journal());
  }
  /** Select this device's complete usable prefix after the caller's reconnect grace policy. */
  takeover(host, options = {}) {
    return this.#select(host, options.coordinator ?? this.#replica.device.publicKey, "takeover", options.transitionId, options.signal, options.expected);
  }
  /** Planned retirement requires the successor's signed retention of the exact current prefix. */
  handover(host, options) {
    return this.#select(host, options.coordinator, "handover", options.transitionId, options.signal);
  }
  /** Fence new work and finish local journal work without waiting for a remote reply. */
  close() {
    this.#lifetime.abort(new Error("APPLICATION_RECOVERY_CLOSED"));
    return this.#tail.then(() => void 0);
  }
  #select(host, coordinator, reason, transitionId, externalSignal, expectation) {
    const signal = externalSignal === void 0 ? this.#signal : AbortSignal.any([this.#signal, externalSignal]);
    const expected = expectation === void 0 ? void 0 : structuredClone(expectation);
    const operation = this.#tail.then(async () => {
      signal.throwIfAborted();
      if (expected !== void 0) {
        validateHistoryPoint(expected.point);
        if (!/^[0-9a-f]{64}$/u.test(expected.generation) || !Number.isSafeInteger(expected.controlRevision) || expected.controlRevision < 0) throw new Error("APPLICATION_RECOVERY_EXPECTATION_INVALID");
      }
      if (transitionId !== void 0 && (transitionId.length < 1 || transitionId.length > 128)) throw new Error("APPLICATION_TRANSITION_ID_INVALID");
      if (!/^[0-9a-f]{64}$/u.test(coordinator)) throw new Error("APPLICATION_COORDINATOR_INVALID");
      const journal = await this.#journal(signal);
      let entry = transitionId === void 0 ? [...journal].reverse().find((value) => value.selected === null && !value.superseded) : journal.find((value) => value.request.payload.transitionId === transitionId);
      if (entry !== void 0 && (entry.request.payload.coordinator !== coordinator || entry.request.payload.reason !== reason)) {
        throw new Error("APPLICATION_TRANSITION_ID_REUSED");
      }
      if (entry !== void 0 && expected !== void 0 && (entry.request.payload.expectedGeneration !== expected.generation || entry.request.payload.controlRevision !== expected.controlRevision || entry.request.payload.base?.point.generation !== expected.point.generation || entry.request.payload.base.point.sequence !== expected.point.sequence || entry.request.payload.base.point.root !== expected.point.root)) {
        throw new Error("APPLICATION_RECOVERY_PROPOSAL_CHANGED");
      }
      if (entry?.superseded === true) throw new ApplicationControlConflictError();
      if (entry === void 0) {
        const bundle = await this.#hostCall(() => host.application({ signal }), signal);
        signal.throwIfAborted();
        await verifyAuthorityBundle(bundle, this.#replica.authority.descriptor);
        signal.throwIfAborted();
        await this.#adoptAuthority(bundle);
        signal.throwIfAborted();
        const generation = this.#replica.generation;
        if (expected !== void 0 && (expected.generation !== generation.id || expected.controlRevision !== generation.payload.controlRevision)) {
          throw new Error("APPLICATION_RECOVERY_PROPOSAL_CHANGED");
        }
        if (reason === "takeover" && this.#replica.isCoordinator && this.#replica.ready) return null;
        if (reason === "handover" && !this.#replica.ready) throw new Error("PEER_RECOVERY_PREFIX_INCOMPLETE");
        if (reason === "handover" && (!this.#replica.isCoordinator || coordinator === this.#replica.device.publicKey)) {
          throw new Error("APPLICATION_HANDOVER_REQUIRES_CURRENT_COORDINATOR");
        }
        const base = await this.#replica.recoveryPoint();
        signal.throwIfAborted();
        if (this.#replica.generation.id !== generation.id || expected !== void 0 && (expected.point.generation !== base.point.generation || expected.point.sequence !== base.point.sequence || expected.point.root !== base.point.root)) {
          throw new Error("APPLICATION_RECOVERY_PROPOSAL_CHANGED");
        }
        if ((reason === "handover" || coordinator !== this.#replica.device.publicKey) && (!this.#replica.ready || !this.#replica.shared(base.point).some((receipt) => receipt.payload.peer === coordinator && receipt.payload.point.generation === base.point.generation && receipt.payload.point.sequence === base.point.sequence && receipt.payload.point.root === base.point.root))) {
          throw new Error(reason === "handover" ? "APPLICATION_HANDOVER_REQUIRES_RETAINED_PREFIX" : "APPLICATION_TAKEOVER_REQUIRES_RETAINED_PREFIX");
        }
        if (journal.length >= 64) throw new Error("APPLICATION_TRANSITION_JOURNAL_FULL");
        const descriptor = this.#replica.descriptor;
        const request2 = await signTransitionRequest({
          applicationId: descriptor.applicationId,
          profile: descriptor.profile,
          policy: descriptor.policy,
          expectedGeneration: generation.id,
          coordinator,
          requester: this.#replica.device.publicKey,
          controlRevision: generation.payload.controlRevision,
          base,
          transitionId: transitionId ?? crypto.randomUUID(),
          reason
        }, this.#replica.device);
        await (await verifyAuthorityBundle(this.#replica.authority)).authorizeTransition(request2);
        signal.throwIfAborted();
        entry = { request: request2, selected: null, superseded: false };
        journal.push(entry);
        await this.#store.put(this.#key, encodePeerValue(journal));
      }
      signal.throwIfAborted();
      const request = entry.request;
      try {
        const selected = await this.#hostCall(() => host.selectGeneration(request, { signal }), signal);
        signal.throwIfAborted();
        const bundle = await this.#hostCall(() => host.application({ signal }), signal);
        signal.throwIfAborted();
        await verifyAuthorityBundle(bundle, this.#replica.authority.descriptor);
        signal.throwIfAborted();
        const observed = bundle.generations.find((generation) => generation.id === selected.id);
        if (observed === void 0 || await peerDigest(observed.payload.transition) !== await peerDigest(entry.request)) {
          throw new Error("APPLICATION_TRANSITION_REPLY_MISMATCH");
        }
        await this.#adoptAuthority(bundle);
        const notice = await this.#replica.adopt(bundle) ?? this.#replica.inspectRecovery().findLast((value) => value.generation === selected.id) ?? null;
        signal.throwIfAborted();
        const index = journal.indexOf(entry);
        journal[index] = { request: entry.request, selected: selected.id, superseded: false };
        await this.#store.put(this.#key, encodePeerValue(journal));
        return notice;
      } catch (error) {
        if (isControlConflict(error)) {
          const bundle = await this.#hostCall(() => host.application({ signal }), signal);
          signal.throwIfAborted();
          await verifyAuthorityBundle(bundle, this.#replica.authority.descriptor);
          signal.throwIfAborted();
          const expected2 = entry.request.payload.expectedGeneration;
          if (bundle.generations.at(-1)?.id === expected2 || !bundle.generations.some((generation) => generation.id === expected2)) {
            throw new Error("APPLICATION_TRANSITION_CONFLICT_UNCONFIRMED", { cause: error });
          }
          journal[journal.indexOf(entry)] = { ...entry, superseded: true };
          await this.#store.put(this.#key, encodePeerValue(journal));
          signal.throwIfAborted();
          await this.#adoptAuthority(bundle);
        }
        throw error;
      }
    });
    this.#tail = operation.catch(() => void 0);
    return operation;
  }
  async #journal(signal = this.#signal) {
    signal.throwIfAborted();
    const bytes = await this.#store.get(this.#key);
    signal.throwIfAborted();
    if (bytes === null) return [];
    const value = decodePeerValue(bytes);
    if (!Array.isArray(value) || value.length > 64 || value.some((entry) => entry.request?.payload?.applicationId !== this.#replica.descriptor.applicationId || entry.request.payload.requester !== this.#replica.device.publicKey || typeof entry.superseded !== "boolean" || entry.selected !== null && !/^[0-9a-f]{64}$/u.test(entry.selected))) throw new Error("APPLICATION_TRANSITION_JOURNAL_INVALID");
    return value;
  }
  #hostCall(call, signal) {
    return awaitOwnedTask(signal, call);
  }
};

// packages/peer-session/src/content.ts
var CONTENT_CHUNK_BYTES = 65536;
var MAX_CONTENT_BYTES = 128 * 1024 * 1024;
var MAX_SOURCES = 8;
var MAX_SOURCE_REQUESTS = 8;
var MAX_RETENTIONS = 16;
var CONTENT_PROFILE = "peer-content-v1";
var RETENTION_DOMAIN = "chronolog/peer-content/retained/v1";
var ApplicationContent = class {
  #replica;
  #store;
  #storageId;
  #keys;
  #acquireKey;
  #prefix;
  #sources = /* @__PURE__ */ new Map();
  #lifetime = new AbortController();
  #pending = Promise.resolve();
  #sourceRequests = 0;
  constructor(options) {
    this.#replica = options.replica;
    this.#store = options.store;
    this.#storageId = options.storageId;
    this.#keys = options.epochKeys;
    this.#acquireKey = options.acquireKey;
    this.#prefix = `peer-content/${this.#replica.descriptor.applicationId}/${this.#replica.descriptor.historyId}`;
  }
  async stage(options) {
    const control = this.#access(this.#replica.device.publicKey, true);
    integer(options.bytes, MAX_CONTENT_BYTES);
    const mediaType = options.mediaType ?? "application/octet-stream";
    media(mediaType);
    const stage = {
      profile: CONTENT_PROFILE,
      applicationId: this.#replica.descriptor.applicationId,
      historyId: this.#replica.descriptor.historyId,
      stageId: bytesToHex2(crypto.getRandomValues(new Uint8Array(16))),
      epoch: control.epoch,
      bytes: options.bytes,
      mediaType,
      committed: null
    };
    await this.#key(stage.epoch);
    this.#access(this.#replica.device.publicKey, true);
    await this.#store.put(this.#stageKey(stage.stageId), encode(stage));
    this.#lifetime.signal.throwIfAborted();
    return this.#upload(stage.stageId);
  }
  async resume(id) {
    await this.#stage(id);
    return this.#upload(id);
  }
  attachSource(peerId, source) {
    this.#access(peerId);
    if (this.#sources.has(peerId) || this.#sources.size >= MAX_SOURCES) throw new Error("CONTENT_SOURCE_LIMIT");
    const attached = { source, lifetime: new AbortController() };
    this.#sources.set(peerId, attached);
    return () => {
      if (this.#sources.get(peerId) !== attached) return;
      this.#sources.delete(peerId);
      attached.lifetime.abort(new Error("CONTENT_SOURCE_DETACHED"));
    };
  }
  async *read(reference, options = {}) {
    this.#access(this.#replica.device.publicKey);
    this.#reference(reference);
    const offset = options.offset ?? 0, length = options.length ?? reference.bytes - offset;
    integer(offset, reference.bytes);
    integer(length, reference.bytes - offset);
    const signal = this.#signal(options.signal);
    signal.throwIfAborted();
    const manifest = await this.#manifest(reference, signal);
    if (manifest === null) throw new Error("CONTENT_UNAVAILABLE");
    for (let index = Math.floor(offset / CONTENT_CHUNK_BYTES); index * CONTENT_CHUNK_BYTES < offset + length; index++) {
      this.#access(this.#replica.device.publicKey);
      signal.throwIfAborted();
      const chunk = await this.#chunk(reference, manifest, index, signal);
      if (chunk === null) throw new Error("CONTENT_UNAVAILABLE");
      const plain = await this.#decrypt(manifest, index, chunk);
      this.#access(this.#replica.device.publicKey);
      signal.throwIfAborted();
      yield plain.slice(Math.max(0, offset - index * CONTENT_CHUNK_BYTES), Math.min(plain.length, offset + length - index * CONTENT_CHUNK_BYTES));
    }
  }
  /** Called only after the connection authenticated requester; rechecks current controls. */
  async serveManifest(requester, reference) {
    this.#access(requester);
    this.#access(this.#replica.device.publicKey);
    this.#reference(reference);
    const bytes = await this.#store.get(`${this.#prefix}/manifest/${reference.id}`);
    this.#access(requester);
    const manifest = bytes === null ? null : await this.#verifyManifest(reference, decode(bytes));
    this.#access(requester);
    this.#access(this.#replica.device.publicKey);
    return manifest;
  }
  async serveChunk(requester, reference, index) {
    const manifest = await this.serveManifest(requester, reference);
    if (manifest === null) return null;
    integer(index, manifest.chunks.length - 1);
    const bytes = await this.#store.get(this.#chunkKey(manifest.chunks[index].hash));
    this.#access(requester);
    this.#access(this.#replica.device.publicKey);
    if (bytes !== null) await this.#verifyChunk(manifest.chunks[index], bytes);
    this.#access(requester);
    this.#access(this.#replica.device.publicKey);
    return bytes;
  }
  async retained(reference) {
    this.#access(this.#replica.device.publicKey);
    const manifest = await this.serveManifest(this.#replica.device.publicKey, reference);
    if (manifest === null) throw new Error("CONTENT_NOT_RETAINED");
    for (let index = 0; index < manifest.chunks.length; index++) {
      const bytes = await this.serveChunk(this.#replica.device.publicKey, reference, index);
      if (bytes === null) throw new Error("CONTENT_NOT_RETAINED");
      await this.#decrypt(manifest, index, bytes);
    }
    const generation = this.#replica.generation;
    const payload = {
      reference: structuredClone(reference),
      peer: this.#replica.device.publicKey,
      storageId: this.#storageId,
      generation: generation.id,
      controlRevision: generation.payload.controlRevision,
      retainedAt: Date.now()
    };
    const signature = await crypto.subtle.sign("Ed25519", this.#replica.device.privateKey, signedBytes(payload));
    this.#access(this.#replica.device.publicKey);
    return { payload, signature: bytesToHex2(new Uint8Array(signature)) };
  }
  /** Fetch a complete independent copy, then attempt to announce its durable retention. */
  async retain(reference, options = {}) {
    const signal = this.#signal(options.signal);
    for await (const _chunk of this.read(reference, options)) {
    }
    const receipt = await this.retained(reference);
    signal.throwIfAborted();
    for (const [peer, attached] of [...this.#sources]) {
      const { source } = attached;
      const observe = source.observeRetention?.bind(source);
      if (observe === void 0) continue;
      try {
        await this.#sourceCall(peer, attached, () => observe(receipt), signal);
      } catch {
        signal.throwIfAborted();
      }
    }
    signal.throwIfAborted();
    return receipt;
  }
  async observeRetention(receipt) {
    await this.#verifyRetention(receipt);
    await this.#mutate(async () => {
      const prior = await this.#retentions(receipt.payload.reference);
      const next = prior.filter((item) => item.payload.peer !== receipt.payload.peer || item.payload.storageId !== receipt.payload.storageId);
      next.push(structuredClone(receipt));
      this.#access(receipt.payload.peer);
      this.#access(this.#replica.device.publicKey);
      await this.#store.put(`${this.#prefix}/retention/${receipt.payload.reference.id}`, encode(next.slice(-MAX_RETENTIONS)));
    });
  }
  /** Past durable-copy observations, never a claim that a provider is reachable now. */
  async retention(reference) {
    this.#access(this.#replica.device.publicKey);
    this.#reference(reference);
    const result = [];
    for (const receipt of await this.#retentions(reference)) {
      try {
        await this.#verifyRetention(receipt);
        result.push(receipt);
      } catch {
        this.#lifetime.signal.throwIfAborted();
      }
    }
    this.#access(this.#replica.device.publicKey);
    return result;
  }
  close() {
    if (this.#lifetime.signal.aborted) return;
    this.#lifetime.abort(new Error("CONTENT_CLOSED"));
    for (const attached of this.#sources.values()) attached.lifetime.abort(this.#lifetime.signal.reason);
    this.#sources.clear();
  }
  #signal(signal) {
    return signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, signal]);
  }
  #sourceAccess(peer, attached, signal) {
    signal.throwIfAborted();
    attached.lifetime.signal.throwIfAborted();
    if (this.#sources.get(peer) !== attached) throw new Error("CONTENT_SOURCE_DETACHED");
    this.#access(peer);
    this.#access(this.#replica.device.publicKey);
  }
  async #sourceCall(peer, attached, call, signal) {
    this.#sourceAccess(peer, attached, signal);
    const lifetime = AbortSignal.any([signal, attached.lifetime.signal]);
    const value = await this.#providerCall(lifetime, call);
    this.#sourceAccess(peer, attached, signal);
    return value;
  }
  #providerCall(signal, call) {
    return awaitOwnedTask(signal, () => {
      if (this.#sourceRequests >= MAX_SOURCE_REQUESTS) throw new Error("CONTENT_SOURCE_BUSY");
      this.#sourceRequests++;
      let request;
      try {
        request = Promise.resolve(call());
      } catch (error) {
        this.#sourceRequests--;
        throw error;
      }
      void request.then(() => {
        this.#sourceRequests--;
      }, () => {
        this.#sourceRequests--;
      });
      return request;
    });
  }
  #access(peerId, write = false) {
    this.#lifetime.signal.throwIfAborted();
    const bundle = this.#replica.authority, control = bundle.controls[this.#replica.generation.payload.controlRevision].payload;
    const grant = control.grants.find((item) => item.publicKey === peerId);
    if (grant?.reader !== true || write && grant.writer !== true) throw new Error("CONTENT_ACCESS_DENIED");
    return control;
  }
  async #key(epoch) {
    const acquire = this.#acquireKey;
    if (!this.#keys.has(epoch) && acquire !== void 0) await this.#providerCall(this.#lifetime.signal, () => acquire(epoch));
    this.#access(this.#replica.device.publicKey);
    const bytes = this.#keys.get(epoch);
    if (bytes?.length !== 32) throw new Error("CONTENT_KEY_UNAVAILABLE");
    const control = this.#replica.authority.controls.find((item) => item.payload.epoch === epoch)?.payload;
    if (control === void 0 || await bytesDigest(bytes) !== control.keyDigest) throw new Error("CONTENT_KEY_MISMATCH");
    this.#access(this.#replica.device.publicKey);
    return crypto.subtle.importKey("raw", new Uint8Array(bytes), "AES-GCM", false, ["encrypt", "decrypt"]);
  }
  #stageKey(id) {
    return `${this.#prefix}/stage/${id}`;
  }
  #chunkKey(hash) {
    return `${this.#prefix}/chunk/${hash}`;
  }
  async #stage(id) {
    if (!/^[0-9a-f]{32}$/u.test(id)) throw new Error("CONTENT_STAGE_INVALID");
    this.#access(this.#replica.device.publicKey, true);
    const bytes = await this.#store.get(this.#stageKey(id));
    if (bytes === null) throw new Error("CONTENT_STAGE_MISSING");
    const stage = decode(bytes);
    if (stage.stageId !== id || stage.applicationId !== this.#replica.descriptor.applicationId || stage.historyId !== this.#replica.descriptor.historyId) throw new Error("CONTENT_STAGE_CORRUPT");
    if (stage.epoch !== this.#access(this.#replica.device.publicKey, true).epoch && stage.committed === null) throw new Error("CONTENT_STAGE_EPOCH_CHANGED");
    return stage;
  }
  #upload(id) {
    return {
      id,
      write: (index, bytes) => this.#mutate(async () => {
        const stage = await this.#stage(id), count = Math.ceil(stage.bytes / CONTENT_CHUNK_BYTES);
        integer(index, count - 1);
        const size = Math.min(CONTENT_CHUNK_BYTES, stage.bytes - index * CONTENT_CHUNK_BYTES);
        if (!(bytes instanceof Uint8Array) || bytes.length !== size) throw new Error("CONTENT_CHUNK_SIZE_INVALID");
        const plain = bytes.slice(), plaintextHash = await bytesDigest(plain), descriptorKey = `${this.#stageKey(id)}/${index}`;
        const saved = await this.#store.get(descriptorKey);
        if (saved !== null) {
          if (decode(saved).plaintextHash !== plaintextHash) throw new Error("CONTENT_CHUNK_REUSED");
          return;
        }
        if (stage.committed !== null) throw new Error("CONTENT_STAGE_COMMITTED");
        const nonce = crypto.getRandomValues(new Uint8Array(12));
        const encrypted = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce, additionalData: aad(stage, index) }, await this.#key(stage.epoch), plain));
        const descriptor = { hash: await bytesDigest(encrypted), nonce: bytesToHex2(nonce), bytes: size, plaintextHash };
        if (stage.epoch !== this.#access(this.#replica.device.publicKey, true).epoch) throw new Error("CONTENT_STAGE_EPOCH_CHANGED");
        await this.#store.put(this.#chunkKey(descriptor.hash), encrypted);
        if (stage.epoch !== this.#access(this.#replica.device.publicKey, true).epoch) throw new Error("CONTENT_STAGE_EPOCH_CHANGED");
        await this.#store.put(descriptorKey, encode(descriptor));
      }),
      progress: async () => {
        const stage = await this.#stage(id), missingChunks = [];
        let storedBytes = 0;
        for (let index = 0; index < Math.ceil(stage.bytes / CONTENT_CHUNK_BYTES); index++) {
          const bytes = await this.#store.get(`${this.#stageKey(id)}/${index}`);
          if (bytes === null) missingChunks.push(index);
          else storedBytes += decode(bytes).bytes;
        }
        this.#access(this.#replica.device.publicKey, true);
        return { bytes: stage.bytes, storedBytes, missingChunks };
      },
      commit: () => this.#mutate(async () => {
        const stage = await this.#stage(id);
        if (stage.committed !== null) return structuredClone(stage.committed);
        const chunks = [];
        for (let index = 0; index < Math.ceil(stage.bytes / CONTENT_CHUNK_BYTES); index++) {
          const saved = await this.#store.get(`${this.#stageKey(id)}/${index}`);
          if (saved === null) throw new Error("CONTENT_STAGE_INCOMPLETE");
          const { hash, nonce, bytes } = decode(saved);
          const body = await this.#store.get(this.#chunkKey(hash));
          if (body === null) throw new Error("CONTENT_STAGE_INCOMPLETE");
          await this.#verifyChunk({ hash, nonce, bytes }, body);
          chunks.push({ hash, nonce, bytes });
        }
        const { committed: _committed, ...metadata } = stage;
        const manifest = { ...metadata, chunks }, contentId = await bytesDigest(encode(manifest));
        const reference = {
          profile: CONTENT_PROFILE,
          applicationId: stage.applicationId,
          historyId: stage.historyId,
          id: contentId,
          epoch: stage.epoch,
          bytes: stage.bytes,
          mediaType: stage.mediaType
        };
        if (stage.epoch !== this.#access(this.#replica.device.publicKey, true).epoch) throw new Error("CONTENT_STAGE_EPOCH_CHANGED");
        await this.#store.put(`${this.#prefix}/manifest/${contentId}`, encode(manifest));
        if (stage.epoch !== this.#access(this.#replica.device.publicKey, true).epoch) throw new Error("CONTENT_STAGE_EPOCH_CHANGED");
        await this.#store.put(this.#stageKey(stage.stageId), encode({ ...stage, committed: reference }));
        this.#lifetime.signal.throwIfAborted();
        return reference;
      })
    };
  }
  #reference(value) {
    if (value === null || value.profile !== CONTENT_PROFILE || value.applicationId !== this.#replica.descriptor.applicationId || value.historyId !== this.#replica.descriptor.historyId || !/^[0-9a-f]{64}$/u.test(value.id)) throw new Error("CONTENT_REFERENCE_INVALID");
    integer(value.epoch, Number.MAX_SAFE_INTEGER);
    integer(value.bytes, MAX_CONTENT_BYTES);
    media(value.mediaType);
    if (Object.keys(value).sort().join(",") !== "applicationId,bytes,epoch,historyId,id,mediaType,profile") throw new Error("CONTENT_REFERENCE_INVALID");
  }
  async #verifyManifest(reference, manifest) {
    this.#reference(reference);
    if (manifest.profile !== CONTENT_PROFILE || manifest.applicationId !== reference.applicationId || manifest.historyId !== reference.historyId || manifest.epoch !== reference.epoch || manifest.bytes !== reference.bytes || manifest.mediaType !== reference.mediaType || !/^[0-9a-f]{32}$/u.test(manifest.stageId) || !Array.isArray(manifest.chunks) || manifest.chunks.length !== Math.ceil(reference.bytes / CONTENT_CHUNK_BYTES)) throw new Error("CONTENT_MANIFEST_INVALID");
    for (const [index, chunk] of manifest.chunks.entries()) {
      if (!/^[0-9a-f]{64}$/u.test(chunk.hash) || !/^[0-9a-f]{24}$/u.test(chunk.nonce) || chunk.bytes !== Math.min(CONTENT_CHUNK_BYTES, reference.bytes - index * CONTENT_CHUNK_BYTES)) throw new Error("CONTENT_MANIFEST_INVALID");
    }
    if (await bytesDigest(encode(manifest)) !== reference.id) throw new Error("CONTENT_MANIFEST_HASH_MISMATCH");
    return structuredClone(manifest);
  }
  async #verifyChunk(chunk, bytes) {
    if (bytes.length !== chunk.bytes + 16 || await bytesDigest(bytes) !== chunk.hash) throw new Error("CONTENT_CHUNK_HASH_MISMATCH");
  }
  async #manifest(reference, signal) {
    const local = await this.serveManifest(this.#replica.device.publicKey, reference);
    signal.throwIfAborted();
    if (local !== null) return local;
    for (const [peer, attached] of [...this.#sources]) {
      try {
        const value = await this.#sourceCall(peer, attached, () => attached.source.manifest(reference), signal);
        if (value === null) continue;
        const manifest = await this.#verifyManifest(reference, value);
        this.#sourceAccess(peer, attached, signal);
        await this.#store.put(`${this.#prefix}/manifest/${reference.id}`, encode(manifest));
        this.#sourceAccess(peer, attached, signal);
        return manifest;
      } catch {
        signal.throwIfAborted();
      }
    }
    return null;
  }
  async #chunk(reference, manifest, index, signal) {
    const descriptor = manifest.chunks[index];
    const local = await this.#store.get(this.#chunkKey(descriptor.hash));
    signal.throwIfAborted();
    if (local !== null) {
      await this.#verifyChunk(descriptor, local);
      signal.throwIfAborted();
      return local;
    }
    for (const [peer, attached] of [...this.#sources]) {
      try {
        const value = await this.#sourceCall(peer, attached, () => attached.source.chunk(reference, index), signal);
        if (value === null) continue;
        await this.#verifyChunk(descriptor, value);
        await this.#decrypt(manifest, index, value);
        this.#sourceAccess(peer, attached, signal);
        await this.#store.put(this.#chunkKey(descriptor.hash), value);
        this.#sourceAccess(peer, attached, signal);
        return value;
      } catch {
        signal.throwIfAborted();
      }
    }
    return null;
  }
  async #decrypt(manifest, index, encrypted) {
    const chunk = manifest.chunks[index];
    await this.#verifyChunk(chunk, encrypted);
    const plain = new Uint8Array(await crypto.subtle.decrypt({
      name: "AES-GCM",
      iv: new Uint8Array(hexToBytes2(chunk.nonce)),
      additionalData: aad(manifest, index)
    }, await this.#key(manifest.epoch), new Uint8Array(encrypted)));
    if (plain.length !== chunk.bytes) throw new Error("CONTENT_CHUNK_SIZE_INVALID");
    return plain;
  }
  async #retentions(reference) {
    const bytes = await this.#store.get(`${this.#prefix}/retention/${reference.id}`);
    const result = bytes === null ? [] : decode(bytes);
    if (!Array.isArray(result) || result.length > MAX_RETENTIONS) throw new Error("CONTENT_RETENTION_CORRUPT");
    return result;
  }
  async #verifyRetention(receipt) {
    const value = receipt.payload;
    this.#reference(value.reference);
    this.#access(value.peer);
    this.#access(this.#replica.device.publicKey);
    integer(value.retainedAt, Number.MAX_SAFE_INTEGER);
    integer(value.controlRevision, Number.MAX_SAFE_INTEGER);
    if (typeof value.storageId !== "string" || value.storageId.length > 256 || !/^[0-9a-f]{128}$/u.test(receipt.signature) || !this.#replica.authority.generations.some((generation) => generation.id === value.generation && generation.payload.controlRevision === value.controlRevision)) throw new Error("CONTENT_RETENTION_INVALID");
    if (!await crypto.subtle.verify("Ed25519", await importEd25519PublicKey(hexToBytes2(value.peer)), new Uint8Array(hexToBytes2(receipt.signature)), signedBytes(value))) throw new Error("CONTENT_RETENTION_INVALID");
    this.#access(value.peer);
    this.#access(this.#replica.device.publicKey);
  }
  #mutate(operation) {
    const pending = this.#pending.then(() => {
      this.#lifetime.signal.throwIfAborted();
      return operation();
    });
    this.#pending = pending.catch(() => void 0);
    return pending;
  }
};
function integer(value, max) {
  if (!Number.isSafeInteger(value) || value < 0 || value > max) throw new Error("CONTENT_RANGE_INVALID");
}
function media(value) {
  if (typeof value !== "string" || !/^[a-z0-9][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*$/u.test(value) || value.length > 128) throw new Error("CONTENT_MEDIA_TYPE_INVALID");
}
function encode(value) {
  return new TextEncoder().encode(canonicalJson(value, { maxBytes: 262144, maxNodes: 32768, maxDepth: 16 }));
}
function decode(bytes) {
  return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
}
function aad(value, index) {
  return encode(["chronolog/peer-content/chunk/v1", value.applicationId, value.historyId, value.stageId, value.epoch, index]);
}
function signedBytes(value) {
  return encode([RETENTION_DOMAIN, value]);
}

// packages/peer-session/src/keys.ts
var REQUEST_DOMAIN = "chronolog/peer-generation/key-request/v1";
var SHARE_DOMAIN = "chronolog/peer-generation/key-share/v1";
var MAX_BATCH = 16;
var ApplicationKeyring = class _ApplicationKeyring {
  #identity;
  #store;
  #key;
  #initial;
  #keys = /* @__PURE__ */ new Map();
  #replica;
  #lifetime = new AbortController();
  #tickets = /* @__PURE__ */ new Set();
  #closeTask;
  #tail = Promise.resolve();
  #pendingRequests = 0;
  #listeners = /* @__PURE__ */ new Set();
  #sources = /* @__PURE__ */ new Map();
  #sourceRequests = 0;
  #acquiring = Promise.resolve();
  constructor(device, authority) {
    this.#identity = device.identity;
    this.#store = device.store;
    this.#initial = structuredClone(authority);
    this.#key = `peer-session/keys/${authority.descriptor.payload.applicationId}/${authority.descriptor.payload.historyId}`;
  }
  static async open(options) {
    await verifyAuthorityBundle(options.authority);
    const ring = new _ApplicationKeyring(options.device, options.authority);
    for (const [epoch, key] of await ring.#load()) ring.#keys.set(epoch, key);
    if (options.epochKeys !== void 0 && options.epochKeys.size > 0) await ring.install(options.epochKeys);
    return ring;
  }
  /** This live read-only port is shared by the replica and encrypted content owner. */
  get epochKeys() {
    return this.#keys;
  }
  bind(replica) {
    if (this.#replica !== void 0 || replica.device.publicKey !== this.#identity.publicKey || bytesToHex2(encodePeerValue(replica.authority.descriptor)) !== bytesToHex2(encodePeerValue(this.#initial.descriptor))) throw new Error("APPLICATION_KEYRING_BINDING_INVALID");
    this.#replica = replica;
  }
  missing(requiredEpochs) {
    this.#open();
    return [...new Set(requiredEpochs ?? this.#replica?.requiredEpochs ?? [...this.#commitments().keys()])].filter((epoch) => !this.#keys.has(epoch)).sort((a, b) => a - b);
  }
  async validate() {
    const commitments = this.#commitments();
    for (const [epoch, key] of this.#keys) if (commitments.get(epoch) !== await bytesDigest(key)) throw new Error("APPLICATION_EPOCH_KEY_MISMATCH");
  }
  subscribe(listener) {
    this.#listeners.add(listener);
    return () => {
      this.#listeners.delete(listener);
    };
  }
  /** Maintained peer transports supply key sources; content can acquire older epochs lazily. */
  attachSource(peerId, offer) {
    this.#open();
    this.#reader(peerId);
    if (!this.#sources.has(peerId) && this.#sources.size >= 8) throw new Error("APPLICATION_KEY_SOURCE_LIMIT");
    this.#sources.get(peerId)?.lifetime.abort(new Error("APPLICATION_KEY_SOURCE_DETACHED"));
    const source = { offer, lifetime: new AbortController() };
    this.#sources.set(peerId, source);
    return () => {
      if (this.#sources.get(peerId) !== source) return;
      this.#sources.delete(peerId);
      source.lifetime.abort(new Error("APPLICATION_KEY_SOURCE_DETACHED"));
    };
  }
  ensure(requiredEpochs) {
    const requested = requiredEpochs === void 0 ? void 0 : [...requiredEpochs];
    const operation = this.#acquiring.then(async () => {
      for (let batch = 0; batch < 256; batch++) {
        this.#reader(this.#identity.publicKey);
        if (this.missing(requested).length === 0) return;
        let obtained = false, failure = new Error("PEER_EPOCH_KEY_UNAVAILABLE");
        for (const [peer, source] of [...this.#sources]) {
          const ticket = await this.request(requested);
          if (ticket === null) return;
          const detached = () => {
            ticket.cancel();
          };
          source.lifetime.signal.addEventListener("abort", detached, { once: true });
          if (source.lifetime.signal.aborted) detached();
          try {
            const share = await this.#offer(peer, source, ticket.request);
            await ticket.accept(share);
            obtained = true;
            break;
          } catch (error) {
            this.#open();
            failure = error;
          } finally {
            source.lifetime.signal.removeEventListener("abort", detached);
            ticket.cancel();
          }
        }
        if (!obtained) throw failure;
      }
      if (this.missing(requested).length > 0) throw new Error("APPLICATION_KEY_EXCHANGE_LIMIT");
    });
    this.#acquiring = operation.catch(() => void 0);
    return operation;
  }
  /** Explicit bootstrap/rotation input must match already authenticated control commitments. */
  install(input) {
    return this.#install(input, () => this.#open());
  }
  #install(input, current) {
    const keys = new Map([...input].map(([epoch, key]) => [epoch, key.slice()]));
    const operation = this.#tail.then(async () => {
      this.#open();
      current();
      const commitments = this.#commitments(), stored = await this.#load();
      for (const [epoch, key] of keys) {
        if (!Number.isSafeInteger(epoch) || epoch < 0 || key.length !== 32 || commitments.get(epoch) !== await bytesDigest(key)) throw new Error("APPLICATION_EPOCH_KEY_MISMATCH");
        const existing = stored.get(epoch);
        if (existing !== void 0 && bytesToHex2(existing) !== bytesToHex2(key)) throw new Error("APPLICATION_EPOCH_KEY_CONFLICT");
        stored.set(epoch, key);
      }
      this.#open();
      current();
      await this.#store.put(this.#key, encodePeerValue([...stored].sort(([a], [b]) => a - b).map(([epoch, key]) => [epoch, bytesToHex2(key)])));
      this.#open();
      current();
      for (const [epoch, key] of stored) this.#keys.set(epoch, key);
      for (const listener of [...this.#listeners]) {
        try {
          listener();
        } catch {
        }
      }
    });
    this.#tail = operation.catch(() => void 0);
    return operation;
  }
  /** A fresh ephemeral HPKE receiver is bound to the actual device's signed request. */
  async request(requiredEpochs) {
    this.#reader(this.#identity.publicKey);
    const epochs = this.missing(requiredEpochs).slice(0, MAX_BATCH);
    if (epochs.length === 0) return null;
    if (this.#pendingRequests >= 4) throw new Error("APPLICATION_KEY_REQUEST_LIMIT");
    this.#pendingRequests++;
    const lifetime = new AbortController(), signal = AbortSignal.any([this.#lifetime.signal, lifetime.signal]);
    this.#tickets.add(lifetime);
    let finished = false, accepting = false, released = false;
    const release = () => {
      if (released) return;
      released = true;
      this.#pendingRequests--;
      this.#tickets.delete(lifetime);
    };
    const cancel = () => {
      finished = true;
      lifetime.abort(new Error("APPLICATION_KEY_REQUEST_CLOSED"));
      if (!accepting) release();
    };
    try {
      const receiver = await generateX25519KeyPair(), authority = this.#authority(), generation = authority.generations.at(-1);
      signal.throwIfAborted();
      const controlDigest = await peerDigest(authority.controls[generation.payload.controlRevision]);
      const request = await sign(REQUEST_DOMAIN, {
        applicationId: authority.descriptor.payload.applicationId,
        historyId: authority.descriptor.payload.historyId,
        generation: generation.id,
        controlDigest,
        recipient: this.#identity.publicKey,
        receiverKey: bytesToHex2(receiver.publicKeyBytes),
        nonce: bytesToHex2(crypto.getRandomValues(new Uint8Array(16))),
        epochs
      }, this.#identity);
      await this.#scope(request);
      signal.throwIfAborted();
      const requestDigest = await peerDigest(request);
      signal.throwIfAborted();
      return { request, cancel, accept: async (share) => {
        if (finished || accepting) throw new Error("APPLICATION_KEY_REQUEST_CLOSED");
        accepting = true;
        const current = () => {
          signal.throwIfAborted();
          if (this.#authority().generations.at(-1)?.id !== request.payload.generation) throw new Error("APPLICATION_KEY_REQUEST_EXPIRED");
          this.#reader(request.payload.recipient);
          this.#reader(share.payload.issuer);
        };
        const work = (async () => {
          signal.throwIfAborted();
          await this.#scope(request);
          signal.throwIfAborted();
          if (share.payload.requestDigest !== requestDigest || !Array.isArray(share.payload.keys) || share.payload.keys.length !== epochs.length) throw new Error("APPLICATION_KEY_SHARE_INVALID");
          this.#reader(share.payload.issuer);
          await verify(SHARE_DOMAIN, share, share.payload.issuer);
          current();
          const installed = /* @__PURE__ */ new Map();
          for (const [index, item] of share.payload.keys.entries()) {
            if (item.epoch !== epochs[index] || !/^[0-9a-f]{64}$/u.test(item.encapsulatedKey) || !/^[0-9a-f]{96}$/u.test(item.ciphertext)) throw new Error("APPLICATION_KEY_SHARE_INVALID");
            const context = wrapContext(requestDigest, item.epoch);
            const key = await hpkeOpenBase(receiver.privateKey, receiver.publicKeyBytes, hexToBytes2(item.encapsulatedKey), hexToBytes2(item.ciphertext), context, context);
            current();
            installed.set(item.epoch, key);
          }
          await this.#scope(request);
          current();
          await this.#install(installed, current);
        })();
        const complete = () => {
          accepting = false;
          finished = true;
          release();
        };
        void work.then(complete, complete);
        return awaitOwnedTask(signal, () => work);
      } };
    } catch (error) {
      cancel();
      throw error;
    }
  }
  /** Any current reader holding the committed key can enroll another granted reader. */
  async offer(request) {
    await this.#scope(request);
    this.#reader(this.#identity.publicKey);
    const requestDigest = await peerDigest(request), keys = [];
    for (const epoch of request.payload.epochs) {
      const key = this.#keys.get(epoch);
      if (key === void 0) throw new Error("PEER_EPOCH_KEY_UNAVAILABLE");
      if (this.#commitments().get(epoch) !== await bytesDigest(key)) throw new Error("APPLICATION_EPOCH_KEY_MISMATCH");
      const context = wrapContext(requestDigest, epoch), wrapped = await hpkeSealBase(hexToBytes2(request.payload.receiverKey), key, context, context);
      keys.push({ epoch, encapsulatedKey: bytesToHex2(wrapped.encapsulatedKey), ciphertext: bytesToHex2(wrapped.ciphertext) });
    }
    await this.#scope(request);
    this.#reader(this.#identity.publicKey);
    const share = await sign(SHARE_DOMAIN, { requestDigest, issuer: this.#identity.publicKey, keys }, this.#identity);
    await this.#scope(request);
    return share;
  }
  close() {
    if (this.#closeTask !== void 0) return this.#closeTask;
    this.#lifetime.abort(new Error("APPLICATION_KEYRING_CLOSED"));
    for (const ticket of this.#tickets) ticket.abort(this.#lifetime.signal.reason);
    this.#tickets.clear();
    for (const source of this.#sources.values()) source.lifetime.abort(this.#lifetime.signal.reason);
    this.#listeners.clear();
    this.#sources.clear();
    for (const key of this.#keys.values()) key.fill(0);
    this.#keys.clear();
    this.#closeTask = Promise.allSettled([this.#tail, this.#acquiring]).then(() => void 0);
    return this.#closeTask;
  }
  #open() {
    this.#lifetime.signal.throwIfAborted();
  }
  async #offer(peer, source, request) {
    const signal = AbortSignal.any([this.#lifetime.signal, source.lifetime.signal]);
    const current = () => {
      signal.throwIfAborted();
      this.#reader(peer);
      if (this.#sources.get(peer) !== source) throw new Error("APPLICATION_KEY_SOURCE_DETACHED");
    };
    current();
    const share = await awaitOwnedTask(signal, () => {
      if (this.#sourceRequests >= 8) throw new Error("APPLICATION_KEY_SOURCE_BUSY");
      this.#sourceRequests++;
      let pending;
      try {
        pending = Promise.resolve(source.offer(request));
      } catch (error) {
        this.#sourceRequests--;
        throw error;
      }
      void pending.then(() => {
        this.#sourceRequests--;
      }, () => {
        this.#sourceRequests--;
      });
      return pending;
    });
    current();
    if (share.payload.issuer !== peer) throw new Error("APPLICATION_KEY_SHARE_INVALID");
    return share;
  }
  #authority() {
    this.#open();
    return this.#replica?.authority ?? this.#initial;
  }
  #reader(peer) {
    const authority = this.#authority(), generation = authority.generations.at(-1);
    if (generation === void 0 || authority.controls[generation.payload.controlRevision]?.payload.grants.find((grant) => grant.publicKey === peer)?.reader !== true) throw new Error("APPLICATION_KEY_ACCESS_DENIED");
  }
  #commitments() {
    const result = /* @__PURE__ */ new Map();
    for (const control of this.#authority().controls) {
      const previous = result.get(control.payload.epoch);
      if (previous !== void 0 && previous !== control.payload.keyDigest) throw new Error("APPLICATION_EPOCH_KEY_CONFLICT");
      result.set(control.payload.epoch, control.payload.keyDigest);
    }
    return result;
  }
  async #scope(request) {
    const value = request.payload, authority = this.#authority(), generation = authority.generations.at(-1);
    const epochs = value.epochs;
    if (generation === void 0 || value.applicationId !== authority.descriptor.payload.applicationId || value.historyId !== authority.descriptor.payload.historyId || value.generation !== generation.id || value.controlDigest !== await peerDigest(authority.controls[generation.payload.controlRevision]) || !/^[0-9a-f]{64}$/u.test(value.receiverKey) || !/^[0-9a-f]{32}$/u.test(value.nonce) || !Array.isArray(value.epochs) || epochs.length < 1 || epochs.length > MAX_BATCH || epochs.some((epoch, index) => !Number.isSafeInteger(epoch) || epoch < 0 || index > 0 && epoch <= epochs[index - 1] || !this.#commitments().has(epoch))) throw new Error("APPLICATION_KEY_REQUEST_INVALID");
    this.#reader(value.recipient);
    await verify(REQUEST_DOMAIN, request, value.recipient);
    this.#reader(value.recipient);
    if (this.#authority().generations.at(-1)?.id !== generation.id) throw new Error("APPLICATION_KEY_REQUEST_EXPIRED");
  }
  async #load() {
    const bytes = await this.#store.get(this.#key);
    if (bytes === null) return /* @__PURE__ */ new Map();
    const value = decodePeerValue(bytes);
    if (!Array.isArray(value) || value.length > 4096) throw new Error("APPLICATION_KEY_STORE_INVALID");
    const result = /* @__PURE__ */ new Map();
    for (const entry of value) {
      if (!Array.isArray(entry) || entry.length !== 2 || !Number.isSafeInteger(entry[0]) || entry[0] < 0 || !/^[0-9a-f]{64}$/u.test(entry[1]) || result.has(entry[0])) throw new Error("APPLICATION_KEY_STORE_INVALID");
      result.set(entry[0], hexToBytes2(entry[1]));
    }
    return result;
  }
};
function wrapContext(requestDigest, epoch) {
  return encodePeerValue(["chronolog/peer-generation/key-wrap/v1", requestDigest, epoch]);
}
async function sign(domain, payload, identity) {
  const signature = await crypto.subtle.sign("Ed25519", identity.privateKey, new Uint8Array(encodePeerValue([domain, payload])));
  return { payload, signature: bytesToHex2(new Uint8Array(signature)) };
}
async function verify(domain, value, publicKey) {
  if (!/^[0-9a-f]{64}$/u.test(publicKey) || !/^[0-9a-f]{128}$/u.test(value.signature) || !await crypto.subtle.verify(
    "Ed25519",
    await importEd25519PublicKey(hexToBytes2(publicKey)),
    new Uint8Array(hexToBytes2(value.signature)),
    new Uint8Array(encodePeerValue([domain, value.payload]))
  )) throw new Error("APPLICATION_KEY_SIGNATURE_INVALID");
}

// packages/peer-session/src/projection.ts
function stateBytes(value) {
  return canonicalJson(value, { maxBytes: APPLICATION_PROJECTION_LIMITS.stateBytes, maxNodes: 32768, maxDepth: 24 });
}
function identifier(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/u.test(value)) throw new Error("APPLICATION_PROJECTION_ID_INVALID");
}
function topics(value) {
  if (value === void 0) return null;
  if (!Array.isArray(value) || value.length > 128) throw new Error("APPLICATION_PROJECTION_TOPICS_INVALID");
  const names = [];
  for (const topic of value) {
    if (typeof topic !== "string") throw new Error("APPLICATION_PROJECTION_TOPICS_INVALID");
    assertEventTopic(topic);
    names.push(topic);
  }
  return [...new Set(names)].sort();
}
var ApplicationProjection = class {
  id;
  #version;
  #topics;
  #initial;
  #reduce;
  #source;
  #store;
  #key;
  #lifetime = new AbortController();
  #signal;
  #release;
  #tail = Promise.resolve();
  #closing;
  #pending = 0;
  #loaded = false;
  #checkpoint = null;
  #fault;
  constructor(options) {
    const definition = options.definition;
    identifier(definition.id);
    identifier(definition.version);
    if (typeof definition.reduce !== "function") throw new Error("APPLICATION_PROJECTION_REDUCER_INVALID");
    this.id = definition.id;
    this.#version = definition.version;
    this.#topics = topics(definition.topics);
    this.#initial = stateBytes(definition.initial);
    this.#reduce = definition.reduce;
    this.#source = options.source;
    this.#store = options.store;
    this.#release = options.release;
    this.#signal = AbortSignal.any([options.source.signal, this.#lifetime.signal]);
    this.#key = `peer-session/projection/${options.source.applicationId}/${this.id}`;
  }
  read(options = {}) {
    const signal = options.signal === void 0 ? this.#signal : AbortSignal.any([this.#signal, options.signal]);
    return awaitOwnedTask(signal, () => {
      if (this.#pending >= APPLICATION_PROJECTION_LIMITS.pending) throw new Error("APPLICATION_PROJECTION_BUSY");
      this.#pending++;
      const result = this.#tail.then(() => this.#read());
      this.#tail = result.catch(() => void 0).finally(() => {
        this.#pending--;
      });
      return result;
    });
  }
  async #read() {
    this.#signal.throwIfAborted();
    if (this.#fault !== void 0) throw new Error("APPLICATION_PROJECTION_REOPEN_REQUIRED", { cause: this.#fault });
    if (!this.#loaded) {
      const bytes2 = await this.#store.get(this.#key);
      this.#signal.throwIfAborted();
      if (bytes2 !== null) {
        if (bytes2.length > APPLICATION_PROJECTION_LIMITS.checkpointBytes) throw new Error("APPLICATION_PROJECTION_CHECKPOINT_INVALID");
        const checkpoint = decodePeerValue(bytes2);
        const fields = ["applicationId", "historyId", "id", "version", "topics", "revision", "cursor", "state"];
        if (checkpoint === null || typeof checkpoint !== "object" || Object.keys(checkpoint).length !== fields.length || fields.some((key) => !Object.hasOwn(checkpoint, key))) throw new Error("APPLICATION_PROJECTION_CHECKPOINT_INVALID");
        validatePeerRevision(checkpoint.revision);
        identifier(checkpoint.version);
        if (checkpoint.applicationId !== this.#source.applicationId || checkpoint.historyId !== this.#source.historyId || checkpoint.id !== this.id || checkpoint.revision.applicationId !== checkpoint.applicationId || checkpoint.revision.historyId !== checkpoint.historyId || typeof checkpoint.cursor !== "string" || checkpoint.cursor.length > APPLICATION_EVENT_CURSOR_LIMIT || typeof checkpoint.state !== "string" || stateBytes(JSON.parse(checkpoint.state)) !== checkpoint.state || checkpoint.topics !== null && !samePeerValue(topics(checkpoint.topics), checkpoint.topics)) {
          throw new Error("APPLICATION_PROJECTION_CHECKPOINT_INVALID");
        }
        this.#checkpoint = checkpoint;
      }
      this.#loaded = true;
    }
    const previous = this.#checkpoint, view = await this.#source.readView();
    let reset = null, next;
    try {
      this.#signal.throwIfAborted();
      const compatible = previous !== null && previous.version === this.#version && samePeerValue(previous.topics, this.#topics);
      if (previous !== null && !compatible) reset = { reason: "definition", previousRevision: previous.revision };
      else if (previous !== null && previous.revision.generation !== view.revision.generation) {
        reset = { reason: "recovery", previousRevision: previous.revision };
      }
      if (compatible && reset === null && samePeerValue(previous.revision, view.revision)) {
        return { revision: structuredClone(previous.revision), state: JSON.parse(previous.state), reset: null };
      }
      let cursor = compatible && reset === null ? previous.cursor : void 0;
      let state = JSON.parse(compatible && reset === null ? previous.state : this.#initial);
      let encoded = stateBytes(state);
      while (true) {
        this.#signal.throwIfAborted();
        let batch;
        try {
          batch = view.readEvents({ ...cursor === void 0 ? {} : { cursor }, ...this.#topics === null ? {} : { topics: this.#topics }, limit: 128 });
        } catch (error) {
          if (!(error instanceof RecoveredViewError) || previous === null || cursor === void 0) throw error;
          reset = { reason: "recovery", previousRevision: previous.revision };
          cursor = void 0;
          state = JSON.parse(this.#initial);
          continue;
        }
        for (const event of batch.events) state = this.#reduce(state, event);
        encoded = stateBytes(state);
        cursor = batch.cursor;
        if (!batch.hasMore) break;
      }
      next = {
        applicationId: this.#source.applicationId,
        historyId: this.#source.historyId,
        id: this.id,
        version: this.#version,
        topics: this.#topics,
        revision: view.revision,
        cursor,
        state: encoded
      };
    } finally {
      view.release();
    }
    const bytes = encodePeerValue(next);
    if (bytes.length > APPLICATION_PROJECTION_LIMITS.checkpointBytes) throw new Error("APPLICATION_PROJECTION_CHECKPOINT_INVALID");
    this.#signal.throwIfAborted();
    try {
      await this.#store.put(this.#key, bytes);
    } catch (error) {
      this.#fault = error ?? new Error("APPLICATION_PROJECTION_WRITE_FAILED");
      throw error;
    }
    this.#checkpoint = next;
    this.#signal.throwIfAborted();
    return { revision: structuredClone(next.revision), state: JSON.parse(next.state), reset: structuredClone(reset) };
  }
  changes(options = {}) {
    const projection = this;
    return { [Symbol.asyncIterator]() {
      const controller = new AbortController(), signal = AbortSignal.any([
        projection.#signal,
        controller.signal,
        ...options.signal === void 0 ? [] : [options.signal]
      ]);
      const iterator = projection.#source.changes({ signal })[Symbol.asyncIterator]();
      let closed = false, pulling = false, previous;
      const finish = () => {
        if (closed) return;
        closed = true;
        signal.removeEventListener("abort", finish);
        controller.abort(new Error("APPLICATION_PROJECTION_STREAM_CLOSED"));
        void iterator.return?.().catch(() => void 0);
      };
      signal.addEventListener("abort", finish, { once: true });
      if (signal.aborted) finish();
      return {
        async next() {
          if (closed) return { done: true, value: void 0 };
          if (pulling) throw new Error("APPLICATION_PROJECTION_CONCURRENT_NEXT");
          pulling = true;
          try {
            const next = await awaitOwnedTask(signal, () => iterator.next());
            if (next.done) {
              finish();
              return { done: true, value: void 0 };
            }
            const value = await projection.read({ signal });
            const reset = value.reset ?? (previous !== void 0 && previous.generation !== value.revision.generation ? { reason: "recovery", previousRevision: previous } : null);
            previous = structuredClone(value.revision);
            return { done: false, value: { ...value, reset } };
          } catch (error) {
            const cancelled = signal.aborted;
            finish();
            if (cancelled) return { done: true, value: void 0 };
            throw error;
          } finally {
            pulling = false;
          }
        },
        async return() {
          finish();
          return { done: true, value: void 0 };
        }
      };
    } };
  }
  close() {
    this.#lifetime.abort(new Error("APPLICATION_PROJECTION_CLOSED"));
    this.#closing ??= this.#tail.then(() => {
      this.#release();
    });
    return this.#closing;
  }
};

// packages/peer-session/src/application-data.ts
var ApplicationData = class {
  #replica;
  #store;
  #storage;
  #definition;
  #session;
  #submit;
  #lifetime = new AbortController();
  signal;
  content;
  keys;
  recovery;
  operations;
  #inflight = /* @__PURE__ */ new Map();
  #links = /* @__PURE__ */ new Set();
  #projections = /* @__PURE__ */ new Map();
  #views = /* @__PURE__ */ new Set();
  #openingViews = 0;
  #closed = false;
  #closeTask;
  constructor(options) {
    this.#replica = options.replica;
    this.#storage = options.storage;
    this.#store = options.storage.store;
    this.#definition = options.definition;
    this.#session = options.session;
    this.#submit = options.submit;
    this.content = options.content;
    this.keys = options.keys;
    this.signal = AbortSignal.any([options.session.signal, this.#lifetime.signal]);
    this.recovery = new ApplicationRecovery({ replica: options.replica, store: this.#store, signal: this.signal, adoptAuthority: options.adoptAuthority });
    const replica = this.#replica;
    this.operations = Object.freeze({
      get: (operationId, options2 = {}) => replica.operation(operationId, options2.author),
      inspect: async (operationId, options2 = {}) => {
        const state = await replica.operation(operationId, options2.author), attempt = await replica.attempt(operationId, options2.author);
        return state === null || attempt === null ? null : { state, attempt };
      },
      wait: (operationId, waitOptions = {}) => this.waitFor(operationId, waitOptions)
    });
  }
  get replica() {
    return this.#replica;
  }
  get applicationId() {
    return this.#replica.descriptor.applicationId;
  }
  get historyId() {
    return this.#replica.descriptor.historyId;
  }
  async command(name, input, options) {
    this.#assertOpen();
    const command = this.#definition.commands[name];
    if (command === void 0) throw new Error("APPLICATION_COMMAND_UNKNOWN");
    await this.#replica.prepare({
      operationId: options.operationId,
      program: command.prepare(input),
      command: name,
      commandVersion: this.#definition.version,
      ...options.basedOn === void 0 ? {} : { basedOn: options.basedOn }
    });
    void this.retry(options.operationId).catch(() => void 0);
    return new ApplicationOperation(this.#session, options.operationId);
  }
  async reapply(operationId, name, input, options) {
    this.#assertOpen();
    const original = await this.#replica.operation(operationId, options.originalAuthor);
    if (original === null || original.status !== "abandoned" && original.status !== "needsReapply") throw new Error("APPLICATION_REAPPLY_REQUIRES_ABANDONED_ATTEMPT");
    if (options.operationId === operationId) throw new Error("APPLICATION_REAPPLY_REQUIRES_NEW_ID");
    const command = this.#definition.commands[name];
    if (command === void 0) throw new Error("APPLICATION_COMMAND_UNKNOWN");
    await this.#replica.prepare({
      operationId: options.operationId,
      program: command.prepare(input),
      command: name,
      commandVersion: this.#definition.version,
      reapplyOf: original.attemptId,
      ...options.basedOn === void 0 ? {} : { basedOn: options.basedOn }
    });
    void this.retry(options.operationId).catch(() => void 0);
    return new ApplicationOperation(this.#session, options.operationId);
  }
  async query(name, input) {
    const query = this.#definition.queries[name];
    if (query === void 0) throw new Error("APPLICATION_QUERY_UNKNOWN");
    const view = await this.readView();
    try {
      return { revision: view.revision, value: await query.read(view, input) };
    } finally {
      view.release();
    }
  }
  async readView() {
    this.#assertOpen();
    if (this.#views.size + this.#openingViews >= 8) throw new Error("APPLICATION_VIEW_LIMIT");
    this.#openingViews++;
    let captured;
    try {
      captured = await this.#replica.capture();
    } finally {
      this.#openingViews--;
    }
    if (this.#closed || this.#views.size >= 8) {
      captured.release();
      throw new Error(this.#closed ? "APPLICATION_SESSION_CLOSED" : "APPLICATION_VIEW_LIMIT");
    }
    let released = false;
    const views = this.#views;
    const held = () => {
      if (released) throw new Error("APPLICATION_VIEW_RELEASED");
    };
    const view = Object.freeze({
      revision: captured.revision,
      query(sql, parameters = []) {
        held();
        const result = captured.read.query(sql, parameters.map(encodeParameter));
        return { columns: result.columns, rows: result.rows.map((row) => row.map(decodeParameter)) };
      },
      readEvents(options = {}) {
        held();
        return readEvents(captured, options);
      },
      release() {
        if (released) return;
        released = true;
        views.delete(view);
        captured.release();
      }
    });
    views.add(view);
    return view;
  }
  onRecovery(listener) {
    this.#assertOpen();
    return this.#replica.onRecovery(listener);
  }
  inspectRecovery() {
    return this.#replica.inspectRecovery();
  }
  recoveryPoint() {
    this.#assertOpen();
    return this.#replica.recoveryPoint();
  }
  async adopt(authority) {
    this.#assertOpen();
    const notice = await this.#replica.adopt(authority);
    void this.resume().catch(() => void 0);
    return notice;
  }
  changes(options = {}) {
    return coalescedChanges(this.#replica, this.signal, options.signal);
  }
  /** Register a pure reducer in the owning Worker or native session. */
  project(definition) {
    this.#assertOpen();
    if (this.#projections.has(definition.id)) throw new Error("APPLICATION_PROJECTION_IN_USE");
    if (this.#projections.size >= APPLICATION_PROJECTION_LIMITS.active) throw new Error("APPLICATION_PROJECTION_LIMIT");
    const projection = new ApplicationProjection({
      source: this,
      store: this.#store,
      definition,
      release: () => {
        this.#projections.delete(projection.id);
        this.#links.delete(projection);
      }
    });
    this.#projections.set(projection.id, projection);
    this.#links.add(projection);
    return projection;
  }
  /** Read a registered projection without moving reducer callbacks across a transport. */
  projection(id) {
    this.#assertOpen();
    const projection = this.#projections.get(id);
    if (projection === void 0) throw new Error("APPLICATION_PROJECTION_NOT_FOUND");
    return projection;
  }
  async retry(operationId) {
    this.#assertOpen();
    const existing = this.#inflight.get(operationId);
    if (existing !== void 0) return existing;
    const task = (async () => {
      const state = await this.#replica.operation(operationId);
      if (state === null) throw new Error("APPLICATION_OPERATION_NOT_FOUND");
      if (state.status === "applied") return;
      if (state.status === "abandoned" || state.status === "needsReapply") throw new AbandonedOperationError(state);
      const attempt = await this.#replica.attempt(operationId);
      if (attempt === null) throw new Error("APPLICATION_ATTEMPT_MISSING");
      if (this.#replica.isCoordinator) await this.#replica.order(attempt);
      else await this.#submit(attempt);
    })();
    this.#inflight.set(operationId, task);
    try {
      await task;
    } finally {
      this.#inflight.delete(operationId);
    }
  }
  async resume() {
    this.#assertOpen();
    if (!this.#replica.ready) return;
    for (const attempt of await this.#replica.pendingAttempts()) await this.retry(attempt.payload.header.operationId);
  }
  async waitFor(operationId, options = {}) {
    return waitFor(this.#replica, this.signal, options.signal, async () => {
      if (!this.#replica.ready) return void 0;
      const current = await this.#replica.operation(operationId, options.author);
      if (current?.status === "applied") return current;
      if (current?.status === "abandoned" || current?.status === "needsReapply") throw new AbandonedOperationError(current);
      if (current === null) throw new Error("APPLICATION_OPERATION_NOT_FOUND");
      return void 0;
    });
  }
  async waitForCoverage(applied, options = {}) {
    return waitFor(this.#replica, this.signal, options.signal, async () => {
      if (!this.#replica.ready) return void 0;
      const current = await this.#replica.operation(applied.operationId, applied.author);
      if (current?.status === "abandoned" || current?.status === "needsReapply") throw new AbandonedOperationError(current);
      const commands = await this.#replica.exportCommands();
      const command = commands.find((value) => value.attempt.id === applied.attemptId);
      if (command === void 0) return void 0;
      const coverage = this.#replica.shared({ generation: applied.generation, sequence: applied.sequence, root: command.receipt.root });
      return coverage.length === 0 ? void 0 : coverage;
    });
  }
  close(reason = new Error("APPLICATION_SESSION_CLOSED")) {
    if (this.#closeTask !== void 0) return this.#closeTask;
    this.#closed = true;
    this.#lifetime.abort(reason);
    for (const view of [...this.#views]) view.release();
    this.content.close();
    this.#closeTask = (async () => {
      await Promise.allSettled([...this.#links].map((link) => Promise.resolve().then(() => link.close())));
      await Promise.allSettled([this.recovery.close(), this.keys.close(), ...this.#inflight.values()]);
      try {
        await this.#replica.close();
      } finally {
        await this.#storage.close();
      }
    })();
    return this.#closeTask;
  }
  #assertOpen() {
    this.signal.throwIfAborted();
    if (this.#closed) throw new Error("APPLICATION_SESSION_CLOSED");
  }
};
async function openApplicationData(options) {
  const signal = options.session.signal;
  let storage, materializer, replica, keys;
  try {
    signal.throwIfAborted();
    storage = await options.device.openStorage();
    signal.throwIfAborted();
    const store = storage.store;
    const device = { ...options.device, store };
    keys = await ApplicationKeyring.open({
      device,
      authority: options.authority,
      ...options.epochKeys === void 0 ? {} : { epochKeys: options.epochKeys }
    });
    signal.throwIfAborted();
    materializer = options.createMaterializer === void 0 ? await createEventMaterializationRuntime({
      store,
      namespace: options.authority.descriptor.payload.historyId,
      ...options.maxHistoryBytes === void 0 ? {} : { maxHistoryBytes: options.maxHistoryBytes }
    }) : await options.createMaterializer({ signal });
    signal.throwIfAborted();
    const requiresSql = options.definition.schema !== void 0 || options.authority.descriptor.payload.schemaDigest !== null;
    if (materializer.queries.capabilities.sql !== requiresSql) {
      throw new Error(requiresSql ? "APPLICATION_SCHEMA_REQUIRES_SQL" : "APPLICATION_SQL_REQUIRES_SCHEMA");
    }
    replica = await createPeerReplica({
      authority: options.authority,
      device: device.identity,
      store,
      storageId: device.storageId,
      epochKeys: keys.epochKeys,
      materializer,
      ...options.maxRecords === void 0 ? {} : { maxRecords: options.maxRecords },
      ...options.maxHistoryBytes === void 0 ? {} : { maxHistoryBytes: options.maxHistoryBytes }
    });
    signal.throwIfAborted();
    keys.bind(replica);
    await keys.validate();
    signal.throwIfAborted();
    const keyring = keys;
    const content = new ApplicationContent({
      replica,
      store,
      storageId: device.storageId,
      epochKeys: keyring.epochKeys,
      acquireKey: (epoch) => keyring.ensure([epoch])
    });
    return new ApplicationData({ replica, storage, definition: options.definition, content, keys, session: options.session, submit: options.submit, adoptAuthority: options.adoptAuthority });
  } catch (error) {
    await Promise.allSettled([
      Promise.resolve().then(() => keys?.close()),
      Promise.resolve().then(() => replica === void 0 ? materializer?.close() : replica.close())
    ]);
    try {
      await storage?.close();
    } catch {
    }
    throw error;
  }
}
function encodeParameter(value) {
  if (value === null) return { kind: "null" };
  if (typeof value === "string") return { kind: "text", value };
  if (typeof value === "bigint") return { kind: "integer", value: String(value) };
  if (value instanceof Uint8Array) return { kind: "blob", value: value.slice() };
  if (typeof value === "number" && Number.isFinite(value)) return Number.isSafeInteger(value) ? { kind: "integer", value: String(value) } : { kind: "real", value };
  throw new Error("APPLICATION_SQL_PARAMETER_INVALID");
}
function decodeParameter(value) {
  switch (value.kind) {
    case "null":
      return null;
    case "integer": {
      const exact = BigInt(value.value);
      return exact >= BigInt(Number.MIN_SAFE_INTEGER) && exact <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(exact) : exact;
    }
    case "real":
    case "text":
      return value.value;
    case "blob":
      return value.value.slice();
  }
}
function readEvents(captured, options) {
  const limit = options.limit ?? 128, topics2 = options.topics === void 0 ? null : [...new Set(options.topics)].sort();
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 1024 || topics2 !== null && (topics2.length > 128 || topics2.some((topic) => typeof topic !== "string" || topic.length > 128))) throw new Error("APPLICATION_EVENT_OPTIONS_INVALID");
  let index = 0;
  if (options.cursor !== void 0) {
    try {
      if (options.cursor.length > APPLICATION_EVENT_CURSOR_LIMIT) throw new Error();
      const cursor = JSON.parse(options.cursor);
      if (cursor.historyId !== captured.revision.historyId || cursor.generation !== captured.revision.generation) throw new RecoveredViewError(captured.revision);
      if (!Number.isSafeInteger(cursor.index) || cursor.index < 0 || cursor.index > captured.read.orderLength || JSON.stringify(cursor.topics) !== JSON.stringify(topics2) || cursor.anchor !== (cursor.index === 0 ? null : bytesToHex2(captured.read.transactionAt(cursor.index - 1).txId))) throw new Error();
      index = cursor.index;
    } catch (error) {
      if (error instanceof RecoveredViewError) throw error;
      throw new Error("APPLICATION_EVENT_CURSOR_INVALID", { cause: error });
    }
  }
  const events = [];
  const end = Math.min(captured.read.orderLength, index + limit);
  while (index < end) {
    const transaction = captured.read.transactionAt(index++);
    if (transaction.outcome !== "accepted") continue;
    const core = decodeTransactionCore(transaction.canonicalCandidate);
    let ordinal = 0;
    for (const step of core.program.steps) {
      if (!isEmitStep(step)) continue;
      const eventOrdinal = ordinal++;
      if (topics2 !== null && !topics2.includes(step.topic)) continue;
      events.push({
        id: `${bytesToHex2(transaction.txId)}:${eventOrdinal}`,
        attemptId: bytesToHex2(transaction.txId),
        operationId: core.operationId,
        author: bytesToHex2(core.authorId),
        authorTimestampMs: String(core.authorTimestampMs),
        topic: step.topic,
        payload: structuredClone(step.payload)
      });
    }
  }
  return {
    revision: captured.revision,
    events,
    hasMore: index < captured.read.orderLength,
    cursor: JSON.stringify({
      historyId: captured.revision.historyId,
      generation: captured.revision.generation,
      index,
      anchor: index === 0 ? null : bytesToHex2(captured.read.transactionAt(index - 1).txId),
      topics: topics2
    })
  };
}
function waitFor(replica, lifetime, signal, check) {
  const abort = signal === void 0 ? lifetime : AbortSignal.any([lifetime, signal]);
  abort.throwIfAborted();
  return new Promise((resolve, reject) => {
    let done = false, running = false, again = false, unsubscribe = () => {
    };
    const finish = (value, error) => {
      if (done) return;
      done = true;
      unsubscribe();
      abort.removeEventListener("abort", stop);
      if (error !== void 0) reject(error);
      else resolve(value);
    };
    const stop = () => finish(void 0, abort.reason);
    const inspect = () => {
      if (done) return;
      if (running) {
        again = true;
        return;
      }
      running = true;
      void (async () => {
        try {
          do {
            again = false;
            const value = await check();
            if (value !== void 0) {
              finish(value);
              return;
            }
          } while (again && !done);
        } catch (error) {
          finish(void 0, error);
        } finally {
          running = false;
        }
      })();
    };
    abort.addEventListener("abort", stop, { once: true });
    unsubscribe = replica.subscribe(inspect);
    inspect();
    if (done) unsubscribe();
  });
}
function coalescedChanges(replica, lifetime, signal) {
  return { [Symbol.asyncIterator]() {
    const abort = signal === void 0 ? lifetime : AbortSignal.any([lifetime, signal]);
    let closed = false, pending, waiting;
    let latestRecovery = null;
    let lastRevision;
    const close = () => {
      if (!closed) {
        closed = true;
        unsubscribe();
        recovery();
        abort.removeEventListener("abort", close);
        waiting?.({ done: true, value: void 0 });
        waiting = void 0;
        pending = void 0;
      }
      return { done: true, value: void 0 };
    };
    const publish = () => {
      if (closed || !replica.ready) return;
      const revision = replica.revision;
      const identity = `${revision.generation}/${revision.point.root}/${revision.materializationRevision}`;
      if (latestRecovery === null && identity === lastRevision) return;
      lastRevision = identity;
      const value = { kind: latestRecovery === null ? "applied" : "recovery", revision, recovery: latestRecovery };
      latestRecovery = null;
      if (waiting !== void 0) {
        const resolve = waiting;
        waiting = void 0;
        resolve({ done: false, value });
      } else pending = value.kind === "applied" && pending?.kind === "recovery" ? { ...value, kind: "recovery", recovery: pending.recovery } : value;
    };
    const unsubscribe = replica.subscribe(publish), recovery = replica.onRecovery((notice) => {
      latestRecovery = notice;
      publish();
    });
    abort.addEventListener("abort", close, { once: true });
    if (abort.aborted) close();
    else publish();
    return {
      next() {
        if (closed) return Promise.resolve({ done: true, value: void 0 });
        if (pending !== void 0) {
          const value = pending;
          pending = void 0;
          return Promise.resolve({ done: false, value });
        }
        if (waiting !== void 0) return Promise.reject(new Error("APPLICATION_CHANGES_CONCURRENT_NEXT"));
        return new Promise((resolve) => {
          waiting = resolve;
        });
      },
      async return() {
        return close();
      }
    };
  } };
}
export {
  ApplicationData,
  openApplicationData
};
