import type { ApplicationSession } from './session.js';
import type { FramedPeerConnection } from '../../records/src/index.js';
export interface ApplicationPeerConnectOptions {
    readonly connection: FramedPeerConnection;
    readonly peerIdentity?: string;
    readonly signal?: AbortSignal;
    readonly handshakeTimeoutMs?: number;
}
export interface ApplicationPeerLink {
    readonly peerIdentity: string;
    readonly signal: AbortSignal;
    readonly completion: Promise<void>;
    readonly stats: {
        readonly sentBytes: number;
        readonly receivedBytes: number;
    };
    synchronize(): Promise<void>;
    close(): Promise<void>;
}
export interface ApplicationPeerDiagnostics {
    readonly connectionId: string;
    readonly peerId: string;
    readonly kind: 'unknown';
    readonly sentReliableBytes: number;
    readonly receivedReliableBytes: number;
}
export declare function applicationPeerDiagnostics(session: ApplicationSession): readonly ApplicationPeerDiagnostics[];
/** Physical feed counters only protect framing. Every proposal authenticates its own immutable authored order. */
export declare function connectApplicationPeer(session: ApplicationSession, options: ApplicationPeerConnectOptions): Promise<ApplicationPeerLink>;
