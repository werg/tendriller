import { type ApplicationDevice } from './device.js';
export { createApplicationSession } from './index.js';
export type { CreateApplicationSessionOptions } from './runtime.js';
export { NativeBytesStore } from '../../records/src/native.js';
export interface DisposableNativeDevice extends ApplicationDevice {
    readonly ephemeral: true;
    readonly resumable: false;
    readonly storageMode: 'disposable-events' | 'disposable-sql';
    /** Managed temp directory allocated for disposable SQL, or null for in-memory events. */
    readonly temporaryDirectory: string | null;
    /** Path for a disposable SQL database file inside temporaryDirectory, or null for events. */
    readonly databasePath: string | null;
}
/** The SQLite file is the exclusive signer/history owner; a second process receives a busy error. */
export declare function openNativeDevice(options: {
    readonly path: string;
    readonly create?: true;
    readonly quotaBytes?: number;
    readonly maxValueBytes?: number;
}): Promise<ApplicationDevice>;
/**
 * Explicit disposable native device replacing ad-hoc `:memory:` SQL workarounds.
 * - Events mode uses in-memory MemoryBytesStore.
 * - SQL mode allocates a managed temp directory under os.tmpdir() and cleans it up on close/exit.
 */
export declare function openDisposableNativeDevice(options?: {
    readonly sql?: boolean;
    readonly quotaBytes?: number;
    readonly maxValueBytes?: number;
}): Promise<DisposableNativeDevice>;
