import { type EventForwarderOptions, type EventForwarderSession } from './event-forwarder.js';
import type { ApplicationChange } from './session-types.js';
/** The part of an application session that merged change feeds and forwarders read. */
export interface MergeableSession {
    readonly applicationId: string;
    readonly historyId: string;
    readonly signal?: AbortSignal;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
}
export interface MergedSessionChange extends ApplicationChange {
    readonly applicationId: string;
    readonly historyId: string;
}
/** Sessions as a fixed collection, or a registry that yields sessions as they open. */
export type SessionSource<Session> = Iterable<Session> | AsyncIterable<Session>;
export interface MergedSessionChanges extends AsyncIterable<MergedSessionChange> {
    /** Start following a session; adding the same session twice is a no-op. */
    add(session: MergeableSession): void;
    /** Stop following a session. A session whose own change feed ends is removed automatically. */
    remove(session: MergeableSession): void;
    readonly size: number;
    /** End the merged stream and every per-session subscription. */
    close(): void;
}
/**
 * One invalidation stream over many sessions in a process. Each session keeps at most
 * one undelivered change: its own feed is not read again until the consumer takes the
 * previous one, so the per-session coalescing of `changes()` bounds memory.
 * A session feed that fails is removed and reported to `onError`; without `onError`
 * the merged stream fails with that error.
 */
export declare function mergeSessionChanges(source?: SessionSource<MergeableSession>, options?: {
    readonly signal?: AbortSignal;
    readonly onError?: (error: unknown, session: MergeableSession) => void;
}): MergedSessionChanges;
export interface SessionCheckpointScope {
    readonly applicationId: string;
    readonly historyId: string;
    /** Stable storage key `${applicationId}:${historyId}`. */
    readonly key: string;
}
export interface SessionCheckpoints {
    load(scope: SessionCheckpointScope): string | undefined | Promise<string | undefined>;
    save(scope: SessionCheckpointScope, cursor: string): void | Promise<void>;
}
export type ForwardableSession = EventForwarderSession & MergeableSession & {
    readonly signal: AbortSignal;
};
export interface SessionForwarders {
    add(session: ForwardableSession): void;
    remove(session: ForwardableSession): void;
    readonly size: number;
    /** Stop every forwarder and wait for them to settle; rejects if the session registry failed. */
    close(): Promise<void>;
}
export declare function sessionCheckpointKey(applicationId: string, historyId: string): string;
/**
 * Run `forwardSessionEvents` for each session, with one durable cursor per
 * (applicationId, historyId). A forwarder that stops with an error, including a
 * recovery review stop, is removed and reported to `onError`; the others continue.
 * A forwarder whose session closes simply ends.
 */
export declare function forwardManySessionEvents<Projected>(options: Omit<EventForwarderOptions<Projected>, 'session' | 'checkpoint'> & {
    readonly sessions?: SessionSource<ForwardableSession>;
    readonly checkpoints: SessionCheckpoints;
    readonly onError: (error: unknown, session: ForwardableSession) => void;
}): SessionForwarders;
