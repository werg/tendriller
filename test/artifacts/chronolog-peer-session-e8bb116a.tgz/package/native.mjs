import {
  openApplicationDevice,
  openPeerApplication
} from "./chunks/chunk-7XHUOSCC.mjs";
import "./chunks/chunk-FZPYG6B6.mjs";
import "./chunks/chunk-TLZH7OYA.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-PFEHSVTG.mjs";
import "./chunks/chunk-4SXHXSRR.mjs";
import "./chunks/chunk-TF4JHBDD.mjs";
import "./chunks/chunk-Q44B5CP6.mjs";
import "./chunks/chunk-DACCYORU.mjs";

// packages/records/src/native.ts
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { DatabaseSync } from "node:sqlite";
var NativeBytesStore = class {
  #database;
  #quotaBytes;
  #maxValueBytes;
  #usedBytes = 0;
  #closed = false;
  constructor(path, options = {}) {
    this.#quotaBytes = options.quotaBytes ?? 256 * 1024 * 1024;
    this.#maxValueBytes = options.maxValueBytes ?? 128 * 1024 * 1024;
    for (const value of [this.#quotaBytes, this.#maxValueBytes]) {
      if (!Number.isSafeInteger(value) || value < 1) throw new Error("BYTES_STORE_QUOTA_INVALID");
    }
    if (path.length === 0) throw new Error("BYTES_STORE_PATH_REQUIRED");
    if (path !== ":memory:") mkdirSync(dirname(path), { recursive: true });
    this.#database = new DatabaseSync(path);
    try {
      this.#database.exec("PRAGMA busy_timeout = 0");
      this.#database.exec("PRAGMA locking_mode = EXCLUSIVE");
      this.#database.exec("PRAGMA journal_mode = WAL");
      this.#database.exec("PRAGMA synchronous = FULL");
      this.#database.exec("BEGIN EXCLUSIVE");
      this.#database.exec(`CREATE TABLE IF NOT EXISTS stored_bytes (
        key TEXT PRIMARY KEY,
        value BLOB NOT NULL
      )`);
      this.#database.exec("COMMIT");
      this.#usedBytes = this.#database.prepare("SELECT coalesce(sum(length(value)), 0) AS bytes FROM stored_bytes").get().bytes;
    } catch (error) {
      try {
        this.#database.close();
      } catch {
      }
      if (/locked|busy/iu.test(error instanceof Error ? error.message : "")) {
        throw new Error("BYTES_STORE_IN_USE", { cause: error });
      }
      throw error;
    }
  }
  async get(key) {
    this.#assertOpen();
    validateKey(key);
    const row = this.#database.prepare("SELECT value FROM stored_bytes WHERE key = ?").get(key);
    return row === void 0 ? null : Uint8Array.from(row.value);
  }
  async put(key, value) {
    this.#assertOpen();
    validateKey(key);
    if (!(value instanceof Uint8Array) || value.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    this.#database.exec("BEGIN IMMEDIATE");
    try {
      const previous = this.#database.prepare("SELECT length(value) AS bytes FROM stored_bytes WHERE key = ?").get(key);
      const used = this.#usedBytes - (previous?.bytes ?? 0) + value.byteLength;
      if (used > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
      this.#database.prepare("INSERT INTO stored_bytes (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(key, value);
      this.#database.exec("COMMIT");
      this.#usedBytes = used;
    } catch (error) {
      this.#database.exec("ROLLBACK");
      throw error;
    }
  }
  usageBytes() {
    this.#assertOpen();
    return this.#usedBytes;
  }
  close() {
    if (this.#closed) return;
    this.#database.close();
    this.#closed = true;
  }
  #assertOpen() {
    if (this.#closed) throw new Error("BYTES_STORE_CLOSED");
  }
};
function validateKey(key) {
  if (key.length === 0 || key.length > 2048 || [...key].some((character) => character.charCodeAt(0) < 32)) throw new Error("BYTES_STORE_KEY_INVALID");
}

// packages/peer-session/src/native.ts
async function openNativeDevice(options) {
  const limits = {
    ...options.quotaBytes === void 0 ? {} : { quotaBytes: options.quotaBytes },
    ...options.maxValueBytes === void 0 ? {} : { maxValueBytes: options.maxValueBytes }
  };
  const store = new NativeBytesStore(options.path, limits);
  try {
    return await openApplicationDevice({ store, ...options.create === void 0 ? {} : { create: options.create }, close: () => store.close() });
  } catch (error) {
    store.close();
    throw error;
  }
}
export {
  NativeBytesStore,
  openPeerApplication as openNativeApplication,
  openNativeDevice
};
