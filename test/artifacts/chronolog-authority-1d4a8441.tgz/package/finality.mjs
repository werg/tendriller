// packages/canonical/src/errors.ts
var CanonicalError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.details = details;
    this.name = "CanonicalError";
  }
  code;
  details;
};

// packages/canonical/src/bytes.ts
var textEncoder = new TextEncoder();
var fatalTextDecoder = new TextDecoder("utf-8", { fatal: true });
function utf8(value) {
  const encoded = textEncoder.encode(value);
  try {
    if (fatalTextDecoder.decode(encoded) !== value) throw new CanonicalError("INVALID_UTF8", "Text contains an unpaired UTF-16 surrogate");
  } catch (error) {
    if (error instanceof CanonicalError) throw error;
    throw new CanonicalError("INVALID_UTF8", "Text cannot be represented as canonical UTF-8");
  }
  return encoded;
}
var hexPairs = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, "0"));
function bytesToHex(value) {
  let result = "";
  for (const byte of value) result += hexPairs[byte];
  return result;
}
function hexToBytes(value) {
  if (!/^(?:[0-9a-fA-F]{2})*$/u.test(value)) throw new CanonicalError("SCHEMA_INVALID", "Hex text is malformed");
  return Uint8Array.from({ length: value.length / 2 }, (_unused, index) => Number.parseInt(value.slice(index * 2, index * 2 + 2), 16));
}

// packages/canonical/src/cbor.ts
var DEFAULT_DECODE_LIMITS = Object.freeze({
  maxBytes: 16 * 1024 * 1024,
  maxDepth: 64,
  maxArrayItems: 1e6,
  maxMapItems: 1e5,
  maxTextBytes: 4 * 1024 * 1024,
  maxBlobBytes: 16 * 1024 * 1024
});
var MAX_UINT64 = (1n << 64n) - 1n;

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/utils.js
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function abytes(b, ...lengths) {
  if (!isBytes(b))
    throw new Error("Uint8Array expected");
  if (lengths.length > 0 && !lengths.includes(b.length))
    throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
}
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput(out, instance) {
  abytes(out);
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error("digestInto() expects output buffer of length at least " + min);
  }
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word, shift) {
  return word << 32 - shift | word >>> shift;
}
function utf8ToBytes(str) {
  if (typeof str !== "string")
    throw new Error("string expected");
  return new Uint8Array(new TextEncoder().encode(str));
}
function toBytes(data) {
  if (typeof data === "string")
    data = utf8ToBytes(data);
  abytes(data);
  return data;
}
var Hash = class {
};
function createHasher(hashCons) {
  const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
  const tmp = hashCons();
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = () => hashCons();
  return hashC;
}

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/_md.js
function setBigUint64(view, byteOffset, value, isLE) {
  if (typeof view.setBigUint64 === "function")
    return view.setBigUint64(byteOffset, value, isLE);
  const _32n = BigInt(32);
  const _u32_max = BigInt(4294967295);
  const wh = Number(value >> _32n & _u32_max);
  const wl = Number(value & _u32_max);
  const h = isLE ? 4 : 0;
  const l = isLE ? 0 : 4;
  view.setUint32(byteOffset + h, wh, isLE);
  view.setUint32(byteOffset + l, wl, isLE);
}
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD = class extends Hash {
  constructor(blockLen, outputLen, padOffset, isLE) {
    super();
    this.finished = false;
    this.length = 0;
    this.pos = 0;
    this.destroyed = false;
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
  update(data) {
    aexists(this);
    data = toBytes(data);
    abytes(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        continue;
      }
      buffer.set(data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
      }
    }
    this.length += data.length;
    this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    clean(this.buffer.subarray(pos));
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      pos = 0;
    }
    for (let i = pos; i < blockLen; i++)
      buffer[i] = 0;
    setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE);
    this.process(view, 0);
    const oview = createView(out);
    const len = this.outputLen;
    if (len % 4)
      throw new Error("_sha2: outputLen should be aligned to 32bit");
    const outLen = len / 4;
    const state = this.get();
    if (outLen > state.length)
      throw new Error("_sha2: outputLen bigger than state");
    for (let i = 0; i < outLen; i++)
      oview.setUint32(4 * i, state[i], isLE);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneInto(to) {
    to || (to = new this.constructor());
    to.set(...this.get());
    const { blockLen, buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (length % blockLen)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha2.js
var SHA256_K = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
var SHA256 = class extends HashMD {
  constructor(outputLen = 32) {
    super(64, outputLen, 8, false);
    this.A = SHA256_IV[0] | 0;
    this.B = SHA256_IV[1] | 0;
    this.C = SHA256_IV[2] | 0;
    this.D = SHA256_IV[3] | 0;
    this.E = SHA256_IV[4] | 0;
    this.F = SHA256_IV[5] | 0;
    this.G = SHA256_IV[6] | 0;
    this.H = SHA256_IV[7] | 0;
  }
  get() {
    const { A, B, C, D, E, F, G, H } = this;
    return [A, B, C, D, E, F, G, H];
  }
  // prettier-ignore
  set(A, B, C, D, E, F, G, H) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
    this.F = F | 0;
    this.G = G | 0;
    this.H = H | 0;
  }
  process(view, offset) {
    for (let i = 0; i < 16; i++, offset += 4)
      SHA256_W[i] = view.getUint32(offset, false);
    for (let i = 16; i < 64; i++) {
      const W15 = SHA256_W[i - 15];
      const W2 = SHA256_W[i - 2];
      const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
      const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
      SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
    }
    let { A, B, C, D, E, F, G, H } = this;
    for (let i = 0; i < 64; i++) {
      const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
      const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
      const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
      const T2 = sigma0 + Maj(A, B, C) | 0;
      H = G;
      G = F;
      F = E;
      E = D + T1 | 0;
      D = C;
      C = B;
      B = A;
      A = T1 + T2 | 0;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    F = F + this.F | 0;
    G = G + this.G | 0;
    H = H + this.H | 0;
    this.set(A, B, C, D, E, F, G, H);
  }
  roundClean() {
    clean(SHA256_W);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    clean(this.buffer);
  }
};
var sha256 = /* @__PURE__ */ createHasher(() => new SHA256());

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha256.js
var sha2562 = sha256;

// packages/canonical/src/sync-hash.ts
function sha256Sync(bytes) {
  return sha2562(bytes);
}

// packages/canonical/src/hash.ts
var HASH_DOMAINS = Object.freeze({
  transaction: "chronolog/transaction",
  schema: "chronolog/schema",
  executionManifest: "chronolog/execution-manifest",
  queryResult: "chronolog/query-result",
  expectation: "chronolog/expectation",
  module: "chronolog/module",
  entropy: "chronolog/entropy",
  platformObject: "chronolog/platform-object",
  genesis: "chronolog/genesis/v1",
  op: "chronolog/op/v1",
  envelope: "chronolog/envelope/v1",
  state: "chronolog/state/v1",
  cas: "chronolog/cas/v1",
  history: "chronolog/history/v1",
  revision: "chronolog/revision/v1"
});
function bufferSource(value) {
  return Uint8Array.from(value).buffer;
}
async function sha2563(payload) {
  return new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bufferSource(payload)));
}

// packages/protocol/src/errors.ts
var ProtocolError = class extends Error {
  code;
  details;
  constructor(code, message, details) {
    super(message);
    this.name = "ProtocolError";
    this.code = code;
    this.details = details;
  }
  toJSON() {
    return this.details === void 0 ? { name: this.name, code: this.code, message: this.message } : { name: this.name, code: this.code, message: this.message, details: this.details };
  }
};
function protocolInvariant(condition, code, message, details) {
  if (!condition) throw new ProtocolError(code, message, details);
}

// packages/protocol/src/primitives.ts
var ED25519 = { name: "Ed25519" };
function bufferSource2(value) {
  return Uint8Array.from(value).buffer;
}
async function importEd25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "Ed25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", bufferSource2(raw), ED25519, true, ["verify"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 public key");
  }
}

// packages/protocol/src/v2.ts
var CONTROL_TOPICS = Object.freeze([
  "$reducers",
  "$permissions",
  "$keys",
  "$finality",
  "$publications",
  "$signal_policy"
]);
var CONTROL_TOPIC_SET = new Set(CONTROL_TOPICS);
var MAX_EVENT_BYTES = 16384;
function canonicalJson(payload, limits = { maxBytes: 65536, maxNodes: 8192, maxDepth: 32 }) {
  for (const bound of [limits.maxBytes, limits.maxNodes, limits.maxDepth]) {
    protocolInvariant(Number.isSafeInteger(bound) && bound > 0, "SCHEMA_INVALID", "Invalid JSON limits");
  }
  let nodes = 0;
  const visit = (value, depth) => {
    protocolInvariant(depth <= limits.maxDepth && ++nodes <= limits.maxNodes, "SCHEMA_INVALID", "JSON payload is too complex");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "Numbers must be finite");
      return JSON.stringify(Object.is(value, -0) ? 0 : value);
    }
    if (Array.isArray(value)) {
      protocolInvariant(Reflect.ownKeys(value).length === value.length + 1, "SCHEMA_INVALID", "Arrays cannot carry extra properties");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const desc = Object.getOwnPropertyDescriptor(value, i);
        protocolInvariant(desc !== void 0 && "value" in desc && desc.enumerable === true, "SCHEMA_INVALID", "Arrays require dense elements");
        entries.push(visit(desc.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    protocolInvariant(
      typeof value === "object" && value !== null && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null),
      "SCHEMA_INVALID",
      "Payload must contain JSON values"
    );
    const keys = Object.keys(value).sort();
    protocolInvariant(Reflect.ownKeys(value).length === keys.length, "SCHEMA_INVALID", "Objects require enumerable string keys");
    return `{${keys.map((key) => {
      const desc = Object.getOwnPropertyDescriptor(value, key);
      protocolInvariant("value" in desc, "SCHEMA_INVALID", "Accessors are prohibited");
      return `${JSON.stringify(key)}:${visit(desc.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const encoded = visit(payload, 0);
  protocolInvariant(utf8(encoded).length <= limits.maxBytes, "SCHEMA_INVALID", "JSON payload is too large");
  return encoded;
}
function canonicalEventPayload(payload) {
  return canonicalJson(payload, { maxBytes: MAX_EVENT_BYTES, maxNodes: 4096, maxDepth: 32 });
}
var DEFAULT_RUNTIME_MANIFEST = Object.freeze({
  js: "quickjs-ng@0.32.0",
  builtins: Object.freeze({
    "chronolog:crypto": "crypto@1",
    "chronolog:cas": "cas@1",
    "chronolog:sqlite": "sqlite-cas@1#sha256-bbc4674a5dd1d11962a8227ce5f1118e2e6ed7d00163ea92f1f35781caf46936"
  })
});
var DEFAULT_GENESIS_LIMITS = Object.freeze({
  maxMemoryBytes: 64 * 1024 * 1024,
  maxTopicStateBytes: 4 * 1024 * 1024,
  maxUpdatesPerOp: 16
});

// packages/authority/src/codec.ts
function check(condition, code) {
  if (!condition) throw Object.assign(new Error(code), { code });
}
function hex(value, length = 32) {
  check(typeof value === "string" && new RegExp(`^[0-9a-f]{${length * 2}}$`, "u").test(value), "AUTHORITY_HEX_INVALID");
}
function normalized(value, depth = 0) {
  check(depth < 32, "RECORD_DEPTH_LIMIT");
  if (value instanceof Uint8Array) return { $bytes: bytesToHex(value) };
  if (typeof value === "bigint") return { $integer: value.toString() };
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    check(Number.isSafeInteger(value), "RECORD_INTEGER_INVALID");
    return value;
  }
  if (Array.isArray(value)) return value.map((item) => normalized(item, depth + 1));
  check(value !== null && typeof value === "object" && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null), "RECORD_INVALID");
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, normalized(value[key], depth + 1)]));
}
function encodeRecord(value) {
  const bytes = new TextEncoder().encode(JSON.stringify(normalized(value)));
  check(bytes.length <= 32 * 1024 * 1024, "RECORD_BYTES_LIMIT");
  return bytes;
}
async function recordDigest(value) {
  return bytesToHex(await sha2563(encodeRecord(value)));
}
function signedBytes(domain, payload) {
  return encodeRecord(["chronolog/authored/v1", domain, payload]);
}
async function signRecord(domain, payload, identity) {
  hex(identity.publicKey);
  const captured = structuredClone(payload);
  const signature = bytesToHex(new Uint8Array(await crypto.subtle.sign("Ed25519", identity.privateKey, Uint8Array.from(signedBytes(domain, captured)).buffer)));
  const result = { payload: captured, signer: identity.publicKey, signature };
  await verifyRecord(domain, result, identity.publicKey);
  return result;
}
async function verifyRecord(domain, signed, expectedSigner) {
  hex(signed.signer);
  hex(signed.signature, 64);
  check(expectedSigner === void 0 || signed.signer === expectedSigner, "AUTHORITY_SIGNER_MISMATCH");
  const key = await importEd25519PublicKey(hexToBytes(signed.signer));
  check(await crypto.subtle.verify("Ed25519", key, Uint8Array.from(hexToBytes(signed.signature)).buffer, Uint8Array.from(signedBytes(domain, signed.payload)).buffer), "AUTHORITY_SIGNATURE_INVALID");
}

// packages/authority/src/finality-v2.ts
async function policyScopeId(chainId, entry) {
  return recordDigest(["chronolog/finality-scope/v2", chainId, entry.effectiveAfterMs, entry.policy]);
}
function computeIncludedSetDigest(opIds) {
  const sorted = [...new Set(opIds)].sort();
  return bytesToHex(sha256Sync(utf8(JSON.stringify(sorted))));
}
async function signFinalityCheckpoint(payload, signer) {
  return signRecord("chronolog/finality-checkpoint/v2", payload, signer);
}
function parseFinalitySchedule(raw) {
  if (raw === null || raw === void 0) return [{ effectiveAfterMs: -1n, policy: { kind: "none" } }];
  check(typeof raw === "object" && !Array.isArray(raw) && Array.isArray(raw.schedule), "FINALITY_SCHEDULE_INVALID");
  const list = raw.schedule;
  check(list.length > 0, "FINALITY_SCHEDULE_EMPTY");
  const out = [];
  let prev = -2n;
  for (const item of list) {
    check(item !== null && typeof item === "object" && !Array.isArray(item), "FINALITY_ENTRY_INVALID");
    const rec = item;
    const after = typeof rec.effectiveAfterMs === "bigint" ? rec.effectiveAfterMs : typeof rec.effectiveAfterMs === "number" && Number.isSafeInteger(rec.effectiveAfterMs) ? BigInt(rec.effectiveAfterMs) : (() => {
      throw new Error("FINALITY_ACTIVATION_INVALID");
    })();
    check(after > prev, "FINALITY_ACTIVATION_NOT_MONOTONIC");
    prev = after;
    out.push({ effectiveAfterMs: after, policy: rec.policy });
  }
  return out;
}
async function verifyAttestationForPolicy(policy, checkpoint, blockchainVerifier) {
  if (policy.kind === "none") return false;
  if (policy.kind === "blockchain-anchor") {
    if (checkpoint.attestation.kind !== "blockchain" || blockchainVerifier === void 0) return false;
    return await blockchainVerifier(policy, checkpoint);
  }
  if (checkpoint.attestation.kind !== "signatures") return false;
  const allowed = policy.kind === "signed-frontier" ? [policy.signer] : policy.validators;
  const threshold = policy.kind === "signed-frontier" ? 1 : policy.threshold;
  const validSigners = /* @__PURE__ */ new Set();
  for (const sig of checkpoint.attestation.signatures) {
    if (!allowed.includes(sig.signer)) continue;
    try {
      await verifyRecord("chronolog/finality-checkpoint/v2", sig, sig.signer);
      if (await recordDigest(sig.payload) === await recordDigest(checkpoint.payload)) {
        validSigners.add(sig.signer);
      }
    } catch {
    }
  }
  return validSigners.size >= threshold;
}
async function verifyFinalityV2(options) {
  hex(options.chainId);
  const scopeEntries = await Promise.all(
    options.schedule.map(async (entry, index) => ({
      index,
      entry,
      scopeId: await policyScopeId(options.chainId, entry)
    }))
  );
  const byScope = new Map(scopeEntries.map((s) => [s.scopeId, s]));
  const sorted = [...options.checkpoints].sort(
    (a, b) => a.payload.closedThroughMs < b.payload.closedThroughMs ? -1 : a.payload.closedThroughMs > b.payload.closedThroughMs ? 1 : 0
  );
  const verifiedCheckpoints = [];
  const includedOpIds = /* @__PURE__ */ new Set();
  let highestClosed = null;
  const closedByScopeIndex = /* @__PURE__ */ new Map();
  for (const cp of sorted) {
    const p = cp.payload;
    if (p.chainId !== options.chainId) continue;
    const scope = byScope.get(p.policyScopeId);
    if (scope === void 0) continue;
    if (scope.entry.policy.kind === "none") continue;
    if (p.closedThroughMs < scope.entry.effectiveAfterMs) continue;
    if (scope.index > 0) {
      const prev = scopeEntries[scope.index - 1];
      if (prev.entry.policy.kind !== "none") {
        const prevClosed = closedByScopeIndex.get(prev.index);
        if (prevClosed === void 0 || prevClosed < scope.entry.effectiveAfterMs) {
          continue;
        }
      }
    }
    const ok = await verifyAttestationForPolicy(scope.entry.policy, cp, options.blockchainVerifier);
    if (!ok) continue;
    for (const inc of p.inclusions) {
      includedOpIds.add(inc.opId);
    }
    const prevScopeClosed = closedByScopeIndex.get(scope.index);
    if (prevScopeClosed === void 0 || p.closedThroughMs > prevScopeClosed) {
      closedByScopeIndex.set(scope.index, p.closedThroughMs);
    }
    if (highestClosed === null || p.closedThroughMs > highestClosed) {
      highestClosed = p.closedThroughMs;
    }
    verifiedCheckpoints.push(cp);
  }
  const excludedOpIds = /* @__PURE__ */ new Set();
  if (highestClosed !== null && options.knownOps !== void 0) {
    for (const op of options.knownOps) {
      if (op.authorTimestampMs <= highestClosed && !includedOpIds.has(op.opId)) {
        excludedOpIds.add(op.opId);
      }
    }
  }
  return {
    closedThroughMs: highestClosed,
    includedOpIds,
    excludedOpIds,
    latestCheckpoint: verifiedCheckpoints.at(-1) ?? null,
    verifiedCheckpoints
  };
}
async function signHostAttestationV2(payload, hostIdentity) {
  const msg = utf8(canonicalEventPayload(["chronolog/host-attestation/v1", payload]));
  const sig = new Uint8Array(await crypto.subtle.sign("Ed25519", hostIdentity.privateKey, Uint8Array.from(msg).buffer));
  return { payload: structuredClone(payload), signature: bytesToHex(sig) };
}
async function verifyHostAttestationV2(attestation, hostPublicKeyHex) {
  if (!/^[0-9a-f]{64}$/u.test(hostPublicKeyHex) || !/^[0-9a-f]{128}$/u.test(attestation.signature)) return false;
  const key = await crypto.subtle.importKey("raw", Uint8Array.from(hexToBytes(hostPublicKeyHex)).buffer, "Ed25519", false, ["verify"]);
  const msg = utf8(canonicalEventPayload(["chronolog/host-attestation/v1", attestation.payload]));
  return crypto.subtle.verify("Ed25519", key, Uint8Array.from(hexToBytes(attestation.signature)).buffer, Uint8Array.from(msg).buffer);
}
export {
  computeIncludedSetDigest,
  parseFinalitySchedule,
  policyScopeId,
  signFinalityCheckpoint,
  signHostAttestationV2,
  verifyFinalityV2,
  verifyHostAttestationV2
};
/*! Bundled license information:

@noble/hashes/esm/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)
*/
