// packages/canonical/src/errors.ts
var CanonicalError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.details = details;
    this.name = "CanonicalError";
  }
  code;
  details;
};
function canonicalInvariant(condition, code, message, details) {
  if (!condition) throw new CanonicalError(code, message, details);
}

// packages/canonical/src/bytes.ts
var textEncoder = new TextEncoder();
var fatalTextDecoder = new TextDecoder("utf-8", { fatal: true });
function utf8(value) {
  const encoded = textEncoder.encode(value);
  try {
    if (fatalTextDecoder.decode(encoded) !== value) throw new CanonicalError("INVALID_UTF8", "Text contains an unpaired UTF-16 surrogate");
  } catch (error) {
    if (error instanceof CanonicalError) throw error;
    throw new CanonicalError("INVALID_UTF8", "Text cannot be represented as canonical UTF-8");
  }
  return encoded;
}
function decodeUtf8(value) {
  try {
    return fatalTextDecoder.decode(value);
  } catch {
    throw new CanonicalError("INVALID_UTF8", "Bytes are not valid UTF-8");
  }
}
function concatBytes(...parts) {
  const size = parts.reduce((sum, part) => sum + part.length, 0);
  const result = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}
function compareBytes(left, right) {
  const size = Math.min(left.length, right.length);
  for (let index = 0; index < size; index += 1) {
    const difference = left[index] - right[index];
    if (difference !== 0) return difference < 0 ? -1 : 1;
  }
  return left.length === right.length ? 0 : left.length < right.length ? -1 : 1;
}
function equalBytes(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}
var hexPairs = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, "0"));
function bytesToHex(value) {
  let result = "";
  for (const byte of value) result += hexPairs[byte];
  return result;
}
function hexToBytes(value) {
  if (!/^(?:[0-9a-fA-F]{2})*$/u.test(value)) throw new CanonicalError("SCHEMA_INVALID", "Hex text is malformed");
  return Uint8Array.from({ length: value.length / 2 }, (_unused, index) => Number.parseInt(value.slice(index * 2, index * 2 + 2), 16));
}

// packages/canonical/src/cbor.ts
var DEFAULT_DECODE_LIMITS = Object.freeze({
  maxBytes: 16 * 1024 * 1024,
  maxDepth: 64,
  maxArrayItems: 1e6,
  maxMapItems: 1e5,
  maxTextBytes: 4 * 1024 * 1024,
  maxBlobBytes: 16 * 1024 * 1024
});
var MAX_UINT64 = (1n << 64n) - 1n;
var POSITIVE_BIGNUM_TAG = 2n;
var NEGATIVE_BIGNUM_TAG = 3n;
function encodeHead(major, value) {
  canonicalInvariant(value >= 0n && value <= MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR integer is outside uint64 range");
  if (value < 24n) return Uint8Array.of(major << 5 | Number(value));
  if (value <= 0xffn) return Uint8Array.of(major << 5 | 24, Number(value));
  if (value <= 0xffffn) return Uint8Array.of(major << 5 | 25, Number(value >> 8n), Number(value & 0xffn));
  if (value <= 0xffffffffn) {
    const bytes3 = new Uint8Array(5);
    bytes3[0] = major << 5 | 26;
    new DataView(bytes3.buffer).setUint32(1, Number(value), false);
    return bytes3;
  }
  const bytes2 = new Uint8Array(9);
  bytes2[0] = major << 5 | 27;
  new DataView(bytes2.buffer).setBigUint64(1, value, false);
  return bytes2;
}
function magnitudeBytes(value) {
  canonicalInvariant(value > MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR bignum must exceed uint64 range");
  const octets = [];
  for (let remaining = value; remaining > 0n; remaining >>= 8n) octets.push(Number(remaining & 0xffn));
  octets.reverse();
  return Uint8Array.from(octets);
}
function encodeBigint(value) {
  const negative = value < 0n;
  const magnitude = negative ? -1n - value : value;
  if (magnitude <= MAX_UINT64) return encodeHead(negative ? 1 : 0, magnitude);
  const bytes2 = magnitudeBytes(magnitude);
  return concatBytes(
    encodeHead(6, negative ? NEGATIVE_BIGNUM_TAG : POSITIVE_BIGNUM_TAG),
    encodeHead(2, BigInt(bytes2.length)),
    bytes2
  );
}
function isMap(value) {
  return value instanceof Map;
}
function encodeCanonicalCbor(value) {
  if (value === null) return Uint8Array.of(246);
  if (value === false) return Uint8Array.of(244);
  if (value === true) return Uint8Array.of(245);
  if (typeof value === "bigint") return encodeBigint(value);
  if (typeof value === "string") {
    const bytes2 = utf8(value);
    return concatBytes(encodeHead(3, BigInt(bytes2.length)), bytes2);
  }
  if (value instanceof Uint8Array) return concatBytes(encodeHead(2, BigInt(value.length)), value);
  if (Array.isArray(value)) return concatBytes(encodeHead(4, BigInt(value.length)), ...value.map(encodeCanonicalCbor));
  if (isMap(value)) {
    const entries = [...value].map(([key, item]) => ({ key: encodeCanonicalCbor(key), value: encodeCanonicalCbor(item) })).sort((a, b) => a.key.length === b.key.length ? compareBytes(a.key, b.key) : a.key.length - b.key.length);
    for (let index = 1; index < entries.length; index += 1) canonicalInvariant(!equalBytes(entries[index - 1].key, entries[index].key), "CBOR_NON_CANONICAL", "Duplicate canonical CBOR map key");
    return concatBytes(encodeHead(5, BigInt(entries.length)), ...entries.flatMap((entry) => [entry.key, entry.value]));
  }
  throw new CanonicalError("SCHEMA_INVALID", "Value is not supported by the deterministic CBOR profile");
}
var Decoder = class {
  constructor(input, limits) {
    this.input = input;
    this.limits = limits;
    canonicalInvariant(input.length <= limits.maxBytes, "CBOR_LIMIT_EXCEEDED", "CBOR input exceeds byte limit");
  }
  input;
  limits;
  offset = 0;
  decode() {
    const value = this.value(0);
    canonicalInvariant(this.offset === this.input.length, "CBOR_INVALID", "Trailing bytes after CBOR value");
    return value;
  }
  byte() {
    canonicalInvariant(this.offset < this.input.length, "CBOR_INVALID", "Unexpected end of CBOR input");
    return this.input[this.offset++];
  }
  bytes(size) {
    canonicalInvariant(Number.isSafeInteger(size) && size >= 0 && this.offset + size <= this.input.length, "CBOR_INVALID", "Invalid or truncated CBOR byte range");
    const value = this.input.slice(this.offset, this.offset + size);
    this.offset += size;
    return value;
  }
  argument(additional) {
    if (additional < 24) return BigInt(additional);
    const read = (size) => {
      const bytes2 = this.bytes(size);
      const view = new DataView(bytes2.buffer, bytes2.byteOffset, size);
      return size === 1 ? BigInt(bytes2[0]) : size === 2 ? BigInt(view.getUint16(0, false)) : size === 4 ? BigInt(view.getUint32(0, false)) : view.getBigUint64(0, false);
    };
    if (additional === 24) {
      const v = read(1);
      canonicalInvariant(v >= 24n, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 25) {
      const v = read(2);
      canonicalInvariant(v > 0xffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 26) {
      const v = read(4);
      canonicalInvariant(v > 0xffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 27) {
      const v = read(8);
      canonicalInvariant(v > 0xffffffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 31) throw new CanonicalError("CBOR_NON_CANONICAL", "Indefinite-length CBOR is prohibited");
    throw new CanonicalError("CBOR_INVALID", "Reserved CBOR additional information");
  }
  bignum(tag, depth) {
    canonicalInvariant(tag === POSITIVE_BIGNUM_TAG || tag === NEGATIVE_BIGNUM_TAG, "CBOR_INVALID", "Unsupported CBOR tag");
    canonicalInvariant(depth < this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    canonicalInvariant(major === 2, "CBOR_INVALID", "CBOR bignum payload must be a byte string");
    const argument = this.argument(additional);
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR bignum is too large");
    const size = Number(argument);
    canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR bignum exceeds blob limit");
    const bytes2 = this.bytes(size);
    canonicalInvariant(bytes2.length > 8 && bytes2[0] !== 0, "CBOR_NON_CANONICAL", "CBOR bignum is not minimally encoded");
    let magnitude = 0n;
    for (const byte of bytes2) magnitude = magnitude << 8n | BigInt(byte);
    canonicalInvariant(magnitude > MAX_UINT64, "CBOR_NON_CANONICAL", "CBOR bignum must use the ordinary integer representation");
    return tag === POSITIVE_BIGNUM_TAG ? magnitude : -1n - magnitude;
  }
  value(depth) {
    canonicalInvariant(depth <= this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    if (major === 7) {
      if (additional === 20) return false;
      if (additional === 21) return true;
      if (additional === 22) return null;
      throw new CanonicalError("CBOR_INVALID", "Floating point and unsupported simple CBOR values are prohibited");
    }
    const argument = this.argument(additional);
    if (major === 6) return this.bignum(argument, depth + 1);
    if (major === 0) return argument;
    if (major === 1) return -1n - argument;
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR collection is too large");
    const size = Number(argument);
    if (major === 2) {
      canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR blob exceeds limit");
      return this.bytes(size);
    }
    if (major === 3) {
      canonicalInvariant(size <= this.limits.maxTextBytes, "CBOR_LIMIT_EXCEEDED", "CBOR text exceeds limit");
      return decodeUtf8(this.bytes(size));
    }
    if (major === 4) {
      canonicalInvariant(size <= this.limits.maxArrayItems, "CBOR_LIMIT_EXCEEDED", "CBOR array exceeds item limit");
      return Array.from({ length: size }, () => this.value(depth + 1));
    }
    if (major === 5) {
      canonicalInvariant(size <= this.limits.maxMapItems, "CBOR_LIMIT_EXCEEDED", "CBOR map exceeds item limit");
      const map = /* @__PURE__ */ new Map();
      let previous;
      for (let index = 0; index < size; index += 1) {
        const start = this.offset, key = this.value(depth + 1);
        canonicalInvariant(typeof key === "bigint" || typeof key === "string" || key instanceof Uint8Array, "CBOR_INVALID", "Unsupported CBOR map key");
        const encoded = this.input.slice(start, this.offset);
        if (previous !== void 0) canonicalInvariant(previous.length === encoded.length ? compareBytes(previous, encoded) < 0 : previous.length < encoded.length, "CBOR_NON_CANONICAL", "CBOR map keys are duplicate or incorrectly ordered");
        previous = encoded;
        map.set(key, this.value(depth + 1));
      }
      return map;
    }
    throw new CanonicalError("CBOR_INVALID", `Unsupported CBOR major type ${major}`);
  }
};
function decodeCanonicalCbor(input, limits) {
  return new Decoder(input, limits).decode();
}
function assertCanonicalCbor(input, limits) {
  const value = decodeCanonicalCbor(input, limits);
  canonicalInvariant(equalBytes(encodeCanonicalCbor(value), input), "CBOR_NON_CANONICAL", "CBOR bytes are not canonical");
  return value;
}

// packages/canonical/src/hash.ts
var HASH_DOMAINS = Object.freeze({
  transaction: "chronolog/transaction",
  schema: "chronolog/schema",
  executionManifest: "chronolog/execution-manifest",
  queryResult: "chronolog/query-result",
  expectation: "chronolog/expectation",
  module: "chronolog/module",
  entropy: "chronolog/entropy",
  platformObject: "chronolog/platform-object"
});
function bufferSource(value) {
  return Uint8Array.from(value).buffer;
}
async function sha256(payload) {
  return new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bufferSource(payload)));
}

// packages/protocol/src/errors.ts
var ProtocolError = class extends Error {
  code;
  details;
  constructor(code, message, details) {
    super(message);
    this.name = "ProtocolError";
    this.code = code;
    this.details = details;
  }
  toJSON() {
    return this.details === void 0 ? { name: this.name, code: this.code, message: this.message } : { name: this.name, code: this.code, message: this.message, details: this.details };
  }
};
function protocolInvariant(condition, code, message, details) {
  if (!condition) throw new ProtocolError(code, message, details);
}

// packages/protocol/src/bytes.ts
function wrap(operation) {
  try {
    return operation();
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
    throw error;
  }
}
function utf82(value) {
  return wrap(() => utf8(value));
}
function bytesToHex2(value) {
  return bytesToHex(value);
}

// packages/protocol/src/cbor.ts
function sharedLimits(limits) {
  return {
    maxBytes: limits.maxBytes ?? DEFAULT_DECODE_LIMITS.maxBytes,
    maxDepth: limits.maxDepth ?? DEFAULT_DECODE_LIMITS.maxDepth,
    maxArrayItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxArrayItems,
    maxMapItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxMapItems,
    maxTextBytes: limits.maxTextBytes ?? DEFAULT_DECODE_LIMITS.maxTextBytes,
    maxBlobBytes: limits.maxByteStringBytes ?? DEFAULT_DECODE_LIMITS.maxBlobBytes
  };
}
function protocolError(error) {
  if (error instanceof ProtocolError) throw error;
  if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
  throw error;
}
function assertCanonicalCbor2(input, limits = {}) {
  try {
    return assertCanonicalCbor(input, sharedLimits(limits));
  } catch (error) {
    return protocolError(error);
  }
}

// packages/protocol/src/schema.ts
function integerMap(entries) {
  const result = /* @__PURE__ */ new Map();
  for (const [key, value] of entries) {
    if (value !== void 0) result.set(BigInt(key), value);
  }
  return result;
}
function expectMap(value, name2) {
  protocolInvariant(value instanceof Map, "SCHEMA_INVALID", `${name2} must be a CBOR map`);
  return value;
}
function expectArray(value, name2) {
  protocolInvariant(Array.isArray(value), "SCHEMA_INVALID", `${name2} must be a CBOR array`);
  return value;
}
function expectBytes(value, name2, length) {
  protocolInvariant(value instanceof Uint8Array, "SCHEMA_INVALID", `${name2} must be bytes`);
  if (length !== void 0) {
    protocolInvariant(value.length === length, "SCHEMA_INVALID", `${name2} must contain ${length} bytes`);
  }
  return value;
}
function expectString(value, name2) {
  protocolInvariant(typeof value === "string", "SCHEMA_INVALID", `${name2} must be text`);
  return value;
}
function expectBigint(value, name2) {
  protocolInvariant(typeof value === "bigint", "SCHEMA_INVALID", `${name2} must be an integer`);
  return value;
}
function expectUint64(value, name2) {
  const integer = expectBigint(value, name2);
  protocolInvariant(integer >= 0n && integer <= (1n << 64n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside uint64 range`);
  return integer;
}
function expectInt64(value, name2) {
  const integer = expectBigint(value, name2);
  protocolInvariant(integer >= -(1n << 63n) && integer <= (1n << 63n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside int64 range`);
  return integer;
}
function required(map, key, name2) {
  const value = map.get(BigInt(key));
  if (value === void 0) throw new ProtocolError("SCHEMA_INVALID", `Missing required field ${name2}`, { field: name2 });
  return value;
}
function optional(map, key) {
  return map.get(BigInt(key));
}
function assertKnownIntegerKeys(map, knownKeys, name2) {
  const known = new Set(knownKeys.map(BigInt));
  for (const key of map.keys()) {
    protocolInvariant(typeof key === "bigint", "SCHEMA_INVALID", `${name2} contains a non-integer field key`);
    protocolInvariant(known.has(key), "SCHEMA_INVALID", `${name2} contains unknown critical field ${String(key)}`);
  }
}
function expectVersion(map, expected, name2) {
  const version2 = expectUint64(required(map, 0, `${name2}.version`), `${name2}.version`);
  protocolInvariant(version2 === expected, "UNSUPPORTED_VERSION", `Unsupported ${name2} version`, { version: version2.toString() });
}

// packages/protocol/src/sql.ts
var MIN_INT64 = -(1n << 63n);
var MAX_INT64 = (1n << 63n) - 1n;
var sqlValue = Object.freeze({
  null: () => ({ kind: "null" }),
  integer: (value) => {
    const integer = typeof value === "bigint" ? value : BigInt(value);
    protocolInvariant(integer >= MIN_INT64 && integer <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
    return { kind: "integer", value: integer };
  },
  real: (value) => {
    protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "SQL REAL must be finite");
    return { kind: "real", value };
  },
  text: (value) => {
    utf82(value);
    return { kind: "text", value };
  },
  blob: (value) => ({ kind: "blob", value: Uint8Array.from(value) })
});
function toSqlValue(value) {
  if (value === null || value === void 0) return sqlValue.null();
  if (typeof value === "bigint") return sqlValue.integer(value);
  if (typeof value === "number") return Number.isSafeInteger(value) ? sqlValue.integer(value) : sqlValue.real(value);
  if (typeof value === "boolean") return sqlValue.integer(value ? 1n : 0n);
  if (typeof value === "string") return sqlValue.text(value);
  if (value instanceof Uint8Array) return sqlValue.blob(value);
  if (isSqlValue(value)) return value;
  throw new TypeError("SQL values must be null, boolean, bigint, number, string, Uint8Array or a tagged SqlValue");
}
function isSqlValue(value) {
  if (typeof value !== "object" || value === null || !("kind" in value)) return false;
  const tagged = value;
  switch (tagged.kind) {
    case "null":
      return true;
    case "integer":
      return typeof tagged.value === "bigint";
    case "real":
      return typeof tagged.value === "number";
    case "text":
      return typeof tagged.value === "string";
    case "blob":
      return tagged.value instanceof Uint8Array;
    default:
      return false;
  }
}
function realBits(value) {
  const bits = new Uint8Array(8);
  new DataView(bits.buffer).setFloat64(0, value, false);
  return bits;
}
function sqlValueToCanonicalCbor(value) {
  switch (value.kind) {
    case "null":
      return [0n];
    case "integer":
      protocolInvariant(value.value >= MIN_INT64 && value.value <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
      return [1n, value.value];
    case "real":
      protocolInvariant(Number.isFinite(value.value), "SCHEMA_INVALID", "SQL REAL must be finite");
      return [2n, realBits(value.value)];
    case "text":
      utf82(value.value);
      return [3n, value.value];
    case "blob":
      return [4n, Uint8Array.from(value.value)];
  }
}
function sqlValueFromCanonicalCbor(value, name2 = "sql_value") {
  const tuple = expectArray(value, name2);
  const kind = expectUint64(tuple[0] ?? null, `${name2}.kind`);
  protocolInvariant(tuple.length === (kind === 0n ? 1 : 2), "SCHEMA_INVALID", `${name2} has invalid arity`);
  switch (kind) {
    case 0n:
      return { kind: "null" };
    case 1n:
      return { kind: "integer", value: expectInt64(tuple[1] ?? null, `${name2}.integer`) };
    case 2n: {
      const bits = expectBytes(tuple[1] ?? null, `${name2}.real`, 8);
      const real = new DataView(bits.buffer, bits.byteOffset, 8).getFloat64(0, false);
      protocolInvariant(Number.isFinite(real), "SCHEMA_INVALID", `${name2}.real must be finite`);
      return { kind: "real", value: real };
    }
    case 3n:
      return { kind: "text", value: expectString(tuple[1] ?? null, `${name2}.text`) };
    case 4n:
      return { kind: "blob", value: Uint8Array.from(expectBytes(tuple[1] ?? null, `${name2}.blob`)) };
    default:
      protocolInvariant(false, "SCHEMA_INVALID", `${name2} has unknown kind`);
  }
}
var DEFAULT_EXECUTION_LIMITS = Object.freeze({
  maxSqlBytes: 1e6,
  maxVmSteps: 1e6,
  maxValueBytes: 16 * 1024 * 1024
});

// packages/protocol/src/sealed.ts
var MAX_SEALED_READERS = 256;
var MAX_SEALED_NAME_BYTES = 128;
var MAX_SEALED_ROW_KEY_VALUES = 64;
var MAX_SEALED_PLAINTEXT_BYTES = 1024 * 1024;
var MAX_SEALED_ENVELOPE_BYTES = MAX_SEALED_PLAINTEXT_BYTES + MAX_SEALED_READERS * 192 + 1024;
var MAX_SEALED_VERSION = (1n << 63n) - 1n;
var SEALED_OP_CODES = Object.freeze({
  register_reader_key: 64n,
  reader_policy: 65n,
  sealed_put: 66n
});
function isSealedPlatformOp(value) {
  return typeof value === "object" && value !== null && "op" in value && typeof value.op === "string" && Object.hasOwn(SEALED_OP_CODES, value.op);
}
var sealedOp = Object.freeze({
  registerReaderKey: (publicKey) => checked({ op: "register_reader_key", publicKey: id(publicKey, "register_reader_key.public_key") }),
  readerPolicy: (input) => checked({
    op: "reader_policy",
    table: input.table,
    rowKey: input.rowKey.map(toSqlValue),
    expectedVersion: input.expectedVersion,
    ...input.expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(input.expectedPolicyId, "reader_policy.expected_policy_id") },
    readers: input.readers.map((reader) => id(reader, "reader_policy.reader")).sort(compareBytes)
  }),
  put: (input) => checked({
    op: "sealed_put",
    policyId: id(input.policyId, "sealed_put.policy_id"),
    expectedPolicyVersion: input.expectedPolicyVersion,
    expectedDataVersion: input.expectedDataVersion,
    slot: input.slot,
    envelope: decodeSealedEnvelope(encodeSealedEnvelope(input.envelope))
  })
});
function checked(op) {
  return sealedPlatformOpFromCanonicalCbor(sealedPlatformOpToCanonicalCbor(op));
}
function id(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === 32, "SCHEMA_INVALID", `${field} must contain 32 bytes`);
  return Uint8Array.from(value);
}
function name(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0 && !value.includes("\0"), "SCHEMA_INVALID", `${field} must be nonempty text without U+0000`);
  protocolInvariant(utf82(value).length <= MAX_SEALED_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function version(value, field, minimum = 1n, maximum = MAX_SEALED_VERSION) {
  const parsed = expectUint64(value, field);
  protocolInvariant(parsed >= minimum && parsed <= maximum, "INTEGER_OUT_OF_RANGE", `${field} is outside the supported version range`);
  return parsed;
}
var isList = (value) => Array.isArray(value);
function orderedReaders(readers, field) {
  protocolInvariant(isList(readers) && readers.length <= MAX_SEALED_READERS, "SCHEMA_INVALID", `${field} has too many readers or is not an array`);
  return readers.map((reader, index) => {
    const key = id(reader, field);
    if (index > 0) protocolInvariant(compareBytes(readers[index - 1], reader) < 0, "SCHEMA_INVALID", `${field} must be sorted and unique`);
    return key;
  });
}
function sealedContextToCanonicalCbor(value) {
  return integerMap([
    [0, 1n],
    [1, id(value.groupId, "sealed_context.group_id")],
    [2, id(value.policyId, "sealed_context.policy_id")],
    [3, version(value.policyVersion, "sealed_context.policy_version")],
    [4, name(value.slot, "sealed_context.slot")],
    [5, version(value.dataVersion, "sealed_context.data_version")]
  ]);
}
function sealedContextFromCanonicalCbor(value) {
  const map = expectMap(value, "sealed_context");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], "sealed_context");
  expectVersion(map, 1n, "sealed_context");
  const context = {
    groupId: id(expectBytes(required(map, 1, "group_id"), "group_id", 32), "group_id"),
    policyId: id(expectBytes(required(map, 2, "policy_id"), "policy_id", 32), "policy_id"),
    policyVersion: expectUint64(required(map, 3, "policy_version"), "policy_version"),
    slot: expectString(required(map, 4, "slot"), "slot"),
    dataVersion: expectUint64(required(map, 5, "data_version"), "data_version")
  };
  sealedContextToCanonicalCbor(context);
  return context;
}
function sealedEnvelopeToCanonicalCbor(value) {
  protocolInvariant(value.nonce instanceof Uint8Array && value.nonce.length === 12, "SCHEMA_INVALID", "sealed_envelope.nonce must contain 12 bytes");
  protocolInvariant(
    value.ciphertext instanceof Uint8Array && value.ciphertext.length >= 16 && value.ciphertext.length <= MAX_SEALED_PLAINTEXT_BYTES + 16,
    "SCHEMA_INVALID",
    "sealed_envelope.ciphertext has an invalid length"
  );
  protocolInvariant(isList(value.wraps), "SCHEMA_INVALID", "sealed_envelope.wraps must be an array");
  orderedReaders(value.wraps.map((wrap2) => wrap2.readerId), "sealed_envelope.wraps");
  return integerMap([
    [0, 1n],
    [1, sealedContextToCanonicalCbor(value.context)],
    [2, Uint8Array.from(value.nonce)],
    [3, Uint8Array.from(value.ciphertext)],
    [4, value.wraps.map((wrap2) => {
      protocolInvariant(wrap2.ciphertext instanceof Uint8Array && wrap2.ciphertext.length === 48, "SCHEMA_INVALID", "sealed_wrap.ciphertext must contain 48 bytes");
      return [
        id(wrap2.readerId, "sealed_wrap.reader_id"),
        id(wrap2.publicKey, "sealed_wrap.public_key"),
        id(wrap2.encapsulatedKey, "sealed_wrap.encapsulated_key"),
        Uint8Array.from(wrap2.ciphertext)
      ];
    })]
  ]);
}
function sealedEnvelopeFromCanonicalCbor(value) {
  const map = expectMap(value, "sealed_envelope");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4], "sealed_envelope");
  expectVersion(map, 1n, "sealed_envelope");
  const envelope = {
    context: sealedContextFromCanonicalCbor(required(map, 1, "context")),
    nonce: Uint8Array.from(expectBytes(required(map, 2, "nonce"), "nonce", 12)),
    ciphertext: Uint8Array.from(expectBytes(required(map, 3, "ciphertext"), "ciphertext")),
    wraps: expectArray(required(map, 4, "wraps"), "wraps").map((entry) => {
      const fields = expectArray(entry, "sealed_wrap");
      protocolInvariant(fields.length === 4, "SCHEMA_INVALID", "sealed_wrap must contain four fields");
      return {
        readerId: id(expectBytes(fields[0], "reader_id", 32), "reader_id"),
        publicKey: id(expectBytes(fields[1], "public_key", 32), "public_key"),
        encapsulatedKey: id(expectBytes(fields[2], "encapsulated_key", 32), "encapsulated_key"),
        ciphertext: Uint8Array.from(expectBytes(fields[3], "wrapped_key", 48))
      };
    })
  };
  sealedEnvelopeToCanonicalCbor(envelope);
  return envelope;
}
function encodeSealedEnvelope(envelope) {
  return encodeCanonicalCbor(sealedEnvelopeToCanonicalCbor(envelope));
}
function decodeSealedEnvelope(bytes2) {
  protocolInvariant(bytes2.length <= MAX_SEALED_ENVELOPE_BYTES, "SCHEMA_INVALID", "sealed_envelope exceeds the encoded size limit");
  return sealedEnvelopeFromCanonicalCbor(assertCanonicalCbor2(bytes2));
}
function sealedPlatformOpToCanonicalCbor(op) {
  protocolInvariant(isSealedPlatformOp(op), "SCHEMA_INVALID", "Unknown sealed operation");
  const entries = [[0, SEALED_OP_CODES[op.op]]];
  switch (op.op) {
    case "register_reader_key":
      entries.push([1, id(op.publicKey, "register_reader_key.public_key")]);
      break;
    case "reader_policy": {
      const expected = version(op.expectedVersion, "reader_policy.expected_version", 0n, MAX_SEALED_VERSION - 1n);
      protocolInvariant(expected === 0n === (op.expectedPolicyId === void 0), "SCHEMA_INVALID", "reader_policy creation uses version 0 without an id; replacement requires an id and positive version");
      protocolInvariant(isList(op.rowKey) && op.rowKey.length >= 1 && op.rowKey.length <= MAX_SEALED_ROW_KEY_VALUES, "SCHEMA_INVALID", "reader_policy.row_key has an invalid length");
      entries.push(
        [1, name(op.table, "reader_policy.table")],
        [2, op.rowKey.map(sqlValueToCanonicalCbor)],
        [3, op.expectedPolicyId === void 0 ? void 0 : id(op.expectedPolicyId, "reader_policy.expected_policy_id")],
        [4, expected],
        [5, orderedReaders(op.readers, "reader_policy.readers")]
      );
      break;
    }
    case "sealed_put": {
      const policyId = id(op.policyId, "sealed_put.policy_id");
      const policyVersion = version(op.expectedPolicyVersion, "sealed_put.expected_policy_version");
      const dataVersion = version(op.expectedDataVersion, "sealed_put.expected_data_version", 0n, MAX_SEALED_VERSION - 1n);
      const slot = name(op.slot, "sealed_put.slot");
      const envelope = sealedEnvelopeToCanonicalCbor(op.envelope);
      protocolInvariant(
        equalBytes(op.envelope.context.policyId, policyId) && op.envelope.context.policyVersion === policyVersion && op.envelope.context.slot === slot && op.envelope.context.dataVersion === dataVersion + 1n,
        "SCHEMA_INVALID",
        "sealed_put envelope does not match its policy, slot or next data version"
      );
      entries.push([1, policyId], [2, policyVersion], [3, dataVersion], [4, slot], [5, envelope]);
      break;
    }
  }
  return integerMap(entries);
}
function sealedPlatformOpFromCanonicalCbor(value, field = "sealed_op") {
  const map = expectMap(value, field);
  const code = expectUint64(required(map, 0, `${field}.op`), `${field}.op`);
  let op;
  if (code === SEALED_OP_CODES.register_reader_key) {
    assertKnownIntegerKeys(map, [0, 1], field);
    op = { op: "register_reader_key", publicKey: id(expectBytes(required(map, 1, "public_key"), "public_key", 32), "public_key") };
  } else if (code === SEALED_OP_CODES.reader_policy) {
    assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], field);
    const expectedPolicyId = optional(map, 3);
    op = {
      op: "reader_policy",
      table: expectString(required(map, 1, "table"), "table"),
      rowKey: expectArray(required(map, 2, "row_key"), "row_key").map((item, index) => sqlValueFromCanonicalCbor(item, `row_key[${index}]`)),
      ...expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(expectBytes(expectedPolicyId, "expected_policy_id", 32), "expected_policy_id") },
      expectedVersion: expectUint64(required(map, 4, "expected_version"), "expected_version"),
      readers: expectArray(required(map, 5, "readers"), "readers").map((reader) => id(expectBytes(reader, "reader", 32), "reader"))
    };
  } else if (code === SEALED_OP_CODES.sealed_put) {
    assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], field);
    op = {
      op: "sealed_put",
      policyId: id(expectBytes(required(map, 1, "policy_id"), "policy_id", 32), "policy_id"),
      expectedPolicyVersion: expectUint64(required(map, 2, "expected_policy_version"), "expected_policy_version"),
      expectedDataVersion: expectUint64(required(map, 3, "expected_data_version"), "expected_data_version"),
      slot: expectString(required(map, 4, "slot"), "slot"),
      envelope: sealedEnvelopeFromCanonicalCbor(required(map, 5, "envelope"))
    };
  } else {
    protocolInvariant(false, "SCHEMA_INVALID", `${field} has an unknown sealed operation`);
  }
  sealedPlatformOpToCanonicalCbor(op);
  return op;
}

// packages/protocol/src/platform.ts
var PLATFORM_ID_BYTES = 32;
var MAX_PLATFORM_NAME_BYTES = 128;
var MAX_PLATFORM_LIST_ENTRIES = 256;
var MAX_ROW_KEY_VALUES = 64;
var MAX_SEED_ROWS = 1e4;
var GROUP_COLLECTIVE_ID = new Uint8Array(PLATFORM_ID_BYTES);
var OP_CODES = [
  "grant",
  "revoke_grant",
  "create_collective",
  "accept_membership",
  "leave",
  "set_members",
  "transfer_offer",
  "transfer_accept",
  "seed_rows",
  "end_seeding",
  "transfer_cancel",
  "grant_ddl",
  "revoke_ddl"
];
var DDL_OPERATIONS = ["create", "alter", "drop", "index", "trigger"];
var OPERATION_BITS = { insert: 1n, update: 2n, delete: 4n };
var GRANT_OPERATIONS = ["insert", "update", "delete"];
var bytes = (value) => Uint8Array.from(value);
var rowKey = (values) => values.map(toSqlValue);
var platformOp = Object.freeze({
  ...sealedOp,
  grantDdl: (input) => checked2({ op: "grant_ddl", scope: { ...input.scope }, grantee: bytes(input.grantee), operations: [...input.operations] }),
  revokeDdl: (grantId) => checked2({ op: "revoke_ddl", grantId: bytes(grantId) }),
  grant: (input) => checked2({
    op: "grant",
    table: input.table,
    grantee: bytes(input.grantee),
    operations: [...input.operations],
    ...input.grantor === void 0 ? {} : { grantor: bytes(input.grantor) },
    ...input.rowKey === void 0 ? {} : { rowKey: rowKey(input.rowKey) },
    ...input.columns === void 0 ? {} : { columns: [...input.columns] }
  }),
  revokeGrant: (grantId) => checked2({ op: "revoke_grant", grantId: bytes(grantId) }),
  createCollective: (input) => checked2({ op: "create_collective", governance: { ...input.governance }, invitees: (input.invitees ?? []).map(bytes) }),
  acceptMembership: (collectiveId) => checked2({ op: "accept_membership", collectiveId: bytes(collectiveId) }),
  leave: (collectiveId) => checked2({ op: "leave", collectiveId: bytes(collectiveId) }),
  setMembers: (collectiveId, changes) => checked2({
    op: "set_members",
    collectiveId: bytes(collectiveId),
    changes: changes.map((change) => ({ member: bytes(change.member), role: change.role }))
  }),
  transferRow: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "row", table: input.table, rowKey: rowKey(input.rowKey) },
    toOwner: bytes(input.toOwner),
    carry: input.carry ?? false,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  transferAll: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "all" },
    toOwner: bytes(input.toOwner),
    carry: true,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  acceptTransfer: (offerId) => checked2({ op: "transfer_accept", offerId: bytes(offerId) }),
  cancelTransfer: (offerId) => checked2({ op: "transfer_cancel", offerId: bytes(offerId) }),
  seedRows: (table, columns, rows) => checked2({ op: "seed_rows", table, columns: [...columns], rows: rows.map(rowKey) }),
  endSeeding: () => checked2({ op: "end_seeding" })
});
function checked2(op) {
  platformOpToCanonicalCbor(op);
  return op;
}
function nameToCbor(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0, "SCHEMA_INVALID", `${field} cannot be empty`);
  protocolInvariant(!value.includes("\0"), "SCHEMA_INVALID", `${field} cannot contain U+0000`);
  protocolInvariant(utf82(value).length <= MAX_PLATFORM_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function idToCbor(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === PLATFORM_ID_BYTES, "SCHEMA_INVALID", `${field} must contain ${PLATFORM_ID_BYTES} bytes`);
  return Uint8Array.from(value);
}
function listToCbor(values, field, encode, minimum = 0) {
  protocolInvariant(isList2(values), "SCHEMA_INVALID", `${field} must be a list`);
  protocolInvariant(values.length >= minimum && values.length <= MAX_PLATFORM_LIST_ENTRIES, "SCHEMA_INVALID", `${field} has an invalid number of entries`);
  return values.map(encode);
}
function uniqueBy(values, key, field) {
  const seen = /* @__PURE__ */ new Set();
  for (const value of values) {
    const entry = key(value);
    protocolInvariant(!seen.has(entry), "SCHEMA_INVALID", `${field} contains a duplicate`);
    seen.add(entry);
  }
}
var hex = (value) => bytesToHex2(value);
var isList2 = (value) => Array.isArray(value);
function rowKeyToCbor(values, field) {
  protocolInvariant(isList2(values) && values.length >= 1 && values.length <= MAX_ROW_KEY_VALUES, "SCHEMA_INVALID", `${field} must have 1 to ${MAX_ROW_KEY_VALUES} values`);
  return values.map(sqlValueToCanonicalCbor);
}
function roleCode(role, field) {
  protocolInvariant(role === "member" || role === "admin", "SCHEMA_INVALID", `${field} must be member or admin`);
  return role === "member" ? 0n : 1n;
}
function platformOpToCanonicalCbor(op) {
  if (isSealedPlatformOp(op)) return sealedPlatformOpToCanonicalCbor(op);
  const code = OP_CODES.indexOf(op.op);
  protocolInvariant(code >= 0, "SCHEMA_INVALID", "Unknown platform operation");
  const entries = [[0, BigInt(code)]];
  switch (op.op) {
    case "grant_ddl": {
      protocolInvariant(op.scope.kind === "namespace" || op.scope.kind === "object", "SCHEMA_INVALID", "Unknown DDL scope");
      protocolInvariant(op.scope.kind !== "namespace" || op.scope.name === "main", "SCHEMA_INVALID", "Only the main namespace exists");
      protocolInvariant(isList2(op.operations) && op.operations.length > 0, "SCHEMA_INVALID", "DDL operations cannot be empty");
      uniqueBy(op.operations, (value) => value, "grant_ddl.operations");
      protocolInvariant(op.operations.every((operation) => DDL_OPERATIONS.includes(operation) && (op.scope.kind === "namespace" ? operation === "create" : operation !== "create")), "SCHEMA_INVALID", "Invalid DDL operation for scope");
      protocolInvariant(
        DDL_OPERATIONS.filter((operation) => op.operations.includes(operation)).every((operation, index) => op.operations[index] === operation),
        "SCHEMA_INVALID",
        "DDL operations must be in create, alter, drop, index, trigger order"
      );
      entries.push(
        [1, [op.scope.kind === "namespace" ? 0n : 1n, nameToCbor(op.scope.name, "grant_ddl.scope")]],
        [2, idToCbor(op.grantee, "grant_ddl.grantee")],
        [3, op.operations.map((operation) => BigInt(DDL_OPERATIONS.indexOf(operation)))]
      );
      break;
    }
    case "revoke_ddl":
      entries.push([1, idToCbor(op.grantId, "revoke_ddl.grant_id")]);
      break;
    case "grant": {
      protocolInvariant(isList2(op.operations) && op.operations.length > 0, "SCHEMA_INVALID", "grant.operations cannot be empty");
      uniqueBy(op.operations, (value) => value, "grant.operations");
      let mask = 0n;
      for (const operation of op.operations) {
        protocolInvariant(GRANT_OPERATIONS.includes(operation), "SCHEMA_INVALID", "grant.operations has an unknown operation");
        mask |= OPERATION_BITS[operation];
      }
      protocolInvariant(
        GRANT_OPERATIONS.filter((operation) => op.operations.includes(operation)).every((operation, index) => op.operations[index] === operation),
        "SCHEMA_INVALID",
        "grant.operations must be in insert, update, delete order"
      );
      if (op.columns !== void 0) uniqueBy(op.columns, (value) => value, "grant.columns");
      entries.push(
        [1, nameToCbor(op.table, "grant.table")],
        [2, idToCbor(op.grantee, "grant.grantee")],
        [3, mask],
        [4, op.grantor === void 0 ? void 0 : idToCbor(op.grantor, "grant.grantor")],
        [5, op.rowKey === void 0 ? void 0 : rowKeyToCbor(op.rowKey, "grant.row_key")],
        [6, op.columns === void 0 ? void 0 : listToCbor(op.columns, "grant.columns", (column) => nameToCbor(column, "grant.columns"), 1)]
      );
      break;
    }
    case "revoke_grant":
      entries.push([1, idToCbor(op.grantId, "revoke_grant.grant_id")]);
      break;
    case "create_collective":
      uniqueBy(op.invitees, hex, "create_collective.invitees");
      entries.push(
        [1, integerMap([
          [0, roleCode(op.governance.insert, "governance.insert")],
          [1, roleCode(op.governance.update, "governance.update")],
          [2, roleCode(op.governance.delete, "governance.delete")]
        ])],
        [2, listToCbor(op.invitees, "create_collective.invitees", (key) => idToCbor(key, "create_collective.invitees"))]
      );
      break;
    case "accept_membership":
    case "leave":
      entries.push([1, idToCbor(op.collectiveId, `${op.op}.collective_id`)]);
      break;
    case "set_members":
      uniqueBy(op.changes, (change) => hex(change.member), "set_members.changes");
      entries.push(
        [1, idToCbor(op.collectiveId, "set_members.collective_id")],
        [2, listToCbor(op.changes, "set_members.changes", (change) => [
          idToCbor(change.member, "set_members.member"),
          change.role === "remove" ? 2n : roleCode(change.role, "set_members.role")
        ], 1)]
      );
      break;
    case "transfer_offer": {
      protocolInvariant(typeof op.carry === "boolean", "SCHEMA_INVALID", "transfer_offer.carry must be a boolean");
      let scope;
      if (op.scope.kind === "all") {
        protocolInvariant(op.carry, "SCHEMA_INVALID", "A transfer of all rows always carries dependents");
        scope = [1n];
      } else {
        protocolInvariant(op.scope.kind === "row", "SCHEMA_INVALID", "transfer_offer.scope is unknown");
        scope = [0n, nameToCbor(op.scope.table, "transfer_offer.table"), rowKeyToCbor(op.scope.rowKey, "transfer_offer.row_key")];
      }
      entries.push(
        [1, scope],
        [2, op.fromOwner === void 0 ? void 0 : idToCbor(op.fromOwner, "transfer_offer.from_owner")],
        [3, idToCbor(op.toOwner, "transfer_offer.to_owner")],
        [4, op.carry ? 1n : 0n]
      );
      break;
    }
    case "transfer_accept":
    case "transfer_cancel":
      entries.push([1, idToCbor(op.offerId, `${op.op}.offer_id`)]);
      break;
    case "seed_rows": {
      uniqueBy(op.columns, (value) => value.toLowerCase(), "seed_rows.columns");
      protocolInvariant(isList2(op.rows) && op.rows.length >= 1 && op.rows.length <= MAX_SEED_ROWS, "SCHEMA_INVALID", "seed_rows.rows has an invalid number of rows");
      entries.push(
        [1, nameToCbor(op.table, "seed_rows.table")],
        [2, listToCbor(op.columns, "seed_rows.columns", (column) => nameToCbor(column, "seed_rows.columns"), 1)],
        [3, op.rows.map((row) => {
          protocolInvariant(isList2(row) && row.length === op.columns.length, "SCHEMA_INVALID", "seed_rows row width must match its columns");
          return row.map(sqlValueToCanonicalCbor);
        })]
      );
      break;
    }
    case "end_seeding":
      break;
  }
  return integerMap(entries);
}

// packages/protocol/src/primitives.ts
var ED25519 = { name: "Ed25519" };
function bufferSource2(value) {
  return Uint8Array.from(value).buffer;
}
async function importEd25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "Ed25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", bufferSource2(raw), ED25519, true, ["verify"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 public key");
  }
}

// packages/authority/src/codec.ts
function check(condition, code) {
  if (!condition) throw Object.assign(new Error(code), { code });
}
function hex2(value, length = 32) {
  check(typeof value === "string" && new RegExp(`^[0-9a-f]{${length * 2}}$`, "u").test(value), "AUTHORITY_HEX_INVALID");
}
function normalized(value, depth = 0) {
  check(depth < 32, "RECORD_DEPTH_LIMIT");
  if (value instanceof Uint8Array) return { $bytes: bytesToHex(value) };
  if (typeof value === "bigint") return { $integer: value.toString() };
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    check(Number.isSafeInteger(value), "RECORD_INTEGER_INVALID");
    return value;
  }
  if (Array.isArray(value)) return value.map((item) => normalized(item, depth + 1));
  check(value !== null && typeof value === "object" && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null), "RECORD_INVALID");
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, normalized(value[key], depth + 1)]));
}
function encodeRecord(value) {
  const bytes2 = new TextEncoder().encode(JSON.stringify(normalized(value)));
  check(bytes2.length <= 32 * 1024 * 1024, "RECORD_BYTES_LIMIT");
  return bytes2;
}
function equalRecord(a, b) {
  return equalBytes(encodeRecord(a), encodeRecord(b));
}
async function recordDigest(value) {
  return bytesToHex(await sha256(encodeRecord(value)));
}
function signedBytes(domain, payload) {
  return encodeRecord(["chronolog/authored/v1", domain, payload]);
}
async function signRecord(domain, payload, identity) {
  hex2(identity.publicKey);
  const captured = structuredClone(payload);
  const signature = bytesToHex(new Uint8Array(await crypto.subtle.sign("Ed25519", identity.privateKey, Uint8Array.from(signedBytes(domain, captured)).buffer)));
  const result = { payload: captured, signer: identity.publicKey, signature };
  await verifyRecord(domain, result, identity.publicKey);
  return result;
}
async function verifyRecord(domain, signed, expectedSigner) {
  hex2(signed.signer);
  hex2(signed.signature, 64);
  check(expectedSigner === void 0 || signed.signer === expectedSigner, "AUTHORITY_SIGNER_MISMATCH");
  const key = await importEd25519PublicKey(hexToBytes(signed.signer));
  check(await crypto.subtle.verify("Ed25519", key, Uint8Array.from(hexToBytes(signed.signature)).buffer, Uint8Array.from(signedBytes(domain, signed.payload)).buffer), "AUTHORITY_SIGNATURE_INVALID");
}

// packages/authority/src/control.ts
function writerAuthorizedAt(authority, publicKey, membershipId, authorTimestampMs, throughRevision = Number.MAX_SAFE_INTEGER) {
  const base = authority.membership(membershipId);
  if (base === null) return null;
  if (authorTimestampMs <= base.authorTimeAfterMs || base.members.find((member) => member.publicKey === publicKey)?.writer !== true) return false;
  for (const successor of authority.bundle().memberships.slice(base.revision + 1)) {
    if (successor.payload.revision > throughRevision || authorTimestampMs <= successor.payload.authorTimeAfterMs) break;
    if (successor.payload.members.find((member) => member.publicKey === publicKey)?.writer !== true) return false;
  }
  return true;
}
function finalizerAuthorizedAt(authority, publicKey, authorityHead, throughMs) {
  const head = authority.membership(authorityHead);
  if (head === null) return null;
  if (head.members.find((member) => member.publicKey === publicKey)?.finalizer !== true) return false;
  for (const successor of authority.bundle().memberships.slice(head.revision + 1)) {
    if (throughMs <= successor.payload.authorTimeAfterMs) break;
    if (successor.payload.members.find((member) => member.publicKey === publicKey)?.finalizer !== true) return false;
  }
  return true;
}

// packages/authority/src/finality.ts
var isArray = (value) => Array.isArray(value);
async function finalityPolicyDigest(policy) {
  return recordDigest(["finality-policy", policy]);
}
async function signFinalityStatement(statement, signer) {
  return signRecord("finality", statement, signer);
}
async function finalityAdmissionScopes(authority) {
  const policy = authority.descriptor.finalityPolicy;
  if (policy.kind === "none") return [];
  const scopes = new Map(policy.scopes.map((scope) => [scope.id, scope]));
  for (const membership of authority.bundle().memberships) {
    const id2 = await recordDigest(membership);
    check(!scopes.has(id2), "FINALITY_SCOPE_COLLISION");
    scopes.set(id2, { id: id2, authorTimeAfterMs: membership.payload.authorTimeAfterMs });
  }
  return [...scopes.values()];
}
async function mergeFinalityProofs(...histories) {
  const statements = /* @__PURE__ */ new Map();
  for (const history of histories) for (const input of history) {
    const proof = structuredClone(input), id2 = await recordDigest(proof.statement);
    check(proof.signatures.length <= 4096, "FINALITY_SIGNATURE_LIMIT");
    let entry = statements.get(id2);
    if (entry === void 0) {
      entry = { statement: proof.statement, signatures: /* @__PURE__ */ new Map() };
      statements.set(id2, entry);
    }
    for (const signature of proof.signatures) {
      check(equalRecord(signature.payload, proof.statement), "FINALITY_SIGNATURE_SCOPE");
      await verifyRecord("finality", signature);
      const prior = entry.signatures.get(signature.signer);
      if (prior === void 0 || signature.signature < prior.signature) entry.signatures.set(signature.signer, signature);
    }
  }
  check(statements.size <= 65536, "FINALITY_PROOF_LIMIT");
  return [...statements.values()].map((entry) => ({ statement: entry.statement, signatures: [...entry.signatures.values()].sort((a, b) => a.signer.localeCompare(b.signer)) })).sort((a, b) => a.statement.scope.localeCompare(b.statement.scope) || a.statement.sequence - b.statement.sequence);
}
async function verifyFinalityProofs(descriptor, input, authority, knownProposals = []) {
  const policy = descriptor.finalityPolicy;
  if (policy.kind === "none") {
    check(input.length === 0, "FINALITY_UNSUPPORTED");
    return { closedThroughMs: null, included: /* @__PURE__ */ new Map(), excludedProposalIds: /* @__PURE__ */ new Set(), proofs: [] };
  }
  check(authority !== void 0, "FINALITY_AUTHORITY_REQUIRED");
  check(equalRecord(descriptor, authority.descriptor), "FINALITY_AUTHORITY_SCOPE_MISMATCH");
  const proofs = await mergeFinalityProofs(input), scopes = await finalityAdmissionScopes(authority), policyDigest = await finalityPolicyDigest(policy);
  const allowed = policy.kind === "signed-frontier" ? [policy.signer] : policy.validators, threshold = policy.kind === "signed-frontier" ? 1 : policy.threshold;
  const heads = /* @__PURE__ */ new Map(), first = /* @__PURE__ */ new Map();
  const candidates = /* @__PURE__ */ new Map(), dependencies = /* @__PURE__ */ new Set(), verifiedProofs = [];
  const candidate = (value) => {
    hex2(value.proposalId);
    hex2(value.membershipId);
    hex2(value.author);
    check(typeof value.authorTimestampMs === "bigint" && value.authorTimestampMs >= 0n && value.authorTimestampMs <= (1n << 63n) - 1n, "FINALITY_INCLUSION_INVALID");
    const prior = candidates.get(value.proposalId);
    check(prior === void 0 || prior.authorTimestampMs === value.authorTimestampMs && prior.membershipId === value.membershipId && prior.author === value.author, "FINALITY_INCLUSION_CONFLICT");
    candidates.set(value.proposalId, value);
  };
  for (const value of knownProposals) candidate(value);
  for (const proof of proofs) {
    const statement = proof.statement, scope = scopes.find((item) => item.id === statement.scope), head = heads.get(statement.scope);
    hex2(statement.scope);
    hex2(statement.authorityHead);
    check(statement.applicationId === descriptor.applicationId && statement.policyDigest === policyDigest, "FINALITY_SCOPE_MISMATCH");
    check(Number.isSafeInteger(statement.sequence) && statement.sequence >= 0 && typeof statement.closedThroughMs === "bigint" && statement.closedThroughMs >= -1n && statement.closedThroughMs <= (1n << 63n) - 1n && isArray(statement.inclusions) && isArray(statement.blockers) && statement.inclusions.length <= 65536 && statement.blockers.length <= 65536, "FINALITY_STATEMENT_INVALID");
    check(proof.signatures.length <= allowed.length, "FINALITY_SIGNATURE_LIMIT");
    for (const signature of proof.signatures) check(allowed.includes(signature.signer), "FINALITY_SIGNATURE_SCOPE");
    const headMembership = authority.membership(statement.authorityHead);
    if (headMembership === null) {
      dependencies.add(`authority/${statement.authorityHead}`);
      continue;
    }
    const eligible = proof.signatures.filter((signature) => finalizerAuthorizedAt(authority, signature.signer, statement.authorityHead, statement.closedThroughMs) === true);
    if (eligible.length < threshold) {
      dependencies.add(`quorum/${await recordDigest(statement)}`);
      continue;
    }
    check(scope !== void 0, "FINALITY_SCOPE_MISMATCH");
    {
      const membership = authority.membership(statement.scope);
      check(membership === null || membership.revision <= headMembership.revision, "FINALITY_SCOPE_NOT_ACTIVE");
    }
    if (statement.sequence > (head?.sequence ?? -1) + 1) {
      dependencies.add(`history/${statement.scope}/${(head?.sequence ?? -1) + 1}`);
      continue;
    }
    check(statement.sequence === (head?.sequence ?? -1) + 1 && statement.previous === (head?.id ?? null), "FINALITY_HISTORY_FORK");
    check(statement.closedThroughMs >= (head?.closed ?? scope.authorTimeAfterMs), "FINALITY_CLOSURE_INVALID");
    for (const blocker of statement.blockers) {
      candidate(blocker);
      check(statement.closedThroughMs < blocker.authorTimestampMs, "FINALITY_BLOCKER_NOT_RESPECTED");
    }
    const scopedFirst = first.get(statement.scope) ?? /* @__PURE__ */ new Map();
    first.set(statement.scope, scopedFirst);
    for (const inclusion of statement.inclusions) {
      candidate(inclusion);
      check(inclusion.authorTimestampMs > scope.authorTimeAfterMs, "FINALITY_INCLUSION_INVALID");
      {
        const membership = authority.membership(inclusion.membershipId);
        check(membership !== null && membership.revision <= headMembership.revision && writerAuthorizedAt(authority, inclusion.author, inclusion.membershipId, inclusion.authorTimestampMs, headMembership.revision) === true, "FINALITY_INCLUSION_SCOPE_INVALID");
        check(!authority.hasMembership(statement.scope) || statement.scope === inclusion.membershipId, "FINALITY_INCLUSION_SCOPE_INVALID");
      }
      check(!scopedFirst.has(inclusion.proposalId), "FINALITY_FIRST_INCLUSION_REPEATED");
      scopedFirst.set(inclusion.proposalId, { inclusion, late: inclusion.authorTimestampMs <= (head?.closed ?? scope.authorTimeAfterMs) });
    }
    heads.set(statement.scope, { sequence: statement.sequence, id: await recordDigest(statement), closed: statement.closedThroughMs });
    verifiedProofs.push(proof);
  }
  const memberships = authority.bundle().memberships, membershipIds = await Promise.all(memberships.map((membership) => recordDigest(membership)));
  for (let index = 1; index < memberships.length; index++) {
    const priorScopes = [...policy.scopes, ...memberships.slice(0, index).map((membership, position) => ({ id: membershipIds[position], authorTimeAfterMs: membership.payload.authorTimeAfterMs }))];
    let sealed = (1n << 63n) - 1n;
    for (const scope of priorScopes) {
      const prior = verifiedProofs.filter((proof) => proof.statement.scope === scope.id && (authority.membership(proof.statement.authorityHead)?.revision ?? Infinity) < index).at(-1)?.statement, cutoff = prior?.closedThroughMs ?? scope.authorTimeAfterMs;
      if (cutoff < sealed) sealed = cutoff;
    }
    check(memberships[index].payload.authorTimeAfterMs >= sealed, "FINALITY_MEMBERSHIP_BEHIND_SEAL");
  }
  const included = /* @__PURE__ */ new Map(), excluded = /* @__PURE__ */ new Set();
  for (const value of candidates.values()) {
    const applicable = policy.scopes.filter((scope) => value.authorTimestampMs > scope.authorTimeAfterMs).map((scope) => scope.id);
    {
      if (writerAuthorizedAt(authority, value.author, value.membershipId, value.authorTimestampMs) === false) excluded.add(value.proposalId);
      applicable.push(value.membershipId);
    }
    let complete = applicable.length > 0;
    for (const id2 of applicable) {
      const admission = first.get(id2)?.get(value.proposalId), closed = heads.get(id2)?.closed;
      if (admission?.late === true || admission === void 0 && closed !== void 0 && value.authorTimestampMs <= closed) excluded.add(value.proposalId);
      if (admission === void 0 || admission.late) complete = false;
    }
    if (complete && !excluded.has(value.proposalId)) included.set(value.proposalId, value);
  }
  let closedThroughMs = null;
  for (const scope of scopes) {
    const cutoff = heads.get(scope.id)?.closed ?? scope.authorTimeAfterMs;
    if (closedThroughMs === null || cutoff < closedThroughMs) closedThroughMs = cutoff;
  }
  if (closedThroughMs !== null && closedThroughMs < 0n) closedThroughMs = null;
  return { closedThroughMs, included, excludedProposalIds: excluded, proofs, certifiedProofs: verifiedProofs, pendingDependencies: [...dependencies].sort() };
}
export {
  finalityAdmissionScopes,
  finalityPolicyDigest,
  mergeFinalityProofs,
  signFinalityStatement,
  verifyFinalityProofs
};
