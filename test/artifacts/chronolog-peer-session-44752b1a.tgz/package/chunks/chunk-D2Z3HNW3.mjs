import {
  awaitOwnedTask
} from "./chunk-KSC4KBWO.mjs";
import {
  canonicalEventPayload,
  canonicalJson,
  exportEd25519PrivateKey,
  generateEd25519KeyPair,
  importEd25519PrivateKey,
  importEd25519PublicKey,
  normalizeJsonValue
} from "./chunk-37AJJO3T.mjs";
import {
  bytesToHex,
  equalBytes,
  hexToBytes,
  sha256,
  sha256Sync,
  utf8
} from "./chunk-ICYUPG2X.mjs";

// packages/authority/src/codec.ts
function check(condition, code) {
  if (!condition) throw Object.assign(new Error(code), { code });
}
function hex(value, length = 32) {
  check(typeof value === "string" && new RegExp(`^[0-9a-f]{${length * 2}}$`, "u").test(value), "AUTHORITY_HEX_INVALID");
}
function normalized(value, depth = 0) {
  check(depth < 32, "RECORD_DEPTH_LIMIT");
  if (value instanceof Uint8Array) return { $bytes: bytesToHex(value) };
  if (typeof value === "bigint") return { $integer: value.toString() };
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    check(Number.isSafeInteger(value), "RECORD_INTEGER_INVALID");
    return value;
  }
  if (Array.isArray(value)) return value.map((item) => normalized(item, depth + 1));
  check(value !== null && typeof value === "object" && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null), "RECORD_INVALID");
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, normalized(value[key], depth + 1)]));
}
function encodeRecord(value) {
  const bytes = new TextEncoder().encode(JSON.stringify(normalized(value)));
  check(bytes.length <= 32 * 1024 * 1024, "RECORD_BYTES_LIMIT");
  return bytes;
}
function decodeRecord(bytes) {
  check(bytes.length <= 32 * 1024 * 1024, "RECORD_BYTES_LIMIT");
  const value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes), (_key, item) => {
    if (item !== null && typeof item === "object" && !Array.isArray(item)) {
      const record = item;
      if (Object.keys(record).length === 1 && typeof record.$bytes === "string") {
        check(/^(?:[0-9a-f]{2})*$/u.test(record.$bytes), "RECORD_BYTES_INVALID");
        return hexToBytes(record.$bytes);
      }
      if (Object.keys(record).length === 1 && typeof record.$integer === "string") {
        check(/^-?(?:0|[1-9][0-9]*)$/u.test(record.$integer), "RECORD_INTEGER_INVALID");
        return BigInt(record.$integer);
      }
    }
    return item;
  });
  check(equalRecord(value, decodeUncanonical(bytes)), "RECORD_INVALID");
  check(equalBytes(encodeRecord(value), bytes), "RECORD_NOT_CANONICAL");
  return value;
}
function decodeUncanonical(bytes) {
  return JSON.parse(new TextDecoder().decode(bytes));
}
function equalRecord(a, b) {
  return equalBytes(encodeRecord(a), encodeRecord(b));
}
async function recordDigest(value) {
  return bytesToHex(await sha256(encodeRecord(value)));
}
function signedBytes(domain, payload) {
  return encodeRecord(["chronolog/authored/v1", domain, payload]);
}
async function signRecord(domain, payload, identity) {
  hex(identity.publicKey);
  const captured = structuredClone(payload);
  const signature = bytesToHex(new Uint8Array(await crypto.subtle.sign("Ed25519", identity.privateKey, Uint8Array.from(signedBytes(domain, captured)).buffer)));
  const result = { payload: captured, signer: identity.publicKey, signature };
  await verifyRecord(domain, result, identity.publicKey);
  return result;
}
async function verifyRecord(domain, signed, expectedSigner) {
  hex(signed.signer);
  hex(signed.signature, 64);
  check(expectedSigner === void 0 || signed.signer === expectedSigner, "AUTHORITY_SIGNER_MISMATCH");
  const key = await importEd25519PublicKey(hexToBytes(signed.signer));
  check(await crypto.subtle.verify("Ed25519", key, Uint8Array.from(hexToBytes(signed.signature)).buffer, Uint8Array.from(signedBytes(domain, signed.payload)).buffer), "AUTHORITY_SIGNATURE_INVALID");
}
async function createSigningIdentity() {
  const pair = await generateEd25519KeyPair();
  return { publicKey: bytesToHex(pair.publicKeyBytes), privateKey: pair.privateKey };
}
async function exportSigningIdentity(identity) {
  return { publicKey: identity.publicKey, privateKey: bytesToHex(await exportEd25519PrivateKey(identity.privateKey)) };
}
async function importSigningIdentity(value) {
  hex(value.publicKey);
  return { publicKey: value.publicKey, privateKey: await importEd25519PrivateKey(hexToBytes(value.privateKey)) };
}

// packages/authority/src/definition.ts
function isArray(value) {
  return Array.isArray(value);
}
function object(value, keys) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), "APPLICATION_DESCRIPTION_INVALID");
}
function parseApplicationInput(schema, value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  const visit = (spec, item, path) => {
    const invalid = () => {
      throw new Error(`APPLICATION_INPUT_INVALID:${path}`);
    };
    if ("anyOf" in spec) {
      for (const option of spec.anyOf) {
        try {
          visit(option, item, path);
          return;
        } catch {
        }
      }
      invalid();
    } else if (spec.type === "null") {
      if (item !== null) invalid();
    } else if (spec.type === "boolean") {
      if (typeof item !== "boolean") invalid();
    } else if (spec.type === "string") {
      if (typeof item !== "string") return invalid();
      const length = [...item].length;
      if (length < (spec.minLength ?? 0) || length > (spec.maxLength ?? 16384) || spec.enum !== void 0 && !spec.enum.includes(item)) invalid();
    } else if (spec.type === "number" || spec.type === "integer") {
      if (typeof item !== "number" || spec.type === "integer" && !Number.isSafeInteger(item) || item < (spec.minimum ?? -Infinity) || item > (spec.maximum ?? Infinity)) invalid();
    } else if (spec.type === "array") {
      if (!Array.isArray(item) || item.length < (spec.minItems ?? 0) || item.length > (spec.maxItems ?? 4096)) return invalid();
      const items = item;
      items.forEach((child, index) => visit(spec.items, child, `${path}[${index}]`));
    } else if (spec.type === "object") {
      if (item === null || typeof item !== "object" || Array.isArray(item)) return invalid();
      const object2 = item;
      for (const name of spec.required ?? []) if (!Object.hasOwn(object2, name)) invalid();
      for (const [name, child] of Object.entries(object2)) {
        if (!Object.hasOwn(spec.properties, name)) invalid();
        visit(spec.properties[name], child, `${path}.${name}`);
      }
    }
  };
  visit(schema, copy, "$");
  return freeze(copy);
}
function checkedApplicationInputSchema(value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  let nodes = 0;
  const visit = (schema, depth) => {
    if (++nodes > 256 || depth > 16 || schema === null || typeof schema !== "object" || Array.isArray(schema)) throw new Error("APPLICATION_SCHEMA_INVALID");
    const keys = /* @__PURE__ */ new Set(["description"]);
    const allow = (...names) => {
      for (const name of names) keys.add(name);
    };
    const bound = (value2, max) => {
      if (value2 !== void 0 && (!Number.isSafeInteger(value2) || value2 < 0 || value2 > max)) throw new Error("APPLICATION_SCHEMA_INVALID");
    };
    if (schema.description !== void 0 && typeof schema.description !== "string") throw new Error("APPLICATION_SCHEMA_INVALID");
    if ("anyOf" in schema) {
      allow("anyOf");
      if (!Array.isArray(schema.anyOf) || schema.anyOf.length < 1 || schema.anyOf.length > 16) throw new Error("APPLICATION_SCHEMA_INVALID");
      const alternatives = schema.anyOf;
      alternatives.forEach((option) => visit(option, depth + 1));
    } else {
      allow("type");
      switch (schema.type) {
        case "string":
          allow("minLength", "maxLength", "enum");
          bound(schema.minLength, 16384);
          bound(schema.maxLength, 16384);
          if ((schema.minLength ?? 0) > (schema.maxLength ?? 16384) || schema.enum !== void 0 && (!Array.isArray(schema.enum) || schema.enum.length === 0 || schema.enum.length > 256 || schema.enum.some((item) => typeof item !== "string"))) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "number":
        case "integer":
          allow("minimum", "maximum");
          if ([schema.minimum, schema.maximum].some((value2) => value2 !== void 0 && !Number.isFinite(value2)) || (schema.minimum ?? -Infinity) > (schema.maximum ?? Infinity)) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "boolean":
        case "null":
          break;
        case "array":
          allow("items", "minItems", "maxItems");
          bound(schema.minItems, 4096);
          bound(schema.maxItems, 4096);
          if ((schema.minItems ?? 0) > (schema.maxItems ?? 4096)) throw new Error("APPLICATION_SCHEMA_INVALID");
          visit(schema.items, depth + 1);
          break;
        case "object":
          allow("properties", "required", "additionalProperties");
          if (schema.properties === null || typeof schema.properties !== "object" || Array.isArray(schema.properties) || schema.additionalProperties !== void 0 && schema.additionalProperties !== false) throw new Error("APPLICATION_SCHEMA_INVALID");
          for (const child of Object.values(schema.properties)) visit(child, depth + 1);
          if (schema.required !== void 0 && (!Array.isArray(schema.required) || schema.required.some((name) => typeof name !== "string" || !Object.hasOwn(schema.properties, name)) || new Set(schema.required).size !== schema.required.length)) {
            throw new Error("APPLICATION_SCHEMA_INVALID");
          }
          Object.assign(schema, { additionalProperties: false });
          break;
        default:
          throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
      }
    }
    if (Object.keys(schema).some((key) => !keys.has(key))) throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
  };
  visit(copy, 0);
  return freeze(copy);
}
function freeze(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
function validateApplicationDescription(value) {
  const bytes = descriptionJson(value);
  check(new TextEncoder().encode(bytes).length <= 262144, "APPLICATION_DESCRIPTION_TOO_LARGE");
  const copy = JSON.parse(bytes);
  object(copy, ["id", "version", "commands", "queries"]);
  for (const text of [copy.id, copy.version]) check(typeof text === "string" && /^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(text), "APPLICATION_DEFINITION_ID_INVALID");
  for (const entries of [copy.commands, copy.queries]) {
    check(isArray(entries) && entries.length <= 128, "APPLICATION_DEFINITION_TOO_LARGE");
    let previous = "";
    for (const entry of entries) {
      object(entry, ["name", "description", "input"]);
      check(typeof entry.name === "string" && /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(entry.name) && !["__proto__", "constructor", "prototype"].includes(entry.name) && entry.name > previous, "APPLICATION_DEFINITION_NAME_INVALID");
      previous = entry.name;
      check(typeof entry.description === "string" && entry.description.length <= 4096, "APPLICATION_DESCRIPTION_INVALID");
      const checked = checkedApplicationInputSchema(entry.input);
      check(canonicalEventPayload(entry.input) === canonicalEventPayload(checked), "APPLICATION_SCHEMA_NOT_CANONICAL");
    }
  }
  return freeze(copy);
}
async function applicationDescriptionDigest(value) {
  const description = validateApplicationDescription(value);
  return recordDigest(["application-description/v1", descriptionJson(description)]);
}
function descriptionJson(value) {
  return canonicalJson(value, { maxBytes: 262144, maxNodes: 65536, maxDepth: 32 });
}

// packages/authority/src/finality-v2.ts
async function policyScopeId(logId, entry) {
  return recordDigest(["chronolog/finality-scope/v2", logId, entry.effectiveAfterMs, entry.policy]);
}
function computeIncludedSetDigest(opIds) {
  const sorted = [...new Set(opIds)].sort();
  return bytesToHex(sha256Sync(utf8(JSON.stringify(sorted))));
}
async function signFinalityCheckpoint(payload, signer) {
  return signRecord("chronolog/finality-checkpoint/v2", payload, signer);
}
function parseFinalitySchedule(raw) {
  if (raw === null || raw === void 0) return [{ effectiveAfterMs: -1n, policy: { kind: "none" } }];
  check(typeof raw === "object" && !Array.isArray(raw) && Array.isArray(raw.schedule), "FINALITY_SCHEDULE_INVALID");
  const list = raw.schedule;
  check(list.length > 0, "FINALITY_SCHEDULE_EMPTY");
  const out = [];
  let prev = -2n;
  for (const item of list) {
    check(item !== null && typeof item === "object" && !Array.isArray(item), "FINALITY_ENTRY_INVALID");
    const rec = item;
    const after = typeof rec.effectiveAfterMs === "bigint" ? rec.effectiveAfterMs : typeof rec.effectiveAfterMs === "number" && Number.isSafeInteger(rec.effectiveAfterMs) ? BigInt(rec.effectiveAfterMs) : (() => {
      throw new Error("FINALITY_ACTIVATION_INVALID");
    })();
    check(after > prev, "FINALITY_ACTIVATION_NOT_MONOTONIC");
    prev = after;
    out.push({ effectiveAfterMs: after, policy: rec.policy });
  }
  return out;
}
async function verifyAttestationForPolicy(policy, checkpoint, blockchainVerifier) {
  if (policy.kind === "none") return false;
  if (policy.kind === "blockchain-anchor") {
    if (checkpoint.attestation.kind !== "blockchain" || blockchainVerifier === void 0) return false;
    return await blockchainVerifier(policy, checkpoint);
  }
  if (checkpoint.attestation.kind !== "signatures") return false;
  const allowed = policy.kind === "signed-frontier" ? [policy.signer] : policy.validators;
  const threshold = policy.kind === "signed-frontier" ? 1 : policy.threshold;
  const validSigners = /* @__PURE__ */ new Set();
  for (const sig of checkpoint.attestation.signatures) {
    if (!allowed.includes(sig.signer)) continue;
    try {
      await verifyRecord("chronolog/finality-checkpoint/v2", sig, sig.signer);
      if (await recordDigest(sig.payload) === await recordDigest(checkpoint.payload)) {
        validSigners.add(sig.signer);
      }
    } catch {
    }
  }
  return validSigners.size >= threshold;
}
async function verifyFinalityV2(options) {
  hex(options.logId);
  const scopeEntries = await Promise.all(
    options.schedule.map(async (entry, index) => ({
      index,
      entry,
      scopeId: await policyScopeId(options.logId, entry)
    }))
  );
  const byScope = new Map(scopeEntries.map((s) => [s.scopeId, s]));
  const sorted = [...options.checkpoints].sort(
    (a, b) => a.payload.closedThroughMs < b.payload.closedThroughMs ? -1 : a.payload.closedThroughMs > b.payload.closedThroughMs ? 1 : 0
  );
  const verifiedCheckpoints = [];
  const includedOpIds = /* @__PURE__ */ new Set();
  let highestClosed = null;
  const closedByScopeIndex = /* @__PURE__ */ new Map();
  for (const cp of sorted) {
    const p = cp.payload;
    if (p.logId !== options.logId) continue;
    const scope = byScope.get(p.policyScopeId);
    if (scope === void 0) continue;
    if (scope.entry.policy.kind === "none") continue;
    if (p.closedThroughMs < scope.entry.effectiveAfterMs) continue;
    if (scope.index > 0) {
      const prev = scopeEntries[scope.index - 1];
      if (prev.entry.policy.kind !== "none") {
        const prevClosed = closedByScopeIndex.get(prev.index);
        if (prevClosed === void 0 || prevClosed < scope.entry.effectiveAfterMs) {
          continue;
        }
      }
    }
    const ok = await verifyAttestationForPolicy(scope.entry.policy, cp, options.blockchainVerifier);
    if (!ok) continue;
    for (const inc of p.inclusions) {
      includedOpIds.add(inc.opId);
    }
    const prevScopeClosed = closedByScopeIndex.get(scope.index);
    if (prevScopeClosed === void 0 || p.closedThroughMs > prevScopeClosed) {
      closedByScopeIndex.set(scope.index, p.closedThroughMs);
    }
    if (highestClosed === null || p.closedThroughMs > highestClosed) {
      highestClosed = p.closedThroughMs;
    }
    verifiedCheckpoints.push(cp);
  }
  const excludedOpIds = /* @__PURE__ */ new Set();
  if (highestClosed !== null && options.knownOps !== void 0) {
    for (const op of options.knownOps) {
      if (op.authorTimestampMs <= highestClosed && !includedOpIds.has(op.opId)) {
        excludedOpIds.add(op.opId);
      }
    }
  }
  return {
    closedThroughMs: highestClosed,
    includedOpIds,
    excludedOpIds,
    latestCheckpoint: verifiedCheckpoints.at(-1) ?? null,
    verifiedCheckpoints
  };
}
async function signHostAttestationV2(payload, hostIdentity) {
  const msg = utf8(canonicalEventPayload(["chronolog/host-attestation/v1", payload]));
  const sig = new Uint8Array(await crypto.subtle.sign("Ed25519", hostIdentity.privateKey, Uint8Array.from(msg).buffer));
  return { payload: structuredClone(payload), signature: bytesToHex(sig) };
}
async function verifyHostAttestationV2(attestation, hostPublicKeyHex) {
  if (!/^[0-9a-f]{64}$/u.test(hostPublicKeyHex) || !/^[0-9a-f]{128}$/u.test(attestation.signature)) return false;
  const key = await crypto.subtle.importKey("raw", Uint8Array.from(hexToBytes(hostPublicKeyHex)).buffer, "Ed25519", false, ["verify"]);
  const msg = utf8(canonicalEventPayload(["chronolog/host-attestation/v1", attestation.payload]));
  return crypto.subtle.verify("Ed25519", key, Uint8Array.from(hexToBytes(attestation.signature)).buffer, Uint8Array.from(msg).buffer);
}

// packages/peer-session/src/definition.ts
function defineCommand(options) {
  const input = checkedApplicationInputSchema(options.input);
  if (typeof options.description !== "string" || options.description.length > 4096 || typeof options.prepare !== "function") {
    throw new Error("APPLICATION_COMMAND_INVALID");
  }
  return Object.freeze({
    description: options.description,
    input,
    prepare(value) {
      const validated = parseApplicationInput(input, value);
      const prepared = options.prepare(validated);
      const list = Array.isArray(prepared) ? prepared : [prepared];
      return list.map((update) => ({
        topic: update.topic,
        input: normalizeJsonValue(update.input)
      }));
    }
  });
}
function defineQuery(options) {
  const input = checkedApplicationInputSchema(options.input);
  if (typeof options.description !== "string" || options.description.length > 4096 || typeof options.read !== "function") {
    throw new Error("APPLICATION_QUERY_INVALID");
  }
  return Object.freeze({
    description: options.description,
    input,
    read(view, value) {
      return options.read(view, parseApplicationInput(input, value));
    }
  });
}
function defineApplication(definition) {
  for (const value of [definition.id, definition.version]) {
    if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(value)) throw new Error("APPLICATION_DEFINITION_ID_INVALID");
  }
  for (const entries of [definition.commands, definition.queries]) {
    const names = Object.keys(entries);
    if (names.length > 128) throw new Error("APPLICATION_DEFINITION_TOO_LARGE");
    for (const name of names) {
      if (!/^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(name) || ["__proto__", "constructor", "prototype"].includes(name)) {
        throw new Error("APPLICATION_DEFINITION_NAME_INVALID");
      }
      checkedApplicationInputSchema(entries[name].input);
    }
  }
  return Object.freeze({ ...definition, commands: Object.freeze({ ...definition.commands }), queries: Object.freeze({ ...definition.queries }) });
}
function describeApplication(definition) {
  const describe = (entries) => Object.keys(entries).sort().map((name) => ({ name, description: entries[name].description, input: entries[name].input }));
  return validateApplicationDescription({ id: definition.id, version: definition.version, commands: describe(definition.commands), queries: describe(definition.queries) });
}
async function applicationDefinitionDigest(definition) {
  return applicationDescriptionDigest(describeApplication(definition));
}

// packages/peer-session/src/content-bytes.ts
var CONTENT_CHUNK_BYTES = 65536;
var MAX_CONTENT_BYTES = 128 * 1024 * 1024;
var MAX_BLOB_BYTES = 16 * 1024 * 1024;
var MAX_BLOB_CHUNKS = MAX_BLOB_BYTES / CONTENT_CHUNK_BYTES;
async function putContentBytes(content, bytes, options = {}) {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength > MAX_CONTENT_BYTES) throw new Error("CONTENT_RANGE_INVALID");
  const signal = options.signal ?? new AbortController().signal;
  signal.throwIfAborted();
  const staging = content.stage({ bytes: bytes.byteLength, ...options.mediaType === void 0 ? {} : { mediaType: options.mediaType } });
  let upload;
  try {
    upload = await awaitOwnedTask(signal, () => staging);
    for (let offset = 0; offset < bytes.byteLength; offset += CONTENT_CHUNK_BYTES) {
      signal.throwIfAborted();
      const chunk = Uint8Array.from(bytes.subarray(offset, offset + CONTENT_CHUNK_BYTES));
      await awaitOwnedTask(signal, () => upload.write(offset / CONTENT_CHUNK_BYTES, chunk));
    }
    const reference = await awaitOwnedTask(signal, () => upload.commit());
    signal.throwIfAborted();
    return reference;
  } catch (error) {
    void staging.then((value) => value.discard()).catch(() => void 0);
    throw error;
  }
}
async function readContentBytes(content, reference, options) {
  if (!Number.isSafeInteger(options?.maxBytes) || options.maxBytes < 0 || options.maxBytes > MAX_CONTENT_BYTES) throw new Error("CONTENT_READ_LIMIT_INVALID");
  if (reference === null || typeof reference !== "object" || !Number.isSafeInteger(reference.bytes) || reference.bytes < 0 || reference.bytes > MAX_CONTENT_BYTES) throw new Error("CONTENT_REFERENCE_INVALID");
  if (reference.bytes > options.maxBytes) throw new Error("CONTENT_READ_LIMIT_EXCEEDED");
  options.signal?.throwIfAborted();
  const result = new Uint8Array(reference.bytes);
  const signal = options.signal ?? new AbortController().signal;
  const iterator = content.read({ ...reference }, { signal })[Symbol.asyncIterator]();
  let offset = 0, chunks = 0;
  try {
    for (; ; ) {
      const next = await awaitOwnedTask(signal, () => iterator.next());
      if (next.done) break;
      const chunk = next.value;
      signal.throwIfAborted();
      if (!(chunk instanceof Uint8Array) || chunk.byteLength === 0 || chunk.byteLength > CONTENT_CHUNK_BYTES || ++chunks > MAX_CONTENT_BYTES / CONTENT_CHUNK_BYTES || offset + chunk.byteLength > result.byteLength) throw new Error("CONTENT_CHUNK_SIZE_INVALID");
      result.set(chunk, offset);
      offset += chunk.byteLength;
    }
    signal.throwIfAborted();
    if (offset !== result.byteLength) throw new Error("CONTENT_INCOMPLETE");
    return result;
  } finally {
    void iterator.return?.().catch(() => void 0);
  }
}

export {
  check,
  hex,
  encodeRecord,
  decodeRecord,
  equalRecord,
  recordDigest,
  signRecord,
  verifyRecord,
  createSigningIdentity,
  exportSigningIdentity,
  importSigningIdentity,
  parseApplicationInput,
  checkedApplicationInputSchema,
  validateApplicationDescription,
  applicationDescriptionDigest,
  policyScopeId,
  computeIncludedSetDigest,
  signFinalityCheckpoint,
  parseFinalitySchedule,
  verifyFinalityV2,
  signHostAttestationV2,
  verifyHostAttestationV2,
  defineCommand,
  defineQuery,
  defineApplication,
  describeApplication,
  applicationDefinitionDigest,
  CONTENT_CHUNK_BYTES,
  MAX_CONTENT_BYTES,
  MAX_BLOB_BYTES,
  MAX_BLOB_CHUNKS,
  putContentBytes,
  readContentBytes
};
