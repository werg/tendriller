import {
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
} from "./chunks/chunk-VBSPY5CU.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-DAFLY5U7.mjs";
export {
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
