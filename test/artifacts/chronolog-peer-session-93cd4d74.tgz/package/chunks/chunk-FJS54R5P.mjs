import {
  CanonicalError,
  DEFAULT_DECODE_LIMITS,
  assertCanonicalCbor,
  bytesToHex,
  compareBytes,
  concatBytes,
  encodeCanonicalCbor,
  equalBytes,
  hashDomainSync,
  hexToBytes,
  utf8
} from "./chunk-ICYUPG2X.mjs";

// packages/protocol/src/errors.ts
var ProtocolError = class extends Error {
  code;
  details;
  constructor(code, message, details) {
    super(message);
    this.name = "ProtocolError";
    this.code = code;
    this.details = details;
  }
  toJSON() {
    return this.details === void 0 ? { name: this.name, code: this.code, message: this.message } : { name: this.name, code: this.code, message: this.message, details: this.details };
  }
};
function protocolInvariant(condition, code, message, details) {
  if (!condition) throw new ProtocolError(code, message, details);
}

// packages/protocol/src/bytes.ts
function wrap(operation) {
  try {
    return operation();
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
    throw error;
  }
}
function utf82(value) {
  return wrap(() => utf8(value));
}
function bytesToHex2(value) {
  return bytesToHex(value);
}
function hexToBytes2(value) {
  return wrap(() => hexToBytes(value));
}

// packages/protocol/src/cbor.ts
function sharedLimits(limits) {
  return {
    maxBytes: limits.maxBytes ?? DEFAULT_DECODE_LIMITS.maxBytes,
    maxDepth: limits.maxDepth ?? DEFAULT_DECODE_LIMITS.maxDepth,
    maxArrayItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxArrayItems,
    maxMapItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxMapItems,
    maxTextBytes: limits.maxTextBytes ?? DEFAULT_DECODE_LIMITS.maxTextBytes,
    maxBlobBytes: limits.maxByteStringBytes ?? DEFAULT_DECODE_LIMITS.maxBlobBytes
  };
}
function protocolError(error) {
  if (error instanceof ProtocolError) throw error;
  if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
  throw error;
}
function assertCanonicalCbor2(input, limits = {}) {
  try {
    return assertCanonicalCbor(input, sharedLimits(limits));
  } catch (error) {
    return protocolError(error);
  }
}

// packages/protocol/src/primitives.ts
function domainSeparatedBytes(domain, payload) {
  return concatBytes(utf82(domain), Uint8Array.of(0), payload);
}
var ED25519 = { name: "Ed25519" };
function bufferSource(value) {
  return Uint8Array.from(value).buffer;
}
async function generateEd25519KeyPair(extractable = true) {
  const pair = await globalThis.crypto.subtle.generateKey(ED25519, extractable, ["sign", "verify"]);
  const publicKeyBytes = new Uint8Array(await globalThis.crypto.subtle.exportKey("raw", pair.publicKey));
  return { publicKey: pair.publicKey, privateKey: pair.privateKey, publicKeyBytes };
}
async function importEd25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "Ed25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", bufferSource(raw), ED25519, true, ["verify"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 public key");
  }
}
async function importEd25519PrivateKey(pkcs8, extractable = true) {
  try {
    return await globalThis.crypto.subtle.importKey("pkcs8", bufferSource(pkcs8), ED25519, extractable, ["sign"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 private key");
  }
}
async function exportEd25519PrivateKey(privateKey) {
  try {
    return new Uint8Array(await globalThis.crypto.subtle.exportKey("pkcs8", privateKey));
  } catch {
    throw new ProtocolError("INVALID_KEY", "Ed25519 private key is not extractable");
  }
}
async function signDomain(domain, payload, privateKey) {
  try {
    const signature = await globalThis.crypto.subtle.sign(ED25519, privateKey, bufferSource(domainSeparatedBytes(domain, payload)));
    return new Uint8Array(signature);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to sign with Ed25519 key");
  }
}
async function verifyDomain(domain, payload, signature, publicKey) {
  if (signature.length !== 64) return false;
  try {
    const key = publicKey instanceof Uint8Array ? await importEd25519PublicKey(publicKey) : publicKey;
    return await globalThis.crypto.subtle.verify(
      ED25519,
      key,
      bufferSource(signature),
      bufferSource(domainSeparatedBytes(domain, payload))
    );
  } catch {
    return false;
  }
}

// packages/protocol/src/v2.ts
var V2_OP_DOMAIN = "chronolog/op/v1";
var CONTROL_TOPICS = Object.freeze([
  "$reducers",
  "$permissions",
  "$keys",
  "$finality",
  "$publications",
  "$signal_policy"
]);
var CONTROL_TOPIC_SET = new Set(CONTROL_TOPICS);
var HEX32 = /^[0-9a-f]{64}$/u;
var MAX_TOPIC_NAME_BYTES = 128;
var MAX_UPDATES_PER_OP = 64;
var MAX_OP_ID_BYTES = 512;
var MAX_EVENT_BYTES = 16384;
function canonicalJson(payload, limits = { maxBytes: 65536, maxNodes: 8192, maxDepth: 32 }) {
  for (const bound of [limits.maxBytes, limits.maxNodes, limits.maxDepth]) {
    protocolInvariant(Number.isSafeInteger(bound) && bound > 0, "SCHEMA_INVALID", "Invalid JSON limits");
  }
  let nodes = 0;
  const visit = (value, depth) => {
    protocolInvariant(depth <= limits.maxDepth && ++nodes <= limits.maxNodes, "SCHEMA_INVALID", "JSON payload is too complex");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "Numbers must be finite");
      return JSON.stringify(Object.is(value, -0) ? 0 : value);
    }
    if (Array.isArray(value)) {
      protocolInvariant(Reflect.ownKeys(value).length === value.length + 1, "SCHEMA_INVALID", "Arrays cannot carry extra properties");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const desc = Object.getOwnPropertyDescriptor(value, i);
        protocolInvariant(desc !== void 0 && "value" in desc && desc.enumerable === true, "SCHEMA_INVALID", "Arrays require dense elements");
        entries.push(visit(desc.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    protocolInvariant(
      typeof value === "object" && value !== null && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null),
      "SCHEMA_INVALID",
      "Payload must contain JSON values"
    );
    const keys = Object.keys(value).sort();
    protocolInvariant(Reflect.ownKeys(value).length === keys.length, "SCHEMA_INVALID", "Objects require enumerable string keys");
    return `{${keys.map((key) => {
      const desc = Object.getOwnPropertyDescriptor(value, key);
      protocolInvariant("value" in desc, "SCHEMA_INVALID", "Accessors are prohibited");
      return `${JSON.stringify(key)}:${visit(desc.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const encoded = visit(payload, 0);
  protocolInvariant(utf8(encoded).length <= limits.maxBytes, "SCHEMA_INVALID", "JSON payload is too large");
  return encoded;
}
function canonicalEventPayload(payload) {
  return canonicalJson(payload, { maxBytes: MAX_EVENT_BYTES, maxNodes: 4096, maxDepth: 32 });
}
function isControlTopic(topic) {
  return CONTROL_TOPIC_SET.has(topic);
}
function assertValidTopicName(topic) {
  protocolInvariant(
    typeof topic === "string" && /^(?:\$[a-z][a-z0-9_]*|[A-Za-z0-9][A-Za-z0-9._/-]*)$/u.test(topic) && utf8(topic).length <= MAX_TOPIC_NAME_BYTES,
    "SCHEMA_INVALID",
    `Invalid topic name: ${String(topic)}`
  );
}
function normalizeJsonValue(value, limits = {}) {
  const maxDepth = limits.maxDepth ?? 32;
  const maxNodes = limits.maxNodes ?? 16384;
  let nodes = 0;
  const visit = (v, depth) => {
    protocolInvariant(depth <= maxDepth && ++nodes <= maxNodes, "SCHEMA_INVALID", "Value exceeds depth/node limits");
    if (v === null || typeof v === "boolean" || typeof v === "string") return v;
    if (typeof v === "number") {
      protocolInvariant(Number.isFinite(v), "SCHEMA_INVALID", "Non-finite number is prohibited");
      return Object.is(v, -0) ? 0 : v;
    }
    if (Array.isArray(v)) {
      protocolInvariant(Reflect.ownKeys(v).length === v.length + 1, "SCHEMA_INVALID", "Arrays cannot carry extra properties");
      const out2 = [];
      for (let i = 0; i < v.length; i++) {
        const desc = Object.getOwnPropertyDescriptor(v, i);
        protocolInvariant(desc !== void 0 && "value" in desc && desc.enumerable === true, "SCHEMA_INVALID", "Sparse arrays are prohibited");
        out2.push(visit(desc.value, depth + 1));
      }
      return out2;
    }
    protocolInvariant(
      typeof v === "object" && v !== null && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null),
      "SCHEMA_INVALID",
      "Value must be plain JSON data"
    );
    const keys = Object.keys(v).sort();
    protocolInvariant(Reflect.ownKeys(v).length === keys.length, "SCHEMA_INVALID", "Objects require enumerable string keys only");
    const out = {};
    for (const key of keys) {
      const desc = Object.getOwnPropertyDescriptor(v, key);
      protocolInvariant("value" in desc, "SCHEMA_INVALID", "Accessors are prohibited");
      out[key] = visit(desc.value, depth + 1);
    }
    return out;
  };
  return visit(value, 0);
}
function jsonToCbor(value) {
  const normalized = normalizeJsonValue(value);
  const convert = (v) => {
    if (v === null || typeof v === "boolean" || typeof v === "string") return v;
    if (typeof v === "number") {
      if (Number.isSafeInteger(v)) return BigInt(v);
      return /* @__PURE__ */ new Map([["$f", JSON.stringify(v)]]);
    }
    if (Array.isArray(v)) return v.map(convert);
    const entries = Object.keys(v).sort().map((k) => [k, convert(v[k])]);
    return new Map(entries);
  };
  return convert(normalized);
}
function cborToJson(value) {
  const convert = (v) => {
    if (v === null || typeof v === "boolean" || typeof v === "string") return v;
    if (typeof v === "bigint") {
      protocolInvariant(v >= BigInt(Number.MIN_SAFE_INTEGER) && v <= BigInt(Number.MAX_SAFE_INTEGER), "INTEGER_OUT_OF_RANGE", "Integer outside safe JS range");
      return Number(v);
    }
    if (Array.isArray(v)) return v.map(convert);
    if (v instanceof Map) {
      if (v.size === 1 && v.has("$f") && typeof v.get("$f") === "string") {
        const parsed = Number(v.get("$f"));
        protocolInvariant(Number.isFinite(parsed) && !Number.isSafeInteger(parsed), "SCHEMA_INVALID", "Invalid float encoding");
        return parsed;
      }
      const out = {};
      for (const [k, item] of v) {
        protocolInvariant(typeof k === "string", "SCHEMA_INVALID", "JSON map keys must be strings");
        out[k] = convert(item);
      }
      return out;
    }
    throw new ProtocolError("SCHEMA_INVALID", "Unsupported CBOR value in JSON bridge");
  };
  return normalizeJsonValue(convert(value));
}
function encodeCanonicalJsonCbor(value) {
  return encodeCanonicalCbor(jsonToCbor(value));
}
function assertValidReducersConfig(value) {
  const norm = normalizeJsonValue(value);
  protocolInvariant(norm !== null && typeof norm === "object" && !Array.isArray(norm), "SCHEMA_INVALID", "$reducers must be an object");
  const obj = norm;
  const runtime = obj.runtime;
  protocolInvariant(runtime !== null && typeof runtime === "object" && !Array.isArray(runtime), "SCHEMA_INVALID", "$reducers.runtime must be an object");
  const rtObj = runtime;
  protocolInvariant(typeof rtObj.js === "string" && rtObj.js.length > 0 && rtObj.js.length <= 256, "SCHEMA_INVALID", "$reducers.runtime.js invalid");
  protocolInvariant(rtObj.builtins !== null && typeof rtObj.builtins === "object" && !Array.isArray(rtObj.builtins), "SCHEMA_INVALID", "$reducers.runtime.builtins invalid");
  const builtins = {};
  for (const [k, v] of Object.entries(rtObj.builtins)) {
    protocolInvariant(k.startsWith("chronolog:") && typeof v === "string" && v.length > 0 && v.length <= 256, "SCHEMA_INVALID", `Invalid builtin mapping: ${k}`);
    builtins[k] = v;
  }
  protocolInvariant(obj.imports !== null && typeof obj.imports === "object" && !Array.isArray(obj.imports), "SCHEMA_INVALID", "$reducers.imports must be an object");
  const imports = {};
  for (const [spec, ref] of Object.entries(obj.imports)) {
    protocolInvariant(typeof spec === "string" && spec.length > 0 && spec.length <= 256 && !spec.startsWith(".") && !spec.startsWith("/"), "SCHEMA_INVALID", `Invalid import specifier: ${spec}`);
    protocolInvariant(typeof ref === "string" && /^cas:sha256-[0-9a-f]{64}$/u.test(ref), "SCHEMA_INVALID", `Import must pin cas:sha256-<hex>: ${spec}`);
    imports[spec] = ref;
  }
  protocolInvariant(obj.topics !== null && typeof obj.topics === "object" && !Array.isArray(obj.topics), "SCHEMA_INVALID", "$reducers.topics must be an object");
  const topics = {};
  for (const [topicName, rawBinding] of Object.entries(obj.topics)) {
    assertValidTopicName(topicName);
    protocolInvariant(rawBinding !== null && typeof rawBinding === "object" && !Array.isArray(rawBinding), "SCHEMA_INVALID", `Invalid topic binding: ${topicName}`);
    const b = rawBinding;
    protocolInvariant(typeof b.module === "string" && Object.hasOwn(imports, b.module), "SCHEMA_INVALID", `Topic ${topicName} references unknown import`);
    if (b.export !== void 0) protocolInvariant(typeof b.export === "string" && b.export.length > 0 && b.export.length <= 128, "SCHEMA_INVALID", `Invalid export for ${topicName}`);
    topics[topicName] = {
      module: b.module,
      ...b.export === void 0 ? {} : { export: b.export },
      ...b.config === void 0 ? {} : { config: b.config }
    };
  }
  return { runtime: { js: rtObj.js, builtins }, imports, topics };
}
function encodeLogGenesis(genesis) {
  protocolInvariant(genesis.version === 1, "UNSUPPORTED_VERSION", "Genesis version must be 1");
  protocolInvariant(typeof genesis.privateLog === "boolean", "SCHEMA_INVALID", "Genesis privateLog must be boolean");
  protocolInvariant(genesis.salt instanceof Uint8Array && genesis.salt.length >= 16 && genesis.salt.length <= 64, "SCHEMA_INVALID", "Genesis salt must be 16..64 bytes");
  for (const n of [genesis.limits.maxMemoryBytes, genesis.limits.maxTopicStateBytes, genesis.limits.maxUpdatesPerOp]) {
    protocolInvariant(Number.isSafeInteger(n) && n > 0, "SCHEMA_INVALID", "Invalid genesis limits");
  }
  protocolInvariant(Object.hasOwn(genesis.initialTopics, "$reducers"), "SCHEMA_INVALID", "Genesis must include $reducers topic");
  assertValidReducersConfig(genesis.initialTopics.$reducers);
  const topicsMap = /* @__PURE__ */ new Map();
  for (const key of Object.keys(genesis.initialTopics).sort()) {
    assertValidTopicName(key);
    const val = normalizeJsonValue(genesis.initialTopics[key]);
    const encodedTopic = encodeCanonicalJsonCbor(val);
    protocolInvariant(encodedTopic.length <= genesis.limits.maxTopicStateBytes, "SCHEMA_INVALID", `Initial topic ${key} exceeds maxTopicStateBytes`);
    topicsMap.set(key, jsonToCbor(val));
  }
  const map = /* @__PURE__ */ new Map([
    [0n, 1n],
    [1n, genesis.privateLog],
    [2n, topicsMap],
    [3n, /* @__PURE__ */ new Map([
      [0n, BigInt(genesis.limits.maxMemoryBytes)],
      [1n, BigInt(genesis.limits.maxTopicStateBytes)],
      [2n, BigInt(genesis.limits.maxUpdatesPerOp)]
    ])],
    [4n, genesis.salt]
  ]);
  return encodeCanonicalCbor(map);
}
function decodeLogGenesis(bytes) {
  const raw = assertCanonicalCbor(bytes, DEFAULT_DECODE_LIMITS);
  protocolInvariant(raw instanceof Map && raw.size === 5, "SCHEMA_INVALID", "Genesis must be a 5-entry map");
  const map = raw;
  protocolInvariant(map.get(0n) === 1n, "UNSUPPORTED_VERSION", "Unsupported genesis version");
  const privateLog = map.get(1n);
  protocolInvariant(typeof privateLog === "boolean", "SCHEMA_INVALID", "Invalid privateLog");
  const topicsRaw = map.get(2n);
  protocolInvariant(topicsRaw instanceof Map, "SCHEMA_INVALID", "Invalid initialTopics");
  const initialTopics = {};
  for (const [k, v] of topicsRaw) {
    protocolInvariant(typeof k === "string", "SCHEMA_INVALID", "Topic name must be string");
    assertValidTopicName(k);
    initialTopics[k] = cborToJson(v);
  }
  const limitsRaw = map.get(3n);
  protocolInvariant(limitsRaw instanceof Map && limitsRaw.size === 3, "SCHEMA_INVALID", "Invalid genesis limits");
  const limitsMap = limitsRaw;
  const num = (v) => {
    protocolInvariant(typeof v === "bigint" && v > 0n && v <= BigInt(Number.MAX_SAFE_INTEGER), "SCHEMA_INVALID", "Invalid limit");
    return Number(v);
  };
  const salt = map.get(4n);
  protocolInvariant(salt instanceof Uint8Array && salt.length >= 16 && salt.length <= 64, "SCHEMA_INVALID", "Invalid genesis salt");
  const genesis = {
    version: 1,
    privateLog,
    initialTopics,
    limits: {
      maxMemoryBytes: num(limitsMap.get(0n)),
      maxTopicStateBytes: num(limitsMap.get(1n)),
      maxUpdatesPerOp: num(limitsMap.get(2n))
    },
    salt: salt.slice()
  };
  protocolInvariant(equalBytes(encodeLogGenesis(genesis), bytes), "CBOR_NON_CANONICAL", "Genesis bytes not canonical");
  return genesis;
}
function genesisLogId(genesis) {
  const bytes = genesis instanceof Uint8Array ? genesis : encodeLogGenesis(genesis);
  return hashDomainSync("genesis", bytes);
}
var MAX_ASSUMPTIONS_PER_OP = 32;
function normalizeAssumptionsConfig(raw) {
  protocolInvariant(raw !== null && typeof raw === "object" && !Array.isArray(raw), "SCHEMA_INVALID", "assumptions must be an object");
  const obj = raw;
  protocolInvariant(Array.isArray(obj.checks) && obj.checks.length > 0 && obj.checks.length <= MAX_ASSUMPTIONS_PER_OP, "SCHEMA_INVALID", "assumptions.checks must be non-empty bounded array");
  if (obj.onFailed !== void 0) {
    protocolInvariant(obj.onFailed === "reject" || obj.onFailed === "record_conflict", "SCHEMA_INVALID", "Invalid assumptions.onFailed");
  }
  const checks = obj.checks.map((item) => {
    protocolInvariant(item !== null && typeof item === "object" && !Array.isArray(item), "SCHEMA_INVALID", "Invalid assumption check");
    const rec = item;
    if (rec.kind === "op_accepted" || rec.kind === "op_rejected") {
      protocolInvariant(typeof rec.opId === "string" && HEX32.test(rec.opId), "SCHEMA_INVALID", "Invalid assumption opId");
      return { kind: rec.kind, opId: rec.opId };
    }
    if (rec.kind === "topic_revision") {
      protocolInvariant(typeof rec.topic === "string", "SCHEMA_INVALID", "Invalid assumption topic");
      assertValidTopicName(rec.topic);
      protocolInvariant(rec.lastOpId === null || typeof rec.lastOpId === "string" && HEX32.test(rec.lastOpId), "SCHEMA_INVALID", "Invalid assumption lastOpId");
      return { kind: "topic_revision", topic: rec.topic, lastOpId: rec.lastOpId };
    }
    if (rec.kind === "query_match") {
      protocolInvariant(typeof rec.topic === "string", "SCHEMA_INVALID", "Invalid assumption topic");
      assertValidTopicName(rec.topic);
      return {
        kind: "query_match",
        topic: rec.topic,
        query: normalizeJsonValue(rec.query ?? null),
        expect: normalizeJsonValue(rec.expect ?? null)
      };
    }
    throw new ProtocolError("SCHEMA_INVALID", `Unknown assumption kind: ${String(rec.kind)}`);
  });
  return {
    checks,
    ...obj.onFailed === void 0 || obj.onFailed === "reject" ? {} : { onFailed: obj.onFailed }
  };
}
function encodeOperationCore(core) {
  protocolInvariant(core.version === 1, "UNSUPPORTED_VERSION", "Operation version must be 1");
  protocolInvariant(core.logId instanceof Uint8Array && core.logId.length === 32, "SCHEMA_INVALID", "logId must be 32 bytes");
  protocolInvariant(core.author instanceof Uint8Array && core.author.length === 32, "SCHEMA_INVALID", "author must be 32 bytes");
  protocolInvariant(
    typeof core.operationId === "string" && core.operationId.length > 0 && utf8(core.operationId).length <= MAX_OP_ID_BYTES && [...core.operationId].every((c) => c.charCodeAt(0) >= 32),
    "SCHEMA_INVALID",
    "Invalid operationId"
  );
  protocolInvariant(core.authorTimestampMs >= 0n && core.authorTimestampMs <= (1n << 63n) - 1n, "INTEGER_OUT_OF_RANGE", "Invalid authorTimestampMs");
  protocolInvariant(core.nonce instanceof Uint8Array && core.nonce.length >= 16 && core.nonce.length <= 64, "SCHEMA_INVALID", "Invalid nonce");
  protocolInvariant(core.visibility === "public" || core.visibility === "encrypted", "SCHEMA_INVALID", "Invalid visibility");
  protocolInvariant(Array.isArray(core.updates) && core.updates.length > 0 && core.updates.length <= MAX_UPDATES_PER_OP, "SCHEMA_INVALID", "Invalid updates list");
  const updatesList = core.updates;
  const encodedUpdates = updatesList.map((u) => {
    assertValidTopicName(u.topic);
    return [u.topic, jsonToCbor(normalizeJsonValue(u.input))];
  });
  const map = /* @__PURE__ */ new Map([
    [0n, 1n],
    [1n, core.logId],
    [2n, core.author],
    [3n, core.operationId],
    [4n, core.authorTimestampMs],
    [5n, core.nonce],
    [6n, core.visibility === "public" ? 0n : 1n],
    [7n, encodedUpdates]
  ]);
  if (core.assumptions !== void 0) {
    const norm = normalizeAssumptionsConfig(core.assumptions);
    const encodedAssumptions = {
      checks: norm.checks.map((c) => ({ ...c })),
      ...norm.onFailed === void 0 ? {} : { onFailed: norm.onFailed }
    };
    map.set(8n, jsonToCbor(encodedAssumptions));
  }
  return encodeCanonicalCbor(map);
}
function decodeOperationCore(bytes) {
  const raw = assertCanonicalCbor(bytes, DEFAULT_DECODE_LIMITS);
  protocolInvariant(raw instanceof Map && (raw.size === 8 || raw.size === 9 && raw.has(8n)), "SCHEMA_INVALID", "OperationCore must be an 8- or 9-entry map");
  const map = raw;
  protocolInvariant(map.get(0n) === 1n, "UNSUPPORTED_VERSION", "Unsupported op version");
  const logId = map.get(1n);
  const author = map.get(2n);
  const operationId = map.get(3n);
  const authorTimestampMs = map.get(4n);
  const nonce = map.get(5n);
  const vis = map.get(6n);
  const rawUpdates = map.get(7n);
  protocolInvariant(logId instanceof Uint8Array && logId.length === 32, "SCHEMA_INVALID", "Invalid logId");
  protocolInvariant(author instanceof Uint8Array && author.length === 32, "SCHEMA_INVALID", "Invalid author");
  protocolInvariant(typeof operationId === "string", "SCHEMA_INVALID", "Invalid operationId");
  protocolInvariant(typeof authorTimestampMs === "bigint", "SCHEMA_INVALID", "Invalid authorTimestampMs");
  protocolInvariant(nonce instanceof Uint8Array, "SCHEMA_INVALID", "Invalid nonce");
  protocolInvariant(vis === 0n || vis === 1n, "SCHEMA_INVALID", "Invalid visibility");
  protocolInvariant(Array.isArray(rawUpdates) && rawUpdates.length > 0 && rawUpdates.length <= MAX_UPDATES_PER_OP, "SCHEMA_INVALID", "Invalid updates");
  const updates = rawUpdates.map((item) => {
    protocolInvariant(Array.isArray(item) && item.length === 2 && typeof item[0] === "string", "SCHEMA_INVALID", "Invalid update tuple");
    assertValidTopicName(item[0]);
    return { topic: item[0], input: cborToJson(item[1]) };
  });
  const rawAssumptions = map.get(8n);
  const assumptions = rawAssumptions === void 0 ? void 0 : normalizeAssumptionsConfig(cborToJson(rawAssumptions));
  const core = {
    version: 1,
    logId: logId.slice(),
    author: author.slice(),
    operationId,
    authorTimestampMs,
    nonce: nonce.slice(),
    visibility: vis === 0n ? "public" : "encrypted",
    updates,
    ...assumptions === void 0 ? {} : { assumptions }
  };
  protocolInvariant(equalBytes(encodeOperationCore(core), bytes), "CBOR_NON_CANONICAL", "OperationCore bytes not canonical");
  return core;
}
function operationIdDigest(coreOrBytes) {
  const bytes = coreOrBytes instanceof Uint8Array ? coreOrBytes : encodeOperationCore(coreOrBytes);
  return hashDomainSync("op", bytes);
}
async function signOperationCore(core, privateKey) {
  const coreBytes = encodeOperationCore(core);
  const signature = await signDomain(V2_OP_DOMAIN, coreBytes, privateKey);
  return { coreBytes, signature };
}
async function verifySignedOperation(op) {
  const core = decodeOperationCore(op.coreBytes);
  protocolInvariant(op.signature instanceof Uint8Array && op.signature.length === 64, "INVALID_SIGNATURE", "Signature must be 64 bytes");
  const valid = await verifyDomain(V2_OP_DOMAIN, op.coreBytes, op.signature, core.author);
  protocolInvariant(valid, "INVALID_SIGNATURE", "Operation signature verification failed");
  return { core, opId: operationIdDigest(op.coreBytes) };
}
function encodeSignedOperation(op) {
  return encodeCanonicalCbor(/* @__PURE__ */ new Map([
    [0n, op.coreBytes],
    [1n, op.signature]
  ]));
}
function decodeSignedOperation(bytes) {
  const raw = assertCanonicalCbor(bytes, DEFAULT_DECODE_LIMITS);
  protocolInvariant(raw instanceof Map && raw.size === 2, "SCHEMA_INVALID", "SignedOperation invalid");
  const map = raw;
  const coreBytes = map.get(0n), signature = map.get(1n);
  protocolInvariant(coreBytes instanceof Uint8Array && signature instanceof Uint8Array && signature.length === 64, "SCHEMA_INVALID", "SignedOperation fields invalid");
  return { coreBytes: coreBytes.slice(), signature: signature.slice() };
}
var RING_NAME_RE = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/u;
function encodeEncryptedEnvelope(env) {
  protocolInvariant(env.version === 1, "UNSUPPORTED_VERSION", "Envelope version must be 1");
  protocolInvariant(env.logId.length === 32 && env.opId.length === 32 && env.author.length === 32, "SCHEMA_INVALID", "Invalid envelope 32-byte field");
  protocolInvariant(Number.isSafeInteger(env.epoch) && env.epoch >= 0, "SCHEMA_INVALID", "Invalid epoch");
  protocolInvariant(env.nonce.length === 12 && env.ciphertext.length > 0, "SCHEMA_INVALID", "Invalid ciphertext/nonce");
  const map = /* @__PURE__ */ new Map([
    [0n, 1n],
    [1n, env.logId],
    [2n, env.opId],
    [3n, env.author],
    [4n, BigInt(env.epoch)],
    [5n, env.nonce],
    [6n, env.ciphertext]
  ]);
  if (env.ring !== void 0 && env.ring !== "default") {
    protocolInvariant(typeof env.ring === "string" && RING_NAME_RE.test(env.ring), "SCHEMA_INVALID", "Invalid envelope ring name");
    map.set(7n, env.ring);
  }
  return encodeCanonicalCbor(map);
}
function decodeEncryptedEnvelope(bytes) {
  const raw = assertCanonicalCbor(bytes, DEFAULT_DECODE_LIMITS);
  protocolInvariant(raw instanceof Map && (raw.size === 7 || raw.size === 8 && raw.has(7n)), "SCHEMA_INVALID", "Invalid envelope");
  const map = raw;
  protocolInvariant(map.get(0n) === 1n, "SCHEMA_INVALID", "Invalid envelope");
  const logId = map.get(1n), opId = map.get(2n), author = map.get(3n), epoch = map.get(4n), nonce = map.get(5n), ciphertext = map.get(6n);
  protocolInvariant(
    logId instanceof Uint8Array && logId.length === 32 && opId instanceof Uint8Array && opId.length === 32 && author instanceof Uint8Array && author.length === 32 && typeof epoch === "bigint" && epoch >= 0n && epoch <= BigInt(Number.MAX_SAFE_INTEGER) && nonce instanceof Uint8Array && nonce.length === 12 && ciphertext instanceof Uint8Array && ciphertext.length > 0,
    "SCHEMA_INVALID",
    "Invalid envelope fields"
  );
  const rawRing = map.get(7n);
  if (rawRing !== void 0) {
    protocolInvariant(typeof rawRing === "string" && rawRing !== "default" && RING_NAME_RE.test(rawRing), "SCHEMA_INVALID", "Invalid envelope ring");
  }
  return {
    version: 1,
    logId: logId.slice(),
    opId: opId.slice(),
    author: author.slice(),
    epoch: Number(epoch),
    nonce: nonce.slice(),
    ciphertext: ciphertext.slice(),
    ...rawRing === void 0 ? {} : { ring: rawRing }
  };
}
function encryptedEnvelopeDigest(env) {
  const bytes = env instanceof Uint8Array ? env : encodeEncryptedEnvelope(env);
  return hashDomainSync("envelope", bytes);
}
function envelopeAad(logId, opId, author) {
  return encodeCanonicalCbor([logId, opId, author]);
}
function compareOperationOrder(left, right) {
  if (left.authorTimestampMs !== right.authorTimestampMs) return left.authorTimestampMs < right.authorTimestampMs ? -1 : 1;
  const authorCmp = compareBytes(left.author, right.author);
  if (authorCmp !== 0) return authorCmp;
  return compareBytes(left.opId, right.opId);
}
var DEFAULT_RUNTIME_MANIFEST = Object.freeze({
  js: "quickjs-ng@0.32.0",
  builtins: Object.freeze({
    "chronolog:crypto": "crypto@1",
    "chronolog:cas": "cas@1",
    "chronolog:sqlite": "sqlite-cas@1#sha256-bbc4674a5dd1d11962a8227ce5f1118e2e6ed7d00163ea92f1f35781caf46936"
  })
});
var DEFAULT_GENESIS_LIMITS = Object.freeze({
  maxMemoryBytes: 64 * 1024 * 1024,
  maxTopicStateBytes: 4 * 1024 * 1024,
  maxUpdatesPerOp: 16
});

// packages/protocol/src/schema.ts
function integerMap(entries) {
  const result = /* @__PURE__ */ new Map();
  for (const [key, value] of entries) {
    if (value !== void 0) result.set(BigInt(key), value);
  }
  return result;
}

export {
  ProtocolError,
  protocolInvariant,
  utf82 as utf8,
  bytesToHex2 as bytesToHex,
  hexToBytes2 as hexToBytes,
  assertCanonicalCbor2 as assertCanonicalCbor,
  generateEd25519KeyPair,
  importEd25519PublicKey,
  importEd25519PrivateKey,
  exportEd25519PrivateKey,
  integerMap,
  canonicalJson,
  canonicalEventPayload,
  isControlTopic,
  normalizeJsonValue,
  jsonToCbor,
  encodeCanonicalJsonCbor,
  assertValidReducersConfig,
  encodeLogGenesis,
  decodeLogGenesis,
  genesisLogId,
  normalizeAssumptionsConfig,
  decodeOperationCore,
  operationIdDigest,
  signOperationCore,
  verifySignedOperation,
  encodeSignedOperation,
  decodeSignedOperation,
  encodeEncryptedEnvelope,
  decodeEncryptedEnvelope,
  encryptedEnvelopeDigest,
  envelopeAad,
  compareOperationOrder,
  DEFAULT_RUNTIME_MANIFEST,
  DEFAULT_GENESIS_LIMITS
};
