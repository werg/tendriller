import {
  createApplicationBackend
} from "./chunks/chunk-D3KIBW2F.mjs";
import "./chunks/chunk-FJS54R5P.mjs";
import "./chunks/chunk-ICYUPG2X.mjs";
export {
  createApplicationBackend
};
