import { type CasPartition, type ContentAddressedStore } from '../../records/src/index.js';
export declare const MERKLE_PAGE_SIZE = 4096;
export declare const MERKLE_FANOUT = 64;
/**
 * Pure Merkle-paged virtual file backed by ContentAddressedStore.
 * - 4 KiB pages organized in a 64-way Merkle tree (depth 3 covers 1 GiB)
 * - Every interior node stores explicit child links in CAS so cas.reachable([dbRoot]) covers the full DB
 * - Unchanged pages stay untouched; commit() writes only dirty pages + O(log N) interior nodes
 */
export declare class MerklePageFile {
    #private;
    constructor(options: {
        readonly dbRoot: string | null;
        readonly cas: ContentAddressedStore;
        readonly partition: CasPartition;
        readonly onMissingCas: (hash: string) => never;
    });
    get byteLength(): number;
    readInto(offset: number, dest: Uint8Array): boolean;
    writeFrom(offset: number, src: Uint8Array): void;
    truncate(newSize: number): void;
    /** Commit all dirty pages into CAS and return the new 32-byte dbRoot hash. */
    commit(): string;
}
export interface MerkleDbDiff {
    readonly baseRoot: string | null;
    readonly nextRoot: string | null;
    readonly baseByteLength: number;
    readonly nextByteLength: number;
    readonly addedPages: readonly number[];
    readonly removedPages: readonly number[];
    readonly modifiedPages: readonly number[];
    readonly totalChangedPages: number;
}
/**
 * Walk two 64-way Merkle page trees in lockstep, skipping identical subtree hashes in O(1),
 * and return the exact list of added, removed, and modified 4 KiB SQLite page indices.
 */
export declare function diffMerkleDbRoots(cas: Pick<ContentAddressedStore, 'getSync'>, baseRoot: string | null, nextRoot: string | null, partition?: CasPartition | 'any'): MerkleDbDiff;
/**
 * Create a zero-copy in-memory overlay over an existing ContentAddressedStore.
 * Reads fall through to baseCas; writes stay strictly inside the ephemeral overlay Map
 * so speculative SQL branches never mutate persisted CAS storage.
 */
export declare function createOverlayCas(baseCas: ContentAddressedStore): ContentAddressedStore;
