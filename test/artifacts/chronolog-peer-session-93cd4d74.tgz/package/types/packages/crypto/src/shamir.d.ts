/**
 * Pure GF(256) Shamir's Secret Sharing (AES irreducible polynomial x^8 + x^4 + x^3 + x + 1 = 0x11b).
 * Used for threshold social recovery so guardians hold encrypted recovery shares without ever
 * being able to decrypt page content unless threshold shares are combined for a recovering device.
 */
export interface ShamirShare {
    /** Non-zero x-coordinate in 1..255. */
    readonly index: number;
    /** Share payload bytes (same length as original secret). */
    readonly bytes: Uint8Array;
}
/**
 * Split a secret byte array into `totalShares` shares such that any `threshold` shares
 * reconstruct the exact secret, while fewer than `threshold` shares reveal zero information.
 */
export declare function splitSecret(secret: Uint8Array, threshold: number, totalShares: number): ShamirShare[];
/**
 * Reconstruct a secret from `threshold` or more Shamir shares via Lagrange interpolation at x = 0.
 */
export declare function combineShares(shares: readonly ShamirShare[]): Uint8Array;
