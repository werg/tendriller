export declare const STD_CRDT_SOURCE: string;
