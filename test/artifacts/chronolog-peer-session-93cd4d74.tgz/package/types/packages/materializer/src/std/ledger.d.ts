export declare const STD_LEDGER_SOURCE: string;
