import { type ContentAddressedStore } from '../../records/src/index.js';
import { STD_CRDT_SOURCE } from './std/crdt.js';
import { STD_TEXT_SOURCE } from './std/text.js';
import { STD_LEDGER_SOURCE } from './std/ledger.js';
import { STD_WORKFLOW_SOURCE } from './std/workflow.js';
import { STD_FS_SOURCE } from './std/fs.js';
export { STD_CRDT_SOURCE, STD_TEXT_SOURCE, STD_LEDGER_SOURCE, STD_WORKFLOW_SOURCE, STD_FS_SOURCE };
export declare const STD_PERMISSIONS_SOURCE: string;
export declare const STD_KEYS_SOURCE: string;
export declare const STD_FINALITY_SOURCE: string;
export declare const STD_PUBLICATIONS_SOURCE: string;
export declare const STD_RLS_SOURCE: string;
export declare const STD_SQL_SOURCE: string;
export declare const STD_SQLITE_HELPERS_SOURCE: string;
export declare const STANDARD_MODULE_SOURCES: Readonly<Record<string, string>>;
export declare const STANDARD_MODULE_IMPORTS: Readonly<Record<string, string>>;
/** Seed all standard audited ES modules into CAS (public partition) and return their pinned import map entries. */
export declare function seedStandardModules(cas: ContentAddressedStore): Promise<Record<string, string>>;
