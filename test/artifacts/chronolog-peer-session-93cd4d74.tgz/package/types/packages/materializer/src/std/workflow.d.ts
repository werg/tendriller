export declare const STD_WORKFLOW_SOURCE: string;
