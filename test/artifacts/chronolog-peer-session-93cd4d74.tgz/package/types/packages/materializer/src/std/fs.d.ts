export declare const STD_FS_SOURCE: string;
