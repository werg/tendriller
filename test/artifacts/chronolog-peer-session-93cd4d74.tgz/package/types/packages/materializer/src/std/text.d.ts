export declare const STD_TEXT_SOURCE: string;
