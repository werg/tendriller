import { type MerkleDbDiff } from '../../sqlite-cas/src/index.js';
import { ContentAddressedStore, type CasPartition } from '../../records/src/index.js';
import type { JsonValue } from '../../protocol/src/index.js';
import type { SqliteBuiltinDriver, SqliteExecOptions, SqliteExecResult, SqliteQueryResult } from '../../materializer/src/index.js';
export interface TableRowDiff {
    readonly table: string;
    readonly keyColumns: readonly string[];
    readonly inserted: readonly Record<string, JsonValue>[];
    readonly updated: readonly {
        readonly key: Record<string, JsonValue>;
        readonly before: Record<string, JsonValue>;
        readonly after: Record<string, JsonValue>;
    }[];
    readonly deleted: readonly Record<string, JsonValue>[];
}
export interface SqlBranchDiff {
    readonly baseRoot: string | null;
    readonly branchRoot: string | null;
    readonly merkle: MerkleDbDiff;
    readonly tables: readonly TableRowDiff[];
}
export interface SqlBranchProposal {
    readonly topic: string;
    readonly baseRoot: string | null;
    readonly branchRoot: string | null;
    readonly statements: readonly {
        readonly sql: string;
        readonly params: readonly JsonValue[];
    }[];
    readonly preconditions: readonly JsonValue[];
    readonly diff: SqlBranchDiff;
}
export interface SqlBranch {
    readonly topic: string;
    readonly baseRoot: string | null;
    exec(sql: string, params?: readonly JsonValue[], options?: SqliteExecOptions): SqliteExecResult;
    query(sql: string, params?: readonly JsonValue[]): SqliteQueryResult;
    commitBranch(): string;
    diff(): SqlBranchDiff;
    toProposal(options?: {
        readonly withRowGuards?: boolean;
    }): SqlBranchProposal;
    close(): void;
}
/**
 * Open a zero-copy O(1) SQLite branch backed by an in-memory OverlayCas.
 * Mutations stay strictly isolated in RAM, can be diffed against baseRoot by table & row,
 * and can be exported as a guarded proposal for human approval or direct submission.
 */
export declare function openSqlBranch(options: {
    readonly topic: string;
    readonly baseRoot: string | null;
    readonly cas: ContentAddressedStore;
    readonly partition: CasPartition;
    readonly driver: SqliteBuiltinDriver;
    readonly actor: string;
}): SqlBranch;
export interface FederatedSqlSource {
    readonly session: {
        query(name: string, input?: unknown): Promise<{
            readonly value: unknown;
        }>;
    };
    readonly topic: string;
    /** Optional allowlist of tables to mount from this source; defaults to all user tables. */
    readonly tables?: readonly string[];
}
/**
 * Execute a zero-trust read-only SQL query (including JOINs & CTEs) across multiple separate
 * encrypted Chronolog sessions locally without sharing encryption keys or exposing data to any host.
 * Each source's tables are mounted as "<alias>__<table>" in an ephemeral read-only sqlite-cas workspace.
 */
export declare function queryFederatedSql(sources: Readonly<Record<string, FederatedSqlSource>>, sql: string, params?: readonly JsonValue[], options?: {
    readonly format?: 'rows' | 'objects';
    readonly driver?: SqliteBuiltinDriver;
}): Promise<{
    readonly columns: readonly string[];
    readonly rows: readonly (readonly JsonValue[])[] | readonly Record<string, JsonValue>[];
    readonly mountedTables: readonly string[];
}>;
