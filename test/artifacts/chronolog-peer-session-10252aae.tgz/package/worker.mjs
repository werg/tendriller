import {
  createApplicationOwner,
  createApplicationSession
} from "./chunks/chunk-I2UYFXSE.mjs";
import {
  openApplicationDevice
} from "./chunks/chunk-TFDTSLN6.mjs";
import "./chunks/chunk-62GBUEL5.mjs";
import "./chunks/chunk-OUV4EWTH.mjs";
import {
  openWorkerWebRtcConnection
} from "./chunks/chunk-5IXWYBUE.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-UIQUGP2I.mjs";
import "./chunks/chunk-I5LQHB54.mjs";
import "./chunks/chunk-FBC6LMDF.mjs";
import "./chunks/chunk-5A4YJVOD.mjs";
import "./chunks/chunk-ICYUPG2X.mjs";

// packages/peer-session/src/browser-metadata.ts
var TABLE = "metadata";
var MAX_BYTES = 16 * 1024 * 1024;
var BrowserMetadataStore = class _BrowserMetadataStore {
  #database;
  #closed = false;
  constructor(database) {
    this.#database = database;
    database.onversionchange = () => {
      this.close();
    };
  }
  static open(name) {
    if (typeof indexedDB === "undefined") return Promise.reject(new Error("BROWSER_IDENTITY_STORAGE_UNAVAILABLE"));
    return new Promise((resolve, reject) => {
      let failed = false;
      const request = indexedDB.open(`chronolog-metadata:${name}`, 1);
      request.onupgradeneeded = () => {
        request.result.createObjectStore(TABLE);
      };
      request.onerror = () => {
        reject(request.error ?? new Error("BROWSER_IDENTITY_STORAGE_UNAVAILABLE"));
      };
      request.onblocked = () => {
        failed = true;
        reject(new Error("BROWSER_IDENTITY_STORAGE_BLOCKED"));
      };
      request.onsuccess = () => {
        if (failed) request.result.close();
        else resolve(new _BrowserMetadataStore(request.result));
      };
    });
  }
  get(key) {
    return this.#transaction("readonly", (table) => {
      const request = table.get(key);
      return () => {
        if (request.result === void 0) return null;
        if (!(request.result instanceof Uint8Array) || request.result.length > MAX_BYTES) throw new Error("BROWSER_METADATA_INVALID");
        return request.result.slice();
      };
    });
  }
  put(key, value) {
    this.#validate(key, value);
    const captured = value.slice();
    return this.#transaction("readwrite", (table) => {
      table.put(captured, key);
      return () => void 0;
    });
  }
  initialize(input) {
    const entries = input.map(({ key, value }) => {
      this.#validate(key, value);
      return { key, value: value.slice() };
    });
    if (entries.length === 0 || entries.length > 8 || new Set(entries.map((entry) => entry.key)).size !== entries.length) {
      return Promise.reject(new Error("BROWSER_METADATA_INITIALIZATION_INVALID"));
    }
    return this.#transaction("readwrite", (table) => {
      let remaining = entries.length, present = false;
      for (const entry of entries) {
        const request = table.get(entry.key);
        request.onsuccess = () => {
          present ||= request.result !== void 0;
          if (--remaining === 0 && !present) for (const candidate of entries) table.add(candidate.value, candidate.key);
        };
      }
      return () => void 0;
    });
  }
  compareAndSwap(key, expected, value) {
    this.#validate(key, value);
    const before = expected?.slice() ?? null, after = value.slice();
    return this.#transaction("readwrite", (table) => {
      let written = false;
      const request = table.get(key);
      request.onsuccess = () => {
        const current = request.result;
        if (before === null ? current === void 0 : current instanceof Uint8Array && before.length === current.length && before.every((byte, index) => byte === current[index])) {
          table.put(after, key);
          written = true;
        }
      };
      return () => written;
    });
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#database.close();
    }
  }
  #validate(key, value) {
    if (!key || key.length > 4096 || value.length > MAX_BYTES) throw new Error("BROWSER_METADATA_LIMIT");
  }
  #transaction(mode, enqueue) {
    if (this.#closed) return Promise.reject(new Error("BROWSER_METADATA_CLOSED"));
    return new Promise((resolve, reject) => {
      const transaction = mode === "readonly" ? this.#database.transaction(TABLE, mode) : this.#database.transaction(TABLE, mode, { durability: "strict" });
      const value = enqueue(transaction.objectStore(TABLE));
      transaction.oncomplete = () => {
        try {
          resolve(value());
        } catch (error) {
          reject(error);
        }
      };
      transaction.onabort = () => {
        reject(transaction.error ?? new Error("BROWSER_METADATA_ABORTED"));
      };
      transaction.onerror = () => {
      };
    });
  }
};

// packages/peer-session/src/browser-device.ts
async function openBrowserDevice(options) {
  if (typeof document !== "undefined") throw new Error("BROWSER_PEER_WORKER_REQUIRED");
  if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/u.test(options.name)) throw new Error("BROWSER_STORAGE_NAME_INVALID");
  const metadata = await BrowserMetadataStore.open(options.name);
  try {
    return await openApplicationDevice({
      store: metadata,
      ...options.create === void 0 ? {} : { create: options.create },
      async openStorage() {
        const { IndexedDbBytesStore } = await import("./chunks/indexeddb-bytes-store-7576VZGD.mjs");
        const store = await IndexedDbBytesStore.open(options.name, { create: true });
        return {
          store,
          close: () => store.close()
        };
      },
      close: () => {
        metadata.close();
      }
    });
  } catch (error) {
    metadata.close();
    throw error;
  }
}

// packages/peer-session/src/worker.ts
async function probeBrowserCapabilities(...args) {
  return (await import("./chunks/browser-capabilities-4B2A2AYX.mjs")).probeBrowserCapabilities(...args);
}
export {
  createApplicationOwner,
  createApplicationSession,
  openBrowserDevice,
  openWorkerWebRtcConnection,
  probeBrowserCapabilities
};
