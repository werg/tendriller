import {
  createApplicationBackend
} from "./chunks/chunk-UIQUGP2I.mjs";
import "./chunks/chunk-5A4YJVOD.mjs";
import "./chunks/chunk-ICYUPG2X.mjs";
export {
  createApplicationBackend
};
