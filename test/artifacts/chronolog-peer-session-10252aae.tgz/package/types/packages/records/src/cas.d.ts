import { type BytesStore, type BytesStoreEntry } from './bytes-store.js';
export type CasPartition = 'public' | 'private';
export interface CasNode {
    readonly bytes: Uint8Array;
    readonly links: readonly string[];
}
export interface CasOptions {
    readonly store: BytesStore;
    readonly prefix?: string;
    readonly maxCacheEntries?: number;
    readonly maxChunkBytes?: number;
}
/**
 * Canonical encoding of an explicit-link CAS DAG node.
 * Node hash = hashDomainSync('cas', canonicalCbor([bytes, sortedUniqueLinkBytes])).
 */
export declare function encodeCasNode(bytes: Uint8Array, links?: readonly string[]): Uint8Array;
export declare function decodeCasNode(encoded: Uint8Array): CasNode;
export declare function hashCasNode(encoded: Uint8Array): string;
export declare function computeCasHash(bytes: Uint8Array, links?: readonly string[]): string;
/**
 * Pure content-addressed DAG store backed by BytesStore.
 * Supports:
 * - Synchronous in-memory cache + staged batch writes during suffix replay
 * - Public vs. private partition isolation (so public control ops never read private chunks)
 * - Exact mark-and-sweep GC over explicit node links
 */
export declare class ContentAddressedStore {
    #private;
    constructor(options: CasOptions);
    /** Preload persisted CAS entries from BytesStore into the in-memory index/cache. */
    preload(): Promise<void>;
    /**
     * Index a single persisted BytesStore entry if it belongs to this CAS prefix.
     * Returns true if the key was a CAS entry (allowing single-pass hydration in ApplicationSession.open).
     */
    indexPersistedEntry(entry: BytesStoreEntry, options?: {
        readonly verifyHash?: boolean;
        readonly preloadCache?: boolean;
    }): boolean;
    /** Begin a staged replay batch: synchronous puts stay in RAM until flushBatch(). */
    beginBatch(): void;
    /** Discard all uncommitted staged writes from the active batch. */
    rollbackBatch(): void;
    /** Persist staged chunks (optionally filtered to a reachable set) to BytesStore in one flush. */
    flushBatch(keepHashes?: ReadonlySet<string>): Promise<void>;
    /** Synchronous put into staged RAM (or cache) for deterministic reducer execution. */
    putSync(bytes: Uint8Array, links?: readonly string[], partition?: CasPartition): string;
    /** Async durable put (for seeding modules, syncing blobs from peers, or outside a batch). */
    put(bytes: Uint8Array, links?: readonly string[], partition?: CasPartition): Promise<string>;
    /** Put raw pre-encoded canonical CAS node bytes (verifying digest matches expectedHash). */
    putRaw(expectedHash: string, encoded: Uint8Array, partition?: CasPartition): Promise<void>;
    /** Batched put for peer/host CAS sync (single putMany per 128 chunks instead of N transactions). */
    putManyVerified(items: readonly {
        readonly hash: string;
        readonly bytes: Uint8Array;
        readonly partition: CasPartition;
    }[]): Promise<number>;
    /** Fault a known-on-disk CAS node back into the synchronous RAM LRU (demand paging for >16 MiB DBs). */
    ensureLoaded(hash: string, allowedPartition?: CasPartition | 'any'): Promise<boolean>;
    /** Synchronous read from staged RAM + LRU cache (respecting partition visibility). */
    getSync(hash: string, allowedPartition?: CasPartition | 'any'): CasNode | null;
    /** Async read checking RAM cache first, then BytesStore (respecting partition visibility). */
    get(hash: string, allowedPartition?: CasPartition | 'any'): Promise<CasNode | null>;
    /** Get raw canonical node bytes for peer replication. */
    getRaw(hash: string, allowedPartition?: CasPartition | 'any'): Promise<Uint8Array | null>;
    hasSync(hash: string, allowedPartition?: CasPartition | 'any'): boolean;
    /** Walk all explicit DAG links reachable from rootHashes (in RAM or durable store). */
    reachable(rootHashes: Iterable<string>): Promise<Set<string>>;
    /** Exact local mark-and-sweep GC preserving everything reachable from rootHashes, deleting in yielding batches. */
    collectGarbage(rootHashes: Iterable<string>): Promise<{
        readonly kept: number;
        readonly deleted: number;
    }>;
    listKnownHashes(partition?: CasPartition): readonly string[];
}
