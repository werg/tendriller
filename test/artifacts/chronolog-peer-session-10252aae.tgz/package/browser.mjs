import {
  APPLICATION_OWNER_PROTOCOL,
  SessionError,
  canonicalJson,
  createAppClient,
  createLiveView,
  createProjection,
  createScopedApplicationTools,
  createViewStore,
  defineProjection,
  forwardSessionEvents,
  submitBatch
} from "./chunks/chunk-62GBUEL5.mjs";
import {
  CONTENT_CHUNK_BYTES,
  MAX_BLOB_BYTES,
  applicationDefinitionDigest,
  defineApplication,
  defineCommand,
  defineQuery,
  describeApplication,
  isPrivateContentReference,
  isPublicBlobReference,
  parseApplicationInput,
  putContentBytes,
  readContentBytes
} from "./chunks/chunk-OUV4EWTH.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import {
  createApplicationBackend
} from "./chunks/chunk-UIQUGP2I.mjs";
import "./chunks/chunk-5A4YJVOD.mjs";
import "./chunks/chunk-ICYUPG2X.mjs";

// packages/peer-session/src/worker-application.ts
var WorkerApplicationOperation = class {
  constructor(id, operationId, session) {
    this.id = id;
    this.operationId = operationId;
    this.session = session;
  }
  id;
  operationId;
  session;
  stored = true;
  inspect() {
    return this.session.request("operation.inspect", [this.id]);
  }
  materialized(options) {
    return this.session.wait(this.id, "materialized", options);
  }
  retained(options) {
    return this.session.wait(this.id, "retained", options);
  }
  finalized(options) {
    return this.session.wait(this.id, "finalized", options);
  }
};
var WorkerApplicationSession = class {
  #endpoint;
  #attachment = crypto.randomUUID();
  #lifetime = new AbortController();
  #pending = /* @__PURE__ */ new Map();
  #statuses = /* @__PURE__ */ new Set();
  #changes = /* @__PURE__ */ new Set();
  #extensions = /* @__PURE__ */ new Set();
  #ownedViews = /* @__PURE__ */ new Set();
  #next = 0;
  #binding;
  #attachmentState = "active";
  #heartbeat;
  #pinging = false;
  #description;
  #status = { canAuthor: false, phase: "ready", database: "idle", connectedPeers: 0, pendingOperations: 0, materializationError: null };
  applicationId = "";
  identity = { publicKey: "" };
  constructor(endpoint) {
    this.#endpoint = endpoint;
    endpoint.addEventListener("message", this.#receive);
    const physical = endpoint;
    physical.addEventListener("close", this.#physicalClose);
    physical.addEventListener("messageerror", this.#physicalClose);
    physical.on?.("close", this.#physicalClose);
    physical.on?.("messageerror", this.#physicalClose);
  }
  #physicalClose = () => {
    this.#detach(Object.assign(new Error("OWNER_UNREACHABLE"), { code: "OWNER_UNREACHABLE" }));
  };
  get signal() {
    return this.#lifetime.signal;
  }
  get status() {
    return { ...this.#status, canAuthor: this.#status.canAuthor && this.#attachmentState === "active" && this.#binding?.capabilities.includes("commands") === true };
  }
  get endpoint() {
    return this.#binding === void 0 ? void 0 : structuredClone(this.#binding);
  }
  get attachmentState() {
    return this.#attachmentState;
  }
  describe() {
    if (this.#description === void 0) throw new Error("ENDPOINT_HANDSHAKE_REQUIRED");
    return structuredClone(this.#description);
  }
  get boundedRequest() {
    const requests = [...this.#pending.values()].filter((request2) => request2.method !== "operation.wait" && request2.method !== "signals.next").sort((a, b) => a.startedAt - b.startedAt);
    const request = requests[0];
    return request === void 0 ? null : { startedAt: request.startedAt, deadline: request.deadline };
  }
  #receive = (event) => {
    const message = event.data;
    if (message?.protocol !== APPLICATION_OWNER_PROTOCOL || message.attachment !== this.#attachment) return;
    if (message.kind === "response") {
      const response = message, pending = this.#pending.get(response.id);
      if (pending === void 0) return;
      this.#pending.delete(response.id);
      clearTimeout(pending.timer);
      pending.cleanup();
      if (response.error !== void 0) pending.reject(Object.assign(new Error(response.error), { code: response.error }));
      else pending.resolve(response.value);
    } else if (message.kind === "notice") {
      const notice = message;
      if (notice.topic === "closed") {
        this.#detach(new Error(String(notice.value)));
        return;
      }
      if (notice.topic === "status") {
        this.#status = notice.value;
        for (const listener of this.#statuses) {
          try {
            listener(this.status);
          } catch {
          }
        }
      }
      if (notice.topic === "extension") for (const listener of this.#extensions) {
        try {
          listener(notice.value);
        } catch {
        }
      }
      if (notice.topic === "change") for (const listener of this.#changes) {
        try {
          listener(notice.value);
        } catch {
        }
      }
    }
  };
  request(method, args, options = {}) {
    if (this.signal.aborted) return Promise.reject(this.signal.reason);
    if (options.signal?.aborted) return Promise.reject(options.signal.reason);
    const control = ["close", "attachment.ping", "attachment.suspend", "attachment.resume", "view.release", "sqlBranch.close", "content.cancel", "content.blobAbortWrite", "content.blobCloseRead", "signals.close", "upload.discard"].includes(method);
    if ([...this.#pending.values()].filter((request) => ["close", "attachment.ping", "attachment.suspend", "attachment.resume", "view.release", "sqlBranch.close", "content.cancel", "content.blobAbortWrite", "content.blobCloseRead", "signals.close", "upload.discard"].includes(request.method) === control).length >= (control ? 8 : 32)) return Promise.reject(new Error("ENDPOINT_REQUEST_LIMIT"));
    const timeoutMs = options.timeoutMs ?? 3e4;
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 12e4) return Promise.reject(new Error("ENDPOINT_TIMEOUT_LIMIT"));
    const id = ++this.#next, startedAt = performance.now();
    return new Promise((resolve, reject) => {
      const cancel = () => {
        try {
          this.#endpoint.postMessage({ protocol: APPLICATION_OWNER_PROTOCOL, attachment: this.#attachment, kind: "cancel", id });
        } catch {
        }
      };
      const abort = () => {
        const pending = this.#pending.get(id);
        if (pending === void 0) return;
        this.#pending.delete(id);
        clearTimeout(pending.timer);
        pending.cleanup();
        cancel();
        reject(options.signal?.reason);
      };
      const cleanup = () => options.signal?.removeEventListener("abort", abort);
      const timer = setTimeout(() => {
        this.#pending.delete(id);
        cleanup();
        cancel();
        reject(Object.assign(new Error("ENDPOINT_REQUEST_TIMEOUT"), { code: "ENDPOINT_REQUEST_TIMEOUT" }));
      }, timeoutMs);
      this.#pending.set(id, { method, startedAt, deadline: startedAt + timeoutMs, resolve: (value) => resolve(value), reject, timer, cleanup });
      options.signal?.addEventListener("abort", abort, { once: true });
      try {
        this.#endpoint.postMessage({ protocol: APPLICATION_OWNER_PROTOCOL, attachment: this.#attachment, kind: "request", id, method, args });
      } catch (error) {
        this.#pending.delete(id);
        clearTimeout(timer);
        cleanup();
        reject(error);
      }
    });
  }
  async initialize(options) {
    const value = await this.request("hello", [options]);
    this.applicationId = value.applicationId;
    this.identity = value.identity;
    this.#status = value.status;
    this.#binding = value.binding;
    this.#description = value.definition;
    if (options.heartbeat === true) {
      this.#heartbeat = setInterval(() => {
        if (this.#pinging || this.signal.aborted || this.#attachmentState === "suspended") return;
        this.#pinging = true;
        void this.request("attachment.ping", [], { timeoutMs: 2e4 }).catch((error) => this.#detach(error)).finally(() => {
          this.#pinging = false;
        });
      }, 5e3);
      this.#heartbeat.unref?.();
    }
  }
  async suspendAttachment() {
    await this.request("attachment.suspend", []);
    this.#attachmentState = "suspended";
    this.#ownedViews.clear();
  }
  suspend() {
    return this.suspendAttachment();
  }
  async resumeAttachment() {
    this.#status = await this.request("attachment.resume", []);
    this.#attachmentState = "active";
    return this.endpoint ?? null;
  }
  detach() {
    return this.close();
  }
  async submit(input) {
    const value = await this.request("submit", [input]);
    return new WorkerApplicationOperation(value.id, value.operationId, this);
  }
  async command(name, input, options = {}) {
    const value = await this.request("command", [name, input, options]);
    return new WorkerApplicationOperation(value.id, value.operationId, this);
  }
  query(name, input = null) {
    return this.request("query", [name, input]);
  }
  topic(name) {
    return this.request("topic", [name]);
  }
  queryAsOf(topic, input = null, target) {
    return this.request("queryAsOf", [topic, input, target]);
  }
  opOutcome(opId) {
    return this.request("opOutcome", [opId]);
  }
  topicLastOpId(topic) {
    return this.request("topicLastOpId", [topic]);
  }
  permissions() {
    return this.request("permissions.summary", []);
  }
  finalityStatus(opId) {
    return this.request("finality.opStatus", [opId]);
  }
  equivocationProofs() {
    return this.request("finality.equivocationProofs", []);
  }
  async forkSql(topic) {
    const opened = await this.request("sqlBranch.open", [topic]);
    let closed = false;
    const checkOpen = () => {
      if (closed) throw new Error("SQL_BRANCH_CLOSED");
    };
    return {
      topic: opened.topic,
      baseRoot: opened.baseRoot,
      exec: (sql, params = [], options = { mode: "user" }) => {
        checkOpen();
        return this.request("sqlBranch.exec", [opened.id, sql, params, options]);
      },
      query: (sql, params = []) => {
        checkOpen();
        return this.request("sqlBranch.query", [opened.id, sql, params]);
      },
      commitBranch: () => {
        checkOpen();
        return this.request("sqlBranch.commit", [opened.id]);
      },
      diff: () => {
        checkOpen();
        return this.request("sqlBranch.diff", [opened.id]);
      },
      toProposal: (options = {}) => {
        checkOpen();
        return this.request("sqlBranch.toProposal", [opened.id, options]);
      },
      close: async () => {
        if (closed) return;
        closed = true;
        await this.request("sqlBranch.close", [opened.id]);
      }
    };
  }
  async createCompartment(ringName, options) {
    const res = await this.request("compartment.create", [ringName, options]);
    return { ring: res.ring, epoch: res.epoch, operation: new WorkerApplicationOperation(res.operation.id, res.operation.operationId, this) };
  }
  async setupSocialRecovery(options) {
    const res = await this.request("recovery.setup", [options]);
    return new WorkerApplicationOperation(res.id, res.operationId, this);
  }
  async requestSocialRecovery(options = {}) {
    const res = await this.request("recovery.request", [options]);
    return { requestId: res.requestId, verificationCode: res.verificationCode, operation: new WorkerApplicationOperation(res.operation.id, res.operation.operationId, this) };
  }
  async approveSocialRecovery(requestId, options = {}) {
    const res = await this.request("recovery.approve", [requestId, options]);
    return new WorkerApplicationOperation(res.id, res.operationId, this);
  }
  completeSocialRecovery() {
    return this.request("recovery.complete", []);
  }
  readEvents(options = {}) {
    return this.request("readEvents", [options]);
  }
  wait(id, fact, options = {}) {
    const timeoutMs = options.timeoutMs ?? 3e4;
    return this.request("operation.wait", [id, fact, timeoutMs], { ...options, timeoutMs: Math.min(12e4, timeoutMs + 1e3) });
  }
  async readView(options = {}) {
    const captured = await this.request("readView", [options]);
    this.#ownedViews.add(captured.id);
    let released = false, releasing;
    return {
      applicationId: this.applicationId,
      revision: captured.revision,
      topic: (name) => {
        if (released) return Promise.reject(new Error("READ_VIEW_RELEASED"));
        return this.request("view.topic", [captured.id, name]);
      },
      query: (topic, input = null) => {
        if (released) return Promise.reject(new Error("READ_VIEW_RELEASED"));
        return this.request("view.query", [captured.id, topic, input]);
      },
      readEvents: (evOptions) => {
        if (released) return Promise.reject(new Error("READ_VIEW_RELEASED"));
        return this.request("view.events", [captured.id, evOptions ?? {}]);
      },
      release: () => {
        if (releasing !== void 0) return releasing;
        released = true;
        this.#ownedViews.delete(captured.id);
        return releasing = this.request("view.release", [captured.id]);
      }
    };
  }
  get operations() {
    const session = this;
    return {
      async retry(id) {
        const value = await session.request("operation.retry", [id]);
        return new WorkerApplicationOperation(value.id, value.operationId, session);
      },
      async get(id) {
        const value = await session.request("operation.get", [id]);
        return value === null ? null : new WorkerApplicationOperation(value.id, value.operationId, session);
      },
      async *subscribe(options) {
        const signal = options.signal === void 0 ? session.signal : AbortSignal.any([session.signal, options.signal]);
        let dirty = true, wake;
        const invalidate = () => {
          dirty = true;
          wake?.();
        };
        const stop = session.onChange(invalidate), stopStatus = session.onStatus(invalidate);
        signal.addEventListener("abort", invalidate);
        try {
          while (!signal.aborted) {
            if (!dirty) await new Promise((resolve) => {
              wake = resolve;
            });
            if (signal.aborted) break;
            dirty = false;
            const operation = await session.operations.get(options.operationId);
            if (operation !== null) yield await operation.inspect();
          }
        } finally {
          stop();
          stopStatus();
          signal.removeEventListener("abort", invalidate);
        }
      }
    };
  }
  onStatus(listener) {
    this.#statuses.add(listener);
    listener(this.status);
    return () => {
      this.#statuses.delete(listener);
    };
  }
  onChange(listener) {
    this.#changes.add(listener);
    return () => {
      this.#changes.delete(listener);
    };
  }
  async *changes(options = {}) {
    const signal = options.signal === void 0 ? this.signal : AbortSignal.any([this.signal, options.signal]), queue = [];
    let wake;
    const stop = this.onChange((value) => {
      queue.splice(0, queue.length, value);
      wake?.();
    }), abort = () => {
      wake?.();
    };
    signal.addEventListener("abort", abort);
    try {
      while (!signal.aborted) {
        if (queue.length === 0) await new Promise((resolve) => {
          wake = resolve;
        });
        while (queue.length > 0 && !signal.aborted) yield queue.shift();
      }
    } finally {
      stop();
      signal.removeEventListener("abort", abort);
    }
  }
  diagnostics() {
    return this.request("diagnostics.peers", []);
  }
  endpoints() {
    return this.request("endpoints.list", []);
  }
  exportFacts(options) {
    return this.request("facts.export", options === void 0 ? [] : [options]);
  }
  mergeFacts(facts) {
    return this.request("facts.merge", [facts]);
  }
  finality = {
    status: () => this.request("finality.status", []),
    createCheckpoint: (options) => this.request("finality.createCheckpoint", [options]),
    submitCheckpoints: (checkpoints) => this.request("finality.submitCheckpoints", [checkpoints])
  };
  extensions = {
    call: (name, args = [], options = {}) => this.request("extension.call", [name, args], options),
    subscribe: (listener) => {
      this.#extensions.add(listener);
      return () => {
        this.#extensions.delete(listener);
      };
    }
  };
  signals = {
    delivery: "application",
    send: (topic, payload, options = {}) => {
      const { signal, ...rest } = options;
      return this.request("signals.send", [topic, payload, rest], signal === void 0 ? {} : { signal });
    },
    subscribe: (options = {}) => {
      const session = this;
      return {
        async *[Symbol.asyncIterator]() {
          const { signal, ...rest } = options;
          const id = await session.request("signals.open", [rest], signal === void 0 ? {} : { signal });
          try {
            while (true) {
              const next = await session.request("signals.next", [id], signal === void 0 ? { timeoutMs: 12e4 } : { signal, timeoutMs: 12e4 });
              if (next === null) return;
              yield next;
            }
          } finally {
            void session.request("signals.close", [id]).catch(() => void 0);
          }
        }
      };
    }
  };
  content = {
    stage: async (options) => {
      const id = await this.request("content.stage", [options]);
      return {
        id,
        write: (index, bytes) => this.request("upload.write", [id, index, bytes]),
        progress: () => this.request("upload.progress", [id]),
        commit: () => this.request("upload.commit", [id]),
        discard: () => this.request("upload.discard", [id])
      };
    },
    read: (reference, options = {}) => {
      const session = this;
      return {
        async *[Symbol.asyncIterator]() {
          const id = await session.request("content.openRead", [reference], options);
          try {
            while (true) {
              const chunk = await session.request("content.next", [id], options);
              if (chunk === null) return;
              yield chunk;
            }
          } finally {
            void session.request("content.cancel", [id]).catch(() => void 0);
          }
        }
      };
    },
    putBytes: (bytes, options) => putContentBytes(this.content, bytes, options),
    readBytes: (reference, options) => readContentBytes(this.content, reference, options),
    retain: (reference, options = {}) => this.request("content.retain", [reference], options),
    retention: (reference, options = {}) => this.request("content.retention", [reference], options),
    retained: (reference) => this.request("content.retained", [reference]),
    discard: (reference) => this.request("content.discard", [reference]),
    putBlob: async (bytes, options = {}) => {
      if (!(bytes instanceof Uint8Array) || bytes.byteLength > MAX_BLOB_BYTES) throw new Error("CONTENT_RANGE_INVALID");
      const reqOptions = options.signal === void 0 ? {} : { signal: options.signal };
      const id = await this.request("content.blobOpenWrite", [bytes.byteLength], reqOptions);
      try {
        for (let offset = 0; offset < bytes.byteLength; offset += CONTENT_CHUNK_BYTES) {
          const chunk = Uint8Array.from(bytes.subarray(offset, Math.min(bytes.byteLength, offset + CONTENT_CHUNK_BYTES)));
          await this.request("content.blobWriteChunk", [id, offset / CONTENT_CHUNK_BYTES, chunk], reqOptions);
        }
        return await this.request("content.blobCommitWrite", [id], reqOptions);
      } catch (error) {
        void this.request("content.blobAbortWrite", [id]).catch(() => void 0);
        throw error;
      }
    },
    getBlob: async (hash, options = {}) => {
      const { signal, ...rest } = options;
      const reqOptions = signal === void 0 ? {} : { signal };
      const opened = await this.request("content.blobOpenRead", [hash, rest], reqOptions);
      if (opened === null) return null;
      const result = new Uint8Array(opened.bytes);
      let offset = 0;
      try {
        while (offset < opened.bytes) {
          const chunk = await this.request("content.blobNextChunk", [opened.id], reqOptions);
          if (chunk === null) break;
          if (!(chunk instanceof Uint8Array) || chunk.byteLength === 0 || offset + chunk.byteLength > opened.bytes) throw new Error("CONTENT_CHUNK_SIZE_INVALID");
          result.set(chunk, offset);
          offset += chunk.byteLength;
        }
        if (offset !== opened.bytes) throw new Error("CONTENT_INCOMPLETE");
        return result;
      } finally {
        void this.request("content.blobCloseRead", [opened.id]).catch(() => void 0);
      }
    },
    hasBlob: (hash) => this.request("content.hasBlob", [hash]),
    deleteBlob: (hash) => this.request("content.deleteBlob", [hash]),
    put: async (bytes, options = {}) => {
      const visibility = options.visibility ?? "private";
      const mediaType = options.mediaType ?? "application/octet-stream";
      if (visibility === "public") {
        const info = await this.content.putBlob(bytes, options.signal === void 0 ? {} : { signal: options.signal });
        return { profile: "chronolog-blob-v2", visibility: "public", hash: info.hash, bytes: info.bytes, mediaType };
      }
      if (options.deduplicate === true) {
        if (!(bytes instanceof Uint8Array) || bytes.byteLength > MAX_BLOB_BYTES) throw new Error("CONTENT_RANGE_INVALID");
        const reqOptions = options.signal === void 0 ? {} : { signal: options.signal };
        const id = await this.request("content.blobOpenWrite", [bytes.byteLength], reqOptions);
        try {
          for (let offset = 0; offset < bytes.byteLength; offset += CONTENT_CHUNK_BYTES) {
            const chunk = Uint8Array.from(bytes.subarray(offset, Math.min(bytes.byteLength, offset + CONTENT_CHUNK_BYTES)));
            await this.request("content.blobWriteChunk", [id, offset / CONTENT_CHUNK_BYTES, chunk], reqOptions);
          }
          return await this.request("content.blobCommitPrivate", [id, mediaType], reqOptions);
        } catch (error) {
          void this.request("content.blobAbortWrite", [id]).catch(() => void 0);
          throw error;
        }
      }
      return this.content.putBytes(bytes, { mediaType, ...options.signal === void 0 ? {} : { signal: options.signal } });
    },
    get: async (target, options = {}) => {
      if (typeof target === "string") return this.content.getBlob(target, options);
      if (isPublicBlobReference(target)) {
        return this.content.getBlob(target.hash, { ...options, expectedBytes: options.expectedBytes ?? target.bytes });
      }
      if (isPrivateContentReference(target)) {
        try {
          return await this.content.readBytes(target, {
            maxBytes: options.maxBytes ?? target.bytes,
            ...options.signal === void 0 ? {} : { signal: options.signal }
          });
        } catch (error) {
          if (error instanceof Error && (error.message === "CONTENT_MANIFEST_MISSING" || error.message === "CONTENT_CHUNK_MISSING")) {
            return null;
          }
          throw error;
        }
      }
      throw new Error("CONTENT_REFERENCE_INVALID");
    }
  };
  #detach(error) {
    if (this.#attachmentState === "detached") return;
    this.#attachmentState = "detached";
    clearInterval(this.#heartbeat);
    this.#lifetime.abort(error);
    for (const pending of this.#pending.values()) {
      clearTimeout(pending.timer);
      pending.cleanup();
      pending.reject(error);
    }
    this.#pending.clear();
    this.#endpoint.removeEventListener("message", this.#receive);
    const physical = this.#endpoint;
    physical.removeEventListener("close", this.#physicalClose);
    physical.removeEventListener("messageerror", this.#physicalClose);
    physical.off?.("close", this.#physicalClose);
    physical.off?.("messageerror", this.#physicalClose);
    this.#status = { ...this.#status, canAuthor: false, phase: "closed", database: "closed" };
    for (const listener of this.#statuses) {
      try {
        listener(this.status);
      } catch {
      }
    }
  }
  async close() {
    if (this.#attachmentState === "detached") return;
    try {
      await this.request("close", [], { timeoutMs: 2e3 });
    } catch {
    }
    this.#detach(new Error("ENDPOINT_CLOSED"));
    this.#endpoint.close?.();
  }
};
async function connectApplicationOwner(endpoint, options) {
  endpoint.start?.();
  const session = new WorkerApplicationSession(endpoint);
  try {
    await session.initialize(options);
    return session;
  } catch (error) {
    await session.close();
    throw error;
  }
}
export {
  SessionError,
  WorkerApplicationOperation,
  WorkerApplicationSession,
  applicationDefinitionDigest,
  canonicalJson,
  connectApplicationOwner,
  createAppClient,
  createApplicationBackend,
  createLiveView,
  createProjection,
  createScopedApplicationTools,
  createViewStore,
  defineApplication,
  defineCommand,
  defineProjection,
  defineQuery,
  describeApplication,
  forwardSessionEvents,
  parseApplicationInput,
  submitBatch
};
