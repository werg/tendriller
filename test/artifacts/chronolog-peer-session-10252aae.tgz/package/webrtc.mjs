import {
  connectApplicationWebRtc
} from "./chunks/chunk-ITOMIYCF.mjs";
import {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
} from "./chunks/chunk-5IXWYBUE.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-FBC6LMDF.mjs";
import "./chunks/chunk-ICYUPG2X.mjs";
export {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
