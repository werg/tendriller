import {
  verifyEd25519Sync
} from "./chunk-I5LQHB54.mjs";
import {
  assertValidReducersConfig,
  canonicalEventPayload,
  canonicalJson,
  compareOperationOrder,
  decodeLogGenesis,
  encodeCanonicalJsonCbor,
  encodeLogGenesis,
  genesisLogId,
  isControlTopic,
  jsonToCbor,
  normalizeJsonValue,
  operationIdDigest
} from "./chunk-5A4YJVOD.mjs";
import {
  bytesToHex,
  decodeUtf8,
  encodeCanonicalCbor,
  hashDomainSync,
  hexToBytes,
  sha256Sync,
  utf8
} from "./chunk-ICYUPG2X.mjs";

// packages/materializer/src/quickjs-sandbox.ts
import {
  newQuickJSWASMModuleFromVariant,
  newVariant
} from "quickjs-emscripten-core";
import baseVariant from "@jitl/quickjs-ng-wasmfile-release-sync";
var MissingDependencyError = class extends Error {
  constructor(hash, kind = "cas") {
    super(`MISSING_DEPENDENCY:${kind}/${hash}`);
    this.hash = hash;
    this.kind = kind;
    this.name = "MissingDependencyError";
  }
  hash;
  kind;
  code = "MISSING_DEPENDENCY";
};
var OperationalTimeoutError = class extends Error {
  code = "OPERATIONAL_TIMEOUT";
  constructor(message = "REDUCER_WATCHDOG_TIMEOUT") {
    super(message);
    this.name = "OperationalTimeoutError";
  }
};
var CRYPTO_MODULE_SHIM = `
export function sha256(input) { return globalThis.__chronologHost.sha256(input); }
export function verifyEd25519(pubKeyHex, message, sigHex) { return globalThis.__chronologHost.verifyEd25519(pubKeyHex, message, sigHex); }
export function canonicalJson(value) { return globalThis.__chronologHost.canonicalJson(value); }
`;
var CAS_MODULE_SHIM = `
export function put(bytes, links = []) { return globalThis.__chronologHost.casPut(bytes, links); }
export function get(hash) { return globalThis.__chronologHost.casGet(hash); }
`;
var SQLITE_MODULE_SHIM = `
export function openDb(dbRoot = null) {
  const handleId = globalThis.__chronologHost.sqlOpen(dbRoot);
  return {
    exec(sql, params = [], options = {}) {
      return JSON.parse(globalThis.__chronologHost.sqlExec(handleId, String(sql), JSON.stringify(params ?? []), JSON.stringify(options ?? {})));
    },
    query(sql, params = []) {
      return JSON.parse(globalThis.__chronologHost.sqlQuery(handleId, String(sql), JSON.stringify(params ?? [])));
    },
    validateExpr(table, sqlOp, expr) {
      globalThis.__chronologHost.sqlValidateExpr(handleId, String(table), String(sqlOp), String(expr));
    },
    commit() {
      return globalThis.__chronologHost.sqlCommit(handleId);
    },
    close() {
      globalThis.__chronologHost.sqlClose(handleId);
    },
  };
}
`;
var DETERMINISM_PRELUDE = `
Object.defineProperty(globalThis, 'Date', { value: undefined, writable: false, configurable: false });
Object.defineProperty(Math, 'random', { value: () => { throw new Error('NONDETERMINISTIC_MATH_RANDOM'); }, writable: false, configurable: false });
if (typeof Intl !== 'undefined') {
  Object.defineProperty(globalThis, 'Intl', { value: undefined, writable: false, configurable: false });
}
`;
var defaultQuickJsPromise = null;
async function loadQuickJsModule(wasmModule) {
  const syncBase = baseVariant;
  if (wasmModule !== void 0) {
    const variant = newVariant(syncBase, { wasmModule });
    return newQuickJSWASMModuleFromVariant(variant);
  }
  if (defaultQuickJsPromise === null) {
    defaultQuickJsPromise = newQuickJSWASMModuleFromVariant(syncBase).catch((err) => {
      defaultQuickJsPromise = null;
      throw err;
    });
  }
  return defaultQuickJsPromise;
}
var QuickJsSandbox = class {
  #wasmPromise;
  #sqliteDriver;
  #watchdogMs;
  #runtimePool = [];
  #nestedQueryCache = /* @__PURE__ */ new Map();
  constructor(options = {}) {
    this.#wasmPromise = loadQuickJsModule(options.wasmModule);
    this.#sqliteDriver = options.sqliteDriver;
    this.#watchdogMs = options.watchdogMs ?? 2e3;
  }
  get sqliteBuiltinId() {
    return this.#sqliteDriver?.builtinId ?? null;
  }
  dispose() {
    for (let i = 0; i < this.#runtimePool.length; i++) {
      try {
        this.#runtimePool[i]?.dispose();
      } catch {
      }
      this.#runtimePool[i] = void 0;
    }
    this.#nestedQueryCache.clear();
  }
  /**
   * Execute one deterministic reduce/query/describe call in a fresh isolated QuickJSContext.
   * Demand-pages locally stored CAS nodes that were evicted from the RAM LRU cache.
   */
  async invoke(input) {
    const qjs = await this.#wasmPromise;
    const readPartition = input.casPartition === "public" ? "public" : "any";
    for (let faults = 0; faults < 256; faults++) {
      try {
        return this.#invokeSync(qjs, input, 0);
      } catch (err) {
        if (err instanceof MissingDependencyError && await input.cas.ensureLoaded(err.hash, readPartition)) {
          continue;
        }
        throw err;
      }
    }
    return this.#invokeSync(qjs, input, 0);
  }
  #acquireRuntime(qjs, depth) {
    const existing = this.#runtimePool[depth];
    if (existing !== void 0) {
      this.#runtimePool[depth] = void 0;
      return existing;
    }
    return qjs.newRuntime();
  }
  #releaseRuntime(runtime, depth, healthy) {
    if (healthy && this.#runtimePool[depth] === void 0) {
      this.#runtimePool[depth] = runtime;
      return;
    }
    try {
      runtime.dispose();
    } catch {
    }
  }
  #invokeSync(qjs, input, depth) {
    const runtime = this.#acquireRuntime(qjs, depth);
    const openDbs = /* @__PURE__ */ new Map();
    let nextDbId = 1;
    let missingDep = null;
    let timedOut = false;
    let healthy = true;
    const deadline = Date.now() + this.#watchdogMs;
    const readPartition = input.casPartition === "public" ? "public" : "any";
    const writePartition = input.casPartition;
    const tripMissing = (hash, kind) => {
      const err = new MissingDependencyError(hash, kind);
      missingDep ??= err;
      throw err;
    };
    try {
      runtime.setMemoryLimit(input.maxMemoryBytes);
      runtime.setMaxStackSize(512 * 1024);
      runtime.setInterruptHandler(() => {
        if (missingDep !== null) return true;
        if (Date.now() > deadline) {
          timedOut = true;
          return true;
        }
        return false;
      });
      runtime.setModuleLoader((moduleName) => {
        if (moduleName === "chronolog:crypto") {
          if (!Object.hasOwn(input.builtins, "chronolog:crypto")) return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:crypto") };
          return CRYPTO_MODULE_SHIM;
        }
        if (moduleName === "chronolog:cas") {
          if (!Object.hasOwn(input.builtins, "chronolog:cas")) return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:cas") };
          return CAS_MODULE_SHIM;
        }
        if (moduleName === "chronolog:sqlite") {
          if (!Object.hasOwn(input.builtins, "chronolog:sqlite") || this.#sqliteDriver === void 0) {
            return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:sqlite") };
          }
          return SQLITE_MODULE_SHIM;
        }
        if (moduleName === "__chronolog_entry__") {
          const exp = input.exportName === "default" ? `import __target from ${JSON.stringify(input.moduleSpecifier)};` : `import { ${input.exportName} as __target } from ${JSON.stringify(input.moduleSpecifier)};`;
          const callExpr = input.method === "reduce" ? "fn(env.state, env.tx, ctx)" : input.method === "onConflict" ? "fn(env.state, env.tx, ctx, env.conflict)" : input.method === "query" ? "fn(env.state, env.payload, ctx)" : "fn(env.state, ctx)";
          return `${exp}
globalThis.__chronologRun = () => { const env = JSON.parse(globalThis.__chronologEnvJson); const ctx = Object.freeze({ topic(name) { return Object.prototype.hasOwnProperty.call(env.topics, name) ? env.topics[name] : null; }, query(name, input = null) { return JSON.parse(globalThis.__chronologHost.queryTopic(String(name), JSON.stringify(input === undefined ? null : input))); }, opOutcome(opId) { const key = String(opId); return env.opOutcomes && Object.prototype.hasOwnProperty.call(env.opOutcomes, key) ? env.opOutcomes[key] : null; }, topicLastOpId(name) { const key = String(name); return env.topicLastOpIds && Object.prototype.hasOwnProperty.call(env.topicLastOpIds, key) ? env.topicLastOpIds[key] : null; }, config: env.config ?? null }); const fn = __target && __target[${JSON.stringify(input.method)}]; if (typeof fn !== 'function') { return JSON.stringify({ __missingMethod: true }); } const out = ${callExpr}; return JSON.stringify({ __ok: true, value: out }); };`;
        }
        const ref = input.imports[moduleName];
        if (ref === void 0) return { error: new Error(`MODULE_NOT_FOUND:${moduleName}`) };
        const match = /^cas:sha256-([0-9a-f]{64})$/u.exec(ref);
        if (match === null) return { error: new Error(`MODULE_REF_INVALID:${moduleName}`) };
        const hash = match[1];
        const node = input.cas.getSync(hash, readPartition);
        if (node === null) {
          missingDep ??= new MissingDependencyError(hash, "module");
          return { error: missingDep };
        }
        return decodeUtf8(node.bytes);
      });
      const ctx = runtime.newContext();
      try {
        const preludeRes = ctx.evalCode(DETERMINISM_PRELUDE, "__prelude__.js");
        if (preludeRes.error) {
          preludeRes.error.dispose();
          return { ok: false, code: "vm:prelude_failed" };
        }
        preludeRes.value.dispose();
        const hostObj = ctx.newObject();
        const bindFn = (name, fn) => {
          const handle = ctx.newFunction(name, (...args) => {
            if (missingDep !== null) throw missingDep;
            return fn(...args);
          });
          ctx.setProp(hostObj, name, handle);
          handle.dispose();
        };
        bindFn("queryTopic", (topicH, inputJsonH) => {
          if (depth >= 4) throw new Error("TOPIC_QUERY_DEPTH_EXCEEDED");
          const topicName = ctx.getString(topicH);
          if (readPartition === "public" && !isControlTopic(topicName)) {
            return ctx.newString("null");
          }
          const rawQueryInput = JSON.parse(ctx.getString(inputJsonH));
          const topicState = Object.hasOwn(input.topics, topicName) ? input.topics[topicName] : null;
          const binding = input.topicBindings?.[topicName];
          if (binding === void 0) {
            return ctx.newString(JSON.stringify(topicState));
          }
          const nestedPartition = readPartition === "public" || isControlTopic(topicName) ? "public" : input.casPartition;
          const modRef = input.imports[binding.module] ?? "";
          const canMemoize = isControlTopic(topicName) && modRef.startsWith("cas:sha256-") && Object.keys(input.imports).length <= 32;
          let memoKey = null;
          if (canMemoize) {
            const stateKey = bytesToHex(sha256Sync(utf8(JSON.stringify(topicState))));
            const inputKey = JSON.stringify(rawQueryInput);
            const configKey = binding.config === void 0 ? "" : JSON.stringify(binding.config);
            memoKey = `${nestedPartition}\0${modRef}\0${binding.export ?? "default"}\0${stateKey}\0${configKey}\0${inputKey}`;
            const hit = this.#nestedQueryCache.get(memoKey);
            if (hit !== void 0) {
              this.#nestedQueryCache.delete(memoKey);
              this.#nestedQueryCache.set(memoKey, hit);
              return ctx.newString(hit);
            }
          }
          let nestedRes;
          try {
            nestedRes = this.#invokeSync(qjs, {
              imports: input.imports,
              builtins: input.builtins,
              ...input.topicBindings === void 0 ? {} : { topicBindings: input.topicBindings },
              moduleSpecifier: binding.module,
              exportName: binding.export ?? "default",
              method: "query",
              state: topicState,
              payload: normalizeJsonValue(rawQueryInput),
              topics: input.topics,
              ...binding.config === void 0 ? {} : { config: binding.config },
              cas: input.cas,
              casPartition: nestedPartition,
              readOnly: true,
              maxMemoryBytes: input.maxMemoryBytes
            }, depth + 1);
          } catch (err) {
            if (err instanceof MissingDependencyError) {
              missingDep ??= err;
              throw err;
            }
            throw err;
          }
          if (!nestedRes.ok) {
            if (nestedRes.code === "vm:missing_method:query") {
              return ctx.newString(JSON.stringify(topicState));
            }
            throw new Error(`TOPIC_QUERY_FAILED:${nestedRes.code}:${nestedRes.detail ?? ""}`);
          }
          const serialized = JSON.stringify(nestedRes.value);
          if (memoKey !== null) {
            this.#nestedQueryCache.set(memoKey, serialized);
            if (this.#nestedQueryCache.size > 512) {
              const oldest = this.#nestedQueryCache.keys().next().value;
              if (oldest !== void 0) this.#nestedQueryCache.delete(oldest);
            }
          }
          return ctx.newString(serialized);
        });
        bindFn("sha256", (dataHandle) => {
          const raw = ctx.dump(dataHandle);
          const bytes = typeof raw === "string" ? utf8(raw) : raw instanceof Uint8Array ? raw : utf8(JSON.stringify(raw));
          return ctx.newString(bytesToHex(sha256Sync(bytes)));
        });
        bindFn("verifyEd25519", (pubH, msgH, sigH) => {
          const pubHex = ctx.getString(pubH);
          const msgRaw = ctx.dump(msgH);
          const sigHex = ctx.getString(sigH);
          if (!/^[0-9a-f]{64}$/u.test(pubHex) || !/^[0-9a-f]{128}$/u.test(sigHex)) return ctx.false;
          const msgBytes = typeof msgRaw === "string" ? utf8(msgRaw) : msgRaw instanceof Uint8Array ? msgRaw : utf8(JSON.stringify(msgRaw));
          return verifyEd25519Sync(hexToBytes(pubHex), msgBytes, hexToBytes(sigHex)) ? ctx.true : ctx.false;
        });
        bindFn("canonicalJson", (valH) => {
          const val = normalizeJsonValue(ctx.dump(valH));
          return ctx.newString(canonicalEventPayload(val));
        });
        bindFn("casPut", (bytesH, linksH) => {
          if (input.readOnly) throw new Error("CAS_READ_ONLY");
          const raw = ctx.dump(bytesH);
          const bytes = typeof raw === "string" ? utf8(raw) : raw instanceof Uint8Array ? raw : Array.isArray(raw) ? Uint8Array.from(raw) : (() => {
            throw new Error("CAS_PUT_BYTES_INVALID");
          })();
          const rawLinks = linksH === void 0 ? [] : ctx.dump(linksH);
          if (!Array.isArray(rawLinks) || !rawLinks.every((l) => typeof l === "string")) throw new Error("CAS_PUT_LINKS_INVALID");
          const hash = input.cas.putSync(bytes, rawLinks, writePartition);
          return ctx.newString(hash);
        });
        bindFn("casGet", (hashH) => {
          const hash = ctx.getString(hashH);
          if (!/^[0-9a-f]{64}$/u.test(hash)) throw new Error("CAS_HASH_INVALID");
          const node = input.cas.getSync(hash, readPartition);
          if (node === null) {
            tripMissing(hash, "cas");
            return ctx.undefined;
          }
          return ctx.newString(JSON.stringify({ bytesHex: bytesToHex(node.bytes), links: node.links }));
        });
        if (this.#sqliteDriver !== void 0) {
          const driver = this.#sqliteDriver;
          bindFn("sqlOpen", (rootH) => {
            const rawRoot = ctx.dump(rootH);
            const dbRoot = typeof rawRoot === "string" ? rawRoot : null;
            const db = driver.openDb({
              dbRoot,
              cas: input.cas,
              partition: input.casPartition,
              actor: input.tx?.author ?? "0".repeat(64),
              opId: input.tx?.opId ?? "0".repeat(64),
              opTimeMs: BigInt(input.tx?.authorTimestampMs ?? 0),
              readOnly: input.readOnly,
              onMissingCas: (hash) => tripMissing(hash, "sqlite")
            });
            const id = nextDbId++;
            openDbs.set(id, db);
            return ctx.newNumber(id);
          });
          bindFn("sqlExec", (idH, sqlH, paramsH, optsH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            const sql = ctx.getString(sqlH);
            const params = JSON.parse(ctx.getString(paramsH));
            const opts = JSON.parse(ctx.getString(optsH));
            const res = db.exec(sql, params, opts);
            return ctx.newString(JSON.stringify(res));
          });
          bindFn("sqlQuery", (idH, sqlH, paramsH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            const sql = ctx.getString(sqlH);
            const params = JSON.parse(ctx.getString(paramsH));
            const res = db.query(sql, params);
            return ctx.newString(JSON.stringify(res));
          });
          bindFn("sqlValidateExpr", (idH, tableH, opH, exprH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            db.validateExpr(ctx.getString(tableH), ctx.getString(opH), ctx.getString(exprH));
          });
          bindFn("sqlCommit", (idH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            return ctx.newString(db.commit());
          });
          bindFn("sqlClose", (idH) => {
            const id = ctx.getNumber(idH);
            const db = openDbs.get(id);
            if (db !== void 0) {
              db.close();
              openDbs.delete(id);
            }
          });
        }
        ctx.setProp(ctx.global, "__chronologHost", hostObj);
        hostObj.dispose();
        const envJson = JSON.stringify({
          state: input.state,
          payload: input.payload,
          tx: input.tx === void 0 ? null : { ...input.tx, payload: input.payload },
          conflict: input.conflict ?? null,
          opOutcomes: input.opOutcomes ?? {},
          topicLastOpIds: input.topicLastOpIds ?? {},
          topics: input.topics,
          config: input.config ?? null
        });
        const envHandle = ctx.newString(envJson);
        ctx.setProp(ctx.global, "__chronologEnvJson", envHandle);
        envHandle.dispose();
        const loadRes = ctx.evalCode(
          `import '__chronolog_entry__';`,
          "__bootstrap__.mjs",
          { type: "module" }
        );
        if (loadRes.error) {
          const dumped = ctx.dump(loadRes.error);
          loadRes.error.dispose();
          if (missingDep !== null) throw missingDep;
          if (timedOut) throw new OperationalTimeoutError();
          return { ok: false, code: "vm:module_load_error", detail: formatJsError(dumped) };
        }
        loadRes.value.dispose();
        if (missingDep !== null) throw missingDep;
        if (timedOut) throw new OperationalTimeoutError();
        const runRes = ctx.evalCode("globalThis.__chronologRun()", "__run__.js");
        if (runRes.error) {
          const dumped = ctx.dump(runRes.error);
          runRes.error.dispose();
          if (missingDep !== null) throw missingDep;
          if (timedOut) throw new OperationalTimeoutError();
          const detail = formatJsError(dumped);
          const code = /out of memory|memory limit/i.test(detail) ? "vm:limit" : "reducer:throw";
          return { ok: false, code, detail };
        }
        const rawOut = ctx.getString(runRes.value);
        runRes.value.dispose();
        if (missingDep !== null) throw missingDep;
        if (timedOut) throw new OperationalTimeoutError();
        const parsed = JSON.parse(rawOut);
        if (parsed.__missingMethod) {
          return { ok: false, code: `vm:missing_method:${input.method}` };
        }
        try {
          const normalized = normalizeJsonValue(parsed.value);
          return { ok: true, value: normalized };
        } catch (err) {
          return { ok: false, code: "vm:invalid_output", detail: err instanceof Error ? err.message : String(err) };
        }
      } finally {
        for (const db of openDbs.values()) {
          try {
            db.close();
          } catch {
          }
        }
        openDbs.clear();
        try {
          ctx.dispose();
        } catch {
          healthy = false;
        }
      }
    } catch (err) {
      healthy = false;
      throw err;
    } finally {
      if (timedOut || missingDep !== null) healthy = false;
      this.#releaseRuntime(runtime, depth, healthy);
    }
  }
};
function formatJsError(dumped) {
  if (typeof dumped === "string") return dumped;
  if (dumped !== null && typeof dumped === "object" && "message" in dumped) {
    return String(dumped.message);
  }
  try {
    return JSON.stringify(dumped);
  } catch {
    return String(dumped);
  }
}

// packages/materializer/src/kernel.ts
var ZERO_HASH = "0".repeat(64);
function seenOpKey(visibility, authorHex, operationId) {
  return `${visibility}:${authorHex}:${operationId}`;
}
function hashSeenOpsSet(seen, cas, partition) {
  const sorted = [...seen].sort();
  const bytes = encodeCanonicalCbor(sorted);
  return cas.putSync(bytes, [], partition);
}
function computeStateRoot(topics, seenOpsRoot) {
  const payload = encodeCanonicalCbor(/* @__PURE__ */ new Map([
    ["seenOpsRoot", seenOpsRoot],
    ["topics", jsonToCbor(normalizeJsonValue(topics))]
  ]));
  return bytesToHex(hashDomainSync("state", payload));
}
function advanceHistoryDigest(prev, opId, outcome, rejectionCode, events) {
  const eventsBytes = encodeCanonicalJsonCbor(
    events.map((e) => ({ o: e.eventOrdinal, t: e.topic, p: e.payload }))
  );
  const payload = encodeCanonicalCbor([prev, opId, outcome, rejectionCode ?? "", eventsBytes]);
  return bytesToHex(hashDomainSync("history", payload));
}
function computeRevisionDigest(historyDigest, stateRoot, view, policyContextDigest) {
  const payload = encodeCanonicalCbor([historyDigest, stateRoot, view, policyContextDigest]);
  return bytesToHex(hashDomainSync("revision", payload));
}
function filterPublicTopics(topics) {
  const out = {};
  for (const [k, v] of Object.entries(topics)) {
    if (isControlTopic(k)) out[k] = v;
  }
  return out;
}
function extractCasHashes(value, out) {
  if (typeof value === "string") {
    if (/^[0-9a-f]{64}$/u.test(value)) out.add(value);
    else if (value.startsWith("cas:sha256-") && value.length === 75) out.add(value.slice(11));
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) extractCasHashes(item, out);
    return;
  }
  if (value !== null && typeof value === "object") {
    for (const v of Object.values(value)) extractCasHashes(v, out);
  }
}
function extractRequiredCasHashes(value, out, key) {
  if (typeof value === "string") {
    if (value.startsWith("cas:sha256-") && value.length === 75) out.add(value.slice(11));
    else if (key === "dbRoot" && /^[0-9a-f]{64}$/u.test(value)) out.add(value);
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) extractRequiredCasHashes(item, out);
    return;
  }
  if (value !== null && typeof value === "object") {
    for (const [k, v] of Object.entries(value)) extractRequiredCasHashes(v, out, k);
  }
}
var TopicKernel = class {
  genesis;
  genesisBytes;
  logId;
  logIdHex;
  cas;
  sandbox;
  blindHostMode;
  #snapshotInterval;
  #policyContextDigest;
  #order = [];
  #outcomes = [];
  #topics;
  #seenOps = /* @__PURE__ */ new Set();
  #opOutcomes = /* @__PURE__ */ new Map();
  #topicLastOpIds = /* @__PURE__ */ new Map();
  #seenOpsRoot;
  #historyDigest = ZERO_HASH;
  #stateRoot;
  #pendingDependencies = /* @__PURE__ */ new Set();
  #skippedOpIds = /* @__PURE__ */ new Set();
  #snapshots = /* @__PURE__ */ new Map();
  #frontierOpIds = /* @__PURE__ */ new Set();
  #frontierOrderLength = 0;
  #frontierMaxTimestampMs = 0n;
  #genesisSnapshot;
  #cacheRestores = 0;
  #cachedDescribe = null;
  #queryCacheStateRoot = "";
  #queryCache = /* @__PURE__ */ new Map();
  constructor(options) {
    this.genesisBytes = options.genesis instanceof Uint8Array ? options.genesis.slice() : encodeLogGenesis(options.genesis);
    this.genesis = decodeLogGenesis(this.genesisBytes);
    this.logId = genesisLogId(this.genesisBytes);
    this.logIdHex = bytesToHex(this.logId);
    this.cas = options.cas;
    this.blindHostMode = options.blindHostMode ?? false;
    this.#snapshotInterval = options.snapshotInterval ?? 16;
    this.#policyContextDigest = options.policyContextDigest ?? ZERO_HASH;
    this.sandbox = new QuickJsSandbox(options);
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(this.genesis.initialTopics)) : structuredClone(this.genesis.initialTopics);
    this.#seenOpsRoot = hashSeenOpsSet(this.#seenOps, this.cas, "public");
    this.#stateRoot = computeStateRoot(this.#topics, this.#seenOpsRoot);
    this.#genesisSnapshot = this.#captureSnapshot(0);
    this.#snapshots.set(0, this.#genesisSnapshot);
  }
  #captureSnapshotFrom(state, orderLength) {
    return {
      topics: structuredClone(state.topics),
      seenOps: new Set(state.seenOps),
      opOutcomes: new Map(state.opOutcomes),
      topicLastOpIds: new Map(state.topicLastOpIds),
      seenOpsRoot: state.seenOpsRoot,
      historyDigest: state.historyDigest,
      stateRoot: state.stateRoot,
      orderLength
    };
  }
  #captureSnapshot(orderLength) {
    return {
      topics: structuredClone(this.#topics),
      seenOps: new Set(this.#seenOps),
      opOutcomes: new Map(this.#opOutcomes),
      topicLastOpIds: new Map(this.#topicLastOpIds),
      seenOpsRoot: this.#seenOpsRoot,
      historyDigest: this.#historyDigest,
      stateRoot: this.#stateRoot,
      orderLength
    };
  }
  get topics() {
    return structuredClone(this.#topics);
  }
  get seenOpsRoot() {
    return this.#seenOpsRoot;
  }
  snapshot() {
    return {
      topics: structuredClone(this.#topics),
      seenOpsRoot: this.#seenOpsRoot,
      historyDigest: this.#historyDigest,
      stateRoot: this.#stateRoot
    };
  }
  topic(name) {
    return Object.hasOwn(this.#topics, name) ? structuredClone(this.#topics[name]) : null;
  }
  opOutcome(opId) {
    return this.#opOutcomes.get(opId)?.outcome ?? null;
  }
  topicLastOpId(topic) {
    return this.#topicLastOpIds.get(topic) ?? null;
  }
  get outcomes() {
    return this.#outcomes.slice();
  }
  get pendingDependencies() {
    return [...this.#pendingDependencies].sort();
  }
  revision(view = "local", policyContextDigest = this.#policyContextDigest) {
    return {
      stateRoot: this.#stateRoot,
      historyDigest: this.#historyDigest,
      digest: computeRevisionDigest(this.#historyDigest, this.#stateRoot, view, policyContextDigest),
      view,
      orderLength: this.#frontierOrderLength + this.#order.length
    };
  }
  get frontierOrderLength() {
    return this.#frontierOrderLength;
  }
  get frontierMaxTimestampMs() {
    return this.#frontierMaxTimestampMs;
  }
  hasFrontierOp(opId) {
    return this.#frontierOpIds.has(opId);
  }
  /** Collect all CAS root hashes reachable from current state + retained suffix snapshots (for local GC). */
  gcRoots() {
    const roots = /* @__PURE__ */ new Set();
    roots.add(this.#seenOpsRoot);
    extractCasHashes(this.#topics, roots);
    for (const snap of this.#snapshots.values()) {
      roots.add(snap.seenOpsRoot);
      extractCasHashes(snap.topics, roots);
    }
    return roots;
  }
  get cacheRestores() {
    return this.#cacheRestores;
  }
  /** Export a self-verifying materialized cache snapshot for instant cold-open or suffix catch-up. */
  exportMaterializedCache() {
    return {
      v: 1,
      logId: this.logIdHex,
      blindHostMode: this.blindHostMode,
      topics: structuredClone(this.#topics),
      seenOpsRoot: this.#seenOpsRoot,
      historyDigest: this.#historyDigest,
      stateRoot: this.#stateRoot,
      orderOpIds: this.#order.map((item) => bytesToHex(item.opId)),
      outcomes: this.#outcomes.map((o) => ({
        opId: o.opId,
        author: o.author,
        operationId: o.operationId,
        authorTimestampMs: o.authorTimestampMs,
        visibility: o.visibility,
        outcome: o.outcome,
        rejectionCode: o.rejectionCode,
        ...o.rejectionDetail === void 0 ? {} : { rejectionDetail: o.rejectionDetail },
        events: o.events.map((e) => ({
          opId: e.opId,
          eventOrdinal: e.eventOrdinal,
          topic: e.topic,
          payload: structuredClone(e.payload),
          author: e.author,
          operationId: e.operationId,
          authorTimestampMs: e.authorTimestampMs
        }))
      }))
    };
  }
  /**
   * Restore materialized state directly from a previously exported cache if:
   * - logId, blindHostMode, and recomputed stateRoot match exactly,
   * - seenOpsRoot and every CAS node hash referenced by topics exist locally, and
   * - cache.orderOpIds is an exact prefix of canonically sorted `inputs`.
   * Returns true on cache hit (exact or suffix-catchup prefix), false on miss.
   */
  async restoreMaterializedCache(cache, inputs) {
    if (cache.v !== 1 || cache.logId !== this.logIdHex || cache.blindHostMode !== this.blindHostMode || !Array.isArray(cache.orderOpIds) || !Array.isArray(cache.outcomes) || cache.orderOpIds.length === 0 || cache.orderOpIds.length !== cache.outcomes.length) {
      return false;
    }
    if (computeStateRoot(cache.topics, cache.seenOpsRoot) !== cache.stateRoot) {
      return false;
    }
    const seenNode = await this.cas.get(cache.seenOpsRoot, "any");
    if (seenNode === null) return false;
    const neededCas = /* @__PURE__ */ new Set();
    extractRequiredCasHashes(cache.topics, neededCas);
    for (const hash of neededCas) {
      if (!this.cas.hasSync(hash, "any") && await this.cas.get(hash, "any") === null) {
        return false;
      }
    }
    let decodedSeen;
    try {
      const { assertCanonicalCbor, DEFAULT_DECODE_LIMITS } = await import("./src-ZNNATASY.mjs");
      const raw = normalizeJsonValue(JSON.parse(JSON.stringify(assertCanonicalCbor(seenNode.bytes, DEFAULT_DECODE_LIMITS))));
      if (!Array.isArray(raw)) return false;
      decodedSeen = raw.filter((v) => typeof v === "string");
    } catch {
      return false;
    }
    const eligible = [];
    const seenIds = /* @__PURE__ */ new Set();
    for (const item of inputs) {
      if (bytesToHex(item.core.logId) !== this.logIdHex) continue;
      if (this.blindHostMode && this.genesis.privateLog && item.core.visibility !== "public") continue;
      const opIdHex = bytesToHex(item.opId);
      if (seenIds.has(opIdHex)) continue;
      seenIds.add(opIdHex);
      eligible.push(item);
    }
    eligible.sort((a, b) => compareOperationOrder(
      { authorTimestampMs: a.core.authorTimestampMs, author: a.core.author, opId: a.opId },
      { authorTimestampMs: b.core.authorTimestampMs, author: b.core.author, opId: b.opId }
    ));
    const prefixLen = cache.orderOpIds.length;
    if (prefixLen > eligible.length) return false;
    for (let i = 0; i < prefixLen; i++) {
      if (bytesToHex(eligible[i].opId) !== cache.orderOpIds[i]) return false;
    }
    this.#order = eligible.slice(0, prefixLen);
    const cachedOutcomes = cache.outcomes;
    this.#outcomes = cachedOutcomes.map((o) => ({
      opId: o.opId,
      author: o.author,
      operationId: o.operationId,
      authorTimestampMs: BigInt(o.authorTimestampMs),
      visibility: o.visibility,
      outcome: o.outcome,
      rejectionCode: o.rejectionCode,
      ...o.rejectionDetail === void 0 ? {} : { rejectionDetail: o.rejectionDetail },
      events: o.events.map((e) => ({
        opId: e.opId,
        eventOrdinal: e.eventOrdinal,
        topic: e.topic,
        payload: structuredClone(e.payload),
        author: e.author,
        operationId: e.operationId,
        authorTimestampMs: BigInt(e.authorTimestampMs)
      }))
    }));
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(cache.topics)) : structuredClone(cache.topics);
    this.#seenOps = new Set(decodedSeen);
    this.#opOutcomes = /* @__PURE__ */ new Map();
    this.#topicLastOpIds = /* @__PURE__ */ new Map();
    for (let i = 0; i < this.#outcomes.length; i++) {
      const o = this.#outcomes[i];
      const entry = this.#order[i];
      this.#opOutcomes.set(o.opId, { outcome: o.outcome, visibility: o.visibility });
      if (o.outcome === "accepted") {
        for (const u of entry.core.updates) {
          this.#topicLastOpIds.set(u.topic, o.opId);
        }
      }
    }
    this.#seenOpsRoot = cache.seenOpsRoot;
    this.#historyDigest = cache.historyDigest;
    this.#stateRoot = cache.stateRoot;
    this.#pendingDependencies.clear();
    this.#skippedOpIds.clear();
    this.#snapshots.clear();
    this.#snapshots.set(0, this.#genesisSnapshot);
    this.#snapshots.set(prefixLen, this.#captureSnapshot(prefixLen));
    this.#cacheRestores++;
    return true;
  }
  /**
   * Bootstrap kernel state directly from a verified FinalityCheckpoint snapshot.
   * Restores both topicsMap, seenOpsRoot (consumed handles), and rolling historyDigest
   * so subsequent suffix replay produces identical stateRoot AND revision.digest.
   */
  async bootstrapFromCheckpoint(checkpoint) {
    const seenNode = await this.cas.get(checkpoint.seenOpsRoot, "any");
    if (seenNode === null) throw new MissingDependencyError(checkpoint.seenOpsRoot, "cas");
    const decodedSeen = normalizeJsonValue(
      JSON.parse(JSON.stringify(
        // Decode CBOR array of strings stored in seenOpsRoot
        await import("./src-ZNNATASY.mjs").then((m) => m.assertCanonicalCbor(seenNode.bytes, m.DEFAULT_DECODE_LIMITS))
      ))
    );
    const computedStateRoot = computeStateRoot(checkpoint.topics, checkpoint.seenOpsRoot);
    if (computedStateRoot !== checkpoint.stateRoot) {
      throw new Error(`CHECKPOINT_STATE_ROOT_MISMATCH: expected ${checkpoint.stateRoot}, got ${computedStateRoot}`);
    }
    this.#order = [];
    this.#outcomes = [];
    this.#opOutcomes.clear();
    this.#topicLastOpIds.clear();
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(checkpoint.topics)) : structuredClone(checkpoint.topics);
    this.#seenOps = new Set(decodedSeen);
    this.#seenOpsRoot = checkpoint.seenOpsRoot;
    this.#historyDigest = checkpoint.historyDigest;
    this.#stateRoot = checkpoint.stateRoot;
    this.#snapshots.clear();
    this.#snapshots.set(0, this.#captureSnapshot(0));
  }
  /**
   * Bootstrap kernel state directly from a host-cached encrypted Snapshot Bundle WITHOUT requiring
   * all historical operations to be downloaded first. Subsequent materialize(suffixInputs) skips
   * any op already covered by `frontierOpIds` and applies only new tail operations.
   */
  async restoreSnapshotFrontier(snapshot) {
    if (computeStateRoot(snapshot.topics, snapshot.seenOpsRoot) !== snapshot.stateRoot) {
      return false;
    }
    const seenNode = await this.cas.get(snapshot.seenOpsRoot, "any");
    if (seenNode === null) return false;
    const neededCas = /* @__PURE__ */ new Set();
    extractRequiredCasHashes(snapshot.topics, neededCas);
    for (const hash of neededCas) {
      if (!this.cas.hasSync(hash, "any") && await this.cas.get(hash, "any") === null) {
        return false;
      }
    }
    let decodedSeen;
    try {
      const { assertCanonicalCbor, DEFAULT_DECODE_LIMITS } = await import("./src-ZNNATASY.mjs");
      const raw = normalizeJsonValue(JSON.parse(JSON.stringify(assertCanonicalCbor(seenNode.bytes, DEFAULT_DECODE_LIMITS))));
      if (!Array.isArray(raw)) return false;
      decodedSeen = raw.filter((v) => typeof v === "string");
    } catch {
      return false;
    }
    this.#order = [];
    this.#outcomes = [];
    this.#opOutcomes.clear();
    this.#topicLastOpIds.clear();
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(snapshot.topics)) : structuredClone(snapshot.topics);
    this.#seenOps = new Set(decodedSeen);
    this.#seenOpsRoot = snapshot.seenOpsRoot;
    this.#historyDigest = snapshot.historyDigest;
    this.#stateRoot = snapshot.stateRoot;
    this.#frontierOpIds = new Set(snapshot.orderOpIds);
    this.#frontierOrderLength = snapshot.orderOpIds.length;
    this.#frontierMaxTimestampMs = snapshot.maxAuthorTimestampMs !== void 0 ? BigInt(snapshot.maxAuthorTimestampMs) : 0n;
    this.#pendingDependencies.clear();
    this.#skippedOpIds.clear();
    this.#snapshots.clear();
    this.#snapshots.set(0, this.#captureSnapshot(0));
    this.#cacheRestores++;
    return true;
  }
  /**
   * Deterministically materialize an eligible operation set (arbitrary input order; sorted internally).
   * Rewinds only to the earliest snapshot before the first changed position (suffix replay).
   */
  async materialize(inputs) {
    const eligible = [];
    const seenIds = /* @__PURE__ */ new Set();
    for (const item of inputs) {
      if (bytesToHex(item.core.logId) !== this.logIdHex) continue;
      if (this.blindHostMode && this.genesis.privateLog && item.core.visibility !== "public") continue;
      const opIdHex = bytesToHex(item.opId);
      if (this.#frontierOpIds.has(opIdHex)) continue;
      if (item.verified !== true && bytesToHex(operationIdDigest(item.core)) !== opIdHex) {
        throw new Error("KERNEL_OP_ID_MISMATCH");
      }
      if (seenIds.has(opIdHex)) continue;
      seenIds.add(opIdHex);
      eligible.push(item);
    }
    eligible.sort((a, b) => compareOperationOrder(
      { authorTimestampMs: a.core.authorTimestampMs, author: a.core.author, opId: a.opId },
      { authorTimestampMs: b.core.authorTimestampMs, author: b.core.author, opId: b.opId }
    ));
    let diff = 0;
    while (diff < this.#order.length && diff < eligible.length) {
      if (bytesToHex(this.#order[diff].opId) !== bytesToHex(eligible[diff].opId)) break;
      diff++;
    }
    if (diff === eligible.length && this.#order.length === eligible.length && this.#pendingDependencies.size === 0) {
      return {
        revision: this.revision("local"),
        outcomes: this.#outcomes.slice(),
        pendingDependencies: this.pendingDependencies,
        skippedOpIds: [...this.#skippedOpIds]
      };
    }
    if (this.#pendingDependencies.size > 0) diff = 0;
    let snapIndex = 0;
    for (const idx of this.#snapshots.keys()) {
      if (idx <= diff && idx > snapIndex) snapIndex = idx;
    }
    const snap = this.#snapshots.get(snapIndex);
    const work = {
      topics: structuredClone(snap.topics),
      seenOps: new Set(snap.seenOps),
      opOutcomes: new Map(snap.opOutcomes),
      topicLastOpIds: new Map(snap.topicLastOpIds),
      seenOpsRoot: snap.seenOpsRoot,
      historyDigest: snap.historyDigest,
      stateRoot: snap.stateRoot
    };
    const nextSnapshots = /* @__PURE__ */ new Map();
    for (const [idx, s] of this.#snapshots) {
      if (idx <= snapIndex && (idx === 0 || idx % this.#snapshotInterval === 0 || idx === snapIndex)) {
        nextSnapshots.set(idx, s);
      }
    }
    const nextOutcomes = this.#outcomes.slice(0, snapIndex);
    const nextOrder = this.#order.slice(0, snapIndex);
    const nextPendingDeps = /* @__PURE__ */ new Set();
    const nextSkippedOps = /* @__PURE__ */ new Set();
    this.cas.beginBatch();
    try {
      for (let i = snapIndex; i < eligible.length; i++) {
        const entry = eligible[i];
        const opIdHex = bytesToHex(entry.opId);
        const authorHex = bytesToHex(entry.core.author);
        const step = await this.#applyOne(work, entry, opIdHex, authorHex);
        if (step.kind === "missing") {
          nextPendingDeps.add(step.dependency);
          nextSkippedOps.add(opIdHex);
          break;
        }
        nextOrder.push(entry);
        nextOutcomes.push(step.outcome);
        if (nextOrder.length % this.#snapshotInterval === 0) {
          nextSnapshots.set(nextOrder.length, this.#captureSnapshotFrom(work, nextOrder.length));
        }
      }
      if (nextOrder.length > 0 && !nextSnapshots.has(nextOrder.length)) {
        for (const idx of [...nextSnapshots.keys()]) {
          if (idx > 0 && idx % this.#snapshotInterval !== 0) nextSnapshots.delete(idx);
        }
        nextSnapshots.set(nextOrder.length, this.#captureSnapshotFrom(work, nextOrder.length));
      }
      await this.cas.flushBatch();
      this.#topics = work.topics;
      this.#seenOps = work.seenOps;
      this.#opOutcomes = work.opOutcomes;
      this.#topicLastOpIds = work.topicLastOpIds;
      this.#seenOpsRoot = work.seenOpsRoot;
      this.#historyDigest = work.historyDigest;
      this.#stateRoot = work.stateRoot;
      this.#order = nextOrder;
      this.#outcomes = nextOutcomes;
      this.#pendingDependencies = nextPendingDeps;
      this.#skippedOpIds = nextSkippedOps;
      this.#snapshots = nextSnapshots;
    } catch (err) {
      this.cas.rollbackBatch();
      throw err;
    }
    return {
      revision: this.revision("local"),
      outcomes: this.#outcomes.slice(),
      pendingDependencies: this.pendingDependencies,
      skippedOpIds: [...this.#skippedOpIds]
    };
  }
  async #applyOne(work, entry, opIdHex, authorHex) {
    const core = entry.core;
    const makeRejected = (code, detail, extra) => {
      const evs = extra?.events ?? [];
      const outcome = {
        opId: opIdHex,
        author: authorHex,
        operationId: core.operationId,
        authorTimestampMs: core.authorTimestampMs,
        visibility: core.visibility,
        outcome: "rejected",
        rejectionCode: code,
        ...detail === void 0 ? {} : { rejectionDetail: detail },
        ...extra?.conflictRecorded === true ? { conflictRecorded: true } : {},
        events: evs
      };
      work.opOutcomes.set(opIdHex, { outcome: "rejected", visibility: core.visibility });
      work.historyDigest = advanceHistoryDigest(work.historyDigest, opIdHex, "rejected", code, evs);
      return { kind: "done", outcome };
    };
    if (this.genesis.privateLog) {
      if (core.visibility === "public") {
        if (core.updates.some((u) => !isControlTopic(u.topic))) {
          return makeRejected("partition:public_op_private_topic");
        }
      } else {
        if (core.updates.some((u) => isControlTopic(u.topic))) {
          return makeRejected("partition:encrypted_op_control_topic");
        }
      }
    }
    if (core.updates.length > this.genesis.limits.maxUpdatesPerOp) {
      return makeRejected("limit:max_updates_per_op");
    }
    const dedupKey = seenOpKey(core.visibility, authorHex, core.operationId);
    if (work.seenOps.has(dedupKey)) {
      return makeRejected("operation_conflict");
    }
    const casPartition = this.genesis.privateLog && core.visibility === "public" ? "public" : "private";
    const isPublicOnPrivate = this.genesis.privateLog && core.visibility === "public";
    const buildVisibleOutcomes = () => {
      const out = {};
      for (const [k, rec] of work.opOutcomes) {
        if (isPublicOnPrivate && rec.visibility !== "public") continue;
        out[k] = rec.outcome;
      }
      return out;
    };
    const buildVisibleTopicLastOpIds = () => {
      const out = {};
      for (const [topicName, lastId] of work.topicLastOpIds) {
        if (isPublicOnPrivate && !isControlTopic(topicName)) continue;
        out[topicName] = lastId;
      }
      return out;
    };
    if (core.assumptions !== void 0 && core.assumptions.checks.length > 0) {
      const visibleTopicsForAssumptions = isPublicOnPrivate ? filterPublicTopics(work.topics) : work.topics;
      const visibleOutcomes = buildVisibleOutcomes();
      const visibleTopicLastOps = buildVisibleTopicLastOpIds();
      let failure = null;
      for (let i = 0; i < core.assumptions.checks.length; i++) {
        const chk = core.assumptions.checks[i];
        if (chk.kind === "op_accepted") {
          const st = Object.hasOwn(visibleOutcomes, chk.opId) ? visibleOutcomes[chk.opId] : void 0;
          if (st === void 0) {
            failure = { code: "assumption:missing_op", detail: `Required op ${chk.opId} not present`, checkIndex: i };
            break;
          }
          if (st !== "accepted") {
            failure = { code: "assumption:dependency_rejected", detail: `Required op ${chk.opId} was rejected`, checkIndex: i };
            break;
          }
        } else if (chk.kind === "op_rejected") {
          const st = Object.hasOwn(visibleOutcomes, chk.opId) ? visibleOutcomes[chk.opId] : void 0;
          if (st === void 0) {
            failure = { code: "assumption:missing_op", detail: `Referenced op ${chk.opId} not present`, checkIndex: i };
            break;
          }
          if (st !== "rejected") {
            failure = { code: "assumption:expected_rejected", detail: `Expected op ${chk.opId} to be rejected`, checkIndex: i };
            break;
          }
        } else if (chk.kind === "topic_revision") {
          if (isPublicOnPrivate && !isControlTopic(chk.topic)) {
            failure = { code: "partition:public_op_private_assumption", detail: `Public op cannot assume private topic ${chk.topic}`, checkIndex: i };
            break;
          }
          const actual = Object.hasOwn(visibleTopicLastOps, chk.topic) ? visibleTopicLastOps[chk.topic] : null;
          if (actual !== chk.lastOpId) {
            failure = { code: "assumption:topic_modified", detail: `Topic ${chk.topic} lastOpId expected ${String(chk.lastOpId)}, got ${String(actual)}`, checkIndex: i };
            break;
          }
        } else if (chk.kind === "query_match") {
          if (isPublicOnPrivate && !isControlTopic(chk.topic)) {
            failure = { code: "partition:public_op_private_assumption", detail: `Public op cannot query private topic ${chk.topic}`, checkIndex: i };
            break;
          }
          let reducersConfig;
          try {
            reducersConfig = assertValidReducersConfig(work.topics.$reducers);
          } catch (err) {
            failure = { code: "reducers_config_invalid", detail: err instanceof Error ? err.message : String(err), checkIndex: i };
            break;
          }
          const binding = reducersConfig.topics[chk.topic];
          const topicState = Object.hasOwn(visibleTopicsForAssumptions, chk.topic) ? visibleTopicsForAssumptions[chk.topic] : null;
          let actualValue = topicState;
          if (binding !== void 0) {
            let qRes;
            try {
              qRes = await this.sandbox.invoke({
                imports: reducersConfig.imports,
                builtins: reducersConfig.runtime.builtins,
                topicBindings: reducersConfig.topics,
                moduleSpecifier: binding.module,
                exportName: binding.export ?? "default",
                method: "query",
                state: topicState,
                payload: chk.query,
                opOutcomes: visibleOutcomes,
                topicLastOpIds: visibleTopicLastOps,
                topics: visibleTopicsForAssumptions,
                ...binding.config === void 0 ? {} : { config: binding.config },
                cas: this.cas,
                casPartition: isPublicOnPrivate || isControlTopic(chk.topic) ? "public" : "private",
                readOnly: true,
                maxMemoryBytes: this.genesis.limits.maxMemoryBytes
              });
            } catch (err) {
              if (err instanceof MissingDependencyError) {
                return { kind: "missing", dependency: `${err.kind}/${err.hash}` };
              }
              throw err;
            }
            if (!qRes.ok) {
              if (qRes.code !== "vm:missing_method:query") {
                failure = { code: "assumption:query_failed", detail: qRes.detail ?? qRes.code, checkIndex: i };
                break;
              }
            } else {
              actualValue = qRes.value;
            }
          }
          if (canonicalJson(actualValue) !== canonicalJson(chk.expect)) {
            failure = { code: "assumption:query_mismatch", detail: `Query assumption ${i} on ${chk.topic} did not match`, checkIndex: i };
            break;
          }
        }
      }
      if (failure !== null) {
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        if (core.assumptions.onFailed === "record_conflict" && failure.code !== "partition:public_op_private_assumption") {
          const primaryUpdate = core.updates[0];
          let reducersConfig = null;
          try {
            reducersConfig = assertValidReducersConfig(work.topics.$reducers);
          } catch {
          }
          const binding = reducersConfig?.topics[primaryUpdate.topic];
          if (reducersConfig !== null && binding !== void 0) {
            const curTopicState = Object.hasOwn(work.topics, primaryUpdate.topic) ? work.topics[primaryUpdate.topic] : null;
            let conflictRes;
            try {
              conflictRes = await this.sandbox.invoke({
                imports: reducersConfig.imports,
                builtins: reducersConfig.runtime.builtins,
                topicBindings: reducersConfig.topics,
                moduleSpecifier: binding.module,
                exportName: binding.export ?? "default",
                method: "onConflict",
                state: curTopicState,
                payload: primaryUpdate.input,
                tx: {
                  opId: opIdHex,
                  author: authorHex,
                  authorTimestampMs: Number(core.authorTimestampMs),
                  operationId: core.operationId
                },
                conflict: failure,
                opOutcomes: visibleOutcomes,
                topicLastOpIds: visibleTopicLastOps,
                topics: visibleTopicsForAssumptions,
                ...binding.config === void 0 ? {} : { config: binding.config },
                cas: this.cas,
                casPartition,
                readOnly: false,
                maxMemoryBytes: this.genesis.limits.maxMemoryBytes
              });
            } catch (err) {
              if (err instanceof MissingDependencyError) {
                return { kind: "missing", dependency: `${err.kind}/${err.hash}` };
              }
              throw err;
            }
            if (conflictRes.ok && conflictRes.value !== null && typeof conflictRes.value === "object" && !Array.isArray(conflictRes.value)) {
              const outRec = conflictRes.value;
              if (outRec.ok === true) {
                const nextTopicState = outRec.state === void 0 ? null : outRec.state;
                const encodedTopic = encodeCanonicalJsonCbor(nextTopicState);
                if (encodedTopic.length <= this.genesis.limits.maxTopicStateBytes) {
                  const conflictEvents = [];
                  let ord = 0;
                  if (Array.isArray(outRec.events)) {
                    for (const rawEv of outRec.events) {
                      if (rawEv !== null && typeof rawEv === "object" && !Array.isArray(rawEv)) {
                        const ev = rawEv;
                        if (typeof ev.topic === "string") {
                          conflictEvents.push({
                            opId: opIdHex,
                            eventOrdinal: ord++,
                            topic: ev.topic,
                            payload: ev.payload ?? null,
                            author: authorHex,
                            operationId: core.operationId,
                            authorTimestampMs: core.authorTimestampMs
                          });
                        }
                      }
                    }
                  }
                  work.topics = { ...work.topics, [primaryUpdate.topic]: nextTopicState };
                  work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
                  return makeRejected(failure.code, failure.detail, { conflictRecorded: true, events: conflictEvents });
                }
              }
            }
          }
        }
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected(failure.code, failure.detail);
      }
    }
    const workingTopics = structuredClone(work.topics);
    const emitted = [];
    let ordinal = 0;
    const visibleOutcomesForReduce = buildVisibleOutcomes();
    const visibleTopicLastOpsForReduce = buildVisibleTopicLastOpIds();
    for (const update of core.updates) {
      let reducersConfig;
      try {
        reducersConfig = assertValidReducersConfig(workingTopics.$reducers);
      } catch (err) {
        return makeRejected("reducers_config_invalid", err instanceof Error ? err.message : String(err));
      }
      const binding = reducersConfig.topics[update.topic];
      if (binding === void 0) {
        return makeRejected(update.topic === "$reducers" ? "reducers_frozen" : `no_reducer:${update.topic}`);
      }
      const visibleTopics = this.genesis.privateLog && core.visibility === "public" ? filterPublicTopics(workingTopics) : workingTopics;
      const curTopicState = Object.hasOwn(workingTopics, update.topic) ? workingTopics[update.topic] : null;
      let res;
      try {
        res = await this.sandbox.invoke({
          imports: reducersConfig.imports,
          builtins: reducersConfig.runtime.builtins,
          topicBindings: reducersConfig.topics,
          moduleSpecifier: binding.module,
          exportName: binding.export ?? "default",
          method: "reduce",
          state: curTopicState,
          payload: update.input,
          tx: {
            opId: opIdHex,
            author: authorHex,
            authorTimestampMs: Number(core.authorTimestampMs),
            operationId: core.operationId
          },
          opOutcomes: visibleOutcomesForReduce,
          topicLastOpIds: visibleTopicLastOpsForReduce,
          topics: visibleTopics,
          ...binding.config === void 0 ? {} : { config: binding.config },
          cas: this.cas,
          casPartition,
          readOnly: false,
          maxMemoryBytes: this.genesis.limits.maxMemoryBytes
        });
      } catch (err) {
        if (err instanceof MissingDependencyError) {
          return { kind: "missing", dependency: `${err.kind}/${err.hash}` };
        }
        throw err;
      }
      if (!res.ok) {
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected(res.code, res.detail);
      }
      const outObj = res.value;
      if (outObj === null || typeof outObj !== "object" || Array.isArray(outObj)) {
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected("vm:invalid_reducer_return");
      }
      const outRec = outObj;
      if (typeof outRec.ok !== "boolean") {
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected("vm:invalid_reducer_return");
      }
      if (!outRec.ok) {
        const rejCode = typeof outRec.code === "string" && outRec.code.length > 0 ? outRec.code : "reducer:rejected";
        const rejDetail = typeof outRec.detail === "string" ? outRec.detail : void 0;
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected(rejCode, rejDetail);
      }
      const nextTopicState = outRec.state === void 0 ? null : outRec.state;
      const encodedTopic = encodeCanonicalJsonCbor(nextTopicState);
      if (encodedTopic.length > this.genesis.limits.maxTopicStateBytes) {
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected("limit:max_topic_state_bytes");
      }
      if (update.topic === "$reducers") {
        try {
          assertValidReducersConfig(nextTopicState);
        } catch (err) {
          work.seenOps.add(dedupKey);
          work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
          work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
          return makeRejected("reducers_config_invalid", err instanceof Error ? err.message : String(err));
        }
      }
      workingTopics[update.topic] = nextTopicState;
      if (Array.isArray(outRec.events)) {
        for (const rawEv of outRec.events) {
          if (rawEv !== null && typeof rawEv === "object" && !Array.isArray(rawEv)) {
            const ev = rawEv;
            if (typeof ev.topic === "string") {
              emitted.push({
                opId: opIdHex,
                eventOrdinal: ordinal++,
                topic: ev.topic,
                payload: ev.payload ?? null,
                author: authorHex,
                operationId: core.operationId,
                authorTimestampMs: core.authorTimestampMs
              });
            }
          }
        }
      }
    }
    work.seenOps.add(dedupKey);
    work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
    work.topics = workingTopics;
    work.opOutcomes.set(opIdHex, { outcome: "accepted", visibility: core.visibility });
    for (const u of core.updates) {
      work.topicLastOpIds.set(u.topic, opIdHex);
    }
    work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
    work.historyDigest = advanceHistoryDigest(work.historyDigest, opIdHex, "accepted", null, emitted);
    return {
      kind: "done",
      outcome: {
        opId: opIdHex,
        author: authorHex,
        operationId: core.operationId,
        authorTimestampMs: core.authorTimestampMs,
        visibility: core.visibility,
        outcome: "accepted",
        rejectionCode: null,
        events: emitted
      }
    };
  }
  /** Execute a pure read-only query against a topic's query() export (or return raw topic state if no query export). */
  async query(topic, input = null, topicsOverride) {
    const sourceTopics = topicsOverride ?? this.#topics;
    const normalizedInput = normalizeJsonValue(input);
    let cacheKey = null;
    if (topicsOverride === void 0) {
      if (this.#queryCacheStateRoot !== this.#stateRoot) {
        this.#queryCache.clear();
        this.#queryCacheStateRoot = this.#stateRoot;
      }
      cacheKey = `${topic}\0${bytesToHex(encodeCanonicalJsonCbor(normalizedInput))}`;
      const hit = this.#queryCache.get(cacheKey);
      if (hit !== void 0) {
        this.#queryCache.delete(cacheKey);
        this.#queryCache.set(cacheKey, hit);
        return structuredClone(hit);
      }
    }
    const reducersConfig = assertValidReducersConfig(sourceTopics.$reducers);
    const binding = reducersConfig.topics[topic];
    const state = Object.hasOwn(sourceTopics, topic) ? sourceTopics[topic] : null;
    if (binding === void 0) return structuredClone(state);
    const casPartition = this.genesis.privateLog && isControlTopic(topic) ? "public" : "private";
    const visibleTopics = this.genesis.privateLog && isControlTopic(topic) ? filterPublicTopics(sourceTopics) : sourceTopics;
    const res = await this.sandbox.invoke({
      imports: reducersConfig.imports,
      builtins: reducersConfig.runtime.builtins,
      topicBindings: reducersConfig.topics,
      moduleSpecifier: binding.module,
      exportName: binding.export ?? "default",
      method: "query",
      state,
      payload: normalizedInput,
      topics: visibleTopics,
      ...binding.config === void 0 ? {} : { config: binding.config },
      cas: this.cas,
      casPartition,
      readOnly: true,
      maxMemoryBytes: this.genesis.limits.maxMemoryBytes
    });
    if (!res.ok) {
      if (res.code === "vm:missing_method:query") return structuredClone(state);
      throw new Error(`KERNEL_QUERY_FAILED:${res.code}:${res.detail ?? ""}`);
    }
    if (cacheKey !== null && this.#queryCacheStateRoot === this.#stateRoot) {
      this.#queryCache.set(cacheKey, structuredClone(res.value));
      if (this.#queryCache.size > 128) {
        const oldest = this.#queryCache.keys().next().value;
        if (oldest !== void 0) this.#queryCache.delete(oldest);
      }
    }
    return res.value;
  }
  /**
   * Time-travel materialization: reconstructs the exact coherent state at a specific opId
   * or at/before a timestamp without mutating live kernel state.
   */
  async materializeAt(target) {
    let targetLen = 0;
    if ("opId" in target) {
      const idx = this.#order.findIndex((item) => bytesToHex(item.opId) === target.opId);
      if (idx < 0) throw new Error(`TIME_TRAVEL_OP_NOT_FOUND:${target.opId}`);
      targetLen = idx + 1;
    } else {
      for (let i = 0; i < this.#order.length; i++) {
        if (this.#order[i].core.authorTimestampMs <= target.atTimestampMs) {
          targetLen = i + 1;
        } else {
          break;
        }
      }
    }
    let snapIndex = 0;
    for (const idx of this.#snapshots.keys()) {
      if (idx <= targetLen && idx > snapIndex) snapIndex = idx;
    }
    const snap = this.#snapshots.get(snapIndex);
    const work = {
      topics: structuredClone(snap.topics),
      seenOps: new Set(snap.seenOps),
      opOutcomes: new Map(snap.opOutcomes),
      topicLastOpIds: new Map(snap.topicLastOpIds),
      seenOpsRoot: snap.seenOpsRoot,
      historyDigest: snap.historyDigest,
      stateRoot: snap.stateRoot
    };
    this.cas.beginBatch();
    try {
      for (let i = snapIndex; i < targetLen; i++) {
        const entry = this.#order[i];
        const opIdHex = bytesToHex(entry.opId);
        const authorHex = bytesToHex(entry.core.author);
        const step = await this.#applyOne(work, entry, opIdHex, authorHex);
        if (step.kind === "missing") {
          throw new MissingDependencyError(step.dependency.split("/")[1] ?? step.dependency, "cas");
        }
      }
      this.cas.rollbackBatch();
    } catch (err) {
      this.cas.rollbackBatch();
      throw err;
    }
    const revision = {
      stateRoot: work.stateRoot,
      historyDigest: work.historyDigest,
      digest: computeRevisionDigest(work.historyDigest, work.stateRoot, "local", this.#policyContextDigest),
      view: "local",
      orderLength: targetLen
    };
    return {
      revision,
      topics: structuredClone(work.topics),
      orderLength: targetLen,
      targetOpId: targetLen > 0 ? bytesToHex(this.#order[targetLen - 1].opId) : null
    };
  }
  /** Execute a read-only query against a historical revision (by opId or timestamp). */
  async queryAt(topic, input, target) {
    const snap = await this.materializeAt(target);
    const value = await this.query(topic, input, snap.topics);
    return { revision: snap.revision, targetOpId: snap.targetOpId, value };
  }
  /** Collect exported command/query descriptions across all bound topics (for MCP & scoped tools). */
  async describe() {
    if (this.#cachedDescribe !== null && this.#cachedDescribe.stateRoot === this.#stateRoot) {
      return structuredClone(this.#cachedDescribe.value);
    }
    const reducersConfig = assertValidReducersConfig(this.#topics.$reducers);
    const out = {};
    for (const [topic, binding] of Object.entries(reducersConfig.topics)) {
      if (this.blindHostMode && this.genesis.privateLog && !isControlTopic(topic)) continue;
      const state = Object.hasOwn(this.#topics, topic) ? this.#topics[topic] : null;
      const casPartition = this.genesis.privateLog && isControlTopic(topic) ? "public" : "private";
      const res = await this.sandbox.invoke({
        imports: reducersConfig.imports,
        builtins: reducersConfig.runtime.builtins,
        topicBindings: reducersConfig.topics,
        moduleSpecifier: binding.module,
        exportName: binding.export ?? "default",
        method: "describe",
        state,
        payload: null,
        topics: this.blindHostMode ? filterPublicTopics(this.#topics) : this.#topics,
        ...binding.config === void 0 ? {} : { config: binding.config },
        cas: this.cas,
        casPartition,
        readOnly: true,
        maxMemoryBytes: this.genesis.limits.maxMemoryBytes
      });
      if (res.ok) out[topic] = res.value;
    }
    this.#cachedDescribe = { stateRoot: this.#stateRoot, value: structuredClone(out) };
    return out;
  }
  /** Evaluate signal authorization policy for the current stateRoot (cached by caller per stateRoot). */
  async signalPolicy() {
    const reducersConfig = assertValidReducersConfig(this.#topics.$reducers);
    if (reducersConfig.topics.$signal_policy !== void 0) {
      const val = await this.query("$signal_policy", null);
      if (val !== null && typeof val === "object" && !Array.isArray(val) && Array.isArray(val.rules)) {
        return val;
      }
    }
    const queriedReaders = await this.query("$permissions", { list: "readers" }).catch(() => null);
    if (Array.isArray(queriedReaders) && queriedReaders.every((x) => typeof x === "string")) {
      return {
        rules: [{ topicPattern: "*", allowedAuthors: queriedReaders, maxTtlMs: 3e4, allowRelay: true }]
      };
    }
    const perms = this.#topics.$permissions;
    const readers = (perms?.members ?? []).filter((m) => m.reader).map((m) => m.publicKey);
    return {
      rules: [{ topicPattern: "*", allowedAuthors: readers, maxTtlMs: 3e4, allowRelay: true }]
    };
  }
};

export {
  MissingDependencyError,
  OperationalTimeoutError,
  QuickJsSandbox,
  TopicKernel
};
