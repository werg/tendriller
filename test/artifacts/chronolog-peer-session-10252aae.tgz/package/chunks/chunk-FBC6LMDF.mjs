import {
  DEFAULT_DECODE_LIMITS,
  assertCanonicalCbor,
  bytesToHex,
  encodeCanonicalCbor,
  equalBytes,
  hashDomainSync,
  hexToBytes
} from "./chunk-ICYUPG2X.mjs";

// packages/records/src/bytes-store.ts
var MemoryBytesStore = class {
  #values = /* @__PURE__ */ new Map();
  #changelog = [];
  #seq = 0;
  #quotaBytes;
  #maxValueBytes;
  #usedBytes = 0;
  constructor(options = {}) {
    for (const limit of [options.quotaBytes, options.maxValueBytes]) {
      if (limit !== void 0 && (!Number.isSafeInteger(limit) || limit < 1)) throw new Error("BYTES_STORE_QUOTA_INVALID");
    }
    this.#quotaBytes = options.quotaBytes ?? Infinity;
    this.#maxValueBytes = options.maxValueBytes ?? Infinity;
  }
  #recordChange(key, deleted) {
    this.#changelog.push({ seq: ++this.#seq, key, deleted });
    if (this.#changelog.length > 16384) this.#changelog.splice(0, this.#changelog.length - 8192);
  }
  async get(key) {
    return this.#values.get(key)?.slice() ?? null;
  }
  async put(key, bytes) {
    if (!(bytes instanceof Uint8Array) || bytes.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    const used = this.#usedBytes - (this.#values.get(key)?.byteLength ?? 0) + bytes.byteLength;
    if (used > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    this.#values.set(key, Uint8Array.from(bytes));
    this.#usedBytes = used;
    this.#recordChange(key, false);
  }
  async putMany(entries) {
    if (entries.length === 0) return;
    const staged = /* @__PURE__ */ new Map();
    for (const entry of entries) {
      if (!(entry.value instanceof Uint8Array) || entry.value.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
      staged.set(entry.key, Uint8Array.from(entry.value));
    }
    let used = this.#usedBytes;
    for (const [key, value] of staged) used = used - (this.#values.get(key)?.byteLength ?? 0) + value.byteLength;
    if (used > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    for (const [key, value] of staged) {
      this.#values.set(key, value);
      this.#recordChange(key, false);
    }
    this.#usedBytes = used;
  }
  async delete(key) {
    if (this.#values.has(key)) {
      this.#usedBytes -= this.#values.get(key)?.byteLength ?? 0;
      this.#values.delete(key);
      this.#recordChange(key, true);
    }
  }
  async deleteMany(keys) {
    for (const key of keys) {
      if (this.#values.has(key)) {
        this.#usedBytes -= this.#values.get(key)?.byteLength ?? 0;
        this.#values.delete(key);
        this.#recordChange(key, true);
      }
    }
  }
  async putAllIfEmpty(entries) {
    const captured = entries.map((entry) => ({ key: entry.key, value: Uint8Array.from(entry.value) }));
    if (new Set(captured.map((entry) => entry.key)).size !== captured.length) throw new Error("BYTES_STORE_DUPLICATE_KEY");
    if (captured.some((entry) => entry.value.byteLength > this.#maxValueBytes)) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    const bytes = captured.reduce((sum, entry) => sum + entry.value.byteLength, 0);
    if (bytes > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    if (this.#values.size !== 0) return false;
    for (const entry of captured) {
      this.#values.set(entry.key, entry.value);
      this.#recordChange(entry.key, false);
    }
    this.#usedBytes = bytes;
    return true;
  }
  async *iterateEntries() {
    const snapshot = [...this.#values].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    for (const [key, value] of snapshot) yield { key, value: value.slice() };
  }
  async *iteratePrefix(prefix) {
    const snapshot = [...this.#values].filter(([k]) => k.startsWith(prefix)).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    for (const [key, value] of snapshot) yield { key, value: value.slice() };
  }
  async latestChangeSeq() {
    return this.#seq;
  }
  async readChangesSince(afterSeq) {
    return {
      latestSeq: this.#seq,
      changes: this.#changelog.filter((c) => c.seq > afterSeq)
    };
  }
  async putStreamIfEmpty(entries) {
    if (this.#values.size !== 0) return false;
    const staged = /* @__PURE__ */ new Map();
    let bytes = 0;
    for await (const entry of entries) {
      if (staged.has(entry.key)) throw new Error("BYTES_STORE_DUPLICATE_KEY");
      if (!(entry.value instanceof Uint8Array) || entry.value.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
      bytes += entry.value.length;
      if (bytes > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
      staged.set(entry.key, Uint8Array.from(entry.value));
    }
    if (this.#values.size !== 0) return false;
    for (const [key, value] of staged) {
      this.#values.set(key, value);
      this.#recordChange(key, false);
    }
    this.#usedBytes = bytes;
    return true;
  }
  async entries() {
    return [...this.#values.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, value]) => ({ key, value: value.slice() }));
  }
};
async function writeBytesMany(store, entries, options) {
  if (entries.length === 0) return;
  if (entries.length === 1) {
    await store.put(entries[0].key, entries[0].value, options);
    return;
  }
  if (store.putMany !== void 0) {
    await store.putMany(entries, options);
    return;
  }
  for (const entry of entries) await store.put(entry.key, entry.value, options);
}
async function deleteBytesMany(store, keys, options) {
  if (keys.length === 0) return;
  if (store.deleteMany !== void 0) {
    await store.deleteMany(keys, options);
    return;
  }
  if (store.delete === void 0) return;
  for (const key of keys) await store.delete(key, options);
}

// packages/records/src/cas.ts
var HEX32 = /^[0-9a-f]{64}$/u;
function assertHashHex(hash) {
  if (!HEX32.test(hash)) throw new Error(`CAS_HASH_INVALID: ${hash}`);
}
function encodeCasNode(bytes, links = []) {
  const unique = [...new Set(links)].sort();
  for (const hash of unique) assertHashHex(hash);
  const linkBytes = unique.map((h) => hexToBytes(h));
  return encodeCanonicalCbor([bytes, linkBytes]);
}
function decodeCasNode(encoded) {
  const decoded = assertCanonicalCbor(encoded, DEFAULT_DECODE_LIMITS);
  if (!Array.isArray(decoded) || decoded.length !== 2) throw new Error("CAS_NODE_INVALID");
  const [bytes, rawLinks] = decoded;
  if (!(bytes instanceof Uint8Array) || !Array.isArray(rawLinks)) throw new Error("CAS_NODE_INVALID");
  const links = [];
  for (const item of rawLinks) {
    if (!(item instanceof Uint8Array) || item.length !== 32) throw new Error("CAS_NODE_LINK_INVALID");
    links.push(bytesToHex(item));
  }
  return { bytes: bytes.slice(), links };
}
function hashCasNode(encoded) {
  return bytesToHex(hashDomainSync("cas", encoded));
}
function computeCasHash(bytes, links = []) {
  return hashCasNode(encodeCasNode(bytes, links));
}
var ContentAddressedStore = class {
  #store;
  #prefix;
  #maxCacheEntries;
  #maxChunkBytes;
  #cache = /* @__PURE__ */ new Map();
  #staged = /* @__PURE__ */ new Map();
  #known = /* @__PURE__ */ new Map();
  #inBatch = false;
  constructor(options) {
    this.#store = options.store;
    this.#prefix = options.prefix ?? "cas/";
    this.#maxCacheEntries = options.maxCacheEntries ?? 4096;
    this.#maxChunkBytes = options.maxChunkBytes ?? 4 * 1024 * 1024;
  }
  #key(partition, hash) {
    return `${this.#prefix}${partition === "public" ? "pub" : "priv"}/${hash}`;
  }
  #touchCache(hash, encoded, node, partition) {
    const existing = this.#cache.get(hash);
    if (existing !== void 0) {
      existing.partitions.add(partition);
      this.#cache.delete(hash);
      this.#cache.set(hash, existing);
      return;
    }
    this.#cache.set(hash, { encoded, node, partitions: /* @__PURE__ */ new Set([partition]) });
    while (this.#cache.size > this.#maxCacheEntries) {
      const oldest = this.#cache.keys().next().value;
      if (oldest === void 0) break;
      this.#cache.delete(oldest);
    }
  }
  /** Preload persisted CAS entries from BytesStore into the in-memory index/cache. */
  async preload() {
    if (this.#store.iteratePrefix !== void 0) {
      for await (const entry of this.#store.iteratePrefix(this.#prefix)) this.indexPersistedEntry(entry);
      return;
    }
    if (this.#store.iterateEntries !== void 0) {
      for await (const entry of this.#store.iterateEntries()) this.indexPersistedEntry(entry);
      return;
    }
    if (this.#store.entries !== void 0) {
      for (const entry of await this.#store.entries()) this.indexPersistedEntry(entry);
    }
  }
  /**
   * Index a single persisted BytesStore entry if it belongs to this CAS prefix.
   * Returns true if the key was a CAS entry (allowing single-pass hydration in ApplicationSession.open).
   */
  indexPersistedEntry(entry, options = {}) {
    if (!entry.key.startsWith(this.#prefix)) return false;
    const rest = entry.key.slice(this.#prefix.length);
    let partition;
    let hash;
    if (rest.startsWith("pub/")) {
      partition = "public";
      hash = rest.slice(4);
    } else if (rest.startsWith("priv/")) {
      partition = "private";
      hash = rest.slice(5);
    } else return true;
    if (!HEX32.test(hash)) return true;
    const verifyHash = options.verifyHash ?? true;
    if (verifyHash) {
      const verifiedHash = hashCasNode(entry.value);
      if (verifiedHash !== hash) throw new Error(`CAS_CORRUPT: ${hash}`);
    }
    const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
    parts.add(partition);
    this.#known.set(hash, parts);
    const shouldPreload = options.preloadCache ?? (partition === "public" || this.#cache.size < this.#maxCacheEntries);
    if (shouldPreload) {
      const node = decodeCasNode(entry.value);
      this.#touchCache(hash, entry.value, node, partition);
    }
    return true;
  }
  /** Begin a staged replay batch: synchronous puts stay in RAM until flushBatch(). */
  beginBatch() {
    if (this.#inBatch) throw new Error("CAS_BATCH_ALREADY_ACTIVE");
    this.#inBatch = true;
  }
  /** Discard all uncommitted staged writes from the active batch. */
  rollbackBatch() {
    this.#staged.clear();
    this.#inBatch = false;
  }
  /** Persist staged chunks (optionally filtered to a reachable set) to BytesStore in one flush. */
  async flushBatch(keepHashes) {
    if (!this.#inBatch) return;
    const entries = [];
    for (const [hash, item] of this.#staged) {
      if (keepHashes !== void 0 && !keepHashes.has(hash)) continue;
      const known = this.#known.get(hash);
      if (known?.has(item.partition)) continue;
      entries.push({ key: this.#key(item.partition, hash), value: item.encoded });
    }
    for (let i = 0; i < entries.length; i += 128) {
      await writeBytesMany(this.#store, entries.slice(i, i + 128), { durability: "relaxed" });
    }
    for (const [hash, item] of this.#staged) {
      if (keepHashes !== void 0 && !keepHashes.has(hash)) continue;
      const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
      parts.add(item.partition);
      this.#known.set(hash, parts);
      this.#touchCache(hash, item.encoded, item.node, item.partition);
    }
    this.#staged.clear();
    this.#inBatch = false;
  }
  /** Synchronous put into staged RAM (or cache) for deterministic reducer execution. */
  putSync(bytes, links = [], partition = "private") {
    if (bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
    const encoded = encodeCasNode(bytes, links);
    const hash = hashCasNode(encoded);
    const node = { bytes: bytes.slice(), links: [...new Set(links)].sort() };
    this.#staged.set(hash, { encoded, node, partition });
    this.#touchCache(hash, encoded, node, partition);
    return hash;
  }
  /** Async durable put (for seeding modules, syncing blobs from peers, or outside a batch). */
  async put(bytes, links = [], partition = "private") {
    if (bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
    const encoded = encodeCasNode(bytes, links);
    const hash = hashCasNode(encoded);
    const node = { bytes: bytes.slice(), links: [...new Set(links)].sort() };
    if (!this.#known.get(hash)?.has(partition)) {
      await this.#store.put(this.#key(partition, hash), encoded, { durability: "relaxed" });
      const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
      parts.add(partition);
      this.#known.set(hash, parts);
    }
    this.#touchCache(hash, encoded, node, partition);
    return hash;
  }
  /** Put raw pre-encoded canonical CAS node bytes (verifying digest matches expectedHash). */
  async putRaw(expectedHash, encoded, partition = "private") {
    assertHashHex(expectedHash);
    if (encoded.byteLength > this.#maxChunkBytes + 65536) throw new Error("CAS_CHUNK_TOO_LARGE");
    const actual = hashCasNode(encoded);
    if (actual !== expectedHash) throw new Error(`CAS_HASH_MISMATCH: expected ${expectedHash}, got ${actual}`);
    const node = decodeCasNode(encoded);
    if (!equalBytes(encodeCasNode(node.bytes, node.links), encoded)) throw new Error("CAS_NODE_NOT_CANONICAL");
    await this.#store.put(this.#key(partition, expectedHash), encoded, { durability: "relaxed" });
    const parts = this.#known.get(expectedHash) ?? /* @__PURE__ */ new Set();
    parts.add(partition);
    this.#known.set(expectedHash, parts);
    this.#touchCache(expectedHash, encoded, node, partition);
  }
  /** Batched put for peer/host CAS sync (single putMany per 128 chunks instead of N transactions). */
  async putManyVerified(items) {
    const toWrite = [];
    const stagedMeta = [];
    for (const item of items) {
      if (this.hasSync(item.hash, item.partition)) continue;
      assertHashHex(item.hash);
      let encoded;
      let node;
      if (hashCasNode(item.bytes) === item.hash) {
        if (item.bytes.byteLength > this.#maxChunkBytes + 65536) throw new Error("CAS_CHUNK_TOO_LARGE");
        node = decodeCasNode(item.bytes);
        if (!equalBytes(encodeCasNode(node.bytes, node.links), item.bytes)) throw new Error("CAS_NODE_NOT_CANONICAL");
        encoded = item.bytes.slice();
      } else if (computeCasHash(item.bytes, []) === item.hash) {
        if (item.bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
        encoded = encodeCasNode(item.bytes, []);
        node = { bytes: item.bytes.slice(), links: [] };
      } else {
        throw new Error(`CAS_NODE_HASH_MISMATCH:${item.hash}`);
      }
      toWrite.push({ key: this.#key(item.partition, item.hash), value: encoded });
      stagedMeta.push({ hash: item.hash, encoded, node, partition: item.partition });
    }
    if (toWrite.length === 0) return 0;
    for (let i = 0; i < toWrite.length; i += 128) {
      await writeBytesMany(this.#store, toWrite.slice(i, i + 128), { durability: "relaxed" });
    }
    for (const meta of stagedMeta) {
      const parts = this.#known.get(meta.hash) ?? /* @__PURE__ */ new Set();
      parts.add(meta.partition);
      this.#known.set(meta.hash, parts);
      this.#touchCache(meta.hash, meta.encoded, meta.node, meta.partition);
    }
    return stagedMeta.length;
  }
  /** Fault a known-on-disk CAS node back into the synchronous RAM LRU (demand paging for >16 MiB DBs). */
  async ensureLoaded(hash, allowedPartition = "any") {
    if (!HEX32.test(hash)) return false;
    if (this.getSync(hash, allowedPartition) !== null) return true;
    const loaded = await this.get(hash, allowedPartition);
    return loaded !== null;
  }
  /** Synchronous read from staged RAM + LRU cache (respecting partition visibility). */
  getSync(hash, allowedPartition = "any") {
    assertHashHex(hash);
    const staged = this.#staged.get(hash);
    if (staged !== void 0 && (allowedPartition === "any" || staged.partition === allowedPartition)) {
      return { bytes: staged.node.bytes.slice(), links: [...staged.node.links] };
    }
    const cached = this.#cache.get(hash);
    if (cached !== void 0 && (allowedPartition === "any" || cached.partitions.has(allowedPartition))) {
      this.#cache.delete(hash);
      this.#cache.set(hash, cached);
      return { bytes: cached.node.bytes.slice(), links: [...cached.node.links] };
    }
    return null;
  }
  /** Async read checking RAM cache first, then BytesStore (respecting partition visibility). */
  async get(hash, allowedPartition = "any") {
    const sync = this.getSync(hash, allowedPartition);
    if (sync !== null) return sync;
    const partitions = allowedPartition === "any" ? ["public", "private"] : [allowedPartition];
    for (const partition of partitions) {
      const raw = await this.#store.get(this.#key(partition, hash));
      if (raw === null) continue;
      if (hashCasNode(raw) !== hash) throw new Error(`CAS_CORRUPT: ${hash}`);
      const node = decodeCasNode(raw);
      const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
      parts.add(partition);
      this.#known.set(hash, parts);
      this.#touchCache(hash, raw, node, partition);
      return { bytes: node.bytes.slice(), links: [...node.links] };
    }
    return null;
  }
  /** Get raw canonical node bytes for peer replication. */
  async getRaw(hash, allowedPartition = "any") {
    assertHashHex(hash);
    const staged = this.#staged.get(hash);
    if (staged !== void 0 && (allowedPartition === "any" || staged.partition === allowedPartition)) {
      return staged.encoded.slice();
    }
    const cached = this.#cache.get(hash);
    if (cached !== void 0 && (allowedPartition === "any" || cached.partitions.has(allowedPartition))) {
      return cached.encoded.slice();
    }
    const partitions = allowedPartition === "any" ? ["public", "private"] : [allowedPartition];
    for (const partition of partitions) {
      const raw = await this.#store.get(this.#key(partition, hash));
      if (raw !== null) return raw;
    }
    return null;
  }
  hasSync(hash, allowedPartition = "any") {
    if (!HEX32.test(hash)) return false;
    const staged = this.#staged.get(hash);
    if (staged !== void 0 && (allowedPartition === "any" || staged.partition === allowedPartition)) return true;
    const cached = this.#cache.get(hash);
    if (cached !== void 0 && (allowedPartition === "any" || cached.partitions.has(allowedPartition))) return true;
    const known = this.#known.get(hash);
    if (known !== void 0 && (allowedPartition === "any" || known.has(allowedPartition))) return true;
    return false;
  }
  /** Walk all explicit DAG links reachable from rootHashes (in RAM or durable store). */
  async reachable(rootHashes) {
    const visited = /* @__PURE__ */ new Set();
    const queue = [];
    for (const hash of rootHashes) {
      if (HEX32.test(hash) && !visited.has(hash)) {
        visited.add(hash);
        queue.push(hash);
      }
    }
    while (queue.length > 0) {
      const current = queue.pop();
      const node = await this.get(current, "any");
      if (node === null) continue;
      for (const link of node.links) {
        if (!visited.has(link)) {
          visited.add(link);
          queue.push(link);
        }
      }
    }
    return visited;
  }
  /** Exact local mark-and-sweep GC preserving everything reachable from rootHashes, deleting in yielding batches. */
  async collectGarbage(rootHashes) {
    if (this.#inBatch) throw new Error("CAS_GC_DURING_BATCH");
    const keep = await this.reachable(rootHashes);
    const keysToDelete = [];
    const hashesToDrop = [];
    for (const [hash, partitions] of [...this.#known.entries()]) {
      if (keep.has(hash)) continue;
      for (const partition of partitions) {
        keysToDelete.push(this.#key(partition, hash));
      }
      hashesToDrop.push(hash);
    }
    for (let i = 0; i < keysToDelete.length; i += 32) {
      await deleteBytesMany(this.#store, keysToDelete.slice(i, i + 32), { durability: "relaxed" });
      if (i + 32 < keysToDelete.length) {
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    }
    for (const hash of hashesToDrop) {
      this.#known.delete(hash);
      this.#cache.delete(hash);
    }
    return { kept: keep.size, deleted: keysToDelete.length };
  }
  listKnownHashes(partition) {
    const out = /* @__PURE__ */ new Set();
    for (const [hash, parts] of this.#known) {
      if (partition === void 0 || parts.has(partition)) out.add(hash);
    }
    for (const [hash, item] of this.#staged) {
      if (partition === void 0 || item.partition === partition) out.add(hash);
    }
    return [...out].sort();
  }
};

// packages/records/src/live-channel.ts
var PEER_LIVE_MESSAGE_LIMITS = Object.freeze({ frameBytes: 16448, queueFrames: 64, bufferedBytes: 65536 });
function frameLiveMessageChannel(channel) {
  channel.binaryType = "arraybuffer";
  let closed = false, reading = false, failure = null;
  let sentBytes = 0, receivedBytes = 0, sentPackets = 0, receivedPackets = 0, queuedReceiveBytes = 0, droppedPackets = 0;
  let resolveReady, rejectReady;
  const ready = new Promise((resolve, reject) => {
    resolveReady = resolve;
    rejectReady = reject;
  });
  void ready.catch(() => void 0);
  const lifetime = new AbortController(), queue = [], waiters = /* @__PURE__ */ new Set();
  const listeners = [];
  const wake = () => {
    for (const resolve of waiters) resolve();
    waiters.clear();
  };
  const stop = (error) => {
    if (closed) return;
    closed = true;
    failure = error ?? null;
    rejectReady(error ?? new Error("PEER_MESSAGE_LIVE_CLOSED"));
    for (const [type, listener] of listeners) channel.removeEventListener(type, listener);
    queue.length = 0;
    queuedReceiveBytes = 0;
    lifetime.abort(error ?? new Error("PEER_MESSAGE_LIVE_CLOSED"));
    channel.close();
    wake();
  };
  const on = (type, listener) => {
    listeners.push([type, listener]);
    channel.addEventListener(type, listener);
  };
  on("open", () => resolveReady());
  on("close", () => stop(new Error("PEER_MESSAGE_LIVE_ENDED")));
  on("error", () => stop(new Error("PEER_MESSAGE_LIVE_ERROR")));
  on("message", (event) => {
    if (closed) return;
    const value = event.data;
    if (!(value instanceof ArrayBuffer) || value.byteLength < 1 || value.byteLength > PEER_LIVE_MESSAGE_LIMITS.frameBytes) {
      stop(new Error("PEER_MESSAGE_LIVE_FRAME_INVALID"));
      return;
    }
    receivedBytes += value.byteLength;
    receivedPackets += 1;
    if (queue.length === PEER_LIVE_MESSAGE_LIMITS.queueFrames) {
      queuedReceiveBytes -= queue.shift().length;
      droppedPackets += 1;
    }
    const bytes = new Uint8Array(value.slice(0));
    queue.push(bytes);
    queuedReceiveBytes += bytes.length;
    wake();
  });
  if (channel.readyState === "open") resolveReady();
  else if (channel.readyState !== "connecting") stop(new Error("PEER_MESSAGE_LIVE_CLOSED"));
  async function* read(signal) {
    if (reading) throw new Error("PEER_MESSAGE_LIVE_READER_EXISTS");
    reading = true;
    const abort = () => stop();
    signal.addEventListener("abort", abort, { once: true });
    try {
      if (signal.aborted) return;
      for (; ; ) {
        if (failure !== null) throw failure;
        if (closed) return;
        const bytes = queue.shift();
        if (bytes === void 0) {
          await new Promise((resolve) => {
            waiters.add(resolve);
          });
          continue;
        }
        queuedReceiveBytes -= bytes.length;
        yield bytes;
      }
    } finally {
      signal.removeEventListener("abort", abort);
      stop();
    }
  }
  return {
    ready,
    signal: lifetime.signal,
    get stats() {
      return {
        sentBytes,
        receivedBytes,
        sentPackets,
        receivedPackets,
        droppedPackets,
        queuedSendBytes: channel.bufferedAmount,
        queuedReceiveBytes,
        queuedReceiveFrames: queue.length
      };
    },
    async trySend(input, options = {}) {
      options.signal?.throwIfAborted();
      if (closed) throw failure ?? new Error("PEER_MESSAGE_LIVE_CLOSED");
      if (channel.readyState !== "open") throw new Error("PEER_MESSAGE_LIVE_NOT_OPEN");
      if (!(input instanceof Uint8Array) || input.length < 1 || input.length > PEER_LIVE_MESSAGE_LIMITS.frameBytes) throw new Error("PEER_MESSAGE_LIVE_FRAME_TOO_LARGE");
      if (channel.bufferedAmount + input.length > PEER_LIVE_MESSAGE_LIMITS.bufferedBytes) return false;
      channel.send(input.slice().buffer);
      sentBytes += input.length;
      sentPackets += 1;
      return true;
    },
    frames(signal) {
      return { [Symbol.asyncIterator]() {
        const controller = new AbortController();
        const iterator = read(signal === void 0 ? controller.signal : AbortSignal.any([controller.signal, signal]));
        return {
          next: () => iterator.next(),
          async return() {
            controller.abort();
            return iterator.return();
          },
          async throw(error) {
            controller.abort();
            return iterator.throw(error);
          }
        };
      } };
    },
    async close() {
      stop();
    }
  };
}

// packages/records/src/message-channel.ts
var PEER_MESSAGE_LIMITS = Object.freeze({
  frameBytes: 1048576 + 65536,
  packetBytes: 16 * 1024,
  queueBytes: 4 * 1024 * 1024,
  queueFrames: 16,
  bufferedBytes: 256 * 1024
});
var HEADER = 16;
var HELLO = 1;
var DATA = 2;
var CREDIT = 3;
function framePeerMessageChannels(channels, options = {}) {
  const reliable = frameMessageChannel(channels.reliable, options);
  let live;
  try {
    live = frameLiveMessageChannel(channels.live);
  } catch (error) {
    void reliable.close();
    channels.live.close();
    throw error;
  }
  const signal = AbortSignal.any([reliable.signal, live.signal]);
  const close = async () => {
    await Promise.all([reliable.close(), live.close()]);
  };
  signal.addEventListener("abort", () => {
    void close();
  }, { once: true });
  if (signal.aborted) void close();
  const ready = Promise.all([reliable.ready, live.ready]).then(() => void 0);
  void ready.catch(() => void 0);
  return {
    ready,
    signal,
    live,
    get stats() {
      const a = reliable.stats, b = live.stats;
      return {
        sentBytes: a.sentBytes + b.sentBytes,
        receivedBytes: a.receivedBytes + b.receivedBytes,
        sentPackets: a.sentPackets + b.sentPackets,
        receivedPackets: a.receivedPackets + b.receivedPackets,
        queuedSendBytes: a.queuedSendBytes + b.queuedSendBytes,
        queuedReceiveBytes: a.queuedReceiveBytes + b.queuedReceiveBytes,
        queuedReceiveFrames: a.queuedReceiveFrames + b.queuedReceiveFrames
      };
    },
    send: (bytes, sendOptions) => reliable.send(bytes, sendOptions),
    frames: (input) => reliable.frames(input),
    close
  };
}
function frameMessageChannel(channel, options = {}) {
  const maximum = options.maxFrameBytes ?? PEER_MESSAGE_LIMITS.frameBytes;
  const windowBytes = options.queueBytes ?? PEER_MESSAGE_LIMITS.queueBytes;
  const windowFrames = options.queueFrames ?? PEER_MESSAGE_LIMITS.queueFrames;
  const timeoutMs = options.sendTimeoutMs ?? 3e4;
  const helloTimeoutMs = options.helloTimeoutMs ?? 1e4;
  if (![maximum, windowBytes, windowFrames, timeoutMs, helloTimeoutMs].every(Number.isSafeInteger) || maximum < 1 || maximum > PEER_MESSAGE_LIMITS.frameBytes || windowBytes < maximum || windowBytes > PEER_MESSAGE_LIMITS.queueBytes || windowFrames < 1 || windowFrames > PEER_MESSAGE_LIMITS.queueFrames || timeoutMs < 1 || timeoutMs > 12e4 || helloTimeoutMs < 1 || helloTimeoutMs > 12e4) throw new Error("PEER_MESSAGE_BOUNDS_INVALID");
  channel.binaryType = "arraybuffer";
  channel.bufferedAmountLowThreshold = PEER_MESSAGE_LIMITS.bufferedBytes / 2;
  let closed = false, failure = null, opened = false, greeted = false, reading = false;
  let remoteMaximum = 0, remoteWindow = 0, remoteFrames = 0, creditBytes = 0, creditFrames = 0;
  let queuedSendBytes = 0, queuedSendFrames = 0, reservedBytes = 0, reservedFrames = 0;
  let assembling = null, received = 0;
  let sentBytes = 0, receivedBytes = 0, sentPackets = 0, receivedPackets = 0;
  const lifetime = new AbortController();
  const queue = [], waiters = /* @__PURE__ */ new Set();
  let tail = Promise.resolve();
  let helloTimer;
  let resolveReady, rejectReady;
  const ready = new Promise((resolve, reject) => {
    resolveReady = resolve;
    rejectReady = reject;
  });
  void ready.catch(() => void 0);
  const wake = () => {
    for (const resolve of waiters) resolve();
    waiters.clear();
  };
  const wait = () => new Promise((resolve) => {
    waiters.add(resolve);
  });
  const assertOpen = () => {
    if (closed) throw failure ?? new Error("PEER_MESSAGE_CONNECTION_CLOSED");
  };
  const listeners = [];
  const stop = (error) => {
    if (closed) return;
    closed = true;
    failure = error ?? null;
    clearTimeout(helloTimer);
    rejectReady(error ?? new Error("PEER_MESSAGE_CONNECTION_CLOSED"));
    for (const [type, listener] of listeners) channel.removeEventListener(type, listener);
    queue.length = 0;
    assembling = null;
    reservedBytes = 0;
    reservedFrames = 0;
    lifetime.abort(error ?? new Error("PEER_MESSAGE_CONNECTION_CLOSED"));
    channel.close();
    wake();
  };
  const fail = (error) => stop(error instanceof Error ? error : new Error(String(error)));
  const packet = (kind, a, b, c = 0, payload) => {
    assertOpen();
    const bytes = new Uint8Array(HEADER + (payload?.length ?? 0)), fields = new DataView(bytes.buffer);
    bytes.set([67, 82, 1, kind]);
    fields.setUint32(4, a);
    fields.setUint32(8, b);
    fields.setUint32(12, c);
    if (payload !== void 0) bytes.set(payload, HEADER);
    channel.send(bytes.buffer);
    sentPackets += 1;
  };
  const open = () => {
    if (opened || closed) return;
    try {
      packet(HELLO, maximum, windowBytes, windowFrames);
      opened = true;
      if (greeted) resolveReady();
      else helloTimer = setTimeout(() => fail(new Error("PEER_MESSAGE_HELLO_TIMEOUT")), helloTimeoutMs);
    } catch (error) {
      fail(error);
    }
  };
  const on = (type, listener) => {
    listeners.push([type, listener]);
    channel.addEventListener(type, listener);
  };
  on("open", open);
  on("bufferedamountlow", wake);
  on("close", () => fail(new Error(assembling === null ? "PEER_MESSAGE_CONNECTION_ENDED" : "PEER_MESSAGE_FRAME_TRUNCATED")));
  on("error", () => fail(new Error("PEER_MESSAGE_CHANNEL_ERROR")));
  on("message", (event) => {
    if (closed) return;
    try {
      const value = event.data;
      if (!(value instanceof ArrayBuffer) || value.byteLength < HEADER || value.byteLength > PEER_MESSAGE_LIMITS.packetBytes) throw new Error("PEER_MESSAGE_PACKET_INVALID");
      const bytes = new Uint8Array(value), fields = new DataView(value), kind = bytes[3];
      if (bytes[0] !== 67 || bytes[1] !== 82 || bytes[2] !== 1) throw new Error("PEER_MESSAGE_PROTOCOL_INVALID");
      const a = fields.getUint32(4), b = fields.getUint32(8), c = fields.getUint32(12);
      receivedPackets += 1;
      if (kind === HELLO) {
        if (greeted || bytes.length !== HEADER || a < 1 || a > PEER_MESSAGE_LIMITS.frameBytes || b < a || b > PEER_MESSAGE_LIMITS.queueBytes || c < 1 || c > PEER_MESSAGE_LIMITS.queueFrames) throw new Error("PEER_MESSAGE_HELLO_INVALID");
        greeted = true;
        remoteMaximum = a;
        remoteWindow = b;
        remoteFrames = c;
        creditBytes = b;
        creditFrames = c;
        if (opened) {
          clearTimeout(helloTimer);
          resolveReady();
        }
        wake();
        return;
      }
      if (!greeted) throw new Error("PEER_MESSAGE_HELLO_REQUIRED");
      if (kind === CREDIT) {
        if (bytes.length !== HEADER || a < 1 || b !== 1 || c !== 0 || creditBytes + a > remoteWindow || creditFrames + 1 > remoteFrames) {
          throw new Error("PEER_MESSAGE_CREDIT_INVALID");
        }
        creditBytes += a;
        creditFrames += 1;
        wake();
        return;
      }
      const length = bytes.length - HEADER;
      if (kind !== DATA || c !== 0 || a < 1 || a > maximum || b !== received || length < 1 || length > a - b || assembling !== null && assembling.length !== a) throw new Error("PEER_MESSAGE_FRAGMENT_INVALID");
      if (assembling === null) {
        if (reservedBytes + a > windowBytes || reservedFrames + 1 > windowFrames) throw new Error("PEER_MESSAGE_RECEIVE_CREDIT_EXCEEDED");
        assembling = new Uint8Array(a);
        reservedBytes += a;
        reservedFrames += 1;
      }
      assembling.set(bytes.subarray(HEADER), b);
      received += length;
      receivedBytes += length;
      if (received === a) {
        queue.push(assembling);
        assembling = null;
        received = 0;
        wake();
      }
    } catch (error) {
      fail(error);
    }
  });
  if (channel.readyState === "open") queueMicrotask(open);
  else if (channel.readyState !== "connecting") stop(new Error("PEER_MESSAGE_CONNECTION_CLOSED"));
  return {
    ready,
    signal: lifetime.signal,
    get stats() {
      return {
        sentBytes,
        receivedBytes,
        sentPackets,
        receivedPackets,
        queuedSendBytes,
        queuedReceiveBytes: reservedBytes,
        queuedReceiveFrames: reservedFrames
      };
    },
    send(input, sendOptions = {}) {
      if (closed) return Promise.reject(failure ?? new Error("PEER_MESSAGE_CONNECTION_CLOSED"));
      if (sendOptions.signal?.aborted === true) return Promise.reject(sendOptions.signal.reason);
      if (!(input instanceof Uint8Array) || input.length < 1 || input.length > maximum) return Promise.reject(new Error("PEER_MESSAGE_FRAME_TOO_LARGE"));
      if (queuedSendBytes + input.length > windowBytes || queuedSendFrames + 1 > windowFrames) return Promise.reject(new Error("PEER_MESSAGE_SEND_BACKPRESSURE"));
      const bytes = input.slice();
      queuedSendBytes += bytes.length;
      queuedSendFrames += 1;
      const task = tail.then(async () => {
        let dispatched = false;
        const assertSending = () => {
          assertOpen();
          sendOptions.signal?.throwIfAborted();
        };
        const cancelled = () => {
          wake();
        };
        sendOptions.signal?.addEventListener("abort", cancelled, { once: true });
        const timeout = setTimeout(() => fail(new Error("PEER_MESSAGE_SEND_TIMEOUT")), timeoutMs);
        try {
          await ready;
          assertSending();
          if (bytes.length > remoteMaximum) throw new Error("PEER_MESSAGE_REMOTE_FRAME_TOO_LARGE");
          while (creditBytes < bytes.length || creditFrames === 0) {
            assertSending();
            await wait();
          }
          assertSending();
          for (let offset = 0; offset < bytes.length; offset += PEER_MESSAGE_LIMITS.packetBytes - HEADER) {
            while (channel.bufferedAmount > PEER_MESSAGE_LIMITS.bufferedBytes - PEER_MESSAGE_LIMITS.packetBytes) {
              assertSending();
              await wait();
            }
            assertSending();
            if (!dispatched) {
              creditBytes -= bytes.length;
              creditFrames -= 1;
              dispatched = true;
            }
            const part = bytes.subarray(offset, offset + PEER_MESSAGE_LIMITS.packetBytes - HEADER);
            packet(DATA, bytes.length, offset, 0, part);
            sentBytes += part.length;
          }
        } catch (error) {
          if (dispatched || sendOptions.signal?.aborted !== true || error !== sendOptions.signal.reason) fail(error);
          throw error;
        } finally {
          clearTimeout(timeout);
          sendOptions.signal?.removeEventListener("abort", cancelled);
        }
      }).finally(() => {
        queuedSendBytes -= bytes.length;
        queuedSendFrames -= 1;
      });
      tail = task.catch(() => void 0);
      return task;
    },
    async *frames(signal) {
      if (reading) throw new Error("PEER_MESSAGE_READER_EXISTS");
      reading = true;
      const abort = () => stop();
      signal?.addEventListener("abort", abort, { once: true });
      try {
        if (signal?.aborted === true) return;
        await ready;
        for (; ; ) {
          if (failure !== null) throw failure;
          if (closed) return;
          const frame = queue.shift();
          if (frame === void 0) {
            await wait();
            continue;
          }
          yield frame;
          if (!closed) {
            reservedBytes -= frame.length;
            reservedFrames -= 1;
            packet(CREDIT, frame.length, 1);
          }
        }
      } finally {
        signal?.removeEventListener("abort", abort);
        stop();
      }
    },
    async close() {
      stop();
      await tail;
    }
  };
}

export {
  MemoryBytesStore,
  writeBytesMany,
  encodeCasNode,
  decodeCasNode,
  hashCasNode,
  computeCasHash,
  ContentAddressedStore,
  PEER_LIVE_MESSAGE_LIMITS,
  PEER_MESSAGE_LIMITS,
  framePeerMessageChannels
};
