import {
  APPLICATION_OWNER_PROTOCOL,
  MAX_RELEASES,
  MAX_REQUESTS,
  MAX_STREAMS,
  PROTOCOL,
  acquireApplicationOwnerLock,
  bounded,
  releasesResource
} from "./chunks/chunk-2ZKHAZYZ.mjs";
import {
  AbandonedOperationError,
  RecoveredViewError
} from "./chunks/chunk-TLZH7OYA.mjs";
import {
  PEER_GENERATION_CAPABILITIES,
  validateApplicationDescription
} from "./chunks/chunk-TF4JHBDD.mjs";
import "./chunks/chunk-Q44B5CP6.mjs";
import "./chunks/chunk-DACCYORU.mjs";
import {
  awaitOwnedTask
} from "./chunks/chunk-KSC4KBWO.mjs";

// packages/peer-session/src/worker-application.ts
var WorkerApplicationSession = class {
  applicationId;
  historyId;
  deviceId;
  storageId;
  endpoint;
  capabilities;
  participation;
  operations = {
    get: (id, options = {}) => this.#call("operation.get", [id, options]),
    inspect: (id, options = {}) => this.#call("operation.inspect", [id, options]),
    wait: (id, options = {}) => {
      const { signal, ...scope } = options;
      return this.#call("operation.wait", [id, scope], signal, true);
    }
  };
  recovery = {
    inspect: () => this.#call("recovery.inspect", []),
    takeover: (options = {}) => {
      const { signal, ...request } = options;
      return this.#call("recovery.takeover", [request], signal, true);
    },
    handover: (options) => {
      const { signal, ...request } = options;
      return this.#call("recovery.handover", [request], signal, true);
    }
  };
  signals = {
    send: (topic, payload, options = {}) => this.#call("signals.send", [topic, payload, { ...options.ttlMs === void 0 ? {} : { ttlMs: options.ttlMs }, ...options.stream === void 0 ? {} : { stream: options.stream } }], options.signal),
    subscribe: (options = {}) => this.#stream("signals", [{
      ...options.topics === void 0 ? {} : { topics: options.topics },
      ...options.mode === void 0 ? {} : { mode: options.mode },
      ...options.streams === void 0 ? {} : { streams: options.streams }
    }], options.signal)
  };
  content = {
    stage: async (options) => this.#upload(await this.#call("content.stage", [options])),
    resume: async (id) => this.#upload(await this.#call("content.resume", [id])),
    read: (reference, options = {}) => this.#stream("content", [reference, { ...options.offset === void 0 ? {} : { offset: options.offset }, ...options.length === void 0 ? {} : { length: options.length } }], options.signal),
    retain: (reference, options = {}) => this.#call("content.retain", [reference], options.signal),
    retained: (reference) => this.#call("content.retained", [reference]),
    retention: (reference) => this.#call("content.retention", [reference])
  };
  #port;
  #description;
  #timeoutMs;
  #lifetime = new AbortController();
  #pending = /* @__PURE__ */ new Map();
  #streams = /* @__PURE__ */ new Set();
  #statusListeners = /* @__PURE__ */ new Set();
  #recoveryListeners = /* @__PURE__ */ new Set();
  #participationListeners = /* @__PURE__ */ new Set();
  #participationLifetime = new AbortController();
  #snapshot;
  #nextId = 0;
  #closing;
  #stopExternal;
  /** Construct through connectApplicationWorker so readiness is authenticated to the owned port. */
  constructor(port, metadata, timeoutMs, signal) {
    this.#port = port;
    this.#timeoutMs = timeoutMs;
    this.#snapshot = metadata;
    this.applicationId = metadata.applicationId;
    this.historyId = metadata.historyId;
    this.deviceId = metadata.deviceId;
    this.storageId = metadata.storageId;
    this.endpoint = metadata.endpoint === void 0 ? void 0 : Object.freeze({
      ...metadata.endpoint,
      context: Object.freeze({ ...metadata.endpoint.context }),
      capabilities: Object.freeze([...metadata.endpoint.capabilities]),
      ...metadata.endpoint.identity === void 0 ? {} : { identity: Object.freeze({ ...metadata.endpoint.identity }) }
    });
    Object.defineProperty(this.signals, "delivery", { value: metadata.signalDelivery ?? "neighbors", enumerable: true });
    this.capabilities = Object.freeze({ ...metadata.description.capabilities });
    this.#description = { ...metadata.description, capabilities: this.capabilities };
    if (metadata.participation !== null) {
      const owner = this;
      this.participation = {
        get status() {
          return structuredClone(owner.#snapshot.participation);
        },
        signal: this.#participationLifetime.signal,
        onStatus(listener) {
          owner.#participationListeners.add(listener);
          try {
            listener(structuredClone(owner.#snapshot.participation));
          } catch {
          }
          return () => {
            owner.#participationListeners.delete(listener);
          };
        },
        approveRecovery: (id) => this.#call("participation.approve", [id]),
        close: () => this.#call("participation.close", [])
      };
      if (metadata.participation.phase === "closed") this.#participationLifetime.abort(new Error("APPLICATION_PARTICIPATION_CLOSED"));
    }
    port.addEventListener("message", this.#receive);
    port.addEventListener("messageerror", this.#messageError);
    port.start();
    if (signal !== void 0) {
      const abort = () => {
        void this.close().catch(() => void 0);
      };
      signal.addEventListener("abort", abort, { once: true });
      this.#stopExternal = () => signal.removeEventListener("abort", abort);
      if (signal.aborted) abort();
    }
    if (this.endpoint === void 0 || this.endpoint.capabilities.includes("diagnostics")) {
      void this.#observe("status", () => {
      }).catch((error) => this.#fail(error));
      void this.#observe("recovery", (notice) => {
        for (const listener of this.#recoveryListeners) {
          try {
            listener(notice);
          } catch {
          }
        }
      }).catch((error) => this.#fail(error));
      if (this.participation !== void 0) void this.#observe("participation", () => {
      }).catch((error) => this.#fail(error));
    }
  }
  /** Oldest finite facade call, in this realm's performance.now() clock.
   * Passive stream/operation waits never count. This is a caller deadline,
   * not evidence that the owner received or began executing the request.
   */
  get boundedRequest() {
    let oldest;
    for (const request of this.#pending.values()) {
      if (request.bounded !== void 0 && (oldest === void 0 || request.bounded.startedAt < oldest.startedAt)) oldest = request.bounded;
    }
    return oldest === void 0 ? null : { ...oldest };
  }
  get signal() {
    return this.#lifetime.signal;
  }
  get status() {
    return { ...this.#snapshot.status };
  }
  get revision() {
    return structuredClone(this.#snapshot.revision);
  }
  describe() {
    return structuredClone(this.#description);
  }
  authority() {
    return this.#call("authority", []);
  }
  onStatus(listener) {
    this.#statusListeners.add(listener);
    try {
      listener(this.status);
    } catch {
    }
    return () => {
      this.#statusListeners.delete(listener);
    };
  }
  onRecovery(listener) {
    this.signal.throwIfAborted();
    this.#recoveryListeners.add(listener);
    return () => {
      this.#recoveryListeners.delete(listener);
    };
  }
  async command(name, input, options) {
    return this.#operation(await this.#call("command", [name, input, options]));
  }
  async reapply(id, name, input, options) {
    return this.#operation(await this.#call("reapply", [id, name, input, options]));
  }
  query(name, input) {
    return this.#call("query", [name, input]);
  }
  retry(id) {
    return this.#call("retry", [id]);
  }
  resume() {
    return this.#call("resume", []);
  }
  inspectRecovery() {
    return this.#call("inspectRecovery", []);
  }
  recoveryPoint() {
    return this.#call("recoveryPoint", []);
  }
  adopt(authority) {
    return this.#call("adopt", [authority]);
  }
  changes(options = {}) {
    return this.#stream("changes", [], options.signal);
  }
  projection(id) {
    const captured = this.#call("projection.open", [id]), lifetime = new AbortController();
    void captured.catch(() => void 0);
    let closing;
    const signal = (external) => AbortSignal.any([
      this.signal,
      lifetime.signal,
      ...external === void 0 ? [] : [external]
    ]);
    return Object.freeze({
      id,
      read: async (options = {}) => {
        const owned = signal(options.signal), token = await awaitOwnedTask(owned, () => captured);
        return this.#call("projection.read", [token], owned);
      },
      changes: (options = {}) => this.#stream("projection", async () => [await captured], signal(options.signal)),
      close: () => {
        if (closing !== void 0) return closing;
        closing = captured.then((token) => this.signal.aborted ? void 0 : this.#call("projection.close", [token])).catch((error) => {
          closing = void 0;
          if (!this.signal.aborted) throw error;
        });
        lifetime.abort(new Error("APPLICATION_PROJECTION_CLOSED"));
        return closing;
      }
    });
  }
  async readView() {
    const captured = await this.#call("view.open", []);
    let released = false;
    const held = () => {
      if (released) throw new Error("APPLICATION_VIEW_RELEASED");
    };
    return {
      revision: captured.revision,
      query: (sql, parameters = []) => {
        held();
        return this.#call("view.query", [captured.id, sql, parameters]);
      },
      readEvents: (options = {}) => {
        held();
        return this.#call("view.events", [captured.id, options]);
      },
      release: async () => {
        if (released) return;
        released = true;
        await this.#call("view.release", [captured.id]);
      }
    };
  }
  /** Detach cancels this endpoint's observation only; the owner's journal survives. */
  detach() {
    return this.close();
  }
  suspend() {
    return this.#call("endpoint.suspend", []);
  }
  resumeAttachment() {
    return this.#call("endpoint.resume", []);
  }
  endpoints() {
    return this.#call("endpoints.list", []);
  }
  close() {
    if (this.#closing !== void 0) return this.#closing;
    this.#closing = (async () => {
      try {
        if (!this.signal.aborted) await this.#call("close", []);
      } catch (error) {
        if (!this.signal.aborted) throw error;
      } finally {
        this.#fail(new Error("APPLICATION_SESSION_CLOSED"));
      }
    })();
    return this.#closing;
  }
  #call(method, args, signal, passive = false) {
    if (this.signal.aborted) return Promise.reject(this.signal.reason);
    if (signal?.aborted) return Promise.reject(signal.reason);
    const release = releasesResource(method);
    if (method !== "close" && [...this.#pending.values()].filter((call) => call.release === release).length >= (release ? MAX_RELEASES : MAX_REQUESTS)) return Promise.reject(new Error("APPLICATION_WORKER_REQUEST_LIMIT"));
    const id = ++this.#nextId;
    if (!Number.isSafeInteger(id)) return Promise.reject(new Error("APPLICATION_WORKER_REQUEST_ID_EXHAUSTED"));
    const request = { id, method, args };
    try {
      bounded(request);
    } catch (error) {
      return Promise.reject(error);
    }
    return new Promise((resolve, reject) => {
      let timer;
      const clean = () => {
        signal?.removeEventListener("abort", abort);
        if (timer !== void 0) clearTimeout(timer);
      };
      const abort = () => {
        clean();
        this.#pending.delete(id);
        this.#cancel(id);
        reject(signal?.reason ?? new Error("APPLICATION_WORKER_TIMEOUT"));
      };
      const startedAt = performance.now();
      this.#pending.set(id, { ...passive ? {} : { bounded: { startedAt, deadline: startedAt + this.#timeoutMs } }, release, resolve: (value) => {
        clean();
        resolve(value);
      }, reject: (error) => {
        clean();
        reject(error);
      } });
      signal?.addEventListener("abort", abort, { once: true });
      if (!passive) timer = setTimeout(abort, this.#timeoutMs);
      try {
        this.#port.postMessage(request);
      } catch (error) {
        this.#pending.delete(id);
        clean();
        reject(error);
      }
    });
  }
  #stream(name, args, signal) {
    const client = this;
    return { [Symbol.asyncIterator]() {
      if (name !== "content" && (client.signal.aborted || signal?.aborted)) {
        const ended = async () => ({ done: true, value: void 0 });
        return { next: ended, return: ended };
      }
      if (client.#streams.size >= MAX_STREAMS) throw new Error("APPLICATION_WORKER_STREAM_LIMIT");
      const controller = new AbortController();
      client.#streams.add(controller);
      const lifetime = AbortSignal.any([client.signal, controller.signal, ...signal === void 0 ? [] : [signal]]);
      let opened, id, done = false, pulling = false;
      const finish = () => {
        if (done) return;
        done = true;
        controller.abort(new Error("APPLICATION_WORKER_STREAM_CLOSED"));
        client.#streams.delete(controller);
        if (id !== void 0) client.#cancel(id);
        else void opened?.then((value) => client.#cancel(value), () => void 0);
      };
      lifetime.addEventListener("abort", finish, { once: true });
      return {
        async next() {
          if (done) return { done: true, value: void 0 };
          if (pulling) throw new Error("APPLICATION_WORKER_STREAM_BUSY");
          pulling = true;
          try {
            opened ??= typeof args === "function" ? awaitOwnedTask(lifetime, args).then((values) => client.#call("stream.open", [name, ...values], lifetime)) : client.#call("stream.open", [name, ...args], lifetime);
            id = await opened;
            const result = await client.#call("stream.next", [id], lifetime, true);
            if (result.done) finish();
            return result;
          } catch (error) {
            const cancelled = lifetime.aborted;
            finish();
            if (cancelled && name !== "content") return { done: true, value: void 0 };
            throw error;
          } finally {
            pulling = false;
          }
        },
        async return() {
          finish();
          lifetime.removeEventListener("abort", finish);
          return { done: true, value: void 0 };
        }
      };
    } };
  }
  #operation(id) {
    return Object.freeze({
      operationId: id,
      get: () => this.operations.get(id),
      applied: (options = {}) => this.operations.wait(id, options),
      retry: () => this.retry(id),
      shared: (options = {}) => this.#call("operation.shared", [id], options.signal, true)
    });
  }
  #upload(id) {
    return {
      id,
      write: (index, bytes) => this.#call("content.write", [id, index, bytes]),
      progress: () => this.#call("content.progress", [id]),
      commit: () => this.#call("content.commit", [id])
    };
  }
  async #observe(name, listener) {
    try {
      for await (const value of this.#stream(name, [], this.signal)) listener(value);
    } catch (error) {
      if (!this.signal.aborted) throw error;
    }
  }
  #cancel(id) {
    try {
      this.#port.postMessage({ cancel: id });
    } catch {
    }
  }
  #receive = (event) => {
    try {
      bounded(event.data);
      const response = event.data;
      if (response.ended !== void 0) {
        this.#fail(fromError(response.ended), false);
        return;
      }
      if (!Number.isSafeInteger(response.id)) throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
      const pending = this.#pending.get(response.id);
      if (pending === void 0) return;
      this.#update(response.snapshot);
      this.#pending.delete(response.id);
      if (response.error === void 0) pending.resolve(response.value);
      else pending.reject(fromError(response.error));
    } catch (error) {
      this.#fail(error);
    }
  };
  #messageError = () => {
    this.#fail(new Error("APPLICATION_WORKER_MESSAGE_INVALID"));
  };
  #update(value) {
    validateStatus(value.status);
    validateParticipation(value.participation);
    if (value.participation === null !== (this.participation === void 0)) throw new Error("APPLICATION_WORKER_PARTICIPATION_CHANGED");
    const changed = JSON.stringify(value.status) !== JSON.stringify(this.#snapshot.status);
    const participationChanged = JSON.stringify(value.participation) !== JSON.stringify(this.#snapshot.participation);
    this.#snapshot = value;
    if (changed) for (const listener of this.#statusListeners) {
      try {
        listener(this.status);
      } catch {
      }
    }
    if (value.participation?.phase === "closed") this.#participationLifetime.abort(new Error("APPLICATION_PARTICIPATION_CLOSED"));
    if (participationChanged) for (const listener of this.#participationListeners) {
      try {
        listener(structuredClone(value.participation));
      } catch {
      }
    }
  }
  #fail(reason, notifyOwner = true) {
    if (this.signal.aborted) return;
    if (notifyOwner) {
      try {
        this.#port.postMessage({ id: ++this.#nextId, method: "close", args: [] });
      } catch {
      }
    }
    this.#lifetime.abort(reason);
    this.#stopExternal?.();
    this.#participationLifetime.abort(reason);
    this.#snapshot = {
      ...this.#snapshot,
      status: { ...this.#snapshot.status, phase: "closed", database: "closed" },
      participation: this.#snapshot.participation === null ? null : { ...this.#snapshot.participation, phase: "closed" }
    };
    for (const listener of this.#statusListeners) {
      try {
        listener(this.status);
      } catch {
      }
    }
    this.#statusListeners.clear();
    this.#recoveryListeners.clear();
    for (const listener of this.#participationListeners) {
      try {
        listener(structuredClone(this.#snapshot.participation));
      } catch {
      }
    }
    this.#participationListeners.clear();
    for (const pending of this.#pending.values()) pending.reject(reason);
    this.#pending.clear();
    for (const controller of this.#streams) controller.abort(reason);
    this.#streams.clear();
    this.#port.removeEventListener("message", this.#receive);
    this.#port.removeEventListener("messageerror", this.#messageError);
    this.#port.close();
  }
};
function connectApplicationWorker(endpoint, options = {}) {
  return connect(endpoint, options, PROTOCOL);
}
function connectApplicationOwner(endpoint, options) {
  const { signal, timeoutMs, ...handshake } = options;
  return connect(endpoint, { ...signal === void 0 ? {} : { signal }, ...timeoutMs === void 0 ? {} : { timeoutMs } }, APPLICATION_OWNER_PROTOCOL, handshake);
}
function connect(endpoint, options, protocol, handshake) {
  const timeoutMs = options.timeoutMs ?? 3e4;
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 12e4) return Promise.reject(new Error("APPLICATION_WORKER_TIMEOUT_INVALID"));
  if (options.signal?.aborted) return Promise.reject(options.signal.reason);
  const channel = new MessageChannel(), port = channel.port1;
  return new Promise((resolve, reject) => {
    const clean = () => {
      clearTimeout(timer);
      options.signal?.removeEventListener("abort", abort);
      port.removeEventListener("message", ready);
    };
    const fail = (reason) => {
      clean();
      try {
        port.postMessage({ id: 1, method: "close", args: [] });
      } catch {
      }
      port.close();
      channel.port2.close();
      reject(reason);
    };
    const abort = () => {
      fail(options.signal?.reason);
    };
    const ready = (event) => {
      try {
        bounded(event.data);
        const value = event.data;
        if (value.ended !== void 0) {
          fail(fromError(value.ended));
          return;
        }
        const metadata = value.ready;
        if (metadata === void 0 || metadata.protocol !== protocol || !/^[0-9a-f]{64}$/u.test(metadata.applicationId) || !/^[0-9a-f]{64}$/u.test(metadata.deviceId) || typeof metadata.storageId !== "string" || typeof metadata.historyId !== "string") {
          throw new Error("APPLICATION_WORKER_METADATA_INVALID");
        }
        const { capabilities, ...description } = metadata.description;
        if (capabilities === null || typeof capabilities !== "object" || typeof capabilities.sql !== "boolean" || Object.keys(capabilities).length !== Object.keys(PEER_GENERATION_CAPABILITIES).length + 1 || Object.entries(PEER_GENERATION_CAPABILITIES).some(([key, expected]) => capabilities[key] !== expected)) {
          throw new Error("APPLICATION_WORKER_METADATA_INVALID");
        }
        validateApplicationDescription(description);
        if (handshake !== void 0 && (metadata.applicationId !== handshake.applicationId || description.id !== handshake.definitionId || description.version !== handshake.definitionVersion || !validEndpoint(metadata.endpoint))) throw new Error("CONTRACT_INCOMPATIBLE");
        validateStatus(metadata.status);
        validateParticipation(metadata.participation);
        clean();
        resolve(new WorkerApplicationSession(port, metadata, timeoutMs, options.signal));
      } catch (error) {
        fail(error);
      }
    };
    const timer = setTimeout(() => fail(new Error("APPLICATION_WORKER_READY_TIMEOUT")), timeoutMs);
    options.signal?.addEventListener("abort", abort, { once: true });
    port.addEventListener("message", ready);
    port.start();
    try {
      endpoint.postMessage({ protocol, port: channel.port2, ...handshake === void 0 ? {} : { handshake } }, [channel.port2]);
    } catch (error) {
      fail(error);
    }
  });
}
function validateParticipation(value) {
  if (value === null) return;
  if (value === void 0 || typeof value !== "object") throw new Error("APPLICATION_WORKER_METADATA_INVALID");
  const status = value;
  if (!["connecting", "connected", "following", "coordinating", "recovering", "approval-required", "unavailable", "closed"].includes(status.phase) || !Array.isArray(status.connectedPeers) || status.connectedPeers.length > 8 || status.connectedPeers.some((peer) => typeof peer !== "string" || !/^[0-9a-f]{64}$/u.test(peer)) || status.error !== null && typeof status.error !== "string" || status.recovery === void 0 || status.recovery !== null && (typeof status.recovery !== "object" || typeof status.recovery.id !== "string" || !["freshness-unknown", "older-than-budget"].includes(status.recovery.reason) || status.recovery.observedAt !== null && (!Number.isSafeInteger(status.recovery.observedAt) || status.recovery.observedAt < 0) || status.recovery.ageMs !== null && (!Number.isSafeInteger(status.recovery.ageMs) || status.recovery.ageMs < 0))) {
    throw new Error("APPLICATION_WORKER_METADATA_INVALID");
  }
}
function fromError(error) {
  if (error.name === "AbandonedOperationError" && error.operation && (error.operation.status === "abandoned" || error.operation.status === "needsReapply")) return new AbandonedOperationError(error.operation);
  if (error.name === "RecoveredViewError" && error.revision) return new RecoveredViewError(error.revision);
  return Object.assign(new Error(error.message), { name: error.name, ...error.code === void 0 ? {} : { code: error.code } });
}
function validateStatus(value) {
  if (value === null || typeof value !== "object") throw new Error("APPLICATION_WORKER_METADATA_INVALID");
  const status = value;
  if (!["ready", "waiting", "recovering", "awaiting-keys", "closed"].includes(status.phase) || !["idle", "opening", "ready", "failed", "closed"].includes(status.database) || !["coordinator", "follower"].includes(status.role) || typeof status.generation !== "string" || !/^[0-9a-f]{64}$/u.test(status.generation) || typeof status.coordinator !== "string" || !/^[0-9a-f]{64}$/u.test(status.coordinator) || !Number.isSafeInteger(status.connectedPeers) || status.connectedPeers < 0 || status.connectedPeers > 8) throw new Error("APPLICATION_WORKER_METADATA_INVALID");
}
function validEndpoint(value) {
  return value !== void 0 && ["ownerInstanceId", "endpointId", "endpointIncarnation"].every((key) => typeof value[key] === "string" && /^[A-Za-z0-9-]{1,128}$/u.test(value[key])) && value.evidence === "owner-bound" && ["caller-asserted", "owner-validated"].includes(value.contextEvidence) && value.context !== null && typeof value.context === "object" && Array.isArray(value.capabilities) && value.capabilities.length <= 8 && value.capabilities.every((item) => typeof item === "string" && ["commands", "queries", "events", "content", "signals", "operations", "diagnostics", "ownerAdmin"].includes(item));
}
export {
  AbandonedOperationError,
  RecoveredViewError,
  WorkerApplicationSession,
  acquireApplicationOwnerLock,
  connectApplicationOwner,
  connectApplicationWorker
};
