/**
 * The single local byte-storage contract for identity, controls, journals and projections.
 * One owner serializes mutations. Each put atomically replaces one key and resolves only
 * after durable persistence. get and put must not expose mutable internal byte buffers.
 */
export interface BytesStoreEntry {
    readonly key: string;
    readonly value: Uint8Array;
}
export interface BytesStore {
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, bytes: Uint8Array): Promise<void>;
    /** Optional deterministic snapshot enumeration for atomic encrypted device checkpoints. */
    entries?(): Promise<readonly BytesStoreEntry[]>;
    /** Atomically initialize an empty store; false leaves an existing store untouched. */
    putAllIfEmpty?(entries: readonly BytesStoreEntry[]): Promise<boolean>;
}
/** Independent ephemeral storage for disposable peers and tests; not a durability claim. */
export declare class MemoryBytesStore implements BytesStore {
    #private;
    constructor(options?: {
        readonly quotaBytes?: number;
        readonly maxValueBytes?: number;
    });
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, bytes: Uint8Array): Promise<void>;
    putAllIfEmpty(entries: readonly BytesStoreEntry[]): Promise<boolean>;
    entries(): Promise<readonly BytesStoreEntry[]>;
}
