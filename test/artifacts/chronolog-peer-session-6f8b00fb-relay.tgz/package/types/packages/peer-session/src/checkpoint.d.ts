import type { BytesStore } from '../../records/src/index.js';
export declare const CHECKPOINT_FORMAT = "chronolog-device-checkpoint-v1";
export declare const DEVICE_RETIRED_KEY = "peer-session/checkpoint-retired/v1";
export interface CheckpointMetadata {
    readonly format: typeof CHECKPOINT_FORMAT;
    readonly applicationId: string | null;
    readonly deviceId: string | null;
    readonly createdAt: string;
    readonly entryCount: number;
    readonly hasSqlDatabase: boolean;
    readonly outboxCount: number;
    readonly manifestSha256: string;
}
export interface CheckpointOutboxRecord {
    readonly operationId: string;
    readonly command?: string;
    readonly payloadHash?: string;
    readonly createdAt: string;
    readonly status?: string;
}
export interface ExportCheckpointOptions {
    /** 32-byte raw AES-256-GCM key or passphrase string (derived via PBKDF2-SHA256). */
    readonly secret: Uint8Array | string;
    readonly applicationId?: string | null;
    readonly deviceId?: string | null;
    /** Optional quiesced SQLite database bytes (read after WAL checkpoint, never raw sidecar copy). */
    readonly sqlDatabaseBytes?: Uint8Array | null;
    /** Optional pending pre-submission outbox records to carry across sandbox replacement. */
    readonly outbox?: readonly CheckpointOutboxRecord[];
    /** Mark the exported source store retired (default: true) to prevent split-brain active copies. */
    readonly retireSource?: boolean;
    /** Durably retain the encrypted checkpoint before retiring its source. Required for moves. */
    readonly persist?: (checkpoint: Readonly<{
        bytes: Uint8Array;
        metadata: CheckpointMetadata;
    }>) => void | Promise<void>;
}
export interface ExportedCheckpoint {
    readonly bytes: Uint8Array;
    readonly metadata: CheckpointMetadata;
    readonly retiredSource: boolean;
}
export interface RestoredCheckpoint {
    readonly metadata: CheckpointMetadata;
    readonly sqlDatabaseBytes: Uint8Array | null;
    readonly outbox: readonly CheckpointOutboxRecord[];
    readonly restoredEntries: number;
}
/** Check whether a store has been retired by an earlier checkpoint export. */
export declare function isDeviceRetired(store: BytesStore): Promise<{
    readonly retired: boolean;
    readonly retiredAt?: string;
    readonly manifestSha256?: string;
}>;
/** Fail closed if a store was retired by an earlier checkpoint handoff. */
export declare function assertDeviceNotRetired(store: BytesStore): Promise<void>;
/**
 * Export a quiesced store under the local device/checkpoint fence
 * (Node SQLite, Browser IndexedDB/OPFS, or Serverless KV) and optionally retire the source store.
 */
export declare function exportDeviceCheckpoint(store: BytesStore, options: ExportCheckpointOptions): Promise<ExportedCheckpoint>;
/**
 * Decrypt, authenticate, and restore an atomic device checkpoint into a clean target BytesStore.
 * Requires atomic empty-store initialization. Existing identity is never overwritten.
 */
export declare function restoreDeviceCheckpoint(targetStore: BytesStore, encryptedBytes: Uint8Array, options: {
    readonly secret: Uint8Array | string;
}): Promise<RestoredCheckpoint>;
export declare function generateCheckpointKey(): Uint8Array;
export declare function encodeCheckpointKeyHex(key: Uint8Array): string;
export declare function decodeCheckpointKeyHex(hex: string): Uint8Array;
