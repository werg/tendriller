import {
  eventExecutionManifest
} from "./chunks/chunk-KIZDMFEG.mjs";
import {
  SessionError,
  canonicalJson,
  createAppClient,
  createLiveView,
  createViewStore,
  describeOperationLifecycle,
  identifier,
  operationReference,
  signerId,
  submitBatch
} from "./chunks/chunk-4PRKLFZ6.mjs";
import {
  createApplicationOwner
} from "./chunks/chunk-RZ5DMPXA.mjs";
import {
  ApplicationControlParticipant,
  ApplicationPublicationError,
  ApplicationSession,
  applicationDefinitionDigest,
  claimApplicationDevice,
  connectApplications,
  defineApplication,
  defineCommand,
  defineQuery,
  describeApplication,
  openApplicationDevice,
  openPeerApplication
} from "./chunks/chunk-RZAPODG7.mjs";
import {
  APPLICATION_EVENT_CURSOR_LIMIT,
  APPLICATION_PROJECTION_LIMITS,
  ApplicationOperation,
  createPeerReplica
} from "./chunks/chunk-BCZYAFUK.mjs";
import {
  acquireApplicationOwnerLock
} from "./chunks/chunk-2ZKHAZYZ.mjs";
import {
  CHECKPOINT_FORMAT,
  DEVICE_RETIRED_KEY,
  assertDeviceNotRetired,
  decodeCheckpointKeyHex,
  encodeCheckpointKeyHex,
  exportDeviceCheckpoint,
  generateCheckpointKey,
  isDeviceRetired,
  restoreDeviceCheckpoint
} from "./chunks/chunk-OZLWN7FL.mjs";
import {
  AbandonedOperationError,
  ApplicationControlConflictError,
  RecoveredViewError
} from "./chunks/chunk-TLZH7OYA.mjs";
import {
  awaitOwnedTask
} from "./chunks/chunk-KSC4KBWO.mjs";
import {
  MemoryBytesStore
} from "./chunks/chunk-DAFLY5U7.mjs";
import {
  CONTROL_PARTICIPANT_POLICY,
  PARTICIPANT_LIMITS,
  PARTICIPANT_PROTOCOL,
  PEER_PARTICIPANT_POLICY,
  PUBLICATION_LIMITS,
  ParticipantProtocolError,
  PeerAuthority,
  assertAuthorityExtension,
  authorizePublication,
  controlParticipantGrant,
  createGenerationRegistry,
  createParticipantRequest,
  createParticipantResponse,
  createParticipantTransport,
  createPublicationRegistry,
  generationStartRoot,
  participantAccepts,
  participantGrant,
  signApplicationDescriptor,
  signApplicationSchema,
  signControlRevision,
  signPublicationManifest,
  signTransitionRequest,
  validateHistoryPoint,
  validateParticipantRequest,
  validateParticipantResponse,
  validatePeerRevision,
  validatePublicationManifest,
  verifyApplicationSchema,
  verifyAuthorityBundle,
  verifyOrderReceipt,
  verifyPublicationAsset,
  verifyPublicationManifest
} from "./chunks/chunk-J6GIQ6XT.mjs";
import {
  PEER_GENERATION_CAPABILITIES,
  PEER_GENERATION_POLICY,
  PEER_GENERATION_PROFILE,
  PEER_MAX_HISTORY_BYTES,
  PEER_MAX_RECORDS,
  PeerGenerationError,
  applicationDescriptionDigest,
  bytesDigest,
  checkedApplicationInputSchema,
  createPeerIdentity,
  decodePeerValue,
  encodePeerValue,
  exportPeerIdentity,
  importPeerIdentity,
  parseApplicationInput,
  peerDigest,
  samePeerValue,
  validateApplicationDescription
} from "./chunks/chunk-R6JLOHZW.mjs";
import {
  APPLICATION_COLLECTIVE_ID,
  bytesToHex,
  emit,
  executionManifestArtifacts,
  hexToBytes,
  program,
  sqlStatement
} from "./chunks/chunk-KPMB233Z.mjs";
import "./chunks/chunk-DEFS6EFN.mjs";

// packages/peer-session/src/tools.ts
var digestSchema = { type: "string", pattern: "^[0-9a-f]{64}$" };
var unsignedSchema = { type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER };
var revisionSchema = {
  type: "object",
  additionalProperties: false,
  required: ["applicationId", "historyId", "generation", "point", "controlRevision", "materializationRevision"],
  properties: {
    applicationId: digestSchema,
    historyId: { type: "string", minLength: 1, maxLength: 128, pattern: "^[^\\u0000-\\u001f\\u007f]+$" },
    generation: digestSchema,
    controlRevision: unsignedSchema,
    materializationRevision: { type: "string", pattern: "^[0-9]{1,32}$" },
    point: {
      type: "object",
      additionalProperties: false,
      required: ["generation", "sequence", "root"],
      properties: { generation: digestSchema, sequence: unsignedSchema, root: digestSchema }
    }
  }
};
function inputRevision(session, value) {
  if (value === void 0) return void 0;
  const revision = value;
  validatePeerRevision(revision);
  if (revision.applicationId !== session.applicationId || revision.historyId !== session.historyId) {
    throw new Error("APPLICATION_TOOL_REVISION_SCOPE_MISMATCH");
  }
  return revision;
}
function sameRevision(left, right) {
  return left.applicationId === right.applicationId && left.historyId === right.historyId && left.generation === right.generation && left.controlRevision === right.controlRevision && left.materializationRevision === right.materializationRevision && left.point.generation === right.point.generation && left.point.sequence === right.point.sequence && left.point.root === right.point.root;
}
async function observeChange(session, after, waitMs, signal) {
  if (typeof waitMs !== "number" || !Number.isSafeInteger(waitMs) || waitMs < 0 || waitMs > 3e4) {
    throw new Error("APPLICATION_TOOL_INPUT_INVALID");
  }
  const deadline = new AbortController(), observation = AbortSignal.any([signal, deadline.signal]);
  const iterator = session.changes({ signal: observation })[Symbol.asyncIterator]();
  const timer = setTimeout(() => {
    deadline.abort();
  }, waitMs);
  try {
    while (true) {
      const next = await iterator.next();
      signal.throwIfAborted();
      if (next.done === true) return { change: null, resetRequired: false };
      const change = next.value;
      if (after !== void 0 && sameRevision(after, change.revision)) continue;
      const resetRequired = after !== void 0 && after.generation !== change.revision.generation;
      const recovery = change.recovery ?? (resetRequired ? (await session.inspectRecovery()).findLast((notice) => notice.generation === change.revision.generation) ?? null : null);
      return { change: recovery === null ? change : { ...change, kind: "recovery", recovery }, resetRequired };
    }
  } finally {
    clearTimeout(timer);
    await iterator.return?.();
  }
}
function createApplicationTools(session, options = {}) {
  const description = session.describe(), operationId = { type: "string", minLength: 1, maxLength: 512 };
  const object = (properties, required = Object.keys(properties)) => ({ type: "object", properties, required, additionalProperties: false });
  const entries = (kind, fields, required = Object.keys(fields)) => ({ oneOf: description[kind].map((entry) => object({
    name: { type: "string", const: entry.name, description: entry.description },
    input: entry.input,
    ...fields
  }, ["name", "input", ...required])) });
  const tools = [
    { name: "describe", description: "Inspect authenticated application definitions, current role and supported guarantees.", inputSchema: object({}) },
    { name: "query", description: "Execute a declared query against one coherent captured application revision.", inputSchema: entries("queries", {}) },
    { name: "command", description: "Save one signed command under a caller-owned operation ID, optionally guarded by a captured revision. Returns saved or currently applied state.", inputSchema: entries("commands", { operationId, basedOn: revisionSchema }, ["operationId"]) },
    { name: "operation", description: "Inspect saved attempt bytes, current outcome and explicit reapplication linkage. Author defaults to this device; specify the original signer to inspect another participant's retained work.", inputSchema: object({ operationId, author: digestSchema }, ["operationId"]) },
    { name: "retry", description: "Retry this device's exact saved command. Never recreates an abandoned operation.", inputSchema: object({ operationId }) },
    { name: "wait", description: "Wait for the current applied result of this device or an explicit original author. Cancellation only cancels this wait.", inputSchema: object({ operationId, author: digestSchema }, ["operationId"]) },
    {
      name: "changes",
      description: "Observe one coalesced coherent revision, optionally waiting after a captured revision. A generation change requires a reread; this is not an event replay cursor.",
      inputSchema: object({ after: revisionSchema, waitMs: { type: "integer", minimum: 0, maximum: 3e4, default: 0 } }, [])
    },
    { name: "recoveries", description: "Inspect generation recovery notices and preserved abandoned operations.", inputSchema: object({}) },
    { name: "reapply", description: "Deliberately create a newly signed, linked command from current input after abandonment, optionally guarded by a captured revision. Specify originalAuthor for another participant's work; the new command is always signed by this device.", inputSchema: entries("commands", { operationId, originalOperationId: operationId, originalAuthor: digestSchema, basedOn: revisionSchema }, ["operationId", "originalOperationId"]) },
    ...options.host === void 0 ? [] : [{ name: "takeover", description: "Select this eligible device's complete recovery point through the hosted authority; may abandon a recent suffix.", inputSchema: object({ transitionId: { type: "string", minLength: 1, maxLength: 128 } }) }]
  ];
  return {
    list() {
      return structuredClone(tools);
    },
    async call(name, input, callOptions = {}) {
      const signal = callOptions.signal === void 0 ? session.signal : AbortSignal.any([session.signal, callOptions.signal]);
      return awaitOwnedTask(signal, async () => {
        if (input === null || typeof input !== "object" || Array.isArray(input)) throw new Error("APPLICATION_TOOL_INPUT_INVALID");
        const value = input;
        const text = (key) => {
          if (typeof value[key] !== "string") throw new Error("APPLICATION_TOOL_INPUT_INVALID");
          return value[key];
        };
        const author = (key) => {
          if (value[key] === void 0) return void 0;
          const identity = text(key);
          if (!/^[0-9a-f]{64}$/u.test(identity)) throw new Error("APPLICATION_TOOL_INPUT_INVALID");
          return identity;
        };
        const fields = (...keys) => {
          if (Object.keys(value).some((key) => !keys.includes(key))) throw new Error("APPLICATION_TOOL_INPUT_INVALID");
        };
        switch (name) {
          case "describe":
            fields();
            return { definition: description, status: session.status };
          case "query":
            fields("name", "input");
            return session.query(text("name"), value.input);
          case "command": {
            fields("name", "input", "operationId", "basedOn");
            const basedOn = inputRevision(session, value.basedOn);
            const operation = await session.command(text("name"), value.input, {
              operationId: text("operationId"),
              ...basedOn === void 0 ? {} : { basedOn }
            });
            return operation.get();
          }
          case "operation": {
            fields("operationId", "author");
            const signer = author("author");
            return session.operations.inspect(text("operationId"), signer === void 0 ? {} : { author: signer });
          }
          case "retry":
            fields("operationId");
            await session.retry(text("operationId"));
            return session.operations.get(text("operationId"));
          case "wait": {
            fields("operationId", "author");
            const signer = author("author");
            return session.operations.wait(text("operationId"), { signal, ...signer === void 0 ? {} : { author: signer } });
          }
          case "changes":
            fields("after", "waitMs");
            return observeChange(session, inputRevision(session, value.after), value.waitMs === void 0 ? 0 : value.waitMs, signal);
          case "recoveries":
            fields();
            return session.inspectRecovery();
          case "reapply": {
            fields("name", "input", "operationId", "originalOperationId", "originalAuthor", "basedOn");
            const basedOn = inputRevision(session, value.basedOn);
            const originalAuthor = author("originalAuthor");
            const operation = await session.reapply(text("originalOperationId"), text("name"), value.input, {
              operationId: text("operationId"),
              ...originalAuthor === void 0 ? {} : { originalAuthor },
              ...basedOn === void 0 ? {} : { basedOn }
            });
            return operation.get();
          }
          case "takeover":
            fields("transitionId");
            if (options.host === void 0) throw new Error("APPLICATION_TOOL_UNAVAILABLE");
            return session.recovery.takeover(options.host, { transitionId: text("transitionId") });
          default:
            throw new Error("APPLICATION_TOOL_UNKNOWN");
        }
      });
    }
  };
}
function createScopedApplicationTools(session, options = {}) {
  const allowedQueries = new Set(options.queries ?? []);
  const allowedCommands = new Set(options.commands ?? []);
  const tools = createApplicationTools(session, options.host === void 0 ? {} : { host: options.host });
  return Object.freeze({
    allowed: Object.freeze({ queries: Object.freeze([...allowedQueries]), commands: Object.freeze([...allowedCommands]) }),
    async execute(call, callOptions = {}) {
      if (call === null || typeof call !== "object") throw new Error("APPLICATION_TOOL_INPUT_INVALID");
      const { kind, name, input, operationId, basedOn, originalOperationId, originalAuthor, generation } = call;
      const signal = callOptions.signal === void 0 ? session.signal : AbortSignal.any([session.signal, callOptions.signal]);
      signal.throwIfAborted();
      const journal = kind === "operation" || kind === "retry" || kind === "wait";
      const write = kind === "command" || kind === "reapply";
      if (!(journal || write || kind === "query") || !(kind === "query" ? allowedQueries : allowedCommands).has(name)) {
        throw Object.assign(new Error("APPLICATION_TOOL_NOT_ALLOWED"), { code: "APPLICATION_TOOL_NOT_ALLOWED" });
      }
      if (generation !== void 0 && generation !== session.status.generation) {
        throw Object.assign(new Error("APPLICATION_TOOL_GENERATION_CHANGED"), { code: "APPLICATION_TOOL_GENERATION_CHANGED" });
      }
      if (journal || kind === "reapply") {
        const id = kind === "reapply" ? originalOperationId : operationId;
        if (typeof id !== "string") throw new Error("APPLICATION_TOOL_INPUT_INVALID");
        const original = await awaitOwnedTask(signal, () => session.operations.inspect(
          id,
          kind === "reapply" && originalAuthor !== void 0 ? { author: originalAuthor } : {}
        ));
        if (original === null || (journal ? original.attempt.payload.header.command !== name : !allowedCommands.has(original.attempt.payload.header.command))) {
          throw Object.assign(new Error("APPLICATION_TOOL_NOT_ALLOWED"), { code: "APPLICATION_TOOL_NOT_ALLOWED" });
        }
        if (generation !== void 0 && generation !== session.status.generation) {
          throw Object.assign(new Error("APPLICATION_TOOL_GENERATION_CHANGED"), { code: "APPLICATION_TOOL_GENERATION_CHANGED" });
        }
      }
      const args = journal ? { operationId } : {
        name,
        input,
        ...write ? {
          operationId,
          ...basedOn === void 0 ? {} : { basedOn },
          ...kind === "reapply" ? { originalOperationId, ...originalAuthor === void 0 ? {} : { originalAuthor } } : {}
        } : {}
      };
      const raw = await tools.call(kind, args, callOptions);
      if (generation !== void 0 && generation !== session.status.generation) {
        throw Object.assign(new Error("APPLICATION_TOOL_GENERATION_CHANGED"), { code: "APPLICATION_TOOL_GENERATION_CHANGED" });
      }
      if (raw !== null && raw !== void 0 && typeof raw === "object" && (write || journal)) {
        return {
          ...raw,
          operationReference: operationReference(
            session,
            operationId,
            journal && kind === "operation" ? raw?.state : raw
          )
        };
      }
      return raw;
    }
  });
}
function formatApplicationToolResult(value) {
  return JSON.stringify(value, (_key, item) => {
    if (typeof item === "bigint") return { $integer: String(item) };
    if (item instanceof Uint8Array) return { $bytes: Array.from(item, (byte) => byte.toString(16).padStart(2, "0")).join("") };
    return item;
  });
}
async function serveApplicationToolLines(session, options) {
  const tools = createApplicationTools(session, options);
  const lifetime = options.signal === void 0 ? session.signal : AbortSignal.any([session.signal, options.signal]);
  lifetime.throwIfAborted();
  const iterator = options.input[Symbol.asyncIterator]();
  let ended = false;
  try {
    while (true) {
      const next = await awaitOwnedTask(lifetime, () => iterator.next());
      if (next.done) {
        ended = true;
        return;
      }
      const line = next.value;
      let id = null;
      let response;
      try {
        if (new TextEncoder().encode(line).length > 262144) throw new Error("APPLICATION_TOOL_LINE_TOO_LARGE");
        const request = JSON.parse(line);
        if (request === null || typeof request !== "object" || Array.isArray(request) || typeof request.id !== "string" && (typeof request.id !== "number" || !Number.isSafeInteger(request.id))) throw new Error("APPLICATION_TOOL_REQUEST_INVALID");
        id = request.id;
        const timeoutMs = request.timeoutMs ?? 3e4;
        if (typeof timeoutMs !== "number" || !Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 6e4) throw new Error("APPLICATION_TOOL_TIMEOUT_INVALID");
        const value = request.tool === "list" ? tools.list() : typeof request.tool === "string" ? await tools.call(request.tool, request.input ?? {}, { signal: AbortSignal.any([lifetime, AbortSignal.timeout(timeoutMs)]) }) : (() => {
          throw new Error("APPLICATION_TOOL_REQUEST_INVALID");
        })();
        response = { id, result: value };
      } catch (error) {
        lifetime.throwIfAborted();
        const state = error instanceof Error && "operation" in error ? { operation: error.operation } : {};
        response = { id, error: error instanceof Error ? error.message : "APPLICATION_TOOL_FAILED", ...state };
      }
      await awaitOwnedTask(lifetime, () => options.write(`${formatApplicationToolResult(response)}
`));
    }
  } finally {
    if (!ended && iterator.return !== void 0) {
      try {
        void Promise.resolve(iterator.return()).catch(() => void 0);
      } catch {
      }
    }
  }
}

// packages/peer-session/src/event-forwarder.ts
async function forwardSessionEvents(options) {
  const { session, topics, limit = 32, checkpoint, project, deliver, signal } = options;
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 256) {
    throw Object.assign(new Error("EVENT_FORWARDER_LIMIT_INVALID"), { code: "EVENT_FORWARDER_LIMIT_INVALID" });
  }
  const owner = new AbortController();
  const lifetime = AbortSignal.any([session.signal, owner.signal, ...signal === void 0 ? [] : [signal]]);
  const selectedTopics = topics === void 0 ? void 0 : [...topics];
  let iterator;
  let captured = false, queued = false, ended = false;
  let wake = () => void 0;
  try {
    let cursor = await awaitOwnedTask(lifetime, () => checkpoint.load());
    iterator = session.changes({ signal: lifetime })[Symbol.asyncIterator]();
    const changes = iterator;
    void (async () => {
      for (; ; ) {
        const next = await awaitOwnedTask(lifetime, () => changes.next());
        if (next.done === true) {
          ended = true;
          wake();
          return;
        }
        if (next.value.kind === "recovery" && (cursor !== void 0 || captured)) {
          throw Object.assign(new Error("EVENT_FORWARDER_REVIEW_RECOVERY"), { code: "EVENT_FORWARDER_REVIEW_RECOVERY" });
        }
        queued = true;
        wake();
      }
    })().catch((error) => {
      owner.abort(error);
    });
    for (; ; ) {
      if (!queued && !ended) await awaitOwnedTask(lifetime, () => new Promise((resolve) => {
        wake = resolve;
      }));
      lifetime.throwIfAborted();
      if (!queued) return;
      queued = false;
      for (; ; ) {
        captured = true;
        const batch = await awaitOwnedTask(lifetime, async () => {
          const view = await session.readView();
          let result;
          try {
            lifetime.throwIfAborted();
            result = await view.readEvents({
              ...cursor === void 0 ? {} : { cursor },
              ...selectedTopics === void 0 ? {} : { topics: selectedTopics },
              limit
            });
          } catch (error) {
            try {
              await view.release();
            } catch {
            }
            throw error;
          }
          await view.release();
          return result;
        });
        if (batch.hasMore && batch.cursor === cursor) throw new Error("EVENT_FORWARDER_CURSOR_STALLED");
        for (const event of batch.events) {
          const projected = await awaitOwnedTask(lifetime, () => project(event, batch));
          if (projected !== null && projected !== void 0) {
            await awaitOwnedTask(lifetime, () => deliver(projected, event, batch, lifetime));
          }
        }
        if (batch.cursor !== cursor) {
          await awaitOwnedTask(lifetime, () => checkpoint.save(batch.cursor));
          cursor = batch.cursor;
        }
        if (!batch.hasMore) break;
      }
    }
  } finally {
    owner.abort(new Error("EVENT_FORWARDER_CLOSED"));
    try {
      void Promise.resolve(iterator?.return?.()).catch(() => void 0);
    } catch {
    }
  }
}
export {
  APPLICATION_COLLECTIVE_ID,
  APPLICATION_EVENT_CURSOR_LIMIT,
  APPLICATION_PROJECTION_LIMITS,
  AbandonedOperationError,
  ApplicationControlConflictError,
  ApplicationControlParticipant,
  ApplicationOperation,
  ApplicationPublicationError,
  ApplicationSession,
  CHECKPOINT_FORMAT,
  CONTROL_PARTICIPANT_POLICY,
  DEVICE_RETIRED_KEY,
  MemoryBytesStore,
  PARTICIPANT_LIMITS,
  PARTICIPANT_PROTOCOL,
  PEER_GENERATION_CAPABILITIES,
  PEER_GENERATION_POLICY,
  PEER_GENERATION_PROFILE,
  PEER_MAX_HISTORY_BYTES,
  PEER_MAX_RECORDS,
  PEER_PARTICIPANT_POLICY,
  PUBLICATION_LIMITS,
  ParticipantProtocolError,
  PeerAuthority,
  PeerGenerationError,
  RecoveredViewError,
  SessionError,
  acquireApplicationOwnerLock,
  applicationDefinitionDigest,
  applicationDescriptionDigest,
  assertAuthorityExtension,
  assertDeviceNotRetired,
  authorizePublication,
  bytesDigest,
  bytesToHex,
  canonicalJson,
  checkedApplicationInputSchema,
  claimApplicationDevice,
  connectApplications,
  controlParticipantGrant,
  createAppClient,
  createApplicationOwner,
  createApplicationTools,
  createGenerationRegistry,
  createLiveView,
  createParticipantRequest,
  createParticipantResponse,
  createParticipantTransport,
  createPeerIdentity,
  createPeerReplica,
  createPublicationRegistry,
  createScopedApplicationTools,
  createViewStore,
  decodeCheckpointKeyHex,
  decodePeerValue,
  defineApplication,
  defineCommand,
  defineQuery,
  describeApplication,
  describeOperationLifecycle,
  emit,
  encodeCheckpointKeyHex,
  encodePeerValue,
  eventExecutionManifest,
  executionManifestArtifacts,
  exportDeviceCheckpoint,
  exportPeerIdentity,
  formatApplicationToolResult,
  forwardSessionEvents,
  generateCheckpointKey,
  generationStartRoot,
  hexToBytes,
  identifier,
  importPeerIdentity,
  isDeviceRetired,
  openApplicationDevice,
  openPeerApplication,
  operationReference,
  parseApplicationInput,
  participantAccepts,
  participantGrant,
  peerDigest,
  program,
  restoreDeviceCheckpoint,
  samePeerValue,
  serveApplicationToolLines,
  signApplicationDescriptor,
  signApplicationSchema,
  signControlRevision,
  signPublicationManifest,
  signTransitionRequest,
  signerId,
  sqlStatement,
  submitBatch,
  validateApplicationDescription,
  validateHistoryPoint,
  validateParticipantRequest,
  validateParticipantResponse,
  validatePeerRevision,
  validatePublicationManifest,
  verifyApplicationSchema,
  verifyAuthorityBundle,
  verifyOrderReceipt,
  verifyPublicationAsset,
  verifyPublicationManifest
};
