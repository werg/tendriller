import {
  bytesToHex,
  hexToBytes
} from "./chunk-KPMB233Z.mjs";

// packages/peer-session/src/checkpoint-lifecycle.ts
var states = /* @__PURE__ */ new WeakMap();
function state(store) {
  let value = states.get(store);
  if (value === void 0) {
    value = { users: 0, checkpoint: false, retired: false };
    states.set(store, value);
  }
  return value;
}
function useDeviceStore(store) {
  const value = state(store);
  if (value.retired) throw Object.assign(new Error("DEVICE_RETIRED_BY_CHECKPOINT"), { code: "DEVICE_RETIRED_BY_CHECKPOINT" });
  if (value.checkpoint) throw Object.assign(new Error("CHECKPOINT_SOURCE_IN_USE"), { code: "CHECKPOINT_SOURCE_IN_USE" });
  value.users++;
  let released = false;
  return () => {
    if (!released) {
      released = true;
      value.users--;
    }
  };
}
function reserveCheckpointStore(store) {
  const value = state(store);
  if (value.users !== 0 || value.checkpoint) throw Object.assign(new Error("CHECKPOINT_SOURCE_IN_USE"), { code: "CHECKPOINT_SOURCE_IN_USE" });
  value.checkpoint = true;
  return () => {
    value.checkpoint = false;
  };
}
function retireDeviceStore(store) {
  state(store).retired = true;
}

// packages/peer-session/src/checkpoint.ts
var CHECKPOINT_FORMAT = "chronolog-device-checkpoint-v1";
var DEVICE_RETIRED_KEY = "peer-session/checkpoint-retired/v1";
var MAGIC = new Uint8Array([67, 76, 67, 80, 1]);
var SALT_BYTES = 16;
var IV_BYTES = 12;
var PBKDF2_ITERATIONS = 1e5;
var encoder = new TextEncoder();
var decoder = new TextDecoder("utf-8", { fatal: true });
var MAX_CHECKPOINT_BYTES = 32 * 1024 * 1024;
var MAX_ENTRIES = 4096;
function fail(code, message) {
  return Object.assign(new Error(message), { code });
}
async function deriveAesKey(secret, salt, usage) {
  if (secret instanceof Uint8Array) {
    if (secret.byteLength !== 32) throw fail("CHECKPOINT_KEY_INVALID", "Raw checkpoint encryption key must be exactly 32 bytes.");
    const copy = new Uint8Array(secret.byteLength);
    copy.set(secret);
    return crypto.subtle.importKey("raw", copy, { name: "AES-GCM" }, false, [...usage]);
  }
  if (typeof secret !== "string" || secret.length < 12) {
    throw fail("CHECKPOINT_KEY_INVALID", "Checkpoint passphrase must be at least 12 characters.");
  }
  const baseKey = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "PBKDF2" }, false, ["deriveKey"]);
  const saltCopy = new Uint8Array(salt.byteLength);
  saltCopy.set(salt);
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", hash: "SHA-256", salt: saltCopy, iterations: PBKDF2_ITERATIONS },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    [...usage]
  );
}
function encodeBase64(bytes) {
  let binary = "";
  const chunk = 32768;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + chunk, bytes.length)));
  }
  return btoa(binary);
}
function decodeBase64(value) {
  const binary = atob(value);
  if (btoa(binary) !== value) throw fail("CHECKPOINT_CORRUPT", "Invalid base64 checkpoint data.");
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}
async function sha256Hex(bytes) {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return bytesToHex(new Uint8Array(await crypto.subtle.digest("SHA-256", copy)));
}
async function manifestDigest(entries, sqlBytes, outbox) {
  const entryDigests = [];
  for (const entry of entries) entryDigests.push([entry.key, await sha256Hex(entry.value), entry.value.byteLength]);
  const sqlDigest = sqlBytes === null ? null : [await sha256Hex(sqlBytes), sqlBytes.byteLength];
  const canonical = JSON.stringify({ entries: entryDigests, sql: sqlDigest, outbox });
  return sha256Hex(encoder.encode(canonical));
}
function validateMetadata(metadata, outbox) {
  if (typeof metadata.createdAt !== "string" || !Number.isFinite(Date.parse(metadata.createdAt)) || [metadata.applicationId, metadata.deviceId].some((id) => id !== null && (typeof id !== "string" || !/^[a-f0-9]{64}$/u.test(id))) || typeof metadata.manifestSha256 !== "string" || !/^[a-f0-9]{64}$/u.test(metadata.manifestSha256) || outbox.length > 1024) throw fail("CHECKPOINT_CORRUPT", "Invalid checkpoint metadata.");
  const seen = /* @__PURE__ */ new Set();
  for (const entry of outbox) {
    if (!entry || typeof entry.operationId !== "string" || !entry.operationId || entry.operationId.length > 512 || [...entry.operationId].some((c) => c.charCodeAt(0) < 32 || c.charCodeAt(0) === 127) || seen.has(entry.operationId) || typeof entry.createdAt !== "string" || !Number.isFinite(Date.parse(entry.createdAt)) || entry.command !== void 0 && (typeof entry.command !== "string" || !entry.command || entry.command.length > 128) || entry.payloadHash !== void 0 && (typeof entry.payloadHash !== "string" || !/^[a-f0-9]{64}$/u.test(entry.payloadHash)) || entry.status !== void 0 && (typeof entry.status !== "string" || entry.status.length > 128)) throw fail("CHECKPOINT_CORRUPT", "Invalid retained outbox record.");
    seen.add(entry.operationId);
  }
}
async function isDeviceRetired(store) {
  const raw = await store.get(DEVICE_RETIRED_KEY);
  if (raw === null) return { retired: false };
  try {
    const parsed = JSON.parse(decoder.decode(raw));
    return {
      retired: true,
      ...typeof parsed.retiredAt === "string" ? { retiredAt: parsed.retiredAt } : {},
      ...typeof parsed.manifestSha256 === "string" ? { manifestSha256: parsed.manifestSha256 } : {}
    };
  } catch {
    return { retired: true };
  }
}
async function assertDeviceNotRetired(store) {
  const status = await isDeviceRetired(store);
  if (status.retired) {
    throw fail("DEVICE_RETIRED_BY_CHECKPOINT", "This local device store was retired when exported to a checkpoint. Resume from the restored target instance.");
  }
}
async function exportDeviceCheckpoint(store, options) {
  if (options.retireSource !== false && typeof options.persist !== "function") throw fail("CHECKPOINT_PERSISTENCE_REQUIRED", "Durably persist the encrypted handoff before source retirement.");
  options = { ...options, secret: options.secret instanceof Uint8Array ? options.secret.slice() : options.secret };
  const release = reserveCheckpointStore(store);
  try {
    if (typeof store.entries !== "function") {
      throw fail("CHECKPOINT_ENUMERATION_UNSUPPORTED", "The supplied BytesStore does not support deterministic checkpoint enumeration.");
    }
    await assertDeviceNotRetired(store);
    const rawEntries = (await store.entries()).filter((entry) => entry.key !== DEVICE_RETIRED_KEY).map((entry) => ({ key: entry.key, value: entry.value.slice() })).sort((a, b) => a.key < b.key ? -1 : a.key > b.key ? 1 : 0);
    const seenKeys = /* @__PURE__ */ new Set();
    for (const entry of rawEntries) {
      if (typeof entry.key !== "string" || entry.key.length === 0 || entry.key.length > 2048 || [...entry.key].some((c) => c.charCodeAt(0) < 32) || seenKeys.has(entry.key)) throw fail("CHECKPOINT_CORRUPT", "Invalid source checkpoint key.");
      seenKeys.add(entry.key);
    }
    const sqlBytes = options.sqlDatabaseBytes?.slice() ?? null;
    const outbox = structuredClone(options.outbox ?? []);
    if (rawEntries.length > MAX_ENTRIES || rawEntries.reduce((size, entry) => size + entry.value.byteLength, sqlBytes?.byteLength ?? 0) > MAX_CHECKPOINT_BYTES / 2) {
      throw fail("CHECKPOINT_LIMIT_EXCEEDED", "Checkpoint data exceeds the bounded handoff limit.");
    }
    const createdAt = (/* @__PURE__ */ new Date()).toISOString();
    const manifestSha256 = await manifestDigest(rawEntries, sqlBytes, outbox);
    const metadata = Object.freeze({
      format: CHECKPOINT_FORMAT,
      applicationId: options.applicationId ?? null,
      deviceId: options.deviceId ?? null,
      createdAt,
      entryCount: rawEntries.length,
      hasSqlDatabase: sqlBytes !== null,
      outboxCount: outbox.length,
      manifestSha256
    });
    validateMetadata(metadata, outbox);
    const plaintext = encoder.encode(JSON.stringify({
      metadata,
      entries: rawEntries.map((entry) => ({ key: entry.key, value: encodeBase64(entry.value) })),
      sqlDatabaseBase64: sqlBytes === null ? null : encodeBase64(sqlBytes),
      outbox
    }));
    if (plaintext.byteLength > MAX_CHECKPOINT_BYTES - 64) throw fail("CHECKPOINT_LIMIT_EXCEEDED", "Encoded checkpoint exceeds the bounded handoff limit.");
    const isRawKey = options.secret instanceof Uint8Array;
    const salt = isRawKey ? new Uint8Array(SALT_BYTES) : crypto.getRandomValues(new Uint8Array(SALT_BYTES));
    const iv = crypto.getRandomValues(new Uint8Array(IV_BYTES));
    const key = await deriveAesKey(options.secret, salt, ["encrypt"]);
    const aad = encoder.encode(CHECKPOINT_FORMAT);
    const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: aad }, key, plaintext));
    const out = new Uint8Array(MAGIC.length + 1 + SALT_BYTES + IV_BYTES + ciphertext.byteLength);
    let offset = 0;
    out.set(MAGIC, offset);
    offset += MAGIC.length;
    out[offset++] = isRawKey ? 1 : 0;
    out.set(salt, offset);
    offset += SALT_BYTES;
    out.set(iv, offset);
    offset += IV_BYTES;
    out.set(ciphertext, offset);
    await options.persist?.(Object.freeze({ bytes: out.slice(), metadata }));
    const retireSource = options.retireSource !== false;
    if (retireSource) {
      retireDeviceStore(store);
      await store.put(DEVICE_RETIRED_KEY, encoder.encode(JSON.stringify({ retiredAt: createdAt, manifestSha256 })));
    }
    return Object.freeze({ bytes: out, metadata, retiredSource: retireSource });
  } finally {
    release();
  }
}
async function restoreDeviceCheckpoint(targetStore, encryptedBytes, options) {
  if (typeof targetStore.entries !== "function" || typeof targetStore.putAllIfEmpty !== "function") throw fail("CHECKPOINT_RESTORE_UNSUPPORTED", "Restore requires atomic empty-store initialization and enumeration.");
  const release = reserveCheckpointStore(targetStore);
  try {
    const headerLength = MAGIC.length + 1 + SALT_BYTES + IV_BYTES;
    if (!(encryptedBytes instanceof Uint8Array) || encryptedBytes.byteLength <= headerLength + 16 || encryptedBytes.byteLength > MAX_CHECKPOINT_BYTES) {
      throw fail("CHECKPOINT_CORRUPT", "Encrypted checkpoint is truncated or invalid.");
    }
    for (let i = 0; i < MAGIC.length; i++) {
      if (encryptedBytes[i] !== MAGIC[i]) throw fail("CHECKPOINT_FORMAT_UNSUPPORTED", "Unrecognized checkpoint header.");
    }
    let offset = MAGIC.length;
    const flags = encryptedBytes[offset++];
    if (flags !== 0 && flags !== 1) throw fail("CHECKPOINT_CORRUPT", "Unrecognized checkpoint flags.");
    const expectRaw = (flags & 1) === 1;
    if (expectRaw !== options.secret instanceof Uint8Array) {
      throw fail("CHECKPOINT_KEY_MISMATCH", expectRaw ? "This checkpoint requires a 32-byte raw key." : "This checkpoint requires a passphrase.");
    }
    const salt = encryptedBytes.subarray(offset, offset + SALT_BYTES);
    offset += SALT_BYTES;
    if (expectRaw && salt.some((byte) => byte !== 0)) throw fail("CHECKPOINT_CORRUPT", "Raw-key checkpoint salt must be zero.");
    const iv = new Uint8Array(encryptedBytes.subarray(offset, offset + IV_BYTES));
    offset += IV_BYTES;
    const ciphertext = new Uint8Array(encryptedBytes.subarray(offset));
    const key = await deriveAesKey(options.secret, salt, ["decrypt"]);
    const aad = encoder.encode(CHECKPOINT_FORMAT);
    let plaintext;
    try {
      plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv, additionalData: aad }, key, ciphertext);
    } catch {
      throw fail("CHECKPOINT_DECRYPT_FAILED", "Checkpoint authentication or decryption failed (wrong key or tampered bytes).");
    }
    let decoded;
    try {
      decoded = JSON.parse(decoder.decode(new Uint8Array(plaintext)));
      if (decoded?.metadata?.format !== CHECKPOINT_FORMAT || !Array.isArray(decoded.entries) || decoded.entries.length > MAX_ENTRIES || !Array.isArray(decoded.outbox) || decoded.outbox.length > 1024 || decoded.metadata.entryCount !== decoded.entries.length || decoded.metadata.outboxCount !== decoded.outbox.length || decoded.metadata.hasSqlDatabase !== (decoded.sqlDatabaseBase64 !== null) || !(decoded.sqlDatabaseBase64 === null || typeof decoded.sqlDatabaseBase64 === "string")) throw new Error();
      validateMetadata(decoded.metadata, decoded.outbox);
      const seen = /* @__PURE__ */ new Set();
      for (const entry of decoded.entries) {
        if (!entry || typeof entry.key !== "string" || entry.key.length === 0 || entry.key.length > 2048 || [...entry.key].some((c) => c.charCodeAt(0) < 32) || typeof entry.value !== "string" || seen.has(entry.key) || entry.key === DEVICE_RETIRED_KEY) throw new Error();
        seen.add(entry.key);
      }
    } catch {
      throw fail("CHECKPOINT_CORRUPT", "Decrypted checkpoint payload is malformed.");
    }
    let entries, sqlDatabaseBytes;
    try {
      entries = decoded.entries.map((item) => ({ key: item.key, value: decodeBase64(item.value) })).sort((a, b) => a.key < b.key ? -1 : a.key > b.key ? 1 : 0);
      sqlDatabaseBytes = decoded.sqlDatabaseBase64 === null ? null : decodeBase64(decoded.sqlDatabaseBase64);
    } catch {
      throw fail("CHECKPOINT_CORRUPT", "Invalid encoded checkpoint data.");
    }
    const actualDigest = await manifestDigest(entries, sqlDatabaseBytes, decoded.outbox);
    if (actualDigest !== decoded.metadata.manifestSha256) {
      throw fail("CHECKPOINT_INTEGRITY_MISMATCH", "Checkpoint manifest SHA-256 verification failed.");
    }
    if (!await targetStore.putAllIfEmpty(entries)) throw fail("CHECKPOINT_TARGET_NOT_EMPTY", "Restore requires a fresh target; existing identity is never overwritten.");
    if (typeof targetStore.entries === "function") {
      const readback = [...await targetStore.entries()].sort((a, b) => a.key < b.key ? -1 : a.key > b.key ? 1 : 0);
      const readbackDigest = await manifestDigest(readback, sqlDatabaseBytes, decoded.outbox);
      if (readbackDigest !== actualDigest) {
        throw fail("CHECKPOINT_RESTORE_VERIFICATION_FAILED", "Restored store contents did not match the checkpoint manifest.");
      }
    }
    return Object.freeze({
      metadata: Object.freeze(decoded.metadata),
      sqlDatabaseBytes,
      outbox: Object.freeze(decoded.outbox),
      restoredEntries: entries.length
    });
  } finally {
    release();
  }
}
function generateCheckpointKey() {
  return crypto.getRandomValues(new Uint8Array(32));
}
function encodeCheckpointKeyHex(key) {
  if (key.byteLength !== 32) throw fail("CHECKPOINT_KEY_INVALID", "Checkpoint key must be 32 bytes.");
  return bytesToHex(key);
}
function decodeCheckpointKeyHex(hex) {
  if (typeof hex !== "string" || !/^[0-9a-f]{64}$/iu.test(hex)) {
    throw fail("CHECKPOINT_KEY_INVALID", "Checkpoint key must be 64 hexadecimal characters.");
  }
  return hexToBytes(hex.toLowerCase());
}

export {
  useDeviceStore,
  CHECKPOINT_FORMAT,
  DEVICE_RETIRED_KEY,
  isDeviceRetired,
  assertDeviceNotRetired,
  exportDeviceCheckpoint,
  restoreDeviceCheckpoint,
  generateCheckpointKey,
  encodeCheckpointKeyHex,
  decodeCheckpointKeyHex
};
