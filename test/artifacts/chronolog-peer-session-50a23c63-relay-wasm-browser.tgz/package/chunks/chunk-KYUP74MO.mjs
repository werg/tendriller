import {
  ProtocolError,
  integerMap,
  protocolInvariant,
  utf8
} from "./chunk-V6KSH7C4.mjs";
import {
  concatBytes,
  encodeCanonicalCbor
} from "./chunk-PDJLSHX7.mjs";

// packages/crypto/src/hpke.ts
var HPKE_SUITE = "DHKEM(X25519,HKDF-SHA256)/HKDF-SHA256/AES-256-GCM";
var KEM_ID = Uint8Array.of(0, 32);
var KDF_ID = Uint8Array.of(0, 1);
var AEAD_ID = Uint8Array.of(0, 2);
var KEM_SUITE_ID = concatBytes(utf8("KEM"), KEM_ID);
var HPKE_SUITE_ID = concatBytes(utf8("HPKE"), KEM_ID, KDF_ID, AEAD_ID);
var HPKE_VERSION = utf8("HPKE-v1");
var HASH_SIZE = 32;
var X25519 = { name: "X25519" };
function source(value) {
  return Uint8Array.from(value).buffer;
}
function i2osp(value, length) {
  protocolInvariant(Number.isSafeInteger(value) && value >= 0 && value < 2 ** (8 * length), "INTEGER_OUT_OF_RANGE", "Integer does not fit HPKE field");
  const result = new Uint8Array(length);
  let remainder = value;
  for (let index = length - 1; index >= 0; index -= 1) {
    result[index] = remainder & 255;
    remainder = Math.floor(remainder / 256);
  }
  return result;
}
async function hmac(keyBytes, data) {
  const key = await globalThis.crypto.subtle.importKey(
    "raw",
    source(keyBytes),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return new Uint8Array(await globalThis.crypto.subtle.sign("HMAC", key, source(data)));
}
async function hkdfExtract(salt, ikm) {
  return hmac(salt.length === 0 ? new Uint8Array(HASH_SIZE) : salt, ikm);
}
async function hkdfExpand(prk, info, length) {
  protocolInvariant(length <= 255 * HASH_SIZE, "INTEGER_OUT_OF_RANGE", "HKDF output is too long");
  let previous = new Uint8Array();
  const blocks = [];
  for (let counter = 1; blocks.reduce((sum, block) => sum + block.length, 0) < length; counter += 1) {
    previous = await hmac(prk, concatBytes(previous, info, Uint8Array.of(counter)));
    blocks.push(previous);
  }
  return concatBytes(...blocks).slice(0, length);
}
async function labeledExtract(suiteId, salt, label, ikm) {
  return hkdfExtract(salt, concatBytes(HPKE_VERSION, suiteId, utf8(label), ikm));
}
async function labeledExpand(suiteId, prk, label, info, length) {
  return hkdfExpand(prk, concatBytes(i2osp(length, 2), HPKE_VERSION, suiteId, utf8(label), info), length);
}
async function generateX25519KeyPair(extractable = true) {
  const pair = await globalThis.crypto.subtle.generateKey(X25519, extractable, ["deriveBits"]);
  return {
    publicKey: pair.publicKey,
    privateKey: pair.privateKey,
    publicKeyBytes: new Uint8Array(await globalThis.crypto.subtle.exportKey("raw", pair.publicKey))
  };
}
async function importX25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "X25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", source(raw), X25519, true, []);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import X25519 public key");
  }
}
async function importX25519PrivateKey(pkcs8, extractable = true) {
  try {
    return await globalThis.crypto.subtle.importKey("pkcs8", source(pkcs8), X25519, extractable, ["deriveBits"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import X25519 private key");
  }
}
async function exportX25519PrivateKey(privateKey) {
  try {
    return new Uint8Array(await globalThis.crypto.subtle.exportKey("pkcs8", privateKey));
  } catch {
    throw new ProtocolError("INVALID_KEY", "X25519 private key is not extractable");
  }
}
async function dh(privateKey, publicKey) {
  try {
    const bits = await globalThis.crypto.subtle.deriveBits({ name: "X25519", public: publicKey }, privateKey, 256);
    const result = new Uint8Array(bits);
    protocolInvariant(result.some((byte) => byte !== 0), "INVALID_KEY", "X25519 produced the prohibited all-zero shared secret");
    return result;
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    throw new ProtocolError("INVALID_KEY", "X25519 key agreement failed");
  }
}
async function extractAndExpand(dhValue, kemContext) {
  const eaePrk = await labeledExtract(KEM_SUITE_ID, new Uint8Array(), "eae_prk", dhValue);
  return labeledExpand(KEM_SUITE_ID, eaePrk, "shared_secret", kemContext, HASH_SIZE);
}
async function keySchedule(sharedSecret, info) {
  const pskIdHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "psk_id_hash", new Uint8Array());
  const infoHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "info_hash", info);
  const keyScheduleContext = concatBytes(Uint8Array.of(0), pskIdHash, infoHash);
  const secret = await labeledExtract(HPKE_SUITE_ID, sharedSecret, "secret", new Uint8Array());
  return {
    key: await labeledExpand(HPKE_SUITE_ID, secret, "key", keyScheduleContext, 32),
    nonce: await labeledExpand(HPKE_SUITE_ID, secret, "base_nonce", keyScheduleContext, 12),
    exporterSecret: await labeledExpand(HPKE_SUITE_ID, secret, "exp", keyScheduleContext, HASH_SIZE)
  };
}
async function aesGcmSeal(keyBytes, nonce, plaintext, aad) {
  const key = await globalThis.crypto.subtle.importKey("raw", source(keyBytes), "AES-GCM", false, ["encrypt"]);
  return new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source(nonce), additionalData: source(aad), tagLength: 128 },
    key,
    source(plaintext)
  ));
}
async function aesGcmOpen(keyBytes, nonce, ciphertext, aad) {
  try {
    const key = await globalThis.crypto.subtle.importKey("raw", source(keyBytes), "AES-GCM", false, ["decrypt"]);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source(nonce), additionalData: source(aad), tagLength: 128 },
      key,
      source(ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "HPKE ciphertext authentication failed");
  }
}
async function senderContext(recipientPublicKeyBytes, info) {
  const recipientPublicKey = await importX25519PublicKey(recipientPublicKeyBytes);
  const ephemeral = await generateX25519KeyPair(false);
  const sharedSecret = await extractAndExpand(
    await dh(ephemeral.privateKey, recipientPublicKey),
    concatBytes(ephemeral.publicKeyBytes, recipientPublicKeyBytes)
  );
  try {
    return { encapsulatedKey: ephemeral.publicKeyBytes, context: await keySchedule(sharedSecret, info) };
  } finally {
    sharedSecret.fill(0);
  }
}
async function recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info) {
  protocolInvariant(recipientPublicKeyBytes.length === 32 && encapsulatedKey.length === 32, "INVALID_KEY", "HPKE X25519 keys must contain 32 bytes");
  const ephemeralPublicKey = await importX25519PublicKey(encapsulatedKey);
  const sharedSecret = await extractAndExpand(
    await dh(recipientPrivateKey, ephemeralPublicKey),
    concatBytes(encapsulatedKey, recipientPublicKeyBytes)
  );
  try {
    return await keySchedule(sharedSecret, info);
  } finally {
    sharedSecret.fill(0);
  }
}
function clearContext(context) {
  context.key.fill(0);
  context.nonce.fill(0);
  context.exporterSecret.fill(0);
}
async function hpkeSealBase(recipientPublicKeyBytes, plaintext, info, aad) {
  const { encapsulatedKey, context } = await senderContext(recipientPublicKeyBytes, info);
  try {
    return { encapsulatedKey, ciphertext: await aesGcmSeal(context.key, context.nonce, plaintext, aad) };
  } finally {
    clearContext(context);
  }
}
async function hpkeOpenBase(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, ciphertext, info, aad) {
  const context = await recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info);
  try {
    return await aesGcmOpen(context.key, context.nonce, ciphertext, aad);
  } finally {
    clearContext(context);
  }
}
async function hpkeSendExportBase(recipientPublicKeyBytes, info, exporterContext, length) {
  const { encapsulatedKey, context } = await senderContext(recipientPublicKeyBytes, info);
  try {
    return { encapsulatedKey, exportedSecret: await labeledExpand(HPKE_SUITE_ID, context.exporterSecret, "sec", exporterContext, length) };
  } finally {
    clearContext(context);
  }
}
async function hpkeReceiveExportBase(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info, exporterContext, length) {
  const context = await recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info);
  try {
    return await labeledExpand(HPKE_SUITE_ID, context.exporterSecret, "sec", exporterContext, length);
  } finally {
    clearContext(context);
  }
}

// packages/crypto/src/epoch.ts
function source2(value) {
  return Uint8Array.from(value).buffer;
}
function payloadAad(epoch, associatedData) {
  return encodeCanonicalCbor(integerMap([[0, 1n], [1, epoch], [2, associatedData]]));
}
async function encryptEpochPayload(contentKey, epoch, plaintext, associatedData) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  const key = await globalThis.crypto.subtle.importKey("raw", source2(contentKey), "AES-GCM", false, ["encrypt"]);
  const nonce = globalThis.crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source2(nonce), additionalData: source2(payloadAad(epoch, associatedData)), tagLength: 128 },
    key,
    source2(plaintext)
  ));
  return { epoch, nonce, ciphertext };
}
async function decryptEpochPayload(contentKey, payload, associatedData) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  protocolInvariant(payload.nonce.length === 12, "SCHEMA_INVALID", "Epoch payload nonce must contain 12 bytes");
  try {
    const key = await globalThis.crypto.subtle.importKey("raw", source2(contentKey), "AES-GCM", false, ["decrypt"]);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source2(payload.nonce), additionalData: source2(payloadAad(payload.epoch, associatedData)), tagLength: 128 },
      key,
      source2(payload.ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "Epoch payload authentication failed");
  }
}

export {
  encryptEpochPayload,
  decryptEpochPayload,
  HPKE_SUITE,
  generateX25519KeyPair,
  importX25519PrivateKey,
  exportX25519PrivateKey,
  hpkeSealBase,
  hpkeOpenBase,
  hpkeSendExportBase,
  hpkeReceiveExportBase
};
