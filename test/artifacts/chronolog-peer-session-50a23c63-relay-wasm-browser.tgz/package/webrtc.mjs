import {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
} from "./chunks/chunk-YLVANYHX.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-MCU2YKH4.mjs";

// packages/peer-session/src/webrtc.ts
async function connectApplicationWebRtc(session, options) {
  const connection = await openWebRtcConnection({ ...options, signal: options.signal === void 0 ? session.signal : AbortSignal.any([session.signal, options.signal]) });
  try {
    const link = await session.connectPeer({
      connection,
      ...options.peerIdentity === void 0 ? {} : { peerIdentity: options.peerIdentity },
      ...options.signal === void 0 ? {} : { signal: options.signal },
      ...options.timeoutMs === void 0 ? {} : { handshakeTimeoutMs: options.timeoutMs }
    });
    await link.synchronize();
    return Object.assign(link, { rtc: connection.session });
  } catch (error) {
    await connection.close();
    throw error;
  }
}
export {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
