export { parseApplicationInput, checkedApplicationInputSchema, validateApplicationDescription, applicationDescriptionDigest, type ApplicationInputSchema, type ApplicationInput, type ApplicationDescription } from './definition.js';
import type { BytesStore } from '../../records/src/index.js';
import { type Signed, type SigningIdentity } from './codec.js';
export interface AdmissionScope {
    readonly id: string;
    readonly authorTimeAfterMs: bigint;
}
export type FinalityPolicy = {
    readonly kind: 'none';
} | {
    readonly kind: 'fixed-validator';
    readonly validators: readonly string[];
    readonly threshold: number;
    readonly scopes: readonly AdmissionScope[];
} | {
    readonly kind: 'signed-frontier';
    readonly signer: string;
    readonly scopes: readonly AdmissionScope[];
};
export interface AppDescriptor {
    readonly applicationId: string;
    readonly rootPrincipal: string;
    readonly authorityPublicKey: string;
    readonly executionManifestDigest: string;
    readonly finalityPolicy: FinalityPolicy;
}
/** `wrapKey` is the member's long-lived X25519 key-wrap public key (hex), or null for a key that never receives data keys. */
export interface MemberGrant {
    readonly publicKey: string;
    readonly wrapKey: string | null;
    readonly reader: boolean;
    readonly writer: boolean;
    readonly administrator: boolean;
    readonly publisher: boolean;
    readonly finalizer: boolean;
}
/**
 * Signed admission policy carried by every membership revision. `hostKey` pins the
 * host's Ed25519 attestation key; `accounts` names the host account principals
 * (`<accountId>` or `email:<address>`) whose attested devices any reader member may
 * admit in `attested` mode with exactly `grant`. `strict` requires an administrator.
 */
export interface AdmissionPolicy {
    readonly mode: 'attested' | 'strict';
    readonly hostKey: string;
    readonly accounts: readonly string[];
    readonly grant: {
        readonly reader: boolean;
        readonly writer: boolean;
    };
}
/** A host statement that an authenticated account proved possession of a device or agent key for one page. It is evidence, never membership. */
export interface HostAttestation {
    readonly subject: 'device' | 'agent';
    readonly pageId: string;
    readonly applicationId: string;
    readonly accountId: string;
    readonly email: string | null;
    readonly publicKey: string;
    readonly wrapKey: string;
    readonly label: string;
    /** The redeemed invite, or null for the owner-account path. */
    readonly inviteId: string | null;
    readonly issuedAt: bigint;
    readonly expiresAt: bigint;
    readonly nonce: string;
}
export type SignedHostAttestation = Signed<HostAttestation>;
export type InviteBinding = {
    readonly kind: 'email';
    readonly email: string;
} | {
    readonly kind: 'open';
} | {
    readonly kind: 'public';
    readonly max: number | null;
};
export type InviteRole = 'reader' | 'writer' | 'admin';
/** An administrator-signed invitation. Only `secretDigest` (SHA-256 hex of the link secret) is in state; the secret travels in the link fragment. */
export interface PageInvite {
    readonly inviteId: string;
    readonly role: InviteRole;
    readonly binding: InviteBinding;
    readonly expiresAt: bigint;
    readonly secretDigest: string;
    readonly revoked: boolean;
}
/**
 * Evidence for one member added in a revision: `attested` (owner-account device,
 * any reader in attested mode), `invited` (redeemed invite, any reader in attested
 * mode) or `approved` (administrator decision on an attested key).
 */
export interface MemberAdmission {
    readonly publicKey: string;
    readonly via: 'attested' | 'invited' | 'approved';
    readonly attestation: SignedHostAttestation;
}
export declare function inviteGrant(role: InviteRole): {
    readonly reader: boolean;
    readonly writer: boolean;
    readonly administrator: boolean;
};
export interface Membership {
    readonly applicationId: string;
    readonly revision: number;
    /** Exclusive signed author-time activation floor; first revision starts at -1. */
    readonly authorTimeAfterMs: bigint;
    readonly previous: string | null;
    readonly members: readonly MemberGrant[];
    readonly epoch: number;
    readonly epochKeyDigest: string;
    readonly admission: AdmissionPolicy;
    /** Admission evidence for members first added by this revision; empty for genesis and administrative changes without attestation. */
    readonly admitted: readonly MemberAdmission[];
    /** Every invite still recorded, including revoked ones; changing it requires an administrator. */
    readonly invites: readonly PageInvite[];
}
export type SignedAppDescriptor = Signed<AppDescriptor>;
export type SignedMembership = Signed<Membership>;
export interface AuthorityBundle {
    readonly descriptor: SignedAppDescriptor;
    readonly memberships: readonly SignedMembership[];
}
export interface AuthorityProvider {
    readonly descriptor: AppDescriptor;
    readonly descriptorId: string;
    readonly currentMembershipId: string;
    readonly currentMembership: Membership;
    bundle(): AuthorityBundle;
    grant(publicKey: string, membershipId?: string): MemberGrant | null;
    hasMembership(id: string): boolean;
    membership(id: string): Membership | null;
    epochKey(epoch: number): Uint8Array | null;
    installEpochKey(epoch: number, key: Uint8Array): Promise<void>;
    merge(bundle: AuthorityBundle): Promise<void>;
    subscribe(listener: () => void): () => void;
}
/** Portable pre-owner validation; no fabricated data-root descriptor or key is needed. */
export declare function validateFinalityPolicy(input: unknown): FinalityPolicy;
export declare function validateDescriptor(value: AppDescriptor): void;
export declare function signAppDescriptor(descriptor: AppDescriptor, signer: SigningIdentity): Promise<SignedAppDescriptor>;
export declare function signMembership(membership: Membership, signer: SigningIdentity): Promise<SignedMembership>;
export declare function validateAdmissionPolicy(input: unknown): AdmissionPolicy;
export declare function validateInvites(input: unknown): readonly PageInvite[];
/** Number of members admitted through one invite in a membership chain. */
export declare function inviteRedemptions(memberships: readonly SignedMembership[], inviteId: string): number;
/** Whether an invite admits this attestation at a signed activation time, excluding the double-spend check. */
export declare function inviteAdmits(invite: PageInvite | undefined, attestation: HostAttestation, activation: bigint): invite is PageInvite;
export declare function inviteCapacity(invite: PageInvite): number;
export declare function signHostAttestation(value: HostAttestation, host: SigningIdentity): Promise<SignedHostAttestation>;
/** Verify a host attestation's signature against the pinned host key and its page/application scope; freshness is the caller's decision. */
export declare function verifyHostAttestation(value: SignedHostAttestation, expected: {
    readonly hostKey: string;
    readonly applicationId: string;
    readonly pageId?: string;
}): Promise<HostAttestation>;
/** True when the policy authorizes the attested account for automatic admission. */
export declare function attestedAccountAuthorized(policy: AdmissionPolicy, attestation: HostAttestation): boolean;
export declare function verifyAuthorityBundle(input: AuthorityBundle, pinned?: SignedAppDescriptor): Promise<void>;
export declare function writerAuthorizedAt(authority: Pick<AuthorityProvider, 'membership' | 'bundle'>, publicKey: string, membershipId: string, authorTimestampMs: bigint, throughRevision?: number): boolean | null;
export declare function finalizerAuthorizedAt(authority: Pick<AuthorityProvider, 'membership' | 'bundle'>, publicKey: string, authorityHead: string, throughMs: bigint): boolean | null;
export declare function epochKeyCommitment(applicationId: string, epoch: number, key: Uint8Array): Promise<string>;
/** Local authority and keys reopen before any optional remote refresh; no remote fetch belongs to this port. */
export declare function createAuthorityProvider(options: {
    readonly store: BytesStore;
    readonly bundle?: AuthorityBundle;
    readonly applicationId?: string;
    readonly epochKeys?: ReadonlyMap<number, Uint8Array>;
}): Promise<AuthorityProvider>;
/** Device-key proof for one page: binds the signing key, its key-wrap key and the host challenge. */
export interface EnrollmentRequest {
    readonly applicationId: string;
    readonly publicKey: string;
    readonly wrapKey: string;
    readonly challenge: string;
}
export type SignedEnrollmentRequest = Signed<EnrollmentRequest>;
export declare function signEnrollmentRequest(request: EnrollmentRequest, identity: SigningIdentity): Promise<SignedEnrollmentRequest>;
export declare function verifyEnrollmentRequest(request: SignedEnrollmentRequest): Promise<void>;
