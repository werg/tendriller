import {
  APPLICATION_PROJECTION_LIMITS
} from "./chunk-FZPYG6B6.mjs";
import {
  HPKE_SUITE,
  PEER_PARTICIPANT_POLICY,
  PUBLICATION_LIMITS,
  assertAuthorityExtension,
  createParticipantRequest,
  createParticipantResponse,
  createParticipantTransport,
  generateX25519KeyPair,
  hpkeReceiveExportBase,
  hpkeSendExportBase,
  signPublicationManifest,
  validateHistoryPoint,
  validateParticipantRequest,
  validateParticipantResponse,
  verifyApplicationSchema,
  verifyAuthorityBundle,
  verifyPublicationManifest
} from "./chunk-4SXHXSRR.mjs";
import {
  PEER_GENERATION_CAPABILITIES,
  applicationDescriptionDigest,
  checkedApplicationInputSchema,
  createPeerIdentity,
  decodePeerValue,
  encodePeerValue,
  parseApplicationInput,
  peerDigest,
  validateApplicationDescription
} from "./chunk-TF4JHBDD.mjs";
import {
  DOMAINS,
  assertCanonicalCbor as assertCanonicalCbor2,
  bytesToHex as bytesToHex2,
  encodeChangeProgram,
  exportEd25519PrivateKey,
  hexToBytes,
  importEd25519PrivateKey,
  importEd25519PublicKey,
  signDomain,
  verifyDomain
} from "./chunk-Q44B5CP6.mjs";
import {
  assertCanonicalCbor,
  bytesToHex,
  encodeCanonicalCbor
} from "./chunk-DACCYORU.mjs";
import {
  awaitOwnedTask
} from "./chunk-KSC4KBWO.mjs";

// packages/peer-session/src/definition.ts
function defineCommand(options) {
  const input = checkedApplicationInputSchema(options.input);
  if (typeof options.description !== "string" || options.description.length > 4096 || typeof options.prepare !== "function") {
    throw new Error("APPLICATION_COMMAND_INVALID");
  }
  return Object.freeze({
    description: options.description,
    input,
    prepare(value) {
      const validated = parseApplicationInput(input, value);
      const program = options.prepare(validated);
      encodeChangeProgram(program);
      return program;
    }
  });
}
function defineQuery(options) {
  const input = checkedApplicationInputSchema(options.input);
  if (typeof options.description !== "string" || options.description.length > 4096 || typeof options.read !== "function") {
    throw new Error("APPLICATION_QUERY_INVALID");
  }
  return Object.freeze({
    description: options.description,
    input,
    read(view, value) {
      return options.read(view, parseApplicationInput(input, value));
    }
  });
}
function defineApplication(definition) {
  for (const value of [definition.id, definition.version]) {
    if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(value)) throw new Error("APPLICATION_DEFINITION_ID_INVALID");
  }
  if (definition.schema !== void 0) encodeChangeProgram(definition.schema);
  for (const entries of [definition.commands, definition.queries]) {
    const names = Object.keys(entries);
    if (names.length > 128) throw new Error("APPLICATION_DEFINITION_TOO_LARGE");
    for (const name of names) {
      if (!/^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(name) || ["__proto__", "constructor", "prototype"].includes(name)) {
        throw new Error("APPLICATION_DEFINITION_NAME_INVALID");
      }
      checkedApplicationInputSchema(entries[name].input);
    }
  }
  return Object.freeze({ ...definition, commands: Object.freeze({ ...definition.commands }), queries: Object.freeze({ ...definition.queries }) });
}
function describeApplication(definition) {
  const describe = (entries) => Object.keys(entries).sort().map((name) => ({ name, description: entries[name].description, input: entries[name].input }));
  return validateApplicationDescription({ id: definition.id, version: definition.version, schema: definition.schema === void 0 ? null : bytesToHex2(encodeChangeProgram(definition.schema)), commands: describe(definition.commands), queries: describe(definition.queries) });
}
async function applicationDefinitionDigest(definition) {
  return applicationDescriptionDigest(describeApplication(definition));
}

// packages/peer-session/src/metadata.ts
var owners = /* @__PURE__ */ new WeakMap();
function updateDeviceMetadata(store, key, update) {
  let keys = owners.get(store);
  if (keys === void 0) {
    keys = /* @__PURE__ */ new Map();
    owners.set(store, keys);
  }
  const previous = keys.get(key) ?? Promise.resolve();
  const task = previous.then(async () => {
    const shared = store;
    for (let attempt = 0; attempt < 32; attempt++) {
      const current = await store.get(key), next = await update(current?.slice() ?? null);
      if (current !== null && same(current, next)) return next;
      if (shared.compareAndSwap === void 0) {
        await store.put(key, next);
        return next;
      }
      if (await shared.compareAndSwap(key, current, next)) return next;
    }
    throw new Error("APPLICATION_METADATA_CONTENTION");
  });
  const settled = task.then(() => void 0, () => void 0);
  keys.set(key, settled);
  void settled.then(() => {
    if (keys.get(key) === settled) keys.delete(key);
  });
  return task;
}
function same(a, b) {
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

// packages/peer-session/src/control-participant.ts
var ApplicationPublicationError = class extends Error {
  constructor(publication, phase, cause, receipt = null) {
    const code = receipt === null ? "APPLICATION_PUBLICATION_OUTCOME_UNKNOWN" : "APPLICATION_PUBLICATION_COMMITTED";
    super(`${code}${cause instanceof Error ? `: ${cause.message}` : ""}`, { cause });
    this.phase = phase;
    this.name = "ApplicationPublicationError";
    this.code = code;
    this.outcome = receipt === null ? "unknown" : "committed";
    this.operationId = publication.payload.operationId;
    this.publicationId = publication.id;
    this.receipt = receipt === null ? null : structuredClone(receipt);
  }
  phase;
  code;
  outcome;
  operationId;
  publicationId;
  receipt;
};
var ApplicationControlParticipant = class {
  role = "control";
  #participant;
  #store;
  #transport;
  #lifetime = new AbortController();
  #signal;
  #timeoutMs;
  #publicationKey;
  #publicationAttempts;
  #publicationReceipts;
  #tail = Promise.resolve();
  constructor(participant, store, signal, options) {
    const timeoutMs = options.timeoutMs ?? 3e4;
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 12e4) throw new Error("APPLICATION_CONTROL_TIMEOUT_INVALID");
    this.#participant = participant;
    this.#store = store;
    this.#timeoutMs = timeoutMs;
    this.#signal = AbortSignal.any([signal, this.#lifetime.signal]);
    this.#transport = createParticipantTransport({ applicationId: participant.descriptor.applicationId, exchange: options.exchange });
    this.#publicationKey = `peer-session/publication/${participant.descriptor.applicationId}`;
    this.#publicationAttempts = `peer-session/publication-attempt/${participant.descriptor.applicationId}`;
    this.#publicationReceipts = `peer-session/publication-receipt/${participant.descriptor.applicationId}`;
  }
  get signal() {
    return this.#signal;
  }
  get policy() {
    return this.#transport.policy;
  }
  /** Learn and durably fence newer authority even while its selected data is still missing. */
  async application(options = {}) {
    const signal = options.signal === void 0 ? this.#signal : AbortSignal.any([this.#signal, options.signal]);
    const bundle = await this.#request("control", "read", {}, signal);
    signal.throwIfAborted();
    await this.#participant.adoptAuthority(bundle);
    signal.throwIfAborted();
    return this.#participant.authority;
  }
  async selectGeneration(input, options = {}) {
    const signal = options.signal === void 0 ? this.#signal : AbortSignal.any([this.#signal, options.signal]);
    const request = structuredClone(input);
    if (request.payload.applicationId !== this.#participant.descriptor.applicationId) throw new Error("PEER_SCOPE_MISMATCH");
    const selected = await this.#request("control", "select", { request }, signal);
    const bundle = this.#participant.authority;
    if (await peerDigest(selected.payload.transition) !== await peerDigest(request)) throw new Error("APPLICATION_TRANSITION_REPLY_MISMATCH");
    const index = selected.payload.number, known = bundle.generations[index];
    if (!Number.isSafeInteger(index) || index < 0 || index > bundle.generations.length || known !== void 0 && known.id !== selected.id) {
      throw new Error("APPLICATION_TRANSITION_REPLY_MISMATCH");
    }
    await verifyAuthorityBundle({
      descriptor: bundle.descriptor,
      controls: bundle.controls.slice(0, selected.payload.controlRevision + 1),
      generations: [...bundle.generations.slice(0, index), selected]
    }, bundle.descriptor);
    signal.throwIfAborted();
    return selected;
  }
  async definition() {
    const result = await this.#request("publication", "definition", {});
    const descriptor = this.#participant.authority.descriptor;
    if (await peerDigest(result.descriptor) !== await peerDigest(descriptor)) throw new Error("PEER_DESCRIPTOR_CHANGED");
    const definition = validateApplicationDescription(result.definition);
    if (await applicationDescriptionDigest(definition) !== descriptor.payload.definitionDigest || (result.schema === null ? null : await peerDigest(result.schema)) !== descriptor.payload.schemaDigest || definition.schema === null !== (result.schema === null) || result.schema !== null && definition.schema !== result.schema.payload.program) {
      throw new Error("APPLICATION_DEFINITION_MISMATCH");
    }
    if (result.schema !== null) await verifyApplicationSchema(result.schema, descriptor.payload);
    this.#signal.throwIfAborted();
    return { descriptor, definition, schema: result.schema };
  }
  /** Verify the selected code chain and remember its head outside lossy application history. */
  publication() {
    return this.#serial(() => this.#readPublication());
  }
  /** Inspect this device's saved intent and receipt without contacting the host or opening application data. */
  publicationOperation(operationId) {
    return this.#serial(async () => {
      const key = await peerDigest(operationId), author = this.#participant.device.publicKey;
      const attempt = await this.#store.get(`${this.#publicationAttempts}/${key}`);
      const retained = await this.#store.get(`${this.#publicationReceipts}/${author}/${key}`);
      if (attempt === null && retained === null) {
        this.#signal.throwIfAborted();
        return null;
      }
      const receipt = retained === null ? null : readPublicationReceipt(decodePeerValue(retained));
      const publication = attempt === null ? receipt.publication : decodePeerValue(attempt);
      await verifyPublicationManifest(publication, await verifyAuthorityBundle(this.#participant.authority));
      if (publication.payload.author !== author || publication.payload.operationId !== operationId) {
        throw new Error("PEER_PUBLICATION_OPERATION_REUSED");
      }
      if (receipt !== null) await verifyPublicationReceipt(receipt, publication);
      this.#signal.throwIfAborted();
      return structuredClone({ publication, receipt });
    });
  }
  /** Save the exact signed code update before returning; retrying its identity never signs new intent. */
  preparePublication(input) {
    const captured = structuredClone(input);
    return this.#serial(async () => {
      const journalKey = `${this.#publicationAttempts}/${await peerDigest(captured.operationId)}`;
      const saved = await updateDeviceMetadata(this.#store, journalKey, async (currentAttempt) => {
        this.#signal.throwIfAborted();
        if (currentAttempt !== null) {
          const publication2 = decodePeerValue(currentAttempt);
          await verifyPublicationManifest(publication2, await verifyAuthorityBundle(this.#participant.authority));
          if (publication2.payload.author !== this.#participant.device.publicKey || publication2.payload.operationId !== captured.operationId || await peerDigest({ entry: publication2.payload.entry, files: publication2.payload.files }) !== await peerDigest({ entry: captured.entry, files: captured.files })) {
            throw new Error("PEER_PUBLICATION_OPERATION_REUSED");
          }
          return currentAttempt;
        }
        const current = await this.#readPublication(), authority = await verifyAuthorityBundle(this.#participant.authority);
        if (authority.grant(this.#participant.device.publicKey)?.publisher !== true) throw new Error("PEER_PUBLICATION_FORBIDDEN");
        const descriptor = authority.descriptor;
        const publication = await signPublicationManifest({
          applicationId: descriptor.applicationId,
          historyId: descriptor.historyId,
          profile: descriptor.profile,
          controlRevision: authority.control.payload.revision,
          author: this.#participant.device.publicKey,
          operationId: captured.operationId,
          revision: (current?.publication.payload.revision ?? -1) + 1,
          previous: current?.publication.id ?? null,
          definitionDigest: descriptor.definitionDigest,
          executionManifestDigest: descriptor.executionManifestDigest,
          entry: captured.entry,
          files: captured.files
        }, this.#participant.device);
        this.#signal.throwIfAborted();
        return encodePeerValue(publication);
      });
      this.#signal.throwIfAborted();
      return decodePeerValue(saved);
    });
  }
  publish(input, assets) {
    const publication = structuredClone(input), capturedAssets = structuredClone(assets);
    return this.#serial(async () => {
      await verifyPublicationManifest(publication, await verifyAuthorityBundle(this.#participant.authority));
      const key = `${this.#publicationReceipts}/${publication.payload.author}/${await peerDigest(publication.payload.operationId)}`;
      const stored = await this.#store.get(key);
      let receipt = stored === null ? null : await verifyPublicationReceipt(decodePeerValue(stored), publication);
      let phase = "submission";
      try {
        const reply = await this.#request("publication", "publish", { publication, assets: capturedAssets });
        phase = "receipt";
        const acknowledged = await verifyPublicationReceipt(reply, publication);
        if (receipt !== null && receipt.version !== acknowledged.version) throw new Error("APPLICATION_PUBLICATION_REPLY_MISMATCH");
        receipt = acknowledged;
        phase = "retention";
        await updateDeviceMetadata(this.#store, key, async (current) => {
          if (current !== null && await peerDigest(decodePeerValue(current)) !== await peerDigest(acknowledged)) {
            throw new Error("APPLICATION_PUBLICATION_RECEIPT_CONFLICT");
          }
          return encodePeerValue(acknowledged);
        });
        phase = "selection";
        await this.#readPublication(acknowledged);
        return receipt;
      } catch (cause) {
        throw new ApplicationPublicationError(publication, phase, cause, receipt);
      }
    });
  }
  async #readPublication(acknowledged) {
    await this.application();
    const authority = await verifyAuthorityBundle(this.#participant.authority);
    const reply = await this.#request("publication", "read", {});
    const current = reply === null ? null : readPublicationReceipt(reply);
    if (current === null) {
      if (await this.#store.get(this.#publicationKey) !== null) throw new Error("APPLICATION_PUBLICATION_REGRESSION");
      if (acknowledged !== void 0) throw new Error("APPLICATION_PUBLICATION_NOT_SELECTED");
      this.#signal.throwIfAborted();
      return null;
    }
    await updateDeviceMetadata(this.#store, this.#publicationKey, async (stored) => {
      this.#signal.throwIfAborted();
      const previous = stored === null ? null : readPublicationReceipt(decodePeerValue(stored));
      if (previous !== null) await verifyPublicationManifest(previous.publication, authority);
      const checkVersion = async (receipt) => {
        const publication = receipt.publication;
        const retained = await this.#store.get(`${this.#publicationReceipts}/${publication.payload.author}/${await peerDigest(publication.payload.operationId)}`);
        const saved = retained === null ? null : await verifyPublicationReceipt(decodePeerValue(retained), publication);
        for (const expected of [previous, acknowledged, saved]) {
          if (expected != null && receipt.publication.id === expected.publication.id && receipt.version !== expected.version) {
            throw new Error("APPLICATION_PUBLICATION_REPLY_MISMATCH");
          }
        }
      };
      let cursor = current.publication;
      await verifyPublicationManifest(cursor, authority);
      await checkVersion(current);
      if (previous !== null && (cursor.payload.revision < previous.publication.payload.revision || cursor.payload.revision === previous.publication.payload.revision && cursor.id !== previous.publication.id)) {
        throw new Error("APPLICATION_PUBLICATION_REGRESSION");
      }
      let previousSeen = cursor.id === previous?.publication.id;
      let acknowledgedSeen = acknowledged === void 0 || cursor.id === acknowledged.publication.id;
      let remaining = PUBLICATION_LIMITS.revisions;
      while ((previous === null || !previousSeen || !acknowledgedSeen) && cursor.payload.previous !== null) {
        if (--remaining < 0) throw new Error("APPLICATION_PUBLICATION_HISTORY_LIMIT");
        const response = await this.#request("publication", "read", { id: cursor.payload.previous });
        const prior = response === null ? null : readPublicationReceipt(response);
        if (prior === null || prior.publication.id !== cursor.payload.previous || prior.publication.payload.revision !== cursor.payload.revision - 1) {
          throw new Error("APPLICATION_PUBLICATION_CHAIN_INVALID");
        }
        await verifyPublicationManifest(prior.publication, authority);
        await checkVersion(prior);
        cursor = prior.publication;
        previousSeen ||= cursor.id === previous?.publication.id;
        acknowledgedSeen ||= cursor.id === acknowledged?.publication.id;
      }
      if (previous !== null && !previousSeen) throw new Error("APPLICATION_PUBLICATION_REGRESSION");
      if (!acknowledgedSeen) throw new Error("APPLICATION_PUBLICATION_NOT_SELECTED");
      this.#signal.throwIfAborted();
      return encodePeerValue(current);
    });
    this.#signal.throwIfAborted();
    return structuredClone(current);
  }
  close() {
    this.#lifetime.abort(new Error("APPLICATION_CONTROL_CLOSED"));
    return this.#tail.then(() => void 0);
  }
  #serial(call) {
    const result = this.#tail.then(() => {
      this.#signal.throwIfAborted();
      return call();
    });
    this.#tail = result.catch(() => void 0);
    return result;
  }
  async #request(facet, action, payload, lifetime = this.#signal) {
    lifetime.throwIfAborted();
    const controller = new AbortController(), timer = setTimeout(() => controller.abort(new Error("APPLICATION_CONTROL_TIMEOUT")), this.#timeoutMs);
    const signal = AbortSignal.any([lifetime, controller.signal]);
    try {
      return await awaitOwnedTask(signal, () => this.#transport.request(facet, action, payload, { signal }));
    } finally {
      clearTimeout(timer);
    }
  }
};
async function verifyPublicationReceipt(input, publication) {
  const receipt = readPublicationReceipt(input);
  if (await peerDigest(receipt.publication) !== await peerDigest(publication)) throw new Error("APPLICATION_PUBLICATION_REPLY_MISMATCH");
  return { publication: structuredClone(publication), version: receipt.version };
}
function readPublicationReceipt(input) {
  if (input === null || typeof input !== "object" || !("publication" in input) || !("version" in input) || typeof input.version !== "number" || !Number.isSafeInteger(input.version) || input.version < 1) {
    throw new Error("APPLICATION_PUBLICATION_REPLY_MISMATCH");
  }
  return { publication: input.publication, version: input.version };
}

// packages/signals/src/payload.ts
function assertSignalTopic(topic) {
  if (typeof topic !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._/-]*$/u.test(topic) || topic.length > 128) throw new Error("SIGNAL_TOPIC_INVALID");
}
function canonicalSignalPayload(payload) {
  let nodes = 0;
  const visit = (value, depth) => {
    if (depth > 32 || ++nodes > 4096) throw new Error("SIGNAL_PAYLOAD_TOO_COMPLEX");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw new Error("SIGNAL_PAYLOAD_INVALID");
      return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
      if (Reflect.ownKeys(value).length !== value.length + 1) throw new Error("SIGNAL_PAYLOAD_INVALID");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, i);
        if (descriptor === void 0 || !("value" in descriptor) || !descriptor.enumerable) throw new Error("SIGNAL_PAYLOAD_INVALID");
        entries.push(visit(descriptor.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    if (typeof value !== "object" || value === null || Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null || Reflect.ownKeys(value).length !== Object.keys(value).length) throw new Error("SIGNAL_PAYLOAD_INVALID");
    return `{${Object.keys(value).sort().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!("value" in descriptor)) throw new Error("SIGNAL_PAYLOAD_INVALID");
      return `${JSON.stringify(key)}:${visit(descriptor.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const result = visit(payload, 0);
  if (new TextEncoder().encode(result).length > 16384) throw new Error("SIGNAL_FRAME_TOO_LARGE");
  return result;
}

// packages/signals/src/index.ts
var SIGNAL_DOMAIN = "chronolog/signal/v1";
var SIGNAL_STREAM_DOMAIN = "chronolog/signal/v2";
var MAX_SIGNAL_BYTES = 16384;
var SignalError = class extends Error {
  constructor(code, message2 = code) {
    super(message2);
    this.code = code;
    this.name = "SignalError";
  }
  code;
};
var SignalChannel = class {
  #options;
  #authorId;
  #session = crypto.getRandomValues(new Uint8Array(32));
  #sessions = /* @__PURE__ */ new Map();
  #subscriptions = /* @__PURE__ */ new Set();
  #routes = /* @__PURE__ */ new Set();
  /** Detached callbacks retain their quota until the actual operation settles. */
  #retiring = /* @__PURE__ */ new Set();
  #lifetime = new AbortController();
  #ttl;
  #skew;
  #maxSessions;
  #maxSequences;
  #maxRemembered;
  #maxSends;
  #maxReceives;
  #maxRoutes;
  #maxSubscriptions;
  #maxQueuedSignals;
  #maxQueuedBytes;
  #sendTimeout;
  #sequence = 0;
  #sendTail = Promise.resolve();
  #pendingSends = 0;
  #pendingReceives = 0;
  #remembered = 0;
  #observedTime = 0;
  constructor(options) {
    if (typeof options.scope !== "string" || options.scope.length === 0 || new TextEncoder().encode(options.scope).length > 256 || !(options.identity.publicKeyBytes instanceof Uint8Array) || options.identity.publicKeyBytes.length !== 32 || typeof options.authorize !== "function") throw new SignalError("SIGNAL_CONFIGURATION_INVALID");
    const credential = typeof options.credential === "function" ? options.credential : credentialBytes(options.credential);
    this.#options = {
      ...options,
      identity: { ...options.identity, publicKeyBytes: options.identity.publicKeyBytes.slice() },
      ...credential === void 0 ? {} : { credential }
    };
    this.#authorId = bytesToHex(options.identity.publicKeyBytes);
    this.#ttl = bound(options.maxTtlMs ?? 3e4, 1, 6e4);
    this.#skew = bound(options.maxClockSkewMs ?? 2e3, 0, 1e4);
    this.#maxSessions = bound(options.maxSessions ?? 1024, 1, 65536);
    this.#maxSequences = bound(options.maxSequencesPerSession ?? 1024, 1, 65536);
    this.#maxRemembered = bound(options.maxRememberedSignals ?? 8192, 1, 1048576);
    this.#maxSends = bound(options.maxPendingSends ?? 32, 1, 1024);
    this.#maxReceives = bound(options.maxPendingReceives ?? 32, 1, 1024);
    this.#maxRoutes = bound(options.maxRoutes ?? 64, 1, 1024);
    this.#maxSubscriptions = bound(options.maxSubscriptions ?? 16, 1, 1024);
    this.#maxQueuedSignals = bound(options.maxQueuedSignals ?? 64, 1, 4096);
    this.#maxQueuedBytes = bound(options.maxQueuedBytes ?? 262144, 1, 16777216);
    this.#sendTimeout = bound(options.sendTimeoutMs ?? 1e4, 1, 12e4);
    if (options.trySend !== void 0) this.attachRoute({ trySend: options.trySend });
  }
  get delivery() {
    return this.#options.relay === true ? "application" : "neighbors";
  }
  attachRoute(transport) {
    this.#assertOpen();
    if (typeof transport.trySend !== "function") throw new SignalError("SIGNAL_TRANSPORT_INVALID");
    if (this.#routes.size + this.#retiring.size >= this.#maxRoutes) throw new SignalError("SIGNAL_ROUTE_QUOTA_EXCEEDED");
    const route = {
      trySend: transport.trySend.bind(transport),
      lifetime: new AbortController(),
      busy: false,
      retired: false,
      ...transport.close === void 0 ? {} : { close: transport.close.bind(transport) }
    };
    this.#routes.add(route);
    return { receive: (frame) => this.#enqueueReceive(frame, route), close: () => this.#detach(route) };
  }
  send(topic, payload, options = {}) {
    try {
      if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
      this.#assertOpen();
      options.signal?.throwIfAborted();
      if (this.#routes.size === 0 && this.#options.localEcho !== true) throw new SignalError("SIGNAL_ROUTE_UNAVAILABLE");
      const routes = [...this.#routes];
      if (this.#pendingSends >= this.#maxSends) throw new SignalError("SIGNAL_BACKPRESSURE");
      assertSignalTopic(topic);
      const encodedPayload = canonicalSignalPayload(payload);
      const stream = options.stream === void 0 ? void 0 : checkedStream(options.stream);
      const ttlMs = bound(options.ttlMs ?? Math.min(5e3, this.#ttl), 1, this.#ttl, "SIGNAL_TTL_INVALID");
      const issuedAtMs = this.#now(), expiresAtMs = issuedAtMs + ttlMs;
      if (!Number.isSafeInteger(expiresAtMs)) throw new SignalError("SIGNAL_CLOCK_INVALID");
      const expiry = new AbortController();
      const timer = setTimeout(() => expiry.abort(new SignalError("SIGNAL_SEND_TIMEOUT")), Math.min(ttlMs, this.#sendTimeout));
      const signal = AbortSignal.any([this.#lifetime.signal, expiry.signal, ...options.signal === void 0 ? [] : [options.signal]]);
      this.#pendingSends += 1;
      let started = false;
      const task = this.#sendTail.then(() => {
        signal.throwIfAborted();
        started = true;
        const operation = (async () => {
          const configured = this.#options.credential;
          const credential = credentialBytes(typeof configured === "function" ? await configured(topic, { signal }) : configured);
          const authorization = { scope: this.#options.scope, authorId: this.#options.identity.publicKeyBytes.slice(), topic, credential: credential ?? null, ...stream === void 0 ? {} : { stream } };
          await this.#authorize(authorization, signal);
          if (this.#sequence >= Number.MAX_SAFE_INTEGER) throw new SignalError("SIGNAL_SEQUENCE_EXHAUSTED");
          const sequence = ++this.#sequence;
          const fields = [
            stream === void 0 ? 1n : 2n,
            stream === void 0 ? SIGNAL_DOMAIN : SIGNAL_STREAM_DOMAIN,
            this.#options.scope,
            this.#options.identity.publicKeyBytes,
            credential ?? null,
            this.#session,
            BigInt(sequence),
            BigInt(issuedAtMs),
            BigInt(expiresAtMs),
            topic,
            encodedPayload,
            ...stream === void 0 ? [] : [JSON.stringify(stream)]
          ];
          const signature = new Uint8Array(await crypto.subtle.sign(
            "Ed25519",
            this.#options.identity.privateKey,
            encodeCanonicalCbor(fields).slice().buffer
          ));
          const frame = encodeCanonicalCbor([...fields, signature]);
          if (frame.length > MAX_SIGNAL_BYTES) throw new SignalError("SIGNAL_FRAME_TOO_LARGE");
          const value = {
            scope: this.#options.scope,
            authorId: this.#authorId,
            sessionId: bytesToHex(this.#session),
            sequence,
            topic,
            payload: JSON.parse(encodedPayload),
            issuedAtMs,
            expiresAtMs,
            ...stream === void 0 ? {} : { stream }
          };
          await this.#authorize(authorization, signal);
          this.#assertFresh(value);
          if (!this.#remember(value)) throw new SignalError("SIGNAL_BACKPRESSURE");
          const local = this.#options.localEcho === true;
          if (local) {
            this.#deliver(value, frame.length);
            if (routes.length > 0) void this.#dispatch({ value, authorization, frame }, routes, signal, false).catch(() => void 0);
          }
          if (!local && !await this.#dispatch({ value, authorization, frame }, routes, signal, true)) {
            this.#forget(value);
            throw new SignalError("SIGNAL_BACKPRESSURE");
          }
          return structuredClone(value);
        })().finally(() => {
          clearTimeout(timer);
          this.#pendingSends -= 1;
        });
        return interrupted(operation, signal);
      }).finally(() => {
        if (!started) {
          clearTimeout(timer);
          this.#pendingSends -= 1;
        }
      });
      this.#sendTail = task.catch(() => void 0);
      return interrupted(task, signal);
    } catch (error) {
      return Promise.reject(error);
    }
  }
  /** Standalone receive validates and delivers without inferring a relay source. */
  receive(frame) {
    return this.#enqueueReceive(frame);
  }
  #enqueueReceive(input, route) {
    try {
      this.#assertOpen();
      if (!(input instanceof Uint8Array) || input.byteLength > MAX_SIGNAL_BYTES) throw new SignalError("SIGNAL_FRAME_TOO_LARGE");
      if (route?.lifetime.signal.aborted === true) throw new SignalError("SIGNAL_ROUTE_CLOSED");
      if (this.#pendingReceives >= this.#maxReceives) return Promise.resolve(null);
      const frame = input.slice();
      const routes = [...this.#routes].filter((attached) => attached !== route);
      this.#pendingReceives += 1;
      const expiry = new AbortController();
      const timer = setTimeout(() => expiry.abort(new SignalError("SIGNAL_RECEIVE_TIMEOUT")), this.#ttl);
      const signal = AbortSignal.any([this.#lifetime.signal, expiry.signal, ...route === void 0 ? [] : [route.lifetime.signal]]);
      const operation = (async () => {
        signal.throwIfAborted();
        const verified = await this.#verify(frame, signal);
        if (verified === null || !this.#remember(verified.value)) return null;
        this.#deliver(verified.value, frame.length);
        if (this.#options.relay === true) await this.#dispatch(verified, routes, signal, false);
        return structuredClone(verified.value);
      })().finally(() => {
        clearTimeout(timer);
        this.#pendingReceives -= 1;
      });
      return interrupted(operation, signal);
    } catch (error) {
      return Promise.reject(error);
    }
  }
  async #verify(bytes, signal) {
    const frame = assertCanonicalCbor(bytes, {
      maxBytes: MAX_SIGNAL_BYTES,
      maxDepth: 2,
      maxArrayItems: 13,
      maxMapItems: 0,
      maxTextBytes: MAX_SIGNAL_BYTES,
      maxBlobBytes: 1024
    });
    if (!Array.isArray(frame) || !(frame.length === 12 && frame[0] === 1n && frame[1] === SIGNAL_DOMAIN || frame.length === 13 && frame[0] === 2n && frame[1] === SIGNAL_STREAM_DOMAIN) || frame[2] !== this.#options.scope || !(frame[3] instanceof Uint8Array) || frame[3].length !== 32 || frame[4] !== null && (!(frame[4] instanceof Uint8Array) || frame[4].length > 1024) || !(frame[5] instanceof Uint8Array) || frame[5].length !== 32 || typeof frame[6] !== "bigint" || typeof frame[7] !== "bigint" || typeof frame[8] !== "bigint" || typeof frame[9] !== "string" || typeof frame[10] !== "string" || !(frame[frame.length - 1] instanceof Uint8Array) || frame[frame.length - 1].length !== 64) throw new SignalError("SIGNAL_FRAME_INVALID");
    assertSignalTopic(frame[9]);
    const stream = frame.length === 13 ? decodeStream(frame[11]) : void 0;
    const payload = JSON.parse(frame[10]);
    if (canonicalSignalPayload(payload) !== frame[10]) throw new SignalError("SIGNAL_PAYLOAD_INVALID");
    const value = {
      scope: this.#options.scope,
      authorId: bytesToHex(frame[3]),
      sessionId: bytesToHex(frame[5]),
      sequence: Number(frame[6]),
      issuedAtMs: Number(frame[7]),
      expiresAtMs: Number(frame[8]),
      topic: frame[9],
      payload,
      ...stream === void 0 ? {} : { stream }
    };
    this.#assertClock(value);
    const key = await crypto.subtle.importKey("raw", frame[3].slice().buffer, "Ed25519", false, ["verify"]);
    if (!await crypto.subtle.verify("Ed25519", key, frame[frame.length - 1].slice().buffer, encodeCanonicalCbor(frame.slice(0, -1)).slice().buffer)) {
      throw new SignalError("SIGNAL_SIGNATURE_INVALID");
    }
    const credential = frame[4];
    const authorization = { scope: value.scope, authorId: frame[3].slice(), topic: value.topic, credential: credential?.slice() ?? null, ...stream === void 0 ? {} : { stream } };
    if (!await this.#allowed(authorization, signal)) return null;
    this.#assertClock(value);
    if (value.expiresAtMs <= this.#now()) return null;
    return { value, authorization, frame: bytes };
  }
  async #allowed(input, signal) {
    signal.throwIfAborted();
    const allowed = await this.#options.authorize(structuredClone(input), { signal });
    signal.throwIfAborted();
    return allowed;
  }
  async #authorize(input, signal) {
    if (!await this.#allowed(input, signal)) throw new SignalError("SIGNAL_UNAUTHORIZED");
  }
  async #dispatch(verified, eligible, signal, required) {
    const attached = eligible.filter((route) => !route.lifetime.signal.aborted);
    if (required && attached.length === 0) throw new SignalError("SIGNAL_ROUTE_UNAVAILABLE");
    const routes = attached.filter((route) => !route.busy);
    if (routes.length === 0) return false;
    const attempts = routes.map((route) => {
      route.busy = true;
      let handedOff = false, settled = false;
      const deadline2 = new AbortController();
      const timer = setTimeout(() => {
        const reason = new SignalError("SIGNAL_SEND_TIMEOUT");
        deadline2.abort(reason);
        if (handedOff && !settled) this.#detach(route, true, reason);
      }, Math.max(1, Math.min(this.#sendTimeout, verified.value.expiresAtMs - this.#now())));
      const lifetime = AbortSignal.any([signal, route.lifetime.signal, deadline2.signal]);
      const operation = (async () => {
        await this.#authorize(verified.authorization, lifetime);
        this.#assertFresh(verified.value);
        handedOff = true;
        const result = await route.trySend(verified.frame.slice(), { signal: lifetime });
        if (typeof result !== "boolean") {
          throw new SignalError("SIGNAL_TRANSPORT_RESULT_INVALID");
        }
        return result;
      })().catch((error) => {
        if (handedOff && (!lifetime.aborted || error !== lifetime.reason)) this.#detach(route, true, error);
        throw error;
      }).finally(() => {
        settled = true;
        route.busy = false;
        this.#retiring.delete(route);
        clearTimeout(timer);
      });
      return interrupted(operation, lifetime);
    });
    if (required) {
      const refused = new Error("Signal dispatch refused");
      try {
        return await Promise.any(attempts.map(async (attempt) => {
          if (!await attempt) throw refused;
          return true;
        }));
      } catch (error) {
        if (error instanceof AggregateError) {
          const failures = error.errors.filter((value) => value !== refused);
          if (failures.length === 0) return false;
          if (failures.length === 1) throw failures[0];
        }
        throw new SignalError("SIGNAL_SEND_FAILED");
      }
    }
    return (await Promise.allSettled(attempts)).some((result) => result.status === "fulfilled" && result.value);
  }
  #remember(value) {
    const now = this.#now();
    for (const [id, progress2] of this.#sessions) {
      for (const [sequence, expiresAtMs] of progress2.seen) if (expiresAtMs <= now) {
        progress2.seen.delete(sequence);
        this.#remembered -= 1;
      }
      if (progress2.seen.size === 0) this.#sessions.delete(id);
    }
    const key = `${value.authorId}/${value.sessionId}`, previous = this.#sessions.get(key);
    if (previous?.seen.has(value.sequence) === true) return false;
    if (previous === void 0 && this.#sessions.size >= this.#maxSessions) return false;
    if ((previous?.seen.size ?? 0) >= this.#maxSequences || this.#remembered >= this.#maxRemembered) return false;
    const progress = previous ?? { seen: /* @__PURE__ */ new Map() };
    progress.seen.set(value.sequence, value.expiresAtMs);
    this.#remembered += 1;
    this.#sessions.set(key, progress);
    return true;
  }
  #forget(value) {
    const key = `${value.authorId}/${value.sessionId}`, session = this.#sessions.get(key);
    if (session?.seen.delete(value.sequence) === true) this.#remembered -= 1;
    if (session?.seen.size === 0) this.#sessions.delete(key);
  }
  #deliver(value, bytes) {
    for (const subscriber of this.#subscriptions) {
      if (subscriber.topics !== null && !subscriber.topics.has(value.topic)) continue;
      if (subscriber.streams !== null && !subscriber.streams.some((selector) => matchesStream(value, selector))) continue;
      const now = this.#now();
      for (let index = subscriber.pending.length - 1; index >= 0; index -= 1) {
        if (subscriber.pending[index].value.expiresAtMs <= now) subscriber.bytes -= subscriber.pending.splice(index, 1)[0].bytes;
      }
      for (const [id, latest] of subscriber.latest) if (latest.retainThroughMs <= now) subscriber.latest.delete(id);
      const key = JSON.stringify([value.authorId, value.sessionId, value.topic, value.stream?.endpointId ?? null, value.stream?.endpointIncarnation ?? null, value.stream?.streamId ?? null, value.stream?.target ?? null]);
      if (subscriber.mode === "latest") {
        const previous = subscriber.latest.get(key);
        if (previous !== void 0 && previous.sequence >= value.sequence) continue;
        if (previous === void 0 && subscriber.latest.size >= this.#maxQueuedSignals) {
          this.#overflow(subscriber);
          continue;
        }
        subscriber.latest.set(key, { sequence: value.sequence, retainThroughMs: now + this.#ttl + this.#skew });
        const index = subscriber.pending.findIndex((item) => item.key === key);
        if (index !== -1) subscriber.bytes -= subscriber.pending.splice(index, 1)[0].bytes;
      }
      if (subscriber.pending.length >= this.#maxQueuedSignals || subscriber.bytes + bytes > this.#maxQueuedBytes) {
        this.#overflow(subscriber);
      } else {
        subscriber.pending.push({ value: structuredClone(value), bytes, key });
        subscriber.bytes += bytes;
      }
      subscriber.wake?.();
    }
  }
  #overflow(subscriber) {
    subscriber.error = new SignalError("SIGNAL_SUBSCRIPTION_OVERFLOW");
    subscriber.pending.length = 0;
    subscriber.bytes = 0;
    subscriber.latest.clear();
    subscriber.clean();
    this.#subscriptions.delete(subscriber);
    subscriber.wake?.();
  }
  subscribe(options = {}) {
    if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
    const self = this;
    return { [Symbol.asyncIterator]() {
      const controller = new AbortController();
      const signal = options.signal === void 0 ? controller.signal : AbortSignal.any([controller.signal, options.signal]);
      const iterator = self.#subscribe({ ...options, signal });
      return {
        next: () => iterator.next(),
        async return() {
          controller.abort();
          return iterator.return();
        },
        async throw(error) {
          controller.abort();
          return iterator.throw(error);
        }
      };
    } };
  }
  async *#subscribe(options) {
    this.#assertOpen();
    if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
    const mode = options.mode ?? "all";
    if (mode !== "all" && mode !== "latest") throw new SignalError("SIGNAL_SUBSCRIPTION_MODE_INVALID");
    if (options.topics !== void 0) {
      if (!Array.isArray(options.topics) || options.topics.length > 64) throw new SignalError("SIGNAL_TOPIC_FILTER_TOO_LARGE");
      for (const topic of options.topics) {
        if (typeof topic !== "string") throw new SignalError("SIGNAL_TOPIC_FILTER_INVALID");
        assertSignalTopic(topic);
      }
    }
    const streams = options.streams === void 0 ? null : checkedSelectors(options.streams);
    if (this.#subscriptions.size >= this.#maxSubscriptions) throw new SignalError("SIGNAL_SUBSCRIPTION_QUOTA_EXCEEDED");
    const subscriber = {
      topics: options.topics === void 0 ? null : new Set(options.topics),
      streams,
      mode,
      pending: [],
      latest: /* @__PURE__ */ new Map(),
      bytes: 0,
      error: null,
      wake: null,
      clean: () => void 0
    };
    this.#subscriptions.add(subscriber);
    const signal = options.signal;
    const abort = () => {
      subscriber.pending.length = 0;
      subscriber.bytes = 0;
      subscriber.latest.clear();
      subscriber.clean();
      this.#subscriptions.delete(subscriber);
      subscriber.wake?.();
    };
    subscriber.clean = () => signal?.removeEventListener("abort", abort);
    signal?.addEventListener("abort", abort, { once: true });
    try {
      while (!this.#lifetime.signal.aborted && signal?.aborted !== true) {
        if (subscriber.error !== null) throw subscriber.error;
        const item = subscriber.pending.shift();
        if (item !== void 0) {
          subscriber.bytes -= item.bytes;
          if (item.value.expiresAtMs > this.#now()) yield structuredClone(item.value);
        } else {
          await new Promise((resolve) => {
            subscriber.wake = resolve;
            if (this.#lifetime.signal.aborted || signal?.aborted === true || subscriber.pending.length > 0 || subscriber.error !== null) resolve();
          });
          subscriber.wake = null;
        }
      }
    } finally {
      subscriber.clean();
      this.#subscriptions.delete(subscriber);
    }
  }
  close() {
    if (this.#lifetime.signal.aborted) return;
    this.#lifetime.abort(new SignalError("SIGNAL_CHANNEL_CLOSED"));
    for (const route of this.#routes) this.#detach(route);
    for (const subscriber of this.#subscriptions) {
      subscriber.pending.length = 0;
      subscriber.latest.clear();
      subscriber.clean();
      subscriber.wake?.();
    }
    this.#subscriptions.clear();
    this.#sessions.clear();
    this.#remembered = 0;
  }
  #detach(route, retire = false, reason = new SignalError("SIGNAL_ROUTE_CLOSED")) {
    if (route.busy) this.#retiring.add(route);
    this.#routes.delete(route);
    route.lifetime.abort(reason);
    if (retire && !route.retired) {
      route.retired = true;
      try {
        void Promise.resolve(route.close?.(reason)).catch(() => void 0);
      } catch {
      }
    }
  }
  #assertOpen() {
    this.#lifetime.signal.throwIfAborted();
  }
  #assertFresh(value) {
    this.#assertClock(value);
    if (value.expiresAtMs <= this.#now()) throw new SignalError("SIGNAL_EXPIRED");
  }
  #assertClock(value) {
    const now = this.#now();
    if (!Number.isSafeInteger(value.sequence) || value.sequence < 1 || !Number.isSafeInteger(value.issuedAtMs) || value.issuedAtMs < 0 || !Number.isSafeInteger(value.expiresAtMs) || value.expiresAtMs <= value.issuedAtMs || value.expiresAtMs - value.issuedAtMs > this.#ttl || value.issuedAtMs > now + this.#skew) throw new SignalError("SIGNAL_CLOCK_INVALID");
  }
  #now() {
    const now = bound(this.#options.now?.() ?? Date.now(), 0, Number.MAX_SAFE_INTEGER, "SIGNAL_CLOCK_INVALID");
    this.#observedTime = Math.max(this.#observedTime, now);
    return this.#observedTime;
  }
};
function credentialBytes(value) {
  if (value === void 0) return void 0;
  if (!(value instanceof Uint8Array) || value.length > 1024) throw new SignalError("SIGNAL_CREDENTIAL_INVALID");
  return value.slice();
}
function bound(value, minimum, maximum, code = "SIGNAL_BOUNDS_INVALID") {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) throw new SignalError(code);
  return value;
}
function interrupted(operation, signal) {
  return new Promise((resolve, reject) => {
    const abort = () => {
      reject(signal.reason);
      signal.removeEventListener("abort", abort);
    };
    signal.addEventListener("abort", abort, { once: true });
    void operation.then(resolve, reject).finally(() => signal.removeEventListener("abort", abort));
    if (signal.aborted) abort();
  });
}
function checkedStream(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !["streamId", "endpointId", "endpointIncarnation", "target"].includes(key)) || !boundedLabel(value.streamId) || value.endpointId === void 0 !== (value.endpointIncarnation === void 0) || value.endpointId !== void 0 && !boundedLabel(value.endpointId) || value.endpointIncarnation !== void 0 && !boundedLabel(value.endpointIncarnation) || value.target !== void 0 && !boundedLabel(value.target)) throw new SignalError("SIGNAL_STREAM_INVALID");
  return {
    streamId: value.streamId,
    ...value.endpointId === void 0 ? {} : { endpointId: value.endpointId, endpointIncarnation: value.endpointIncarnation },
    ...value.target === void 0 ? {} : { target: value.target }
  };
}
function decodeStream(value) {
  if (typeof value !== "string" || value.length > 2048) throw new SignalError("SIGNAL_STREAM_INVALID");
  let parsed;
  try {
    parsed = JSON.parse(value);
  } catch {
    throw new SignalError("SIGNAL_STREAM_INVALID");
  }
  const stream = checkedStream(parsed);
  if (JSON.stringify(stream) !== value) throw new SignalError("SIGNAL_STREAM_INVALID");
  return stream;
}
function boundedLabel(value) {
  return typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._:/@-]{0,127}$/u.test(value);
}
function checkedSelectors(value) {
  const keys = ["authorId", "sessionId", "streamId", "endpointId", "endpointIncarnation", "target"];
  if (!Array.isArray(value) || value.length > 64 || value.some((selector) => selector === null || typeof selector !== "object" || Array.isArray(selector) || Object.entries(selector).some(([key, item]) => !keys.includes(key) || !boundedLabel(item)))) {
    throw new SignalError("SIGNAL_STREAM_FILTER_INVALID");
  }
  return structuredClone(value);
}
function matchesStream(value, selector) {
  return (selector.authorId === void 0 || selector.authorId === value.authorId) && (selector.sessionId === void 0 || selector.sessionId === value.sessionId) && (selector.streamId === void 0 || selector.streamId === value.stream?.streamId) && (selector.endpointId === void 0 || selector.endpointId === value.stream?.endpointId) && (selector.endpointIncarnation === void 0 || selector.endpointIncarnation === value.stream?.endpointIncarnation) && (selector.target === void 0 || selector.target === value.stream?.target);
}

// packages/peer-session/src/network-wire.ts
var APPLICATION_NETWORK_LIMITS = Object.freeze({
  messageBytes: 32 * 1024 * 1024,
  fragmentBytes: 48 * 1024,
  queuedMessages: 8,
  queuedBytes: 32 * 1024 * 1024,
  pendingRequests: 4,
  incomingRequests: 4,
  rangeCommands: 32,
  rangeBytes: 4 * 1024 * 1024,
  peers: 8
});
function networkError(code) {
  return new Error(code);
}
function requireNetwork(value, code) {
  if (!value) throw networkError(code);
}
function record(value, keys) {
  requireNetwork(value !== null && typeof value === "object" && !Array.isArray(value), "APPLICATION_NETWORK_MESSAGE_INVALID");
  const result = value;
  requireNetwork(Object.keys(result).length === keys.length && keys.every((key) => Object.hasOwn(result, key)), "APPLICATION_NETWORK_MESSAGE_INVALID");
  return result;
}
function interruptible(promise, signal) {
  signal.throwIfAborted();
  return new Promise((resolve, reject) => {
    const abort = () => reject(signal.reason);
    signal.addEventListener("abort", abort, { once: true });
    void promise.then(resolve, reject).finally(() => signal.removeEventListener("abort", abort));
  });
}
function timeout(milliseconds, message2) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(networkError(message2)), milliseconds);
  return { signal: controller.signal, cancel: () => clearTimeout(timer) };
}
var ApplicationMessageWire = class {
  #connection;
  #signal;
  #timeoutMs;
  #authorize;
  #outgoing = 0;
  #incoming = 0;
  #pending = 0;
  #pendingBytes = 0;
  #sentBytes = 0;
  #receivedBytes = 0;
  #tail = Promise.resolve();
  constructor(connection, signal, timeoutMs, authorize = () => {
  }) {
    this.#connection = connection;
    this.#signal = signal;
    this.#timeoutMs = timeoutMs;
    this.#authorize = authorize;
  }
  get stats() {
    return { sentBytes: this.#sentBytes, receivedBytes: this.#receivedBytes };
  }
  send(value, authorize) {
    this.#signal.throwIfAborted();
    requireNetwork(this.#pending < APPLICATION_NETWORK_LIMITS.queuedMessages, "APPLICATION_NETWORK_BACKPRESSURE");
    const bytes = encodePeerValue(value);
    requireNetwork(bytes.length > 0 && bytes.length <= APPLICATION_NETWORK_LIMITS.messageBytes && this.#pendingBytes + bytes.length <= APPLICATION_NETWORK_LIMITS.queuedBytes, "APPLICATION_NETWORK_BACKPRESSURE");
    this.#pending++;
    this.#pendingBytes += bytes.length;
    const queued = timeout(this.#timeoutMs, "APPLICATION_NETWORK_WRITE_TIMEOUT");
    const signal = AbortSignal.any([this.#signal, queued.signal]);
    const task = this.#tail.then(async () => {
      signal.throwIfAborted();
      authorize?.();
      requireNetwork(this.#outgoing < Number.MAX_SAFE_INTEGER, "APPLICATION_NETWORK_SEQUENCE_EXHAUSTED");
      const id = ++this.#outgoing;
      for (let offset = 0; offset < bytes.length; offset += APPLICATION_NETWORK_LIMITS.fragmentBytes) {
        signal.throwIfAborted();
        this.#authorize();
        const fragment = bytes.subarray(offset, offset + APPLICATION_NETWORK_LIMITS.fragmentBytes);
        const frame = encodeCanonicalCbor([1n, BigInt(id), BigInt(offset), BigInt(bytes.length), fragment]);
        await interruptible(this.#connection.send(frame, { signal }), signal);
        this.#sentBytes += frame.length;
      }
    }).finally(() => {
      queued.cancel();
      this.#pending--;
      this.#pendingBytes -= bytes.length;
    });
    this.#tail = task.catch(() => void 0);
    return task;
  }
  async *messages() {
    let body = null, offset = 0;
    let assembly;
    const iterator = this.#connection.frames(this.#signal)[Symbol.asyncIterator]();
    try {
      while (!this.#signal.aborted) {
        const signal = assembly === void 0 ? this.#signal : AbortSignal.any([this.#signal, assembly.signal]);
        const next = await interruptible(iterator.next(), signal);
        if (next.done) {
          requireNetwork(body === null, "APPLICATION_NETWORK_TRUNCATED");
          return;
        }
        const bytes = next.value;
        requireNetwork(
          bytes instanceof Uint8Array && bytes.length > 0 && bytes.length <= APPLICATION_NETWORK_LIMITS.fragmentBytes + 128,
          "APPLICATION_NETWORK_FRAME_LIMIT"
        );
        this.#receivedBytes += bytes.length;
        const frame = assertCanonicalCbor2(bytes);
        requireNetwork(Array.isArray(frame) && frame.length === 5 && frame[0] === 1n && typeof frame[1] === "bigint" && typeof frame[2] === "bigint" && typeof frame[3] === "bigint" && frame[4] instanceof Uint8Array, "APPLICATION_NETWORK_FRAME_INVALID");
        const [id, position2, total] = [Number(frame[1]), Number(frame[2]), Number(frame[3])], chunk = frame[4];
        requireNetwork(
          Number.isSafeInteger(id) && id === this.#incoming + 1 && Number.isSafeInteger(position2) && position2 === offset && Number.isSafeInteger(total) && total > 0 && total <= APPLICATION_NETWORK_LIMITS.messageBytes && chunk.length > 0 && chunk.length <= APPLICATION_NETWORK_LIMITS.fragmentBytes && offset + chunk.length <= total,
          "APPLICATION_NETWORK_FRAME_INVALID"
        );
        if (body === null) {
          body = new Uint8Array(total);
          assembly = timeout(this.#timeoutMs, "APPLICATION_NETWORK_READ_TIMEOUT");
        }
        requireNetwork(body.length === total, "APPLICATION_NETWORK_FRAME_INVALID");
        body.set(chunk, offset);
        offset += chunk.length;
        if (offset === total) {
          const complete = body;
          body = null;
          offset = 0;
          this.#incoming++;
          assembly?.cancel();
          assembly = void 0;
          yield decodePeerValue(complete);
        }
      }
    } finally {
      assembly?.cancel();
      void iterator.return?.().catch(() => void 0);
    }
  }
};
function memoryLane(maxBytes, maxFrames) {
  const queue = [], waiters = /* @__PURE__ */ new Set();
  let bytes = 0, closed = false, reading = false;
  const notify = () => {
    for (const wake of [...waiters]) wake();
  };
  return {
    push(frame) {
      requireNetwork(!closed, "APPLICATION_NETWORK_CLOSED");
      if (queue.length >= maxFrames || bytes + frame.length > maxBytes) return false;
      queue.push(frame.slice());
      bytes += frame.length;
      notify();
      return true;
    },
    async wait(signal) {
      signal.throwIfAborted();
      await new Promise((resolve, reject) => {
        const done = () => {
          waiters.delete(wake);
          signal.removeEventListener("abort", abort);
        };
        const wake = () => {
          done();
          resolve();
        }, abort = () => {
          done();
          reject(signal.reason);
        };
        waiters.add(wake);
        signal.addEventListener("abort", abort, { once: true });
      });
    },
    async *frames(signal) {
      requireNetwork(!reading, "APPLICATION_NETWORK_READER_EXISTS");
      reading = true;
      while (!closed && !signal.aborted) {
        const frame = queue.shift();
        if (frame !== void 0) {
          bytes -= frame.length;
          notify();
          yield frame;
        } else await this.wait(signal);
      }
    },
    close() {
      closed = true;
      queue.length = 0;
      bytes = 0;
      notify();
    }
  };
}
function createFramedPeerConnectionPair() {
  const controller = new AbortController(), reliable = [memoryLane(4 * 1024 * 1024, 64), memoryLane(4 * 1024 * 1024, 64)];
  const live = [memoryLane(128 * 1024, 8), memoryLane(128 * 1024, 8)];
  const close = async () => {
    if (controller.signal.aborted) return;
    controller.abort(networkError("APPLICATION_NETWORK_CLOSED"));
    for (const lane of [...reliable, ...live]) lane.close();
  };
  const side = (index) => {
    const opposite = index === 0 ? 1 : 0;
    return {
      signal: controller.signal,
      close,
      async send(frame, options = {}) {
        const signal = options.signal === void 0 ? controller.signal : AbortSignal.any([controller.signal, options.signal]);
        while (true) {
          signal.throwIfAborted();
          if (reliable[opposite].push(frame)) return;
          await reliable[opposite].wait(signal);
        }
      },
      frames: (signal) => reliable[index].frames(signal === void 0 ? controller.signal : AbortSignal.any([controller.signal, signal])),
      live: {
        signal: controller.signal,
        close,
        async trySend(frame, options = {}) {
          controller.signal.throwIfAborted();
          options.signal?.throwIfAborted();
          return live[opposite].push(frame);
        },
        frames: (signal) => live[index].frames(signal === void 0 ? controller.signal : AbortSignal.any([controller.signal, signal]))
      }
    };
  };
  return [side(0), side(1)];
}

// packages/peer-session/src/secure-channel.ts
var APPLICATION_CHANNEL_SUITE = `${HPKE_SUITE}/peer-record-v1`;
var APPLICATION_CHANNEL_LIMITS = Object.freeze({ overheadBytes: 22, records: 2 ** 24, plaintextBytes: 2 ** 32 });
var DOMAIN = "chronolog/peer-channel/v1";
var EXPORT_CONTEXT = encodePeerValue({ domain: DOMAIN, layout: ["reliable-key:32", "reliable-nonce:12", "live-key:32", "live-nonce:12"] });
var HEADER = 6;
var TAG = 16;
var limit = (live) => live ? MAX_SIGNAL_BYTES : APPLICATION_NETWORK_LIMITS.fragmentBytes + 128;
var source = (bytes) => Uint8Array.from(bytes).buffer;
var context = (sender, receiver) => encodePeerValue({ domain: DOMAIN, suite: APPLICATION_CHANNEL_SUITE, sender, receiver });
var RecordCipher = class {
  #key;
  #baseNonce;
  #live;
  #sequence = 0;
  #bytes = 0;
  constructor(key, nonce, live) {
    this.#key = key;
    this.#baseNonce = nonce;
    this.#live = live;
  }
  #nonce(sequence) {
    const nonce = this.#baseNonce.slice(), view = new DataView(nonce.buffer);
    view.setUint32(8, view.getUint32(8) ^ sequence);
    return nonce;
  }
  #budget(length) {
    requireNetwork(this.#key !== void 0, "APPLICATION_CHANNEL_CLOSED");
    requireNetwork(
      this.#sequence < APPLICATION_CHANNEL_LIMITS.records && this.#bytes + length <= APPLICATION_CHANNEL_LIMITS.plaintextBytes,
      "APPLICATION_CHANNEL_KEY_EXHAUSTED"
    );
  }
  async seal(input) {
    requireNetwork(input instanceof Uint8Array && input.length > 0 && input.length <= limit(this.#live), "APPLICATION_CHANNEL_FRAME_LIMIT");
    this.#budget(input.length);
    const sequence = ++this.#sequence, header = Uint8Array.of(1, this.#live ? 2 : 1, 0, 0, 0, 0);
    new DataView(header.buffer).setUint32(2, sequence);
    this.#bytes += input.length;
    const encrypted = new Uint8Array(await crypto.subtle.encrypt({
      name: "AES-GCM",
      iv: source(this.#nonce(sequence)),
      additionalData: source(header),
      tagLength: 128
    }, this.#key, source(input)));
    const result = new Uint8Array(header.length + encrypted.length);
    result.set(header);
    result.set(encrypted, HEADER);
    return result;
  }
  async open(input) {
    requireNetwork(
      input instanceof Uint8Array && input.length > HEADER + TAG && input.length <= limit(this.#live) + HEADER + TAG,
      "APPLICATION_CHANNEL_FRAME_LIMIT"
    );
    requireNetwork(input[0] === 1 && input[1] === (this.#live ? 2 : 1), "APPLICATION_CHANNEL_FRAME_INVALID");
    const sequence = new DataView(input.buffer, input.byteOffset, HEADER).getUint32(2);
    requireNetwork(sequence > 0 && sequence <= APPLICATION_CHANNEL_LIMITS.records, "APPLICATION_CHANNEL_SEQUENCE_INVALID");
    if (this.#live && sequence <= this.#sequence) return null;
    requireNetwork(this.#live || sequence === this.#sequence + 1, "APPLICATION_CHANNEL_SEQUENCE_INVALID");
    this.#budget(input.length - HEADER - TAG);
    let plaintext;
    try {
      plaintext = new Uint8Array(await crypto.subtle.decrypt({
        name: "AES-GCM",
        iv: source(this.#nonce(sequence)),
        additionalData: source(input.subarray(0, HEADER)),
        tagLength: 128
      }, this.#key, source(input.subarray(HEADER))));
    } catch {
      throw new Error("APPLICATION_CHANNEL_AUTHENTICATION_FAILED");
    }
    this.#sequence = sequence;
    this.#bytes += plaintext.length;
    return plaintext;
  }
  clear() {
    this.#key = void 0;
    this.#baseNonce.fill(0);
  }
};
async function direction(secret, usage) {
  requireNetwork(secret.length === 88, "APPLICATION_CHANNEL_KEY_INVALID");
  try {
    const reliable = await crypto.subtle.importKey("raw", source(secret.subarray(0, 32)), "AES-GCM", false, [usage]);
    const live = await crypto.subtle.importKey("raw", source(secret.subarray(44, 76)), "AES-GCM", false, [usage]);
    return { reliable: new RecordCipher(reliable, secret.slice(32, 44), false), live: new RecordCipher(live, secret.slice(76, 88), true) };
  } finally {
    secret.fill(0);
  }
}
function clear(value) {
  value?.reliable.clear();
  value?.live.clear();
}
var ApplicationSecureChannel = class {
  connection;
  #signal;
  #receiver;
  #outbound;
  #inbound;
  #hello = false;
  #preparing = false;
  #sending = false;
  #closed = false;
  #reliableBusy = false;
  #liveBusy = false;
  #onAbort = () => this.clear();
  constructor(raw, signal) {
    this.#signal = AbortSignal.any([signal, raw.signal]);
    const lifetime = this.#signal, channel = this;
    const live = raw.live === void 0 ? void 0 : {
      signal: AbortSignal.any([lifetime, raw.live.signal]),
      async trySend(frame, options = {}) {
        const signal2 = options.signal === void 0 ? lifetime : AbortSignal.any([lifetime, options.signal]);
        channel.#open();
        signal2.throwIfAborted();
        requireNetwork(channel.#sending && channel.#outbound !== void 0, "APPLICATION_PEER_AUTHENTICATION_REQUIRED");
        if (channel.#liveBusy) return false;
        channel.#liveBusy = true;
        try {
          const encrypted = await channel.#outbound.live.seal(frame);
          channel.#open();
          signal2.throwIfAborted();
          return await raw.live.trySend(encrypted, { signal: signal2 });
        } finally {
          channel.#liveBusy = false;
        }
      },
      async *frames(signal2) {
        const lifetime2 = signal2 === void 0 ? channel.#signal : AbortSignal.any([channel.#signal, signal2]);
        for await (const frame of raw.live.frames(lifetime2)) {
          channel.#open();
          lifetime2.throwIfAborted();
          requireNetwork(channel.#inbound !== void 0, "APPLICATION_PEER_AUTHENTICATION_REQUIRED");
          const plaintext = await channel.#inbound.live.open(frame);
          channel.#open();
          lifetime2.throwIfAborted();
          if (plaintext !== null) yield plaintext;
        }
      },
      close: () => raw.live.close()
    };
    this.connection = {
      signal: lifetime,
      ...live === void 0 ? {} : { live },
      async send(frame, options = {}) {
        const signal2 = options.signal === void 0 ? lifetime : AbortSignal.any([lifetime, options.signal]);
        channel.#open();
        signal2.throwIfAborted();
        requireNetwork(!channel.#reliableBusy, "APPLICATION_NETWORK_BACKPRESSURE");
        channel.#reliableBusy = true;
        try {
          const bytes = channel.#sending ? await channel.#outbound.reliable.seal(frame) : frame;
          channel.#open();
          signal2.throwIfAborted();
          await raw.send(bytes, { signal: signal2 });
        } catch (error) {
          if (channel.#sending) {
            channel.clear();
            void raw.close().catch(() => void 0);
          }
          throw error;
        } finally {
          channel.#reliableBusy = false;
        }
      },
      async *frames(signal2) {
        const lifetime2 = signal2 === void 0 ? channel.#signal : AbortSignal.any([channel.#signal, signal2]);
        for await (const frame of raw.frames(lifetime2)) {
          channel.#open();
          lifetime2.throwIfAborted();
          const plaintext = channel.#inbound === void 0 ? frame : await channel.#inbound.reliable.open(frame);
          channel.#open();
          lifetime2.throwIfAborted();
          yield plaintext;
        }
      },
      close: async () => {
        channel.clear();
        await raw.close();
      }
    };
    lifetime.addEventListener("abort", this.#onAbort, { once: true });
    if (lifetime.aborted) this.clear();
  }
  #open() {
    this.#signal.throwIfAborted();
    requireNetwork(!this.#closed, "APPLICATION_CHANNEL_CLOSED");
  }
  async hello() {
    this.#open();
    requireNetwork(!this.#hello, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    this.#hello = true;
    const receiver = await generateX25519KeyPair(false);
    this.#open();
    this.#receiver = receiver;
    return { suite: APPLICATION_CHANNEL_SUITE, receiverKey: bytesToHex2(receiver.publicKeyBytes) };
  }
  async prepare(peerReceiverKey, sender, receiver) {
    this.#open();
    requireNetwork(!this.#preparing, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    this.#preparing = true;
    const exported = await hpkeSendExportBase(hexToBytes(peerReceiverKey), context(sender, receiver), EXPORT_CONTEXT, 88);
    try {
      this.#open();
      const outbound = await direction(exported.exportedSecret, "encrypt");
      if (this.#closed || this.#signal.aborted) {
        clear(outbound);
        this.#open();
      }
      this.#outbound = outbound;
      return bytesToHex2(exported.encapsulatedKey);
    } finally {
      exported.exportedSecret.fill(0);
    }
  }
  /** Called only when every public proof fragment has been dispatched. */
  enableSending() {
    this.#open();
    requireNetwork(this.#outbound !== void 0 && !this.#sending, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    this.#sending = true;
  }
  async accept(encapsulatedKey, sender, receiver) {
    this.#open();
    requireNetwork(this.#receiver !== void 0 && this.#inbound === void 0, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    const key = this.#receiver;
    this.#receiver = void 0;
    const secret = await hpkeReceiveExportBase(key.privateKey, key.publicKeyBytes, hexToBytes(encapsulatedKey), context(sender, receiver), EXPORT_CONTEXT, 88);
    try {
      this.#open();
      const inbound = await direction(secret, "decrypt");
      if (this.#closed || this.#signal.aborted) {
        clear(inbound);
        this.#open();
      }
      this.#inbound = inbound;
    } finally {
      secret.fill(0);
    }
  }
  clear() {
    if (this.#closed) return;
    this.#closed = true;
    this.#receiver = void 0;
    this.#signal.removeEventListener("abort", this.#onAbort);
    clear(this.#outbound);
    clear(this.#inbound);
    this.#outbound = void 0;
    this.#inbound = void 0;
  }
};

// packages/peer-session/src/network.ts
var methods = ["state", "openData", "range", "submit", "coverage", "keyShare", "contentManifest", "contentChunk", "contentRetained", "contentObserveRetention"];
var interests = {
  state: { facet: "control", action: "state" },
  keyShare: { facet: "control", action: "keyShare" },
  openData: { facet: "database", action: "open" },
  range: { facet: "database", action: "range" },
  submit: { facet: "database", action: "submit" },
  coverage: { facet: "database", action: "coverage" },
  contentManifest: { facet: "content", action: "manifest" },
  contentChunk: { facet: "content", action: "chunk" },
  contentRetained: { facet: "content", action: "retained" },
  contentObserveRetention: { facet: "content", action: "observeRetention" }
};
var owners2 = /* @__PURE__ */ new WeakMap();
var hexadecimal = (value, length = 64) => typeof value === "string" && value.length === length && /^[0-9a-f]+$/u.test(value);
var same2 = (a, b) => bytesToHex2(encodePeerValue(a)) === bytesToHex2(encodePeerValue(b));
var PeerDataUnavailableError = class extends Error {
  constructor() {
    super("APPLICATION_DATA_UNAVAILABLE");
  }
};
function isPeerDataUnavailable(error) {
  return error instanceof PeerDataUnavailableError;
}
function retryablePull(error) {
  return error instanceof Error && [
    "APPLICATION_NETWORK_STATE_CHANGED",
    "PEER_AUTHORITY_REGRESSION",
    "PEER_CURSOR_RECOVERY_REQUIRED",
    "PEER_VIEW_RECOVERY_REQUIRED",
    "APPLICATION_KEY_REQUEST_EXPIRED"
  ].includes(error.message);
}
async function useData(data, run) {
  try {
    requireNetwork(!data.replica.closed, "APPLICATION_DATA_UNAVAILABLE");
    const value = await run();
    requireNetwork(!data.replica.closed, "APPLICATION_DATA_UNAVAILABLE");
    return value;
  } catch (error) {
    if (data.replica.closed) throw new PeerDataUnavailableError();
    throw error;
  }
}
function availablePoint(replica) {
  if (replica === void 0) return null;
  try {
    return replica.retainedPoint;
  } catch (error) {
    if (error instanceof Error && error.message === "PEER_RECOVERY_PREFIX_INCOMPLETE") return null;
    throw error;
  }
}
function grant(participant, key, role) {
  return participant.grant(key)?.[role] === true;
}
function deadline(value, fallback) {
  const selected = value ?? fallback;
  requireNetwork(Number.isSafeInteger(selected) && selected > 0 && selected <= 12e4, "APPLICATION_NETWORK_TIMEOUT_INVALID");
  return selected;
}
function position(authority, point) {
  validateHistoryPoint(point);
  const index = authority.selectedSegments().findIndex((value) => value.generation.id === point.generation);
  requireNetwork(index >= 0 && authority.contains(point), "APPLICATION_NETWORK_CURSOR_INVALID");
  return [index, point.sequence];
}
function atOrAfter(authority, left, right) {
  const a = position(authority, left), b = position(authority, right);
  return a[0] > b[0] || a[0] === b[0] && a[1] >= b[1];
}
function newest(left, right) {
  const a = left.bundle, b = right.bundle;
  requireNetwork(same2(a.descriptor, b.descriptor), "APPLICATION_NETWORK_SCOPE_MISMATCH");
  const [old, current] = a.generations.length <= b.generations.length ? [a, b] : [b, a];
  requireNetwork(current.controls.length >= old.controls.length && old.controls.every((value, index) => same2(value, current.controls[index])) && old.generations.every((value, index) => same2(value, current.generations[index])), "PEER_CONTROL_EQUIVOCATION");
  return current === b ? right : left;
}
function transferTarget(remote, latest, point) {
  if (point === null) return null;
  const remoteSegments = remote.selectedSegments(), available = position(remote, point)[0];
  let target = null;
  for (const selected of latest.selectedSegments()) {
    const index = remoteSegments.findIndex((value) => value.generation.id === selected.generation.id);
    if (index < 0 || index > available) continue;
    const retained = index === available ? point : remoteSegments[index].cutoff;
    const candidate = selected.cutoff !== null && selected.cutoff.sequence <= retained.sequence ? selected.cutoff : retained;
    if (candidate.sequence > 0) target = candidate;
  }
  return target;
}
var NetworkPeer = class {
  #port;
  #input;
  #owner;
  #attempt;
  #controller = new AbortController();
  #wire;
  #channel;
  #proofSent;
  #pending = /* @__PURE__ */ new Map();
  #requestMs;
  #handshakeMs;
  #drainMs;
  #retiring = false;
  #drainTimer;
  #ready;
  completion;
  #readyResolve;
  #readyReject;
  #completeResolve;
  #completeReject;
  #local;
  #remote;
  #authenticated = false;
  #confirmed = false;
  #nextRequest = 0;
  #lastRemoteRequest = 0;
  #sentLiveBytes = 0;
  #receivedLiveBytes = 0;
  #sentRequests = 0;
  #receivedRequests = 0;
  #incoming = 0;
  #route;
  #detach;
  #detachContent;
  #detachKeys;
  #data;
  #disposeLive;
  #unsubscribe;
  #disposeListeners = [];
  #closeTask;
  #sync;
  #nextSync;
  #syncAgain = false;
  #hintPending = false;
  #lastHint = "";
  #stateRetries = 0;
  #remoteData;
  #remoteDataFailure;
  #remoteOpening;
  constructor(port, input, owner, attempt) {
    this.#port = port;
    this.#input = input;
    this.#owner = owner;
    this.#attempt = attempt;
    this.#requestMs = deadline(input.requestTimeoutMs, 12e4);
    this.#handshakeMs = deadline(input.handshakeTimeoutMs, 1e4);
    this.#drainMs = deadline(input.drainTimeoutMs, 5e3);
    this.#channel = new ApplicationSecureChannel(input.connection, this.signal);
    this.#wire = new ApplicationMessageWire(this.#channel.connection, this.signal, deadline(input.transferTimeoutMs, 3e4), () => {
      if (this.#authenticated) this.#reader();
    });
    this.#ready = new Promise((resolve, reject) => {
      this.#readyResolve = resolve;
      this.#readyReject = reject;
    });
    this.completion = new Promise((resolve, reject) => {
      this.#completeResolve = resolve;
      this.#completeReject = reject;
    });
    void this.#ready.catch(() => void 0);
    void this.completion.catch(() => void 0);
    for (const signal of [port.signal, input.signal, input.connection.signal]) {
      if (signal === void 0) continue;
      const abort = () => this.#fail(signal.reason ?? networkError("APPLICATION_NETWORK_CLOSED"));
      signal.addEventListener("abort", abort, { once: true });
      this.#disposeListeners.push(() => signal.removeEventListener("abort", abort));
      if (signal.aborted) abort();
    }
  }
  get peerId() {
    return this.#remote?.author ?? "";
  }
  get data() {
    return this.#remoteData === true ? "active" : this.#remoteDataFailure === void 0 ? "idle" : "unavailable";
  }
  get signal() {
    return this.#controller.signal;
  }
  get stats() {
    return { ...this.#wire.stats, sentLiveBytes: this.#sentLiveBytes, receivedLiveBytes: this.#receivedLiveBytes, sentRequests: this.#sentRequests, receivedRequests: this.#receivedRequests };
  }
  #reader() {
    this.signal.throwIfAborted();
    requireNetwork(this.#remote !== void 0 && grant(this.#port.participant, this.peerId, "reader") && grant(this.#port.participant, this.#port.participant.device.publicKey, "reader"), "APPLICATION_PEER_NOT_AUTHORIZED");
  }
  async open() {
    const participant = this.#port.participant;
    requireNetwork(this.#input.peerIdentity === void 0 || hexadecimal(this.#input.peerIdentity), "APPLICATION_PEER_IDENTITY_INVALID");
    requireNetwork(grant(participant, participant.device.publicKey, "reader"), "APPLICATION_PEER_NOT_AUTHORIZED");
    this.#local = {
      application: participant.descriptor.applicationId,
      profile: "peer-generation-v1",
      descriptor: await peerDigest(participant.authority.descriptor),
      author: participant.device.publicKey,
      nonce: bytesToHex2(crypto.getRandomValues(new Uint8Array(32))),
      authority: participant.authority,
      channel: await this.#channel.hello()
    };
    const handshake = timeout(this.#handshakeMs, "APPLICATION_PEER_HANDSHAKE_TIMEOUT");
    void this.#read().catch((error) => this.#fail(error));
    try {
      await interruptible(this.#wire.send({ kind: "hello", value: this.#local }), AbortSignal.any([this.signal, handshake.signal]));
      await interruptible(this.#ready, AbortSignal.any([this.signal, handshake.signal]));
      this.#reader();
      requireNetwork((this.#owner.accepted.get(this.peerId) ?? 0) <= this.#attempt, "APPLICATION_PEER_SUPERSEDED");
      requireNetwork(this.#owner.peers.size < APPLICATION_NETWORK_LIMITS.peers || this.#owner.peers.has(this.peerId), "APPLICATION_PEER_LIMIT");
      const previous = this.#owner.peers.get(this.peerId);
      this.#owner.accepted.set(this.peerId, this.#attempt);
      this.#owner.peers.set(this.peerId, this);
      if (previous !== void 0) void previous.retire().catch(() => void 0);
      this.#detach = this.#port.attach(this.peerId, async (attempt) => {
        this.#reader();
        requireNetwork(attempt.payload.header.author === participant.device.publicKey && grant(participant, participant.device.publicKey, "writer"), "PEER_AUTHOR_FORBIDDEN");
        await this.#request("submit", attempt);
        this.#reader();
        await this.synchronize();
      }, this);
      this.#unsubscribe = participant.subscribe(() => this.#changed());
      this.#changed();
    } catch (error) {
      this.#fail(error);
      throw error;
    } finally {
      handshake.cancel();
    }
  }
  #prepareLive() {
    if (this.#channel.connection.live !== void 0) {
      const lane = this.#channel.connection.live;
      this.#route = this.#port.signals.attachRoute({ close: (reason) => this.#dispose(reason), trySend: async (frame, { signal }) => {
        signal.throwIfAborted();
        this.#reader();
        if (this.#retiring || this.#owner.peers.get(this.peerId) !== this) return false;
        const accepted = await lane.trySend(frame, { signal: AbortSignal.any([signal, this.signal]) });
        if (accepted) this.#sentLiveBytes += frame.length;
        this.#reader();
        return accepted;
      } });
      const route = this.#route;
      let closed = false;
      const dispose = () => {
        if (closed) return;
        closed = true;
        route.close();
        lane.signal.removeEventListener("abort", dispose);
        void lane.close().catch(() => void 0);
      };
      this.#disposeLive = dispose;
      lane.signal.addEventListener("abort", dispose, { once: true });
      if (lane.signal.aborted) dispose();
      void this.#readLive(lane, route).catch((error) => this.#fail(error)).finally(dispose);
    }
  }
  #attachData() {
    const data = this.#port.participant.data;
    if (this.#retiring || data === void 0 || data === this.#data) return false;
    this.#data = data;
    this.#detachContent = data.content.attachSource(this.peerId, {
      manifest: async (reference) => await this.#request("contentManifest", reference),
      chunk: async (reference, index) => {
        const bytes = await this.#request("contentChunk", { reference, index });
        this.#reader();
        if (bytes === null) return null;
        requireNetwork(
          typeof bytes === "string" && bytes.length <= 2 * (65536 + 16) && /^(?:[0-9a-f]{2})+$/u.test(bytes),
          "APPLICATION_CONTENT_CHUNK_INVALID"
        );
        return hexToBytes(bytes);
      },
      retained: async (reference) => {
        const receipt = await this.#request("contentRetained", reference);
        requireNetwork(receipt?.payload?.peer === this.peerId, "CONTENT_RETENTION_INVALID");
        return receipt;
      },
      observeRetention: async (receipt) => {
        await this.#request("contentObserveRetention", receipt);
      }
    });
    this.#detachKeys = data.keys.attachSource(this.peerId, async (request) => {
      const share = await this.#request("keyShare", request);
      this.#reader();
      requireNetwork(share?.payload?.issuer === this.peerId, "APPLICATION_KEY_SHARE_INVALID");
      return share;
    });
    return true;
  }
  async #read() {
    for await (const value of this.#wire.messages()) {
      this.signal.throwIfAborted();
      requireNetwork(value !== null && typeof value === "object" && "kind" in value, "APPLICATION_NETWORK_MESSAGE_INVALID");
      const kind = value.kind;
      if (kind === "hello") {
        const message2 = record(value, ["kind", "value"]), input = record(message2.value, ["application", "profile", "descriptor", "author", "nonce", "authority", "channel"]);
        const channel = record(input.channel, ["suite", "receiverKey"]);
        const local = this.#local;
        requireNetwork(local !== void 0, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
        requireNetwork(this.#remote === void 0 && channel.suite === APPLICATION_CHANNEL_SUITE && hexadecimal(channel.receiverKey) && input.application === local.application && input.profile === local.profile && input.descriptor === local.descriptor && hexadecimal(input.author) && hexadecimal(input.nonce) && input.author !== local.author && (this.#input.peerIdentity === void 0 || input.author === this.#input.peerIdentity), "APPLICATION_NETWORK_SCOPE_MISMATCH");
        const remote = await verifyAuthorityBundle(input.authority, this.#port.participant.authority.descriptor);
        this.signal.throwIfAborted();
        const current = await verifyAuthorityBundle(this.#port.participant.authority);
        this.signal.throwIfAborted();
        const latest = newest(current, remote);
        if (!same2(latest.bundle, current.bundle)) await this.#port.participant.adoptAuthority(latest.bundle);
        this.signal.throwIfAborted();
        this.#remote = input;
        this.#reader();
        const encapsulatedKey = await this.#channel.prepare(channel.receiverKey, this.#local, this.#remote);
        this.#reader();
        const signature = await signDomain(DOMAINS.peerConnection, encodePeerValue({ sender: this.#local, receiver: this.#remote, encapsulatedKey }), this.#port.participant.device.privateKey);
        this.#reader();
        this.#proofSent = this.#wire.send({ kind: "proof", signature: bytesToHex2(signature), encapsulatedKey }, () => this.#reader()).then(() => {
          this.#channel.enableSending();
        });
        void this.#proofSent.catch((error) => this.#fail(error));
      } else if (kind === "proof") {
        const message2 = record(value, ["kind", "signature", "encapsulatedKey"]);
        requireNetwork(!this.#authenticated && this.#remote !== void 0 && this.#proofSent !== void 0 && hexadecimal(message2.signature, 128) && hexadecimal(message2.encapsulatedKey), "APPLICATION_PEER_PROOF_INVALID");
        requireNetwork(await verifyDomain(
          DOMAINS.peerConnection,
          encodePeerValue({ sender: this.#remote, receiver: this.#local, encapsulatedKey: message2.encapsulatedKey }),
          hexToBytes(message2.signature),
          hexToBytes(this.peerId)
        ), "APPLICATION_PEER_PROOF_INVALID");
        this.#reader();
        await this.#channel.accept(message2.encapsulatedKey, this.#remote, this.#local);
        await interruptible(this.#proofSent, this.signal);
        this.#reader();
        this.#authenticated = true;
        this.#prepareLive();
        void this.#wire.send({ kind: "ready" }).catch((error) => this.#fail(error));
      } else {
        requireNetwork(this.#authenticated, "APPLICATION_PEER_AUTHENTICATION_REQUIRED");
        this.#reader();
        if (kind === "ready") {
          record(value, ["kind"]);
          requireNetwork(!this.#confirmed, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
          this.#confirmed = true;
          this.#readyResolve();
          continue;
        }
        requireNetwork(this.#confirmed, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
        if (kind === "request") {
          const message2 = record(value, ["kind", "message"]);
          const request = this.#incomingMessage(message2.message), id = Number(request.requestId);
          const method = methods.find((method2) => interests[method2].facet === request.facet && interests[method2].action === request.action);
          requireNetwork(
            Number.isSafeInteger(id) && String(id) === request.requestId && id > this.#lastRemoteRequest && method !== void 0 && this.#incoming < APPLICATION_NETWORK_LIMITS.incomingRequests,
            "APPLICATION_NETWORK_REQUEST_INVALID"
          );
          this.#lastRemoteRequest = id;
          this.#incoming++;
          this.#receivedRequests++;
          void this.#respond(request, method).catch((error) => this.#fail(error)).finally(() => {
            this.#incoming--;
          });
        } else if (kind === "response") {
          const message2 = record(value, ["kind", "ok", "message"]), response = this.#incomingMessage(message2.message);
          const id = Number(response.requestId);
          requireNetwork(Number.isSafeInteger(id) && String(id) === response.requestId && typeof message2.ok === "boolean", "APPLICATION_NETWORK_RESPONSE_INVALID");
          const pending = this.#pending.get(id);
          requireNetwork(pending !== void 0, "APPLICATION_NETWORK_RESPONSE_INVALID");
          const payload = validateParticipantResponse(response, pending.request, PEER_PARTICIPANT_POLICY).payload;
          let failure;
          if (!message2.ok) {
            requireNetwork(typeof payload === "string" && /^[A-Z0-9_]{1,128}$/u.test(payload), "APPLICATION_NETWORK_RESPONSE_INVALID");
            failure = pending.method !== "state" && payload === "APPLICATION_DATA_UNAVAILABLE" ? new PeerDataUnavailableError() : networkError(payload);
            if (isPeerDataUnavailable(failure)) {
              this.#remoteData = false;
              this.#remoteDataFailure = failure;
            }
          }
          this.#pending.delete(id);
          pending.cancel();
          if (failure === void 0) pending.resolve(payload);
          else pending.reject(failure);
        } else if (kind === "hint") {
          const message2 = this.#incomingMessage(record(value, ["kind", "message"]).message);
          requireNetwork(message2.facet === "ephemeral" && message2.action === "hint" && message2.payload === null, "APPLICATION_NETWORK_MESSAGE_INVALID");
          this.#kick();
        } else throw networkError("APPLICATION_NETWORK_MESSAGE_INVALID");
      }
    }
    throw networkError("APPLICATION_NETWORK_ENDED");
  }
  #incomingMessage(value) {
    const message2 = validateParticipantRequest(value, PEER_PARTICIPANT_POLICY);
    requireNetwork(message2.applicationId === this.#port.participant.descriptor.applicationId, "APPLICATION_NETWORK_SCOPE_MISMATCH");
    return message2;
  }
  async #readLive(lane, route) {
    try {
      for await (const frame of lane.frames(AbortSignal.any([this.signal, lane.signal]))) {
        this.#reader();
        requireNetwork(frame instanceof Uint8Array && frame.length <= MAX_SIGNAL_BYTES, "APPLICATION_NETWORK_LIVE_LIMIT");
        this.#receivedLiveBytes += frame.length;
        if (!this.#retiring && this.#owner.peers.get(this.peerId) === this) await route.receive(frame);
        this.#reader();
      }
    } catch (error) {
      if (!this.signal.aborted && !lane.signal.aborted) throw error;
    }
  }
  #request(method, value) {
    this.#reader();
    if (this.#retiring) {
      const current = this.#owner.peers.get(this.peerId);
      requireNetwork(current !== void 0 && current !== this, "APPLICATION_PEER_RETIRED");
      return current.#request(method, value);
    }
    if (method !== "state" && method !== "openData" && !this.#remoteData)
      return this.#openRemoteData().then(() => this.#request(method, value));
    requireNetwork(this.#pending.size < APPLICATION_NETWORK_LIMITS.pendingRequests && this.#nextRequest < Number.MAX_SAFE_INTEGER, "APPLICATION_NETWORK_BACKPRESSURE");
    const id = ++this.#nextRequest;
    const request = createParticipantRequest({
      applicationId: this.#port.participant.descriptor.applicationId,
      requestId: String(id),
      ...interests[method],
      payload: value
    }, PEER_PARTICIPANT_POLICY);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => this.#fail(networkError("APPLICATION_NETWORK_REQUEST_TIMEOUT")), this.#requestMs);
      this.#pending.set(id, { method, request, resolve, reject, cancel: () => clearTimeout(timer) });
      void Promise.resolve().then(() => this.#wire.send({ kind: "request", message: request }, () => {
        if (method === "submit") requireNetwork(grant(this.#port.participant, this.#port.participant.device.publicKey, "writer"), "PEER_AUTHOR_FORBIDDEN");
        if (method === "keyShare") requireNetwork(
          value.payload.recipient === this.#port.participant.device.publicKey,
          "APPLICATION_KEY_REQUEST_INVALID"
        );
      })).then(() => {
        this.#sentRequests++;
      }).catch((error) => {
        const pending = this.#pending.get(id);
        this.#pending.delete(id);
        pending?.cancel();
        pending?.reject(error);
        if (!(error instanceof Error && ["APPLICATION_NETWORK_BACKPRESSURE", "PEER_AUTHOR_FORBIDDEN"].includes(error.message))) this.#fail(error);
      });
    });
  }
  #openRemoteData() {
    if (this.#remoteData === true) return Promise.resolve();
    if (this.#remoteDataFailure !== void 0) return Promise.reject(this.#remoteDataFailure);
    requireNetwork(this.#port.participant.data !== void 0, "APPLICATION_DATA_NOT_ACTIVE");
    if (this.#remoteOpening !== void 0) return this.#remoteOpening;
    const work = (async () => {
      await this.#readState();
      if (this.#remoteData === true) return;
      requireNetwork(this.peerId === this.#port.participant.generation.payload.coordinator, "APPLICATION_DATA_NOT_ACTIVE");
      const value = await this.#request("openData", null);
      requireNetwork(value === null, "APPLICATION_NETWORK_RESPONSE_INVALID");
      this.#reader();
      this.#remoteData = true;
    })().finally(() => {
      if (this.#remoteOpening === work) this.#remoteOpening = void 0;
    });
    this.#remoteOpening = work;
    return work;
  }
  async #readState() {
    const response = record(await this.#request("state", null), ["authority", "data", "point", "revision"]);
    requireNetwork(typeof response.data === "boolean" && (response.data || response.point === null && response.revision === null), "APPLICATION_NETWORK_STATE_INVALID");
    this.#remoteData = response.data;
    if (response.data) this.#remoteDataFailure = void 0;
    return response;
  }
  async #respond(request, method) {
    try {
      this.#reader();
      const participant = this.#port.participant, input = request.payload;
      let value;
      if (method === "state") {
        requireNetwork(input === null, "APPLICATION_NETWORK_MESSAGE_INVALID");
        const replica = participant.data?.replica, revision = replica?.ready === true ? replica.revision : null;
        value = { authority: participant.authority, data: replica !== void 0, point: revision?.point ?? availablePoint(replica), revision };
      } else value = await this.#serveData(method, input);
      this.#reader();
      await this.#wire.send({ kind: "response", ok: true, message: createParticipantResponse(request, value, PEER_PARTICIPANT_POLICY) });
    } catch (error) {
      this.#reader();
      const code = error instanceof Error && /^[A-Z0-9_]{1,128}$/u.test(error.message) ? error.message : "APPLICATION_NETWORK_REQUEST_REJECTED";
      await this.#wire.send({ kind: "response", ok: false, message: createParticipantResponse(request, code, PEER_PARTICIPANT_POLICY) });
    }
  }
  async #serveData(method, input) {
    const participant = this.#port.participant;
    if (method === "openData") {
      requireNetwork(input === null, "APPLICATION_NETWORK_MESSAGE_INVALID");
      requireNetwork(participant.isCoordinator, "PEER_NOT_COORDINATOR");
    }
    if (method === "submit") {
      requireNetwork(input?.payload?.header?.author === this.peerId && grant(participant, this.peerId, "writer"), "PEER_AUTHOR_FORBIDDEN");
      requireNetwork(participant.isCoordinator, "PEER_NOT_COORDINATOR");
    }
    const activate = method === "openData" || method === "submit";
    requireNetwork(activate || participant.data !== void 0, "APPLICATION_DATA_NOT_ACTIVE");
    let data = participant.data;
    if (activate) {
      try {
        data = await participant.openData();
      } catch {
        this.#reader();
        throw networkError("APPLICATION_DATA_UNAVAILABLE");
      }
    }
    requireNetwork(data !== void 0, "APPLICATION_DATA_NOT_ACTIVE");
    this.#reader();
    this.#attachData();
    if (method === "openData") return null;
    return useData(data, async () => {
      const replica = data.replica;
      let value = null;
      if (method === "range") {
        const request = record(input, ["generation", "after", "through", "at"]);
        requireNetwork(request.generation === replica.generation.id, "APPLICATION_NETWORK_STATE_CHANGED");
        if (request.after !== null) validateHistoryPoint(request.after);
        validateHistoryPoint(request.through);
        const authority = await verifyAuthorityBundle(replica.authority);
        const commands = await replica.exportCommands({
          ...request.after === null ? {} : { after: request.after },
          ...request.at === null ? {} : { at: request.at },
          limit: APPLICATION_NETWORK_LIMITS.rangeCommands,
          maxBytes: APPLICATION_NETWORK_LIMITS.rangeBytes
        });
        this.#reader();
        requireNetwork(request.generation === replica.generation.id, "APPLICATION_NETWORK_STATE_CHANGED");
        value = commands.filter((command) => atOrAfter(
          authority,
          request.through,
          { generation: command.receipt.payload.generation, sequence: command.receipt.payload.sequence, root: command.receipt.root }
        ));
      } else if (method === "submit") {
        const attempt = input;
        requireNetwork(attempt?.payload?.header?.author === this.peerId && grant(participant, this.peerId, "writer"), "PEER_AUTHOR_FORBIDDEN");
        await replica.order(attempt);
        this.#reader();
        requireNetwork(grant(participant, this.peerId, "writer"), "PEER_AUTHOR_FORBIDDEN");
      } else if (method === "coverage") {
        const request = record(input, ["generation", "point"]);
        validateHistoryPoint(request.point);
        if (request.generation === replica.generation.id) {
          try {
            value = await replica.retainedCoverage(request.point);
          } catch (error) {
            if (!(error instanceof Error && ["PEER_RECOVERY_PREFIX_INCOMPLETE", "PEER_EPOCH_KEY_UNAVAILABLE"].includes(error.message))) throw error;
          }
        }
      } else if (method === "keyShare") {
        const request = input;
        requireNetwork(request?.payload?.recipient === this.peerId, "APPLICATION_KEY_REQUEST_INVALID");
        value = await data.keys.offer(request);
      } else if (method === "contentManifest") value = await data.content.serveManifest(this.peerId, input);
      else if (method === "contentChunk") {
        const request = record(input, ["reference", "index"]);
        requireNetwork(Number.isSafeInteger(request.index), "APPLICATION_CONTENT_CHUNK_INVALID");
        const bytes = await data.content.serveChunk(this.peerId, request.reference, request.index);
        value = bytes === null ? null : bytesToHex2(bytes);
      } else if (method === "contentRetained") value = await data.content.retained(input);
      else {
        const receipt = input;
        requireNetwork(receipt?.payload?.peer === this.peerId, "CONTENT_RETENTION_INVALID");
        await data.content.observeRetention(receipt);
      }
      return value;
    });
  }
  synchronize() {
    this.#reader();
    if (this.#retiring) {
      const current = this.#owner.peers.get(this.peerId);
      requireNetwork(current !== void 0 && current !== this, "APPLICATION_PEER_RETIRED");
      return current.synchronize();
    }
    if (this.#sync === void 0) return this.#startPull();
    if (this.#nextSync !== void 0) return this.#nextSync;
    const next = this.#sync.then(() => {
      this.#nextSync = void 0;
      this.#reader();
      return this.#startPull();
    }).finally(() => {
      if (this.#nextSync === next) this.#nextSync = void 0;
    });
    this.#nextSync = next;
    return next;
  }
  #startPull() {
    const task = this.#pull().catch((error) => {
      if (!isPeerDataUnavailable(error) && !retryablePull(error)) this.#fail(error);
      throw error;
    }).finally(() => {
      if (this.#sync === task) this.#sync = void 0;
      if (this.#syncAgain && this.#nextSync === void 0 && !this.signal.aborted && !this.#retiring) {
        this.#syncAgain = false;
        this.#kick();
      }
      if (!this.signal.aborted && !this.#retiring && this.#port.participant.data?.replica.ready === true) void this.#port.resume().catch(() => void 0);
    });
    this.#sync = task;
    return task;
  }
  async #pull(opened = false) {
    const requestedAt = Date.now(), participant = this.#port.participant;
    const response = await this.#readState();
    const remote = await verifyAuthorityBundle(response.authority, participant.authority.descriptor);
    const local = await verifyAuthorityBundle(participant.authority);
    this.#reader();
    const latest = newest(local, remote);
    if (!same2(latest.bundle, local.bundle)) await participant.adoptAuthority(latest.bundle);
    this.#reader();
    const target = transferTarget(remote, latest, response.point);
    const at = response.revision !== null && remote.current?.id === latest.current?.id ? response.revision : null;
    if (at !== null) {
      validateHistoryPoint(at.point);
      requireNetwork(
        at.applicationId === participant.descriptor.applicationId && at.historyId === participant.descriptor.historyId && at.generation === remote.current?.id && at.point.generation === at.generation && at.controlRevision === remote.current.payload.controlRevision && (at.point.sequence === 0 || same2(at.point, target)),
        "APPLICATION_NETWORK_STATE_INVALID"
      );
    }
    const data = participant.data;
    if (data === void 0) return;
    if (!response.data && this.peerId !== participant.generation.payload.coordinator) return;
    if (!response.data) {
      requireNetwork(!opened, "APPLICATION_NETWORK_STATE_CHANGED");
      await this.#openRemoteData();
      return this.#pull(true);
    }
    await useData(data, async () => {
      const replica = data.replica;
      await data.keys.ensure();
      this.#reader();
      let after = availablePoint(replica);
      if (after !== null && !remote.contains(after)) after = null;
      const peer = this;
      async function* pages() {
        const retained = availablePoint(replica);
        if (target === null || retained !== null && atOrAfter(latest, retained, target)) return;
        for (; ; ) {
          const input = await peer.#request("range", { generation: remote.current.id, after, through: target, at });
          requireNetwork(
            Array.isArray(input) && input.length > 0 && input.length <= APPLICATION_NETWORK_LIMITS.rangeCommands && encodePeerValue(input).length <= APPLICATION_NETWORK_LIMITS.rangeBytes,
            "APPLICATION_NETWORK_RANGE_INVALID"
          );
          const commands = input;
          let point = after;
          for (const command of commands) {
            const receipt = command?.receipt;
            requireNetwork(receipt?.payload !== void 0, "APPLICATION_NETWORK_RANGE_INVALID");
            const next = { generation: receipt.payload.generation, sequence: receipt.payload.sequence, root: receipt.root };
            requireNetwork(
              (point === null || !atOrAfter(latest, point, next)) && atOrAfter(latest, target, next) && (!atOrAfter(latest, next, target) || same2(next, target)),
              "APPLICATION_NETWORK_RANGE_INVALID"
            );
            point = next;
          }
          yield commands;
          peer.#reader();
          after = point;
          if (same2(point, target)) break;
        }
      }
      if (at !== null) await replica.synchronize(latest.bundle, pages(), { at });
      else {
        for await (const commands of pages()) await replica.receiveHistory(latest.bundle, commands);
        if (!replica.ready) await replica.receiveHistory(latest.bundle, []);
      }
      this.#reader();
      if (replica.ready) {
        const generation = replica.generation.id, point = at?.point ?? target ?? replica.revision.point;
        const remoteCoverage = await this.#request("coverage", { generation, point });
        if (remoteCoverage !== null) {
          const coverage = remoteCoverage;
          requireNetwork(coverage.payload?.peer === this.peerId && coverage.payload.generation === generation && same2(coverage.payload.point, point), "PEER_COVERAGE_INVALID");
          if (replica.ready && replica.generation.id === generation) await replica.observeCoverage(coverage);
        }
        this.#reader();
      }
      if (at !== null && replica.generation.id === at.generation && this.peerId === replica.generation.payload.coordinator) {
        this.#reader();
        this.#port.observeHead?.(this.peerId, structuredClone(at), requestedAt);
      }
    });
  }
  #kick() {
    if (this.signal.aborted || this.#retiring) return;
    if (this.#sync !== void 0) {
      this.#syncAgain = true;
      return;
    }
    void this.#startPull().then(() => {
      this.#stateRetries = 0;
    }).catch((error) => {
      if (isPeerDataUnavailable(error)) return;
      if (retryablePull(error) && this.#stateRetries++ < 2) this.#kick();
      else this.#fail(error);
    });
  }
  #changed() {
    try {
      this.#reader();
      if (this.#retiring) return;
      const activated = this.#attachData(), participant = this.#port.participant, replica = participant.data?.replica;
      const key = `${participant.generation.id}/${participant.authority.controls.at(-1).payload.revision}/${replica === void 0 ? "inactive" : "active"}/${availablePoint(replica)?.root ?? ""}/${replica?.ready ?? false}`;
      if (key !== this.#lastHint) {
        this.#lastHint = key;
        this.#sendHint();
      }
      if (activated) this.#kick();
    } catch (error) {
      this.#fail(error);
    }
  }
  #sendHint() {
    if (this.#hintPending || this.signal.aborted || this.#retiring) return;
    this.#hintPending = true;
    const advertised = this.#lastHint;
    const message2 = createParticipantRequest({
      applicationId: this.#port.participant.descriptor.applicationId,
      requestId: "hint",
      facet: "ephemeral",
      action: "hint",
      payload: null
    }, PEER_PARTICIPANT_POLICY);
    void Promise.resolve().then(() => {
      if (!this.#retiring) return this.#wire.send({ kind: "hint", message: message2 });
    }).catch((error) => this.#fail(error)).finally(() => {
      this.#hintPending = false;
      if (this.#lastHint !== advertised) this.#sendHint();
    });
  }
  #fail(error) {
    void this.#dispose(error);
  }
  #dispose(error) {
    if (this.#closeTask !== void 0) return this.#closeTask;
    let closed;
    this.#closeTask = new Promise((resolve) => {
      closed = resolve;
    });
    const reason = error ?? networkError("APPLICATION_NETWORK_CLOSED");
    if (this.#drainTimer !== void 0) clearTimeout(this.#drainTimer);
    this.#drainTimer = void 0;
    if (this.#owner.retiring.get(this.peerId) === this) this.#owner.retiring.delete(this.peerId);
    this.#controller.abort(reason);
    this.#channel.clear();
    this.#readyReject(reason);
    for (const pending of this.#pending.values()) {
      pending.cancel();
      pending.reject(reason);
    }
    this.#pending.clear();
    this.#detach?.();
    this.#detachContent?.();
    this.#detachKeys?.();
    this.#unsubscribe?.();
    this.#route?.close();
    this.#disposeLive?.();
    for (const dispose of this.#disposeListeners) dispose();
    this.#disposeListeners = [];
    if (this.#owner.peers.get(this.peerId) === this) this.#owner.peers.delete(this.peerId);
    if (error === void 0) this.#completeResolve();
    else this.#completeReject(error);
    const deadline2 = timeout(1e3, "APPLICATION_NETWORK_CLOSE_TIMEOUT");
    void interruptible(Promise.resolve().then(() => this.#input.connection.close()), deadline2.signal).catch(() => void 0).finally(() => {
      deadline2.cancel();
      closed();
    });
    return this.#closeTask;
  }
  retire() {
    if (this.#closeTask !== void 0) return this.#closeTask;
    if (this.#retiring) return this.completion;
    this.#reader();
    this.#retiring = true;
    this.#syncAgain = false;
    const previous = this.#owner.retiring.get(this.peerId);
    if (previous !== void 0 && previous !== this) void previous.close();
    if (this.#owner.retiring.size >= APPLICATION_NETWORK_LIMITS.peers) void this.#owner.retiring.values().next().value?.close();
    this.#owner.retiring.set(this.peerId, this);
    if (this.#owner.peers.get(this.peerId) === this) this.#owner.peers.delete(this.peerId);
    this.#detach?.();
    this.#detach = void 0;
    this.#detachContent?.();
    this.#detachContent = void 0;
    this.#detachKeys?.();
    this.#detachKeys = void 0;
    this.#route?.close();
    this.#drainTimer = setTimeout(() => {
      void this.#dispose();
    }, this.#drainMs);
    return this.completion;
  }
  close() {
    return this.#dispose();
  }
};
function connectedApplicationPeers(port) {
  return [...owners2.get(port)?.peers.values() ?? []];
}
async function connectApplicationPeer(port, input) {
  let owner = owners2.get(port);
  if (owner === void 0) {
    owner = { next: 0, openings: /* @__PURE__ */ new Map(), accepted: /* @__PURE__ */ new Map(), peers: /* @__PURE__ */ new Map(), retiring: /* @__PURE__ */ new Map() };
    owners2.set(port, owner);
  }
  requireNetwork(owner.openings.size < APPLICATION_NETWORK_LIMITS.peers && owner.next < Number.MAX_SAFE_INTEGER, "APPLICATION_PEER_LIMIT");
  const attempt = ++owner.next, peer = new NetworkPeer(port, input, owner, attempt);
  owner.openings.set(peer, attempt);
  try {
    await peer.open();
    return peer;
  } catch (error) {
    await peer.close();
    throw error;
  } finally {
    owner.openings.delete(peer);
    const oldest = Math.min(...owner.openings.values());
    for (const [key, accepted] of owner.accepted) if (!owner.peers.has(key) && accepted < oldest) owner.accepted.delete(key);
  }
}
async function connectApplicationPeerPair(left, right) {
  requireNetwork(left !== right, "APPLICATION_PEER_SELF");
  const [a, b] = createFramedPeerConnectionPair();
  const links = await Promise.allSettled([
    connectApplicationPeer(left, { connection: a, peerIdentity: right.participant.device.publicKey }),
    connectApplicationPeer(right, { connection: b, peerIdentity: left.participant.device.publicKey })
  ]);
  if (links[0].status !== "fulfilled" || links[1].status !== "fulfilled") {
    await Promise.all([a.close(), b.close()]);
    throw links.find((value) => value.status === "rejected").reason;
  }
  const first = links[0].value, second = links[1].value;
  const close = async () => {
    const x = first.close(), y = second.close();
    await Promise.all([x, y]);
  };
  try {
    await Promise.all([first.synchronize(), second.synchronize()]);
    return { synchronize: async () => {
      await Promise.all([first.synchronize(), second.synchronize()]);
    }, close };
  } catch (error) {
    await close();
    throw error;
  }
}

// packages/peer-session/src/participation.ts
var identity = (value) => typeof value === "string" && /^[0-9a-f]{64}$/u.test(value);
var samePoint = (left, right) => left.generation === right.generation && left.sequence === right.sequence && left.root === right.root;
var message = (error) => error instanceof Error ? error.message : "APPLICATION_PARTICIPATION_FAILED";
function bound2(value, fallback, minimum, maximum) {
  const selected = value ?? fallback;
  if (!Number.isSafeInteger(selected) || selected < minimum || selected > maximum) throw new Error("APPLICATION_PARTICIPATION_OPTIONS_INVALID");
  return selected;
}
var OwnedApplicationParticipation = class {
  #owner;
  #options;
  #lifetime = new AbortController();
  #discoveryFence = new AbortController();
  signal;
  #maxPeers;
  #initialRetry;
  #maximumRetry;
  #graceMs;
  #freshnessMs;
  #upgradeCooldownMs;
  #timeoutMs;
  #observationKey;
  #listeners = /* @__PURE__ */ new Set();
  #calls = /* @__PURE__ */ new Map();
  #joining = /* @__PURE__ */ new Map();
  #physicalOpenings = /* @__PURE__ */ new Set();
  #ownedLinks = /* @__PURE__ */ new Set();
  #transports = /* @__PURE__ */ new WeakMap();
  #lastUpgrade = /* @__PURE__ */ new Map();
  #upgradeTask;
  #connectionIds = /* @__PURE__ */ new WeakMap();
  #nextConnectionId = 0;
  #connectionRevision = 0;
  #connectionKey = "[]";
  #watchedLinks = /* @__PURE__ */ new Map();
  #task;
  #invitations;
  #notifications;
  #unsubscribe;
  #status = { connectionRevision: 0, phase: "connecting", connectedPeers: [], recovery: null, error: null };
  #observation = null;
  #pendingObservation = null;
  #persistence;
  #proposal = null;
  #approved = null;
  #wakePending = false;
  #wakeWait;
  #nextScan = Infinity;
  #nextAdvertisement = Infinity;
  #discoveryReady = false;
  #hasDiscoveryReady = false;
  #discoveryTerminal = false;
  #discoveryError = null;
  #advertiseRetry = 0;
  #advertisementError = null;
  #stateKey;
  #missingSince = null;
  #retry = 0;
  #initial = true;
  #generation;
  #error = null;
  #closed;
  #dataActive;
  constructor(owner, input) {
    this.#owner = owner;
    const application = input.control.application.bind(input.control), selectGeneration = input.control.selectGeneration.bind(input.control);
    this.#options = {
      control: {
        application: (options) => this.#delivery("control:read", () => application(options)),
        selectGeneration: (request, options) => this.#delivery("control:select", () => selectGeneration(request, options))
      },
      discovery: {
        read: input.discovery.read.bind(input.discovery),
        advertise: input.discovery.advertise.bind(input.discovery),
        notifications: input.discovery.notifications.bind(input.discovery),
        withdraw: input.discovery.withdraw.bind(input.discovery),
        invitations: input.discovery.invitations.bind(input.discovery)
      },
      transport: {
        open: input.transport.open.bind(input.transport),
        ...input.transport.upgrade === void 0 ? {} : { upgrade: input.transport.upgrade.bind(input.transport) },
        ...input.transport.describe === void 0 ? {} : { describe: input.transport.describe.bind(input.transport) }
      }
    };
    this.#maxPeers = bound2(input.connections?.maxPeers, 4, 1, 8);
    this.#initialRetry = bound2(input.connections?.retryInitialMs, 1e3, 1, 6e4);
    this.#maximumRetry = bound2(input.connections?.retryMaxMs, 3e4, this.#initialRetry, 6e5);
    this.#timeoutMs = bound2(input.connections?.timeoutMs, 15e3, 1, 12e4);
    this.#upgradeCooldownMs = bound2(input.connections?.upgradeCooldownMs, 3e4, 1e3, 6e5);
    this.#graceMs = bound2(input.recovery?.graceMs, 3e3, 1, 6e5);
    this.#freshnessMs = bound2(input.recovery?.freshnessMs, 3e5, 1, 864e5);
    this.#generation = owner.participant.generation.id;
    this.#dataActive = owner.participant.data !== void 0;
    this.#observationKey = `peer-session/coordinator-observation/${owner.participant.descriptor.applicationId}`;
    this.signal = AbortSignal.any([owner.signal, this.#lifetime.signal]);
    this.#stateKey = this.#snapshotKey();
    this.#unsubscribe = owner.participant.subscribe(() => {
      const key = this.#snapshotKey();
      if (key === this.#stateKey) return;
      this.#stateKey = key;
      this.#nextScan = 0;
      this.#nextAdvertisement = 0;
      if (!this.#dataActive && owner.participant.data !== void 0) {
        this.#dataActive = true;
        this.#missingSince = null;
        this.#nextScan = 0;
        this.#nextAdvertisement = 0;
      }
      this.#wake();
    });
    this.#notifications = Promise.resolve().then(() => this.#watchDiscovery()).catch((error) => {
      if (!this.signal.aborted) {
        this.#discoveryError = message(error);
        this.#publish("unavailable");
      }
    });
    this.#invitations = Promise.resolve().then(() => this.#listen()).catch((error) => {
      if (!this.signal.aborted) this.#error = message(error);
    });
    this.#task = Promise.resolve().then(() => this.#run()).catch((error) => {
      if (!this.signal.aborted) {
        this.#error = message(error);
        this.#publish("unavailable");
      }
    });
  }
  get status() {
    return structuredClone(this.#status);
  }
  onStatus(listener) {
    this.#listeners.add(listener);
    try {
      listener(this.status);
    } catch {
    }
    return () => {
      this.#listeners.delete(listener);
    };
  }
  diagnostics() {
    return Promise.resolve(this.#links().map((link) => {
      const stats = link.stats;
      return {
        peerId: link.peerId,
        ...this.#transports.get(link) ?? { kind: "unknown" },
        ...stats,
        sentReliableBytes: stats.sentBytes,
        receivedReliableBytes: stats.receivedBytes,
        sentBytes: stats.sentBytes + stats.sentLiveBytes,
        receivedBytes: stats.receivedBytes + stats.receivedLiveBytes
      };
    }).sort((left, right) => left.peerId.localeCompare(right.peerId)));
  }
  reconsiderConnections() {
    if (this.signal.aborted || this.#discoveryTerminal || this.#options.transport.upgrade === void 0) return Promise.resolve();
    if (this.#upgradeTask !== void 0) return this.#upgradeTask;
    const candidates = this.#links().filter((link) => this.#transports.get(link)?.kind === "relay");
    const now = Date.now(), current = new Set(this.#links().map((link) => link.peerId));
    for (const peerId of this.#lastUpgrade.keys()) if (!current.has(peerId)) this.#lastUpgrade.delete(peerId);
    const work = candidates.filter((link) => now - (this.#lastUpgrade.get(link.peerId) ?? -Infinity) >= this.#upgradeCooldownMs);
    if (work.length === 0) return Promise.resolve();
    const task = Promise.allSettled(work.map((link) => this.#connect({ peer: { identity: link.peerId, route: null }, upgrade: true }))).then(() => void 0).finally(() => {
      if (this.#upgradeTask === task) this.#upgradeTask = void 0;
    });
    this.#upgradeTask = task;
    return task;
  }
  async approveRecovery(proposalId) {
    this.signal.throwIfAborted();
    const proposal = this.#proposal, replica = this.#owner.participant.data?.replica;
    if (replica === void 0 || proposal === null || proposal.id !== proposalId) throw new Error("APPLICATION_RECOVERY_APPROVAL_STALE");
    const base = await replica.recoveryPoint().catch((error) => {
      throw new Error("APPLICATION_RECOVERY_APPROVAL_STALE", { cause: error });
    });
    const generation = replica.generation;
    const id = await peerDigest({ generation: generation.id, control: generation.payload.controlRevision, coordinator: proposal.coordinator, point: base.point });
    this.signal.throwIfAborted();
    if (this.#proposal?.id !== proposalId || !samePoint(proposal.point, base.point) || id !== proposalId || replica.generation.id !== generation.id) throw new Error("APPLICATION_RECOVERY_APPROVAL_STALE");
    this.#approved = proposalId;
    this.#nextScan = 0;
    this.#wake();
  }
  /** Called only after this exact coordinator's authenticated head has been fully verified locally. */
  observeHead(peerId, revision, requestedAt) {
    const replica = this.#owner.participant.data?.replica;
    if (replica === void 0 || this.signal.aborted || peerId !== replica.generation.payload.coordinator || revision.generation !== replica.generation.id || !Number.isSafeInteger(requestedAt) || requestedAt > Date.now() || requestedAt < 0) return;
    if (this.#observation?.generation === revision.generation && this.#observation.observedAt > requestedAt) return;
    this.#observation = { generation: revision.generation, point: structuredClone(revision.point), observedAt: requestedAt };
    this.#pendingObservation = this.#observation;
    if (this.#persistence !== void 0) return;
    const task = (async () => {
      while (this.#pendingObservation !== null) {
        const value = this.#pendingObservation;
        this.#pendingObservation = null;
        await this.#owner.store.put(this.#observationKey, encodePeerValue(value));
      }
    })().catch((error) => {
      this.#observation = null;
      this.#pendingObservation = null;
      this.#error = message(error);
      this.#wake();
    }).finally(() => {
      if (this.#persistence === task) this.#persistence = void 0;
    });
    this.#persistence = task;
  }
  async #run() {
    const bytes = await this.#owner.store.get(this.#observationKey);
    this.signal.throwIfAborted();
    if (bytes !== null) {
      const value = decodePeerValue(bytes);
      validateHistoryPoint(value.point);
      if (identity(value.generation) && Number.isSafeInteger(value.observedAt) && value.observedAt >= 0 && value.point.generation === value.generation && (this.#observation === null || value.observedAt > this.#observation.observedAt)) this.#observation = value;
    }
    while (!this.signal.aborted) {
      if (this.#discoveryTerminal) {
        this.#publish("unavailable");
        await this.#wait(Infinity);
        continue;
      }
      this.#watchLinks();
      const participant = this.#owner.participant, replica = participant.data?.replica, now = Date.now();
      this.#observeGeneration();
      if (replica === void 0 || this.#healthy()) {
        this.#missingSince = null;
        this.#proposal = null;
        this.#approved = null;
      } else this.#missingSince ??= now;
      if (!this.#discoveryReady && (!this.#hasDiscoveryReady || this.#healthy())) {
        this.#publish();
        await this.#wait(Infinity);
        continue;
      }
      if (this.#discoveryReady && now >= this.#nextAdvertisement) {
        this.#nextAdvertisement = Infinity;
        try {
          await this.#call("advertise", (signal) => this.#options.discovery.advertise(this.#advertisement(), { signal }));
          this.#advertiseRetry = 0;
          this.#advertisementError = null;
        } catch (error) {
          this.#advertisementError = message(error);
          this.#nextAdvertisement = Math.min(this.#nextAdvertisement, Date.now() + this.#backoff(this.#advertiseRetry++));
        }
      }
      if (!this.#discoveryTerminal && Date.now() >= this.#nextScan) {
        this.#nextScan = Infinity;
        let failed = false;
        try {
          await this.#scan();
          this.#error = null;
        } catch (error) {
          failed = true;
          this.#error = message(error);
        }
        this.signal.throwIfAborted();
        if (failed || !this.#healthy()) this.#nextScan = Math.min(this.#nextScan, Date.now() + this.#backoff(this.#retry++));
        else this.#retry = 0;
      }
      this.#publish();
      await this.#wait(Math.max(1, Math.min(this.#nextScan, this.#discoveryReady ? this.#nextAdvertisement : Infinity) - Date.now()));
    }
  }
  #advertisement() {
    const participant = this.#owner.participant, replica = participant.data?.replica;
    return {
      identity: participant.device.publicKey,
      storageId: participant.storageId,
      generation: participant.generation.id,
      data: replica !== void 0,
      point: replica?.ready === true ? replica.revision.point : null
    };
  }
  #snapshotKey() {
    const participant = this.#owner.participant, replica = participant.data?.replica, control = participant.authority.controls.at(-1);
    return JSON.stringify([
      participant.generation.id,
      control?.payload.revision,
      control?.signature,
      replica !== void 0,
      replica?.closed === true,
      this.#links().map((link) => `${link.peerId}:${link.data}`).sort()
    ]);
  }
  async #watchDiscovery() {
    let failures = 0;
    while (!this.signal.aborted) {
      let iterator;
      let ready = false;
      try {
        iterator = this.#options.discovery.notifications({ signal: this.signal })[Symbol.asyncIterator]();
        while (!this.signal.aborted) {
          const next = await awaitOwnedTask(this.signal, () => iterator.next());
          if (next.done) throw new Error("APPLICATION_DISCOVERY_NOTIFICATIONS_ENDED");
          const value = next.value;
          if (value === null || typeof value !== "object" || Array.isArray(value) || Object.keys(value).join() !== "type" || !("type" in value) || value.type !== "ready" && value.type !== "changed" || !ready && value.type !== "ready") throw new Error("APPLICATION_DISCOVERY_NOTIFICATION_INVALID");
          if (value.type === "ready") {
            ready = true;
            this.#discoveryReady = true;
            this.#hasDiscoveryReady = true;
            this.#discoveryError = null;
            failures = 0;
            this.#nextAdvertisement = 0;
            void this.reconsiderConnections();
          }
          this.#nextScan = 0;
          this.#wake();
        }
      } catch (error) {
        if (!this.signal.aborted) {
          this.#discoveryReady = false;
          this.#discoveryError = message(error);
          if (error !== null && typeof error === "object" && "retryable" in error && error.retryable === false) {
            this.#discoveryTerminal = true;
            this.#nextScan = Infinity;
            this.#nextAdvertisement = Infinity;
            this.#proposal = null;
            this.#approved = null;
            this.#discoveryFence.abort(error);
            for (const [peerId, joining] of this.#joining) {
              if (!joining.upgrade && !this.#links().some((link) => link.peerId === peerId && link.data === "active")) joining.controller.abort(error);
            }
            this.#wake();
            break;
          }
          this.#wake();
        }
      } finally {
        try {
          void Promise.resolve(iterator?.return?.()).catch(() => void 0);
        } catch {
        }
      }
      if (!this.signal.aborted) await delay(this.#backoff(failures++), this.signal);
    }
  }
  async #scan() {
    const participant = this.#owner.participant;
    let authorityError;
    if (this.#initial || !this.#healthy()) {
      try {
        const bundle = await this.#call("authority", (signal) => this.#options.control.application({ signal }));
        this.signal.throwIfAborted();
        await verifyAuthorityBundle(bundle, participant.authority.descriptor);
        this.signal.throwIfAborted();
        await participant.adoptAuthority(bundle);
        this.#initial = false;
      } catch (error) {
        authorityError = new Error(message(error), { cause: error });
      }
    }
    let directoryError;
    if (!this.#healthy() || this.#links().length < this.#maxPeers) {
      try {
        const hints = this.#hints(await this.#call("directory", (signal) => this.#options.discovery.read({ signal })));
        const coordinator = participant.generation.payload.coordinator;
        hints.sort((left, right) => Number(right.identity === coordinator) - Number(left.identity === coordinator) || Number(participant.grant(right.identity)?.reader === true) - Number(participant.grant(left.identity)?.reader === true) || left.identity.localeCompare(right.identity));
        await Promise.allSettled(hints.slice(0, this.#maxPeers).map((peer) => this.#connect({ peer })));
      } catch (error) {
        directoryError = new Error(message(error), { cause: error });
      }
    }
    this.signal.throwIfAborted();
    const links = this.#links(), synchronized = await Promise.allSettled(links.map((link) => this.#call(`sync:${link.peerId}`, () => link.synchronize())));
    for (const [index, result] of synchronized.entries()) {
      if (result.status === "rejected" && !isPeerDataUnavailable(result.reason) && !this.signal.aborted && !this.#discoveryTerminal) void links[index].close().catch(() => void 0);
    }
    const available = new Set(links.filter((link, index) => synchronized[index]?.status === "fulfilled" && link.data === "active" && !link.signal.aborted).map((link) => link.peerId));
    this.signal.throwIfAborted();
    this.#observeGeneration();
    const data = participant.data;
    if (data === void 0) {
      if (directoryError !== void 0) throw directoryError;
      if (authorityError !== void 0) throw authorityError;
      return;
    }
    const replica = data.replica;
    const pending = [...await this.#call("journal", () => data.recovery.inspect())].reverse().find((entry) => entry.selected === null && !entry.superseded);
    if (pending !== void 0) {
      if (pending.request.payload.reason !== "takeover" && pending.request.payload.reason !== "handover") throw new Error("APPLICATION_TRANSITION_JOURNAL_INVALID");
      await this.#select(pending.request.payload.coordinator, pending.request.payload.transitionId, pending.request.payload.reason);
      return;
    }
    if (this.#healthy() || this.#missingSince === null || Date.now() - this.#missingSince < this.#graceMs) {
      if (directoryError !== void 0) throw directoryError;
      if (authorityError !== void 0) throw authorityError;
      return;
    }
    if (authorityError !== void 0) throw authorityError;
    if (replica.grant(replica.device.publicKey)?.recovery !== true) throw new Error("PEER_RECOVERY_FORBIDDEN");
    const base = await replica.recoveryPoint();
    this.signal.throwIfAborted();
    const expected = { generation: replica.generation.id, controlRevision: replica.generation.payload.controlRevision, point: base.point };
    const retained = replica.ready ? replica.shared(base.point) : [];
    const candidates = /* @__PURE__ */ new Set();
    if (replica.grant(replica.device.publicKey)?.coordinator === true) candidates.add(replica.device.publicKey);
    for (const link of this.#links()) {
      if (available.has(link.peerId) && replica.grant(link.peerId)?.coordinator === true && retained.some((receipt) => receipt.payload.peer === link.peerId && samePoint(receipt.payload.point, base.point))) candidates.add(link.peerId);
    }
    const selected = [...candidates].sort()[0];
    if (selected === void 0) throw new Error("APPLICATION_NO_COMPLETE_COORDINATOR");
    const observation = this.#observation, now = Date.now();
    let observedAt = null;
    if (observation !== null && observation.generation === replica.generation.id && observation.observedAt <= now) {
      try {
        await replica.prefixProof(observation.point);
        observedAt = observation.observedAt;
      } catch {
      }
    }
    this.signal.throwIfAborted();
    const ageMs = observedAt === null ? null : now - observedAt;
    const id = await peerDigest({ generation: expected.generation, control: expected.controlRevision, coordinator: selected, point: base.point });
    if (this.#healthy() || this.#joining.has(replica.generation.payload.coordinator)) return;
    if (ageMs === null || ageMs > this.#freshnessMs) {
      this.#proposal = { id, coordinator: selected, point: base.point, reason: ageMs === null ? "freshness-unknown" : "older-than-budget", observedAt, ageMs };
      if (this.#approved !== id) return;
    } else this.#proposal = null;
    await this.#select(selected, void 0, "takeover", expected);
  }
  async #select(coordinator, transitionId, reason = "takeover", expected) {
    const data = this.#owner.participant.data;
    if (data === void 0) throw new Error("APPLICATION_DATA_NOT_ACTIVE");
    this.#publish("recovering");
    await this.#call("selection", (signal) => data.recovery[reason](this.#options.control, {
      coordinator,
      signal,
      ...transitionId === void 0 ? {} : { transitionId },
      ...expected === void 0 ? {} : { expected }
    }));
    this.signal.throwIfAborted();
    await this.#call("resume", () => this.#owner.resume());
    this.#proposal = null;
    this.#approved = null;
    this.#nextAdvertisement = 0;
  }
  #hints(input) {
    const payload = createParticipantRequest({
      applicationId: this.#owner.participant.descriptor.applicationId,
      requestId: "directory",
      facet: "discovery",
      action: "read",
      payload: input
    }).payload;
    if (!Array.isArray(payload) || payload.length > 64 || encodePeerValue(payload).length > 64 * 1024) throw new Error("APPLICATION_DIRECTORY_INVALID");
    const valid = payload.map((value) => {
      if (value === null || typeof value !== "object" || Object.keys(value).length !== 2 || !("identity" in value) || !identity(value.identity) || !Object.hasOwn(value, "route")) throw new Error("APPLICATION_DIRECTORY_INVALID");
      return value;
    }).filter((value) => value.identity !== this.#owner.participant.device.publicKey);
    return [...new Map(valid.map((value) => [value.identity, value])).values()];
  }
  async #listen() {
    const signal = AbortSignal.any([this.signal, this.#discoveryFence.signal]);
    let failures = 0;
    while (!signal.aborted) {
      let iterator;
      try {
        iterator = this.#options.discovery.invitations({ signal })[Symbol.asyncIterator]();
        while (!signal.aborted) {
          const next = await awaitOwnedTask(signal, () => iterator.next());
          if (next.done) break;
          const value = createParticipantRequest({
            applicationId: this.#owner.participant.descriptor.applicationId,
            requestId: "invitation",
            facet: "ephemeral",
            action: "invite",
            payload: next.value
          }).payload;
          if (value === null || typeof value !== "object" || Object.keys(value).length !== 2 && !(Object.keys(value).length === 3 && value.upgrade === true) || !Object.hasOwn(value, "token")) throw new Error("APPLICATION_INVITATION_INVALID");
          const peer = this.#hints([value.peer])[0];
          if (peer !== void 0) void this.#connect({ peer, invitation: value.token, ...value.upgrade ? { upgrade: true } : {} }).catch((error) => {
            if (!value.upgrade) {
              this.#error = message(error);
              this.#wake();
            }
          });
          failures = 0;
        }
      } catch (error) {
        if (!signal.aborted) this.#error = message(error);
      } finally {
        try {
          void Promise.resolve(iterator?.return?.()).catch(() => void 0);
        } catch {
        }
      }
      if (!signal.aborted) await delay(this.#backoff(failures++), signal);
    }
  }
  async #connect(input) {
    this.signal.throwIfAborted();
    this.#discoveryFence.signal.throwIfAborted();
    const peer = this.#hints([input.peer])[0];
    if (peer === void 0) return;
    let current = this.#links().find((link2) => link2.peerId === peer.identity);
    if (input.upgrade ? current === void 0 || this.#transports.get(current)?.kind !== "relay" || this.#options.transport.upgrade === void 0 : current !== void 0) return;
    const incoming = input.invitation !== void 0;
    let superseded = false;
    while (true) {
      const previous = this.#joining.get(peer.identity);
      if (previous === void 0) {
        if (input.upgrade && !superseded) {
          const last = this.#lastUpgrade.get(peer.identity);
          if (last !== void 0 && Date.now() - last < this.#upgradeCooldownMs) return;
        }
        break;
      }
      if (!incoming) {
        await awaitOwnedTask(this.signal, () => previous.finished);
        return;
      }
      if (previous.incoming || this.#owner.participant.device.publicKey < peer.identity) return;
      superseded = true;
      previous.controller.abort(new Error("APPLICATION_CONNECTION_SUPERSEDED"));
      await awaitOwnedTask(this.signal, () => previous.finished);
      this.signal.throwIfAborted();
      this.#discoveryFence.signal.throwIfAborted();
      if (input.upgrade ? !this.#links().some((link2) => link2.peerId === peer.identity && this.#transports.get(link2)?.kind === "relay") : this.#links().some((link2) => link2.peerId === peer.identity)) return;
    }
    current = this.#links().find((link2) => link2.peerId === peer.identity);
    if (input.upgrade ? current === void 0 || this.#transports.get(current)?.kind !== "relay" : current !== void 0) return;
    if (this.#physicalOpenings.size >= this.#maxPeers || !input.upgrade && this.#links().length + this.#physicalOpenings.size >= this.#maxPeers) return;
    if (input.upgrade) this.#lastUpgrade.set(peer.identity, Date.now());
    const token = /* @__PURE__ */ Symbol(), controller = new AbortController();
    const signal = AbortSignal.any([this.signal, controller.signal]);
    const fenceUpgrade = () => {
      if (!this.#links().some((value) => value.peerId === peer.identity && value !== current)) controller.abort(this.#discoveryFence.signal.reason);
    };
    if (input.upgrade) {
      this.#discoveryFence.signal.addEventListener("abort", fenceUpgrade, { once: true });
      if (this.#discoveryFence.signal.aborted) fenceUpgrade();
    }
    let finished, settled = false, link, connection;
    const joining = { controller, incoming, upgrade: input.upgrade === true, finished: new Promise((resolve) => {
      finished = resolve;
    }) };
    this.#joining.set(peer.identity, joining);
    this.#physicalOpenings.add(token);
    const timer = setTimeout(() => controller.abort(new Error("APPLICATION_CONNECTION_TIMEOUT")), this.#timeoutMs);
    const opening = Promise.resolve().then(() => {
      signal.throwIfAborted();
      const value = { peer, ...incoming ? { invitation: structuredClone(input.invitation) } : {} };
      return input.upgrade ? this.#options.transport.upgrade(value, { signal }) : this.#options.transport.open(value, { signal });
    });
    void opening.then((value) => {
      if (signal.aborted) return value.close();
    }, () => void 0).catch(() => void 0);
    void opening.finally(() => {
      settled = true;
      if (signal.aborted) this.#physicalOpenings.delete(token);
    }).catch(() => void 0);
    try {
      connection = await awaitOwnedTask(signal, () => opening);
      signal.throwIfAborted();
      if (input.upgrade && this.#links().some((link2) => link2.peerId === peer.identity && this.#transports.get(link2)?.kind === "direct")) {
        await connection.close();
        return;
      }
      const description = this.#options.transport.describe?.(connection) ?? { kind: "unknown" };
      if (!["direct", "relay", "unknown"].includes(description.kind) || description.reason !== void 0 && !["direct_failed", "direct_timeout"].includes(description.reason) || input.upgrade && description.kind !== "direct") throw new Error("APPLICATION_TRANSPORT_DESCRIPTION_INVALID");
      link = await this.#owner.connect({
        connection,
        peerIdentity: peer.identity,
        signal,
        handshakeTimeoutMs: this.#timeoutMs,
        requestTimeoutMs: this.#timeoutMs,
        transferTimeoutMs: this.#timeoutMs
      });
      this.#discoveryFence.signal.removeEventListener("abort", fenceUpgrade);
      this.#transports.set(link, { kind: description.kind, ...description.reason === void 0 ? {} : { reason: description.reason } });
      try {
        await awaitOwnedTask(signal, () => link.synchronize());
      } catch (error) {
        if (!isPeerDataUnavailable(error)) throw error;
      }
      signal.throwIfAborted();
      this.#ownedLinks.add(link);
      this.#watchLinks();
      this.#nextScan = 0;
      this.#wake();
    } catch (error) {
      controller.abort(error);
      if (link !== void 0) await link.close();
      else if (connection !== void 0) void connection.close().catch(() => void 0);
      throw error;
    } finally {
      clearTimeout(timer);
      this.#discoveryFence.signal.removeEventListener("abort", fenceUpgrade);
      if (settled) this.#physicalOpenings.delete(token);
      if (this.#joining.get(peer.identity) === joining) this.#joining.delete(peer.identity);
      finished();
    }
  }
  #links() {
    return this.#owner.links().filter((link) => !link.signal.aborted);
  }
  #observeGeneration() {
    const generation = this.#owner.participant.generation.id;
    if (this.#generation === generation) return;
    this.#generation = generation;
    this.#proposal = null;
    this.#approved = null;
    this.#nextScan = 0;
    this.#nextAdvertisement = 0;
  }
  #healthy() {
    const replica = this.#owner.participant.data?.replica;
    if (replica === void 0) return this.#links().length > 0;
    return replica.ready && (replica.isCoordinator || this.#links().some((link) => link.peerId === replica.generation.payload.coordinator && link.data === "active"));
  }
  #watchLinks() {
    for (const link of this.#links()) {
      if (this.#watchedLinks.has(link)) continue;
      const ended = () => {
        this.#watchedLinks.delete(link);
        this.#ownedLinks.delete(link);
        this.#nextScan = Math.min(this.#nextScan, Date.now() + this.#initialRetry);
        this.#wake();
      };
      this.#watchedLinks.set(link, ended);
      link.signal.addEventListener("abort", ended, { once: true });
      if (link.signal.aborted) ended();
    }
  }
  #backoff(attempt) {
    return Math.max(1, Math.round(Math.min(this.#maximumRetry, this.#initialRetry * 2 ** Math.min(attempt, 20)) * (0.75 + Math.random() * 0.25)));
  }
  #publish(phase) {
    const replica = this.#owner.participant.data?.replica;
    const error = this.#discoveryError ?? this.#error ?? this.#advertisementError ?? (replica !== void 0 && this.#links().some((link) => link.peerId === replica.generation.payload.coordinator && link.data === "unavailable") ? "APPLICATION_DATA_UNAVAILABLE" : null);
    const links = this.#links();
    const key = JSON.stringify(links.map((link) => {
      let id = this.#connectionIds.get(link);
      if (id === void 0) {
        id = ++this.#nextConnectionId;
        this.#connectionIds.set(link, id);
      }
      return [link.peerId, id, this.#transports.get(link) ?? null];
    }).sort((left, right) => String(left[0]).localeCompare(String(right[0]))));
    if (key !== this.#connectionKey) {
      this.#connectionKey = key;
      this.#connectionRevision++;
    }
    const next = {
      connectionRevision: this.#connectionRevision,
      phase: this.signal.aborted ? "closed" : this.#discoveryTerminal ? "unavailable" : !this.#hasDiscoveryReady ? error === null ? "connecting" : "unavailable" : phase ?? (this.#proposal !== null && this.#approved !== this.#proposal.id ? "approval-required" : replica === void 0 ? error !== null ? "unavailable" : this.#links().length > 0 ? "connected" : "connecting" : !replica.ready ? "recovering" : replica.isCoordinator ? "coordinating" : this.#healthy() ? "following" : error !== null ? "unavailable" : "connecting"),
      connectedPeers: this.#links().map((link) => link.peerId).sort(),
      recovery: structuredClone(this.#proposal),
      error
    };
    if (JSON.stringify(next) === JSON.stringify(this.#status)) return;
    this.#status = next;
    for (const listener of [...this.#listeners]) {
      try {
        listener(this.status);
      } catch {
      }
    }
  }
  #wake() {
    this.#wakePending = true;
    this.#wakeWait?.();
  }
  #wait(ms) {
    if (this.#wakePending) {
      this.#wakePending = false;
      return Promise.resolve();
    }
    return new Promise((resolve) => {
      const finish = () => {
        clearTimeout(timer);
        this.signal.removeEventListener("abort", finish);
        this.#wakeWait = void 0;
        this.#wakePending = false;
        resolve();
      };
      const timer = Number.isFinite(ms) ? setTimeout(finish, ms) : void 0;
      this.#wakeWait = finish;
      this.signal.addEventListener("abort", finish, { once: true });
      if (this.signal.aborted) finish();
    });
  }
  async #call(key, call) {
    this.signal.throwIfAborted();
    this.#discoveryFence.signal.throwIfAborted();
    if (this.#calls.has(key)) throw new Error("APPLICATION_PARTICIPATION_BUSY");
    const timeout2 = new AbortController(), timer = setTimeout(() => timeout2.abort(new Error("APPLICATION_PARTICIPATION_TIMEOUT")), this.#timeoutMs);
    const signal = AbortSignal.any([this.signal, this.#discoveryFence.signal, timeout2.signal]);
    const work = this.#delivery(key, () => {
      signal.throwIfAborted();
      return call(signal);
    });
    try {
      return await awaitOwnedTask(signal, () => work);
    } finally {
      clearTimeout(timer);
    }
  }
  #delivery(key, call) {
    this.signal.throwIfAborted();
    this.#discoveryFence.signal.throwIfAborted();
    if (this.#calls.has(key)) throw new Error("APPLICATION_PARTICIPATION_BUSY");
    const work = Promise.resolve().then(() => {
      this.signal.throwIfAborted();
      this.#discoveryFence.signal.throwIfAborted();
      return call();
    });
    this.#calls.set(key, work);
    void work.finally(() => {
      if (this.#calls.get(key) === work) this.#calls.delete(key);
    }).catch(() => void 0);
    return work;
  }
  close() {
    if (this.#closed !== void 0) return this.#closed;
    let resolve, reject;
    this.#closed = new Promise((done, fail) => {
      resolve = done;
      reject = fail;
    });
    const links = [...this.#ownedLinks];
    this.#lifetime.abort(new Error("APPLICATION_PARTICIPATION_CLOSED"));
    this.#unsubscribe();
    this.#wake();
    for (const joining of this.#joining.values()) joining.controller.abort(this.signal.reason);
    for (const [link, dispose] of this.#watchedLinks) link.signal.removeEventListener("abort", dispose);
    this.#watchedLinks.clear();
    this.#publish("closed");
    this.#listeners.clear();
    void (async () => {
      await Promise.allSettled([this.#task, this.#notifications, this.#invitations, this.#upgradeTask, ...links.map((link) => link.close())]);
      await this.#persistence;
      if (this.#discoveryTerminal) return;
      const cleanup = AbortSignal.timeout(Math.min(this.#timeoutMs, 1e3));
      await awaitOwnedTask(cleanup, () => this.#options.discovery.withdraw({ signal: cleanup })).catch(() => void 0);
    })().then(resolve, reject);
    return this.#closed;
  }
};
function delay(ms, signal) {
  return new Promise((resolve) => {
    const finish = () => {
      clearTimeout(timer);
      signal.removeEventListener("abort", finish);
      resolve();
    };
    const timer = setTimeout(finish, ms);
    signal.addEventListener("abort", finish, { once: true });
    if (signal.aborted) finish();
  });
}

// packages/peer-session/src/deferred-stream.ts
function deferredStream(open, options) {
  return { [Symbol.asyncIterator]() {
    const controller = new AbortController(), signal = AbortSignal.any([options.signal, controller.signal]);
    let iterator, opening;
    let closed = false, pulling = false, closing;
    const finish = () => {
      if (closed) return closing ?? Promise.resolve();
      closed = true;
      signal.removeEventListener("abort", aborted);
      controller.abort(new Error("APPLICATION_STREAM_CLOSED"));
      closing = Promise.resolve().then(async () => {
        await iterator?.return?.();
      });
      return closing;
    };
    const aborted = () => {
      void finish().catch(() => void 0);
    };
    signal.addEventListener("abort", aborted, { once: true });
    if (signal.aborted) aborted();
    const acquire = () => opening ??= Promise.resolve().then(async () => {
      signal.throwIfAborted();
      const acquired = (await open(signal))[Symbol.asyncIterator]();
      if (closed) await acquired.return?.();
      else iterator = acquired;
      return acquired;
    });
    return {
      async next() {
        if (closed) {
          if (options.abort === "throw") options.signal.throwIfAborted();
          return { done: true, value: void 0 };
        }
        if (pulling) throw new Error(options.concurrentNextError);
        pulling = true;
        try {
          const acquired = await awaitOwnedTask(signal, acquire);
          const value = await awaitOwnedTask(signal, () => acquired.next());
          if (value.done) await finish();
          return value;
        } catch (error) {
          const cancelled = signal.aborted;
          await finish().catch(() => void 0);
          if (cancelled && (options.abort === "done" || !options.signal.aborted)) return { done: true, value: void 0 };
          throw error;
        } finally {
          pulling = false;
        }
      },
      async return() {
        await finish();
        return { done: true, value: void 0 };
      }
    };
  } };
}

// packages/peer-session/src/session-authority.ts
async function retainApplicationAuthority(device, input) {
  const proposed = await verifyAuthorityBundle(input);
  const bytes = await updateDeviceMetadata(device.store, `peer-session/authority/${proposed.descriptor.applicationId}`, async (current) => {
    if (current === null) return encodePeerValue(proposed.bundle);
    const previous = await verifyAuthorityBundle(decodePeerValue(current), proposed.bundle.descriptor);
    const [older, newer] = previous.bundle.generations.length <= proposed.bundle.generations.length && previous.bundle.controls.length <= proposed.bundle.controls.length ? [previous, proposed] : [proposed, previous];
    assertAuthorityExtension(older, newer);
    return encodePeerValue(newer.bundle);
  });
  return verifyAuthorityBundle(decodePeerValue(bytes), proposed.bundle.descriptor);
}

// packages/peer-session/src/session.ts
var internals = /* @__PURE__ */ new WeakMap();
var ApplicationSession = class {
  capabilities;
  signals;
  content;
  recovery;
  keys;
  operations;
  #options;
  #closing;
  #lifetime = new AbortController();
  #participant;
  #peers = /* @__PURE__ */ new Map();
  #links = /* @__PURE__ */ new Set();
  #projections = /* @__PURE__ */ new Map();
  #listeners = /* @__PURE__ */ new Set();
  #statusListeners = /* @__PURE__ */ new Set();
  #recoveryListeners = /* @__PURE__ */ new Set();
  #authority;
  #authorityTail = Promise.resolve();
  #data;
  #dataTask;
  #initialDataTask;
  #database = "idle";
  #dataDisposers = [];
  #lastStatus = "";
  #closed = false;
  #closeTask;
  #control;
  #participation;
  constructor(options, authority, closing) {
    this.#options = options;
    this.#authority = authority;
    this.#closing = closing;
    this.capabilities = Object.freeze({
      ...PEER_GENERATION_CAPABILITIES,
      sql: options.definition.schema !== void 0 || authority.descriptor.schemaDigest !== null
    });
    const session = this;
    this.#participant = {
      device: options.device.identity,
      storageId: options.device.storageId,
      get descriptor() {
        return session.#authority.descriptor;
      },
      get authority() {
        return session.#authority.bundle;
      },
      get generation() {
        const generation = session.#authority.current;
        if (generation === null) throw new Error("PEER_NO_SELECTED_GENERATION");
        return generation;
      },
      get isCoordinator() {
        return this.generation.payload.coordinator === this.device.publicKey;
      },
      grant(publicKey) {
        return session.#authority.grant(publicKey);
      },
      adoptAuthority: async (input) => {
        await this.#adoptAuthority(input);
      },
      subscribe: (listener) => {
        this.#listeners.add(listener);
        return () => {
          this.#listeners.delete(listener);
        };
      },
      get data() {
        return session.#data?.replica.closed === false ? session.#data : void 0;
      },
      openData: () => this.#openData()
    };
    const signals = new SignalChannel({
      ...options.signals?.limits,
      scope: this.applicationId,
      relay: options.signals?.delivery === "application",
      localEcho: options.signals?.localEcho === true,
      identity: { publicKeyBytes: hexToBytes(this.deviceId), privateKey: options.device.identity.privateKey },
      authorize: ({ scope, authorId }) => scope === this.applicationId && this.#participant.grant(bytesToHex2(authorId))?.reader === true
    });
    this.signals = signals;
    internals.set(this, {
      participant: this.#participant,
      signals,
      signal: this.signal,
      attach: (peerId, submit, link) => this.#attachPeer(peerId, submit, link),
      resume: () => this.resume(),
      observeHead: (peerId, revision, requestedAt) => this.#participation?.observeHead(peerId, revision, requestedAt)
    });
    this.content = Object.freeze({
      stage: async (input) => (await this.#requireData()).content.stage(input),
      resume: async (id) => (await this.#requireData()).content.resume(id),
      read(reference, input = {}) {
        return deferredStream(async (signal) => (await session.#dataFor(signal)).content.read(reference, { ...input, signal }), {
          signal: input.signal === void 0 ? session.signal : AbortSignal.any([session.signal, input.signal]),
          concurrentNextError: "APPLICATION_CONTENT_CONCURRENT_NEXT",
          abort: "throw"
        });
      },
      retain: async (reference, input = {}) => (await this.#dataFor(input.signal)).content.retain(reference, input),
      retained: async (reference) => (await this.#requireData()).content.retained(reference),
      retention: async (reference) => (await this.#requireData()).content.retention(reference),
      observeRetention: async (receipt) => (await this.#requireData()).content.observeRetention(receipt)
    });
    this.keys = Object.freeze({
      missing: async (required) => (await this.#requireData()).keys.missing(required),
      install: async (input) => (await this.#requireData()).keys.install(input),
      ensure: async (required) => (await this.#requireData()).keys.ensure(required),
      request: async (required) => (await this.#requireData()).keys.request(required),
      offer: async (request) => (await this.#requireData()).keys.offer(request),
      validate: async () => (await this.#requireData()).keys.validate()
    });
    this.recovery = Object.freeze({
      inspect: async () => (await this.#requireData()).recovery.inspect(),
      takeover: async (host, input = {}) => (await this.#dataFor(input.signal)).recovery.takeover(host, input),
      handover: async (host, input) => (await this.#dataFor(input.signal)).recovery.handover(host, input)
    });
    this.operations = Object.freeze({
      get: async (id, input = {}) => (await this.#requireData()).operations.get(id, input),
      inspect: async (id, input = {}) => (await this.#requireData()).operations.inspect(id, input),
      wait: (id, input = {}) => this.waitFor(id, input)
    });
  }
  get signal() {
    return this.#lifetime.signal;
  }
  get revision() {
    return this.#data?.replica.ready ? this.#data.replica.revision : null;
  }
  get deviceId() {
    return this.#options.device.identity.publicKey;
  }
  get applicationId() {
    return this.#participant.descriptor.applicationId;
  }
  get historyId() {
    return this.#participant.descriptor.historyId;
  }
  get storageId() {
    return this.#options.device.storageId;
  }
  get participation() {
    return this.#participation;
  }
  get status() {
    const coordinator = this.#participant.generation.payload.coordinator, data = this.#participant.data;
    return {
      phase: this.#closed ? "closed" : data !== void 0 && data.keys.missing().length > 0 ? "awaiting-keys" : data !== void 0 && !data.replica.ready ? "recovering" : this.#participant.isCoordinator || this.#peers.has(coordinator) ? "ready" : "waiting",
      database: this.#database,
      role: this.#participant.isCoordinator ? "coordinator" : "follower",
      generation: this.#participant.generation.id,
      coordinator,
      connectedPeers: this.#peers.size
    };
  }
  describe() {
    return { ...describeApplication(this.#options.definition), capabilities: this.capabilities };
  }
  /** Public signed authority already verified by this owner; no data activation or host request. */
  async authority() {
    this.#assertOpen();
    return structuredClone(this.#participant.authority);
  }
  onStatus(listener) {
    this.#statusListeners.add(listener);
    try {
      listener(this.status);
    } catch {
    }
    return () => {
      this.#statusListeners.delete(listener);
    };
  }
  #changed() {
    for (const listener of this.#listeners) {
      try {
        listener();
      } catch {
      }
    }
    const status = this.status, encoded = JSON.stringify(status);
    if (encoded === this.#lastStatus) return;
    this.#lastStatus = encoded;
    for (const listener of this.#statusListeners) {
      try {
        listener(status);
      } catch {
      }
    }
  }
  #serializeAuthority(run) {
    const result = this.#authorityTail.then(run);
    this.#authorityTail = result.catch(() => void 0);
    return result;
  }
  #adoptAuthority(input) {
    const captured = structuredClone(input);
    return this.#serializeAuthority(async () => {
      this.#assertOpen();
      const next = await verifyAuthorityBundle(captured, this.#participant.authority.descriptor);
      assertAuthorityExtension(await verifyAuthorityBundle(this.#participant.authority), next);
      const retained = await retainApplicationAuthority(this.#options.device, next.bundle);
      this.#assertOpen();
      this.#authority = retained;
      const data = this.#participant.data;
      let recovery = null;
      if (data !== void 0) {
        try {
          recovery = (await data.replica.receiveHistory(retained.bundle, [])).recovery;
        } catch (error) {
          if (!data.replica.closed) throw error;
        }
      }
      this.#changed();
      return recovery;
    });
  }
  #openData() {
    this.#assertDataAvailable();
    if (this.#dataTask !== void 0) return this.#dataTask;
    this.#database = "opening";
    const task = (async () => {
      let data;
      try {
        const { openApplicationData } = await import("./application-data-RML4EC2Y.mjs");
        this.#assertOpen();
        data = await openApplicationData({
          ...this.#options,
          authority: this.#participant.authority,
          session: this,
          adoptAuthority: async (input) => {
            await this.#adoptAuthority(input);
          },
          submit: async (attempt) => {
            await this.#peers.get(this.#participant.generation.payload.coordinator)?.submit(attempt);
          }
        });
        const opened = data;
        await this.#serializeAuthority(async () => {
          this.#assertOpen();
          const retained = await retainApplicationAuthority(this.#options.device, opened.replica.authority);
          await opened.replica.receiveHistory(retained.bundle, []);
          this.#assertOpen();
          this.#authority = retained;
          this.#data = opened;
          this.#dataDisposers = [
            opened.replica.subscribe(() => {
              if (opened.replica.closed && !this.#closed) {
                this.#database = "failed";
                for (const dispose of this.#dataDisposers.splice(0)) dispose();
                void opened.close(new Error("APPLICATION_DATA_UNAVAILABLE")).catch(() => void 0);
              }
              this.#changed();
            }),
            opened.keys.subscribe(() => this.#changed()),
            opened.replica.onRecovery((notice) => {
              for (const listener of this.#recoveryListeners) {
                try {
                  listener(notice);
                } catch {
                }
              }
            })
          ];
          this.#database = "ready";
          this.#changed();
        });
        void opened.resume().catch(() => void 0);
        return opened;
      } catch (error) {
        await data?.close().catch(() => void 0);
        if (!this.#closed) {
          this.#database = "failed";
          this.#changed();
        }
        throw error;
      }
    })();
    this.#dataTask = task;
    this.#changed();
    void task.catch(() => void 0);
    return task;
  }
  /** Existing links join the first public data demand once; inbound activation remains local-only. */
  #requireData() {
    this.#assertDataAvailable();
    this.#initialDataTask ??= Promise.resolve().then(async () => {
      const data = await this.#openData();
      await Promise.allSettled(connectedApplicationPeers(internals.get(this)).map((link) => link.synchronize()));
      this.#assertDataAvailable();
      return data;
    });
    return this.#initialDataTask;
  }
  #dataFor(signal) {
    return awaitOwnedTask(signal === void 0 ? this.signal : AbortSignal.any([this.signal, signal]), () => this.#requireData());
  }
  async command(name, input, options) {
    return (await this.#requireData()).command(name, input, options);
  }
  async reapply(id, name, input, options) {
    return (await this.#requireData()).reapply(id, name, input, options);
  }
  async query(name, input) {
    return (await this.#requireData()).query(name, input);
  }
  async readView() {
    return (await this.#requireData()).readView();
  }
  onRecovery(listener) {
    this.#assertOpen();
    this.#recoveryListeners.add(listener);
    return () => {
      this.#recoveryListeners.delete(listener);
    };
  }
  async inspectRecovery() {
    return (await this.#requireData()).inspectRecovery();
  }
  async recoveryPoint() {
    return (await this.#requireData()).recoveryPoint();
  }
  /** Durable pause covers local and remote coordinator ordering; closing does not release it. */
  async pauseOrdering(operationId) {
    return (await this.#requireData()).replica.pauseOrdering(operationId);
  }
  async orderingPause() {
    return (await this.#requireData()).replica.orderingPause();
  }
  /** Reconcile the original control operation before resuming; a lost reply is not cancellation. */
  async resumeOrdering(operationId) {
    return (await this.#requireData()).replica.resumeOrdering(operationId);
  }
  async adopt(authority) {
    const data = await this.#requireData(), notice = await this.#adoptAuthority(authority);
    this.#assertDataAvailable();
    return await data.adopt(this.#participant.authority) ?? notice;
  }
  changes(options = {}) {
    return deferredStream(async (signal) => (await this.#dataFor(signal)).changes({ signal }), {
      signal: options.signal === void 0 ? this.signal : AbortSignal.any([this.signal, options.signal]),
      concurrentNextError: "APPLICATION_CHANGE_CONCURRENT_NEXT",
      abort: "done"
    });
  }
  project(definition) {
    this.#assertOpen();
    if (this.#projections.has(definition.id)) throw new Error("APPLICATION_PROJECTION_IN_USE");
    if (this.#projections.size >= APPLICATION_PROJECTION_LIMITS.active) throw new Error("APPLICATION_PROJECTION_LIMIT");
    const captured = {
      ...definition,
      initial: structuredClone(definition.initial),
      ...definition.topics === void 0 ? {} : { topics: [...definition.topics] }
    };
    const lifetime = new AbortController(), signal = AbortSignal.any([this.signal, lifetime.signal]);
    let closed = false, actual;
    const acquire = async (input) => {
      if (closed) throw new Error("APPLICATION_PROJECTION_CLOSED");
      const data = await this.#dataFor(input === void 0 ? signal : AbortSignal.any([signal, input]));
      if (closed) throw new Error("APPLICATION_PROJECTION_CLOSED");
      actual ??= data.project(captured);
      return actual;
    };
    const handle = Object.freeze({
      id: captured.id,
      read: async (options = {}) => (await acquire(options.signal)).read(options),
      changes(options = {}) {
        return deferredStream(async (owned) => (await acquire(owned)).changes({ signal: owned }), {
          signal: options.signal === void 0 ? signal : AbortSignal.any([signal, options.signal]),
          concurrentNextError: "APPLICATION_PROJECTION_CONCURRENT_NEXT",
          abort: "done"
        });
      },
      close: async () => {
        if (closed) return;
        closed = true;
        lifetime.abort(new Error("APPLICATION_PROJECTION_CLOSED"));
        this.#projections.delete(captured.id);
        await actual?.close();
      }
    });
    this.#projections.set(captured.id, handle);
    return handle;
  }
  projection(id) {
    this.#assertOpen();
    const handle = this.#projections.get(id);
    if (handle === void 0) throw new Error("APPLICATION_PROJECTION_NOT_FOUND");
    return handle;
  }
  connectPeer(options) {
    this.#assertOpen();
    return connectApplicationPeer(internals.get(this), options);
  }
  participate(options) {
    this.#assertOpen();
    if (this.#participation !== void 0) throw new Error("APPLICATION_PARTICIPATION_ALREADY_STARTED");
    const participation = new OwnedApplicationParticipation({
      participant: this.#participant,
      store: this.#options.device.store,
      signal: this.signal,
      connect: (input) => this.connectPeer(input),
      links: () => connectedApplicationPeers(internals.get(this)),
      resume: () => this.resume()
    }, options);
    this.#participation = participation;
    this.#links.add(participation);
    return participation;
  }
  connectControlParticipant(options) {
    this.#assertOpen();
    if (this.#control !== void 0 && this.#links.has(this.#control)) throw new Error("APPLICATION_CONTROL_ALREADY_ATTACHED");
    const participant = new ApplicationControlParticipant(this.#participant, this.#options.device.store, this.signal, options);
    this.#control = participant;
    this.#links.add(participant);
    participant.signal.addEventListener("abort", () => {
      const released = () => {
        this.#links.delete(participant);
      };
      void participant.close().then(released, released);
    }, { once: true });
    return participant;
  }
  async retry(id) {
    return (await this.#requireData()).retry(id);
  }
  async resume() {
    this.#assertOpen();
    if (this.#participant.data !== void 0) await this.#data?.resume();
  }
  async waitFor(id, options = {}) {
    return (await this.#dataFor(options.signal)).waitFor(id, options);
  }
  async waitForCoverage(applied, options = {}) {
    return (await this.#dataFor(options.signal)).waitForCoverage(applied, options);
  }
  #attachPeer(peerId, submit, link) {
    this.#assertOpen();
    if (this.#participant.grant(peerId)?.reader !== true) throw new Error("APPLICATION_PEER_NOT_AUTHORIZED");
    if (this.#peers.size >= 8 && !this.#peers.has(peerId)) throw new Error("APPLICATION_PEER_LIMIT");
    const previous = this.#peers.get(peerId), endpoint = { submit, link };
    this.#peers.set(peerId, endpoint);
    this.#links.add(link);
    if (previous !== void 0 && previous.link !== link) {
      try {
        void Promise.resolve(previous.link.close()).catch(() => void 0);
      } catch {
      }
    }
    this.#changed();
    return () => {
      if (this.#peers.get(peerId) === endpoint) this.#peers.delete(peerId);
      this.#links.delete(link);
      this.#changed();
    };
  }
  close() {
    if (this.#closeTask !== void 0) return this.#closeTask;
    this.#closeTask = Promise.resolve().then(async () => {
      await Promise.allSettled([...this.#links, ...this.#projections.values()].map((value) => Promise.resolve().then(() => value.close())));
      await this.#dataTask?.catch(() => void 0);
      for (const dispose of this.#dataDisposers.splice(0)) dispose();
      await this.#authorityTail;
      try {
        await this.#data?.close();
      } finally {
        await this.#closing();
      }
    });
    this.#closed = true;
    this.#database = "closed";
    this.#lifetime.abort(new Error("APPLICATION_SESSION_CLOSED"));
    internals.get(this).signals.close();
    this.#changed();
    this.#listeners.clear();
    this.#statusListeners.clear();
    this.#recoveryListeners.clear();
    return this.#closeTask;
  }
  #assertOpen() {
    if (this.#closed) throw new Error("APPLICATION_SESSION_CLOSED");
  }
  #assertDataAvailable() {
    this.#assertOpen();
    if (this.#data?.replica.closed === true) throw new Error("APPLICATION_DATA_UNAVAILABLE");
  }
};
async function connectApplications(left, right) {
  if (left === right) throw new Error("APPLICATION_PEER_SELF");
  return connectApplicationPeerPair(internals.get(left), internals.get(right));
}

// packages/peer-session/src/device.ts
var DEVICE_KEY = "peer-session/device/v1";
var DEVICE_BINDING = "peer-session/device-binding/v1";
var STORAGE_BINDING = "peer-session/storage-binding/v1";
var STORAGE_OPENED = "peer-session/storage-opened/v1";
var claimed = /* @__PURE__ */ new WeakSet();
async function openApplicationDevice(options) {
  let raw = await options.store.get(DEVICE_KEY), binding = await options.store.get(DEVICE_BINDING);
  if (raw === null && binding !== null) raw = await options.store.get(DEVICE_KEY);
  let identity2, storageId;
  if (raw === null) {
    if (binding !== null) throw new Error("APPLICATION_DEVICE_KEYS_MISSING");
    if (options.create !== true) throw new Error("APPLICATION_DEVICE_NOT_FOUND");
    const candidate = await createPeerIdentity(), candidateStorageId = crypto.randomUUID();
    const entries = [
      { key: DEVICE_BINDING, value: encodeCanonicalCbor([candidate.publicKey, candidateStorageId]) },
      { key: DEVICE_KEY, value: encodeCanonicalCbor([
        1n,
        candidate.publicKey,
        await exportEd25519PrivateKey(candidate.privateKey),
        candidateStorageId
      ]) }
    ];
    if (options.store.initialize !== void 0) await options.store.initialize(entries);
    else for (const entry of entries) await options.store.put(entry.key, entry.value);
    raw = await options.store.get(DEVICE_KEY);
    binding = await options.store.get(DEVICE_BINDING);
    if (raw === null) throw new Error(binding === null ? "APPLICATION_DEVICE_NOT_FOUND" : "APPLICATION_DEVICE_KEYS_MISSING");
  }
  {
    const value = assertCanonicalCbor2(raw);
    if (!Array.isArray(value) || value.length !== 4 || value[0] !== 1n || typeof value[1] !== "string" || !/^[0-9a-f]{64}$/u.test(value[1]) || !(value[2] instanceof Uint8Array) || typeof value[3] !== "string" || value[3].length > 128 || value[3].length === 0) throw new Error("APPLICATION_DEVICE_INVALID");
    identity2 = { publicKey: value[1], privateKey: await importEd25519PrivateKey(value[2]) };
    storageId = value[3];
    if (binding === null || !sameBytes(binding, encodeCanonicalCbor([identity2.publicKey, storageId]))) throw new Error("APPLICATION_DEVICE_BINDING_INVALID");
    const proof = new TextEncoder().encode("chronolog/device-resume/v1");
    const signature = await crypto.subtle.sign("Ed25519", identity2.privateKey, proof);
    if (!await crypto.subtle.verify("Ed25519", await importEd25519PublicKey(hexToBytes(identity2.publicKey)), signature, proof)) {
      throw new Error("APPLICATION_DEVICE_KEY_MISMATCH");
    }
  }
  let closed = false, storage;
  let opening, closing;
  return Object.freeze({
    identity: Object.freeze(identity2),
    storageId,
    store: options.store,
    openStorage() {
      if (closed) return Promise.reject(new Error("APPLICATION_DEVICE_CLOSED"));
      return opening ??= Promise.resolve().then(async () => {
        if (closed) throw new Error("APPLICATION_DEVICE_CLOSED");
        const resource = options.openStorage === void 0 ? { store: options.store, close() {
        } } : await options.openStorage();
        let releasing;
        const acquired = Object.freeze({
          store: resource.store,
          close: () => releasing ??= Promise.resolve().then(() => resource.close())
        });
        storage = acquired;
        try {
          if (closed) throw new Error("APPLICATION_DEVICE_CLOSED");
          const expected = encodeCanonicalCbor([identity2.publicKey, storageId]);
          const opened = await options.store.get(STORAGE_OPENED), retained = await acquired.store.get(STORAGE_BINDING);
          if (opened !== null && !sameBytes(opened, expected) || retained !== null && !sameBytes(retained, expected)) {
            throw new Error("APPLICATION_DATA_STORAGE_BINDING_INVALID");
          }
          if (opened !== null && retained === null) throw new Error("APPLICATION_DATA_STORAGE_MISSING");
          if (retained === null) await acquired.store.put(STORAGE_BINDING, expected);
          if (opened === null) await options.store.put(STORAGE_OPENED, expected);
          if (closed) throw new Error("APPLICATION_DEVICE_CLOSED");
          return acquired;
        } catch (error) {
          storage = void 0;
          try {
            await acquired.close();
          } catch {
          }
          throw error;
        }
      });
    },
    close() {
      if (closing !== void 0) return closing;
      closed = true;
      closing = (async () => {
        try {
          await opening?.catch(() => void 0);
          await storage?.close();
        } finally {
          await options.close?.();
        }
      })();
      return closing;
    }
  });
}
function claimApplicationDevice(device) {
  if (claimed.has(device)) throw new Error("APPLICATION_DEVICE_IN_USE");
  claimed.add(device);
  return () => {
    claimed.delete(device);
  };
}
function sameBytes(a, b) {
  return a.length === b.length && a.every((byte, index) => byte === b[index]);
}

// packages/peer-session/src/runtime.ts
async function openPeerApplication(options) {
  const release = claimApplicationDevice(options.device);
  try {
    const requiresSql = options.definition.schema !== void 0 || options.authority.descriptor.payload.schemaDigest !== null;
    if (requiresSql && options.createMaterializer === void 0) throw new Error("APPLICATION_SCHEMA_REQUIRES_SQL");
    if (await applicationDefinitionDigest(options.definition) !== options.authority.descriptor.payload.definitionDigest) throw new Error("APPLICATION_DEFINITION_MISMATCH");
    const authority = await retainApplicationAuthority(options.device, options.authority);
    if (authority.current === null) throw new Error("PEER_NO_SELECTED_GENERATION");
    const captured = { ...options, ...options.epochKeys === void 0 ? {} : {
      epochKeys: new Map([...options.epochKeys].map(([epoch, key]) => [epoch, key.slice()]))
    } };
    return new ApplicationSession(captured, authority, async () => {
      release();
      await options.device.close();
    });
  } catch (error) {
    release();
    await options.device.close();
    throw error;
  }
}

export {
  defineCommand,
  defineQuery,
  defineApplication,
  describeApplication,
  applicationDefinitionDigest,
  ApplicationPublicationError,
  ApplicationControlParticipant,
  ApplicationSession,
  connectApplications,
  openApplicationDevice,
  claimApplicationDevice,
  openPeerApplication
};
