import type { BytesStore } from '../../records/src/index.js';
import type { ReplayProposal } from './types.js';
export interface EventHistoryState {
    readonly order: readonly ReplayProposal[];
    readonly revision: bigint;
    readonly finalLength: number;
    readonly finalRevision: bigint;
}
/** Immutable ordered records plus one small atomic publication pointer. */
export declare class EventHistoryStore {
    #private;
    readonly store: BytesStore;
    readonly key: string;
    readonly digest: Uint8Array;
    readonly quota: number;
    constructor(store: BytesStore, key: string, digest: Uint8Array, quota: number);
    load(): Promise<EventHistoryState | null>;
    commit(state: EventHistoryState, difference: number): Promise<string>;
}
