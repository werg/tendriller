import { type ReleaseRegistry, type ReleaseRegistryOptions } from './release-types.js';
/**
 * A control/content participant with no SQL replica or application decryption key.
 * The store has one exclusive durable owner. Content is immutable, and its adapter
 * must retain published references atomically with acknowledged manifest storage.
 */
export declare function createReleaseRegistry(options: ReleaseRegistryOptions): Promise<ReleaseRegistry>;
