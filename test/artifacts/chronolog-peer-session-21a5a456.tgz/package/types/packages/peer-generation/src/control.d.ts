import type { BytesStore } from '../../records/src/index.js';
import { type ApplicationDescriptor, type AuthorityBundle, type ControlRevision, type HistoryPoint, type OrderReceipt, type PeerGrant, type PeerIdentity, type PrefixProof, type SignedApplicationDescriptor, type SignedControlRevision, type SignedGeneration, type SignedTransitionRequest, type TransitionRequest } from './control-types.js';
export * from './control-types.js';
export * from './definition.js';
export * from './schema.js';
export * from './participant.js';
export * from './publication.js';
export * from './release-types.js';
export * from './release-verify.js';
export * from './release-registry.js';
export { createPeerIdentity, exportPeerIdentity, importPeerIdentity, PeerGenerationError, encodePeerValue, decodePeerValue, peerDigest, bytesDigest } from './codec.js';
/** Monotonic learned authority: a signed older state or a divergent chain cannot replace it. */
export declare function assertAuthorityExtension(previous: PeerAuthority, next: PeerAuthority): void;
export declare function validateHistoryPoint(point: HistoryPoint): void;
export declare function signApplicationDescriptor(payload: ApplicationDescriptor, signer: PeerIdentity): Promise<SignedApplicationDescriptor>;
/** The supported shared-application policy; every granted power remains explicit on the wire. */
export declare function participantGrant(publicKey: string, options?: {
    readonly administrator?: boolean;
    readonly publisher?: boolean;
    readonly dataRole?: 'member' | 'admin' | null;
}): PeerGrant;
/** Explicit control-only host role, enabling account ownership recovery without a creator device. */
export declare function controlParticipantGrant(publicKey: string): PeerGrant;
export declare function signControlRevision(payload: ControlRevision, signer: PeerIdentity): Promise<SignedControlRevision>;
export declare function signTransitionRequest(payload: TransitionRequest, signer: PeerIdentity): Promise<SignedTransitionRequest>;
export declare function generationStartRoot(generation: SignedGeneration): Promise<string>;
export declare function verifyOrderReceipt(receipt: OrderReceipt, generation: SignedGeneration, descriptor: ApplicationDescriptor): Promise<void>;
interface SelectedSegment {
    readonly generation: SignedGeneration;
    readonly cutoff: HistoryPoint | null;
}
/** Constructed only after checking the signed descriptor, control chain and every selection. */
export declare class PeerAuthority {
    #private;
    private constructor();
    get bundle(): AuthorityBundle;
    get descriptor(): ApplicationDescriptor;
    get current(): SignedGeneration | null;
    get control(): SignedControlRevision;
    generation(id: string): SignedGeneration;
    controlAt(revision: number): SignedControlRevision;
    grant(publicKey: string, revision?: number): PeerGrant | null;
    selectedSegments(): readonly SelectedSegment[];
    /** Structural inclusion; a complete replica additionally checks the local retained root. */
    contains(point: HistoryPoint): boolean;
    verifyPrefix(proof: PrefixProof): Promise<void>;
    /** Compare points on the selected history after their roots have been authenticated. */
    atOrAfter(point: HistoryPoint, floor: HistoryPoint): boolean;
    authorizeTransition(request: SignedTransitionRequest, nextControl?: SignedControlRevision): Promise<void>;
    static verify(input: AuthorityBundle, pinned?: SignedApplicationDescriptor): Promise<PeerAuthority>;
}
export declare function verifyAuthorityBundle(bundle: AuthorityBundle, pinned?: SignedApplicationDescriptor): Promise<PeerAuthority>;
export interface GenerationRegistry {
    read(): Promise<AuthorityBundle>;
    select(request: SignedTransitionRequest, options?: {
        readonly control?: SignedControlRevision;
    }): Promise<SignedGeneration>;
}
/** The host owns an exclusive durable store; no command body is accepted by this service. */
export declare function createGenerationRegistry(options: {
    readonly store: BytesStore;
    readonly descriptor: SignedApplicationDescriptor;
    readonly controls: readonly SignedControlRevision[];
    readonly signer: PeerIdentity;
    readonly requireExisting?: boolean;
}): Promise<GenerationRegistry>;
