import type { PeerIdentity } from './control-types.js';
import { type ReleaseActivationRequest, type ReleaseApplicationBinding, type ReleaseAsset, type ReleaseContentSource, type ReleaseManifest, type ReleasePolicy, type ReleasePolicyRequest, type ReleaseState, type ReleaseTrust, type SignedReleaseActivation, type SignedReleaseActivationRequest, type SignedReleaseManifest, type SignedReleasePolicy } from './release-types.js';
export declare function validateReleasePath(value: string): void;
export declare function validateReleaseApplicationBinding(value: ReleaseApplicationBinding): void;
export declare function validateReleaseAsset(value: ReleaseAsset): void;
export declare function validateReleasePolicyRequest(value: ReleasePolicyRequest): void;
export declare function validateReleasePolicy(value: ReleasePolicy): void;
export declare function validateReleaseManifest(value: ReleaseManifest): void;
export declare function validateReleaseActivationRequest(value: ReleaseActivationRequest): void;
export declare function signReleasePolicy(value: ReleasePolicy, signer: PeerIdentity): Promise<SignedReleasePolicy>;
export declare function signReleaseManifest(value: ReleaseManifest, signer: PeerIdentity): Promise<SignedReleaseManifest>;
export declare function signReleaseActivationRequest(value: ReleaseActivationRequest, signer: PeerIdentity): Promise<SignedReleaseActivationRequest>;
export declare function verifyReleasePolicy(value: SignedReleasePolicy, trust: ReleaseTrust): Promise<void>;
export declare function verifyReleaseManifest(value: SignedReleaseManifest, policy: SignedReleasePolicy, trust: ReleaseTrust): Promise<string>;
export declare function verifyReleaseActivationRequest(value: SignedReleaseActivationRequest, policy: SignedReleasePolicy, trust: ReleaseTrust): Promise<void>;
export declare function verifyReleaseActivation(value: SignedReleaseActivation, policy: SignedReleasePolicy, trust: ReleaseTrust): Promise<void>;
/** Verifies the separate monotonic policy and activation histories, never a data generation. */
export declare function verifyReleaseState(input: ReleaseState, trust: ReleaseTrust): Promise<ReleaseState>;
/** A learned publisher revocation or code activation cannot be replaced by an old signed state. */
export declare function assertReleaseStateExtension(previous: ReleaseState, next: ReleaseState): void;
/** Incremental verification limits memory to one source chunk and one hash state. */
export declare function verifyReleaseContent(manifest: SignedReleaseManifest, content: ReleaseContentSource, options?: {
    readonly signal?: AbortSignal;
}): Promise<void>;
/** Verify one stored asset before serving its immutable storage version. No page manifest is invented. */
export declare function verifyReleaseAsset(asset: ReleaseAsset, content: ReleaseContentSource, options?: {
    readonly signal?: AbortSignal;
}): Promise<void>;
