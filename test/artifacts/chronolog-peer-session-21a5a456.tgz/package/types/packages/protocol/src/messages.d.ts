import { type ChangeProgram } from './program.js';
export interface TransactionCore {
    readonly operationId: string;
    readonly groupId: Uint8Array;
    readonly membershipRevision: Uint8Array;
    readonly validationPolicy: Uint8Array;
    readonly authorId: Uint8Array;
    /** Exact writer grant; required by governed groups, unused by static membership. */
    readonly writerCapability?: Uint8Array;
    readonly authorTimestampMs: bigint;
    readonly nonce: Uint8Array;
    readonly executionManifestDigest: Uint8Array;
    readonly program: ChangeProgram;
    readonly metadata?: ReadonlyMap<string, Uint8Array>;
}
export type EnvelopeMessageType = 'candidate' | 'attestation' | 'heartbeat' | 'capability' | 'epoch-manifest' | 'proof-bundle' | 'snapshot';
export interface ChronologEnvelope {
    readonly groupRoute: Uint8Array;
    readonly messageType: EnvelopeMessageType;
    readonly encryptionEpoch: Uint8Array | null;
    /** The (possibly encrypted) signed wire message. */
    readonly payload: Uint8Array;
}
export interface ValidatorAttestation {
    readonly groupId: Uint8Array;
    readonly membershipRevision: Uint8Array;
    readonly validatorCapability: Uint8Array;
    readonly txId: Uint8Array;
    readonly validatorId: Uint8Array;
    readonly authorTimestampMs: bigint;
    readonly acceptedAboveMs: bigint;
    readonly candidateDigest: Uint8Array;
    readonly decision: 'admit';
    readonly policyVersion: bigint;
}
export interface ValidatorHeartbeat {
    readonly groupId: Uint8Array;
    readonly membershipRevision: Uint8Array;
    readonly validatorCapability: Uint8Array;
    readonly validatorId: Uint8Array;
    readonly acceptanceCutoffMs: bigint;
}
/** Application order is independent of transport feeds and receipt positions. */
export interface TransactionOrderKey {
    readonly authorTimestampMs: bigint;
    readonly authorId: Uint8Array;
    readonly txId: Uint8Array;
}
export declare function encodeTransactionCore(value: TransactionCore): Uint8Array;
export declare function decodeTransactionCore(bytes: Uint8Array): TransactionCore;
export declare function transactionDigest(value: TransactionCore | Uint8Array): Promise<Uint8Array>;
export declare function encodeEnvelope(value: ChronologEnvelope): Uint8Array;
export declare function decodeEnvelope(bytes: Uint8Array): ChronologEnvelope;
export declare function encodeValidatorAttestation(value: ValidatorAttestation): Uint8Array;
export declare function decodeValidatorAttestation(bytes: Uint8Array): ValidatorAttestation;
export declare function encodeValidatorHeartbeat(value: ValidatorHeartbeat): Uint8Array;
export declare function decodeValidatorHeartbeat(bytes: Uint8Array): ValidatorHeartbeat;
export declare function transactionOrderKey(core: Pick<TransactionCore, 'authorTimestampMs' | 'authorId'>, txId: Uint8Array): TransactionOrderKey;
export declare function compareTransactionOrder(left: TransactionOrderKey, right: TransactionOrderKey): number;
export declare function assertUniqueOrderKeys(keys: readonly TransactionOrderKey[]): void;
