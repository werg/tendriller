export declare function uint32Bytes(value: number): Uint8Array;
export declare function uint64Bytes(value: bigint): Uint8Array;
export declare function int64Bytes(value: bigint): Uint8Array;
export declare function bytesToUint32(bytes: Uint8Array): number;
export declare function bytesToUint64(bytes: Uint8Array): bigint;
export declare function bytesToInt64(bytes: Uint8Array): bigint;
