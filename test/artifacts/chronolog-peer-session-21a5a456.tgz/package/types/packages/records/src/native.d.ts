import type { BytesStore } from './bytes-store.js';
export interface NativeBytesStoreOptions {
    readonly quotaBytes?: number;
    readonly maxValueBytes?: number;
}
/**
 * One native storage owner for records, authority state, outboxes and local
 * consumer checkpoints. Each durable atomic key replacement shares the
 * same BytesStore contract. SQLite holds the exclusive writer fence until close (also
 * across processes); a process crash releases it without a stale lock file.
 */
export declare class NativeBytesStore implements BytesStore {
    #private;
    constructor(path: string, options?: NativeBytesStoreOptions);
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, value: Uint8Array): Promise<void>;
    usageBytes(): number;
    close(): void;
}
