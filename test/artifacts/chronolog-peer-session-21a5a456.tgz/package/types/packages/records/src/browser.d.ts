import type { BytesStore } from './bytes-store.js';
export interface OpfsWriter {
    write(bytes: ArrayBuffer): Promise<void>;
    close(): Promise<void>;
    abort(): Promise<void>;
}
export interface OpfsFile {
    getFile(): Promise<{
        arrayBuffer(): Promise<ArrayBuffer>;
    }>;
    createWritable(): Promise<OpfsWriter>;
}
export interface OpfsDirectory {
    getFileHandle(name: string, options?: {
        create?: boolean;
    }): Promise<OpfsFile>;
}
/** An atomic OPFS writer; the same envelope and ordering rules as the IDB backend. */
export declare class OpfsBytesStore implements BytesStore {
    #private;
    constructor(directory: OpfsDirectory);
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, input: Uint8Array): Promise<void>;
    close(): Promise<void>;
}
export interface BrowserStorageLock {
    close(): Promise<void>;
}
export interface BrowserStorageOwner {
    readonly directory: FileSystemDirectoryHandle;
    readonly bytes: OpfsBytesStore;
    close(): Promise<void>;
}
/** Hold a single named exclusive Web Lock for selection AND the entire data lifetime. */
export declare function acquireBrowserStorageLock(name: string): Promise<BrowserStorageLock>;
/** Compatible direct OPFS acquisition for existing browser consumers. */
export declare function acquireBrowserStorage(name: string): Promise<BrowserStorageOwner>;
/** A prior app directory, even empty, is evidence of a possible interrupted legacy write. */
export declare function inspectLegacyOpfsDirectory(name: string, providedRoot?: FileSystemDirectoryHandle): Promise<boolean>;
/** An isolated writable-file test: API presence alone is insufficient on Safari. */
export declare function probeOpfsWritable(providedRoot?: FileSystemDirectoryHandle): Promise<boolean>;
