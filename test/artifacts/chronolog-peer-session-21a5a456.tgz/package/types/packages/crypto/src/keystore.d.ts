import { DOMAINS, type ProtocolDomain } from '../../protocol/src/index.js';
export type KeyPurpose = 'signing' | 'hpke-recipient';
export interface StoredKeyDescriptor {
    readonly reference: string;
    readonly purpose: KeyPurpose;
    readonly publicKey: Uint8Array;
}
export interface KeyStore {
    create(reference: string, purpose: KeyPurpose): Promise<StoredKeyDescriptor>;
    import(reference: string, purpose: KeyPurpose, publicKey: Uint8Array, privateKey: CryptoKey): Promise<void>;
    exportPublic(reference: string): Promise<StoredKeyDescriptor>;
    list(): Promise<readonly StoredKeyDescriptor[]>;
    sign(reference: string, domain: ProtocolDomain, payload: Uint8Array): Promise<Uint8Array>;
    hpkeOpen(reference: string, encapsulatedKey: Uint8Array, ciphertext: Uint8Array, info: Uint8Array, aad: Uint8Array): Promise<Uint8Array>;
    delete(reference: string): Promise<void>;
}
export declare class MemoryKeyStore implements KeyStore {
    private readonly entries;
    create(reference: string, purpose: KeyPurpose): Promise<StoredKeyDescriptor>;
    import(reference: string, purpose: KeyPurpose, publicKey: Uint8Array, privateKey: CryptoKey): Promise<void>;
    exportPublic(reference: string): Promise<StoredKeyDescriptor>;
    list(): Promise<readonly StoredKeyDescriptor[]>;
    sign(reference: string, domain: ProtocolDomain, payload: Uint8Array): Promise<Uint8Array>;
    hpkeOpen(reference: string, encapsulatedKey: Uint8Array, ciphertext: Uint8Array, info: Uint8Array, aad: Uint8Array): Promise<Uint8Array>;
    delete(reference: string): Promise<void>;
    private require;
}
export interface ExportedDevelopmentKey {
    readonly purpose: KeyPurpose;
    readonly publicKey: Uint8Array;
    readonly privateKeyPkcs8: Uint8Array;
}
export declare function exportDevelopmentKey(purpose: KeyPurpose, publicKey: Uint8Array, privateKey: CryptoKey): Promise<ExportedDevelopmentKey>;
export { DOMAINS };
