import { HPKE_SUITE } from './hpke.js';
export interface EpochRecipient {
    readonly recipientId: Uint8Array;
    readonly publicKey: Uint8Array;
}
export interface EpochKeyWrap {
    readonly recipientId: Uint8Array;
    readonly recipientPublicKey: Uint8Array;
    readonly encapsulatedKey: Uint8Array;
    readonly ciphertext: Uint8Array;
}
export interface EpochManifest {
    readonly groupId: Uint8Array;
    readonly epoch: bigint;
    /** Governance revision that introduced this epoch; genesis digest for epoch zero. */
    readonly membershipRevision: Uint8Array;
    /** Binds every distribution of this epoch to the same content key. */
    readonly contentKeyDigest: Uint8Array;
    readonly suite: typeof HPKE_SUITE;
    readonly createdAtMs: bigint;
    readonly wraps: readonly EpochKeyWrap[];
}
export interface SignedEpochManifest {
    readonly manifest: EpochManifest;
    readonly signerPublicKey: Uint8Array;
    readonly signature: Uint8Array;
}
export interface CreatedEpoch {
    readonly signedManifest: SignedEpochManifest;
    readonly contentKey: Uint8Array;
}
export interface EncryptedEpochPayload {
    readonly epoch: bigint;
    readonly nonce: Uint8Array;
    readonly ciphertext: Uint8Array;
}
export declare function epochContentKeyDigest(groupId: Uint8Array, epoch: bigint, contentKey: Uint8Array): Promise<Uint8Array>;
export declare function encodeEpochManifest(value: EpochManifest): Uint8Array;
export declare function decodeEpochManifest(bytes: Uint8Array): EpochManifest;
export declare function encodeSignedEpochManifest(value: SignedEpochManifest): Uint8Array;
export declare function decodeSignedEpochManifest(bytes: Uint8Array): SignedEpochManifest;
export declare function createEpochManifest(input: {
    readonly groupId: Uint8Array;
    readonly epoch: bigint;
    readonly membershipRevision: Uint8Array;
    readonly createdAtMs: bigint;
    readonly recipients: readonly EpochRecipient[];
    readonly signerPublicKey: Uint8Array;
    readonly signerPrivateKey: CryptoKey;
    readonly contentKey?: Uint8Array;
}): Promise<CreatedEpoch>;
export declare function verifyEpochManifest(value: SignedEpochManifest, trustedSigner: Uint8Array): Promise<boolean>;
export declare function unwrapEpochKey(input: {
    readonly signedManifest: SignedEpochManifest;
    readonly trustedSigner: Uint8Array;
    readonly recipientId: Uint8Array;
    readonly recipientPrivateKey: CryptoKey;
}): Promise<Uint8Array>;
export declare function encryptEpochPayload(contentKey: Uint8Array, epoch: bigint, plaintext: Uint8Array, associatedData: Uint8Array): Promise<EncryptedEpochPayload>;
export declare function decryptEpochPayload(contentKey: Uint8Array, payload: EncryptedEpochPayload, associatedData: Uint8Array): Promise<Uint8Array>;
