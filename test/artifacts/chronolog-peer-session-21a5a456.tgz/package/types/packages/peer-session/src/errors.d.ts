import type { OperationState, PeerRevision } from '../../peer-generation/src/index.js';
export declare class AbandonedOperationError extends Error {
    readonly operation: Extract<OperationState, {
        status: 'abandoned' | 'needsReapply';
    }>;
    constructor(operation: Extract<OperationState, {
        status: 'abandoned' | 'needsReapply';
    }>);
}
export declare class RecoveredViewError extends Error {
    readonly revision: PeerRevision;
    constructor(revision: PeerRevision);
}
/** The portable control-port conflict; adapters may preserve an equivalent typed error. */
export declare class ApplicationControlConflictError extends Error {
    readonly code: "peer_generation_conflict";
    constructor(message?: string, options?: ErrorOptions);
}
