import { type ApplicationDevice } from './device.js';
export { openPeerApplication as openNativeApplication } from './runtime.js';
export type { OpenPeerApplicationOptions } from './runtime.js';
export { NativeBytesStore } from '../../records/src/native.js';
/** The SQLite file is the exclusive signer/history owner; a second process receives a busy error. */
export declare function openNativeDevice(options: {
    readonly path: string;
    readonly create?: true;
    readonly quotaBytes?: number;
    readonly maxValueBytes?: number;
}): Promise<ApplicationDevice>;
