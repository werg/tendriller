import type { OperationState, RecoveryNotice } from '../../peer-generation/src/index.js';
import type { ApplicationEventOptions, ApplicationSession, QueryParameter } from './session.js';
import type { WorkerApplicationSession } from './worker-application.js';
export interface PeerApplicationProgram {
    readonly name: string;
    readonly input: unknown;
}
interface SubmitOptions {
    readonly operationId: string;
    readonly basedOn?: string;
}
interface ViewOptions {
    readonly view?: 'applied';
}
interface EventOptions extends ApplicationEventOptions {
    readonly signal?: AbortSignal;
}
/**
 * Tendriller's applied backend shape, using the owned public session directly.
 * Domain event publication is opt-in through an ordinary declared command.
 */
export declare function createApplicationBackend(options: {
    readonly id: string;
    readonly session: ApplicationSession | WorkerApplicationSession;
    readonly eventCommand?: string;
}): Readonly<{
    id: string;
    capabilities: readonly string[];
    readonly status: import("./session-types.js").SessionStatus;
    readonly endpoint: import("./owner-types.js").ApplicationEndpointBinding | undefined;
    onStatus: ((listener: (status: import("./session-types.js").SessionStatus) => void) => () => void) | ((listener: (status: import("./session-types.js").SessionStatus) => void) => () => void);
    submit: (program: PeerApplicationProgram, input: SubmitOptions) => Promise<OperationState>;
    changes(input?: ViewOptions & {
        readonly signal?: AbortSignal;
    }): {
        [Symbol.asyncIterator](): AsyncGenerator<{
            recovery?: {
                revision: string;
                previousGeneration: string;
                generation: string;
                adopted: import("../../peer-generation/src/index.js").HistoryPoint | null;
                abandoned: readonly OperationState[];
                unknownLoss: boolean;
            };
            view: "applied";
            revision: string;
            generation: string;
            kind: "update" | "recovery";
        }, void, unknown>;
    };
    readView(input?: ViewOptions): Promise<Readonly<{
        view: "applied";
        revision: string;
        generation: string;
        query(sql: string, parameters?: readonly QueryParameter[]): Promise<import("./session-types.js").QueryRows>;
        readEvents(input?: EventOptions): Promise<{
            transactions: {
                proposalId: string;
                events: Array<{
                    id: string;
                    proposalId: string;
                    eventOrdinal: number;
                    topic: string;
                    payload: unknown;
                    origin: {
                        kind: string;
                        authorId: string;
                        operationId: string;
                    };
                }>;
            }[];
            scannedThrough: string;
            hasMore: boolean;
            revision: string;
        }>;
        release: () => Promise<void>;
    }>>;
    onRecovery: (listener: (notice: ReturnType<typeof recoveryNotice>) => void) => () => void;
    inspectRecovery: () => Promise<{
        revision: string;
        previousGeneration: string;
        generation: string;
        adopted: import("../../peer-generation/src/index.js").HistoryPoint | null;
        abandoned: readonly OperationState[];
        unknownLoss: boolean;
    }[]>;
    operations: Readonly<{
        get: (id: string) => Promise<OperationState | null>;
        subscribe(input: {
            readonly operationId: string;
            readonly signal?: AbortSignal;
        }): {
            [Symbol.asyncIterator](): AsyncGenerator<OperationState, void, unknown>;
        };
    }>;
    events: Readonly<{
        publish(topic: string, payload: unknown, input: SubmitOptions): Promise<OperationState>;
        read: (input?: EventOptions) => Promise<{
            transactions: {
                proposalId: string;
                events: Array<{
                    id: string;
                    proposalId: string;
                    eventOrdinal: number;
                    topic: string;
                    payload: unknown;
                    origin: {
                        kind: string;
                        authorId: string;
                        operationId: string;
                    };
                }>;
            }[];
            scannedThrough: string;
            hasMore: boolean;
            revision: string;
        }>;
        subscribe(input?: EventOptions): {
            [Symbol.asyncIterator](): AsyncGenerator<{
                transactions: {
                    proposalId: string;
                    events: Array<{
                        id: string;
                        proposalId: string;
                        eventOrdinal: number;
                        topic: string;
                        payload: unknown;
                        origin: {
                            kind: string;
                            authorId: string;
                            operationId: string;
                        };
                    }>;
                }[];
                scannedThrough: string;
                hasMore: boolean;
                revision: string;
            }, void, unknown>;
        };
    }>;
}>;
declare function recoveryNotice(notice: RecoveryNotice): {
    revision: string;
    previousGeneration: string;
    generation: string;
    adopted: import("../../peer-generation/src/index.js").HistoryPoint | null;
    abandoned: readonly OperationState[];
    unknownLoss: boolean;
};
export {};
