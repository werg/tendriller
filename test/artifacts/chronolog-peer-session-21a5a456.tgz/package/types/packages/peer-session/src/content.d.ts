import type { BytesStore } from '../../records/src/index.js';
import { type PeerReplica, type Signed } from '../../peer-generation/src/index.js';
export declare const CONTENT_CHUNK_BYTES = 65536;
declare const CONTENT_PROFILE: "peer-content-v1";
/** A reference identifies encrypted content; possession never grants read access. */
export interface ContentReference {
    readonly profile: typeof CONTENT_PROFILE;
    readonly applicationId: string;
    readonly historyId: string;
    readonly id: string;
    readonly epoch: number;
    readonly bytes: number;
    readonly mediaType: string;
}
export interface ContentManifest {
    readonly profile: typeof CONTENT_PROFILE;
    readonly applicationId: string;
    readonly historyId: string;
    readonly stageId: string;
    readonly epoch: number;
    readonly bytes: number;
    readonly mediaType: string;
    readonly chunks: readonly ContentChunk[];
}
interface ContentChunk {
    readonly hash: string;
    readonly nonce: string;
    readonly bytes: number;
}
export type ContentRetention = Signed<{
    readonly reference: ContentReference;
    readonly peer: string;
    readonly storageId: string;
    readonly generation: string;
    readonly controlRevision: number;
    readonly retainedAt: number;
}>;
/** Providers carry encrypted bounded chunks. Hosted providers are an explicit attachment. */
export interface ContentSource {
    manifest(reference: ContentReference): Promise<ContentManifest | null>;
    chunk(reference: ContentReference, index: number): Promise<Uint8Array | null>;
    retained?(reference: ContentReference): Promise<ContentRetention>;
    observeRetention?(receipt: ContentRetention): Promise<void>;
}
export interface ContentUpload {
    readonly id: string;
    /** Exact repeated writes are safe; an index cannot be replaced with different bytes. */
    write(index: number, bytes: Uint8Array): Promise<void>;
    progress(): Promise<{
        readonly bytes: number;
        readonly storedBytes: number;
        readonly missingChunks: readonly number[];
    }>;
    commit(): Promise<ContentReference>;
}
/**
 * The session's content owner. Staging and downloads use the same durable store,
 * independently of command delivery. Chunks are encrypted before persistence;
 * partial fetches resume from locally verified chunks, with one chunk in memory.
 */
export declare class ApplicationContent {
    #private;
    constructor(options: {
        readonly replica: PeerReplica;
        readonly store: BytesStore;
        readonly storageId: string;
        readonly epochKeys: ReadonlyMap<number, Uint8Array>;
        readonly acquireKey?: (epoch: number) => Promise<void>;
    });
    stage(options: {
        readonly bytes: number;
        readonly mediaType?: string;
    }): Promise<ContentUpload>;
    resume(id: string): Promise<ContentUpload>;
    attachSource(peerId: string, source: ContentSource): () => void;
    read(reference: ContentReference, options?: {
        readonly offset?: number;
        readonly length?: number;
        readonly signal?: AbortSignal;
    }): AsyncIterable<Uint8Array>;
    /** Called only after the connection authenticated requester; rechecks current controls. */
    serveManifest(requester: string, reference: ContentReference): Promise<ContentManifest | null>;
    serveChunk(requester: string, reference: ContentReference, index: number): Promise<Uint8Array | null>;
    retained(reference: ContentReference): Promise<ContentRetention>;
    /** Fetch a complete independent copy, then attempt to announce its durable retention. */
    retain(reference: ContentReference, options?: {
        readonly signal?: AbortSignal;
    }): Promise<ContentRetention>;
    observeRetention(receipt: ContentRetention): Promise<void>;
    /** Past durable-copy observations, never a claim that a provider is reachable now. */
    retention(reference: ContentReference): Promise<readonly ContentRetention[]>;
    close(): void;
}
export {};
