import type { AppliedResult, OperationState, SignedRetainedCoverage } from '../../peer-generation/src/index.js';
import type { ApplicationSession } from './session.js';
/** A saved immutable attempt. Cancelling a waiter never cancels its command. */
export declare class ApplicationOperation {
    readonly session: ApplicationSession;
    readonly operationId: string;
    constructor(session: ApplicationSession, operationId: string);
    get(): Promise<OperationState | null>;
    applied(options?: {
        readonly signal?: AbortSignal;
    }): Promise<AppliedResult>;
    retry(): Promise<void>;
    shared(options?: {
        readonly signal?: AbortSignal;
    }): Promise<readonly SignedRetainedCoverage[]>;
}
