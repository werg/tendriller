import type { ApplicationControlHost } from './recovery.js';
import type { ApplicationSession } from './session.js';
export interface ApplicationTool {
    readonly name: string;
    readonly description: string;
    readonly inputSchema: Readonly<Record<string, unknown>>;
}
/** Local agent tools execute against the same owned session, identity and journal as the UI. */
export declare function createApplicationTools(session: ApplicationSession, options?: {
    readonly host?: ApplicationControlHost;
}): {
    list(): readonly ApplicationTool[];
    call(name: string, input: unknown, callOptions?: {
        readonly signal?: AbortSignal;
    }): Promise<unknown>;
};
/** JSON-lines/CLI formatting preserves exact SQL integers and binary values explicitly. */
export declare function formatApplicationToolResult(value: unknown): string;
/** Per-request deadlines bound tool waits; input/output waits end with the owned lifetime. */
export declare function serveApplicationToolLines(session: ApplicationSession, options: {
    readonly input: AsyncIterable<string>;
    readonly write: (line: string) => void | Promise<void>;
    readonly host?: ApplicationControlHost;
    readonly signal?: AbortSignal;
}): Promise<void>;
