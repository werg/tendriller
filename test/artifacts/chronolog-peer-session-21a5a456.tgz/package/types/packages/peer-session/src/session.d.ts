import { PEER_GENERATION_CAPABILITIES, type AuthorityBundle, type PeerAuthority } from '../../peer-generation/src/control.js';
import type { PeerRevision, AppliedResult, OperationState, RecoveryNotice, SignedAttempt, SignedRetainedCoverage, PeerOrderingPause, PrefixProof } from '../../peer-generation/src/index.js';
import { type EventPayload } from '../../protocol/src/index.js';
import { type Signals } from '../../signals/src/index.js';
import { type ApplicationCommand, type ApplicationDefinition, type ApplicationQuery } from './definition.js';
import type { OpenPeerApplicationOptions } from './runtime.js';
import type { ApplicationContent } from './content.js';
import type { ApplicationKeyring } from './keys.js';
import type { ApplicationRecovery } from './recovery.js';
import { type ApplicationProjectionDefinition, type ApplicationProjectionHandle } from './projection-types.js';
import { ApplicationControlParticipant, type ControlParticipantOptions } from './control-participant.js';
import type { ApplicationParticipation, ApplicationParticipationOptions } from './participation-types.js';
import { type ApplicationPeerConnectOptions, type ApplicationPeerLink } from './network.js';
import type { ApplicationChange, ApplicationReadView, CommandOptions, SessionStatus } from './session-types.js';
import type { ApplicationOperation } from './operation.js';
export * from './session-types.js';
export * from './errors.js';
export { ApplicationOperation } from './operation.js';
type CommandArguments<T> = T extends ApplicationCommand<infer I> ? I : never;
type QueryArguments<T> = T extends ApplicationQuery<infer I, unknown, never> ? I : never;
type QueryResult<T> = T extends ApplicationQuery<never, infer R, never> ? Awaited<R> : never;
export type ApplicationContentAccess = Pick<ApplicationContent, 'stage' | 'resume' | 'read' | 'retain' | 'retained' | 'retention' | 'observeRetention'>;
export type ApplicationRecoveryAccess = Pick<ApplicationRecovery, 'inspect' | 'takeover' | 'handover'>;
export type ApplicationKeyAccess = Pick<ApplicationKeyring, 'install' | 'ensure' | 'request' | 'offer' | 'validate'> & {
    missing(requiredEpochs?: readonly number[]): Promise<readonly number[]>;
};
/** One protocol owner, with a single durable facet loaded by actual data demand. */
export declare class ApplicationSession<D extends ApplicationDefinition = ApplicationDefinition> {
    #private;
    readonly capabilities: typeof PEER_GENERATION_CAPABILITIES & {
        readonly sql: boolean;
    };
    readonly signals: Signals;
    readonly content: ApplicationContentAccess;
    readonly recovery: ApplicationRecoveryAccess;
    readonly keys: ApplicationKeyAccess;
    readonly operations: {
        get(operationId: string, options?: {
            readonly author?: string;
        }): Promise<OperationState | null>;
        inspect(operationId: string, options?: {
            readonly author?: string;
        }): Promise<{
            readonly state: OperationState;
            readonly attempt: SignedAttempt;
        } | null>;
        wait(operationId: string, options?: {
            readonly author?: string;
            readonly signal?: AbortSignal;
        }): Promise<AppliedResult>;
    };
    constructor(options: OpenPeerApplicationOptions<D>, authority: PeerAuthority, closing: () => Promise<void>);
    get signal(): AbortSignal;
    get revision(): PeerRevision | null;
    get deviceId(): string;
    get applicationId(): string;
    get historyId(): string;
    get storageId(): string;
    get participation(): ApplicationParticipation | undefined;
    get status(): SessionStatus;
    describe(): {
        capabilities: Readonly<{
            readonly ordering: "generation-sequence";
            readonly applied: true;
            readonly shared: true;
            readonly finality: false;
            readonly automaticExternalEffects: false;
            readonly recovery: "selected-prefix";
        }> & {
            readonly sql: boolean;
        };
        id: string;
        version: string;
        schema: string | null;
        commands: readonly import("../../peer-generation/src/index.js").ApplicationEntryDescription[];
        queries: readonly import("../../peer-generation/src/index.js").ApplicationEntryDescription[];
    };
    /** Public signed authority already verified by this owner; no data activation or host request. */
    authority(): Promise<AuthorityBundle>;
    onStatus(listener: (status: SessionStatus) => void): () => void;
    command<Name extends keyof D['commands'] & string>(name: Name, input: CommandArguments<D['commands'][Name]>, options: CommandOptions): Promise<ApplicationOperation>;
    reapply<Name extends keyof D['commands'] & string>(id: string, name: Name, input: CommandArguments<D['commands'][Name]>, options: CommandOptions & {
        readonly originalAuthor?: string;
    }): Promise<ApplicationOperation>;
    query<Name extends keyof D['queries'] & string>(name: Name, input: QueryArguments<D['queries'][Name]>): Promise<{
        readonly revision: PeerRevision;
        readonly value: QueryResult<D['queries'][Name]>;
    }>;
    readView(): Promise<ApplicationReadView>;
    onRecovery(listener: (notice: RecoveryNotice) => void): () => void;
    inspectRecovery(): Promise<readonly RecoveryNotice[]>;
    recoveryPoint(): Promise<PrefixProof>;
    /** Durable pause covers local and remote coordinator ordering; closing does not release it. */
    pauseOrdering(operationId: string): Promise<PeerOrderingPause>;
    orderingPause(): Promise<PeerOrderingPause | null>;
    /** Reconcile the original control operation before resuming; a lost reply is not cancellation. */
    resumeOrdering(operationId: string): Promise<void>;
    adopt(authority: AuthorityBundle): Promise<RecoveryNotice | null>;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
    project<State extends EventPayload>(definition: ApplicationProjectionDefinition<State>): ApplicationProjectionHandle<State>;
    projection<State extends EventPayload = EventPayload>(id: string): ApplicationProjectionHandle<State>;
    connectPeer(options: ApplicationPeerConnectOptions): Promise<ApplicationPeerLink>;
    participate(options: ApplicationParticipationOptions): ApplicationParticipation;
    connectControlParticipant(options: ControlParticipantOptions): ApplicationControlParticipant;
    retry(id: string): Promise<void>;
    resume(): Promise<void>;
    waitFor(id: string, options?: {
        readonly author?: string;
        readonly signal?: AbortSignal;
    }): Promise<AppliedResult>;
    waitForCoverage(applied: AppliedResult, options?: {
        readonly signal?: AbortSignal;
    }): Promise<readonly SignedRetainedCoverage[]>;
    close(): Promise<void>;
}
/** In-process transport uses the same participant and durable-facet protocol. */
export declare function connectApplications(left: ApplicationSession, right: ApplicationSession): Promise<{
    synchronize(): Promise<void>;
    close(): Promise<void>;
}>;
