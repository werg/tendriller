import {
  canonicalEventPayload,
  canonicalJson,
  decodeChangeProgram,
  exportEd25519PrivateKey,
  generateEd25519KeyPair,
  importEd25519PrivateKey,
  signDomain,
  verifyDomain
} from "./chunk-Q44B5CP6.mjs";
import {
  bytesToHex,
  hexToBytes,
  sha256
} from "./chunk-DACCYORU.mjs";

// packages/peer-generation/src/codec.ts
var PeerGenerationError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "PeerGenerationError";
  }
  code;
};
function check(condition, code) {
  if (!condition) throw new PeerGenerationError(code);
}
function object(value, keys) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null), "PEER_RECORD_INVALID");
  const record = value;
  check(Object.keys(record).length === keys.length && keys.every((key) => Object.hasOwn(record, key)), "PEER_RECORD_FIELDS_INVALID");
  return record;
}
function boundedText(value, max = 512) {
  check(typeof value === "string" && value.length > 0 && value.length <= max && [...value].every((character) => character.charCodeAt(0) >= 32 && character.charCodeAt(0) !== 127), "PEER_TEXT_INVALID");
}
function hex(value, bytes = 32) {
  check(typeof value === "string" && value.length === bytes * 2 && /^[0-9a-f]+$/u.test(value), "PEER_HEX_INVALID");
}
function uint(value, maximum = Number.MAX_SAFE_INTEGER) {
  check(Number.isSafeInteger(value) && value >= 0 && value <= maximum, "PEER_INTEGER_INVALID");
}
function canonical(value, depth) {
  check(depth <= 24, "PEER_RECORD_TOO_DEEP");
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") {
    check(Number.isSafeInteger(value), "PEER_INTEGER_INVALID");
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map((item) => canonical(item, depth + 1)).join(",")}]`;
  check(typeof value === "object" && value !== null && Object.getPrototypeOf(value) === Object.prototype, "PEER_RECORD_INVALID");
  const record = value;
  return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonical(record[key], depth + 1)}`).join(",")}}`;
}
function encodePeerValue(value) {
  const bytes = new TextEncoder().encode(canonical(value, 0));
  check(bytes.length <= 32 * 1024 * 1024, "PEER_RECORD_TOO_LARGE");
  return bytes;
}
function decodePeerValue(bytes) {
  check(bytes.length <= 32 * 1024 * 1024, "PEER_RECORD_TOO_LARGE");
  const value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  check(bytesToHex(encodePeerValue(value)) === bytesToHex(bytes), "PEER_RECORD_NOT_CANONICAL");
  return value;
}
function samePeerValue(left, right) {
  return canonical(left, 0) === canonical(right, 0);
}
async function peerDigest(value) {
  return bytesToHex(await sha256(encodePeerValue(value)));
}
async function bytesDigest(value) {
  return bytesToHex(await sha256(value));
}
async function signPeerValue(domain, payload, identity) {
  const captured = structuredClone(payload);
  return { payload: captured, signature: bytesToHex(await signDomain(domain, encodePeerValue(captured), identity.privateKey)) };
}
async function verifyPeerValue(domain, value, publicKey) {
  object(value, ["payload", "signature"]);
  hex(value.signature, 64);
  hex(publicKey);
  check(await verifyDomain(domain, encodePeerValue(value.payload), hexToBytes(value.signature), hexToBytes(publicKey)), "PEER_SIGNATURE_INVALID");
}
async function createPeerIdentity() {
  const pair = await generateEd25519KeyPair();
  return { publicKey: bytesToHex(pair.publicKeyBytes), privateKey: pair.privateKey };
}
async function exportPeerIdentity(identity) {
  return { publicKey: identity.publicKey, privateKey: bytesToHex(await exportEd25519PrivateKey(identity.privateKey)) };
}
async function importPeerIdentity(value) {
  object(value, ["publicKey", "privateKey"]);
  hex(value.publicKey);
  check(typeof value.privateKey === "string" && /^[0-9a-f]{96,512}$/u.test(value.privateKey), "PEER_PRIVATE_KEY_INVALID");
  const identity = { publicKey: value.publicKey, privateKey: await importEd25519PrivateKey(hexToBytes(value.privateKey)) };
  const test = new TextEncoder().encode("chronolog/peer-identity/check");
  const signature = await signDomain("chronolog/peer-generation/descriptor/v1", test, identity.privateKey);
  check(await verifyDomain("chronolog/peer-generation/descriptor/v1", test, signature, hexToBytes(identity.publicKey)), "PEER_IDENTITY_KEY_MISMATCH");
  return identity;
}
var Serial = class {
  #tail = Promise.resolve();
  async run(task) {
    const prior = this.#tail;
    let release;
    this.#tail = new Promise((resolve) => {
      release = resolve;
    });
    await prior;
    try {
      return await task();
    } finally {
      release();
    }
  }
};
function isArray(value) {
  return Array.isArray(value);
}

// packages/peer-generation/src/control-types.ts
var PEER_GENERATION_PROFILE = "peer-generation-v1";
var PEER_GENERATION_POLICY = "eligible-members-v1";
var PEER_MAX_RECORDS = 4096;
var PEER_MAX_HISTORY_BYTES = 64 * 1024 * 1024;
var PEER_GENERATION_CAPABILITIES = Object.freeze({
  ordering: "generation-sequence",
  applied: true,
  shared: true,
  finality: false,
  automaticExternalEffects: false,
  recovery: "selected-prefix"
});

// packages/peer-generation/src/definition.ts
function parseApplicationInput(schema, value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  const visit = (spec, item, path) => {
    const invalid = () => {
      throw new Error(`APPLICATION_INPUT_INVALID:${path}`);
    };
    if ("anyOf" in spec) {
      for (const option of spec.anyOf) {
        try {
          visit(option, item, path);
          return;
        } catch {
        }
      }
      invalid();
    } else if (spec.type === "null") {
      if (item !== null) invalid();
    } else if (spec.type === "boolean") {
      if (typeof item !== "boolean") invalid();
    } else if (spec.type === "string") {
      if (typeof item !== "string") return invalid();
      const length = [...item].length;
      if (length < (spec.minLength ?? 0) || length > (spec.maxLength ?? 16384) || spec.enum !== void 0 && !spec.enum.includes(item)) invalid();
    } else if (spec.type === "number" || spec.type === "integer") {
      if (typeof item !== "number" || spec.type === "integer" && !Number.isSafeInteger(item) || item < (spec.minimum ?? -Infinity) || item > (spec.maximum ?? Infinity)) invalid();
    } else if (spec.type === "array") {
      if (!Array.isArray(item) || item.length < (spec.minItems ?? 0) || item.length > (spec.maxItems ?? 4096)) return invalid();
      const items = item;
      items.forEach((child, index) => visit(spec.items, child, `${path}[${index}]`));
    } else if (spec.type === "object") {
      if (item === null || typeof item !== "object" || Array.isArray(item)) return invalid();
      const object2 = item;
      for (const name of spec.required ?? []) if (!Object.hasOwn(object2, name)) invalid();
      for (const [name, child] of Object.entries(object2)) {
        if (!Object.hasOwn(spec.properties, name)) invalid();
        visit(spec.properties[name], child, `${path}.${name}`);
      }
    }
  };
  visit(schema, copy, "$");
  return freeze(copy);
}
function checkedApplicationInputSchema(value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  let nodes = 0;
  const visit = (schema, depth) => {
    if (++nodes > 256 || depth > 16 || schema === null || typeof schema !== "object" || Array.isArray(schema)) throw new Error("APPLICATION_SCHEMA_INVALID");
    const keys = /* @__PURE__ */ new Set(["description"]);
    const allow = (...names) => {
      for (const name of names) keys.add(name);
    };
    const bound = (value2, max) => {
      if (value2 !== void 0 && (!Number.isSafeInteger(value2) || value2 < 0 || value2 > max)) throw new Error("APPLICATION_SCHEMA_INVALID");
    };
    if (schema.description !== void 0 && typeof schema.description !== "string") throw new Error("APPLICATION_SCHEMA_INVALID");
    if ("anyOf" in schema) {
      allow("anyOf");
      if (!Array.isArray(schema.anyOf) || schema.anyOf.length < 1 || schema.anyOf.length > 16) throw new Error("APPLICATION_SCHEMA_INVALID");
      const alternatives = schema.anyOf;
      alternatives.forEach((option) => visit(option, depth + 1));
    } else {
      allow("type");
      switch (schema.type) {
        case "string":
          allow("minLength", "maxLength", "enum");
          bound(schema.minLength, 16384);
          bound(schema.maxLength, 16384);
          if ((schema.minLength ?? 0) > (schema.maxLength ?? 16384) || schema.enum !== void 0 && (!Array.isArray(schema.enum) || schema.enum.length === 0 || schema.enum.length > 256 || schema.enum.some((item) => typeof item !== "string"))) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "number":
        case "integer":
          allow("minimum", "maximum");
          if ([schema.minimum, schema.maximum].some((value2) => value2 !== void 0 && !Number.isFinite(value2)) || (schema.minimum ?? -Infinity) > (schema.maximum ?? Infinity)) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "boolean":
        case "null":
          break;
        case "array":
          allow("items", "minItems", "maxItems");
          bound(schema.minItems, 4096);
          bound(schema.maxItems, 4096);
          if ((schema.minItems ?? 0) > (schema.maxItems ?? 4096)) throw new Error("APPLICATION_SCHEMA_INVALID");
          visit(schema.items, depth + 1);
          break;
        case "object":
          allow("properties", "required", "additionalProperties");
          if (schema.properties === null || typeof schema.properties !== "object" || Array.isArray(schema.properties) || schema.additionalProperties !== void 0 && schema.additionalProperties !== false) throw new Error("APPLICATION_SCHEMA_INVALID");
          for (const child of Object.values(schema.properties)) visit(child, depth + 1);
          if (schema.required !== void 0 && (!Array.isArray(schema.required) || schema.required.some((name) => typeof name !== "string" || !Object.hasOwn(schema.properties, name)) || new Set(schema.required).size !== schema.required.length)) {
            throw new Error("APPLICATION_SCHEMA_INVALID");
          }
          Object.assign(schema, { additionalProperties: false });
          break;
        default:
          throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
      }
    }
    if (Object.keys(schema).some((key) => !keys.has(key))) throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
  };
  visit(copy, 0);
  return freeze(copy);
}
function freeze(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
function validateApplicationDescription(value) {
  const bytes = descriptionJson(value);
  check(new TextEncoder().encode(bytes).length <= 262144, "APPLICATION_DESCRIPTION_TOO_LARGE");
  const copy = JSON.parse(bytes);
  object(copy, ["id", "version", "schema", "commands", "queries"]);
  for (const text of [copy.id, copy.version]) check(typeof text === "string" && /^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(text), "APPLICATION_DEFINITION_ID_INVALID");
  if (copy.schema !== null) {
    check(typeof copy.schema === "string" && /^(?:[0-9a-f]{2})+$/u.test(copy.schema), "APPLICATION_SCHEMA_PROGRAM_INVALID");
    decodeChangeProgram(hexToBytes(copy.schema));
  }
  for (const entries of [copy.commands, copy.queries]) {
    check(isArray(entries) && entries.length <= 128, "APPLICATION_DEFINITION_TOO_LARGE");
    let previous = "";
    for (const entry of entries) {
      object(entry, ["name", "description", "input"]);
      check(typeof entry.name === "string" && /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(entry.name) && !["__proto__", "constructor", "prototype"].includes(entry.name) && entry.name > previous, "APPLICATION_DEFINITION_NAME_INVALID");
      previous = entry.name;
      check(typeof entry.description === "string" && entry.description.length <= 4096, "APPLICATION_DESCRIPTION_INVALID");
      const checked = checkedApplicationInputSchema(entry.input);
      check(canonicalEventPayload(entry.input) === canonicalEventPayload(checked), "APPLICATION_SCHEMA_NOT_CANONICAL");
    }
  }
  return freeze(copy);
}
async function applicationDescriptionDigest(value) {
  const description = validateApplicationDescription(value);
  return bytesDigest(new TextEncoder().encode(descriptionJson(description)));
}
function descriptionJson(value) {
  return canonicalJson(value, { maxBytes: 262144, maxNodes: 65536, maxDepth: 32 });
}

export {
  PeerGenerationError,
  check,
  object,
  boundedText,
  hex,
  uint,
  encodePeerValue,
  decodePeerValue,
  samePeerValue,
  peerDigest,
  bytesDigest,
  signPeerValue,
  verifyPeerValue,
  createPeerIdentity,
  exportPeerIdentity,
  importPeerIdentity,
  Serial,
  isArray,
  PEER_GENERATION_PROFILE,
  PEER_GENERATION_POLICY,
  PEER_MAX_RECORDS,
  PEER_MAX_HISTORY_BYTES,
  PEER_GENERATION_CAPABILITIES,
  parseApplicationInput,
  checkedApplicationInputSchema,
  validateApplicationDescription,
  applicationDescriptionDigest
};
