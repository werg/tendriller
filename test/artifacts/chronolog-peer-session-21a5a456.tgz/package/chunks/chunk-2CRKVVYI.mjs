import {
  DEFAULT_DECODE_LIMITS,
  assertCanonicalCbor,
  encodeCanonicalCbor,
  equalBytes,
  sha256,
  utf8
} from "./chunk-DACCYORU.mjs";

// packages/records/src/record-envelope.ts
var MAX_RECORD_VALUE_BYTES = 128 * 1024 * 1024;
var MAX_RECORD_ENVELOPE_BYTES = MAX_RECORD_VALUE_BYTES + 8192;
function assertRecordKey(key) {
  if (typeof key !== "string" || key.length === 0 || key.length > 4096) throw new Error("OPFS_KEY_INVALID");
}
async function recordFilename(key) {
  assertRecordKey(key);
  return "value-" + [...await sha256(utf8(key))].map((value) => value.toString(16).padStart(2, "0")).join("");
}
async function encodeRecordValue(key, bytes) {
  assertRecordKey(key);
  if (bytes.length > MAX_RECORD_VALUE_BYTES) throw new Error("BYTES_STORE_VALUE_LIMIT");
  const raw = encodeCanonicalCbor([1n, key, bytes, await sha256(bytes)]);
  if (raw.length > MAX_RECORD_ENVELOPE_BYTES) throw new Error("BYTES_STORE_VALUE_LIMIT");
  return raw;
}
async function decodeRecordValue(key, raw, corruptionCode) {
  assertRecordKey(key);
  if (raw.length === 0 || raw.length > MAX_RECORD_ENVELOPE_BYTES) throw new Error(corruptionCode);
  try {
    const decoded = assertCanonicalCbor(raw, {
      ...DEFAULT_DECODE_LIMITS,
      maxBytes: MAX_RECORD_ENVELOPE_BYTES,
      maxBlobBytes: MAX_RECORD_VALUE_BYTES
    });
    if (!Array.isArray(decoded) || decoded.length !== 4 || decoded[0] !== 1n || decoded[1] !== key || !(decoded[2] instanceof Uint8Array) || !(decoded[3] instanceof Uint8Array) || !equalBytes(decoded[3], await sha256(decoded[2]))) throw new Error(corruptionCode);
    return decoded[2].slice();
  } catch {
    throw new Error(corruptionCode);
  }
}

// packages/records/src/browser.ts
var OpfsBytesStore = class {
  #directory;
  #pending = Promise.resolve();
  #closing;
  #closed = false;
  constructor(directory) {
    this.#directory = directory;
  }
  async get(key) {
    assertRecordKey(key);
    return this.#enqueue(async () => {
      let file;
      try {
        file = await this.#directory.getFileHandle(await recordFilename(key));
      } catch (error) {
        if (error instanceof DOMException && error.name === "NotFoundError") return null;
        throw error;
      }
      const raw = new Uint8Array(await (await file.getFile()).arrayBuffer());
      if (raw.length === 0) return null;
      return decodeRecordValue(key, raw, "OPFS_VALUE_CORRUPT");
    });
  }
  async put(key, input) {
    assertRecordKey(key);
    const bytes = input.slice();
    return this.#enqueue(async () => {
      const raw = await encodeRecordValue(key, bytes);
      const file = await this.#directory.getFileHandle(await recordFilename(key), { create: true });
      const writer = await file.createWritable();
      try {
        await writer.write(raw.slice().buffer);
        await writer.close();
      } catch (error) {
        try {
          await writer.abort();
        } catch {
        }
        throw error;
      }
    });
  }
  close() {
    if (this.#closing !== void 0) return this.#closing;
    this.#closed = true;
    this.#closing = this.#pending.then(() => void 0);
    return this.#closing;
  }
  #enqueue(work) {
    if (this.#closed) return Promise.reject(new Error("OPFS_STORE_CLOSED"));
    const task = this.#pending.then(work);
    this.#pending = task.then(() => void 0, () => void 0);
    return task;
  }
};
function acquireBrowserStorageLock(name) {
  if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/u.test(name)) return Promise.reject(new Error("BROWSER_STORAGE_NAME_INVALID"));
  if (typeof navigator === "undefined" || navigator.locks === void 0) {
    return Promise.reject(new Error("BROWSER_DURABLE_STORAGE_UNAVAILABLE"));
  }
  return new Promise((resolve, reject) => {
    const completed = navigator.locks.request("chronolog:" + name, { mode: "exclusive", ifAvailable: true }, async (lock) => {
      if (lock === null) {
        reject(new Error("BROWSER_STORAGE_IN_USE"));
        return;
      }
      let release;
      const held = new Promise((done) => {
        release = done;
      });
      let closing;
      resolve({ close() {
        if (closing !== void 0) return closing;
        release();
        closing = completed.then(() => void 0);
        return closing;
      } });
      await held;
    });
    void completed.catch(reject);
  });
}
async function inspectLegacyOpfsDirectory(name, providedRoot) {
  if (typeof navigator === "undefined" || navigator.storage?.getDirectory === void 0) {
    throw new Error("BROWSER_STORAGE_BACKEND_AMBIGUOUS");
  }
  try {
    const root = providedRoot ?? await navigator.storage.getDirectory();
    try {
      await root.getDirectoryHandle("chronolog-" + name);
      return true;
    } catch (error) {
      if (error instanceof DOMException && error.name === "NotFoundError") return false;
      throw error;
    }
  } catch (error) {
    throw new Error("BROWSER_STORAGE_BACKEND_AMBIGUOUS", { cause: error });
  }
}
async function probeOpfsWritable(providedRoot) {
  if (typeof navigator === "undefined" || navigator.storage?.getDirectory === void 0) return false;
  const root = providedRoot ?? await navigator.storage.getDirectory();
  const fileName = "chronolog-probe-" + crypto.randomUUID();
  let created = false;
  try {
    const file = await root.getFileHandle(fileName, { create: true });
    created = true;
    if (typeof file.createWritable !== "function") return false;
    let writer;
    try {
      writer = await file.createWritable();
    } catch (error) {
      if (error instanceof DOMException && error.name === "NotSupportedError") return false;
      throw error;
    }
    try {
      await writer.write(Uint8Array.of(23, 42));
      await writer.close();
    } catch (error) {
      try {
        await writer.abort();
      } catch {
      }
      throw error;
    }
    const bytes = new Uint8Array(await (await file.getFile()).arrayBuffer());
    if (bytes.length !== 2 || bytes[0] !== 23 || bytes[1] !== 42) throw new Error("BROWSER_OPFS_PROBE_FAILED");
    return true;
  } finally {
    if (created) try {
      await root.removeEntry(fileName);
    } catch {
    }
  }
}

// packages/records/src/indexeddb-bytes-store.ts
var TABLE = "values";
var VERSION = 1;
var IndexedDbBytesStore = class _IndexedDbBytesStore {
  #database;
  #pending = Promise.resolve();
  #closing;
  #closed = false;
  #invalid;
  constructor(database) {
    this.#database = database;
    database.onversionchange = () => {
      this.#invalid = new Error("INDEXEDDB_STORE_VERSION_CHANGED");
      database.close();
    };
  }
  static open(name, { create = true } = {}) {
    if (typeof indexedDB === "undefined") return Promise.reject(new Error("BROWSER_STORAGE_BACKEND_UNSUPPORTED"));
    return new Promise((resolve, reject) => {
      let blocked = false, missing = false;
      const request = indexedDB.open("chronolog-data:" + name, VERSION);
      request.onupgradeneeded = () => {
        if (blocked) {
          request.transaction?.abort();
          return;
        }
        if (!create) {
          missing = true;
          request.transaction?.abort();
          return;
        }
        request.result.createObjectStore(TABLE);
      };
      request.onerror = () => {
        reject(missing ? new Error("APPLICATION_DATA_STORAGE_MISSING") : request.error ?? new Error("INDEXEDDB_STORE_OPEN_FAILED"));
      };
      request.onblocked = () => {
        blocked = true;
        reject(new Error("INDEXEDDB_STORE_BLOCKED"));
      };
      request.onsuccess = () => {
        if (blocked) request.result.close();
        else resolve(new _IndexedDbBytesStore(request.result));
      };
    });
  }
  async get(key) {
    assertRecordKey(key);
    return this.#enqueue(async () => {
      const raw = await this.#transaction("readonly", (table) => {
        const request = table.get(key);
        return () => request.result;
      });
      if (raw === void 0) return null;
      if (!(raw instanceof Uint8Array) || raw.length > MAX_RECORD_ENVELOPE_BYTES) throw new Error("INDEXEDDB_VALUE_CORRUPT");
      return decodeRecordValue(key, raw, "INDEXEDDB_VALUE_CORRUPT");
    });
  }
  async put(key, input) {
    assertRecordKey(key);
    if (input.length > MAX_RECORD_VALUE_BYTES) return Promise.reject(new Error("BYTES_STORE_VALUE_LIMIT"));
    const bytes = input.slice();
    return this.#enqueue(async () => {
      const raw = await encodeRecordValue(key, bytes);
      await this.#transaction("readwrite", (table) => {
        table.put(raw, key);
        return () => void 0;
      });
    });
  }
  close() {
    if (this.#closing !== void 0) return this.#closing;
    this.#closed = true;
    this.#closing = this.#pending.then(() => {
      this.#database.close();
    });
    return this.#closing;
  }
  #enqueue(work) {
    if (this.#closed) return Promise.reject(new Error("INDEXEDDB_STORE_CLOSED"));
    if (this.#invalid !== void 0) return Promise.reject(this.#invalid);
    const task = this.#pending.then(() => {
      if (this.#invalid !== void 0) throw this.#invalid;
      return work();
    });
    this.#pending = task.then(() => void 0, () => void 0);
    return task;
  }
  #transaction(mode, enqueue) {
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.#database.transaction(TABLE, mode, { durability: "strict" });
      } catch (error) {
        reject(error);
        return;
      }
      let value;
      try {
        value = enqueue(transaction.objectStore(TABLE));
      } catch (error) {
        try {
          transaction.abort();
        } catch {
        }
        reject(error);
        return;
      }
      transaction.oncomplete = () => {
        try {
          resolve(value());
        } catch (error) {
          reject(error);
        }
      };
      transaction.onabort = () => {
        reject(transaction.error ?? new Error("INDEXEDDB_TRANSACTION_ABORTED"));
      };
      transaction.onerror = () => {
      };
    });
  }
};
async function probeIndexedDbBytesStore() {
  if (typeof indexedDB === "undefined") return false;
  const name = "probe-" + crypto.randomUUID();
  let store;
  try {
    store = await IndexedDbBytesStore.open(name);
    await store.put("probe", Uint8Array.of(0, 255));
    await store.close();
    store = void 0;
    const reopened = await IndexedDbBytesStore.open(name);
    store = reopened;
    const bytes = await reopened.get("probe");
    if (bytes?.length !== 2 || bytes[0] !== 0 || bytes[1] !== 255) throw new Error("INDEXEDDB_PROBE_FAILED");
    return true;
  } finally {
    await store?.close();
    await new Promise((resolve, reject) => {
      const request = indexedDB.deleteDatabase("chronolog-data:" + name);
      request.onsuccess = () => {
        resolve();
      };
      request.onerror = () => {
        reject(request.error ?? new Error("INDEXEDDB_PROBE_CLEANUP_FAILED"));
      };
      request.onblocked = () => {
        reject(new Error("INDEXEDDB_PROBE_CLEANUP_BLOCKED"));
      };
    });
  }
}
function inspectExistingIndexedDbRecords(name) {
  if (typeof indexedDB === "undefined") return Promise.resolve(false);
  if (typeof indexedDB.databases === "function") {
    return indexedDB.databases().then((databases) => databases.some((database) => database.name === "chronolog-data:" + name));
  }
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("chronolog-data:" + name);
    let absent = false;
    request.onupgradeneeded = (event) => {
      if (event.oldVersion === 0) {
        absent = true;
        request.transaction?.abort();
      }
    };
    request.onerror = () => {
      if (absent && request.error?.name === "AbortError") resolve(false);
      else reject(request.error ?? new Error("INDEXEDDB_INSPECTION_FAILED"));
    };
    request.onblocked = () => {
      reject(new Error("INDEXEDDB_INSPECTION_BLOCKED"));
    };
    request.onsuccess = () => {
      request.result.close();
      resolve(true);
    };
  });
}

export {
  OpfsBytesStore,
  acquireBrowserStorageLock,
  inspectLegacyOpfsDirectory,
  probeOpfsWritable,
  IndexedDbBytesStore,
  probeIndexedDbBytesStore,
  inspectExistingIndexedDbRecords
};
