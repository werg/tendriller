import {
  createApplicationBackend
} from "./chunks/chunk-5IPT5RAQ.mjs";
import "./chunks/chunk-V6KSH7C4.mjs";
import "./chunks/chunk-PDJLSHX7.mjs";
export {
  createApplicationBackend
};
