import type { MaterializerOptions } from '../../materializer-doltlite/src/browser.js';
import type { ChronologMaterializationRuntime } from '../../materializer/src/index.js';
/** DDL and grants are ordinary signed submissions after this empty trusted platform bootstrap. */
export declare function createSqlMaterializationRuntime(options: MaterializerOptions): Promise<ChronologMaterializationRuntime>;
export type { MaterializerOptions, SqlEngine } from '../../materializer-doltlite/src/browser.js';
