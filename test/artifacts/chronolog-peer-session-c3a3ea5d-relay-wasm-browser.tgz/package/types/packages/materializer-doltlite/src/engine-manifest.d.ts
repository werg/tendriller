import type { EngineBuildManifest } from './types.js';
/** Capture the same closed build identity from the native addon or WASM artifact. */
export declare function normalizeEngineManifest(value: unknown): EngineBuildManifest;
/** One versioned canonical descriptor, independent of the engine's host runtime. */
export declare function engineManifestDescriptor(manifest: EngineBuildManifest): string;
export declare function digestEngineManifest(manifest: EngineBuildManifest): Uint8Array;
