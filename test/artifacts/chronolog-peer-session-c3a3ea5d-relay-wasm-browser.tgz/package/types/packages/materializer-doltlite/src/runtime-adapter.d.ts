import { type ReplayProposal, type ChronologMaterializationRuntime, type MaterializedApplicationSnapshot, type MaterializedReadHandle } from '../../materializer/src/index.js';
import type { LocalSqlOptions, LocalSqlQueryResult, LocalSqlValue, MaterializedRevision, TransactionOutcome } from './types.js';
export interface DoltLiteMaterializerRuntimeBackend {
    readonly revision: bigint;
    readonly orderLength: number;
    readonly finalRevision?: bigint;
    readonly finalOrderLength?: number;
    readonly executionManifestDigest: Uint8Array;
    proposalIdAt(index: number): Uint8Array | null;
    materialize(orderedTransactions: readonly ReplayProposal[]): Promise<MaterializedRevision | null>;
    publishFinal?(prefixLength: number): Promise<void>;
    localSql(sql: string, parameters?: readonly LocalSqlValue[], options?: LocalSqlOptions): LocalSqlQueryResult;
    outcome(txId: Uint8Array): TransactionOutcome | null;
    captureApplication(options?: {
        readonly view?: 'local' | 'final';
    }): MaterializedApplicationSnapshot;
    captureRead?(options?: {
        readonly view?: 'local' | 'final';
    }): MaterializedReadHandle;
    subscribe(subscriber: (revision: MaterializedRevision) => void): () => void;
    close(): void;
}
/**
 * Adapts the branch-backed DoltLite materializer to the portable runtime seams.
 * DoltLite has already moved its local head when materialize() returns, so
 * publish() validates and memoizes that exact movement as already-current.
 */
export declare function createDoltLiteMaterializationRuntime(materializer: DoltLiteMaterializerRuntimeBackend): ChronologMaterializationRuntime;
