import type { DatabaseLike, DdlPermissions, NativeSecurityConfiguration, SqlRuntimeLimits, StatementLike } from './types.js';
export declare const SQLITE_LIMIT_CATEGORY: {
    readonly LENGTH: 0;
    readonly SQL_LENGTH: 1;
    readonly COLUMN: 2;
    readonly EXPR_DEPTH: 3;
    readonly COMPOUND_SELECT: 4;
    readonly VDBE_OP: 5;
    readonly FUNCTION_ARG: 6;
    readonly ATTACHED: 7;
    readonly LIKE_PATTERN_LENGTH: 8;
    readonly VARIABLE_NUMBER: 9;
    readonly TRIGGER_DEPTH: 10;
    readonly WORKER_THREADS: 11;
};
export declare const DEFAULT_SQL_RUNTIME_LIMITS: Readonly<SqlRuntimeLimits>;
/** Included in the execution-manifest platform digest on every runtime. */
export declare const SQL_PROFILE_VERSION = "chronolog-portable-sql-policy-v3";
/**
 * Read-only pragmas whose answers describe replicated SQL state. Build and
 * connection catalogs are separate: native and WASM share SQL semantics while
 * compiling different host adapters and diagnostic registrations.
 */
export declare const READ_ONLY_PRAGMAS: ReadonlySet<string>;
/**
 * The replicated block-list: functions whose result depends on connection
 * history, physical storage, Dolt history or the host. Everything else in
 * the pinned engine is allowed; the clock and PRNG are pinned per transaction.
 */
export declare const REPLICATED_DENIED_FUNCTIONS: ReadonlySet<string>;
/** Virtual-table modules that read physical storage rather than SQL state. */
export declare const REPLICATED_DENIED_MODULES: ReadonlySet<string>;
/** Local SQL is not replayed, so only external effects and Dolt control are denied. */
export declare const FORBIDDEN_LOCAL_READ_FUNCTIONS: ReadonlySet<string>;
export type SqlAuthorizationMode = 'internal_bootstrap' | 'replicated'
/** Trusted platform operations: may write chronolog_* objects. App triggers they fire stay under replicated rules. */
 | 'platform' | 'local_read';
export interface SqlAuthorizationOptions {
    /** Fresh trusted snapshot derived from the permission catalog before this statement. */
    readonly ddlPermissions?: DdlPermissions;
    /** Exact generated trigger names; their privilege is restricted to lifecycle metadata columns. */
    readonly lifecycleTriggers?: ReadonlySet<string>;
    /**
     * Lower-case names of tables that carry no owner checks (virtual tables and
     * sqlite-vec chunk tables). App SQL may write them only from app triggers,
     * which fire on owner-checked writes to registered tables.
     */
    readonly writeProtectedTables?: ReadonlySet<string>;
    /**
     * Lower-case names of SQLite shadow tables (owned by virtual-table modules).
     * Local reads let a module prepare its own writes to them (R-tree prepares
     * them on connect); defensive mode keeps them read-only to app SQL, and
     * writes to the virtual tables themselves stay denied.
     */
    readonly shadowTables?: ReadonlySet<string>;
}
/** Raises a policy rejection; callable only from chronolog_* triggers and views. */
export declare const POLICY_VIOLATION_FUNCTION = "chronolog_policy_violation";
/** The owner column every registered table carries. */
export declare const OWNER_COLUMN = "chronolog_owner";
/** Names owned by SQLite, Dolt or Chronolog rather than the application. */
export declare function isReservedSchemaObjectName(value: string): boolean;
export declare class SqlProfileError extends Error {
    readonly code: string;
    constructor(code: string);
}
/** A deterministic refusal from the host's native SQL profile. */
export declare class NativeSqlRejection extends Error {
    readonly code: string;
    constructor(code: string);
}
export declare function normalizeSqlRuntimeLimits(input?: Partial<SqlRuntimeLimits>): SqlRuntimeLimits;
/** Apply and verify connection-local sqlite3_limit values. */
export declare function configureSqliteLimits(database: DatabaseLike, input?: Partial<SqlRuntimeLimits>): ReadonlyMap<number, number>;
/** Fail startup if the native connection did not apply every security bit. */
export declare function assertNativeSecurityConfiguration(config: NativeSecurityConfiguration): void;
export declare function prepareProfiledStatement(database: DatabaseLike, sql: string, mode: SqlAuthorizationMode, inputLimits?: Partial<SqlRuntimeLimits>, authorization?: SqlAuthorizationOptions): StatementLike;
/**
 * Keep authorizer and budget installed through prepare and step. This matters
 * because sqlite3_step() may reprepare after a schema change.
 */
export declare function withProfiledStatement<T>(database: DatabaseLike, sql: string, mode: SqlAuthorizationMode, operation: (statement: StatementLike) => T, inputLimits?: Partial<SqlRuntimeLimits>, authorization?: SqlAuthorizationOptions): T;
export declare function withAuthorizer<T>(database: DatabaseLike, mode: SqlAuthorizationMode, operation: () => T, authorization?: SqlAuthorizationOptions): T;
export declare function withExecutionBudget<T>(database: DatabaseLike, operation: () => T, inputLimits?: Partial<SqlRuntimeLimits>): T;
export declare function sqlitePrimaryCode(error: unknown): number | null;
/** True when the failure is local/environmental and must abort replay. */
export declare function isOperationalSqliteError(error: unknown): boolean;
