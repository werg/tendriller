import { type ExecutionManifest } from '../../protocol/src/index.js';
import type { MaterializedApplicationSnapshot, MaterializedReadHandle } from '../../materializer/src/index.js';
import type { ReplayProposal, LocalSqlOptions, LocalSqlQueryResult, LocalSqlValue, MaterializedRevision, MaterializerBackendInfo, MaterializerCheckpointInfo, MaterializerSqlBackend, MaterializerOptions, RevisionSubscriber, TransactionLogRow, TransactionOutcome } from './types.js';
export declare class MaterializerInputError extends Error {
    readonly code: string;
    constructor(code: string);
}
export declare class DeterministicMaterializer implements MaterializerSqlBackend {
    #private;
    private constructor();
    static open(input: MaterializerOptions): Promise<DeterministicMaterializer>;
    get revision(): bigint;
    get orderLength(): number;
    get finalRevision(): bigint;
    get finalOrderLength(): number;
    get executionManifestDigest(): Uint8Array;
    get executionManifest(): ExecutionManifest;
    get backend(): MaterializerBackendInfo;
    get checkpointError(): string | null;
    get databaseContentHash(): string;
    proposalIdAt(index: number): Uint8Array | null;
    transactionLogDigest(): Promise<Uint8Array>;
    checkpoints(): readonly MaterializerCheckpointInfo[];
    transactionLog(): readonly TransactionLogRow[];
    outcome(txId: Uint8Array): TransactionOutcome | null;
    localSql(sql: string, parameters?: readonly LocalSqlValue[], options?: LocalSqlOptions): LocalSqlQueryResult;
    localQuery(sql: string, parameters?: readonly LocalSqlValue[], options?: LocalSqlOptions): LocalSqlQueryResult;
    captureApplication(options?: {
        readonly view?: 'local' | 'final';
    }): MaterializedApplicationSnapshot;
    captureRead(options?: {
        readonly view?: 'local' | 'final';
    }): MaterializedReadHandle;
    subscribe(subscriber: RevisionSubscriber): () => void;
    materialize(orderedTransactions: readonly ReplayProposal[]): Promise<MaterializedRevision | null>;
    publishFinal(prefixLength: number): Promise<void>;
    close(): void;
}
