import { type ChangeProgram } from '../../protocol/src/index.js';
import { toDatabaseValue } from './platform/session.js';
import type { DatabaseLike, SqlRuntimeLimits } from './types.js';
export { toDatabaseValue };
/** A deterministic reason a transaction is rejected; recorded in the log. */
export declare class SqlRejection extends Error {
    readonly code: string;
    readonly statementIndex: number | null;
    /** `statementIndex` is the failing step, or null for whole-transaction checks. */
    constructor(code: string, statementIndex: number | null);
}
export interface DeterministicContext {
    /** The value of 'now': the transaction's signed author timestamp. */
    readonly authorTimestampMs: bigint;
    /** Seeds random()/randomblob(); derived from the transaction id. */
    readonly txId: Uint8Array;
    /** The signing key: chronolog_actor() and the owner of new rows. */
    readonly actor: Uint8Array;
    /** Binds sealed ciphertext to this replication group. */
    readonly groupId: Uint8Array;
}
/**
 * Execute a transaction program as its signer: SQL steps as ordinary SQLite
 * statements, platform operations through trusted platform code, with the
 * engine's non-SQL inputs pinned to the transaction. A transaction that
 * changed the schema is reconciled before it may commit. Throws SqlRejection
 * for a deterministic failure; any other error is operational and stops
 * replay. Must run synchronously: the pinned context is process-global.
 */
export declare function executeTransactionProgram(database: DatabaseLike, program: ChangeProgram, context: DeterministicContext, limits?: Partial<SqlRuntimeLimits>): void;
/** A nonzero 32-bit PRNG seed from the transaction id. */
export declare function prngSeed(txId: Uint8Array): number;
