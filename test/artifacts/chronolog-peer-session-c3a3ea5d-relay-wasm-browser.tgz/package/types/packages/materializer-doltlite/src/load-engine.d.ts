import { type ChronologWasmModule, type WasmBuildManifest } from './wasm-engine.js';
export interface LoadedBrowserEngine {
    readonly module: ChronologWasmModule;
    readonly manifest: WasmBuildManifest;
}
/** Load the reproducible build, validate exact WASM bytes, and instantiate once in the owner Worker. */
export declare function loadBrowserEngine(baseUrl: string | URL): Promise<LoadedBrowserEngine>;
