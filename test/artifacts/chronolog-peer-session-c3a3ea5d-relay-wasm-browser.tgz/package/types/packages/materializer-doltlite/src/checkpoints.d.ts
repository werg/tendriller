import type { DatabaseLike, MaterializerCheckpointInfo, TransactionLogRow } from './types.js';
export declare const HEAD_BRANCH: "chronolog_head";
export declare const FINAL_BRANCH: "chronolog_final";
export interface PublishedRef {
    readonly revision: bigint;
    readonly prefixLength: number;
    readonly branchRef: string;
    readonly doltCommitHash: string;
    readonly contentHash: string;
    readonly orderDigest: string;
}
export declare function discoverFinalRef(database: DatabaseLike): PublishedRef | null;
export declare function publishFinalRef(database: DatabaseLike, revision: bigint, log: readonly TransactionLogRow[], commitHash: string): PublishedRef;
export declare function discoverPublishedRef(database: DatabaseLike): PublishedRef | null;
export declare function discoverCheckpoints(database: DatabaseLike): MaterializerCheckpointInfo[];
export declare function checkpointOrderDigest(branchRef: string): string;
export declare function createCheckpointRef(database: DatabaseLike, prefixLength: number, revision: bigint, commitHash: string, log: readonly TransactionLogRow[]): MaterializerCheckpointInfo;
export declare function createRevisionRef(database: DatabaseLike, revision: bigint, prefixLength: number, commitHash: string, log: readonly TransactionLogRow[]): PublishedRef;
export declare function createReplayBranch(database: DatabaseLike, revision: bigint, fromRef: string): string;
export declare function publishRef(database: DatabaseLike, published: PublishedRef): void;
export declare function removeBranchIfPresent(database: DatabaseLike, branchRef: string): void;
export declare function cleanupOrphanBranches(database: DatabaseLike, published: PublishedRef, retainedCheckpoints: readonly MaterializerCheckpointInfo[], retainedReaders?: readonly string[]): void;
export declare function orderDigest(log: readonly Pick<TransactionLogRow, 'txId'>[]): string;
export declare function verifyPublishedLog(published: PublishedRef, log: readonly TransactionLogRow[]): void;
