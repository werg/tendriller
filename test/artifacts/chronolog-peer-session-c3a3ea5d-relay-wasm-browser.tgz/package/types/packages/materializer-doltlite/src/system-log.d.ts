import type { DatabaseLike, StoredExecutionManifest, TransactionLogRow } from './types.js';
/** The replicated transaction log; readable by transactions, written only by Chronolog. */
export declare const TRANSACTION_LOG_TABLE: "chronolog_transactions";
export declare const EXECUTION_MANIFEST_TABLE: "chronolog_execution_manifest";
/** Replicated system schema, also committed by the execution manifest digest. */
export declare const SYSTEM_LOG_SQL: string;
export declare function initializeSystemLog(database: DatabaseLike): void;
export declare function insertExecutionManifest(database: DatabaseLike, manifest: StoredExecutionManifest): void;
export declare function readExecutionManifest(database: DatabaseLike): StoredExecutionManifest;
export declare function readSystemLog(database: DatabaseLike): TransactionLogRow[];
export declare function insertSystemLogRow(database: DatabaseLike, row: Omit<TransactionLogRow, 'orderKey'>): void;
