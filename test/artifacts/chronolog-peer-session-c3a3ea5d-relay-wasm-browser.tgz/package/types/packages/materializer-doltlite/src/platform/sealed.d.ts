import { type SealedPlatformOp, type SqlValue } from '../../../protocol/src/index.js';
import type { DatabaseLike, SqlRuntimeLimits } from '../types.js';
import { type TableShape } from './tables.js';
/** Reader keys and ciphertext are replicated; private keys and plaintext never enter this state. */
export declare const SEALED_TABLES_SQL: readonly string[];
export declare const SEEDABLE_SEALED_TABLES: readonly string[];
/** Closing the policy generation prevents permissions reviving after delete/reinsert or a PK change. */
export declare function closeReaderPolicySql(table: string, oldKey: string, condition?: string): string;
/** A sealed app column can only change through an exact, policy-checked sealed_put. */
export declare function sealedWriteGuard(shape: TableShape, oldKey: string): string;
export declare class SealedRejection extends Error {
    constructor(reason: string);
}
/** Row ownership stays in the existing platform session; this module adds no new owner/admin roles. */
export interface SealedOperationHost {
    readonly actor: Uint8Array;
    readonly txId: Uint8Array;
    readonly groupId: Uint8Array;
    readonly limits: Partial<SqlRuntimeLimits>;
    registered(table: string): TableShape;
    findRow(shape: TableShape, values: readonly SqlValue[]): {
        readonly key: string;
        readonly owner: Uint8Array;
    } | null;
    ownerOf(shape: TableShape, key: string): Uint8Array | null;
    administers(owner: Uint8Array): boolean;
    objectId(stepIndex: number): Uint8Array;
}
export declare class SealedSession {
    readonly database: DatabaseLike;
    readonly host: SealedOperationHost;
    constructor(database: DatabaseLike, host: SealedOperationHost);
    execute(op: SealedPlatformOp, stepIndex: number): void;
    private registerKey;
    private setPolicy;
    private policy;
    private put;
    private run;
    private get;
    private all;
}
