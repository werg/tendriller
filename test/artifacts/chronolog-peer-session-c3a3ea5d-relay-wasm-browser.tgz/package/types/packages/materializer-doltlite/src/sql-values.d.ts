import type { DatabaseLike, LocalSqlValue, SqlRuntimeLimits } from './types.js';
/**
 * Execute explicitly local, non-replicated SQL against an immutable reader.
 * These tagged values deliberately have no canonical transaction encoding.
 */
export declare function executeLocalSql(database: DatabaseLike, sql: string, parameters?: readonly LocalSqlValue[], inputLimits?: Partial<SqlRuntimeLimits>): {
    readonly columns: readonly {
        readonly name: string;
        readonly declaredType?: string;
    }[];
    readonly rows: readonly (readonly LocalSqlValue[])[];
};
