import type { ExecutionLimits } from '../../protocol/src/index.js';
import type { DatabaseLike, DoltBranchInfoLike, EngineBuildManifest, NativeSecurityConfiguration, SqlEngine, StatementLike } from './types.js';
type Authorizer = Parameters<DatabaseLike['setAuthorizer']>[0];
interface WasmApi {
    alloc(bytes: number): number;
    dealloc(pointer: number): void;
    heap8u(): Uint8Array;
    peekPtr(pointer: number): number;
    xCall(name: string, ...args: (number | bigint)[]): number;
}
interface SqliteApi {
    sqlite3_open_v2(path: string, output: number, flags: number, vfs: string): number;
    sqlite3_close_v2(database: number): number;
    sqlite3_exec(database: number, sql: string, callback: number, context: number, error: number): number;
    sqlite3_get_autocommit(database: number): number;
    sqlite3_errmsg(database: number): string;
    sqlite3_extended_errcode(database: number): number;
    sqlite3_prepare_v3(database: number, sql: number, bytes: number, flags: number, output: number, tail: number): number;
    sqlite3_finalize(statement: number): number;
    sqlite3_step(statement: number): number;
    sqlite3_reset(statement: number): number;
    sqlite3_clear_bindings(statement: number): number;
    sqlite3_sql(statement: number): string;
    sqlite3_column_count(statement: number): number;
    sqlite3_column_name(statement: number, index: number): string;
    sqlite3_column_type(statement: number, index: number): number;
    sqlite3_column_int64(statement: number, index: number): bigint;
    sqlite3_column_double(statement: number, index: number): number;
    sqlite3_column_text(statement: number, index: number): string;
    sqlite3_column_blob(statement: number, index: number): number;
    sqlite3_column_bytes(statement: number, index: number): number;
    sqlite3_bind_parameter_count(statement: number): number;
    sqlite3_bind_parameter_name(statement: number, index: number): string | null;
    sqlite3_bind_int64(statement: number, index: number, value: bigint): number;
    sqlite3_bind_double(statement: number, index: number, value: number): number;
    sqlite3_bind_text(statement: number, index: number, pointer: number, length: number, destroy: number): number;
    sqlite3_bind_blob(statement: number, index: number, pointer: number, length: number, destroy: number): number;
    sqlite3_changes64(database: number): bigint;
    sqlite3_last_insert_rowid(database: number): bigint;
    sqlite3_set_authorizer(database: number, callback: ((context: number, action: number, a: string | 0, b: string | 0, c: string | 0, d: string | 0) => number) | null, context: number): number;
    sqlite3_progress_handler(database: number, steps: number, callback: (() => number) | null, context: number): void;
    sqlite3_limit(database: number, category: number, value: number): number;
    sqlite3_interrupt(database: number): void;
}
/** Only the stable public C/JS API of the built SQLite/DoltLite WASM artifact. */
export interface ChronologWasmModule {
    readonly capi: SqliteApi;
    readonly wasm: WasmApi;
    installOpfsSAHPoolVfs?(options: {
        readonly name: string;
        readonly directory: string;
        readonly initialCapacity: number;
    }): Promise<OpfsSqlitePool>;
}
export interface OpfsSqlitePool {
    readonly vfsName: string;
    /** Release owned handles without deleting durable data; all SQL must be closed first. */
    pauseVfs(): unknown;
}
export interface WasmBuildManifest {
    readonly format: 1;
    readonly toolchain: 'emscripten-4.0.20';
    readonly nativeManifest: EngineBuildManifest;
    readonly runtimeVersions: {
        readonly doltlite: string;
        readonly sqlite: string;
        readonly vec: string;
    };
    readonly portabilityPatches: readonly ['chunk-store-optional-sector-size-v1', 'chunk-store-optional-has-moved-v1', 'vfs-identity-forwarding-v1', 'chunk-store-incremental-reload-v1'];
    readonly deterministicSourceSha256: string;
    readonly loaderSha256: string;
    readonly wasmSha256: string;
    readonly wasmBytes: number;
}
/** Verify the actual module bytes before instantiation; unavailable profiles fail closed. */
export declare function verifyWasmBuild(bytes: Uint8Array, manifest: WasmBuildManifest): void;
/** Create a synchronous engine factory after the Worker has loaded its one WASM instance. */
export declare function createBrowserSqlEngine(options: {
    readonly module: ChronologWasmModule;
    readonly manifest: WasmBuildManifest;
    readonly vfs: string;
    readonly limits?: Partial<ExecutionLimits>;
}): SqlEngine;
export declare class WasmDatabase implements DatabaseLike {
    #private;
    readonly module: ChronologWasmModule;
    readonly pointer: number;
    constructor(module: ChronologWasmModule, path: string);
    get inTransaction(): boolean;
    exec(sql: string): void;
    prepare(sql: string): StatementLike;
    close(): void;
    configureSecurity(): NativeSecurityConfiguration;
    triggerUsesIgnore(sql: string): boolean;
    setAuthorizer(callback: Authorizer): void;
    setProgressHandler(steps: number, callback: (() => boolean) | null): void;
    setLimit(category: number, value: number): number;
    interrupt(): void;
    setDeterministicContext(unixMs: bigint, seed: number, actor?: Uint8Array | null, actorId?: bigint | null, transactionId?: Uint8Array | null): void;
    clearDeterministicContext(): void;
    doltCommit(message: string): string;
    doltBranch(name: string, from?: string): void;
    doltCheckout(branch: string): void;
    doltResetHard(ref: string): void;
    doltForceBranch(name: string, ref: string): void;
    doltDeleteBranch(name: string): void;
    doltHashOf(ref?: string): string;
    doltVersion(): string;
    doltBranches(): DoltBranchInfoLike[];
    doltActiveBranch(): string;
    scalar(sql: string, ...parameters: unknown[]): unknown;
    check(code: number): void;
    error(code: number): Error;
    assertOpen(): void;
}
export {};
