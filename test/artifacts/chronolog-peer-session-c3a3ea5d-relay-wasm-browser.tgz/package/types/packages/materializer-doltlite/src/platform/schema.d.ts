import type { DatabaseLike } from '../types.js';
/**
 * Replicated platform state for owner-controlled rows
 * (docs/design-owner-rows.md §3). Transactions may read it; only platform
 * operations write it.
 */
export declare const PLATFORM_TABLES_SQL: readonly string[];
export type OwnerOperation = 'insert' | 'update' | 'delete';
export declare const OWNER_OPERATIONS: readonly OwnerOperation[];
/** The actor's principal id plus those of the collectives whose governance lets the actor perform `operation`. */
export declare const ownerIdsView: (operation: OwnerOperation) => string;
/** Live grants to the actor for `operation`; `grantor` is a principal id; row_key is NULL for whole-table grants. */
export declare const grantsToMeView: (operation: OwnerOperation) => string;
export declare const PLATFORM_VIEWS_SQL: readonly string[];
export declare const PLATFORM_VIEW_NAMES: ReadonlySet<string>;
/**
 * Create the platform tables and views and the `group` collective,
 * administered by the trusted initial principal. Fork seeding starts open only in a fork.
 */
export declare function initializePlatform(database: DatabaseLike, rootPrincipal: Uint8Array, forkSeeding: boolean): void;
export declare function readRootPrincipal(database: DatabaseLike): Uint8Array;
