import { type ExecutionLimits, type ExecutionManifest } from '../../protocol/src/index.js';
/** One SQL semantics identity, independent of host runtime and history ordering. */
export declare function createDoltLiteExecutionManifest(options: {
    readonly engineDigest: Uint8Array;
    readonly limits?: Partial<ExecutionLimits>;
}): ExecutionManifest;
