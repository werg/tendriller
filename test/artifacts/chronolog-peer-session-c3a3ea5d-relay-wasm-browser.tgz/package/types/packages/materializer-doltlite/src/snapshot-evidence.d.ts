import type { TransactionLogRow } from './types.js';
/** Exact digest of every protected materialized-log field in order. */
export declare function materializedLogDigest(rows: readonly TransactionLogRow[]): Promise<Uint8Array>;
