import { type RowKeyPart } from '../../../protocol/src/index.js';
import type { DatabaseLike } from '../types.js';
/** The declaration every registered table's owner column must have. */
export declare const OWNER_COLUMN_TYPE = "INTEGER";
export declare const OWNER_COLUMN_DEFAULT = "chronolog_actor_id()";
export declare const OWNER_COLUMN_SQL = "chronolog_owner INTEGER NOT NULL DEFAULT (chronolog_actor_id())";
export interface ColumnShape {
    readonly name: string;
    readonly type: string;
    readonly notNull: boolean;
    readonly defaultValue: string | null;
    /** Position in the primary key (1-based), or 0. */
    readonly primaryKey: number;
    /** 0 for ordinary columns; generated and hidden columns are nonzero. */
    readonly hidden: number;
}
export interface ForeignKeyShape {
    readonly table: string;
    readonly from: readonly string[];
    readonly to: readonly (string | null)[];
    readonly onUpdate: string;
    readonly onDelete: string;
}
export interface TableShape {
    readonly name: string;
    readonly columns: readonly ColumnShape[];
    readonly primaryKey: readonly string[];
    readonly foreignKeys: readonly ForeignKeyShape[];
    /** SQLite's INTEGER PRIMARY KEY alias; its implicit NOT NULL is not in table_xinfo. */
    readonly rowidPrimaryKey?: string;
}
export declare function quoteIdentifier(name: string): string;
export declare function quoteText(value: string): string;
/** The schema's spelling of an ordinary main-schema table, matched case-insensitively. */
export declare function resolveTable(database: DatabaseLike, name: string): string | null;
export declare function tableShape(database: DatabaseLike, name: string): TableShape;
export declare function ownerColumn(shape: TableShape): ColumnShape | undefined;
/** True when the owner column is declared exactly as `OWNER_COLUMN_SQL`. */
export declare function hasValidOwnerColumn(shape: TableShape): boolean;
/** An FK that carries the owner: its columns include chronolog_owner, mapped to the parent's chronolog_owner. */
export declare function isOwnerComposite(foreignKey: ForeignKeyShape): boolean;
/**
 * Cross-owner references may not cascade: an owner-composite FK must be
 * ON UPDATE CASCADE (so a transfer carries the child) and may delete-cascade;
 * any other FK must be RESTRICT or NO ACTION. Returns the offending parent table.
 */
export declare function foreignKeyViolation(shape: TableShape): string | null;
/** Every row must have one unambiguous, non-NULL primary-key tuple. */
export declare function hasNonNullPrimaryKey(shape: TableShape): boolean;
/**
 * Lossless typed primary-key tuple. Owner components use stable owner keys,
 * never this materializer's principal ids, so fork remapping preserves keys.
 */
export declare function rowKeyExpression(alias: string, primaryKey: readonly string[]): string;
/** Decode raw storage values; TEXT remains bytes, including embedded NUL/invalid UTF-8. */
export declare function parseRowKey(key: string): readonly RowKeyPart[];
/** Indexed tuple lookup plus an exact typed-key check independent of collation. */
export declare function rowKeyFilter(alias: string, primaryKey: readonly string[]): string;
export declare function rowKeyBindings(key: string, primaryKey: readonly string[]): unknown[];
export type TriggerEvent = 'ins' | 'upd' | 'del' | 'life_ins';
export declare const PLATFORM_TRIGGER_EVENTS: readonly TriggerEvent[];
export declare function platformTriggerName(table: string, event: TriggerEvent): string;
export interface PlatformTrigger {
    readonly name: string;
    readonly sql: string;
}
/** The three generated BEFORE triggers that enforce row ownership on `shape` (§4). */
export declare function platformTriggers(shape: TableShape): readonly PlatformTrigger[];
