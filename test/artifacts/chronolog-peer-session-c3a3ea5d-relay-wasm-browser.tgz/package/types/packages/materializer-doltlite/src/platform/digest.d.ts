/**
 * Version of the platform-operation semantics in ./session.ts. Bump it with
 * any change to what an operation checks or writes: the platform code decides
 * replicated state, so replicas must run the same version.
 */
export declare const PLATFORM_CODE_VERSION = "chronolog-platform-ops-v11-authored-replay-ddl-acl-v1";
/** SHA-256 over SQL/operation semantics, replicated schemas, and generated views and triggers. */
export declare function computePlatformDigest(): Uint8Array;
export declare const PLATFORM_DIGEST: Uint8Array;
