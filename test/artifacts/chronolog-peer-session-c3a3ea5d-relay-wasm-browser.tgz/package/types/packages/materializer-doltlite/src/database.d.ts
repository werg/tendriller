import type { DatabaseLike, EngineBuildManifest, SqlEngine } from './types.js';
/** Both adapters enter the same verified SQL security and build-identity boundary. */
export declare function configureSqlDatabase(database: DatabaseLike, manifest: EngineBuildManifest): ReturnType<SqlEngine['openDatabase']>;
