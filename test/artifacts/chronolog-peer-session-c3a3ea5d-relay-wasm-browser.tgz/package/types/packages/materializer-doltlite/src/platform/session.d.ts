import { type PlatformOp, type SqlValue } from '../../../protocol/src/index.js';
import type { DatabaseLike, DdlPermissions, SqlRuntimeLimits, StatementLike } from '../types.js';
/** A deterministic rejection raised by platform code; `code` is the full rejection code. */
export declare class PlatformRejection extends Error {
    readonly code: string;
    constructor(code: string);
}
/**
 * Platform tables a fork seeds verbatim from its source (§7), parents first.
 * The `group` collective is not seeded: the fork's genesis root administers it.
 */
export declare const SEEDABLE_PLATFORM_TABLES: readonly string[];
export interface PlatformContext {
    /** The signing key of the transaction: chronolog_actor(). */
    readonly actor: Uint8Array;
    readonly txId: Uint8Array;
    readonly groupId: Uint8Array;
    readonly limits: Partial<SqlRuntimeLimits>;
}
/**
 * Trusted, deterministic platform code for one transaction. Every write runs
 * as the signer: platform statements use the `platform` authorizer mode, but
 * chronolog_actor() stays the signer, and app triggers they fire are checked
 * like any other write.
 */
export declare class PlatformSession {
    #private;
    constructor(database: DatabaseLike, context: PlatformContext);
    /** Snapshot only protected catalog names, before authored SQL runs. */
    reservedObjectNames(): ReadonlySet<string>;
    /** ALTER callbacks name only the old object; do not let a rename claim protected names. */
    assertReservedObjectsUnchanged(before: ReadonlySet<string>): void;
    /** Derive from the current transaction state, never from enrollment roles or cached cookies. */
    ddlPermissions(): DdlPermissions;
    /**
     * Start a transaction: close fork seeding unless the signer is the genesis
     * root (seeding ends at the plan's EndSeeding step, or at the first
     * transaction by anyone else if that comes first),
     * give a first-time signer its principal id, and read the schema cookie. One cached read, since it runs for
     * every transaction.
     */
    begin(): {
        readonly actorId: bigint;
        readonly schemaVersion: number;
    };
    execute(op: PlatformOp, stepIndex: number): void;
    /**
     * Run after every transaction that changed the schema (§3): every
     * application table is registered and carries current platform triggers, no
     * foreign chronolog_* trigger or view exists, and no app trigger uses
     * RAISE(IGNORE). Throws PlatformRejection with the bare rejection code.
     */
    reconcile(): void;
}
/**
 * A prepared statement of fixed, trusted platform SQL, reused across
 * transactions. Use only for reads that run while no authorizer is installed
 * (SQLite may re-prepare it after a schema change).
 */
export declare function cachedInternalStatement(database: DatabaseLike, sql: string): StatementLike;
/**
 * Exact generated lifecycle callers, read while no authorizer is installed.
 * Re-read authorization inventories on every use: schema_version is a
 * rollbackable cookie, not a unique identity for the current catalog. Caching
 * results by that cookie makes authorization depend on prior failed work.
 * Only the fixed SQL statements themselves are cached.
 */
export declare function lifecycleTriggerNames(database: DatabaseLike): ReadonlySet<string>;
/** Current lower-case SQLite shadow table names; read while no authorizer is installed. */
export declare function shadowTables(database: DatabaseLike): ReadonlySet<string>;
/**
 * Lower-case names of the tables that carry no owner checks: virtual tables
 * (FTS5, R-tree, sqlite-vec) and sqlite-vec's chunk tables. Recomputed from the
 * current catalog while no authorizer is installed.
 */
export declare function writeProtectedTables(database: DatabaseLike): ReadonlySet<string>;
/**
 * sqlite-vec's per-column vector tables are not marked as shadow tables (their
 * names contain `_`), so they are recognized by what vec0 creates: a table
 * named after an existing vec0 table, for one of its vector columns, with
 * exactly vec0's two columns. vec0 creates that name with the vec0 table, so
 * no other table can hold it. (The stored CREATE text is not compared: Dolt
 * re-serializes it on checkout.) Writes to them are denied outside app
 * triggers (§5).
 */
export declare function isVecChunkTable(database: DatabaseLike, name: string, vecTables: ReadonlyMap<string, number>): boolean;
export declare function toDatabaseValue(value: SqlValue): unknown;
