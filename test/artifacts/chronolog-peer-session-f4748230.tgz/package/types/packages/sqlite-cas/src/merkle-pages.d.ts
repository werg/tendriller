import type { CasPartition, ContentAddressedStore } from '../../records/src/index.js';
export declare const MERKLE_PAGE_SIZE = 4096;
export declare const MERKLE_FANOUT = 64;
/**
 * Pure Merkle-paged virtual file backed by ContentAddressedStore.
 * - 4 KiB pages organized in a 64-way Merkle tree (depth 3 covers 1 GiB)
 * - Every interior node stores explicit child links in CAS so cas.reachable([dbRoot]) covers the full DB
 * - Unchanged pages stay untouched; commit() writes only dirty pages + O(log N) interior nodes
 */
export declare class MerklePageFile {
    #private;
    constructor(options: {
        readonly dbRoot: string | null;
        readonly cas: ContentAddressedStore;
        readonly partition: CasPartition;
        readonly onMissingCas: (hash: string) => never;
    });
    get byteLength(): number;
    readInto(offset: number, dest: Uint8Array): boolean;
    writeFrom(offset: number, src: Uint8Array): void;
    truncate(newSize: number): void;
    /** Commit all dirty pages into CAS and return the new 32-byte dbRoot hash. */
    commit(): string;
}
