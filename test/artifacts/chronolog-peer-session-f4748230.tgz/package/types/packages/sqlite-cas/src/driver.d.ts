import type { SqliteBuiltinDriver } from '../../materializer/src/index.js';
export declare const SQLITE_CAS_BUILTIN_ID = "sqlite-cas@1#sha256-bbc4674a5dd1d11962a8227ce5f1118e2e6ed7d00163ea92f1f35781caf46936";
export interface CreateSqliteCasDriverOptions {
    /** Optional static pre-compiled WebAssembly.Module (for Cloudflare Workers / strict CSP). */
    readonly wasmModule?: WebAssembly.Module;
}
export declare function createSqliteCasDriver(options?: CreateSqliteCasDriverOptions): Promise<SqliteBuiltinDriver>;
