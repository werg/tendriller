import type { ApplicationChange, ApplicationEvent, ApplicationEventBatch, ApplicationEventOptions, MaterializedRevision, SessionStatus } from './session-types.js';
import type { OperationInspection } from './operation.js';
export interface ForwarderReadView {
    readonly applicationId: string;
    readonly revision: MaterializedRevision;
    topic?(name: string): unknown;
    query(topic: string, input?: unknown): unknown;
    readEvents(options?: ApplicationEventOptions): ApplicationEventBatch | Promise<ApplicationEventBatch>;
    release(): void | Promise<void>;
}
export interface EventForwarderSession {
    readonly applicationId: string;
    readonly signal: AbortSignal;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
    onStatus(listener: (status: SessionStatus) => void): () => void;
    readView(options?: {
        readonly view?: 'local' | 'final';
    }): Promise<ForwarderReadView>;
    readonly operations: {
        get(id: string): {
            inspect(): OperationInspection | Promise<OperationInspection>;
        } | null | Promise<{
            inspect(): OperationInspection | Promise<OperationInspection>;
        } | null>;
    };
}
/** A private durable exporter checkpoint, not an application ordering cursor or a UI draft store. */
export interface EventForwarderCheckpoint {
    load(): string | undefined | Promise<string | undefined>;
    save(state: string): void | Promise<void>;
}
export type EventDeliveryObservation = Pick<OperationInspection, 'stored' | 'materialized' | 'retained' | 'finalized' | 'excluded'>;
export interface EventProjection {
    readonly name: string;
    readonly payload: unknown;
}
export type EventDeliveryProjection<Projected extends EventProjection> = Projected & {
    readonly observation: EventDeliveryObservation;
    readonly change: 'upsert' | 'retract';
};
export interface EventForwarderOptions<Projected extends EventProjection> {
    readonly session: EventForwarderSession;
    readonly topics?: readonly string[];
    readonly limit?: number;
    readonly view?: 'local' | 'final';
    /** Change this local exporter label when projection meaning changes. It never freezes database schema. */
    readonly scope?: string;
    readonly maxEvents?: number;
    readonly maxBytes?: number;
    readonly checkpoint: EventForwarderCheckpoint;
    readonly project: (event: ApplicationEvent, batch: ApplicationEventBatch, context: {
        readonly view: ForwarderReadView;
        readonly observation: EventDeliveryObservation;
    }) => Projected | null | undefined | Promise<Projected | null | undefined>;
    readonly deliver: (projected: EventDeliveryProjection<Projected>, event: ApplicationEvent, batch: ApplicationEventBatch, signal: AbortSignal) => void | Promise<void>;
    readonly signal?: AbortSignal;
}
/**
 * Reconciles effective snapshots by stable event ID. Late SQL outcome changes retract prior provisional
 * exports; facts can update without a new application revision. The pending ledger is durable BEFORE
 * external delivery, so lost replies retry the same identity. Delivery must be idempotent; this helper
 * does not promise exactly-once external effects or turn finality into a retention promise.
 */
export declare function forwardSessionEvents<Projected extends EventProjection>(options: EventForwarderOptions<Projected>): Promise<void>;
