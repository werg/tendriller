import type { BytesStore } from '../../records/src/index.js';
import { type SigningIdentity } from '../../authority/src/index.js';
export interface DeviceWrapKey {
    readonly publicKey: string;
    readonly privateKey: CryptoKey;
}
export interface ApplicationDevice {
    readonly identity: SigningIdentity;
    readonly wrapKey: DeviceWrapKey;
    readonly storageId: string;
    /** Small identity and verified-control metadata, independent of application data. */
    readonly store: BytesStore;
    /** Acquire the application's durable store once, only when data is actually used. */
    openStorage(): Promise<ApplicationStorage>;
    close(): void | Promise<void>;
}
export interface ApplicationStorage {
    readonly store: BytesStore;
    close(): void | Promise<void>;
}
/** Shared browser metadata can initialize the signer and its binding atomically. */
export interface DeviceMetadataStore extends BytesStore {
    initialize?(entries: readonly {
        readonly key: string;
        readonly value: Uint8Array;
    }[]): Promise<void>;
    compareAndSwap?(key: string, expected: Uint8Array | null, value: Uint8Array): Promise<boolean>;
}
/** Explicit setup can create once. Resume never replaces a missing or inconsistent signer. */
export declare function openApplicationDevice(options: {
    readonly store: DeviceMetadataStore;
    readonly create?: true;
    /** A host-managed signer is resolved on every activation and never serialized. */
    readonly managedSigner?: SigningIdentity;
    /** Optional host-managed X25519 wrap key paired with managedSigner. */
    readonly managedWrapKey?: DeviceWrapKey;
    readonly openStorage?: () => ApplicationStorage | Promise<ApplicationStorage>;
    readonly close?: () => void | Promise<void>;
}): Promise<ApplicationDevice>;
export declare function claimApplicationDevice(device: ApplicationDevice): () => void;
export declare function verifyDeviceSigner(identity: SigningIdentity): Promise<void>;
