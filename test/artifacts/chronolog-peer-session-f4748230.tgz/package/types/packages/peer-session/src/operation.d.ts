import type { OperationVisibility, TopicUpdate } from '../../protocol/src/index.js';
import type { Signed } from '../../authority/src/index.js';
import type { MaterializedRevision, WaitOptions } from './session-types.js';
export interface MaterializedOperation {
    readonly proposalId: string;
    readonly revision: MaterializedRevision;
    readonly outcome: 'accepted' | 'rejected';
    readonly rejectionCode: string | null;
    readonly rejectionDetail?: string;
}
export interface RetentionStatement {
    readonly applicationId: string;
    readonly proposalId: string;
    readonly author: string;
    readonly envelopeDigest: string;
    readonly peer: string;
    readonly storageId: string;
}
export type RetentionEvidence = Signed<RetentionStatement>;
export interface OperationInspection {
    readonly applicationId: string;
    readonly author: string;
    readonly authorTimestampMs: string | null;
    readonly proposalId: string;
    readonly operationId: string;
    readonly visibility: OperationVisibility;
    readonly stored: boolean;
    readonly pending: 'dependency' | 'key' | null;
    readonly materialized: MaterializedOperation | null;
    readonly retained: readonly RetentionEvidence[];
    readonly finalized: boolean;
    readonly excluded: boolean;
}
export interface OperationOwner {
    inspectOperation(id: string): OperationInspection;
    waitOperation(id: string, fact: 'materialized' | 'retained' | 'finalized', options?: WaitOptions): Promise<OperationInspection>;
}
export declare class ApplicationOperation {
    readonly id: string;
    readonly operationId: string;
    private readonly owner;
    readonly stored = true;
    constructor(id: string, operationId: string, owner: OperationOwner);
    inspect(): OperationInspection;
    materialized(options?: WaitOptions): Promise<MaterializedOperation>;
    retained(options?: WaitOptions): Promise<readonly RetentionEvidence[]>;
    finalized(options?: WaitOptions): Promise<MaterializedOperation>;
}
export interface ApplicationSubmission {
    readonly operationId?: string;
    readonly authorTimestampMs?: bigint;
    readonly visibility?: OperationVisibility;
    readonly updates: readonly TopicUpdate[];
}
