import type { CommandOptions as InlineCommandOptions } from './session-types.js';
import type { ApplicationSession } from './session.js';
/** Host adapter is structurally typed, portable and carries no host ordering authority. */
export declare function createApplicationBackend(session: ApplicationSession): {
    applicationId: string;
    identity: {
        readonly publicKey: string;
    };
    readonly status: import("./session-types.js").SessionStatus;
    signal: AbortSignal;
    onStatus: (listener: (status: import("./session-types.js").SessionStatus) => void) => () => void;
    submit: (input: import("./operation.js").ApplicationSubmission) => Promise<import("./operation.js").ApplicationOperation>;
    command: (name: string, input?: unknown, options?: InlineCommandOptions) => Promise<import("./operation.js").ApplicationOperation>;
    query: (name: string, input?: unknown, _options?: {
        readonly signal?: AbortSignal;
    }) => Promise<{
        readonly applicationId: string;
        readonly revision: import("./session-types.js").MaterializedRevision;
        readonly value: unknown;
    }>;
    topic: (name: string) => import("../../protocol/src/index.js").JsonValue | null;
    describe: () => Promise<import("../../authority/src/index.js").ApplicationDescription>;
    changes: (options?: {
        readonly signal?: AbortSignal;
    }) => AsyncIterable<import("./session-types.js").ApplicationChange>;
    readView: (options?: {
        readonly view?: "local" | "final";
    }) => Promise<import("./session-types.js").ApplicationReadView>;
    operations: {
        get: (idOrOperationId: string) => import("./operation.js").ApplicationOperation | null;
        retry: (idOrOperationId: string) => Promise<import("./operation.js").ApplicationOperation>;
    };
    events: {
        publish: (topic: string, payload: unknown, options?: InlineCommandOptions) => Promise<import("./operation.js").ApplicationOperation>;
        read: (options?: import("./session-types.js").ApplicationEventOptions & {
            readonly view?: "local" | "final";
        }) => import("./session-types.js").ApplicationEventBatch;
    };
};
