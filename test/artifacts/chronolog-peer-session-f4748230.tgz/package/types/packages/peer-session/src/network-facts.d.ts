import type { SessionFacts } from './session.js';
/**
 * Per-connection knowledge tracker for Chronolog v2 facts.
 * - Reconciles encrypted envelopes by `encryptedEnvelopeDigest` (never opId-only),
 *   so rewrapped envelopes for previously-undecryptable operations sync immediately.
 * - Reconciles CAS nodes by `(partition, hash)`.
 * - Reconciles public ops by sha256(rawBytes), retentions and checkpoints by recordDigest.
 */
export declare class PeerFactKnowledge {
    #private;
    get size(): number;
    remember(facts: SessionFacts): Promise<void>;
    missing(facts: SessionFacts): Promise<SessionFacts>;
}
