import type { WaitOptions as InlineWaitOptions, CommandOptions as InlineCommandOptions, MaterializedRevision } from './session-types.js';
import type { ApplicationDescription as InlineApplicationDescription } from '../../authority/src/index.js';
import type { ApplicationSession } from './session.js';
import type { OperationInspection } from './operation.js';
interface ToolOperation {
    readonly id: string;
    readonly operationId: string;
    inspect(): OperationInspection | Promise<OperationInspection>;
    materialized(options?: InlineWaitOptions): Promise<unknown>;
    retained(options?: InlineWaitOptions): Promise<unknown>;
    finalized(options?: InlineWaitOptions): Promise<unknown>;
}
interface ToolSession {
    readonly scopeOperationId?: (rawId: string) => string;
    readonly definition?: ApplicationSession['definition'];
    describe?(): InlineApplicationDescription | Promise<InlineApplicationDescription>;
    readonly applicationId: string;
    readonly identity: {
        readonly publicKey: string;
    };
    command(name: string, input: unknown, options?: InlineCommandOptions): Promise<ToolOperation>;
    query(name: string, input: unknown): Promise<unknown>;
    readonly operations: {
        retry(id: string): Promise<ToolOperation>;
        get(id: string): ToolOperation | null | Promise<ToolOperation | null>;
    };
    readView(): Promise<{
        readonly revision: MaterializedRevision;
        release(): void | Promise<void>;
    }>;
}
export interface ScopedToolRequest {
    readonly kind: 'command' | 'query' | 'inspect' | 'retry' | 'wait';
    readonly name?: string;
    readonly input?: unknown;
    readonly operationId?: string;
    readonly basedOn?: MaterializedRevision;
    readonly fact?: 'stored' | 'materialized' | 'retained' | 'finalized';
}
export interface ScopedToolContext {
    readonly signal?: AbortSignal;
    readonly caller: string;
    readonly timeoutMs?: number;
}
/** Named executable allowlists and caller-scoped idempotency cannot be widened by request input. */
export declare function createScopedApplicationTools(session: ToolSession, options?: {
    readonly commands?: readonly string[];
    readonly queries?: readonly string[];
    readonly description?: InlineApplicationDescription;
}): {
    operationId: (rawId: string, context: {
        readonly caller: string;
    }) => Promise<string>;
    list(): ({
        name: string;
        kind: "command";
        description: string;
        inputSchema: import("../../authority/src/index.js").ApplicationInputSchema;
    } | {
        name: string;
        kind: "query";
        description: string;
        inputSchema: import("../../authority/src/index.js").ApplicationInputSchema;
    })[];
    execute(request: ScopedToolRequest, context: ScopedToolContext): Promise<unknown>;
};
export {};
