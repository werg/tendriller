/** Synchronous Ed25519 verification for pure deterministic QuickJS reducers. */
export declare function verifyEd25519Sync(publicKey: Uint8Array, message: Uint8Array, signature: Uint8Array): boolean;
