import { type QuickJSWASMModule } from 'quickjs-emscripten-core';
import { type JsonValue } from '../../protocol/src/index.js';
import type { CasPartition, ContentAddressedStore } from '../../records/src/index.js';
export declare const QUICKJS_RUNTIME_ID = "quickjs-ng@0.32.0";
export declare const CRYPTO_BUILTIN_ID = "crypto@1";
export declare const CAS_BUILTIN_ID = "cas@1";
/** Uncatchable host-level signal that a required CAS chunk/module is missing locally. */
export declare class MissingDependencyError extends Error {
    readonly hash: string;
    readonly kind: 'cas' | 'module' | 'sqlite';
    readonly code: "MISSING_DEPENDENCY";
    constructor(hash: string, kind?: 'cas' | 'module' | 'sqlite');
}
export declare class OperationalTimeoutError extends Error {
    readonly code: "OPERATIONAL_TIMEOUT";
    constructor(message?: string);
}
export interface SqliteDdlAllowlist {
    readonly createTable?: boolean;
    readonly alterTable?: readonly string[];
    readonly dropTable?: readonly string[];
    readonly indexOn?: readonly string[];
    readonly createView?: boolean;
    readonly dropView?: readonly string[];
}
export interface SqliteExecOptions {
    readonly mode?: 'admin' | 'user' | 'readonly';
    readonly ddl?: SqliteDdlAllowlist;
}
export interface SqliteExecResult {
    readonly changes: number;
    readonly lastInsertRowid: number;
    readonly createdTables: readonly string[];
    readonly droppedTables: readonly string[];
    readonly createdViews?: readonly string[];
    readonly droppedViews?: readonly string[];
}
export interface SqliteQueryResult {
    readonly columns: readonly string[];
    readonly rows: readonly (readonly JsonValue[])[];
}
export interface SqliteDbHandle {
    exec(sql: string, params?: readonly JsonValue[], options?: SqliteExecOptions): SqliteExecResult;
    query(sql: string, params?: readonly JsonValue[]): SqliteQueryResult;
    validateExpr(table: string, sqlOp: 'INSERT' | 'UPDATE' | 'DELETE', expr: string): void;
    commit(): string;
    close(): void;
}
export interface SqliteBuiltinDriver {
    readonly builtinId: string;
    openDb(options: {
        readonly dbRoot: string | null;
        readonly cas: ContentAddressedStore;
        readonly partition: CasPartition;
        readonly actor: string;
        readonly opId: string;
        readonly opTimeMs: bigint;
        readonly readOnly: boolean;
        readonly onMissingCas: (hash: string) => never;
    }): SqliteDbHandle;
}
export interface QuickJsSandboxOptions {
    /** Optional static pre-compiled WebAssembly.Module (required on Cloudflare Workers). */
    readonly wasmModule?: WebAssembly.Module;
    readonly sqliteDriver?: SqliteBuiltinDriver;
    readonly watchdogMs?: number;
}
export interface ReducerInvocationInput {
    readonly imports: Readonly<Record<string, string>>;
    readonly builtins: Readonly<Record<string, string>>;
    readonly topicBindings?: Readonly<Record<string, {
        readonly module: string;
        readonly export?: string;
        readonly config?: JsonValue;
    }>>;
    readonly moduleSpecifier: string;
    readonly exportName: string;
    readonly method: 'reduce' | 'query' | 'describe';
    readonly state: JsonValue;
    readonly payload: JsonValue;
    readonly tx?: {
        readonly opId: string;
        readonly author: string;
        readonly authorTimestampMs: number;
        readonly operationId: string;
    };
    readonly topics: Readonly<Record<string, JsonValue>>;
    readonly config?: JsonValue;
    readonly cas: ContentAddressedStore;
    readonly casPartition: CasPartition;
    readonly readOnly: boolean;
    readonly maxMemoryBytes: number;
}
export type ReducerInvocationResult = {
    readonly ok: true;
    readonly value: JsonValue;
} | {
    readonly ok: false;
    readonly code: string;
    readonly detail?: string;
};
export declare function loadQuickJsModule(wasmModule?: WebAssembly.Module): Promise<QuickJSWASMModule>;
export declare class QuickJsSandbox {
    #private;
    constructor(options?: QuickJsSandboxOptions);
    get sqliteBuiltinId(): string | null;
    /**
     * Execute one deterministic reduce/query/describe call in a brand-new isolated QuickJSRuntime + Context.
     * Zero live module state is ever shared across invocations.
     */
    invoke(input: ReducerInvocationInput): Promise<ReducerInvocationResult>;
}
