import {
  claimApplicationDevice,
  epochKeyCommitmentV2,
  hpkeOpenEpochKey,
  hpkeSealEpochKey
} from "./chunk-6VPJRVPQ.mjs";
import {
  CONTENT_CHUNK_BYTES,
  MAX_BLOB_BYTES,
  MAX_BLOB_CHUNKS,
  MAX_CONTENT_BYTES,
  check,
  checkedApplicationInputSchema,
  computeIncludedSetDigest,
  decodeRecord,
  describeApplication,
  encodeRecord,
  equalRecord,
  isPrivateContentReference,
  isPublicBlobReference,
  parseFinalitySchedule,
  policyScopeId,
  putContentBytes,
  readContentBytes,
  recordDigest,
  signFinalityCheckpoint,
  signRecord,
  validateApplicationDescription,
  verifyFinalityV2,
  verifyRecord
} from "./chunk-RHNTU73B.mjs";
import {
  awaitOwnedTask
} from "./chunk-KSC4KBWO.mjs";
import {
  TopicKernel
} from "./chunk-C42CWG3S.mjs";
import {
  HPKE_SUITE,
  STANDARD_MODULE_SOURCES,
  decryptEpochPayload,
  encryptEpochPayload,
  generateX25519KeyPair,
  hpkeReceiveExportBase,
  hpkeSendExportBase
} from "./chunk-6WN33SZZ.mjs";
import {
  ContentAddressedStore,
  computeCasHash,
  decodeCasNode,
  hashCasNode
} from "./chunk-CTIAFLQ6.mjs";
import {
  assertCanonicalCbor as assertCanonicalCbor2,
  assertValidReducersConfig,
  bytesToHex as bytesToHex2,
  compareOperationOrder,
  decodeEncryptedEnvelope,
  decodeLogGenesis,
  decodeOperationCore,
  decodeSignedOperation,
  encodeEncryptedEnvelope,
  encodeLogGenesis,
  encodeSignedOperation,
  encryptedEnvelopeDigest,
  envelopeAad,
  genesisLogId,
  hexToBytes as hexToBytes2,
  isControlTopic,
  normalizeJsonValue,
  operationIdDigest,
  signOperationCore,
  verifySignedOperation
} from "./chunk-37AJJO3T.mjs";
import {
  assertCanonicalCbor,
  bytesToHex,
  concatBytes,
  encodeCanonicalCbor,
  hexToBytes,
  sha256,
  sha256Sync,
  utf8
} from "./chunk-ICYUPG2X.mjs";

// packages/signals/src/payload.ts
function assertSignalTopic(topic) {
  if (typeof topic !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._/-]*$/u.test(topic) || topic.length > 128) throw new Error("SIGNAL_TOPIC_INVALID");
}
function canonicalSignalPayload(payload) {
  let nodes = 0;
  const visit = (value, depth) => {
    if (depth > 32 || ++nodes > 4096) throw new Error("SIGNAL_PAYLOAD_TOO_COMPLEX");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw new Error("SIGNAL_PAYLOAD_INVALID");
      return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
      if (Reflect.ownKeys(value).length !== value.length + 1) throw new Error("SIGNAL_PAYLOAD_INVALID");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, i);
        if (descriptor === void 0 || !("value" in descriptor) || !descriptor.enumerable) throw new Error("SIGNAL_PAYLOAD_INVALID");
        entries.push(visit(descriptor.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    if (typeof value !== "object" || value === null || Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null || Reflect.ownKeys(value).length !== Object.keys(value).length) throw new Error("SIGNAL_PAYLOAD_INVALID");
    return `{${Object.keys(value).sort().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!("value" in descriptor)) throw new Error("SIGNAL_PAYLOAD_INVALID");
      return `${JSON.stringify(key)}:${visit(descriptor.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const result = visit(payload, 0);
  if (new TextEncoder().encode(result).length > 16384) throw new Error("SIGNAL_FRAME_TOO_LARGE");
  return result;
}

// packages/signals/src/index.ts
var SIGNAL_DOMAIN = "chronolog/signal/v1";
var SIGNAL_STREAM_DOMAIN = "chronolog/signal/v2";
var MAX_SIGNAL_BYTES = 16384;
var SignalError = class extends Error {
  constructor(code, message = code) {
    super(message);
    this.code = code;
    this.name = "SignalError";
  }
  code;
};
var SignalChannel = class {
  #options;
  #authorId;
  #session = crypto.getRandomValues(new Uint8Array(32));
  #sessions = /* @__PURE__ */ new Map();
  #subscriptions = /* @__PURE__ */ new Set();
  #routes = /* @__PURE__ */ new Set();
  /** Detached callbacks retain their quota until the actual operation settles. */
  #retiring = /* @__PURE__ */ new Set();
  #lifetime = new AbortController();
  #ttl;
  #skew;
  #maxSessions;
  #maxSequences;
  #maxRemembered;
  #maxSends;
  #maxReceives;
  #maxRoutes;
  #maxSubscriptions;
  #maxQueuedSignals;
  #maxQueuedBytes;
  #maxRetainedLatest;
  #sendTimeout;
  #verifyKeys = /* @__PURE__ */ new Map();
  #retainedLatest = /* @__PURE__ */ new Map();
  #sequence = 0;
  #sendTail = Promise.resolve();
  #pendingSends = 0;
  #pendingReceives = 0;
  #remembered = 0;
  #observedTime = 0;
  #lastPruneAt = 0;
  constructor(options) {
    if (typeof options.scope !== "string" || options.scope.length === 0 || new TextEncoder().encode(options.scope).length > 256 || !(options.identity.publicKeyBytes instanceof Uint8Array) || options.identity.publicKeyBytes.length !== 32 || typeof options.authorize !== "function") throw new SignalError("SIGNAL_CONFIGURATION_INVALID");
    const credential = typeof options.credential === "function" ? options.credential : credentialBytes(options.credential);
    this.#options = {
      ...options,
      identity: { ...options.identity, publicKeyBytes: options.identity.publicKeyBytes.slice() },
      ...credential === void 0 ? {} : { credential }
    };
    this.#authorId = bytesToHex(options.identity.publicKeyBytes);
    this.#ttl = bound(options.maxTtlMs ?? 3e4, 1, 6e4);
    this.#skew = bound(options.maxClockSkewMs ?? 2e3, 0, 1e4);
    this.#maxSessions = bound(options.maxSessions ?? 1024, 1, 65536);
    this.#maxSequences = bound(options.maxSequencesPerSession ?? 1024, 1, 65536);
    this.#maxRemembered = bound(options.maxRememberedSignals ?? 8192, 1, 1048576);
    this.#maxSends = bound(options.maxPendingSends ?? 32, 1, 1024);
    this.#maxReceives = bound(options.maxPendingReceives ?? 32, 1, 1024);
    this.#maxRoutes = bound(options.maxRoutes ?? 64, 1, 1024);
    this.#maxSubscriptions = bound(options.maxSubscriptions ?? 16, 1, 1024);
    this.#maxQueuedSignals = bound(options.maxQueuedSignals ?? 64, 1, 4096);
    this.#maxQueuedBytes = bound(options.maxQueuedBytes ?? 262144, 1, 16777216);
    this.#maxRetainedLatest = bound(options.maxRetainedLatest ?? 128, 0, 4096);
    this.#sendTimeout = bound(options.sendTimeoutMs ?? 1e4, 1, 12e4);
    if (options.trySend !== void 0) this.attachRoute({ trySend: options.trySend });
  }
  get delivery() {
    return this.#options.relay === true ? "application" : "neighbors";
  }
  attachRoute(transport) {
    this.#assertOpen();
    if (typeof transport.trySend !== "function") throw new SignalError("SIGNAL_TRANSPORT_INVALID");
    if (this.#routes.size + this.#retiring.size >= this.#maxRoutes) throw new SignalError("SIGNAL_ROUTE_QUOTA_EXCEEDED");
    const route = {
      trySend: transport.trySend.bind(transport),
      lifetime: new AbortController(),
      busy: false,
      retired: false,
      rejections: { total: 0, clockSkew: 0, expired: 0, unauthorized: 0, duplicate: 0, capacity: 0 },
      ...transport.close === void 0 ? {} : { close: transport.close.bind(transport) }
    };
    this.#routes.add(route);
    return {
      receive: (frame) => this.#enqueueReceive(frame, route),
      close: () => this.#detach(route),
      get diagnostics() {
        return { ...route.rejections };
      }
    };
  }
  send(topic, payload, options = {}) {
    try {
      if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
      this.#assertOpen();
      options.signal?.throwIfAborted();
      if (this.#routes.size === 0 && this.#options.localEcho !== true) throw new SignalError("SIGNAL_ROUTE_UNAVAILABLE");
      const routes = [...this.#routes];
      if (this.#pendingSends >= this.#maxSends) throw new SignalError("SIGNAL_BACKPRESSURE");
      assertSignalTopic(topic);
      const encodedPayload = canonicalSignalPayload(payload);
      const stream = options.stream === void 0 ? void 0 : checkedStream(options.stream);
      const ttlMs = bound(options.ttlMs ?? Math.min(5e3, this.#ttl), 1, this.#ttl, "SIGNAL_TTL_INVALID");
      const issuedAtMs = this.#now(), expiresAtMs = issuedAtMs + ttlMs;
      if (!Number.isSafeInteger(expiresAtMs)) throw new SignalError("SIGNAL_CLOCK_INVALID");
      const expiry = new AbortController();
      const timer = setTimeout(() => expiry.abort(new SignalError("SIGNAL_SEND_TIMEOUT")), Math.min(ttlMs, this.#sendTimeout));
      const signal = AbortSignal.any([this.#lifetime.signal, expiry.signal, ...options.signal === void 0 ? [] : [options.signal]]);
      this.#pendingSends += 1;
      let started = false;
      const task = this.#sendTail.then(() => {
        signal.throwIfAborted();
        started = true;
        const operation = (async () => {
          const configured = this.#options.credential;
          const credential = credentialBytes(typeof configured === "function" ? await configured(topic, { signal }) : configured);
          const authorization = { scope: this.#options.scope, authorId: this.#options.identity.publicKeyBytes.slice(), topic, credential: credential ?? null, ...stream === void 0 ? {} : { stream } };
          await this.#authorize(authorization, signal);
          if (this.#sequence >= Number.MAX_SAFE_INTEGER) throw new SignalError("SIGNAL_SEQUENCE_EXHAUSTED");
          const sequence = ++this.#sequence;
          const fields2 = [
            stream === void 0 ? 1n : 2n,
            stream === void 0 ? SIGNAL_DOMAIN : SIGNAL_STREAM_DOMAIN,
            this.#options.scope,
            this.#options.identity.publicKeyBytes,
            credential ?? null,
            this.#session,
            BigInt(sequence),
            BigInt(issuedAtMs),
            BigInt(expiresAtMs),
            topic,
            encodedPayload,
            ...stream === void 0 ? [] : [JSON.stringify(stream)]
          ];
          const signature = new Uint8Array(await crypto.subtle.sign(
            "Ed25519",
            this.#options.identity.privateKey,
            encodeCanonicalCbor(fields2).slice().buffer
          ));
          const frame = encodeCanonicalCbor([...fields2, signature]);
          if (frame.length > MAX_SIGNAL_BYTES) throw new SignalError("SIGNAL_FRAME_TOO_LARGE");
          const value = {
            scope: this.#options.scope,
            authorId: this.#authorId,
            sessionId: bytesToHex(this.#session),
            sequence,
            topic,
            payload: JSON.parse(encodedPayload),
            issuedAtMs,
            expiresAtMs,
            ...stream === void 0 ? {} : { stream }
          };
          await this.#authorize(authorization, signal);
          this.#assertFresh(value);
          if (!this.#remember(value)) throw new SignalError("SIGNAL_BACKPRESSURE");
          const local = this.#options.localEcho === true;
          if (local) {
            this.#deliver(value, frame.length);
            if (routes.length > 0) void this.#dispatch({ value, authorization, frame }, routes, signal, false).catch(() => void 0);
          }
          if (!local && !await this.#dispatch({ value, authorization, frame }, routes, signal, true)) {
            this.#forget(value);
            throw new SignalError("SIGNAL_BACKPRESSURE");
          }
          return structuredClone(value);
        })().finally(() => {
          clearTimeout(timer);
          this.#pendingSends -= 1;
        });
        return interrupted(operation, signal);
      }).finally(() => {
        if (!started) {
          clearTimeout(timer);
          this.#pendingSends -= 1;
        }
      });
      this.#sendTail = task.catch(() => void 0);
      return interrupted(task, signal);
    } catch (error) {
      return Promise.reject(error);
    }
  }
  /** Standalone receive validates and delivers without inferring a relay source. */
  receive(frame) {
    return this.#enqueueReceive(frame);
  }
  #enqueueReceive(input, route) {
    try {
      this.#assertOpen();
      if (!(input instanceof Uint8Array) || input.byteLength > MAX_SIGNAL_BYTES) throw new SignalError("SIGNAL_FRAME_TOO_LARGE");
      if (route?.lifetime.signal.aborted === true) throw new SignalError("SIGNAL_ROUTE_CLOSED");
      if (this.#pendingReceives >= this.#maxReceives) return Promise.resolve(this.#reject(route, "capacity"));
      const frame = input.slice();
      const routes = [...this.#routes].filter((attached) => attached !== route);
      this.#pendingReceives += 1;
      const expiry = new AbortController();
      const timer = setTimeout(() => expiry.abort(new SignalError("SIGNAL_RECEIVE_TIMEOUT")), this.#ttl);
      const signal = AbortSignal.any([this.#lifetime.signal, expiry.signal, ...route === void 0 ? [] : [route.lifetime.signal]]);
      const operation = (async () => {
        signal.throwIfAborted();
        const verified = await this.#verify(frame, signal, route);
        if (verified === null || !this.#remember(verified.value, route)) return null;
        this.#deliver(verified.value, frame.length);
        if (this.#options.relay === true) await this.#dispatch(verified, routes, signal, false);
        return structuredClone(verified.value);
      })().finally(() => {
        clearTimeout(timer);
        this.#pendingReceives -= 1;
      });
      return interrupted(operation, signal);
    } catch (error) {
      return Promise.reject(error);
    }
  }
  async #verify(bytes, signal, route) {
    const frame = assertCanonicalCbor(bytes, {
      maxBytes: MAX_SIGNAL_BYTES,
      maxDepth: 2,
      maxArrayItems: 13,
      maxMapItems: 0,
      maxTextBytes: MAX_SIGNAL_BYTES,
      maxBlobBytes: 1024
    });
    if (!Array.isArray(frame) || !(frame.length === 12 && frame[0] === 1n && frame[1] === SIGNAL_DOMAIN || frame.length === 13 && frame[0] === 2n && frame[1] === SIGNAL_STREAM_DOMAIN) || frame[2] !== this.#options.scope || !(frame[3] instanceof Uint8Array) || frame[3].length !== 32 || frame[4] !== null && (!(frame[4] instanceof Uint8Array) || frame[4].length > 1024) || !(frame[5] instanceof Uint8Array) || frame[5].length !== 32 || typeof frame[6] !== "bigint" || typeof frame[7] !== "bigint" || typeof frame[8] !== "bigint" || typeof frame[9] !== "string" || typeof frame[10] !== "string" || !(frame[frame.length - 1] instanceof Uint8Array) || frame[frame.length - 1].length !== 64) throw new SignalError("SIGNAL_FRAME_INVALID");
    assertSignalTopic(frame[9]);
    const stream = frame.length === 13 ? decodeStream(frame[11]) : void 0;
    const payload = JSON.parse(frame[10]);
    if (canonicalSignalPayload(payload) !== frame[10]) throw new SignalError("SIGNAL_PAYLOAD_INVALID");
    const value = {
      scope: this.#options.scope,
      authorId: bytesToHex(frame[3]),
      sessionId: bytesToHex(frame[5]),
      sequence: Number(frame[6]),
      issuedAtMs: Number(frame[7]),
      expiresAtMs: Number(frame[8]),
      topic: frame[9],
      payload,
      ...stream === void 0 ? {} : { stream }
    };
    this.#assertClockFields(value);
    let key = this.#verifyKeys.get(value.authorId);
    if (key === void 0) {
      key = await crypto.subtle.importKey("raw", frame[3].slice().buffer, "Ed25519", false, ["verify"]);
      if (this.#verifyKeys.size >= 256) {
        const oldest = this.#verifyKeys.keys().next().value;
        if (oldest !== void 0) this.#verifyKeys.delete(oldest);
      }
      this.#verifyKeys.set(value.authorId, key);
    }
    if (!await crypto.subtle.verify("Ed25519", key, frame[frame.length - 1].slice().buffer, encodeCanonicalCbor(frame.slice(0, -1)).slice().buffer)) {
      throw new SignalError("SIGNAL_SIGNATURE_INVALID");
    }
    const credential = frame[4];
    const authorization = { scope: value.scope, authorId: frame[3].slice(), topic: value.topic, credential: credential?.slice() ?? null, ...stream === void 0 ? {} : { stream } };
    if (!await this.#allowed(authorization, signal)) return this.#reject(route, "unauthorized");
    const now = this.#now();
    if (value.issuedAtMs > now + this.#skew) return this.#reject(route, "clockSkew");
    if (value.expiresAtMs <= now) return this.#reject(route, "expired");
    return { value, authorization, frame: bytes };
  }
  async #allowed(input, signal) {
    signal.throwIfAborted();
    const allowed = await this.#options.authorize(structuredClone(input), { signal });
    signal.throwIfAborted();
    return allowed;
  }
  async #authorize(input, signal) {
    if (!await this.#allowed(input, signal)) throw new SignalError("SIGNAL_UNAUTHORIZED");
  }
  async #dispatch(verified, eligible, signal, required) {
    const attached = eligible.filter((route) => !route.lifetime.signal.aborted);
    if (required && attached.length === 0) throw new SignalError("SIGNAL_ROUTE_UNAVAILABLE");
    const routes = attached.filter((route) => !route.busy);
    if (routes.length === 0) return false;
    const attempts = routes.map((route) => {
      route.busy = true;
      let handedOff = false, settled = false;
      const deadline = new AbortController();
      const timer = setTimeout(() => {
        const reason = new SignalError("SIGNAL_SEND_TIMEOUT");
        deadline.abort(reason);
        if (handedOff && !settled) this.#detach(route, true, reason);
      }, Math.max(1, Math.min(this.#sendTimeout, verified.value.expiresAtMs - this.#now())));
      const lifetime = AbortSignal.any([signal, route.lifetime.signal, deadline.signal]);
      const operation = (async () => {
        await this.#authorize(verified.authorization, lifetime);
        this.#assertFresh(verified.value);
        handedOff = true;
        const result = await route.trySend(verified.frame.slice(), { signal: lifetime });
        if (typeof result !== "boolean") {
          throw new SignalError("SIGNAL_TRANSPORT_RESULT_INVALID");
        }
        return result;
      })().catch((error) => {
        if (handedOff && (!lifetime.aborted || error !== lifetime.reason)) this.#detach(route, true, error);
        throw error;
      }).finally(() => {
        settled = true;
        route.busy = false;
        this.#retiring.delete(route);
        clearTimeout(timer);
      });
      return interrupted(operation, lifetime);
    });
    if (required) {
      const refused = new Error("Signal dispatch refused");
      try {
        return await Promise.any(attempts.map(async (attempt) => {
          if (!await attempt) throw refused;
          return true;
        }));
      } catch (error) {
        if (error instanceof AggregateError) {
          const failures = error.errors.filter((value) => value !== refused);
          if (failures.length === 0) return false;
          if (failures.length === 1) throw failures[0];
        }
        throw new SignalError("SIGNAL_SEND_FAILED");
      }
    }
    return (await Promise.allSettled(attempts)).some((result) => result.status === "fulfilled" && result.value);
  }
  #pruneRemembered(now) {
    this.#lastPruneAt = now;
    for (const [id, progress] of this.#sessions) {
      for (const [sequence, expiresAtMs] of progress.seen) if (expiresAtMs <= now) {
        progress.seen.delete(sequence);
        this.#remembered -= 1;
      }
      if (progress.seen.size === 0) this.#sessions.delete(id);
    }
  }
  #reject(route, reason) {
    if (route !== void 0) {
      route.rejections.total = Math.min(Number.MAX_SAFE_INTEGER, route.rejections.total + 1);
      route.rejections[reason] = Math.min(Number.MAX_SAFE_INTEGER, route.rejections[reason] + 1);
    }
    return null;
  }
  #remember(value, route) {
    const now = this.#now();
    const key = `${value.authorId}/${value.sessionId}`;
    let previous = this.#sessions.get(key);
    const existingExpiry = previous?.seen.get(value.sequence);
    if (existingExpiry !== void 0) {
      if (existingExpiry > now) {
        this.#reject(route, "duplicate");
        return false;
      }
      previous.seen.delete(value.sequence);
      this.#remembered -= 1;
      if (previous.seen.size === 0) {
        this.#sessions.delete(key);
        previous = void 0;
      }
    }
    if (now - this.#lastPruneAt >= 1e3 || previous === void 0 && this.#sessions.size >= this.#maxSessions || (previous?.seen.size ?? 0) >= this.#maxSequences || this.#remembered >= this.#maxRemembered) {
      this.#pruneRemembered(now);
      previous = this.#sessions.get(key);
    }
    if (previous === void 0 && this.#sessions.size >= this.#maxSessions || (previous?.seen.size ?? 0) >= this.#maxSequences || this.#remembered >= this.#maxRemembered) {
      this.#reject(route, "capacity");
      return false;
    }
    const progress = previous ?? { seen: /* @__PURE__ */ new Map() };
    progress.seen.set(value.sequence, value.expiresAtMs);
    this.#remembered += 1;
    this.#sessions.set(key, progress);
    return true;
  }
  #forget(value) {
    const key = `${value.authorId}/${value.sessionId}`, session = this.#sessions.get(key);
    if (session?.seen.delete(value.sequence) === true) this.#remembered -= 1;
    if (session?.seen.size === 0) this.#sessions.delete(key);
  }
  #deliver(value, bytes) {
    const now = this.#now();
    const streamKey = JSON.stringify([value.authorId, value.sessionId, value.topic, value.stream?.endpointId ?? null, value.stream?.endpointIncarnation ?? null, value.stream?.streamId ?? null, value.stream?.target ?? null]);
    if (this.#maxRetainedLatest > 0 && value.expiresAtMs > now) {
      const prior = this.#retainedLatest.get(streamKey);
      if (prior === void 0 || prior.value.sequence < value.sequence || prior.value.expiresAtMs <= now) {
        if (prior !== void 0) this.#retainedLatest.delete(streamKey);
        else if (this.#retainedLatest.size >= this.#maxRetainedLatest) {
          for (const [id, entry] of this.#retainedLatest) if (entry.value.expiresAtMs <= now) this.#retainedLatest.delete(id);
          if (this.#retainedLatest.size >= this.#maxRetainedLatest) {
            const oldest = this.#retainedLatest.keys().next().value;
            if (oldest !== void 0) this.#retainedLatest.delete(oldest);
          }
        }
        this.#retainedLatest.set(streamKey, { value: structuredClone(value), bytes });
      }
    }
    for (const subscriber of this.#subscriptions) {
      if (subscriber.topics !== null && !subscriber.topics.has(value.topic)) continue;
      if (subscriber.streams !== null && !subscriber.streams.some((selector) => matchesStream(value, selector))) continue;
      for (let index = subscriber.pending.length - 1; index >= 0; index -= 1) {
        if (subscriber.pending[index].value.expiresAtMs <= now) subscriber.bytes -= subscriber.pending.splice(index, 1)[0].bytes;
      }
      for (const [id, latest] of subscriber.latest) if (latest.retainThroughMs <= now) subscriber.latest.delete(id);
      const key = streamKey;
      if (subscriber.mode === "latest") {
        const previous = subscriber.latest.get(key);
        if (previous !== void 0 && previous.sequence >= value.sequence) continue;
        if (previous === void 0 && subscriber.latest.size >= this.#maxQueuedSignals) {
          this.#overflow(subscriber);
          continue;
        }
        subscriber.latest.set(key, { sequence: value.sequence, retainThroughMs: now + this.#ttl + this.#skew });
        const index = subscriber.pending.findIndex((item) => item.key === key);
        if (index !== -1) subscriber.bytes -= subscriber.pending.splice(index, 1)[0].bytes;
      }
      if (subscriber.pending.length >= this.#maxQueuedSignals || subscriber.bytes + bytes > this.#maxQueuedBytes) {
        this.#overflow(subscriber);
      } else {
        subscriber.pending.push({ value: structuredClone(value), bytes, key });
        subscriber.bytes += bytes;
      }
      subscriber.wake?.();
    }
  }
  #overflow(subscriber) {
    subscriber.error = new SignalError("SIGNAL_SUBSCRIPTION_OVERFLOW");
    subscriber.pending.length = 0;
    subscriber.bytes = 0;
    subscriber.latest.clear();
    subscriber.clean();
    this.#subscriptions.delete(subscriber);
    subscriber.wake?.();
  }
  subscribe(options = {}) {
    if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
    const self = this;
    return { [Symbol.asyncIterator]() {
      const controller = new AbortController();
      const signal = options.signal === void 0 ? controller.signal : AbortSignal.any([controller.signal, options.signal]);
      const iterator = self.#subscribe({ ...options, signal });
      return {
        next: () => iterator.next(),
        async return() {
          controller.abort();
          return iterator.return();
        },
        async throw(error) {
          controller.abort();
          return iterator.throw(error);
        }
      };
    } };
  }
  async *#subscribe(options) {
    this.#assertOpen();
    if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
    const mode = options.mode ?? "all";
    if (mode !== "all" && mode !== "latest") throw new SignalError("SIGNAL_SUBSCRIPTION_MODE_INVALID");
    if (options.topics !== void 0) {
      if (!Array.isArray(options.topics) || options.topics.length > 64) throw new SignalError("SIGNAL_TOPIC_FILTER_TOO_LARGE");
      for (const topic of options.topics) {
        if (typeof topic !== "string") throw new SignalError("SIGNAL_TOPIC_FILTER_INVALID");
        assertSignalTopic(topic);
      }
    }
    const streams = options.streams === void 0 ? null : checkedSelectors(options.streams);
    if (this.#subscriptions.size >= this.#maxSubscriptions) throw new SignalError("SIGNAL_SUBSCRIPTION_QUOTA_EXCEEDED");
    const subscriber = {
      topics: options.topics === void 0 ? null : new Set(options.topics),
      streams,
      mode,
      pending: [],
      latest: /* @__PURE__ */ new Map(),
      bytes: 0,
      error: null,
      wake: null,
      clean: () => void 0
    };
    if (options.includeLatest === true) {
      if (mode !== "latest") throw new SignalError("SIGNAL_SUBSCRIPTION_MODE_INVALID");
      const now = this.#now();
      for (const [key, entry] of this.#retainedLatest) {
        if (entry.value.expiresAtMs <= now) {
          this.#retainedLatest.delete(key);
          continue;
        }
        if (subscriber.topics !== null && !subscriber.topics.has(entry.value.topic)) continue;
        if (subscriber.streams !== null && !subscriber.streams.some((selector) => matchesStream(entry.value, selector))) continue;
        if (subscriber.pending.length >= this.#maxQueuedSignals || subscriber.bytes + entry.bytes > this.#maxQueuedBytes) break;
        subscriber.latest.set(key, { sequence: entry.value.sequence, retainThroughMs: now + this.#ttl + this.#skew });
        subscriber.pending.push({ value: structuredClone(entry.value), bytes: entry.bytes, key });
        subscriber.bytes += entry.bytes;
      }
    }
    this.#subscriptions.add(subscriber);
    const signal = options.signal;
    const abort = () => {
      subscriber.pending.length = 0;
      subscriber.bytes = 0;
      subscriber.latest.clear();
      subscriber.clean();
      this.#subscriptions.delete(subscriber);
      subscriber.wake?.();
    };
    subscriber.clean = () => signal?.removeEventListener("abort", abort);
    signal?.addEventListener("abort", abort, { once: true });
    try {
      while (!this.#lifetime.signal.aborted && signal?.aborted !== true) {
        if (subscriber.error !== null) throw subscriber.error;
        const item = subscriber.pending.shift();
        if (item !== void 0) {
          subscriber.bytes -= item.bytes;
          if (item.value.expiresAtMs > this.#now()) yield structuredClone(item.value);
        } else {
          await new Promise((resolve) => {
            subscriber.wake = resolve;
            if (this.#lifetime.signal.aborted || signal?.aborted === true || subscriber.pending.length > 0 || subscriber.error !== null) resolve();
          });
          subscriber.wake = null;
        }
      }
    } finally {
      subscriber.clean();
      this.#subscriptions.delete(subscriber);
    }
  }
  close() {
    if (this.#lifetime.signal.aborted) return;
    this.#lifetime.abort(new SignalError("SIGNAL_CHANNEL_CLOSED"));
    for (const route of this.#routes) this.#detach(route);
    for (const subscriber of this.#subscriptions) {
      subscriber.pending.length = 0;
      subscriber.latest.clear();
      subscriber.clean();
      subscriber.wake?.();
    }
    this.#subscriptions.clear();
    this.#sessions.clear();
    this.#retainedLatest.clear();
    this.#verifyKeys.clear();
    this.#remembered = 0;
  }
  #detach(route, retire = false, reason = new SignalError("SIGNAL_ROUTE_CLOSED")) {
    if (route.busy) this.#retiring.add(route);
    this.#routes.delete(route);
    route.lifetime.abort(reason);
    if (retire && !route.retired) {
      route.retired = true;
      try {
        void Promise.resolve(route.close?.(reason)).catch(() => void 0);
      } catch {
      }
    }
  }
  #assertOpen() {
    this.#lifetime.signal.throwIfAborted();
  }
  #assertFresh(value) {
    this.#assertClock(value);
    if (value.expiresAtMs <= this.#now()) throw new SignalError("SIGNAL_EXPIRED");
  }
  #assertClockFields(value) {
    if (!Number.isSafeInteger(value.sequence) || value.sequence < 1 || !Number.isSafeInteger(value.issuedAtMs) || value.issuedAtMs < 0 || !Number.isSafeInteger(value.expiresAtMs) || value.expiresAtMs <= value.issuedAtMs || value.expiresAtMs - value.issuedAtMs > this.#ttl) {
      throw new SignalError("SIGNAL_CLOCK_INVALID");
    }
  }
  #assertClock(value) {
    this.#assertClockFields(value);
    if (value.issuedAtMs > this.#now() + this.#skew) throw new SignalError("SIGNAL_CLOCK_INVALID");
  }
  #now() {
    const now = bound(this.#options.now?.() ?? Date.now(), 0, Number.MAX_SAFE_INTEGER, "SIGNAL_CLOCK_INVALID");
    this.#observedTime = Math.max(this.#observedTime, now);
    return this.#observedTime;
  }
};
function credentialBytes(value) {
  if (value === void 0) return void 0;
  if (!(value instanceof Uint8Array) || value.length > 1024) throw new SignalError("SIGNAL_CREDENTIAL_INVALID");
  return value.slice();
}
function bound(value, minimum, maximum, code = "SIGNAL_BOUNDS_INVALID") {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) throw new SignalError(code);
  return value;
}
function interrupted(operation, signal) {
  return new Promise((resolve, reject) => {
    const abort = () => {
      reject(signal.reason);
      signal.removeEventListener("abort", abort);
    };
    signal.addEventListener("abort", abort, { once: true });
    void operation.then(resolve, reject).finally(() => signal.removeEventListener("abort", abort));
    if (signal.aborted) abort();
  });
}
function checkedStream(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !["streamId", "endpointId", "endpointIncarnation", "target", "stateRoot", "supersedesStream"].includes(key)) || !boundedLabel(value.streamId) || value.endpointId === void 0 !== (value.endpointIncarnation === void 0) || value.endpointId !== void 0 && !boundedLabel(value.endpointId) || value.endpointIncarnation !== void 0 && !boundedLabel(value.endpointIncarnation) || value.target !== void 0 && !boundedLabel(value.target) || value.stateRoot !== void 0 && !/^[0-9a-f]{64}$/u.test(value.stateRoot) || value.supersedesStream !== void 0 && !boundedLabel(value.supersedesStream)) throw new SignalError("SIGNAL_STREAM_INVALID");
  return {
    streamId: value.streamId,
    ...value.endpointId === void 0 ? {} : { endpointId: value.endpointId, endpointIncarnation: value.endpointIncarnation },
    ...value.target === void 0 ? {} : { target: value.target },
    ...value.stateRoot === void 0 ? {} : { stateRoot: value.stateRoot },
    ...value.supersedesStream === void 0 ? {} : { supersedesStream: value.supersedesStream }
  };
}
function decodeStream(value) {
  if (typeof value !== "string" || value.length > 2048) throw new SignalError("SIGNAL_STREAM_INVALID");
  let parsed;
  try {
    parsed = JSON.parse(value);
  } catch {
    throw new SignalError("SIGNAL_STREAM_INVALID");
  }
  const stream = checkedStream(parsed);
  if (JSON.stringify(stream) !== value) throw new SignalError("SIGNAL_STREAM_INVALID");
  return stream;
}
function boundedLabel(value) {
  return typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._:/@-]{0,127}$/u.test(value);
}
function checkedSelectors(value) {
  const keys = ["authorId", "sessionId", "streamId", "endpointId", "endpointIncarnation", "target"];
  if (!Array.isArray(value) || value.length > 64 || value.some((selector) => selector === null || typeof selector !== "object" || Array.isArray(selector) || Object.entries(selector).some(([key, item]) => !keys.includes(key) || !boundedLabel(item)))) {
    throw new SignalError("SIGNAL_STREAM_FILTER_INVALID");
  }
  return structuredClone(value);
}
function matchesStream(value, selector) {
  return (selector.authorId === void 0 || selector.authorId === value.authorId) && (selector.sessionId === void 0 || selector.sessionId === value.sessionId) && (selector.streamId === void 0 || selector.streamId === value.stream?.streamId) && (selector.endpointId === void 0 || selector.endpointId === value.stream?.endpointId) && (selector.endpointIncarnation === void 0 || selector.endpointIncarnation === value.stream?.endpointIncarnation) && (selector.target === void 0 || selector.target === value.stream?.target);
}

// packages/peer-session/src/content.ts
var MAX_CONTENT_CHUNKS = MAX_CONTENT_BYTES / CONTENT_CHUNK_BYTES;
var MAX_CONTENT_ENCRYPTED_CHUNK_BYTES = CONTENT_CHUNK_BYTES * 2 + 1024;
var MAX_CONTENT_MANIFEST_BYTES = 256 * 1024;
var digest = (value) => typeof value === "string" && /^[0-9a-f]{64}$/u.test(value);
var stageId = (value) => typeof value === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u.test(value);
function object(value, keys) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), "CONTENT_SHAPE_INVALID");
}
function assertReferenceBody(value) {
  object(value, ["profile", "applicationId", "epoch", "bytes", "mediaType"]);
  check(value.profile === "authored-content-v1" && digest(value.applicationId) && Number.isSafeInteger(value.epoch) && Number(value.epoch) >= 0 && Number.isSafeInteger(value.bytes) && Number(value.bytes) >= 0 && Number(value.bytes) <= MAX_CONTENT_BYTES && typeof value.mediaType === "string" && value.mediaType.length > 0 && value.mediaType.length <= 256 && /^[\x20-\x7e]+$/u.test(value.mediaType), "CONTENT_REFERENCE_INVALID");
}
function assertContentReference(value) {
  object(value, ["profile", "applicationId", "id", "epoch", "bytes", "mediaType"]);
  check(digest(value.id), "CONTENT_REFERENCE_INVALID");
  const { id: _id, ...body2 } = value;
  assertReferenceBody(body2);
}
function assertContentManifest(value) {
  object(value, ["stageId", "reference", "chunks"]);
  check(stageId(value.stageId), "CONTENT_MANIFEST_INVALID");
  assertReferenceBody(value.reference);
  check(Array.isArray(value.chunks) && value.chunks.length <= MAX_CONTENT_CHUNKS && value.chunks.length === Math.ceil(value.reference.bytes / CONTENT_CHUNK_BYTES), "CONTENT_MANIFEST_INVALID");
  for (const chunk of value.chunks) {
    object(chunk, ["hash", "bytes"]);
    check(digest(chunk.hash) && Number.isSafeInteger(chunk.bytes) && Number(chunk.bytes) > 0 && Number(chunk.bytes) <= MAX_CONTENT_ENCRYPTED_CHUNK_BYTES, "CONTENT_MANIFEST_INVALID");
  }
  check(encodeRecord(value).length <= MAX_CONTENT_MANIFEST_BYTES, "CONTENT_MANIFEST_INVALID");
}
function assertContentRetention(value) {
  object(value, ["payload", "signer", "signature"]);
  check(digest(value.signer) && typeof value.signature === "string" && /^[0-9a-f]{128}$/u.test(value.signature), "CONTENT_RETENTION_INVALID");
  object(value.payload, ["reference", "peer", "storageId"]);
  assertContentReference(value.payload.reference);
  check(value.payload.peer === value.signer && typeof value.payload.storageId === "string" && value.payload.storageId.length > 0 && value.payload.storageId.length <= 256, "CONTENT_RETENTION_INVALID");
}
function assertBlobInfo(value) {
  object(value, ["hash", "bytes"]);
  check(digest(value.hash) && Number.isSafeInteger(value.bytes) && Number(value.bytes) >= 0 && Number(value.bytes) <= MAX_BLOB_BYTES, "CONTENT_BLOB_INVALID");
}
function body(reference) {
  const { id: _id, ...rest } = reference;
  return rest;
}
function envelope(bytes, epoch, plaintextBytes) {
  check(bytes.length > 0 && bytes.length <= MAX_CONTENT_ENCRYPTED_CHUNK_BYTES, "CONTENT_CHUNK_INVALID");
  const value = decodeRecord(bytes);
  object(value, ["epoch", "nonce", "ciphertext"]);
  check(value.epoch === BigInt(epoch) && value.nonce instanceof Uint8Array && value.nonce.length === 12 && value.ciphertext instanceof Uint8Array && value.ciphertext.length === plaintextBytes + 16, "CONTENT_CHUNK_INVALID");
  return value;
}
var ApplicationContent = class {
  #sources = /* @__PURE__ */ new Map();
  #reads = /* @__PURE__ */ new Map();
  #lifetime = new AbortController();
  #prefix;
  #options;
  #cacheIndex = null;
  #tail = Promise.resolve();
  constructor(options) {
    check(typeof options.storageId === "string" && options.storageId.length > 0 && options.storageId.length <= 256, "CONTENT_STORAGE_ID_INVALID");
    this.#options = options;
    this.#prefix = `content/${options.authority.applicationId}`;
  }
  async #loadCacheIndex() {
    if (this.#cacheIndex !== null) return this.#cacheIndex;
    const map = /* @__PURE__ */ new Map();
    const raw = await this.#options.store.get(`${this.#prefix}/cache-index`);
    if (raw !== null && raw.length > 0) {
      try {
        const list = decodeRecord(raw);
        if (Array.isArray(list)) {
          for (const item of list) {
            if (item && typeof item.key === "string" && (item.kind === "public" || item.kind === "private") && typeof item.bytes === "number") {
              map.set(`${item.kind}:${item.key}`, { ...item, pinned: Boolean(item.pinned) });
            }
          }
        }
      } catch {
      }
    }
    this.#cacheIndex = map;
    return map;
  }
  async #saveCacheIndex(map) {
    await this.#options.store.put(`${this.#prefix}/cache-index`, encodeRecord([...map.values()]));
  }
  async #touchCacheEntry(kind, key, bytes, reference) {
    const map = await this.#loadCacheIndex();
    const id = `${kind}:${key}`;
    const prev = map.get(id);
    map.set(id, {
      kind,
      key,
      bytes,
      lastAccessMs: Date.now(),
      pinned: prev?.pinned ?? false,
      ...reference !== void 0 ? { reference } : prev?.reference !== void 0 ? { reference: prev.reference } : {}
    });
    await this.#saveCacheIndex(map);
  }
  async #dropCacheEntry(kind, key) {
    const map = await this.#loadCacheIndex();
    if (map.delete(`${kind}:${key}`)) {
      await this.#saveCacheIndex(map);
    }
  }
  #cacheIdOf(target) {
    if (typeof target === "string") {
      check(digest(target), "CONTENT_BLOB_INVALID");
      return { kind: "public", key: target };
    }
    if (isPublicBlobReference(target)) {
      check(digest(target.hash), "CONTENT_BLOB_INVALID");
      return { kind: "public", key: target.hash };
    }
    if (isPrivateContentReference(target)) {
      const ref = this.#reference(target);
      return { kind: "private", key: ref.id };
    }
    throw new Error("CONTENT_REFERENCE_INVALID");
  }
  #reader() {
    this.#lifetime.signal.throwIfAborted();
    check(this.#options.authority.isReader(this.#options.identity.publicKey), "CONTENT_READER_REQUIRED");
  }
  #reference(input) {
    assertContentReference(input);
    check(input.applicationId === this.#options.authority.applicationId, "CONTENT_SCOPE_INVALID");
    return { ...input };
  }
  #serial(work) {
    const task = this.#tail.then(() => {
      this.#lifetime.signal.throwIfAborted();
      return work();
    });
    this.#tail = task.catch(() => void 0);
    return task;
  }
  #scopeKey(key, options) {
    this.#reader();
    options.signal?.throwIfAborted();
    const controller = new AbortController();
    let reads = this.#reads.get(key);
    if (reads === void 0) {
      reads = /* @__PURE__ */ new Set();
      this.#reads.set(key, reads);
    }
    reads.add(controller);
    const signal = AbortSignal.any([this.#lifetime.signal, controller.signal, ...options.signal === void 0 ? [] : [options.signal]]);
    signal.throwIfAborted();
    return { signal, release: () => {
      reads.delete(controller);
      if (reads.size === 0) this.#reads.delete(key);
    } };
  }
  #readScope(reference, options) {
    return this.#scopeKey(reference.id, options);
  }
  #blobScope(hash, options) {
    return this.#scopeKey(`blob:${hash}`, options);
  }
  attachSource(id, source2) {
    this.#lifetime.signal.throwIfAborted();
    check(typeof id === "string" && id.length > 0 && id.length <= 256 && this.#sources.size < 8 && !this.#sources.has(id), "CONTENT_SOURCE_LIMIT");
    this.#sources.set(id, source2);
    let detached = false;
    return () => {
      if (!detached) {
        detached = true;
        this.#sources.delete(id);
      }
    };
  }
  async stage(options) {
    this.#reader();
    const id = crypto.randomUUID(), epoch = this.#options.authority.currentEpoch();
    const reference = { profile: "authored-content-v1", applicationId: this.#options.authority.applicationId, epoch, bytes: options.bytes, mediaType: options.mediaType ?? "application/octet-stream" };
    assertReferenceBody(reference);
    check(this.#options.authority.epochKey(epoch) !== null, "CONTENT_KEY_MISSING");
    await this.#serial(() => this.#options.store.put(`${this.#prefix}/stage/${id}`, encodeRecord({ stageId: id, reference, committed: null, discarded: false })));
    return this.resumeUpload(id);
  }
  async resumeUpload(id) {
    this.#reader();
    check(stageId(id), "CONTENT_STAGE_INVALID");
    const key = `${this.#prefix}/stage/${id}`;
    const readStage = async () => {
      this.#reader();
      const raw = await this.#options.store.get(key);
      check(raw !== null, "CONTENT_STAGE_MISSING");
      const stage = decodeRecord(raw);
      object(stage, ["stageId", "reference", "committed", "discarded"]);
      assertReferenceBody(stage.reference);
      check(stage.stageId === id && stage.reference.applicationId === this.#options.authority.applicationId && typeof stage.discarded === "boolean", "CONTENT_STAGE_INVALID");
      if (stage.committed !== null) {
        assertContentReference(stage.committed);
        check(equalRecord(body(stage.committed), stage.reference), "CONTENT_STAGE_INVALID");
      }
      check(!stage.discarded, "CONTENT_STAGE_DISCARDED");
      return stage;
    };
    const first = await readStage(), count = Math.ceil(first.reference.bytes / CONTENT_CHUNK_BYTES);
    return {
      id,
      write: (index, input) => {
        check(input instanceof Uint8Array && input.length <= CONTENT_CHUNK_BYTES, "CONTENT_CHUNK_SIZE_INVALID");
        const bytes = input.slice();
        return this.#serial(async () => {
          const stage = await readStage();
          check(stage.committed === null && Number.isSafeInteger(index) && index >= 0 && index < count && bytes.length === Math.min(CONTENT_CHUNK_BYTES, stage.reference.bytes - index * CONTENT_CHUNK_BYTES), "CONTENT_CHUNK_SIZE_INVALID");
          const epochKey = this.#options.authority.epochKey(stage.reference.epoch);
          check(epochKey !== null, "CONTENT_KEY_MISSING");
          const aad = encodeRecord([this.#prefix, id, index]), existing = await this.#options.store.get(`${key}/chunk/${index}`);
          if (existing !== null) {
            const plaintext = await decryptEpochPayload(epochKey, envelope(existing, stage.reference.epoch, bytes.length), aad);
            check(equalRecord(plaintext, bytes), "CONTENT_CHUNK_CONFLICT");
            return;
          }
          const encrypted = encodeRecord(await encryptEpochPayload(epochKey, BigInt(stage.reference.epoch), bytes, aad));
          await this.#options.store.put(`${key}/chunk/${index}`, encrypted);
        });
      },
      progress: () => this.#serial(async () => {
        const stage = await readStage(), missingChunks = [];
        let storedBytes = 0;
        for (let index = 0; index < count; index++) {
          const chunk = await this.#options.store.get(`${key}/chunk/${index}`);
          if (chunk === null) missingChunks.push(index);
          else {
            envelope(chunk, stage.reference.epoch, Math.min(CONTENT_CHUNK_BYTES, stage.reference.bytes - index * CONTENT_CHUNK_BYTES));
            storedBytes += Math.min(CONTENT_CHUNK_BYTES, stage.reference.bytes - index * CONTENT_CHUNK_BYTES);
          }
        }
        return { bytes: stage.reference.bytes, storedBytes, missingChunks };
      }),
      commit: () => this.#serial(async () => {
        const stage = await readStage();
        if (stage.committed !== null) return structuredClone(stage.committed);
        const chunks = [];
        const epochKey = this.#options.authority.epochKey(stage.reference.epoch);
        check(epochKey !== null, "CONTENT_KEY_MISSING");
        for (let index = 0; index < count; index++) {
          const bytes = await this.#options.store.get(`${key}/chunk/${index}`);
          check(bytes !== null, "CONTENT_INCOMPLETE");
          await decryptEpochPayload(epochKey, envelope(bytes, stage.reference.epoch, Math.min(CONTENT_CHUNK_BYTES, stage.reference.bytes - index * CONTENT_CHUNK_BYTES)), encodeRecord([this.#prefix, id, index]));
          const hash = bytesToHex(await sha256(bytes));
          await this.#options.store.put(`${this.#prefix}/chunk/${hash}`, bytes);
          chunks.push({ hash, bytes: bytes.length });
        }
        const manifest = { stageId: id, reference: stage.reference, chunks };
        const reference = { ...stage.reference, id: await recordDigest(manifest) };
        await this.#options.store.put(`${this.#prefix}/manifest/${reference.id}`, encodeRecord(manifest));
        await this.#options.store.put(key, encodeRecord({ ...stage, committed: reference }));
        await this.#touchCacheEntry("private", reference.id, reference.bytes, reference);
        return reference;
      }),
      discard: () => this.#serial(async () => {
        const raw = await this.#options.store.get(key);
        if (raw === null) return;
        const stage = decodeRecord(raw);
        await this.#options.store.put(key, encodeRecord({ ...stage, discarded: true }));
        for (let index = 0; index < count; index++) await this.#remove(`${key}/chunk/${index}`);
      })
    };
  }
  async #remove(key) {
    if (this.#options.store.delete !== void 0) await this.#options.store.delete(key);
    else await this.#options.store.put(key, new Uint8Array());
  }
  async #validateManifest(manifest, reference) {
    assertContentManifest(manifest);
    check(equalRecord(manifest.reference, body(reference)) && await recordDigest(manifest) === reference.id, "CONTENT_MANIFEST_INVALID");
  }
  async #manifest(reference, signal, localOnly = false) {
    signal.throwIfAborted();
    this.#reader();
    const raw = await awaitOwnedTask(signal, () => this.#options.store.get(`${this.#prefix}/manifest/${reference.id}`));
    if (raw !== null && raw.length > 0) {
      check(raw.length <= MAX_CONTENT_MANIFEST_BYTES, "CONTENT_MANIFEST_INVALID");
      const manifest = decodeRecord(raw);
      await this.#validateManifest(manifest, reference);
      signal.throwIfAborted();
      return manifest;
    }
    if (localOnly) return null;
    let failure;
    for (const source2 of [...this.#sources.values()]) {
      try {
        const candidate = await awaitOwnedTask(signal, () => source2.manifest(reference, { signal }));
        if (candidate === null) continue;
        assertContentManifest(candidate);
        const manifest = structuredClone(candidate);
        await this.#validateManifest(manifest, reference);
        await this.#serial(async () => {
          signal.throwIfAborted();
          this.#reader();
          await this.#options.store.put(`${this.#prefix}/manifest/${reference.id}`, encodeRecord(manifest));
        });
        return manifest;
      } catch (error) {
        signal.throwIfAborted();
        failure = error;
      }
    }
    if (failure !== void 0) throw failure instanceof Error ? failure : new Error("CONTENT_SOURCE_FAILED", { cause: failure });
    throw new Error("CONTENT_MANIFEST_MISSING");
  }
  async #chunk(reference, manifest, index, signal, localOnly = false) {
    signal.throwIfAborted();
    this.#reader();
    const descriptor = manifest.chunks[index];
    check(descriptor !== void 0, "CONTENT_CHUNK_INDEX_INVALID");
    const valid = async (bytes) => {
      check(bytes instanceof Uint8Array && bytes.length === descriptor.bytes && bytes.length <= MAX_CONTENT_ENCRYPTED_CHUNK_BYTES && bytesToHex(await sha256(bytes)) === descriptor.hash, "CONTENT_CHUNK_INVALID");
      envelope(bytes, reference.epoch, Math.min(CONTENT_CHUNK_BYTES, reference.bytes - index * CONTENT_CHUNK_BYTES));
    };
    const stored = await awaitOwnedTask(signal, () => this.#options.store.get(`${this.#prefix}/chunk/${descriptor.hash}`));
    if (stored !== null && stored.length > 0) {
      await valid(stored);
      signal.throwIfAborted();
      return stored;
    }
    if (localOnly) return null;
    let failure;
    for (const source2 of [...this.#sources.values()]) {
      try {
        const candidate = await awaitOwnedTask(signal, () => source2.chunk(reference, index, { signal }));
        if (candidate === null) continue;
        check(candidate instanceof Uint8Array && candidate.length <= MAX_CONTENT_ENCRYPTED_CHUNK_BYTES, "CONTENT_CHUNK_INVALID");
        const bytes = candidate.slice();
        await valid(bytes);
        await this.#serial(async () => {
          signal.throwIfAborted();
          this.#reader();
          await this.#options.store.put(`${this.#prefix}/chunk/${descriptor.hash}`, bytes);
        });
        return bytes.slice();
      } catch (error) {
        signal.throwIfAborted();
        failure = error;
      }
    }
    if (failure !== void 0) throw failure instanceof Error ? failure : new Error("CONTENT_SOURCE_FAILED", { cause: failure });
    throw new Error("CONTENT_CHUNK_MISSING");
  }
  async *read(input, options = {}) {
    const reference = this.#reference(input), scope = this.#readScope(reference, options);
    try {
      const manifest = await this.#manifest(reference, scope.signal);
      check(manifest !== null, "CONTENT_MANIFEST_MISSING");
      const key = this.#options.authority.epochKey(reference.epoch);
      check(key !== null, "CONTENT_KEY_MISSING");
      for (let index = 0; index < manifest.chunks.length; index++) {
        const bytes = await this.#chunk(reference, manifest, index, scope.signal);
        check(bytes !== null, "CONTENT_CHUNK_MISSING");
        const plaintext = await decryptEpochPayload(key, envelope(bytes, reference.epoch, Math.min(CONTENT_CHUNK_BYTES, reference.bytes - index * CONTENT_CHUNK_BYTES)), encodeRecord([this.#prefix, manifest.stageId, index]));
        scope.signal.throwIfAborted();
        this.#reader();
        yield plaintext;
      }
    } finally {
      scope.release();
    }
  }
  async #receipt(reference, signal) {
    const receipt = await signRecord("content-retention", { reference, peer: this.#options.identity.publicKey, storageId: this.#options.storageId }, this.#options.identity);
    signal.throwIfAborted();
    this.#reader();
    return receipt;
  }
  /** Transfer/check the entire encrypted object before claiming local retention. */
  async retain(input, options = {}) {
    const reference = this.#reference(input), scope = this.#readScope(reference, options);
    try {
      const manifest = await this.#manifest(reference, scope.signal);
      check(manifest !== null, "CONTENT_MANIFEST_MISSING");
      for (let index = 0; index < manifest.chunks.length; index++) await this.#chunk(reference, manifest, index, scope.signal);
      return await this.#receipt(reference, scope.signal);
    } finally {
      scope.release();
    }
  }
  async verifyRetention(input, receipt, expectedPeer) {
    const reference = this.#reference(input);
    assertContentRetention(receipt);
    check(equalRecord(receipt.payload.reference, reference) && (expectedPeer === void 0 || receipt.signer === expectedPeer) && this.#options.authority.isReader(receipt.signer), "CONTENT_RETENTION_INVALID");
    await verifyRecord("content-retention", receipt, expectedPeer);
  }
  /** Ask attached sources to retain the object; these signed availability facts are not finality. */
  async retention(input, options = {}) {
    const reference = this.#reference(input), scope = this.#readScope(reference, options);
    try {
      const receipts = new Map((await this.retained(reference)).map((receipt) => [receipt.signer, receipt]));
      for (const source2 of [...this.#sources.values()]) {
        if (source2.retained === void 0) continue;
        const receipt = await awaitOwnedTask(scope.signal, () => source2.retained(reference, { signal: scope.signal }));
        await this.verifyRetention(reference, receipt);
        if (receipt.signer === this.#options.identity.publicKey || receipt.payload.storageId === this.#options.storageId) continue;
        check(receipts.size < 8 || receipts.has(receipt.signer), "CONTENT_RETENTION_LIMIT");
        receipts.set(receipt.signer, structuredClone(receipt));
        await this.#serial(async () => {
          scope.signal.throwIfAborted();
          const stored = new Map((await this.retained(reference)).map((value) => [value.signer, value]));
          check(stored.size < 8 || stored.has(receipt.signer), "CONTENT_RETENTION_LIMIT");
          stored.set(receipt.signer, structuredClone(receipt));
          await this.#options.store.put(`${this.#prefix}/retentions/${reference.id}`, encodeRecord([...stored.values()]));
        });
      }
      scope.signal.throwIfAborted();
      return await this.retained(reference);
    } finally {
      scope.release();
    }
  }
  async retained(input) {
    this.#reader();
    const reference = this.#reference(input);
    const raw = await this.#options.store.get(`${this.#prefix}/retentions/${reference.id}`);
    if (raw === null || raw.length === 0) return [];
    check(raw.length <= 16 * 1024, "CONTENT_RETENTION_LIMIT");
    const receipts = decodeRecord(raw);
    check(Array.isArray(receipts) && receipts.length <= 8, "CONTENT_RETENTION_LIMIT");
    for (const receipt of receipts) await this.verifyRetention(reference, receipt);
    return receipts.filter((receipt) => receipt.signer !== this.#options.identity.publicKey && receipt.payload.storageId !== this.#options.storageId);
  }
  async discard(input) {
    this.#reader();
    const reference = this.#reference(input);
    for (const read of this.#reads.get(reference.id) ?? []) read.abort(new Error("CONTENT_DISCARDED"));
    await this.#serial(async () => {
      const manifest = await this.#manifest(reference, this.#lifetime.signal, true);
      await this.#remove(`${this.#prefix}/manifest/${reference.id}`);
      await this.#remove(`${this.#prefix}/retentions/${reference.id}`);
      for (const chunk of manifest?.chunks ?? []) await this.#remove(`${this.#prefix}/chunk/${chunk.hash}`);
      await this.#dropCacheEntry("private", reference.id);
    });
  }
  async #localBlobInfo(hash, signal) {
    signal.throwIfAborted();
    this.#reader();
    const raw = await awaitOwnedTask(signal, () => this.#options.store.get(`${this.#prefix}/blob/${hash}/meta`));
    if (raw === null || raw.length === 0) return null;
    check(raw.length <= 1024, "CONTENT_BLOB_INVALID");
    const info = decodeRecord(raw);
    assertBlobInfo(info);
    check(info.hash === hash, "CONTENT_BLOB_INVALID");
    signal.throwIfAborted();
    return info;
  }
  async #localBlobChunk(hash, info, index, signal) {
    signal.throwIfAborted();
    this.#reader();
    const count = Math.ceil(info.bytes / CONTENT_CHUNK_BYTES);
    check(Number.isSafeInteger(index) && index >= 0 && index < count, "CONTENT_CHUNK_INDEX_INVALID");
    const expectedLen = Math.min(CONTENT_CHUNK_BYTES, info.bytes - index * CONTENT_CHUNK_BYTES);
    const stored = await awaitOwnedTask(signal, () => this.#options.store.get(`${this.#prefix}/blob/${hash}/chunk/${index}`));
    if (stored === null || stored.length === 0) return null;
    check(stored.length === expectedLen, "CONTENT_BLOB_INVALID");
    signal.throwIfAborted();
    return stored.slice();
  }
  async #storeLocalBlob(hash, bytes, signal) {
    const info = { hash, bytes: bytes.byteLength };
    await this.#serial(async () => {
      signal.throwIfAborted();
      this.#reader();
      const count = Math.ceil(bytes.byteLength / CONTENT_CHUNK_BYTES);
      for (let index = 0; index < count; index++) {
        signal.throwIfAborted();
        const chunk = bytes.subarray(index * CONTENT_CHUNK_BYTES, Math.min(bytes.byteLength, (index + 1) * CONTENT_CHUNK_BYTES));
        await this.#options.store.put(`${this.#prefix}/blob/${hash}/chunk/${index}`, chunk.slice());
      }
      await this.#options.store.put(`${this.#prefix}/blob/${hash}/meta`, encodeRecord(info));
      await this.#touchCacheEntry("public", hash, info.bytes);
    });
    return info;
  }
  /** Store raw bytes locally indexed by SHA-256 hash so peers can recover historical blobs by hash. */
  async putBlob(input, options = {}) {
    this.#reader();
    check(input instanceof Uint8Array && input.byteLength <= MAX_BLOB_BYTES, "CONTENT_RANGE_INVALID");
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    signal.throwIfAborted();
    const bytes = input.slice();
    const hash = bytesToHex(await awaitOwnedTask(signal, () => sha256(bytes)));
    return this.#storeLocalBlob(hash, bytes, signal);
  }
  async hasBlob(hash) {
    this.#reader();
    check(digest(hash), "CONTENT_BLOB_INVALID");
    const info = await this.#localBlobInfo(hash, this.#lifetime.signal);
    if (info === null) return false;
    const count = Math.ceil(info.bytes / CONTENT_CHUNK_BYTES);
    for (let index = 0; index < count; index++) {
      if (await this.#localBlobChunk(hash, info, index, this.#lifetime.signal) === null) return false;
    }
    return true;
  }
  /** Retrieve a SHA-256 hash-addressed blob locally, falling back to connected peers and verifying the digest. */
  async getBlob(hash, options = {}) {
    check(digest(hash), "CONTENT_BLOB_INVALID");
    const maxBytes = options.maxBytes ?? MAX_BLOB_BYTES;
    check(Number.isSafeInteger(maxBytes) && maxBytes >= 0 && maxBytes <= MAX_BLOB_BYTES, "CONTENT_READ_LIMIT_INVALID");
    if (options.expectedBytes !== void 0) {
      check(Number.isSafeInteger(options.expectedBytes) && options.expectedBytes >= 0 && options.expectedBytes <= MAX_BLOB_BYTES, "CONTENT_BLOB_INVALID");
      check(options.expectedBytes <= maxBytes, "CONTENT_READ_LIMIT_EXCEEDED");
    }
    const scope = this.#blobScope(hash, options);
    try {
      const localInfo = await this.#localBlobInfo(hash, scope.signal);
      if (localInfo !== null) {
        if (options.expectedBytes !== void 0) check(localInfo.bytes === options.expectedBytes, "CONTENT_BLOB_INVALID");
        check(localInfo.bytes <= maxBytes, "CONTENT_READ_LIMIT_EXCEEDED");
        const count = Math.ceil(localInfo.bytes / CONTENT_CHUNK_BYTES);
        const assembled = new Uint8Array(localInfo.bytes);
        let complete = true;
        for (let index = 0; index < count; index++) {
          const chunk = await this.#localBlobChunk(hash, localInfo, index, scope.signal);
          if (chunk === null) {
            complete = false;
            break;
          }
          assembled.set(chunk, index * CONTENT_CHUNK_BYTES);
        }
        if (complete) {
          check(bytesToHex(await awaitOwnedTask(scope.signal, () => sha256(assembled))) === hash, "CONTENT_BLOB_INVALID");
          scope.signal.throwIfAborted();
          return assembled;
        }
      }
      if (options.localOnly === true) return null;
      let failure;
      for (const source2 of [...this.#sources.values()]) {
        if (source2.blobInfo === void 0 || source2.blobChunk === void 0) continue;
        try {
          const info = await awaitOwnedTask(scope.signal, () => source2.blobInfo(hash, { signal: scope.signal }));
          if (info === null) continue;
          assertBlobInfo(info);
          check(info.hash === hash, "CONTENT_BLOB_INVALID");
          if (options.expectedBytes !== void 0) check(info.bytes === options.expectedBytes, "CONTENT_BLOB_INVALID");
          check(info.bytes <= maxBytes, "CONTENT_READ_LIMIT_EXCEEDED");
          const count = Math.ceil(info.bytes / CONTENT_CHUNK_BYTES);
          const assembled = new Uint8Array(info.bytes);
          for (let index = 0; index < count; index++) {
            const expectedLen = Math.min(CONTENT_CHUNK_BYTES, info.bytes - index * CONTENT_CHUNK_BYTES);
            const chunk = await awaitOwnedTask(scope.signal, () => source2.blobChunk(hash, index, { signal: scope.signal }));
            check(chunk instanceof Uint8Array && chunk.byteLength === expectedLen, "CONTENT_BLOB_INVALID");
            assembled.set(chunk, index * CONTENT_CHUNK_BYTES);
          }
          check(bytesToHex(await awaitOwnedTask(scope.signal, () => sha256(assembled))) === hash, "CONTENT_BLOB_INVALID");
          scope.signal.throwIfAborted();
          if (options.cache !== false) await this.#storeLocalBlob(hash, assembled, scope.signal);
          return assembled;
        } catch (error) {
          scope.signal.throwIfAborted();
          failure = error;
        }
      }
      if (failure !== void 0) throw failure instanceof Error ? failure : new Error("CONTENT_SOURCE_FAILED", { cause: failure });
      return null;
    } finally {
      scope.release();
    }
  }
  async deleteBlob(hash) {
    this.#reader();
    check(digest(hash), "CONTENT_BLOB_INVALID");
    for (const read of this.#reads.get(`blob:${hash}`) ?? []) read.abort(new Error("CONTENT_DISCARDED"));
    await this.#serial(async () => {
      const info = await this.#localBlobInfo(hash, this.#lifetime.signal).catch(() => null);
      await this.#remove(`${this.#prefix}/blob/${hash}/meta`);
      const count = info === null ? 0 : Math.ceil(info.bytes / CONTENT_CHUNK_BYTES);
      for (let index = 0; index < count; index++) await this.#remove(`${this.#prefix}/blob/${hash}/chunk/${index}`);
      await this.#dropCacheEntry("public", hash);
    });
  }
  /** Serve only verified local bytes. Serving never recursively consults remote sources. */
  source() {
    return {
      manifest: async (input, options = {}) => {
        const reference = this.#reference(input), scope = this.#readScope(reference, options);
        try {
          return await this.#manifest(reference, scope.signal, true);
        } finally {
          scope.release();
        }
      },
      chunk: async (input, index, options = {}) => {
        const reference = this.#reference(input), scope = this.#readScope(reference, options);
        try {
          const manifest = await this.#manifest(reference, scope.signal, true);
          check(Number.isSafeInteger(index) && index >= 0 && index < Math.ceil(reference.bytes / CONTENT_CHUNK_BYTES), "CONTENT_CHUNK_INDEX_INVALID");
          return manifest === null ? null : await this.#chunk(reference, manifest, index, scope.signal, true);
        } finally {
          scope.release();
        }
      },
      retained: async (input, options = {}) => {
        const reference = this.#reference(input), scope = this.#readScope(reference, options);
        try {
          const manifest = await this.#manifest(reference, scope.signal, true);
          check(manifest !== null, "CONTENT_MANIFEST_MISSING");
          for (let index = 0; index < manifest.chunks.length; index++) check(await this.#chunk(reference, manifest, index, scope.signal, true) !== null, "CONTENT_INCOMPLETE");
          return await this.#receipt(reference, scope.signal);
        } finally {
          scope.release();
        }
      },
      blobInfo: async (hash, options = {}) => {
        check(digest(hash), "CONTENT_BLOB_INVALID");
        const scope = this.#blobScope(hash, options);
        try {
          return await this.#localBlobInfo(hash, scope.signal);
        } finally {
          scope.release();
        }
      },
      blobChunk: async (hash, index, options = {}) => {
        check(digest(hash), "CONTENT_BLOB_INVALID");
        const scope = this.#blobScope(hash, options);
        try {
          const info = await this.#localBlobInfo(hash, scope.signal);
          if (info === null) return null;
          return await this.#localBlobChunk(hash, info, index, scope.signal);
        } finally {
          scope.release();
        }
      }
    };
  }
  putBytes(bytes, options) {
    return putContentBytes(this, bytes, options);
  }
  readBytes(reference, options) {
    return readContentBytes(this, reference, options);
  }
  /**
   * Keyed-convergent deterministic encryption under the current epoch key:
   * identical plaintext uploaded by different readers in the same epoch produces
   * the exact same `ContentReference` and chunk hashes, while remaining opaque
   * to any party without the epoch key.
   */
  async #putPrivateConvergent(input, options = {}) {
    this.#reader();
    check(input instanceof Uint8Array && input.byteLength <= MAX_CONTENT_BYTES, "CONTENT_RANGE_INVALID");
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    signal.throwIfAborted();
    const bytes = input.slice();
    const epoch = this.#options.authority.currentEpoch();
    const mediaType = options.mediaType ?? "application/octet-stream";
    const refBody = {
      profile: "authored-content-v1",
      applicationId: this.#options.authority.applicationId,
      epoch,
      bytes: bytes.byteLength,
      mediaType
    };
    assertReferenceBody(refBody);
    const epochKey = this.#options.authority.epochKey(epoch);
    check(epochKey !== null, "CONTENT_KEY_MISSING");
    const plainDigest = await awaitOwnedTask(signal, () => sha256(bytes));
    const stageBytes = await awaitOwnedTask(
      signal,
      () => sha256(concatBytes(utf8("chronolog/convergent-stage/v2:"), epochKey, utf8(this.#prefix), utf8(mediaType), plainDigest))
    );
    const uuidHex = bytesToHex(stageBytes.subarray(0, 16));
    const id = `${uuidHex.slice(0, 8)}-${uuidHex.slice(8, 12)}-4${uuidHex.slice(13, 16)}-8${uuidHex.slice(17, 20)}-${uuidHex.slice(20, 32)}`;
    const count = Math.ceil(bytes.byteLength / CONTENT_CHUNK_BYTES);
    const encryptedChunks = [];
    for (let index = 0; index < count; index++) {
      signal.throwIfAborted();
      const plainChunk = bytes.subarray(index * CONTENT_CHUNK_BYTES, Math.min(bytes.byteLength, (index + 1) * CONTENT_CHUNK_BYTES));
      const nonceDigest = await awaitOwnedTask(
        signal,
        () => sha256(concatBytes(utf8("chronolog/convergent-nonce/v2:"), epochKey, utf8(this.#prefix), plainDigest, utf8(`:${index}`)))
      );
      const encrypted = encodeRecord(await awaitOwnedTask(
        signal,
        () => encryptEpochPayload(epochKey, BigInt(epoch), plainChunk, encodeRecord([this.#prefix, id, index]), nonceDigest.subarray(0, 12))
      ));
      const hash = bytesToHex(await awaitOwnedTask(signal, () => sha256(encrypted)));
      encryptedChunks.push({ hash, bytes: encrypted });
    }
    const manifest = {
      stageId: id,
      reference: refBody,
      chunks: encryptedChunks.map((c) => ({ hash: c.hash, bytes: c.bytes.length }))
    };
    const reference = { ...refBody, id: await recordDigest(manifest) };
    await this.#serial(async () => {
      signal.throwIfAborted();
      this.#reader();
      for (const chunk of encryptedChunks) {
        await this.#options.store.put(`${this.#prefix}/chunk/${chunk.hash}`, chunk.bytes);
      }
      await this.#options.store.put(`${this.#prefix}/manifest/${reference.id}`, encodeRecord(manifest));
      await this.#touchCacheEntry("private", reference.id, reference.bytes, reference);
    });
    return reference;
  }
  /** Stream an async iterable of Uint8Array chunks into private or public lazy-pull content without holding the entire file in memory. */
  async putStream(chunks, options = {}) {
    const visibility = options.visibility ?? "private";
    const mediaType = options.mediaType ?? "application/octet-stream";
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    signal.throwIfAborted();
    if (visibility === "private" && options.totalBytes !== void 0) {
      this.#reader();
      const total2 = options.totalBytes;
      check(Number.isSafeInteger(total2) && total2 >= 0 && total2 <= MAX_CONTENT_BYTES, "CONTENT_RANGE_INVALID");
      const upload = await this.stage({ bytes: total2, mediaType });
      let written = 0;
      let chunkIndex = 0;
      let buffer = new Uint8Array(0);
      try {
        for await (const part of chunks) {
          signal.throwIfAborted();
          check(part instanceof Uint8Array, "CONTENT_CHUNK_SIZE_INVALID");
          if (part.byteLength === 0) continue;
          buffer = buffer.byteLength === 0 ? part.slice() : concatBytes(buffer, part);
          while (buffer.byteLength >= CONTENT_CHUNK_BYTES) {
            const slice = buffer.subarray(0, CONTENT_CHUNK_BYTES);
            await upload.write(chunkIndex++, slice);
            written += slice.byteLength;
            buffer = buffer.subarray(CONTENT_CHUNK_BYTES);
          }
        }
        if (buffer.byteLength > 0) {
          await upload.write(chunkIndex++, buffer);
          written += buffer.byteLength;
        }
        check(written === total2, "CONTENT_INCOMPLETE");
        return await upload.commit();
      } catch (error) {
        await upload.discard().catch(() => void 0);
        throw error;
      }
    }
    const maxAllowed = visibility === "public" ? MAX_BLOB_BYTES : MAX_CONTENT_BYTES;
    const parts = [];
    let total = 0;
    for await (const part of chunks) {
      signal.throwIfAborted();
      check(part instanceof Uint8Array, "CONTENT_CHUNK_SIZE_INVALID");
      total += part.byteLength;
      check(total <= maxAllowed, "CONTENT_RANGE_INVALID");
      if (part.byteLength > 0) parts.push(part.slice());
    }
    const assembled = parts.length === 0 ? new Uint8Array(0) : concatBytes(...parts);
    return this.put(assembled, { visibility, mediaType, ...options.signal === void 0 ? {} : { signal: options.signal } });
  }
  /** Stream verified chunks for either a private ContentReference or a public PublicBlobReference / SHA-256 hash. */
  async *readStream(target, options = {}) {
    if (isPrivateContentReference(target)) {
      const ref = this.#reference(target);
      if (options.maxBytes !== void 0) check(ref.bytes <= options.maxBytes, "CONTENT_READ_LIMIT_EXCEEDED");
      for await (const chunk of this.read(ref, options.signal === void 0 ? {} : { signal: options.signal })) {
        yield chunk;
      }
      return;
    }
    const hash = typeof target === "string" ? target : isPublicBlobReference(target) ? target.hash : "";
    check(digest(hash), "CONTENT_REFERENCE_INVALID");
    const expectedBytes = options.expectedBytes ?? (isPublicBlobReference(target) ? target.bytes : void 0);
    const bytes = await this.getBlob(hash, { ...options, ...expectedBytes === void 0 ? {} : { expectedBytes } });
    if (bytes === null) throw new Error("CONTENT_BLOB_MISSING");
    for (let offset = 0; offset < bytes.byteLength; offset += CONTENT_CHUNK_BYTES) {
      yield bytes.subarray(offset, Math.min(bytes.byteLength, offset + CONTENT_CHUNK_BYTES));
    }
  }
  /** Pin a cached blob or private content item so `pruneCache()` will never evict it. */
  async pin(target) {
    this.#reader();
    const { kind, key } = this.#cacheIdOf(target);
    await this.#serial(async () => {
      const map = await this.#loadCacheIndex();
      const id = `${kind}:${key}`;
      const existing = map.get(id);
      if (existing !== void 0) {
        existing.pinned = true;
        existing.lastAccessMs = Date.now();
      } else {
        map.set(id, {
          kind,
          key,
          bytes: typeof target === "string" ? 0 : target.bytes,
          lastAccessMs: Date.now(),
          pinned: true,
          ...isPrivateContentReference(target) ? { reference: this.#reference(target) } : {}
        });
      }
      await this.#saveCacheIndex(map);
    });
  }
  async unpin(target) {
    this.#reader();
    const { kind, key } = this.#cacheIdOf(target);
    await this.#serial(async () => {
      const map = await this.#loadCacheIndex();
      const existing = map.get(`${kind}:${key}`);
      if (existing !== void 0) {
        existing.pinned = false;
        await this.#saveCacheIndex(map);
      }
    });
  }
  async isPinned(target) {
    this.#reader();
    const { kind, key } = this.#cacheIdOf(target);
    const map = await this.#loadCacheIndex();
    return map.get(`${kind}:${key}`)?.pinned === true;
  }
  async stats() {
    this.#reader();
    const map = await this.#loadCacheIndex();
    let publicBlobs = 0;
    let privateItems = 0;
    let totalBytes = 0;
    let pinnedCount = 0;
    for (const entry of map.values()) {
      if (entry.kind === "public") publicBlobs++;
      else privateItems++;
      totalBytes += entry.bytes;
      if (entry.pinned) pinnedCount++;
    }
    return {
      publicBlobs,
      privateItems,
      totalBytes,
      pinnedCount,
      maxCacheBytes: this.#options.maxCacheBytes ?? null
    };
  }
  /** Evict oldest unpinned locally cached blobs/items down to `maxBytes` (LRU). */
  async pruneCache(options = {}) {
    this.#reader();
    const limit2 = options.maxBytes ?? this.#options.maxCacheBytes;
    check(limit2 !== void 0 && Number.isSafeInteger(limit2) && limit2 >= 0, "CONTENT_CACHE_LIMIT_INVALID");
    const map = await this.#loadCacheIndex();
    let totalBytes = 0;
    for (const entry of map.values()) totalBytes += entry.bytes;
    if (totalBytes <= limit2) {
      return { evictedCount: 0, evictedBytes: 0, remainingBytes: totalBytes };
    }
    const candidates = [...map.values()].filter((e) => !e.pinned).sort((a, b) => a.lastAccessMs - b.lastAccessMs || a.key.localeCompare(b.key));
    let evictedCount = 0;
    let evictedBytes = 0;
    for (const entry of candidates) {
      if (totalBytes - evictedBytes <= limit2) break;
      if (entry.kind === "public") {
        await this.deleteBlob(entry.key);
      } else if (entry.reference !== void 0) {
        await this.discard(entry.reference);
      } else {
        await this.#serial(() => this.#dropCacheEntry(entry.kind, entry.key));
      }
      evictedCount++;
      evictedBytes += entry.bytes;
    }
    return {
      evictedCount,
      evictedBytes,
      remainingBytes: Math.max(0, totalBytes - evictedBytes)
    };
  }
  /** Unified lazy-pull blob write: supports both public raw-SHA-256 blobs and private epoch-encrypted blobs. */
  async put(bytes, options = {}) {
    const visibility = options.visibility ?? "private";
    const mediaType = options.mediaType ?? "application/octet-stream";
    if (visibility === "public") {
      check(typeof mediaType === "string" && mediaType.length > 0 && mediaType.length <= 256 && /^[\x20-\x7e]+$/u.test(mediaType), "CONTENT_REFERENCE_INVALID");
      const info = await this.putBlob(bytes, options.signal === void 0 ? {} : { signal: options.signal });
      return { profile: "chronolog-blob-v2", visibility: "public", hash: info.hash, bytes: info.bytes, mediaType };
    }
    const putOpts = {
      mediaType,
      ...options.signal === void 0 ? {} : { signal: options.signal }
    };
    return options.deduplicate === true ? this.#putPrivateConvergent(bytes, putOpts) : this.putBytes(bytes, putOpts);
  }
  /** Unified lazy-pull blob read: accepts a raw SHA-256 hex hash, a PublicBlobReference, or a private ContentReference. */
  async get(target, options = {}) {
    if (typeof target === "string") {
      return this.getBlob(target, options);
    }
    if (isPublicBlobReference(target)) {
      return this.getBlob(target.hash, {
        ...options,
        expectedBytes: options.expectedBytes ?? target.bytes
      });
    }
    if (isPrivateContentReference(target)) {
      try {
        return await this.readBytes(target, {
          maxBytes: options.maxBytes ?? target.bytes,
          ...options.signal === void 0 ? {} : { signal: options.signal }
        });
      } catch (error) {
        if (error instanceof Error && (error.message === "CONTENT_MANIFEST_MISSING" || error.message === "CONTENT_CHUNK_MISSING")) {
          return null;
        }
        throw error;
      }
    }
    throw new Error("CONTENT_REFERENCE_INVALID");
  }
  async close() {
    this.#lifetime.abort(new Error("CONTENT_CLOSED"));
    this.#sources.clear();
    await this.#tail;
  }
};

// packages/peer-session/src/network-content.ts
var CONTENT_NETWORK_LIMITS = Object.freeze({
  pending: 4,
  active: 4,
  timeoutMs: 3e4,
  chunkBytes: MAX_CONTENT_ENCRYPTED_CHUNK_BYTES,
  chunkBase64Characters: 4 * Math.ceil(MAX_CONTENT_ENCRYPTED_CHUNK_BYTES / 3),
  messageBytes: MAX_CONTENT_MANIFEST_BYTES + 4096
});
var digest2 = (value) => typeof value === "string" && /^[0-9a-f]{64}$/u.test(value);
function fields(value, keys) {
  check(Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), "CONTENT_WIRE_INVALID");
}
function base64(bytes) {
  let binary = "";
  for (let index = 0; index < bytes.length; index += 8192) binary += String.fromCharCode(...bytes.subarray(index, index + 8192));
  return btoa(binary);
}
function decoded(value) {
  check(value.length > 0 && value.length <= CONTENT_NETWORK_LIMITS.chunkBase64Characters && /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/u.test(value), "CONTENT_WIRE_CHUNK_INVALID");
  const binary = atob(value);
  check(binary.length <= CONTENT_NETWORK_LIMITS.chunkBytes && btoa(binary) === value, "CONTENT_WIRE_CHUNK_INVALID");
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}
function assertContentWireMessage(input) {
  check(input !== null && typeof input === "object" && !Array.isArray(input), "CONTENT_WIRE_INVALID");
  const value = input;
  check(typeof value.id === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u.test(value.id), "CONTENT_WIRE_INVALID");
  switch (value.type) {
    case "manifest-request":
    case "retain-request":
      fields(value, ["type", "id", "reference"]);
      assertContentReference(value.reference);
      break;
    case "chunk-request":
      fields(value, ["type", "id", "reference", "index"]);
      assertContentReference(value.reference);
      check(Number.isSafeInteger(value.index) && Number(value.index) >= 0 && Number(value.index) < MAX_CONTENT_CHUNKS && Number(value.index) < Math.ceil(value.reference.bytes / CONTENT_CHUNK_BYTES), "CONTENT_WIRE_CHUNK_INVALID");
      break;
    case "blob-info-request":
      fields(value, ["type", "id", "hash"]);
      check(digest2(value.hash), "CONTENT_WIRE_INVALID");
      break;
    case "blob-chunk-request":
      fields(value, ["type", "id", "hash", "index"]);
      check(digest2(value.hash) && Number.isSafeInteger(value.index) && Number(value.index) >= 0 && Number(value.index) < MAX_BLOB_CHUNKS, "CONTENT_WIRE_CHUNK_INVALID");
      break;
    case "manifest-response":
      fields(value, ["type", "id", "manifest"]);
      if (value.manifest !== null) assertContentManifest(value.manifest);
      break;
    case "chunk-response":
      fields(value, ["type", "id", "bytes"]);
      check(value.bytes === null || typeof value.bytes === "string", "CONTENT_WIRE_CHUNK_INVALID");
      if (typeof value.bytes === "string") decoded(value.bytes);
      break;
    case "blob-info-response":
      fields(value, ["type", "id", "bytes"]);
      check(value.bytes === null || Number.isSafeInteger(value.bytes) && Number(value.bytes) >= 0 && Number(value.bytes) <= MAX_BLOB_BYTES, "CONTENT_WIRE_INVALID");
      break;
    case "blob-chunk-response":
      fields(value, ["type", "id", "bytes"]);
      check(value.bytes === null || typeof value.bytes === "string", "CONTENT_WIRE_CHUNK_INVALID");
      if (typeof value.bytes === "string") check(decoded(value.bytes).length <= CONTENT_CHUNK_BYTES, "CONTENT_WIRE_CHUNK_INVALID");
      break;
    case "retain-response":
      fields(value, ["type", "id", "receipt"]);
      assertContentRetention(value.receipt);
      break;
    case "error":
      fields(value, ["type", "id", "code"]);
      check(["CONTENT_UNAVAILABLE", "CONTENT_FORBIDDEN", "CONTENT_BUSY"].includes(String(value.code)), "CONTENT_WIRE_INVALID");
      break;
    case "cancel":
      fields(value, ["type", "id"]);
      break;
    default:
      throw new Error("CONTENT_WIRE_INVALID");
  }
  check(encodeRecord(input).length <= CONTENT_NETWORK_LIMITS.messageBytes, "CONTENT_WIRE_LIMIT");
}
function createNetworkContent(options) {
  options.signal.throwIfAborted();
  check(/^[0-9a-f]{64}$/u.test(options.peerId), "CONTENT_PEER_INVALID");
  const lifetime = new AbortController(), signal = AbortSignal.any([options.signal, lifetime.signal]);
  const pending = /* @__PURE__ */ new Map(), active = /* @__PURE__ */ new Map();
  const local = options.content.source();
  const allowed = () => {
    signal.throwIfAborted();
    check(options.authorize() === true, "CONTENT_FORBIDDEN");
  };
  const close = () => {
    if (lifetime.signal.aborted) return;
    lifetime.abort(new Error("CONTENT_NETWORK_CLOSED"));
    options.signal.removeEventListener("abort", close);
    detach();
    for (const waiter of pending.values()) {
      waiter.cleanup();
      waiter.reject(signal.reason);
    }
    pending.clear();
    for (const controller of active.values()) controller.abort(signal.reason);
    active.clear();
  };
  const send = async (message) => {
    allowed();
    assertContentWireMessage(message);
    try {
      await awaitOwnedTask(signal, () => options.send(message));
      allowed();
    } catch (error) {
      close();
      throw error;
    }
  };
  const cancel = (id) => {
    if (!signal.aborted && options.authorize()) void send({ type: "cancel", id }).catch(() => void 0);
  };
  const sendRequest = (action, build, input) => {
    allowed();
    input.signal?.throwIfAborted();
    check(pending.size < CONTENT_NETWORK_LIMITS.pending, "CONTENT_REQUEST_LIMIT");
    const id = crypto.randomUUID(), requestSignal = input.signal;
    const message = build(id);
    assertContentWireMessage(message);
    return new Promise((resolve, reject) => {
      const finish = (error) => {
        const waiter = pending.get(id);
        if (waiter === void 0) return;
        pending.delete(id);
        waiter.cleanup();
        reject(error);
        cancel(id);
      };
      const abort = () => finish(requestSignal?.reason instanceof Error ? requestSignal.reason : new Error("CONTENT_REQUEST_ABORTED"));
      const timer = setTimeout(() => finish(new Error("CONTENT_REQUEST_TIMEOUT")), CONTENT_NETWORK_LIMITS.timeoutMs);
      const cleanup = () => {
        clearTimeout(timer);
        requestSignal?.removeEventListener("abort", abort);
      };
      pending.set(id, { action, resolve, reject, cleanup });
      requestSignal?.addEventListener("abort", abort, { once: true });
      void send(message).catch((error) => {
        const waiter = pending.get(id);
        if (waiter !== void 0) {
          pending.delete(id);
          cleanup();
          reject(error);
        }
      });
    });
  };
  const detach = options.content.attachSource(`network:${options.peerId}:${crypto.randomUUID()}`, {
    async manifest(reference, input = {}) {
      assertContentReference(reference);
      const response = await sendRequest("manifest", (id) => ({ type: "manifest-request", id, reference: { ...reference } }), input);
      check(response.type === "manifest-response", "CONTENT_RESPONSE_INVALID");
      return response.manifest;
    },
    async chunk(reference, index, input = {}) {
      assertContentReference(reference);
      const response = await sendRequest("chunk", (id) => ({ type: "chunk-request", id, reference: { ...reference }, index }), input);
      check(response.type === "chunk-response", "CONTENT_RESPONSE_INVALID");
      if (response.bytes === null) return null;
      const bytes = decoded(response.bytes), manifest = await local.manifest(reference, input), expected = manifest?.chunks[index];
      check(expected !== void 0 && bytes.length === expected.bytes && bytesToHex(await sha256(bytes)) === expected.hash, "CONTENT_CHUNK_INVALID");
      allowed();
      input.signal?.throwIfAborted();
      return bytes;
    },
    async retained(reference, input = {}) {
      assertContentReference(reference);
      const response = await sendRequest("retain", (id) => ({ type: "retain-request", id, reference: { ...reference } }), input);
      check(response.type === "retain-response", "CONTENT_RESPONSE_INVALID");
      await options.content.verifyRetention(reference, response.receipt, options.peerId);
      allowed();
      input.signal?.throwIfAborted();
      return response.receipt;
    },
    async blobInfo(hash, input = {}) {
      check(digest2(hash), "CONTENT_BLOB_INVALID");
      const response = await sendRequest("blob-info", (id) => ({ type: "blob-info-request", id, hash }), input);
      check(response.type === "blob-info-response", "CONTENT_RESPONSE_INVALID");
      allowed();
      input.signal?.throwIfAborted();
      return response.bytes === null ? null : { hash, bytes: response.bytes };
    },
    async blobChunk(hash, index, input = {}) {
      check(digest2(hash), "CONTENT_BLOB_INVALID");
      const response = await sendRequest("blob-chunk", (id) => ({ type: "blob-chunk-request", id, hash, index }), input);
      check(response.type === "blob-chunk-response", "CONTENT_RESPONSE_INVALID");
      if (response.bytes === null) return null;
      const bytes = decoded(response.bytes);
      check(bytes.length <= CONTENT_CHUNK_BYTES, "CONTENT_BLOB_INVALID");
      allowed();
      input.signal?.throwIfAborted();
      return bytes;
    }
  });
  options.signal.addEventListener("abort", close, { once: true });
  if (options.signal.aborted) close();
  const serve = async (message, controller) => {
    const timer = setTimeout(() => controller.abort(new Error("CONTENT_REQUEST_TIMEOUT")), CONTENT_NETWORK_LIMITS.timeoutMs);
    const requestSignal = AbortSignal.any([signal, controller.signal]);
    try {
      allowed();
      requestSignal.throwIfAborted();
      let response;
      if (message.type === "manifest-request") response = { type: "manifest-response", id: message.id, manifest: await awaitOwnedTask(requestSignal, () => local.manifest(message.reference, { signal: requestSignal })) };
      else if (message.type === "chunk-request") {
        const bytes = await awaitOwnedTask(requestSignal, () => local.chunk(message.reference, message.index, { signal: requestSignal }));
        response = { type: "chunk-response", id: message.id, bytes: bytes === null ? null : base64(bytes) };
      } else if (message.type === "blob-info-request") {
        const info = await awaitOwnedTask(requestSignal, () => local.blobInfo(message.hash, { signal: requestSignal }));
        response = { type: "blob-info-response", id: message.id, bytes: info === null ? null : info.bytes };
      } else if (message.type === "blob-chunk-request") {
        const bytes = await awaitOwnedTask(requestSignal, () => local.blobChunk(message.hash, message.index, { signal: requestSignal }));
        response = { type: "blob-chunk-response", id: message.id, bytes: bytes === null ? null : base64(bytes) };
      } else response = { type: "retain-response", id: message.id, receipt: await awaitOwnedTask(requestSignal, () => options.content.retain(message.reference, { signal: requestSignal })) };
      requestSignal.throwIfAborted();
      allowed();
      await send(response);
    } catch {
      if (!requestSignal.aborted && !signal.aborted) await send({ type: "error", id: message.id, code: options.authorize() ? "CONTENT_UNAVAILABLE" : "CONTENT_FORBIDDEN" }).catch(() => void 0);
    } finally {
      clearTimeout(timer);
      if (active.get(message.id) === controller) active.delete(message.id);
    }
  };
  return { close, async handle(message) {
    allowed();
    assertContentWireMessage(message);
    if (message.type === "cancel") {
      active.get(message.id)?.abort(new Error("CONTENT_REQUEST_CANCELLED"));
      return;
    }
    if (message.type === "manifest-request" || message.type === "chunk-request" || message.type === "retain-request" || message.type === "blob-info-request" || message.type === "blob-chunk-request") {
      check(!active.has(message.id), "CONTENT_REQUEST_DUPLICATE");
      if (active.size >= CONTENT_NETWORK_LIMITS.active) {
        await send({ type: "error", id: message.id, code: "CONTENT_BUSY" });
        return;
      }
      const controller = new AbortController();
      active.set(message.id, controller);
      void serve(message, controller).catch(() => close());
      return;
    }
    const waiter = pending.get(message.id);
    if (waiter === void 0) return;
    check(message.type === "error" || message.type === `${waiter.action}-response`, "CONTENT_RESPONSE_INVALID");
    pending.delete(message.id);
    waiter.cleanup();
    if (message.type === "error") waiter.reject(new Error(message.code));
    else waiter.resolve(message);
  } };
}

// packages/peer-session/src/network-wire.ts
var APPLICATION_NETWORK_LIMITS = Object.freeze({
  messageBytes: 32 * 1024 * 1024,
  fragmentBytes: 48 * 1024,
  queuedMessages: 8,
  queuedBytes: 32 * 1024 * 1024,
  pendingRequests: 4,
  incomingRequests: 4,
  rangeCommands: 32,
  rangeBytes: 4 * 1024 * 1024,
  peers: 16
});
function networkError(code) {
  return new Error(code);
}
function requireNetwork(value, code) {
  if (!value) throw networkError(code);
}
function interruptible(promise, signal) {
  signal.throwIfAborted();
  return new Promise((resolve, reject) => {
    const abort = () => reject(signal.reason);
    signal.addEventListener("abort", abort, { once: true });
    void promise.then(resolve, reject).finally(() => signal.removeEventListener("abort", abort));
  });
}
function timeout(milliseconds, message) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(networkError(message)), milliseconds);
  return { signal: controller.signal, cancel: () => clearTimeout(timer) };
}
var ApplicationMessageWire = class {
  #connection;
  #signal;
  #timeoutMs;
  #authorize;
  #outgoing = 0;
  #incoming = 0;
  #pending = 0;
  #pendingBytes = 0;
  #sentBytes = 0;
  #receivedBytes = 0;
  #tail = Promise.resolve();
  constructor(connection, signal, timeoutMs, authorize = () => {
  }) {
    this.#connection = connection;
    this.#signal = signal;
    this.#timeoutMs = timeoutMs;
    this.#authorize = authorize;
  }
  get stats() {
    return { sentBytes: this.#sentBytes, receivedBytes: this.#receivedBytes };
  }
  send(value, authorize) {
    this.#signal.throwIfAborted();
    requireNetwork(this.#pending < APPLICATION_NETWORK_LIMITS.queuedMessages, "APPLICATION_NETWORK_BACKPRESSURE");
    const bytes = encodeRecord(value);
    requireNetwork(bytes.length > 0 && bytes.length <= APPLICATION_NETWORK_LIMITS.messageBytes && this.#pendingBytes + bytes.length <= APPLICATION_NETWORK_LIMITS.queuedBytes, "APPLICATION_NETWORK_BACKPRESSURE");
    this.#pending++;
    this.#pendingBytes += bytes.length;
    const queued = timeout(this.#timeoutMs, "APPLICATION_NETWORK_WRITE_TIMEOUT");
    const signal = AbortSignal.any([this.#signal, queued.signal]);
    const task = this.#tail.then(async () => {
      signal.throwIfAborted();
      authorize?.();
      requireNetwork(this.#outgoing < Number.MAX_SAFE_INTEGER, "APPLICATION_NETWORK_SEQUENCE_EXHAUSTED");
      const id = ++this.#outgoing;
      for (let offset = 0; offset < bytes.length; offset += APPLICATION_NETWORK_LIMITS.fragmentBytes) {
        signal.throwIfAborted();
        this.#authorize();
        authorize?.();
        const fragment = bytes.subarray(offset, offset + APPLICATION_NETWORK_LIMITS.fragmentBytes);
        const frame = encodeCanonicalCbor([1n, BigInt(id), BigInt(offset), BigInt(bytes.length), fragment]);
        await interruptible(this.#connection.send(frame, { signal }), signal);
        this.#sentBytes += frame.length;
      }
    }).finally(() => {
      queued.cancel();
      this.#pending--;
      this.#pendingBytes -= bytes.length;
    });
    this.#tail = task.catch(() => void 0);
    return task;
  }
  async *messages() {
    let body2 = null, offset = 0;
    let assembly;
    const iterator = this.#connection.frames(this.#signal)[Symbol.asyncIterator]();
    try {
      while (!this.#signal.aborted) {
        const signal = assembly === void 0 ? this.#signal : AbortSignal.any([this.#signal, assembly.signal]);
        const next = await interruptible(iterator.next(), signal);
        if (next.done) {
          requireNetwork(body2 === null, "APPLICATION_NETWORK_TRUNCATED");
          return;
        }
        const bytes = next.value;
        requireNetwork(
          bytes instanceof Uint8Array && bytes.length > 0 && bytes.length <= APPLICATION_NETWORK_LIMITS.fragmentBytes + 128,
          "APPLICATION_NETWORK_FRAME_LIMIT"
        );
        this.#receivedBytes += bytes.length;
        const frame = assertCanonicalCbor2(bytes);
        requireNetwork(Array.isArray(frame) && frame.length === 5 && frame[0] === 1n && typeof frame[1] === "bigint" && typeof frame[2] === "bigint" && typeof frame[3] === "bigint" && frame[4] instanceof Uint8Array, "APPLICATION_NETWORK_FRAME_INVALID");
        const [id, position, total] = [Number(frame[1]), Number(frame[2]), Number(frame[3])], chunk = frame[4];
        requireNetwork(
          Number.isSafeInteger(id) && id === this.#incoming + 1 && Number.isSafeInteger(position) && position === offset && Number.isSafeInteger(total) && total > 0 && total <= APPLICATION_NETWORK_LIMITS.messageBytes && chunk.length > 0 && chunk.length <= APPLICATION_NETWORK_LIMITS.fragmentBytes && offset + chunk.length <= total,
          "APPLICATION_NETWORK_FRAME_INVALID"
        );
        if (body2 === null) {
          body2 = new Uint8Array(total);
          assembly = timeout(this.#timeoutMs, "APPLICATION_NETWORK_READ_TIMEOUT");
        }
        requireNetwork(body2.length === total, "APPLICATION_NETWORK_FRAME_INVALID");
        body2.set(chunk, offset);
        offset += chunk.length;
        if (offset === total) {
          const complete = body2;
          body2 = null;
          offset = 0;
          this.#incoming++;
          assembly?.cancel();
          assembly = void 0;
          yield decodeRecord(complete);
        }
      }
    } finally {
      assembly?.cancel();
      void iterator.return?.().catch(() => void 0);
    }
  }
};

// packages/peer-session/src/secure-channel.ts
var APPLICATION_CHANNEL_SUITE = `${HPKE_SUITE}/peer-record-v1`;
var APPLICATION_CHANNEL_LIMITS = Object.freeze({ overheadBytes: 22, records: 2 ** 24, plaintextBytes: 2 ** 32 });
var DOMAIN = "chronolog/peer-channel/v1";
var EXPORT_CONTEXT = encodeRecord({ domain: DOMAIN, layout: ["reliable-key:32", "reliable-nonce:12", "live-key:32", "live-nonce:12"] });
var HEADER = 6;
var TAG = 16;
var limit = (live) => live ? MAX_SIGNAL_BYTES : APPLICATION_NETWORK_LIMITS.fragmentBytes + 128;
var source = (bytes) => Uint8Array.from(bytes).buffer;
var context = (sender, receiver) => encodeRecord({ domain: DOMAIN, suite: APPLICATION_CHANNEL_SUITE, sender, receiver });
var RecordCipher = class {
  #key;
  #baseNonce;
  #live;
  #sequence = 0;
  #bytes = 0;
  constructor(key, nonce, live) {
    this.#key = key;
    this.#baseNonce = nonce;
    this.#live = live;
  }
  #nonce(sequence) {
    const nonce = this.#baseNonce.slice(), view = new DataView(nonce.buffer);
    view.setUint32(8, view.getUint32(8) ^ sequence);
    return nonce;
  }
  #budget(length) {
    requireNetwork(this.#key !== void 0, "APPLICATION_CHANNEL_CLOSED");
    requireNetwork(
      this.#sequence < APPLICATION_CHANNEL_LIMITS.records && this.#bytes + length <= APPLICATION_CHANNEL_LIMITS.plaintextBytes,
      "APPLICATION_CHANNEL_KEY_EXHAUSTED"
    );
  }
  async seal(input) {
    requireNetwork(input instanceof Uint8Array && input.length > 0 && input.length <= limit(this.#live), "APPLICATION_CHANNEL_FRAME_LIMIT");
    this.#budget(input.length);
    const sequence = ++this.#sequence, header = Uint8Array.of(1, this.#live ? 2 : 1, 0, 0, 0, 0);
    new DataView(header.buffer).setUint32(2, sequence);
    this.#bytes += input.length;
    const encrypted = new Uint8Array(await crypto.subtle.encrypt({
      name: "AES-GCM",
      iv: source(this.#nonce(sequence)),
      additionalData: source(header),
      tagLength: 128
    }, this.#key, source(input)));
    const result = new Uint8Array(header.length + encrypted.length);
    result.set(header);
    result.set(encrypted, HEADER);
    return result;
  }
  async open(input) {
    requireNetwork(
      input instanceof Uint8Array && input.length > HEADER + TAG && input.length <= limit(this.#live) + HEADER + TAG,
      "APPLICATION_CHANNEL_FRAME_LIMIT"
    );
    requireNetwork(input[0] === 1 && input[1] === (this.#live ? 2 : 1), "APPLICATION_CHANNEL_FRAME_INVALID");
    const sequence = new DataView(input.buffer, input.byteOffset, HEADER).getUint32(2);
    requireNetwork(sequence > 0 && sequence <= APPLICATION_CHANNEL_LIMITS.records, "APPLICATION_CHANNEL_SEQUENCE_INVALID");
    if (this.#live && sequence <= this.#sequence) return null;
    requireNetwork(this.#live || sequence === this.#sequence + 1, "APPLICATION_CHANNEL_SEQUENCE_INVALID");
    this.#budget(input.length - HEADER - TAG);
    let plaintext;
    try {
      plaintext = new Uint8Array(await crypto.subtle.decrypt({
        name: "AES-GCM",
        iv: source(this.#nonce(sequence)),
        additionalData: source(input.subarray(0, HEADER)),
        tagLength: 128
      }, this.#key, source(input.subarray(HEADER))));
    } catch {
      throw new Error("APPLICATION_CHANNEL_AUTHENTICATION_FAILED");
    }
    this.#sequence = sequence;
    this.#bytes += plaintext.length;
    return plaintext;
  }
  clear() {
    this.#key = void 0;
    this.#baseNonce.fill(0);
  }
};
async function direction(secret, usage) {
  requireNetwork(secret.length === 88, "APPLICATION_CHANNEL_KEY_INVALID");
  try {
    const reliable = await crypto.subtle.importKey("raw", source(secret.subarray(0, 32)), "AES-GCM", false, [usage]);
    const live = await crypto.subtle.importKey("raw", source(secret.subarray(44, 76)), "AES-GCM", false, [usage]);
    return { reliable: new RecordCipher(reliable, secret.slice(32, 44), false), live: new RecordCipher(live, secret.slice(76, 88), true) };
  } finally {
    secret.fill(0);
  }
}
function clear(value) {
  value?.reliable.clear();
  value?.live.clear();
}
var ApplicationSecureChannel = class {
  connection;
  #signal;
  #receiver;
  #outbound;
  #inbound;
  #hello = false;
  #preparing = false;
  #sending = false;
  #closed = false;
  #reliableBusy = false;
  #liveBusy = false;
  #onAbort = () => this.clear();
  constructor(raw, signal) {
    this.#signal = AbortSignal.any([signal, raw.signal]);
    const lifetime = this.#signal, channel = this;
    const live = raw.live === void 0 ? void 0 : {
      signal: AbortSignal.any([lifetime, raw.live.signal]),
      async trySend(frame, options = {}) {
        const signal2 = options.signal === void 0 ? lifetime : AbortSignal.any([lifetime, options.signal]);
        channel.#open();
        signal2.throwIfAborted();
        requireNetwork(channel.#sending && channel.#outbound !== void 0, "APPLICATION_PEER_AUTHENTICATION_REQUIRED");
        if (channel.#liveBusy) return false;
        channel.#liveBusy = true;
        try {
          const encrypted = await channel.#outbound.live.seal(frame);
          channel.#open();
          signal2.throwIfAborted();
          return await raw.live.trySend(encrypted, { signal: signal2 });
        } finally {
          channel.#liveBusy = false;
        }
      },
      async *frames(signal2) {
        const lifetime2 = signal2 === void 0 ? channel.#signal : AbortSignal.any([channel.#signal, signal2]);
        for await (const frame of raw.live.frames(lifetime2)) {
          channel.#open();
          lifetime2.throwIfAborted();
          requireNetwork(channel.#inbound !== void 0, "APPLICATION_PEER_AUTHENTICATION_REQUIRED");
          const plaintext = await channel.#inbound.live.open(frame);
          channel.#open();
          lifetime2.throwIfAborted();
          if (plaintext !== null) yield plaintext;
        }
      },
      close: () => raw.live.close()
    };
    this.connection = {
      signal: lifetime,
      ...live === void 0 ? {} : { live },
      async send(frame, options = {}) {
        const signal2 = options.signal === void 0 ? lifetime : AbortSignal.any([lifetime, options.signal]);
        channel.#open();
        signal2.throwIfAborted();
        requireNetwork(!channel.#reliableBusy, "APPLICATION_NETWORK_BACKPRESSURE");
        channel.#reliableBusy = true;
        try {
          const bytes = channel.#sending ? await channel.#outbound.reliable.seal(frame) : frame;
          channel.#open();
          signal2.throwIfAborted();
          await raw.send(bytes, { signal: signal2 });
        } catch (error) {
          if (channel.#sending) {
            channel.clear();
            void raw.close().catch(() => void 0);
          }
          throw error;
        } finally {
          channel.#reliableBusy = false;
        }
      },
      async *frames(signal2) {
        const lifetime2 = signal2 === void 0 ? channel.#signal : AbortSignal.any([channel.#signal, signal2]);
        for await (const frame of raw.frames(lifetime2)) {
          channel.#open();
          lifetime2.throwIfAborted();
          const plaintext = channel.#inbound === void 0 ? frame : await channel.#inbound.reliable.open(frame);
          channel.#open();
          lifetime2.throwIfAborted();
          yield plaintext;
        }
      },
      close: async () => {
        channel.clear();
        await raw.close();
      }
    };
    lifetime.addEventListener("abort", this.#onAbort, { once: true });
    if (lifetime.aborted) this.clear();
  }
  #open() {
    this.#signal.throwIfAborted();
    requireNetwork(!this.#closed, "APPLICATION_CHANNEL_CLOSED");
  }
  async hello() {
    this.#open();
    requireNetwork(!this.#hello, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    this.#hello = true;
    const receiver = await generateX25519KeyPair(false);
    this.#open();
    this.#receiver = receiver;
    return { suite: APPLICATION_CHANNEL_SUITE, receiverKey: bytesToHex2(receiver.publicKeyBytes) };
  }
  async prepare(peerReceiverKey, sender, receiver) {
    this.#open();
    requireNetwork(!this.#preparing, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    this.#preparing = true;
    const exported = await hpkeSendExportBase(hexToBytes2(peerReceiverKey), context(sender, receiver), EXPORT_CONTEXT, 88);
    try {
      this.#open();
      const outbound = await direction(exported.exportedSecret, "encrypt");
      if (this.#closed || this.#signal.aborted) {
        clear(outbound);
        this.#open();
      }
      this.#outbound = outbound;
      return bytesToHex2(exported.encapsulatedKey);
    } finally {
      exported.exportedSecret.fill(0);
    }
  }
  /** Called only when every public proof fragment has been dispatched. */
  enableSending() {
    this.#open();
    requireNetwork(this.#outbound !== void 0 && !this.#sending, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    this.#sending = true;
  }
  async accept(encapsulatedKey, sender, receiver) {
    this.#open();
    requireNetwork(this.#receiver !== void 0 && this.#inbound === void 0, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    const key = this.#receiver;
    this.#receiver = void 0;
    const secret = await hpkeReceiveExportBase(key.privateKey, key.publicKeyBytes, hexToBytes2(encapsulatedKey), context(sender, receiver), EXPORT_CONTEXT, 88);
    try {
      this.#open();
      const inbound = await direction(secret, "decrypt");
      if (this.#closed || this.#signal.aborted) {
        clear(inbound);
        this.#open();
      }
      this.#inbound = inbound;
    } finally {
      secret.fill(0);
    }
  }
  clear() {
    if (this.#closed) return;
    this.#closed = true;
    this.#receiver = void 0;
    this.#signal.removeEventListener("abort", this.#onAbort);
    clear(this.#outbound);
    clear(this.#inbound);
    this.#outbound = void 0;
    this.#inbound = void 0;
  }
};

// packages/peer-session/src/network-facts.ts
var PeerFactKnowledge = class {
  #known = /* @__PURE__ */ new Map();
  get size() {
    return this.#known.size;
  }
  async #digestItems(facts) {
    const publicOps = facts.publicOps.map((raw) => {
      const digest3 = bytesToHex(sha256Sync(raw));
      return { key: `pub/${digest3}`, digest: digest3, value: raw };
    });
    const encryptedEnvelopes = facts.encryptedEnvelopes.map((raw) => {
      const digest3 = bytesToHex(encryptedEnvelopeDigest(raw));
      return { key: `enc/${digest3}`, digest: digest3, value: raw };
    });
    const casNodes = facts.casNodes.map((node) => ({
      key: `cas/${node.partition}/${node.hash}`,
      digest: node.hash,
      value: node
    }));
    const retentions = await Promise.all(facts.retentions.map(async (value) => {
      const digest3 = await recordDigest(value);
      return { key: `ret/${digest3}`, digest: digest3, value };
    }));
    const checkpoints = await Promise.all(facts.checkpoints.map(async (value) => {
      const digest3 = await recordDigest(value);
      return { key: `cp/${await recordDigest(value.payload)}`, digest: digest3, value };
    }));
    return { publicOps, encryptedEnvelopes, casNodes, retentions, checkpoints };
  }
  async remember(facts) {
    const entries = await this.#digestItems(facts);
    for (const group of [entries.publicOps, entries.encryptedEnvelopes, entries.casNodes, entries.retentions, entries.checkpoints]) {
      for (const item of group) this.#known.set(item.key, item.digest);
    }
  }
  async missing(facts) {
    const entries = await this.#digestItems(facts);
    const filter = (list) => list.filter((item) => this.#known.get(item.key) !== item.digest).map((item) => item.value);
    return {
      publicOps: filter(entries.publicOps),
      encryptedEnvelopes: filter(entries.encryptedEnvelopes),
      casNodes: filter(entries.casNodes),
      retentions: filter(entries.retentions),
      checkpoints: filter(entries.checkpoints)
    };
  }
};

// packages/peer-session/src/network.ts
var tracked = /* @__PURE__ */ new WeakMap();
var activeLinks = /* @__PURE__ */ new WeakMap();
var linkListeners = /* @__PURE__ */ new WeakMap();
function applicationPeerDiagnostics(session) {
  return [...tracked.get(session)?.values() ?? []].map((snapshot) => snapshot());
}
function applicationPeerLinks(session) {
  return [...activeLinks.get(session)?.values() ?? []];
}
function onApplicationPeerLink(session, listener) {
  let set = linkListeners.get(session);
  if (!set) linkListeners.set(session, set = /* @__PURE__ */ new Set());
  set.add(listener);
  for (const link of applicationPeerLinks(session)) {
    try {
      listener({ type: "connected", link });
    } catch {
    }
  }
  return () => {
    set.delete(listener);
  };
}
var unavailableMedia = Object.freeze({
  available: false,
  unavailableReason: "relay",
  addTrack() {
    throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
  },
  removeTrack() {
    throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
  },
  addTransceiver() {
    throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
  },
  getTransceivers() {
    return [];
  },
  onTrack() {
    return () => {
    };
  },
  async restartIce() {
    throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
  }
});
var unavailableStreams = Object.freeze({
  available: false,
  unavailableReason: "relay",
  open() {
    throw new Error("WEBRTC_STREAMS_UNAVAILABLE");
  },
  onStream() {
    return () => {
    };
  }
});
async function connectApplicationPeer(session, options) {
  check(session.status.connectedPeers < APPLICATION_NETWORK_LIMITS.peers, "SESSION_PEER_LIMIT");
  const lifetime = new AbortController();
  const signal = AbortSignal.any([lifetime.signal, session.signal, options.connection.signal, ...options.signal === void 0 ? [] : [options.signal]]);
  const secure = new ApplicationSecureChannel(options.connection, signal);
  const wire = new ApplicationMessageWire(secure.connection, signal, options.handshakeTimeoutMs ?? 3e4);
  const iterator = wire.messages()[Symbol.asyncIterator]();
  const localNonce = crypto.randomUUID(), connectionId = crypto.randomUUID();
  const timeout2 = setTimeout(() => lifetime.abort(new Error("PEER_HANDSHAKE_TIMEOUT")), options.handshakeTimeoutMs ?? 3e4);
  let authenticated = false;
  let stopping;
  let stopFacts;
  let signalRoute;
  let contentLink;
  let inBandRtc;
  let createdLink;
  let sentLiveBytes = 0, receivedLiveBytes = 0;
  const liveDiagnostics = () => signalRoute === void 0 ? {} : { sentLiveBytes, receivedLiveBytes, signalRejections: signalRoute.diagnostics };
  const pending = /* @__PURE__ */ new Map();
  const close = () => stopping ??= (async () => {
    lifetime.abort(new Error("PEER_CLOSED"));
    stopFacts?.();
    signalRoute?.close();
    contentLink?.close();
    inBandRtc?.close();
    secure.clear();
    for (const value of pending.values()) {
      clearTimeout(value.timer);
      value.reject(signal.reason);
    }
    pending.clear();
    if (authenticated) {
      authenticated = false;
      tracked.get(session)?.delete(connectionId);
      if (createdLink) {
        const links = activeLinks.get(session);
        if (links?.get(connectionId) === createdLink) links.delete(connectionId);
        for (const listener of linkListeners.get(session) ?? []) {
          try {
            listener({ type: "disconnected", link: createdLink });
          } catch {
          }
        }
      }
      session.setConnectedPeers(tracked.get(session)?.size ?? 0);
    }
    await options.connection.close();
    void iterator.return?.();
  })();
  signal.addEventListener("abort", () => {
    void close().catch(() => void 0);
  }, { once: true });
  try {
    const publicControl = await session.exportPublicControlFacts();
    await wire.send({
      kind: "hello",
      value: await signRecord("peer-hello", {
        applicationId: session.applicationId,
        nonce: localNonce,
        publicOps: publicControl.publicOps,
        casNodes: publicControl.casNodes,
        channel: await secure.hello()
      }, session.device.identity)
    });
    const next = await iterator.next();
    check(!next.done, "PEER_HELLO_MISSING");
    const hello = next.value;
    check(hello.kind === "hello", "PEER_HELLO_INVALID");
    await verifyRecord("peer-hello", hello.value);
    check(
      hello.value.payload.applicationId === session.applicationId && typeof hello.value.payload.nonce === "string" && hello.value.payload.nonce.length <= 128 && (options.peerIdentity === void 0 || options.peerIdentity === hello.value.signer),
      "PEER_SCOPE_MISMATCH"
    );
    await session.mergeFacts({
      publicOps: hello.value.payload.publicOps,
      encryptedEnvelopes: [],
      casNodes: hello.value.payload.casNodes.filter((n) => n.partition === "public"),
      retentions: [],
      checkpoints: []
    });
    check(session.isMember(hello.value.signer), "PEER_MEMBER_REQUIRED");
    const localContext = { applicationId: session.applicationId, identity: session.device.identity.publicKey, nonce: localNonce };
    const peerContext = { applicationId: session.applicationId, identity: hello.value.signer, nonce: hello.value.payload.nonce };
    const encapsulatedKey = await secure.prepare(hello.value.payload.channel.receiverKey, localContext, peerContext);
    await wire.send({
      kind: "proof",
      value: await signRecord("peer-proof", {
        applicationId: session.applicationId,
        localNonce,
        peerNonce: hello.value.payload.nonce,
        encapsulatedKey
      }, session.device.identity)
    });
    secure.enableSending();
    const proofNext = await iterator.next();
    check(!proofNext.done, "PEER_PROOF_MISSING");
    const proof = proofNext.value;
    check(proof.kind === "proof", "PEER_PROOF_INVALID");
    await verifyRecord("peer-proof", proof.value, hello.value.signer);
    check(
      proof.value.payload.applicationId === session.applicationId && proof.value.payload.localNonce === hello.value.payload.nonce && proof.value.payload.peerNonce === localNonce,
      "PEER_PROOF_CONTEXT_INVALID"
    );
    await secure.accept(proof.value.payload.encapsulatedKey, peerContext, localContext);
    clearTimeout(timeout2);
    const peerId = hello.value.signer;
    const connections = tracked.get(session) ?? /* @__PURE__ */ new Map();
    check(connections.size < APPLICATION_NETWORK_LIMITS.peers, "SESSION_PEER_LIMIT");
    tracked.set(session, connections);
    authenticated = true;
    connections.set(connectionId, () => ({
      connectionId,
      peerId,
      kind: "unknown",
      sentReliableBytes: wire.stats.sentBytes,
      receivedReliableBytes: wire.stats.receivedBytes,
      ...liveDiagnostics()
    }));
    session.setConnectedPeers(connections.size);
    const authorizeReader = () => {
      check(session.isReader(peerId) && session.isReader(session.device.identity.publicKey), "RTC_FORBIDDEN");
    };
    const sendRtc = (rtcMessage) => wire.send({ kind: "rtc", message: rtcMessage }, authorizeReader);
    const polite = session.device.identity.publicKey < peerId;
    const rtcSession = options.connection.session;
    if (rtcSession !== void 0) {
      inBandRtc = rtcSession.attachInBandSignaling({ polite, send: sendRtc });
    } else if (typeof options.connection.attachInBandSignaling === "function") {
      inBandRtc = options.connection.attachInBandSignaling({ peerId, polite, send: sendRtc });
    }
    const transportKind = rtcSession !== void 0 || typeof options.connection.attachInBandSignaling === "function" ? "direct" : "relay";
    if (secure.connection.live !== void 0 && session.isReader(peerId)) {
      const live = secure.connection.live;
      signalRoute = session.signals.attachRoute({
        async trySend(frame, input) {
          const accepted = await live.trySend(frame, input);
          if (accepted) sentLiveBytes = Math.min(Number.MAX_SAFE_INTEGER, sentLiveBytes + frame.length);
          return accepted;
        }
      });
      void (async () => {
        try {
          for await (const frame of live.frames(signal)) {
            if (!session.isReader(peerId)) break;
            receivedLiveBytes = Math.min(Number.MAX_SAFE_INTEGER, receivedLiveBytes + frame.length);
            await signalRoute?.receive(frame);
          }
        } catch {
        }
      })();
    }
    contentLink = createNetworkContent({
      content: session.content,
      peerId,
      signal,
      authorize: () => session.isReader(peerId) && session.isReader(session.device.identity.publicKey),
      send: (message) => wire.send(
        { kind: "content", message },
        () => check(session.isReader(peerId) && session.isReader(session.device.identity.publicKey), "CONTENT_FORBIDDEN")
      )
    });
    const knowledge = new PeerFactKnowledge();
    const retainIncoming = async (facts) => {
      for (const raw of facts.publicOps) {
        try {
          const signed = decodeSignedOperation(raw);
          const core = decodeOperationCore(signed.coreBytes);
          const proposalId = bytesToHex(operationIdDigest(signed.coreBytes));
          await session.retain(proposalId, {
            author: bytesToHex(core.author),
            envelopeDigest: bytesToHex(sha256Sync(raw))
          });
        } catch {
        }
      }
      for (const raw of facts.encryptedEnvelopes) {
        try {
          const envDigest = bytesToHex(encryptedEnvelopeDigest(raw));
          const inspected = session.inspectOperation(envDigest);
          if (inspected.stored) {
            await session.retain(inspected.proposalId, { author: inspected.author, envelopeDigest: envDigest });
          }
        } catch {
        }
      }
    };
    let sendTail = Promise.resolve();
    const sendFacts = (requestId = "") => {
      const task = sendTail.then(async () => {
        signal.throwIfAborted();
        const allFacts = await session.exportFacts({ includePrivateCas: session.isReader(peerId) });
        const facts = await knowledge.missing(allFacts);
        const count = facts.publicOps.length + facts.encryptedEnvelopes.length + facts.casNodes.length + facts.retentions.length + facts.checkpoints.length;
        if (requestId === "" && count === 0) return;
        await wire.send({ kind: "facts", requestId, facts });
        await knowledge.remember(facts);
      });
      sendTail = task.catch(() => void 0);
      return task;
    };
    let flushing, dirty = false;
    const publish = () => {
      dirty = true;
      return flushing ??= (async () => {
        try {
          while (dirty && !signal.aborted) {
            dirty = false;
            await sendFacts();
          }
        } finally {
          flushing = void 0;
        }
      })();
    };
    stopFacts = session.onFacts(() => {
      void publish().catch(() => close());
    });
    void (async () => {
      try {
        while (!signal.aborted) {
          const incoming = await iterator.next();
          if (incoming.done) break;
          const message = incoming.value;
          check(session.isMember(peerId), "PEER_REVOKED");
          if (message.kind === "facts") {
            check(typeof message.requestId === "string" && message.requestId.length <= 128, "PEER_REQUEST_INVALID");
            await session.mergeFacts(message.facts);
            await knowledge.remember(message.facts);
            await retainIncoming(message.facts);
            if (message.requestId !== "") await wire.send({ kind: "ack", requestId: message.requestId });
          } else if (message.kind === "content") {
            await contentLink.handle(message.message);
          } else if (message.kind === "rtc") {
            if (inBandRtc !== void 0 && session.isReader(peerId)) {
              void inBandRtc.receive(message.message).catch(() => void 0);
            }
          } else if (message.kind === "ack") {
            const waiter = pending.get(message.requestId);
            if (waiter !== void 0) {
              pending.delete(message.requestId);
              clearTimeout(waiter.timer);
              waiter.resolve();
            }
          } else {
            throw new Error("PEER_MESSAGE_INVALID");
          }
        }
      } catch (error) {
        lifetime.abort(error);
      } finally {
        await close();
      }
    })();
    await publish();
    const completion = signal.aborted ? Promise.resolve() : new Promise((resolve) => signal.addEventListener("abort", () => resolve(), { once: true }));
    const link = {
      peerIdentity: peerId,
      transportKind,
      media: rtcSession?.media ?? unavailableMedia,
      streams: rtcSession?.streams ?? unavailableStreams,
      signal,
      completion,
      get stats() {
        return { ...wire.stats, ...liveDiagnostics() };
      },
      close,
      synchronize() {
        check(!signal.aborted && pending.size < 4, "PEER_REQUEST_LIMIT");
        const requestId = crypto.randomUUID();
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            pending.delete(requestId);
            reject(new Error("PEER_SYNC_TIMEOUT"));
            void close();
          }, 3e4);
          pending.set(requestId, { resolve, reject, timer });
          void sendFacts(requestId).catch((error) => {
            clearTimeout(timer);
            pending.delete(requestId);
            reject(error);
            void close();
          });
        });
      }
    };
    createdLink = link;
    let sessionLinks = activeLinks.get(session);
    if (!sessionLinks) {
      sessionLinks = /* @__PURE__ */ new Map();
      activeLinks.set(session, sessionLinks);
    }
    sessionLinks.set(connectionId, link);
    for (const listener of linkListeners.get(session) ?? []) {
      try {
        listener({ type: "connected", link });
      } catch {
      }
    }
    return link;
  } catch (error) {
    await close();
    throw error;
  } finally {
    clearTimeout(timeout2);
  }
}

// packages/peer-session/src/operation.ts
var ApplicationOperation = class {
  constructor(id, operationId, owner) {
    this.id = id;
    this.operationId = operationId;
    this.owner = owner;
  }
  id;
  operationId;
  owner;
  stored = true;
  inspect() {
    return this.owner.inspectOperation(this.id);
  }
  async materialized(options) {
    return (await this.owner.waitOperation(this.id, "materialized", options)).materialized;
  }
  async retained(options) {
    return (await this.owner.waitOperation(this.id, "retained", options)).retained;
  }
  async finalized(options) {
    return (await this.owner.waitOperation(this.id, "finalized", options)).materialized;
  }
};

// packages/peer-session/src/session-types.ts
var APPLICATION_EVENT_CURSOR_LIMIT = 128 * 1024;

// packages/peer-session/src/session.ts
function sameBytes(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}
function globMatches(pattern, topic) {
  if (pattern === "*" || pattern === topic) return true;
  if (pattern.endsWith("*")) return topic.startsWith(pattern.slice(0, -1));
  return false;
}
function toMaterializedRevision(rev) {
  return Object.freeze({
    digest: rev.digest,
    stateRoot: rev.stateRoot,
    historyDigest: rev.historyDigest,
    view: rev.view,
    orderLength: rev.orderLength
  });
}
function toApplicationEvent(ev) {
  return Object.freeze({
    id: `${ev.opId}:${ev.eventOrdinal}`,
    proposalId: ev.opId,
    operationId: ev.operationId,
    author: ev.author,
    authorTimestampMs: ev.authorTimestampMs.toString(),
    topic: ev.topic,
    payload: structuredClone(ev.payload)
  });
}
var ApplicationSession = class _ApplicationSession {
  applicationId;
  logId;
  genesis;
  genesisBytes;
  device;
  identity;
  definition;
  cas;
  content;
  signals;
  #store;
  #prefix;
  #lifetime = new AbortController();
  #release;
  #blindHostMode;
  #blockchainVerifier;
  #sandboxOptions;
  #sqliteWasmModule;
  #maxOperations;
  #sqliteDriver;
  #sqliteLoadPromise;
  #kernel;
  #kernelHasSqlite = false;
  #controlKernel = null;
  #finalKernel = null;
  #publicOps = /* @__PURE__ */ new Map();
  #encryptedEnvelopes = /* @__PURE__ */ new Map();
  #localPending = /* @__PURE__ */ new Map();
  #retentions = /* @__PURE__ */ new Map();
  #checkpoints = /* @__PURE__ */ new Map();
  #epochKeys = /* @__PURE__ */ new Map();
  #statusListeners = /* @__PURE__ */ new Set();
  #changeListeners = /* @__PURE__ */ new Set();
  #factListeners = /* @__PURE__ */ new Set();
  #connectedPeers = 0;
  #connectionRevision = 0;
  #materializationError = null;
  #lastLocalRevision;
  #lastFinalRevision = null;
  #verifiedFinality = {
    closedThroughMs: null,
    includedOpIds: /* @__PURE__ */ new Set(),
    excludedOpIds: /* @__PURE__ */ new Set(),
    latestCheckpoint: null,
    verifiedCheckpoints: []
  };
  #cachedSignalPolicy = null;
  #cachedDescription = null;
  #evaluatedPermissions = null;
  #closed = false;
  #closing;
  #tail = Promise.resolve();
  constructor(options, genesisBytes, cas) {
    this.genesisBytes = genesisBytes.slice();
    this.genesis = decodeLogGenesis(this.genesisBytes);
    this.logId = bytesToHex(genesisLogId(this.genesisBytes));
    this.applicationId = options.applicationId ?? this.logId;
    this.device = options.device;
    this.identity = Object.freeze({ publicKey: options.device.identity.publicKey });
    if (options.definition !== void 0) this.definition = options.definition;
    this.cas = cas;
    this.#store = options.store;
    this.#prefix = `v2/${this.logId}`;
    this.#release = options.release;
    this.#blindHostMode = options.blindHostMode ?? false;
    if (options.blockchainVerifier !== void 0) this.#blockchainVerifier = options.blockchainVerifier;
    if (options.sqliteWasmModule !== void 0) this.#sqliteWasmModule = options.sqliteWasmModule;
    this.#maxOperations = options.maxOperations ?? 5e4;
    this.#sandboxOptions = {
      ...options.wasmModule === void 0 ? {} : { wasmModule: options.wasmModule },
      ...options.sqliteDriver === void 0 ? {} : { sqliteDriver: options.sqliteDriver }
    };
    if (options.sqliteDriver !== void 0) {
      this.#sqliteDriver = options.sqliteDriver;
      this.#kernelHasSqlite = true;
    }
    this.#kernel = new TopicKernel({
      genesis: this.genesisBytes,
      cas: this.cas,
      blindHostMode: this.#blindHostMode,
      ...this.#sandboxOptions
    });
    if (this.genesis.privateLog && !this.#blindHostMode) {
      this.#controlKernel = new TopicKernel({
        genesis: this.genesisBytes,
        cas: this.cas,
        blindHostMode: true,
        ...this.#sandboxOptions
      });
    }
    this.#lastLocalRevision = toMaterializedRevision(this.#kernel.revision("local"));
    this.content = new ApplicationContent({
      store: this.#store,
      identity: this.device.identity,
      storageId: this.device.storageId,
      authority: {
        applicationId: this.applicationId,
        isReader: (pk) => this.isReader(pk),
        currentEpoch: () => Math.max(0, this.currentEpoch()),
        epochKey: (epoch) => this.#epochKeys.get(epoch) ?? null
      }
    });
    this.signals = new SignalChannel({
      scope: this.applicationId,
      identity: {
        publicKeyBytes: hexToBytes(this.device.identity.publicKey),
        privateKey: this.device.identity.privateKey
      },
      localEcho: true,
      authorize: async (auth) => {
        if (auth.scope !== this.applicationId) return false;
        const authorHex = bytesToHex(auth.authorId);
        const policy = await this.#resolveSignalPolicy();
        for (const rule of policy.rules) {
          if (!globMatches(rule.topicPattern, auth.topic)) continue;
          if (!rule.allowedAuthors.includes("*") && !rule.allowedAuthors.includes(authorHex)) continue;
          return true;
        }
        return false;
      }
    });
  }
  static async open(options) {
    const cas = new ContentAddressedStore({ store: options.store });
    await cas.preload();
    if (options.casNodes !== void 0) {
      for (const node of options.casNodes) {
        const expected = computeCasHash(node.bytes, []);
        if (expected === node.hash) {
          await cas.put(node.bytes, [], node.partition);
        } else if (hashCasNode(node.bytes) === node.hash) {
          await cas.putRaw(node.hash, node.bytes, node.partition);
        } else {
          throw new Error(`CAS_NODE_HASH_MISMATCH:${node.hash}`);
        }
      }
    }
    let genesisBytes = null;
    if (options.genesis !== void 0) {
      genesisBytes = options.genesis instanceof Uint8Array ? options.genesis.slice() : encodeLogGenesis(options.genesis);
      const logId = bytesToHex(genesisLogId(genesisBytes));
      if (options.logId !== void 0 && options.logId !== logId) {
        throw new Error("SESSION_CHAIN_ID_MISMATCH");
      }
      const existing = await options.store.get(`v2/${logId}/genesis`);
      if (existing !== null && !sameBytes(existing, genesisBytes)) {
        throw new Error("SESSION_GENESIS_MISMATCH");
      }
      if (existing === null) await options.store.put(`v2/${logId}/genesis`, genesisBytes);
    } else if (options.logId !== void 0) {
      genesisBytes = await options.store.get(`v2/${options.logId}/genesis`);
    } else {
      const all = await readAllStoreEntries(options.store);
      for (const entry of all) {
        if (entry.key.startsWith("v2/") && entry.key.endsWith("/genesis")) {
          genesisBytes = entry.value;
          break;
        }
      }
    }
    if (genesisBytes === null) throw new Error("SESSION_GENESIS_NOT_FOUND");
    const session = new _ApplicationSession(options, genesisBytes, cas);
    if (options.epochKeys !== void 0) {
      for (const [epoch, key] of options.epochKeys) {
        await session.installEpochKey(epoch, key);
      }
    }
    await session.#hydrateFromStore();
    await session.#rematerialize();
    return session;
  }
  get signal() {
    return this.#lifetime.signal;
  }
  get status() {
    const pendingOps = this.#countPendingOps();
    const canAuthor = !this.#closed && !this.#blindHostMode && this.#canLocallyAuthor();
    const awaitingKeys = this.genesis.privateLog && !this.#blindHostMode && this.isReader(this.identity.publicKey) && this.currentEpoch() >= 0 && !this.#epochKeys.has(this.currentEpoch());
    return Object.freeze({
      ...this.#kernel.pendingDependencies.length > 0 ? { pendingDependencies: this.#kernel.pendingDependencies } : {},
      canAuthor,
      phase: this.#closed ? "closed" : awaitingKeys ? "awaiting-keys" : "ready",
      database: this.#closed ? "closed" : this.#materializationError !== null ? "failed" : "ready",
      connectedPeers: this.#connectedPeers,
      connectionRevision: this.#connectionRevision,
      pendingOperations: pendingOps,
      materializationError: this.#materializationError
    });
  }
  permissions() {
    if (this.#evaluatedPermissions !== null) {
      const p = this.#evaluatedPermissions;
      return {
        mode: p.mode,
        members: p.members,
        readers: p.openReaders ? ["*"] : [...p.readers].sort(),
        writers: p.openWriters ? ["*"] : [...p.writers].sort(),
        administrators: [...p.administrators].sort(),
        publishers: [...p.publishers].sort(),
        openReaders: p.openReaders,
        openWriters: p.openWriters,
        blockedAuthors: [...p.blockedAuthors].sort(),
        admission: p.admission,
        multisig: p.multisig
      };
    }
    const raw = this.#kernel.topic("$permissions");
    if (raw === null || typeof raw !== "object" || !Array.isArray(raw.members)) {
      return { members: [], openReaders: false, openWriters: false, blockedAuthors: [], admission: null, multisig: null };
    }
    return raw;
  }
  member(publicKey) {
    return this.permissions().members.find((m) => m.publicKey === publicKey) ?? null;
  }
  isBlockedAuthor(publicKey) {
    return this.#evaluatedPermissions !== null && this.#evaluatedPermissions.blockedAuthors.has(publicKey);
  }
  isMember(publicKey) {
    if (this.#evaluatedPermissions !== null) {
      if (this.#evaluatedPermissions.openWriters || this.#evaluatedPermissions.openReaders) return /^[0-9a-f]{64}$/u.test(publicKey);
      return this.#evaluatedPermissions.members.some((m) => m.publicKey === publicKey) || this.#evaluatedPermissions.readers.has(publicKey) || this.#evaluatedPermissions.writers.has(publicKey) || this.#evaluatedPermissions.administrators.has(publicKey);
    }
    return this.member(publicKey) !== null;
  }
  isReader(publicKey) {
    if (!this.genesis.privateLog) return true;
    if (this.#evaluatedPermissions !== null) {
      if (this.#evaluatedPermissions.openReaders) return /^[0-9a-f]{64}$/u.test(publicKey);
      return this.#evaluatedPermissions.readers.has(publicKey);
    }
    return this.member(publicKey)?.reader === true;
  }
  isWriter(publicKey) {
    if (this.#evaluatedPermissions !== null) {
      if (this.#evaluatedPermissions.blockedAuthors.has(publicKey)) return false;
      if (this.#evaluatedPermissions.openWriters) return /^[0-9a-f]{64}$/u.test(publicKey);
      return this.#evaluatedPermissions.writers.has(publicKey) || this.#evaluatedPermissions.administrators.has(publicKey);
    }
    return this.member(publicKey)?.writer === true || this.member(publicKey)?.administrator === true;
  }
  isAdministrator(publicKey) {
    if (this.#evaluatedPermissions !== null) {
      return this.#evaluatedPermissions.administrators.has(publicKey);
    }
    return this.member(publicKey)?.administrator === true;
  }
  /** Query an arbitrary capability (standard or custom) against the chain's `$permissions` reducer. */
  async checkPermission(capability, actor = this.identity.publicKey) {
    const res = await this.#kernel.query("$permissions", { check: capability, actor }).catch(() => null);
    if (typeof res === "boolean") return res;
    if (capability === "reader") return this.isReader(actor);
    if (capability === "writer") return this.isWriter(actor);
    if (capability === "administrator") return this.isAdministrator(actor);
    if (capability === "publisher") {
      return this.#evaluatedPermissions !== null ? this.#evaluatedPermissions.publishers.has(actor) || this.#evaluatedPermissions.administrators.has(actor) : this.member(actor)?.publisher === true || this.member(actor)?.administrator === true;
    }
    if (capability === "member") return this.isMember(actor);
    return false;
  }
  keysState() {
    const raw = this.#kernel.topic("$keys");
    if (raw === null || typeof raw !== "object") return { currentEpoch: -1, epochs: {} };
    return raw;
  }
  currentEpoch() {
    const state = this.keysState();
    if (state.currentEpoch >= 0) return state.currentEpoch;
    if (this.#epochKeys.size > 0) return Math.max(...this.#epochKeys.keys());
    return -1;
  }
  epochKey(epoch) {
    return this.#epochKeys.get(epoch)?.slice() ?? null;
  }
  hasEpochKey(epoch) {
    return this.#epochKeys.has(epoch);
  }
  exportEpochKeys() {
    const out = /* @__PURE__ */ new Map();
    for (const [ep, key] of this.#epochKeys) out.set(ep, key.slice());
    return out;
  }
  async installEpochKey(epoch, key) {
    check(Number.isSafeInteger(epoch) && epoch >= 0 && key instanceof Uint8Array && key.length === 32, "EPOCH_KEY_INVALID");
    this.#epochKeys.set(epoch, key.slice());
    await this.#store.put(`${this.#prefix}/epoch-key/${epoch}`, key.slice());
  }
  async unlockEpochsFromKeysTopic(wrapPrivateKey, wrapPublicKeyHex) {
    return this.#serial(async () => {
      if (!this.genesis.privateLog || this.#blindHostMode) return 0;
      const keys = this.keysState();
      let unlocked = 0;
      for (const entry of Object.values(keys.epochs ?? {})) {
        if (this.#epochKeys.has(entry.epoch)) continue;
        const box = entry.boxes?.[this.identity.publicKey];
        if (box === void 0) continue;
        try {
          const plainKey = await hpkeOpenEpochKey(
            wrapPrivateKey,
            wrapPublicKeyHex,
            box,
            this.logId,
            entry.epoch
          );
          if (epochKeyCommitmentV2(plainKey) !== entry.keyCommitment) continue;
          await this.installEpochKey(entry.epoch, plainKey);
          unlocked++;
        } catch {
        }
      }
      if (unlocked > 0) await this.#rematerialize();
      return unlocked;
    });
  }
  topic(name) {
    return this.#kernel.topic(name);
  }
  revision(view = "local") {
    if (view === "final") {
      return this.#lastFinalRevision ?? toMaterializedRevision(this.#kernel.revision("final"));
    }
    return this.#lastLocalRevision;
  }
  async retryMaterialization() {
    await this.#serial(() => this.#rematerialize());
  }
  #canLocallyAuthor() {
    const pk = this.identity.publicKey;
    const isAdmin = this.isAdministrator(pk);
    const isPub = this.#evaluatedPermissions !== null ? this.#evaluatedPermissions.publishers.has(pk) : this.member(pk)?.publisher === true;
    if (!this.isWriter(pk) && !isAdmin && !isPub) return false;
    if (this.genesis.privateLog && this.currentEpoch() >= 0 && !this.#epochKeys.has(this.currentEpoch())) {
      return isAdmin;
    }
    return true;
  }
  #countPendingOps() {
    let count = this.#kernel.pendingDependencies.length;
    if (!this.#blindHostMode) {
      for (const entry of this.#encryptedEnvelopes.values()) {
        if (entry.decrypted === void 0) count++;
      }
    }
    return count;
  }
  #serial(work) {
    const task = this.#tail.then(() => {
      if (this.#closed) throw new Error("SESSION_CLOSED");
      return work();
    });
    this.#tail = task.catch(() => void 0);
    return task;
  }
  #emitStatus() {
    const snap = this.status;
    for (const listener of this.#statusListeners) {
      try {
        listener(snap);
      } catch {
      }
    }
  }
  #emitChange(change) {
    for (const listener of this.#changeListeners) {
      try {
        listener(change);
      } catch {
      }
    }
  }
  #emitFacts() {
    for (const listener of this.#factListeners) {
      try {
        listener();
      } catch {
      }
    }
  }
  onStatus(listener) {
    this.#statusListeners.add(listener);
    try {
      listener(this.status);
    } catch {
    }
    return () => {
      this.#statusListeners.delete(listener);
    };
  }
  onChange(listener) {
    this.#changeListeners.add(listener);
    return () => {
      this.#changeListeners.delete(listener);
    };
  }
  onFacts(listener) {
    this.#factListeners.add(listener);
    return () => {
      this.#factListeners.delete(listener);
    };
  }
  async *changes(options = {}) {
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    const queue = [];
    let wake;
    const stop = this.onChange((value) => {
      queue.splice(0, queue.length, value);
      wake?.();
    });
    const abort = () => {
      wake?.();
    };
    signal.addEventListener("abort", abort);
    try {
      while (!signal.aborted) {
        if (queue.length === 0) await new Promise((resolve) => {
          wake = resolve;
        });
        while (queue.length > 0 && !signal.aborted) yield queue.shift();
      }
    } finally {
      stop();
      signal.removeEventListener("abort", abort);
    }
  }
  setConnectedPeers(count) {
    this.#connectedPeers = count;
    this.#connectionRevision++;
    this.#emitStatus();
  }
  async #ensureSqliteIfNeeded(reducersOverride) {
    if (this.#sqliteDriver !== void 0) return !this.#kernelHasSqlite;
    const reducersRaw = reducersOverride !== void 0 ? reducersOverride : this.#kernel.topic("$reducers");
    if (reducersRaw === null) return false;
    let needsSqlite = false;
    try {
      const cfg = assertValidReducersConfig(reducersRaw);
      const queue = [];
      const visited = /* @__PURE__ */ new Set();
      for (const [topicName, binding] of Object.entries(cfg.topics)) {
        if (this.#blindHostMode && this.genesis.privateLog && !isControlTopic(topicName)) continue;
        queue.push(binding.module);
      }
      const importSpecRe = /\bfrom\s*['"]([^'"]+)['"]|\bimport\s*\(\s*['"]([^'"]+)['"]\s*\)/gu;
      while (queue.length > 0) {
        const modSpec = queue.shift();
        if (visited.has(modSpec)) continue;
        visited.add(modSpec);
        if (modSpec === "chronolog:sqlite" || modSpec === "chronolog/sql" || modSpec === "chronolog/sqlite-helpers") {
          needsSqlite = true;
          break;
        }
        const ref = cfg.imports[modSpec];
        if (ref === void 0 || !ref.startsWith("cas:sha256-")) continue;
        const hash = ref.slice(11);
        const node = await this.cas.get(hash, "any");
        if (node === null) continue;
        const text = new TextDecoder().decode(node.bytes);
        if (text.includes("chronolog:sqlite") || text.includes("chronolog/sql") || text.includes("chronolog/sqlite-helpers")) {
          needsSqlite = true;
          break;
        }
        importSpecRe.lastIndex = 0;
        let match;
        while ((match = importSpecRe.exec(text)) !== null) {
          const dep = match[1] ?? match[2];
          if (dep !== void 0 && !visited.has(dep) && Object.hasOwn(cfg.imports, dep)) {
            queue.push(dep);
          }
        }
      }
    } catch {
      return false;
    }
    if (!needsSqlite) return false;
    this.#sqliteLoadPromise ??= (async () => {
      const mod = await import("./src-PQDYXONH.mjs");
      const driver = await mod.createSqliteCasDriver({
        ...this.#sqliteWasmModule === void 0 ? {} : { wasmModule: this.#sqliteWasmModule }
      });
      this.#sqliteDriver = driver;
      return driver;
    })();
    await this.#sqliteLoadPromise;
    return !this.#kernelHasSqlite;
  }
  async #refreshPermissionsCache(kernel = this.#kernel) {
    const parseStringList = (val) => {
      const keys = /* @__PURE__ */ new Set();
      let open = false;
      if (Array.isArray(val)) {
        for (const item of val) {
          if (item === "*") open = true;
          else if (typeof item === "string") keys.add(item);
        }
      }
      return { keys, open };
    };
    const parseMembers = (val) => {
      if (!Array.isArray(val)) return [];
      return val.filter((m) => m !== null && typeof m === "object" && typeof m.publicKey === "string");
    };
    try {
      const summary = await kernel.query("$permissions", { summary: true });
      if (summary !== null && typeof summary === "object" && !Array.isArray(summary) && Array.isArray(summary.administrators) && Array.isArray(summary.readers)) {
        const s = summary;
        const readers = parseStringList(s.readers);
        const writers = parseStringList(s.writers);
        const admins = parseStringList(s.administrators);
        const pubs = parseStringList(s.publishers);
        const blocked = parseStringList(s.blockedAuthors);
        const admission = s.admission !== null && typeof s.admission === "object" && !Array.isArray(s.admission) ? s.admission : null;
        const msRaw = s.multisig;
        const multisig = msRaw !== null && typeof msRaw === "object" && !Array.isArray(msRaw) && typeof msRaw.threshold === "number" && Array.isArray(msRaw.signers) ? {
          threshold: msRaw.threshold,
          signers: msRaw.signers.filter((k) => typeof k === "string"),
          proposals: msRaw.proposals ?? {}
        } : null;
        const openReaders = s.openReaders === true || readers.open;
        const openWriters = s.openWriters === true || writers.open;
        const mode = s.mode === "attested" || s.mode === "open" || s.mode === "multisig" ? s.mode : multisig !== null ? "multisig" : openReaders || openWriters ? "open" : admission !== null ? "attested" : "custom";
        this.#evaluatedPermissions = {
          mode,
          members: parseMembers(s.members),
          readers: readers.keys,
          writers: writers.keys,
          administrators: admins.keys,
          publishers: pubs.keys,
          openReaders,
          openWriters,
          blockedAuthors: blocked.keys,
          admission,
          multisig
        };
        return;
      }
      const [rRaw, wRaw, aRaw, pRaw, mRaw, admRaw, blkRaw] = await Promise.all([
        kernel.query("$permissions", { list: "readers" }).catch(() => null),
        kernel.query("$permissions", { list: "writers" }).catch(() => null),
        kernel.query("$permissions", { list: "administrators" }).catch(() => null),
        kernel.query("$permissions", { list: "publishers" }).catch(() => null),
        kernel.query("$permissions", { list: "members" }).catch(() => null),
        kernel.query("$permissions", { admission: true }).catch(() => null),
        kernel.query("$permissions", { list: "blockedAuthors" }).catch(() => null)
      ]);
      if (Array.isArray(rRaw) || Array.isArray(wRaw) || Array.isArray(aRaw)) {
        const readers = parseStringList(rRaw);
        const writers = parseStringList(wRaw);
        const admins = parseStringList(aRaw);
        const pubs = parseStringList(pRaw);
        const blocked = parseStringList(blkRaw);
        const admission = admRaw !== null && typeof admRaw === "object" && !Array.isArray(admRaw) ? admRaw : null;
        this.#evaluatedPermissions = {
          mode: readers.open || writers.open ? "open" : admission !== null ? "attested" : "custom",
          members: parseMembers(mRaw),
          readers: readers.keys,
          writers: writers.keys,
          administrators: admins.keys,
          publishers: pubs.keys,
          openReaders: readers.open,
          openWriters: writers.open,
          blockedAuthors: blocked.keys,
          admission,
          multisig: null
        };
        return;
      }
    } catch {
    }
    const raw = kernel.topic("$permissions");
    if (raw !== null && typeof raw === "object" && Array.isArray(raw.members)) {
      const members = parseMembers(raw.members);
      this.#evaluatedPermissions = {
        mode: raw.admission ? "attested" : "custom",
        members,
        readers: new Set(members.filter((m) => m.reader).map((m) => m.publicKey)),
        writers: new Set(members.filter((m) => m.writer || m.administrator).map((m) => m.publicKey)),
        administrators: new Set(members.filter((m) => m.administrator).map((m) => m.publicKey)),
        publishers: new Set(members.filter((m) => m.publisher || m.administrator).map((m) => m.publicKey)),
        openReaders: false,
        openWriters: false,
        blockedAuthors: /* @__PURE__ */ new Set(),
        admission: raw.admission ?? null,
        multisig: null
      };
    } else {
      this.#evaluatedPermissions = null;
    }
  }
  async #hydrateFromStore() {
    const entries = await readAllStoreEntries(this.#store);
    const prefix = `${this.#prefix}/`;
    for (const entry of entries) {
      if (!entry.key.startsWith(prefix)) continue;
      const rest = entry.key.slice(prefix.length);
      if (rest.startsWith("epoch-key/")) {
        const ep = Number(rest.slice("epoch-key/".length));
        if (Number.isSafeInteger(ep) && ep >= 0 && entry.value.length === 32 && !this.#epochKeys.has(ep)) {
          this.#epochKeys.set(ep, entry.value.slice());
        }
      } else if (rest.startsWith("public-op/")) {
        try {
          const signed = decodeSignedOperation(entry.value);
          const verified = await verifySignedOperation(signed);
          if (bytesToHex(verified.core.logId) === this.logId && verified.core.visibility === "public") {
            this.#publicOps.set(bytesToHex(verified.opId), { raw: entry.value.slice(), signed, core: verified.core });
          }
        } catch {
        }
      } else if (rest.startsWith("enc-env/")) {
        try {
          const envelope2 = decodeEncryptedEnvelope(entry.value);
          if (bytesToHex(envelope2.logId) === this.logId) {
            const digest3 = bytesToHex(encryptedEnvelopeDigest(entry.value));
            this.#encryptedEnvelopes.set(digest3, { digest: digest3, raw: entry.value.slice(), envelope: envelope2 });
          }
        } catch {
        }
      } else if (rest.startsWith("local-pending/")) {
        try {
          const rec = decodeRecord(entry.value);
          const signed = decodeSignedOperation(rec.raw);
          const verified = await verifySignedOperation(signed);
          this.#localPending.set(bytesToHex(verified.opId), {
            raw: rec.raw.slice(),
            signed,
            core: verified.core,
            currentEnvelopeDigest: rec.envelopeDigest,
            currentEpoch: rec.epoch
          });
        } catch {
        }
      } else if (rest.startsWith("retention/")) {
        try {
          const ev = decodeRecord(entry.value);
          await verifyRecord("operation-retention", ev, ev.signer);
          let byPeer = this.#retentions.get(ev.payload.proposalId);
          if (byPeer === void 0) {
            byPeer = /* @__PURE__ */ new Map();
            this.#retentions.set(ev.payload.proposalId, byPeer);
          }
          byPeer.set(ev.signer, ev);
        } catch {
        }
      } else if (rest.startsWith("checkpoint/")) {
        try {
          const cp = decodeRecord(entry.value);
          const key = await recordDigest(cp.payload);
          this.#checkpoints.set(key, cp);
        } catch {
        }
      }
    }
  }
  #keysStateFrom(kernel) {
    const raw = kernel.topic("$keys");
    if (raw === null || typeof raw !== "object") return { currentEpoch: -1, epochs: {} };
    return raw;
  }
  #currentEpochFrom(kernel) {
    const state = this.#keysStateFrom(kernel);
    if (state.currentEpoch >= 0) return state.currentEpoch;
    if (this.#epochKeys.size > 0) return Math.max(...this.#epochKeys.keys());
    return -1;
  }
  async #unsealAvailableEpochKeys(kernel = this.#kernel) {
    if (!this.genesis.privateLog || this.#blindHostMode) return false;
    const keys = this.#keysStateFrom(kernel);
    let unlockedAny = false;
    for (const entry of Object.values(keys.epochs ?? {})) {
      if (this.#epochKeys.has(entry.epoch)) continue;
      const box = entry.boxes?.[this.identity.publicKey];
      if (box === void 0) continue;
      try {
        const plainKey = await hpkeOpenEpochKey(
          this.device.wrapKey.privateKey,
          this.device.wrapKey.publicKey,
          box,
          this.logId,
          entry.epoch
        );
        if (epochKeyCommitmentV2(plainKey) !== entry.keyCommitment) continue;
        await this.installEpochKey(entry.epoch, plainKey);
        unlockedAny = true;
      } catch {
      }
    }
    return unlockedAny;
  }
  async #decryptPendingEnvelopes() {
    if (!this.genesis.privateLog || this.#blindHostMode) return;
    for (const entry of this.#encryptedEnvelopes.values()) {
      if (entry.decrypted !== void 0) continue;
      const epochKey = this.#epochKeys.get(entry.envelope.epoch);
      if (epochKey === void 0) continue;
      try {
        const aad = envelopeAad(entry.envelope.logId, entry.envelope.opId, entry.envelope.author);
        const plaintext = await decryptEpochPayload(epochKey, {
          epoch: BigInt(entry.envelope.epoch),
          nonce: entry.envelope.nonce,
          ciphertext: entry.envelope.ciphertext
        }, aad);
        const signed = decodeSignedOperation(plaintext);
        const verified = await verifySignedOperation(signed);
        if (bytesToHex(verified.core.logId) !== this.logId) continue;
        if (verified.core.visibility !== "encrypted") continue;
        if (!sameBytes(verified.opId, entry.envelope.opId) || !sameBytes(verified.core.author, entry.envelope.author)) continue;
        entry.decrypted = { opId: bytesToHex(verified.opId), signed, core: verified.core };
      } catch {
      }
    }
  }
  /**
   * Reconnect rewrapping: if this device authored offline encrypted ops under an older epoch
   * and $keys has since rotated to a newer epoch that we hold (and we are still a writer),
   * re-encrypt the EXACT original SignedOperation bytes under the newest epoch so peers can
   * decrypt them without changing opId, authorTimestampMs, or signature!
   */
  async #rewrapPendingLocalOps(kernel = this.#kernel) {
    if (!this.genesis.privateLog || this.#blindHostMode) return false;
    const newestEpoch = this.#currentEpochFrom(kernel);
    if (newestEpoch < 0) return false;
    const newestKey = this.#epochKeys.get(newestEpoch);
    if (newestKey === void 0 || !this.isWriter(this.identity.publicKey)) return false;
    let rewrapped = false;
    for (const [opId, pending] of this.#localPending) {
      if (pending.currentEpoch >= newestEpoch) continue;
      const logIdBytes = hexToBytes(this.logId);
      const opIdBytes = hexToBytes(opId);
      const aad = envelopeAad(logIdBytes, opIdBytes, pending.core.author);
      const enc = await encryptEpochPayload(newestKey, BigInt(newestEpoch), pending.raw, aad);
      const env = {
        version: 1,
        logId: logIdBytes,
        opId: opIdBytes,
        author: pending.core.author,
        epoch: newestEpoch,
        nonce: enc.nonce,
        ciphertext: enc.ciphertext
      };
      const envBytes = encodeEncryptedEnvelope(env);
      const envDigest = bytesToHex(encryptedEnvelopeDigest(envBytes));
      const oldRetentions = this.#retentions.get(opId);
      const oldRetainedRemotely = oldRetentions !== void 0 && [...oldRetentions.values()].some((r) => r.signer !== this.identity.publicKey);
      if (!oldRetainedRemotely && this.#encryptedEnvelopes.has(pending.currentEnvelopeDigest)) {
        this.#encryptedEnvelopes.delete(pending.currentEnvelopeDigest);
        await this.#store.delete?.(`${this.#prefix}/enc-env/${pending.currentEnvelopeDigest}`);
      }
      await this.#store.put(`${this.#prefix}/enc-env/${envDigest}`, envBytes);
      this.#encryptedEnvelopes.set(envDigest, {
        digest: envDigest,
        raw: envBytes,
        envelope: env,
        decrypted: { opId, signed: pending.signed, core: pending.core }
      });
      pending.currentEpoch = newestEpoch;
      pending.currentEnvelopeDigest = envDigest;
      await this.#store.put(`${this.#prefix}/local-pending/${opId}`, encodeRecord({
        raw: pending.raw,
        envelopeDigest: envDigest,
        epoch: newestEpoch
      }));
      rewrapped = true;
    }
    return rewrapped;
  }
  #collectDecryptedKernelInputs() {
    const byOpId = /* @__PURE__ */ new Map();
    for (const [opId, entry] of this.#publicOps) {
      byOpId.set(opId, { opId: hexToBytes(opId), core: entry.core });
    }
    if (!this.#blindHostMode) {
      for (const entry of this.#encryptedEnvelopes.values()) {
        if (entry.decrypted === void 0) continue;
        if (!byOpId.has(entry.decrypted.opId)) {
          byOpId.set(entry.decrypted.opId, {
            opId: hexToBytes(entry.decrypted.opId),
            core: entry.decrypted.core
          });
        }
      }
    }
    return byOpId;
  }
  async #rematerialize() {
    const prevDigest = this.#lastLocalRevision.digest;
    const prevFinalDigest = this.#lastFinalRevision?.digest ?? null;
    const prevOutcomes = new Map(this.#kernel.outcomes.map((o) => [o.opId, `${o.outcome}:${o.rejectionCode ?? ""}`]));
    try {
      const publicInputs = [];
      for (const [opId, entry] of this.#publicOps) {
        publicInputs.push({ opId: hexToBytes(opId), core: entry.core });
      }
      let controlKernel;
      let rewrapped = false;
      let allByOpId;
      if (this.#controlKernel !== null) {
        controlKernel = this.#controlKernel;
        await controlKernel.materialize(publicInputs);
        await this.#refreshPermissionsCache(controlKernel);
        await this.#unsealAvailableEpochKeys(controlKernel);
        await this.#decryptPendingEnvelopes();
        rewrapped = await this.#rewrapPendingLocalOps(controlKernel);
        allByOpId = this.#collectDecryptedKernelInputs();
      } else {
        allByOpId = this.#collectDecryptedKernelInputs();
        if (this.#checkpoints.size > 0) {
          await this.#ensureSqliteIfNeeded();
          controlKernel = new TopicKernel({
            genesis: this.genesisBytes,
            cas: this.cas,
            blindHostMode: this.#blindHostMode,
            ...this.#sandboxOptions,
            ...this.#sqliteDriver === void 0 ? {} : { sqliteDriver: this.#sqliteDriver }
          });
          await controlKernel.materialize(publicInputs);
        } else {
          controlKernel = this.#kernel;
        }
      }
      const schedule = parseFinalitySchedule(controlKernel.topic("$finality"));
      this.#verifiedFinality = await verifyFinalityV2({
        logId: this.logId,
        schedule,
        checkpoints: [...this.#checkpoints.values()],
        knownOps: [...allByOpId.entries()].map(([opId, input]) => ({
          opId,
          authorTimestampMs: input.core.authorTimestampMs
        })),
        ...this.#blockchainVerifier === void 0 ? {} : { blockchainVerifier: this.#blockchainVerifier }
      });
      const eligibleLocal = [];
      for (const [opId, input] of allByOpId) {
        if (this.#verifiedFinality.excludedOpIds.has(opId)) continue;
        eligibleLocal.push(input);
      }
      const needsKernelUpgrade = await this.#ensureSqliteIfNeeded(controlKernel.topic("$reducers"));
      let localResult;
      if (needsKernelUpgrade && this.#sqliteDriver !== void 0) {
        const nextKernel = new TopicKernel({
          genesis: this.genesisBytes,
          cas: this.cas,
          blindHostMode: this.#blindHostMode,
          ...this.#sandboxOptions,
          sqliteDriver: this.#sqliteDriver
        });
        localResult = await nextKernel.materialize(eligibleLocal);
        this.#kernel = nextKernel;
        this.#kernelHasSqlite = true;
        this.#finalKernel = null;
      } else {
        localResult = await this.#kernel.materialize(eligibleLocal);
      }
      if (!this.#kernelHasSqlite && await this.#ensureSqliteIfNeeded(this.#kernel.topic("$reducers")) && this.#sqliteDriver !== void 0) {
        const nextKernel = new TopicKernel({
          genesis: this.genesisBytes,
          cas: this.cas,
          blindHostMode: this.#blindHostMode,
          ...this.#sandboxOptions,
          sqliteDriver: this.#sqliteDriver
        });
        localResult = await nextKernel.materialize(eligibleLocal);
        this.#kernel = nextKernel;
        this.#kernelHasSqlite = true;
        this.#finalKernel = null;
      }
      await this.#refreshPermissionsCache(this.#kernel);
      this.#lastLocalRevision = toMaterializedRevision(localResult.revision);
      if (this.#verifiedFinality.closedThroughMs !== null) {
        this.#finalKernel ??= new TopicKernel({
          genesis: this.genesisBytes,
          cas: this.cas,
          blindHostMode: this.#blindHostMode,
          ...this.#sandboxOptions,
          ...this.#sqliteDriver === void 0 ? {} : { sqliteDriver: this.#sqliteDriver }
        });
        const finalInputs = [];
        for (const [opId, input] of allByOpId) {
          if (this.#verifiedFinality.includedOpIds.has(opId)) finalInputs.push(input);
        }
        await this.#finalKernel.materialize(finalInputs);
        this.#lastFinalRevision = toMaterializedRevision(this.#finalKernel.revision("final"));
      } else {
        this.#lastFinalRevision = null;
      }
      if (this.#cachedSignalPolicy !== null && this.#cachedSignalPolicy.stateRoot !== this.#lastLocalRevision.stateRoot) {
        this.#cachedSignalPolicy = null;
      }
      this.#materializationError = null;
      const revised = [];
      for (const o of localResult.outcomes) {
        const key = `${o.outcome}:${o.rejectionCode ?? ""}`;
        if (prevOutcomes.get(o.opId) !== key) revised.push(o.opId);
      }
      if (this.#lastLocalRevision.digest !== prevDigest) {
        this.#emitChange({
          kind: localResult.pendingDependencies.length > 0 ? "dependency" : "materialized",
          revision: this.#lastLocalRevision,
          revisedProposalIds: revised
        });
      }
      if (this.#lastFinalRevision !== null && this.#lastFinalRevision.digest !== prevFinalDigest) {
        this.#emitChange({
          kind: "finalized",
          revision: this.#lastFinalRevision,
          revisedProposalIds: []
        });
      }
      this.#emitStatus();
      if (rewrapped) this.#emitFacts();
    } catch (error) {
      this.#materializationError = error instanceof Error ? error.message : String(error);
      this.#emitStatus();
      throw error;
    }
  }
  async #resolveSignalPolicy() {
    const stateRoot = this.#lastLocalRevision.stateRoot;
    if (this.#cachedSignalPolicy !== null && this.#cachedSignalPolicy.stateRoot === stateRoot) {
      return this.#cachedSignalPolicy;
    }
    const policy = await this.#kernel.signalPolicy();
    this.#cachedSignalPolicy = { stateRoot, rules: policy.rules };
    return this.#cachedSignalPolicy;
  }
  /** Author locally and durably before network delivery. */
  submit(input) {
    return this.#serial(async () => {
      check(!this.#blindHostMode, "SESSION_BLIND_HOST_CANNOT_AUTHOR");
      check(Array.isArray(input.updates) && input.updates.length > 0, "OPERATION_UPDATES_REQUIRED");
      const updatesList = input.updates;
      const allControl = updatesList.every((u) => isControlTopic(u.topic));
      const anyControl = updatesList.some((u) => isControlTopic(u.topic));
      check(!anyControl || allControl, "OPERATION_CROSS_PARTITION_FORBIDDEN");
      const visibility = input.visibility ?? (this.genesis.privateLog ? allControl ? "public" : "encrypted" : "public");
      if (this.genesis.privateLog) {
        if (allControl) check(visibility === "public", "CONTROL_OP_MUST_BE_PUBLIC");
        else check(visibility === "encrypted", "PRIVATE_OP_MUST_BE_ENCRYPTED");
      }
      const operationId = input.operationId ?? crypto.randomUUID();
      for (const [opId, entry] of this.#publicOps) {
        if (entry.core.visibility === visibility && bytesToHex(entry.core.author) === this.identity.publicKey && entry.core.operationId === operationId) {
          return new ApplicationOperation(opId, operationId, this);
        }
      }
      for (const [opId, pending] of this.#localPending) {
        if (pending.core.visibility === visibility && pending.core.operationId === operationId) {
          return new ApplicationOperation(opId, operationId, this);
        }
      }
      const authorTimestampMs = input.authorTimestampMs ?? BigInt(Date.now());
      const logIdBytes = hexToBytes(this.logId);
      const authorBytes = hexToBytes(this.identity.publicKey);
      const core = {
        version: 1,
        logId: logIdBytes,
        author: authorBytes,
        operationId,
        authorTimestampMs,
        nonce: crypto.getRandomValues(new Uint8Array(16)),
        visibility,
        updates: updatesList.map((u) => ({ topic: u.topic, input: normalizeJsonValue(u.input) }))
      };
      const signed = await signOperationCore(core, this.device.identity.privateKey);
      const opBytes = encodeSignedOperation(signed);
      const opIdBytes = operationIdDigest(signed.coreBytes);
      const opIdHex = bytesToHex(opIdBytes);
      if (visibility === "public") {
        await this.#store.put(`${this.#prefix}/public-op/${opIdHex}`, opBytes);
        this.#publicOps.set(opIdHex, { raw: opBytes, signed, core });
      } else {
        const epoch = this.currentEpoch();
        check(epoch >= 0, "EPOCH_KEY_REQUIRED");
        const epochKey = this.#epochKeys.get(epoch);
        check(epochKey !== void 0, "EPOCH_KEY_MISSING");
        const aad = envelopeAad(logIdBytes, opIdBytes, authorBytes);
        const enc = await encryptEpochPayload(epochKey, BigInt(epoch), opBytes, aad);
        const env = {
          version: 1,
          logId: logIdBytes,
          opId: opIdBytes,
          author: authorBytes,
          epoch,
          nonce: enc.nonce,
          ciphertext: enc.ciphertext
        };
        const envBytes = encodeEncryptedEnvelope(env);
        const envDigest = bytesToHex(encryptedEnvelopeDigest(envBytes));
        await this.#store.put(`${this.#prefix}/enc-env/${envDigest}`, envBytes);
        await this.#store.put(`${this.#prefix}/local-pending/${opIdHex}`, encodeRecord({
          raw: opBytes,
          envelopeDigest: envDigest,
          epoch
        }));
        this.#encryptedEnvelopes.set(envDigest, {
          digest: envDigest,
          raw: envBytes,
          envelope: env,
          decrypted: { opId: opIdHex, signed, core }
        });
        this.#localPending.set(opIdHex, {
          raw: opBytes,
          signed,
          core,
          currentEnvelopeDigest: envDigest,
          currentEpoch: epoch
        });
      }
      await this.#rematerialize();
      this.#emitFacts();
      return new ApplicationOperation(opIdHex, operationId, this);
    });
  }
  /** Execute a named command (via local ApplicationDefinition if present, else direct topic dispatch). */
  async command(name, input = {}, options = {}) {
    if (this.definition !== void 0 && Object.hasOwn(this.definition.commands, name)) {
      const cmd = this.definition.commands[name];
      const updates = cmd.prepare(input);
      return this.submit({ ...options, updates });
    }
    const reducers = this.#kernel.topic("$reducers");
    const topics = reducers?.topics ?? {};
    if (Object.hasOwn(topics, name)) {
      return this.submit({ ...options, updates: [{ topic: name, input: normalizeJsonValue(input) }] });
    }
    const sep = name.includes(".") ? name.indexOf(".") : name.indexOf(":");
    if (sep > 0) {
      const topic = name.slice(0, sep);
      const action = name.slice(sep + 1);
      if (Object.hasOwn(topics, topic)) {
        const body2 = input !== null && typeof input === "object" && !Array.isArray(input) ? { action, ...input } : { action, input: normalizeJsonValue(input) };
        return this.submit({ ...options, updates: [{ topic, input: body2 }] });
      }
    }
    const appTopics = Object.keys(topics).filter((t) => !isControlTopic(t));
    if (appTopics.length === 1) {
      const topic = appTopics[0];
      const described = await this.describe().catch(() => null);
      const matchesDescribed = (cName) => cName === name || cName === `${topic}.${name}` || cName === `${topic}:${name}`;
      if (described && described.commands.length > 0 && !described.commands.some((c) => matchesDescribed(c.name))) {
        throw new Error(`APPLICATION_COMMAND_UNKNOWN:${name}`);
      }
      const body2 = input !== null && typeof input === "object" && !Array.isArray(input) ? { action: name, ...input } : { action: name, input: normalizeJsonValue(input) };
      return this.submit({ ...options, updates: [{ topic, input: body2 }] });
    }
    throw new Error(`APPLICATION_COMMAND_UNKNOWN:${name}`);
  }
  /** Execute a named query (via local ApplicationDefinition if present, else reducer query()). */
  async query(name, input = null, _options) {
    if (this.definition !== void 0 && Object.hasOwn(this.definition.queries, name)) {
      const view = await this.readView();
      try {
        const value = await this.definition.queries[name].read(view, input);
        return { applicationId: this.applicationId, revision: view.revision, value };
      } finally {
        view.release();
      }
    }
    const reducers = this.#kernel.topic("$reducers");
    const topics = reducers?.topics ?? {};
    if (Object.hasOwn(topics, name)) {
      const value = await this.#kernel.query(name, normalizeJsonValue(input));
      return { applicationId: this.applicationId, revision: this.#lastLocalRevision, value };
    }
    const sep = name.includes(".") ? name.indexOf(".") : name.indexOf(":");
    if (sep > 0) {
      const topic = name.slice(0, sep);
      const queryName = name.slice(sep + 1);
      if (Object.hasOwn(topics, topic)) {
        const body2 = input !== null && typeof input === "object" && !Array.isArray(input) ? { query: queryName, ...input } : { query: queryName, input: normalizeJsonValue(input) };
        const value = await this.#kernel.query(topic, body2);
        return { applicationId: this.applicationId, revision: this.#lastLocalRevision, value };
      }
    }
    const appTopics = Object.keys(topics).filter((t) => !isControlTopic(t));
    if (appTopics.length === 1) {
      const topic = appTopics[0];
      const described = await this.describe().catch(() => null);
      const matchesDescribed = (qName) => qName === name || qName === `${topic}.${name}` || qName === `${topic}:${name}`;
      if (described && described.queries.length > 0 && !described.queries.some((q) => matchesDescribed(q.name))) {
        throw new Error(`APPLICATION_QUERY_UNKNOWN:${name}`);
      }
      const body2 = input !== null && typeof input === "object" && !Array.isArray(input) ? { query: name, ...input } : { query: name, input: normalizeJsonValue(input) };
      const value = await this.#kernel.query(topic, body2);
      return { applicationId: this.applicationId, revision: this.#lastLocalRevision, value };
    }
    throw new Error(`APPLICATION_QUERY_UNKNOWN:${name}`);
  }
  /** Describe available commands and queries (from local definition or in-chain reducer describe() exports). */
  async describe() {
    if (this.definition !== void 0) return describeApplication(this.definition);
    const stateRoot = this.#lastLocalRevision.stateRoot;
    if (this.#cachedDescription !== null && this.#cachedDescription.stateRoot === stateRoot) {
      return structuredClone(this.#cachedDescription.value);
    }
    const raw = await this.#kernel.describe();
    const commands = [];
    const queries = [];
    const multiTopic = Object.keys(raw).filter((t) => !isControlTopic(t)).length > 1;
    for (const [topic, entry] of Object.entries(raw)) {
      if (entry === null || typeof entry !== "object" || Array.isArray(entry)) continue;
      const obj = entry;
      const prefix = multiTopic ? `${topic}.` : "";
      if (Array.isArray(obj.commands)) {
        for (const c of obj.commands) {
          if (c && typeof c === "object" && typeof c.name === "string") {
            const cmd = c;
            commands.push({
              name: `${prefix}${cmd.name}`,
              description: cmd.description ?? "",
              input: checkedApplicationInputSchema(cmd.input ?? { type: "object", properties: {} })
            });
          }
        }
      }
      if (Array.isArray(obj.queries)) {
        for (const q of obj.queries) {
          if (q && typeof q === "object" && typeof q.name === "string") {
            const qry = q;
            queries.push({
              name: `${prefix}${qry.name}`,
              description: qry.description ?? "",
              input: checkedApplicationInputSchema(qry.input ?? { type: "object", properties: {} })
            });
          }
        }
      }
    }
    commands.sort((a, b) => a.name.localeCompare(b.name));
    queries.sort((a, b) => a.name.localeCompare(b.name));
    const description = validateApplicationDescription({
      id: `chain-${this.logId.slice(0, 16)}`,
      version: "2.0.0",
      commands,
      queries
    });
    this.#cachedDescription = { stateRoot, value: structuredClone(description) };
    return description;
  }
  #hasActiveFinalityPolicy() {
    const schedule = parseFinalitySchedule(this.#kernel.topic("$finality"));
    return schedule.some((entry) => entry.policy.kind !== "none");
  }
  /** Capture a coherent read snapshot for reactive views, queries, and event pagination. */
  async readView(options = {}) {
    const viewKind = options.view ?? "local";
    if (viewKind === "final" && !this.#hasActiveFinalityPolicy()) {
      throw Object.assign(new Error("FINALITY_UNSUPPORTED"), { code: "FINALITY_UNSUPPORTED" });
    }
    const kernel = viewKind === "final" ? this.#finalKernel : this.#kernel;
    const revision = kernel === null ? this.revision(viewKind) : toMaterializedRevision(kernel.revision(viewKind));
    const topicsSnap = kernel === null ? {} : kernel.topics;
    const outcomesSnap = kernel === null ? [] : kernel.outcomes;
    const events = [];
    for (const outcome of outcomesSnap) {
      if (outcome.outcome !== "accepted") continue;
      for (const ev of outcome.events) events.push(toApplicationEvent(ev));
    }
    let released = false;
    const checkLive = () => {
      if (released) throw new Error("READ_VIEW_RELEASED");
    };
    return {
      applicationId: this.applicationId,
      revision,
      topic(name) {
        checkLive();
        return Object.hasOwn(topicsSnap, name) ? structuredClone(topicsSnap[name]) : null;
      },
      async query(topic, input) {
        checkLive();
        if (kernel === null) return Object.hasOwn(topicsSnap, topic) ? structuredClone(topicsSnap[topic]) : null;
        return kernel.query(topic, input ?? null, topicsSnap);
      },
      readEvents(eventOptions = {}) {
        checkLive();
        return sliceEvents(events, revision, eventOptions);
      },
      release() {
        released = true;
      }
    };
  }
  readEvents(options = {}) {
    const viewKind = options.view ?? "local";
    if (viewKind === "final" && !this.#hasActiveFinalityPolicy()) {
      throw Object.assign(new Error("FINALITY_UNSUPPORTED"), { code: "FINALITY_UNSUPPORTED" });
    }
    const kernel = viewKind === "final" ? this.#finalKernel : this.#kernel;
    const revision = kernel === null ? this.revision(viewKind) : toMaterializedRevision(kernel.revision(viewKind));
    const events = [];
    if (kernel !== null) {
      for (const outcome of kernel.outcomes) {
        if (outcome.outcome !== "accepted") continue;
        for (const ev of outcome.events) events.push(toApplicationEvent(ev));
      }
    }
    return sliceEvents(events, revision, options);
  }
  // ---- High-level v2 control helpers ----
  async admitMember(options) {
    const memberPayload = {
      publicKey: options.publicKey,
      ...options.wrapKey ? { wrapKey: options.wrapKey } : {},
      ...options.label ? { label: options.label } : {},
      ...options.subject ? { subject: options.subject } : {},
      reader: options.reader ?? true,
      writer: options.writer ?? true,
      administrator: options.administrator ?? false,
      publisher: options.publisher ?? false,
      finalizer: options.finalizer ?? false
    };
    const updates = [
      {
        topic: "$permissions",
        input: {
          action: "setMember",
          member: memberPayload,
          ...options.attestation ? { attestation: options.attestation } : {}
        }
      }
    ];
    if (this.genesis.privateLog && (options.reader ?? true) && options.wrapKey) {
      const keysState = this.keysState();
      if (keysState.currentEpoch < 0) {
        const epoch0 = this.#epochKeys.get(0) ?? crypto.getRandomValues(new Uint8Array(32));
        await this.installEpochKey(0, epoch0);
        const boxes = {};
        const allReaders = /* @__PURE__ */ new Map();
        for (const m of this.permissions().members) {
          if (m.reader && m.wrapKey) allReaders.set(m.publicKey, m.wrapKey);
        }
        allReaders.set(options.publicKey, options.wrapKey);
        for (const [pk, wk] of allReaders) {
          boxes[pk] = await hpkeSealEpochKey(wk, epoch0, this.logId, 0);
        }
        updates.push({
          topic: "$keys",
          input: {
            action: "rotateEpoch",
            epoch: 0,
            keyCommitment: epochKeyCommitmentV2(epoch0),
            boxes
          }
        });
      } else {
        const minEp = options.minEpoch ?? 0;
        const epochBoxes = {};
        for (let ep = minEp; ep <= keysState.currentEpoch; ep++) {
          const epKey = this.#epochKeys.get(ep);
          if (epKey === void 0) continue;
          epochBoxes[String(ep)] = await hpkeSealEpochKey(options.wrapKey, epKey, this.logId, ep);
        }
        if (Object.keys(epochBoxes).length > 0) {
          updates.push({
            topic: "$keys",
            input: {
              action: "grantBoxes",
              member: options.publicKey,
              epochBoxes
            }
          });
        }
      }
    }
    return this.submit({
      visibility: "public",
      updates,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs }
    });
  }
  async rotateEpoch(options = {}) {
    check(this.genesis.privateLog, "EPOCH_ROTATION_PRIVATE_LOG_ONLY");
    const keysState = this.keysState();
    const nextEpoch = keysState.currentEpoch + 1;
    const key = options.newEpochKey ?? crypto.getRandomValues(new Uint8Array(32));
    await this.installEpochKey(nextEpoch, key);
    const exclude = new Set(options.excludeMembers ?? []);
    const boxes = {};
    for (const m of this.permissions().members) {
      if (!m.reader || !m.wrapKey || exclude.has(m.publicKey)) continue;
      boxes[m.publicKey] = await hpkeSealEpochKey(m.wrapKey, key, this.logId, nextEpoch);
    }
    const operation = await this.submit({
      visibility: "public",
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$keys",
        input: {
          action: "rotateEpoch",
          epoch: nextEpoch,
          keyCommitment: epochKeyCommitmentV2(key),
          boxes
        }
      }]
    });
    return { epoch: nextEpoch, operation };
  }
  async removeMember(publicKey, options = {}) {
    const updates = [
      { topic: "$permissions", input: { action: "removeMember", publicKey } }
    ];
    if (this.genesis.privateLog && options.rotateEpoch !== false) {
      const nextEpoch = this.keysState().currentEpoch + 1;
      const key = crypto.getRandomValues(new Uint8Array(32));
      await this.installEpochKey(nextEpoch, key);
      const boxes = {};
      for (const m of this.permissions().members) {
        if (!m.reader || !m.wrapKey || m.publicKey === publicKey) continue;
        boxes[m.publicKey] = await hpkeSealEpochKey(m.wrapKey, key, this.logId, nextEpoch);
      }
      updates.push({
        topic: "$keys",
        input: {
          action: "rotateEpoch",
          epoch: nextEpoch,
          keyCommitment: epochKeyCommitmentV2(key),
          boxes
        }
      });
    }
    return this.submit({
      visibility: "public",
      updates,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs }
    });
  }
  async publishRelease(options) {
    const descriptors = [];
    for (const f of options.files) {
      let hash = f.hash;
      let size = f.size;
      if (f.bytes !== void 0) {
        const computedHash = bytesToHex(sha256Sync(f.bytes));
        if (hash !== void 0) check(hash === computedHash, "PUBLICATION_FILE_HASH_MISMATCH");
        hash = computedHash;
        size = f.bytes.length;
        if (this.isReader(this.identity.publicKey)) {
          await this.content.putBlob(f.bytes);
        }
      }
      check(hash !== void 0 && size !== void 0, "PUBLICATION_FILE_INVALID");
      descriptors.push({ path: f.path, hash, size, type: f.type });
    }
    return this.submit({
      visibility: "public",
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$publications",
        input: {
          action: "publish",
          entry: options.entry,
          files: descriptors,
          ...options.expectedRevision === void 0 ? {} : { expectedRevision: options.expectedRevision }
        }
      }]
    });
  }
  async rollbackRelease(options) {
    check(options.revision !== void 0 || options.opId !== void 0, "PUBLICATION_ROLLBACK_TARGET_REQUIRED");
    return this.submit({
      visibility: "public",
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$publications",
        input: {
          action: "rollback",
          ...options.revision === void 0 ? {} : { revision: options.revision },
          ...options.opId === void 0 ? {} : { opId: options.opId }
        }
      }]
    });
  }
  async scheduleFinality(options) {
    return this.submit({
      visibility: "public",
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$finality",
        input: {
          action: "schedulePolicy",
          effectiveAfterMs: Number(options.effectiveAfterMs),
          policy: options.policy
        }
      }]
    });
  }
  async updateReducers(options) {
    const pinnedImports = {};
    if (options.imports !== void 0) {
      for (const [spec, val] of Object.entries(options.imports)) {
        if (val === null || val.startsWith("cas:sha256-")) {
          pinnedImports[spec] = val;
        } else {
          const hash = await this.cas.put(utf8(val), [], "public");
          pinnedImports[spec] = `cas:sha256-${hash}`;
        }
      }
    }
    return this.submit({
      visibility: "public",
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$reducers",
        input: {
          ...Object.keys(pinnedImports).length > 0 ? { imports: pinnedImports } : {},
          ...options.topics !== void 0 ? { topics: options.topics } : {}
        }
      }]
    });
  }
  // ---- Finality operations ----
  finality = {
    status: () => ({
      ...this.#verifiedFinality,
      schedule: parseFinalitySchedule(this.#kernel.topic("$finality"))
    }),
    createCheckpoint: async (options) => {
      return this.#serial(async () => {
        const schedule = parseFinalitySchedule(this.#kernel.topic("$finality"));
        let active = schedule[0];
        for (const entry of schedule) {
          if (entry.effectiveAfterMs <= options.throughMs) active = entry;
        }
        check(active.policy.kind !== "none", "FINALITY_NOT_ACTIVE");
        const scopeId = await policyScopeId(this.logId, active);
        const all = this.#collectDecryptedKernelInputs();
        const included = [];
        for (const [opId, input] of all) {
          if (this.#verifiedFinality.excludedOpIds.has(opId)) continue;
          if (input.core.authorTimestampMs <= options.throughMs) included.push(input);
        }
        included.sort((a, b) => compareOperationOrder(
          { authorTimestampMs: a.core.authorTimestampMs, author: a.core.author, opId: a.opId },
          { authorTimestampMs: b.core.authorTimestampMs, author: b.core.author, opId: b.opId }
        ));
        const tempKernel = new TopicKernel({
          genesis: this.genesisBytes,
          cas: this.cas,
          blindHostMode: this.#blindHostMode,
          ...this.#sandboxOptions,
          ...this.#sqliteDriver === void 0 ? {} : { sqliteDriver: this.#sqliteDriver }
        });
        await tempKernel.materialize(included);
        const snap = tempKernel.snapshot();
        const inclusions = included.map((i) => ({
          opId: bytesToHex(i.opId),
          authorTimestampMs: i.core.authorTimestampMs,
          author: bytesToHex(i.core.author)
        }));
        const payload = {
          logId: this.logId,
          policyScopeId: scopeId,
          closedThroughMs: options.throughMs,
          includedSetDigest: computeIncludedSetDigest(inclusions.map((i) => i.opId)),
          historyDigest: snap.historyDigest,
          stateRoot: snap.stateRoot,
          inclusions
        };
        const sig = await signFinalityCheckpoint(payload, this.device.identity);
        const checkpoint = {
          payload,
          attestation: { kind: "signatures", signatures: [sig] }
        };
        const key = await recordDigest(payload);
        this.#checkpoints.set(key, checkpoint);
        await this.#store.put(`${this.#prefix}/checkpoint/${key}`, encodeRecord(checkpoint));
        await this.#rematerialize();
        this.#emitFacts();
        return { checkpoint, snapshot: snap };
      });
    },
    submitCheckpoints: async (checkpoints) => {
      await this.mergeFacts({
        publicOps: [],
        encryptedEnvelopes: [],
        casNodes: [],
        retentions: [],
        checkpoints
      });
    },
    bootstrapFromCheckpoint: async (checkpoint, snapshot) => {
      await this.#serial(async () => {
        check(checkpoint.payload.logId === this.logId, "CHECKPOINT_CHAIN_MISMATCH");
        check(checkpoint.payload.stateRoot === snapshot.stateRoot && checkpoint.payload.historyDigest === snapshot.historyDigest, "CHECKPOINT_SNAPSHOT_MISMATCH");
        const key = await recordDigest(checkpoint.payload);
        this.#checkpoints.set(key, checkpoint);
        await this.#store.put(`${this.#prefix}/checkpoint/${key}`, encodeRecord(checkpoint));
        await this.#kernel.bootstrapFromCheckpoint(snapshot);
        if (this.#controlKernel !== null) {
          await this.#controlKernel.bootstrapFromCheckpoint(snapshot);
        }
        this.#lastLocalRevision = toMaterializedRevision(this.#kernel.revision("local"));
        this.#emitChange({ kind: "finalized", revision: this.#lastLocalRevision, revisedProposalIds: [] });
        this.#emitStatus();
      });
    }
  };
  // ---- Operation inspection & waiting ----
  inspectOperation(idOrOperationId) {
    let opIdHex = idOrOperationId;
    let core = null;
    let pending = null;
    const pub = this.#publicOps.get(idOrOperationId);
    if (pub !== void 0) {
      core = pub.core;
    } else {
      for (const [k, v] of this.#publicOps) {
        if (v.core.operationId === idOrOperationId && bytesToHex(v.core.author) === this.identity.publicKey) {
          opIdHex = k;
          core = v.core;
          break;
        }
      }
    }
    if (core === null) {
      const byDigest = this.#encryptedEnvelopes.get(idOrOperationId);
      if (byDigest?.decrypted !== void 0) {
        opIdHex = byDigest.decrypted.opId;
        core = byDigest.decrypted.core;
      }
    }
    if (core === null) {
      for (const entry of this.#encryptedEnvelopes.values()) {
        if (entry.decrypted?.opId === idOrOperationId) {
          opIdHex = entry.decrypted.opId;
          core = entry.decrypted.core;
          break;
        }
        if (entry.decrypted?.core.operationId === idOrOperationId && bytesToHex(entry.decrypted.core.author) === this.identity.publicKey) {
          opIdHex = entry.decrypted.opId;
          core = entry.decrypted.core;
          break;
        }
      }
    }
    if (core === null) {
      const pend = this.#localPending.get(idOrOperationId);
      if (pend !== void 0) core = pend.core;
      else {
        for (const [k, v] of this.#localPending) {
          if (v.core.operationId === idOrOperationId) {
            opIdHex = k;
            core = v.core;
            break;
          }
        }
      }
    }
    const outcome = this.#kernel.outcomes.find((o) => o.opId === opIdHex);
    const materialized = outcome === void 0 ? null : {
      proposalId: opIdHex,
      revision: this.#lastLocalRevision,
      outcome: outcome.outcome,
      rejectionCode: outcome.rejectionCode,
      ...outcome.rejectionDetail === void 0 ? {} : { rejectionDetail: outcome.rejectionDetail }
    };
    if (materialized === null) {
      if (this.#kernel.pendingDependencies.length > 0) pending = "dependency";
      else if (core === null) pending = "key";
    }
    const retained = [...this.#retentions.get(opIdHex)?.values() ?? []].filter((r) => r.signer !== this.identity.publicKey && r.payload.storageId !== this.device.storageId);
    return {
      applicationId: this.applicationId,
      author: core === null ? "" : bytesToHex(core.author),
      authorTimestampMs: core === null ? null : core.authorTimestampMs.toString(),
      proposalId: opIdHex,
      operationId: core === null ? idOrOperationId : core.operationId,
      visibility: core === null ? "encrypted" : core.visibility,
      stored: core !== null,
      pending,
      materialized,
      retained,
      finalized: this.#verifiedFinality.includedOpIds.has(opIdHex),
      excluded: this.#verifiedFinality.excludedOpIds.has(opIdHex)
    };
  }
  async waitOperation(id, fact, options = {}) {
    if (fact === "finalized" && !this.#hasActiveFinalityPolicy()) {
      throw Object.assign(new Error("FINALITY_UNSUPPORTED"), { code: "FINALITY_UNSUPPORTED" });
    }
    const checkDone = () => {
      const info = this.inspectOperation(id);
      if (fact === "materialized" && info.materialized !== null) return info;
      if (fact === "retained" && info.retained.length > 0) return info;
      if (fact === "finalized" && info.finalized && info.materialized !== null) return info;
      return null;
    };
    const immediate = checkDone();
    if (immediate !== null) return immediate;
    const timeoutMs = options.timeoutMs ?? 3e4;
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    signal.throwIfAborted();
    return new Promise((resolve, reject) => {
      let settled = false;
      const done = (fn) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        stopChange();
        stopStatus();
        stopFacts();
        signal.removeEventListener("abort", onAbort);
        fn();
      };
      const evaluate = () => {
        const ready = checkDone();
        if (ready !== null) done(() => resolve(ready));
      };
      const onAbort = () => done(() => reject(signal.reason));
      const timer = setTimeout(() => done(() => reject(new Error(`OPERATION_WAIT_TIMEOUT:${fact}`))), timeoutMs);
      const stopChange = this.onChange(evaluate);
      const stopStatus = this.onStatus(evaluate);
      const stopFacts = this.onFacts(evaluate);
      signal.addEventListener("abort", onAbort, { once: true });
      evaluate();
    });
  }
  operations = {
    get: (idOrOperationId) => {
      const info = this.inspectOperation(idOrOperationId);
      return info.stored ? new ApplicationOperation(info.proposalId, info.operationId, this) : null;
    },
    retry: async (idOrOperationId) => {
      const existing = this.operations.get(idOrOperationId);
      check(existing !== null, "OPERATION_UNKNOWN");
      this.#emitFacts();
      return existing;
    }
  };
  // ---- Retention ----
  async retain(proposalId, subject) {
    const evidence = await signRecord("operation-retention", {
      applicationId: this.applicationId,
      proposalId,
      author: subject.author,
      envelopeDigest: subject.envelopeDigest,
      peer: this.identity.publicKey,
      storageId: this.device.storageId
    }, this.device.identity);
    let byPeer = this.#retentions.get(proposalId);
    if (byPeer === void 0) {
      byPeer = /* @__PURE__ */ new Map();
      this.#retentions.set(proposalId, byPeer);
    }
    byPeer.set(this.identity.publicKey, evidence);
    await this.#store.put(`${this.#prefix}/retention/${proposalId}/${this.identity.publicKey}`, encodeRecord(evidence));
    this.#emitFacts();
    return evidence;
  }
  // ---- Facts export & merge (P2P + blind host sync) ----
  /** Read a decoded CAS node payload & links cleanly without touching internal wire envelopes. */
  async readCasPayload(hash, partition = "any") {
    const node = await this.cas.get(hash, partition);
    if (node === null) return null;
    return { hash, payload: node.bytes.slice(), links: [...node.links] };
  }
  async exportFacts(options = {}) {
    const includePrivate = options.includePrivateCas ?? (!this.#blindHostMode && this.isReader(this.identity.publicKey));
    const casNodes = [];
    const partitions = includePrivate ? ["public", "private"] : ["public"];
    for (const partition of partitions) {
      for (const hash of this.cas.listKnownHashes(partition)) {
        const raw = await this.cas.getRaw(hash, partition);
        if (raw !== null) casNodes.push({ hash, bytes: raw, partition });
      }
    }
    const retentions = [];
    for (const byPeer of this.#retentions.values()) {
      for (const ev of byPeer.values()) retentions.push(ev);
    }
    return {
      ...options.includeGenesis ? { genesisBytes: this.genesisBytes.slice() } : {},
      publicOps: [...this.#publicOps.values()].map((v) => v.raw.slice()),
      encryptedEnvelopes: [...this.#encryptedEnvelopes.values()].map((v) => v.raw.slice()),
      casNodes,
      retentions,
      checkpoints: [...this.#checkpoints.values()]
    };
  }
  async exportPublicControlFacts() {
    const casNodes = [];
    for (const hash of this.cas.listKnownHashes("public")) {
      const raw = await this.cas.getRaw(hash, "public");
      if (raw !== null) casNodes.push({ hash, bytes: raw, partition: "public" });
    }
    return {
      publicOps: [...this.#publicOps.values()].map((v) => v.raw.slice()),
      casNodes,
      checkpoints: [...this.#checkpoints.values()]
    };
  }
  mergeFacts(facts) {
    return this.#serial(async () => {
      if (facts.genesisBytes !== void 0) {
        check(sameBytes(facts.genesisBytes, this.genesisBytes), "FACTS_GENESIS_MISMATCH");
      }
      let materializedChanged = false;
      let factsChanged = false;
      for (const node of facts.casNodes ?? []) {
        if (this.cas.hasSync(node.hash, node.partition)) continue;
        if (hashCasNode(node.bytes) === node.hash) {
          decodeCasNode(node.bytes);
          await this.cas.putRaw(node.hash, node.bytes, node.partition);
          materializedChanged = true;
          factsChanged = true;
        } else if (computeCasHash(node.bytes, []) === node.hash) {
          await this.cas.put(node.bytes, [], node.partition);
          materializedChanged = true;
          factsChanged = true;
        } else {
          throw new Error(`CAS_NODE_HASH_MISMATCH:${node.hash}`);
        }
      }
      for (const raw of facts.publicOps ?? []) {
        const signed = decodeSignedOperation(raw);
        const verified = await verifySignedOperation(signed);
        if (bytesToHex(verified.core.logId) !== this.logId) continue;
        if (verified.core.visibility !== "public") continue;
        const opId = bytesToHex(verified.opId);
        if (this.#publicOps.has(opId)) continue;
        check(this.#publicOps.size + this.#encryptedEnvelopes.size < this.#maxOperations, "SESSION_OPERATION_LIMIT");
        await this.#store.put(`${this.#prefix}/public-op/${opId}`, raw.slice());
        this.#publicOps.set(opId, { raw: raw.slice(), signed, core: verified.core });
        materializedChanged = true;
        factsChanged = true;
      }
      for (const raw of facts.encryptedEnvelopes ?? []) {
        const envelope2 = decodeEncryptedEnvelope(raw);
        if (bytesToHex(envelope2.logId) !== this.logId) continue;
        const digest3 = bytesToHex(encryptedEnvelopeDigest(raw));
        if (this.#encryptedEnvelopes.has(digest3)) continue;
        check(this.#publicOps.size + this.#encryptedEnvelopes.size < this.#maxOperations, "SESSION_OPERATION_LIMIT");
        await this.#store.put(`${this.#prefix}/enc-env/${digest3}`, raw.slice());
        this.#encryptedEnvelopes.set(digest3, { digest: digest3, raw: raw.slice(), envelope: envelope2 });
        materializedChanged = true;
        factsChanged = true;
      }
      for (const ev of facts.retentions ?? []) {
        if (ev.payload.applicationId !== this.applicationId) continue;
        await verifyRecord("operation-retention", ev, ev.signer);
        let byPeer = this.#retentions.get(ev.payload.proposalId);
        if (byPeer === void 0) {
          byPeer = /* @__PURE__ */ new Map();
          this.#retentions.set(ev.payload.proposalId, byPeer);
        }
        if (!byPeer.has(ev.signer)) {
          byPeer.set(ev.signer, ev);
          await this.#store.put(`${this.#prefix}/retention/${ev.payload.proposalId}/${ev.signer}`, encodeRecord(ev));
          factsChanged = true;
        }
      }
      for (const cp of facts.checkpoints ?? []) {
        if (cp.payload.logId !== this.logId) continue;
        const key = await recordDigest(cp.payload);
        if (!this.#checkpoints.has(key)) {
          this.#checkpoints.set(key, cp);
          await this.#store.put(`${this.#prefix}/checkpoint/${key}`, encodeRecord(cp));
          materializedChanged = true;
          factsChanged = true;
        }
      }
      if (materializedChanged) {
        await this.#rematerialize();
      } else if (factsChanged) {
        this.#emitStatus();
      }
      if (factsChanged) {
        this.#emitFacts();
      }
    });
  }
  async collectGarbage() {
    return this.#serial(async () => {
      const roots = this.#kernel.gcRoots();
      if (this.#controlKernel !== null) {
        for (const r of this.#controlKernel.gcRoots()) roots.add(r);
      }
      if (this.#finalKernel !== null) {
        for (const r of this.#finalKernel.gcRoots()) roots.add(r);
      }
      for (const src of Object.values(STANDARD_MODULE_SOURCES)) {
        roots.add(computeCasHash(utf8(src), []));
      }
      return this.cas.collectGarbage(roots);
    });
  }
  connectPeer(options) {
    return connectApplicationPeer(this, options);
  }
  diagnostics() {
    return applicationPeerDiagnostics(this);
  }
  peerLinks() {
    return applicationPeerLinks(this);
  }
  onPeerLink(listener) {
    return onApplicationPeerLink(this, listener);
  }
  close() {
    return this.#closing ??= (async () => {
      this.#closed = true;
      this.#lifetime.abort(new Error("SESSION_CLOSED"));
      this.#emitStatus();
      await this.content.close();
      await this.#release();
    })();
  }
};
async function readAllStoreEntries(store) {
  if (store.iterateEntries !== void 0) {
    const entries = [];
    for await (const entry of store.iterateEntries()) entries.push(entry);
    return entries;
  }
  if (store.entries !== void 0) {
    return store.entries();
  }
  return [];
}
function sliceEvents(events, revision, options) {
  const limit2 = options.limit ?? 64;
  check(Number.isSafeInteger(limit2) && limit2 >= 1 && limit2 <= 512, "EVENT_LIMIT_INVALID");
  const normalizedTopics = options.topics === void 0 ? null : [...new Set(options.topics)].sort();
  const topicFilter = normalizedTopics === null ? null : new Set(normalizedTopics);
  const filtered = topicFilter === null ? events : events.filter((ev) => topicFilter.has(ev.topic));
  let start = 0;
  if (options.cursor !== void 0 && options.cursor !== "") {
    check(options.cursor.length <= APPLICATION_EVENT_CURSOR_LIMIT, "EVENT_CURSOR_INVALID");
    let parsed;
    try {
      parsed = JSON.parse(options.cursor);
    } catch {
      throw Object.assign(new Error("EVENT_CURSOR_INVALID"), { code: "EVENT_CURSOR_INVALID" });
    }
    if (parsed === null || typeof parsed !== "object" || typeof parsed.after !== "number" || !Number.isSafeInteger(parsed.after) || parsed.after < 0) {
      throw Object.assign(new Error("EVENT_CURSOR_INVALID"), { code: "EVENT_CURSOR_INVALID" });
    }
    if (parsed.revision !== revision.digest || parsed.view !== revision.view || JSON.stringify(parsed.topics ?? null) !== JSON.stringify(normalizedTopics)) {
      throw Object.assign(new Error("EVENT_CURSOR_STALE"), { code: "EVENT_CURSOR_STALE" });
    }
    start = parsed.after;
  }
  const page = filtered.slice(start, start + limit2);
  const nextAfter = start + page.length;
  const hasMore = nextAfter < filtered.length;
  const cursor = JSON.stringify({
    revision: revision.digest,
    view: revision.view,
    topics: normalizedTopics,
    after: nextAfter
  });
  return { revision, events: page, cursor, hasMore };
}

// packages/peer-session/src/runtime.ts
async function createApplicationSession(options) {
  const release = claimApplicationDevice(options.device);
  try {
    const storage = await options.device.openStorage();
    return await ApplicationSession.open({
      ...options,
      store: storage.store,
      async release() {
        release();
        await options.device.close();
      }
    });
  } catch (error) {
    release();
    await options.device.close();
    throw error;
  }
}
export {
  createApplicationSession
};
