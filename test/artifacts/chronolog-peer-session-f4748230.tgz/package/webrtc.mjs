import {
  connectApplicationWebRtc
} from "./chunks/chunk-P7AXB6ZP.mjs";
import {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
} from "./chunks/chunk-UXJAGBJW.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-CTIAFLQ6.mjs";
import "./chunks/chunk-ICYUPG2X.mjs";
export {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
