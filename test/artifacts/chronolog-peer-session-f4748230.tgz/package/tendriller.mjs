import {
  createApplicationBackend
} from "./chunks/chunk-KRDAJCBF.mjs";
import "./chunks/chunk-37AJJO3T.mjs";
import "./chunks/chunk-ICYUPG2X.mjs";
export {
  createApplicationBackend
};
