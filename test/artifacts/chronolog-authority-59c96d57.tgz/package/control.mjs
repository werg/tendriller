// packages/canonical/src/errors.ts
var CanonicalError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.details = details;
    this.name = "CanonicalError";
  }
  code;
  details;
};
function canonicalInvariant(condition, code, message, details) {
  if (!condition) throw new CanonicalError(code, message, details);
}

// packages/canonical/src/bytes.ts
var textEncoder = new TextEncoder();
var fatalTextDecoder = new TextDecoder("utf-8", { fatal: true });
function utf8(value) {
  const encoded = textEncoder.encode(value);
  try {
    if (fatalTextDecoder.decode(encoded) !== value) throw new CanonicalError("INVALID_UTF8", "Text contains an unpaired UTF-16 surrogate");
  } catch (error) {
    if (error instanceof CanonicalError) throw error;
    throw new CanonicalError("INVALID_UTF8", "Text cannot be represented as canonical UTF-8");
  }
  return encoded;
}
function decodeUtf8(value) {
  try {
    return fatalTextDecoder.decode(value);
  } catch {
    throw new CanonicalError("INVALID_UTF8", "Bytes are not valid UTF-8");
  }
}
function concatBytes(...parts) {
  const size = parts.reduce((sum, part) => sum + part.length, 0);
  const result = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}
function compareBytes(left, right) {
  const size = Math.min(left.length, right.length);
  for (let index = 0; index < size; index += 1) {
    const difference = left[index] - right[index];
    if (difference !== 0) return difference < 0 ? -1 : 1;
  }
  return left.length === right.length ? 0 : left.length < right.length ? -1 : 1;
}
function equalBytes(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}
var hexPairs = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, "0"));
function bytesToHex(value) {
  let result = "";
  for (const byte of value) result += hexPairs[byte];
  return result;
}
function hexToBytes(value) {
  if (!/^(?:[0-9a-fA-F]{2})*$/u.test(value)) throw new CanonicalError("SCHEMA_INVALID", "Hex text is malformed");
  return Uint8Array.from({ length: value.length / 2 }, (_unused, index) => Number.parseInt(value.slice(index * 2, index * 2 + 2), 16));
}

// packages/canonical/src/cbor.ts
var DEFAULT_DECODE_LIMITS = Object.freeze({
  maxBytes: 16 * 1024 * 1024,
  maxDepth: 64,
  maxArrayItems: 1e6,
  maxMapItems: 1e5,
  maxTextBytes: 4 * 1024 * 1024,
  maxBlobBytes: 16 * 1024 * 1024
});
var MAX_UINT64 = (1n << 64n) - 1n;
var POSITIVE_BIGNUM_TAG = 2n;
var NEGATIVE_BIGNUM_TAG = 3n;
function encodeHead(major, value) {
  canonicalInvariant(value >= 0n && value <= MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR integer is outside uint64 range");
  if (value < 24n) return Uint8Array.of(major << 5 | Number(value));
  if (value <= 0xffn) return Uint8Array.of(major << 5 | 24, Number(value));
  if (value <= 0xffffn) return Uint8Array.of(major << 5 | 25, Number(value >> 8n), Number(value & 0xffn));
  if (value <= 0xffffffffn) {
    const bytes3 = new Uint8Array(5);
    bytes3[0] = major << 5 | 26;
    new DataView(bytes3.buffer).setUint32(1, Number(value), false);
    return bytes3;
  }
  const bytes2 = new Uint8Array(9);
  bytes2[0] = major << 5 | 27;
  new DataView(bytes2.buffer).setBigUint64(1, value, false);
  return bytes2;
}
function magnitudeBytes(value) {
  canonicalInvariant(value > MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR bignum must exceed uint64 range");
  const octets = [];
  for (let remaining = value; remaining > 0n; remaining >>= 8n) octets.push(Number(remaining & 0xffn));
  octets.reverse();
  return Uint8Array.from(octets);
}
function encodeBigint(value) {
  const negative = value < 0n;
  const magnitude = negative ? -1n - value : value;
  if (magnitude <= MAX_UINT64) return encodeHead(negative ? 1 : 0, magnitude);
  const bytes2 = magnitudeBytes(magnitude);
  return concatBytes(
    encodeHead(6, negative ? NEGATIVE_BIGNUM_TAG : POSITIVE_BIGNUM_TAG),
    encodeHead(2, BigInt(bytes2.length)),
    bytes2
  );
}
function isMap(value) {
  return value instanceof Map;
}
function encodeCanonicalCbor(value) {
  if (value === null) return Uint8Array.of(246);
  if (value === false) return Uint8Array.of(244);
  if (value === true) return Uint8Array.of(245);
  if (typeof value === "bigint") return encodeBigint(value);
  if (typeof value === "string") {
    const bytes2 = utf8(value);
    return concatBytes(encodeHead(3, BigInt(bytes2.length)), bytes2);
  }
  if (value instanceof Uint8Array) return concatBytes(encodeHead(2, BigInt(value.length)), value);
  if (Array.isArray(value)) return concatBytes(encodeHead(4, BigInt(value.length)), ...value.map(encodeCanonicalCbor));
  if (isMap(value)) {
    const entries = [...value].map(([key, item]) => ({ key: encodeCanonicalCbor(key), value: encodeCanonicalCbor(item) })).sort((a, b) => a.key.length === b.key.length ? compareBytes(a.key, b.key) : a.key.length - b.key.length);
    for (let index = 1; index < entries.length; index += 1) canonicalInvariant(!equalBytes(entries[index - 1].key, entries[index].key), "CBOR_NON_CANONICAL", "Duplicate canonical CBOR map key");
    return concatBytes(encodeHead(5, BigInt(entries.length)), ...entries.flatMap((entry) => [entry.key, entry.value]));
  }
  throw new CanonicalError("SCHEMA_INVALID", "Value is not supported by the deterministic CBOR profile");
}
var Decoder = class {
  constructor(input, limits) {
    this.input = input;
    this.limits = limits;
    canonicalInvariant(input.length <= limits.maxBytes, "CBOR_LIMIT_EXCEEDED", "CBOR input exceeds byte limit");
  }
  input;
  limits;
  offset = 0;
  decode() {
    const value = this.value(0);
    canonicalInvariant(this.offset === this.input.length, "CBOR_INVALID", "Trailing bytes after CBOR value");
    return value;
  }
  byte() {
    canonicalInvariant(this.offset < this.input.length, "CBOR_INVALID", "Unexpected end of CBOR input");
    return this.input[this.offset++];
  }
  bytes(size) {
    canonicalInvariant(Number.isSafeInteger(size) && size >= 0 && this.offset + size <= this.input.length, "CBOR_INVALID", "Invalid or truncated CBOR byte range");
    const value = this.input.slice(this.offset, this.offset + size);
    this.offset += size;
    return value;
  }
  argument(additional) {
    if (additional < 24) return BigInt(additional);
    const read = (size) => {
      const bytes2 = this.bytes(size);
      const view = new DataView(bytes2.buffer, bytes2.byteOffset, size);
      return size === 1 ? BigInt(bytes2[0]) : size === 2 ? BigInt(view.getUint16(0, false)) : size === 4 ? BigInt(view.getUint32(0, false)) : view.getBigUint64(0, false);
    };
    if (additional === 24) {
      const v = read(1);
      canonicalInvariant(v >= 24n, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 25) {
      const v = read(2);
      canonicalInvariant(v > 0xffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 26) {
      const v = read(4);
      canonicalInvariant(v > 0xffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 27) {
      const v = read(8);
      canonicalInvariant(v > 0xffffffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 31) throw new CanonicalError("CBOR_NON_CANONICAL", "Indefinite-length CBOR is prohibited");
    throw new CanonicalError("CBOR_INVALID", "Reserved CBOR additional information");
  }
  bignum(tag, depth) {
    canonicalInvariant(tag === POSITIVE_BIGNUM_TAG || tag === NEGATIVE_BIGNUM_TAG, "CBOR_INVALID", "Unsupported CBOR tag");
    canonicalInvariant(depth < this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    canonicalInvariant(major === 2, "CBOR_INVALID", "CBOR bignum payload must be a byte string");
    const argument = this.argument(additional);
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR bignum is too large");
    const size = Number(argument);
    canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR bignum exceeds blob limit");
    const bytes2 = this.bytes(size);
    canonicalInvariant(bytes2.length > 8 && bytes2[0] !== 0, "CBOR_NON_CANONICAL", "CBOR bignum is not minimally encoded");
    let magnitude = 0n;
    for (const byte of bytes2) magnitude = magnitude << 8n | BigInt(byte);
    canonicalInvariant(magnitude > MAX_UINT64, "CBOR_NON_CANONICAL", "CBOR bignum must use the ordinary integer representation");
    return tag === POSITIVE_BIGNUM_TAG ? magnitude : -1n - magnitude;
  }
  value(depth) {
    canonicalInvariant(depth <= this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    if (major === 7) {
      if (additional === 20) return false;
      if (additional === 21) return true;
      if (additional === 22) return null;
      throw new CanonicalError("CBOR_INVALID", "Floating point and unsupported simple CBOR values are prohibited");
    }
    const argument = this.argument(additional);
    if (major === 6) return this.bignum(argument, depth + 1);
    if (major === 0) return argument;
    if (major === 1) return -1n - argument;
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR collection is too large");
    const size = Number(argument);
    if (major === 2) {
      canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR blob exceeds limit");
      return this.bytes(size);
    }
    if (major === 3) {
      canonicalInvariant(size <= this.limits.maxTextBytes, "CBOR_LIMIT_EXCEEDED", "CBOR text exceeds limit");
      return decodeUtf8(this.bytes(size));
    }
    if (major === 4) {
      canonicalInvariant(size <= this.limits.maxArrayItems, "CBOR_LIMIT_EXCEEDED", "CBOR array exceeds item limit");
      return Array.from({ length: size }, () => this.value(depth + 1));
    }
    if (major === 5) {
      canonicalInvariant(size <= this.limits.maxMapItems, "CBOR_LIMIT_EXCEEDED", "CBOR map exceeds item limit");
      const map = /* @__PURE__ */ new Map();
      let previous;
      for (let index = 0; index < size; index += 1) {
        const start = this.offset, key = this.value(depth + 1);
        canonicalInvariant(typeof key === "bigint" || typeof key === "string" || key instanceof Uint8Array, "CBOR_INVALID", "Unsupported CBOR map key");
        const encoded = this.input.slice(start, this.offset);
        if (previous !== void 0) canonicalInvariant(previous.length === encoded.length ? compareBytes(previous, encoded) < 0 : previous.length < encoded.length, "CBOR_NON_CANONICAL", "CBOR map keys are duplicate or incorrectly ordered");
        previous = encoded;
        map.set(key, this.value(depth + 1));
      }
      return map;
    }
    throw new CanonicalError("CBOR_INVALID", `Unsupported CBOR major type ${major}`);
  }
};
function decodeCanonicalCbor(input, limits) {
  return new Decoder(input, limits).decode();
}
function assertCanonicalCbor(input, limits) {
  const value = decodeCanonicalCbor(input, limits);
  canonicalInvariant(equalBytes(encodeCanonicalCbor(value), input), "CBOR_NON_CANONICAL", "CBOR bytes are not canonical");
  return value;
}

// packages/canonical/src/hash.ts
var HASH_DOMAINS = Object.freeze({
  transaction: "chronolog/transaction",
  schema: "chronolog/schema",
  executionManifest: "chronolog/execution-manifest",
  queryResult: "chronolog/query-result",
  expectation: "chronolog/expectation",
  module: "chronolog/module",
  entropy: "chronolog/entropy",
  platformObject: "chronolog/platform-object"
});
function bufferSource(value) {
  return Uint8Array.from(value).buffer;
}
async function sha256(payload) {
  return new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bufferSource(payload)));
}

// packages/protocol/src/errors.ts
var ProtocolError = class extends Error {
  code;
  details;
  constructor(code, message, details) {
    super(message);
    this.name = "ProtocolError";
    this.code = code;
    this.details = details;
  }
  toJSON() {
    return this.details === void 0 ? { name: this.name, code: this.code, message: this.message } : { name: this.name, code: this.code, message: this.message, details: this.details };
  }
};
function protocolInvariant(condition, code, message, details) {
  if (!condition) throw new ProtocolError(code, message, details);
}

// packages/protocol/src/bytes.ts
function wrap(operation) {
  try {
    return operation();
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
    throw error;
  }
}
function utf82(value) {
  return wrap(() => utf8(value));
}
function bytesToHex2(value) {
  return bytesToHex(value);
}

// packages/protocol/src/cbor.ts
function sharedLimits(limits) {
  return {
    maxBytes: limits.maxBytes ?? DEFAULT_DECODE_LIMITS.maxBytes,
    maxDepth: limits.maxDepth ?? DEFAULT_DECODE_LIMITS.maxDepth,
    maxArrayItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxArrayItems,
    maxMapItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxMapItems,
    maxTextBytes: limits.maxTextBytes ?? DEFAULT_DECODE_LIMITS.maxTextBytes,
    maxBlobBytes: limits.maxByteStringBytes ?? DEFAULT_DECODE_LIMITS.maxBlobBytes
  };
}
function protocolError(error) {
  if (error instanceof ProtocolError) throw error;
  if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
  throw error;
}
function assertCanonicalCbor2(input, limits = {}) {
  try {
    return assertCanonicalCbor(input, sharedLimits(limits));
  } catch (error) {
    return protocolError(error);
  }
}

// packages/protocol/src/schema.ts
function integerMap(entries) {
  const result = /* @__PURE__ */ new Map();
  for (const [key, value] of entries) {
    if (value !== void 0) result.set(BigInt(key), value);
  }
  return result;
}
function expectMap(value, name2) {
  protocolInvariant(value instanceof Map, "SCHEMA_INVALID", `${name2} must be a CBOR map`);
  return value;
}
function expectArray(value, name2) {
  protocolInvariant(Array.isArray(value), "SCHEMA_INVALID", `${name2} must be a CBOR array`);
  return value;
}
function expectBytes(value, name2, length) {
  protocolInvariant(value instanceof Uint8Array, "SCHEMA_INVALID", `${name2} must be bytes`);
  if (length !== void 0) {
    protocolInvariant(value.length === length, "SCHEMA_INVALID", `${name2} must contain ${length} bytes`);
  }
  return value;
}
function expectString(value, name2) {
  protocolInvariant(typeof value === "string", "SCHEMA_INVALID", `${name2} must be text`);
  return value;
}
function expectBigint(value, name2) {
  protocolInvariant(typeof value === "bigint", "SCHEMA_INVALID", `${name2} must be an integer`);
  return value;
}
function expectUint64(value, name2) {
  const integer = expectBigint(value, name2);
  protocolInvariant(integer >= 0n && integer <= (1n << 64n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside uint64 range`);
  return integer;
}
function expectInt64(value, name2) {
  const integer = expectBigint(value, name2);
  protocolInvariant(integer >= -(1n << 63n) && integer <= (1n << 63n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside int64 range`);
  return integer;
}
function required(map, key, name2) {
  const value = map.get(BigInt(key));
  if (value === void 0) throw new ProtocolError("SCHEMA_INVALID", `Missing required field ${name2}`, { field: name2 });
  return value;
}
function optional(map, key) {
  return map.get(BigInt(key));
}
function assertKnownIntegerKeys(map, knownKeys, name2) {
  const known = new Set(knownKeys.map(BigInt));
  for (const key of map.keys()) {
    protocolInvariant(typeof key === "bigint", "SCHEMA_INVALID", `${name2} contains a non-integer field key`);
    protocolInvariant(known.has(key), "SCHEMA_INVALID", `${name2} contains unknown critical field ${String(key)}`);
  }
}
function expectVersion(map, expected, name2) {
  const version2 = expectUint64(required(map, 0, `${name2}.version`), `${name2}.version`);
  protocolInvariant(version2 === expected, "UNSUPPORTED_VERSION", `Unsupported ${name2} version`, { version: version2.toString() });
}

// packages/protocol/src/sql.ts
var MIN_INT64 = -(1n << 63n);
var MAX_INT64 = (1n << 63n) - 1n;
var sqlValue = Object.freeze({
  null: () => ({ kind: "null" }),
  integer: (value) => {
    const integer = typeof value === "bigint" ? value : BigInt(value);
    protocolInvariant(integer >= MIN_INT64 && integer <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
    return { kind: "integer", value: integer };
  },
  real: (value) => {
    protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "SQL REAL must be finite");
    return { kind: "real", value };
  },
  text: (value) => {
    utf82(value);
    return { kind: "text", value };
  },
  blob: (value) => ({ kind: "blob", value: Uint8Array.from(value) })
});
function toSqlValue(value) {
  if (value === null || value === void 0) return sqlValue.null();
  if (typeof value === "bigint") return sqlValue.integer(value);
  if (typeof value === "number") return Number.isSafeInteger(value) ? sqlValue.integer(value) : sqlValue.real(value);
  if (typeof value === "boolean") return sqlValue.integer(value ? 1n : 0n);
  if (typeof value === "string") return sqlValue.text(value);
  if (value instanceof Uint8Array) return sqlValue.blob(value);
  if (isSqlValue(value)) return value;
  throw new TypeError("SQL values must be null, boolean, bigint, number, string, Uint8Array or a tagged SqlValue");
}
function isSqlValue(value) {
  if (typeof value !== "object" || value === null || !("kind" in value)) return false;
  const tagged = value;
  switch (tagged.kind) {
    case "null":
      return true;
    case "integer":
      return typeof tagged.value === "bigint";
    case "real":
      return typeof tagged.value === "number";
    case "text":
      return typeof tagged.value === "string";
    case "blob":
      return tagged.value instanceof Uint8Array;
    default:
      return false;
  }
}
function realBits(value) {
  const bits = new Uint8Array(8);
  new DataView(bits.buffer).setFloat64(0, value, false);
  return bits;
}
function sqlValueToCanonicalCbor(value) {
  switch (value.kind) {
    case "null":
      return [0n];
    case "integer":
      protocolInvariant(value.value >= MIN_INT64 && value.value <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
      return [1n, value.value];
    case "real":
      protocolInvariant(Number.isFinite(value.value), "SCHEMA_INVALID", "SQL REAL must be finite");
      return [2n, realBits(value.value)];
    case "text":
      utf82(value.value);
      return [3n, value.value];
    case "blob":
      return [4n, Uint8Array.from(value.value)];
  }
}
function sqlValueFromCanonicalCbor(value, name2 = "sql_value") {
  const tuple = expectArray(value, name2);
  const kind = expectUint64(tuple[0] ?? null, `${name2}.kind`);
  protocolInvariant(tuple.length === (kind === 0n ? 1 : 2), "SCHEMA_INVALID", `${name2} has invalid arity`);
  switch (kind) {
    case 0n:
      return { kind: "null" };
    case 1n:
      return { kind: "integer", value: expectInt64(tuple[1] ?? null, `${name2}.integer`) };
    case 2n: {
      const bits = expectBytes(tuple[1] ?? null, `${name2}.real`, 8);
      const real = new DataView(bits.buffer, bits.byteOffset, 8).getFloat64(0, false);
      protocolInvariant(Number.isFinite(real), "SCHEMA_INVALID", `${name2}.real must be finite`);
      return { kind: "real", value: real };
    }
    case 3n:
      return { kind: "text", value: expectString(tuple[1] ?? null, `${name2}.text`) };
    case 4n:
      return { kind: "blob", value: Uint8Array.from(expectBytes(tuple[1] ?? null, `${name2}.blob`)) };
    default:
      protocolInvariant(false, "SCHEMA_INVALID", `${name2} has unknown kind`);
  }
}
var DEFAULT_EXECUTION_LIMITS = Object.freeze({
  maxSqlBytes: 1e6,
  maxVmSteps: 1e6,
  maxValueBytes: 16 * 1024 * 1024
});

// packages/protocol/src/sealed.ts
var MAX_SEALED_READERS = 256;
var MAX_SEALED_NAME_BYTES = 128;
var MAX_SEALED_ROW_KEY_VALUES = 64;
var MAX_SEALED_PLAINTEXT_BYTES = 1024 * 1024;
var MAX_SEALED_ENVELOPE_BYTES = MAX_SEALED_PLAINTEXT_BYTES + MAX_SEALED_READERS * 192 + 1024;
var MAX_SEALED_VERSION = (1n << 63n) - 1n;
var SEALED_OP_CODES = Object.freeze({
  register_reader_key: 64n,
  reader_policy: 65n,
  sealed_put: 66n
});
function isSealedPlatformOp(value) {
  return typeof value === "object" && value !== null && "op" in value && typeof value.op === "string" && Object.hasOwn(SEALED_OP_CODES, value.op);
}
var sealedOp = Object.freeze({
  registerReaderKey: (publicKey) => checked({ op: "register_reader_key", publicKey: id(publicKey, "register_reader_key.public_key") }),
  readerPolicy: (input) => checked({
    op: "reader_policy",
    table: input.table,
    rowKey: input.rowKey.map(toSqlValue),
    expectedVersion: input.expectedVersion,
    ...input.expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(input.expectedPolicyId, "reader_policy.expected_policy_id") },
    readers: input.readers.map((reader) => id(reader, "reader_policy.reader")).sort(compareBytes)
  }),
  put: (input) => checked({
    op: "sealed_put",
    policyId: id(input.policyId, "sealed_put.policy_id"),
    expectedPolicyVersion: input.expectedPolicyVersion,
    expectedDataVersion: input.expectedDataVersion,
    slot: input.slot,
    envelope: decodeSealedEnvelope(encodeSealedEnvelope(input.envelope))
  })
});
function checked(op) {
  return sealedPlatformOpFromCanonicalCbor(sealedPlatformOpToCanonicalCbor(op));
}
function id(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === 32, "SCHEMA_INVALID", `${field} must contain 32 bytes`);
  return Uint8Array.from(value);
}
function name(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0 && !value.includes("\0"), "SCHEMA_INVALID", `${field} must be nonempty text without U+0000`);
  protocolInvariant(utf82(value).length <= MAX_SEALED_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function version(value, field, minimum = 1n, maximum = MAX_SEALED_VERSION) {
  const parsed = expectUint64(value, field);
  protocolInvariant(parsed >= minimum && parsed <= maximum, "INTEGER_OUT_OF_RANGE", `${field} is outside the supported version range`);
  return parsed;
}
var isList = (value) => Array.isArray(value);
function orderedReaders(readers, field) {
  protocolInvariant(isList(readers) && readers.length <= MAX_SEALED_READERS, "SCHEMA_INVALID", `${field} has too many readers or is not an array`);
  return readers.map((reader, index) => {
    const key = id(reader, field);
    if (index > 0) protocolInvariant(compareBytes(readers[index - 1], reader) < 0, "SCHEMA_INVALID", `${field} must be sorted and unique`);
    return key;
  });
}
function sealedContextToCanonicalCbor(value) {
  return integerMap([
    [0, 1n],
    [1, id(value.groupId, "sealed_context.group_id")],
    [2, id(value.policyId, "sealed_context.policy_id")],
    [3, version(value.policyVersion, "sealed_context.policy_version")],
    [4, name(value.slot, "sealed_context.slot")],
    [5, version(value.dataVersion, "sealed_context.data_version")]
  ]);
}
function sealedContextFromCanonicalCbor(value) {
  const map = expectMap(value, "sealed_context");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], "sealed_context");
  expectVersion(map, 1n, "sealed_context");
  const context = {
    groupId: id(expectBytes(required(map, 1, "group_id"), "group_id", 32), "group_id"),
    policyId: id(expectBytes(required(map, 2, "policy_id"), "policy_id", 32), "policy_id"),
    policyVersion: expectUint64(required(map, 3, "policy_version"), "policy_version"),
    slot: expectString(required(map, 4, "slot"), "slot"),
    dataVersion: expectUint64(required(map, 5, "data_version"), "data_version")
  };
  sealedContextToCanonicalCbor(context);
  return context;
}
function sealedEnvelopeToCanonicalCbor(value) {
  protocolInvariant(value.nonce instanceof Uint8Array && value.nonce.length === 12, "SCHEMA_INVALID", "sealed_envelope.nonce must contain 12 bytes");
  protocolInvariant(
    value.ciphertext instanceof Uint8Array && value.ciphertext.length >= 16 && value.ciphertext.length <= MAX_SEALED_PLAINTEXT_BYTES + 16,
    "SCHEMA_INVALID",
    "sealed_envelope.ciphertext has an invalid length"
  );
  protocolInvariant(isList(value.wraps), "SCHEMA_INVALID", "sealed_envelope.wraps must be an array");
  orderedReaders(value.wraps.map((wrap2) => wrap2.readerId), "sealed_envelope.wraps");
  return integerMap([
    [0, 1n],
    [1, sealedContextToCanonicalCbor(value.context)],
    [2, Uint8Array.from(value.nonce)],
    [3, Uint8Array.from(value.ciphertext)],
    [4, value.wraps.map((wrap2) => {
      protocolInvariant(wrap2.ciphertext instanceof Uint8Array && wrap2.ciphertext.length === 48, "SCHEMA_INVALID", "sealed_wrap.ciphertext must contain 48 bytes");
      return [
        id(wrap2.readerId, "sealed_wrap.reader_id"),
        id(wrap2.publicKey, "sealed_wrap.public_key"),
        id(wrap2.encapsulatedKey, "sealed_wrap.encapsulated_key"),
        Uint8Array.from(wrap2.ciphertext)
      ];
    })]
  ]);
}
function sealedEnvelopeFromCanonicalCbor(value) {
  const map = expectMap(value, "sealed_envelope");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4], "sealed_envelope");
  expectVersion(map, 1n, "sealed_envelope");
  const envelope = {
    context: sealedContextFromCanonicalCbor(required(map, 1, "context")),
    nonce: Uint8Array.from(expectBytes(required(map, 2, "nonce"), "nonce", 12)),
    ciphertext: Uint8Array.from(expectBytes(required(map, 3, "ciphertext"), "ciphertext")),
    wraps: expectArray(required(map, 4, "wraps"), "wraps").map((entry) => {
      const fields = expectArray(entry, "sealed_wrap");
      protocolInvariant(fields.length === 4, "SCHEMA_INVALID", "sealed_wrap must contain four fields");
      return {
        readerId: id(expectBytes(fields[0], "reader_id", 32), "reader_id"),
        publicKey: id(expectBytes(fields[1], "public_key", 32), "public_key"),
        encapsulatedKey: id(expectBytes(fields[2], "encapsulated_key", 32), "encapsulated_key"),
        ciphertext: Uint8Array.from(expectBytes(fields[3], "wrapped_key", 48))
      };
    })
  };
  sealedEnvelopeToCanonicalCbor(envelope);
  return envelope;
}
function encodeSealedEnvelope(envelope) {
  return encodeCanonicalCbor(sealedEnvelopeToCanonicalCbor(envelope));
}
function decodeSealedEnvelope(bytes2) {
  protocolInvariant(bytes2.length <= MAX_SEALED_ENVELOPE_BYTES, "SCHEMA_INVALID", "sealed_envelope exceeds the encoded size limit");
  return sealedEnvelopeFromCanonicalCbor(assertCanonicalCbor2(bytes2));
}
function sealedPlatformOpToCanonicalCbor(op) {
  protocolInvariant(isSealedPlatformOp(op), "SCHEMA_INVALID", "Unknown sealed operation");
  const entries = [[0, SEALED_OP_CODES[op.op]]];
  switch (op.op) {
    case "register_reader_key":
      entries.push([1, id(op.publicKey, "register_reader_key.public_key")]);
      break;
    case "reader_policy": {
      const expected = version(op.expectedVersion, "reader_policy.expected_version", 0n, MAX_SEALED_VERSION - 1n);
      protocolInvariant(expected === 0n === (op.expectedPolicyId === void 0), "SCHEMA_INVALID", "reader_policy creation uses version 0 without an id; replacement requires an id and positive version");
      protocolInvariant(isList(op.rowKey) && op.rowKey.length >= 1 && op.rowKey.length <= MAX_SEALED_ROW_KEY_VALUES, "SCHEMA_INVALID", "reader_policy.row_key has an invalid length");
      entries.push(
        [1, name(op.table, "reader_policy.table")],
        [2, op.rowKey.map(sqlValueToCanonicalCbor)],
        [3, op.expectedPolicyId === void 0 ? void 0 : id(op.expectedPolicyId, "reader_policy.expected_policy_id")],
        [4, expected],
        [5, orderedReaders(op.readers, "reader_policy.readers")]
      );
      break;
    }
    case "sealed_put": {
      const policyId = id(op.policyId, "sealed_put.policy_id");
      const policyVersion = version(op.expectedPolicyVersion, "sealed_put.expected_policy_version");
      const dataVersion = version(op.expectedDataVersion, "sealed_put.expected_data_version", 0n, MAX_SEALED_VERSION - 1n);
      const slot = name(op.slot, "sealed_put.slot");
      const envelope = sealedEnvelopeToCanonicalCbor(op.envelope);
      protocolInvariant(
        equalBytes(op.envelope.context.policyId, policyId) && op.envelope.context.policyVersion === policyVersion && op.envelope.context.slot === slot && op.envelope.context.dataVersion === dataVersion + 1n,
        "SCHEMA_INVALID",
        "sealed_put envelope does not match its policy, slot or next data version"
      );
      entries.push([1, policyId], [2, policyVersion], [3, dataVersion], [4, slot], [5, envelope]);
      break;
    }
  }
  return integerMap(entries);
}
function sealedPlatformOpFromCanonicalCbor(value, field = "sealed_op") {
  const map = expectMap(value, field);
  const code = expectUint64(required(map, 0, `${field}.op`), `${field}.op`);
  let op;
  if (code === SEALED_OP_CODES.register_reader_key) {
    assertKnownIntegerKeys(map, [0, 1], field);
    op = { op: "register_reader_key", publicKey: id(expectBytes(required(map, 1, "public_key"), "public_key", 32), "public_key") };
  } else if (code === SEALED_OP_CODES.reader_policy) {
    assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], field);
    const expectedPolicyId = optional(map, 3);
    op = {
      op: "reader_policy",
      table: expectString(required(map, 1, "table"), "table"),
      rowKey: expectArray(required(map, 2, "row_key"), "row_key").map((item, index) => sqlValueFromCanonicalCbor(item, `row_key[${index}]`)),
      ...expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(expectBytes(expectedPolicyId, "expected_policy_id", 32), "expected_policy_id") },
      expectedVersion: expectUint64(required(map, 4, "expected_version"), "expected_version"),
      readers: expectArray(required(map, 5, "readers"), "readers").map((reader) => id(expectBytes(reader, "reader", 32), "reader"))
    };
  } else if (code === SEALED_OP_CODES.sealed_put) {
    assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], field);
    op = {
      op: "sealed_put",
      policyId: id(expectBytes(required(map, 1, "policy_id"), "policy_id", 32), "policy_id"),
      expectedPolicyVersion: expectUint64(required(map, 2, "expected_policy_version"), "expected_policy_version"),
      expectedDataVersion: expectUint64(required(map, 3, "expected_data_version"), "expected_data_version"),
      slot: expectString(required(map, 4, "slot"), "slot"),
      envelope: sealedEnvelopeFromCanonicalCbor(required(map, 5, "envelope"))
    };
  } else {
    protocolInvariant(false, "SCHEMA_INVALID", `${field} has an unknown sealed operation`);
  }
  sealedPlatformOpToCanonicalCbor(op);
  return op;
}

// packages/protocol/src/platform.ts
var PLATFORM_ID_BYTES = 32;
var MAX_PLATFORM_NAME_BYTES = 128;
var MAX_PLATFORM_LIST_ENTRIES = 256;
var MAX_ROW_KEY_VALUES = 64;
var MAX_SEED_ROWS = 1e4;
var GROUP_COLLECTIVE_ID = new Uint8Array(PLATFORM_ID_BYTES);
var OP_CODES = [
  "grant",
  "revoke_grant",
  "create_collective",
  "accept_membership",
  "leave",
  "set_members",
  "transfer_offer",
  "transfer_accept",
  "seed_rows",
  "end_seeding",
  "transfer_cancel",
  "grant_ddl",
  "revoke_ddl"
];
var DDL_OPERATIONS = ["create", "alter", "drop", "index", "trigger"];
var OPERATION_BITS = { insert: 1n, update: 2n, delete: 4n };
var GRANT_OPERATIONS = ["insert", "update", "delete"];
var bytes = (value) => Uint8Array.from(value);
var rowKey = (values) => values.map(toSqlValue);
var platformOp = Object.freeze({
  ...sealedOp,
  grantDdl: (input) => checked2({ op: "grant_ddl", scope: { ...input.scope }, grantee: bytes(input.grantee), operations: [...input.operations] }),
  revokeDdl: (grantId) => checked2({ op: "revoke_ddl", grantId: bytes(grantId) }),
  grant: (input) => checked2({
    op: "grant",
    table: input.table,
    grantee: bytes(input.grantee),
    operations: [...input.operations],
    ...input.grantor === void 0 ? {} : { grantor: bytes(input.grantor) },
    ...input.rowKey === void 0 ? {} : { rowKey: rowKey(input.rowKey) },
    ...input.columns === void 0 ? {} : { columns: [...input.columns] }
  }),
  revokeGrant: (grantId) => checked2({ op: "revoke_grant", grantId: bytes(grantId) }),
  createCollective: (input) => checked2({ op: "create_collective", governance: { ...input.governance }, invitees: (input.invitees ?? []).map(bytes) }),
  acceptMembership: (collectiveId) => checked2({ op: "accept_membership", collectiveId: bytes(collectiveId) }),
  leave: (collectiveId) => checked2({ op: "leave", collectiveId: bytes(collectiveId) }),
  setMembers: (collectiveId, changes) => checked2({
    op: "set_members",
    collectiveId: bytes(collectiveId),
    changes: changes.map((change) => ({ member: bytes(change.member), role: change.role }))
  }),
  transferRow: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "row", table: input.table, rowKey: rowKey(input.rowKey) },
    toOwner: bytes(input.toOwner),
    carry: input.carry ?? false,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  transferAll: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "all" },
    toOwner: bytes(input.toOwner),
    carry: true,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  acceptTransfer: (offerId) => checked2({ op: "transfer_accept", offerId: bytes(offerId) }),
  cancelTransfer: (offerId) => checked2({ op: "transfer_cancel", offerId: bytes(offerId) }),
  seedRows: (table, columns, rows) => checked2({ op: "seed_rows", table, columns: [...columns], rows: rows.map(rowKey) }),
  endSeeding: () => checked2({ op: "end_seeding" })
});
function checked2(op) {
  platformOpToCanonicalCbor(op);
  return op;
}
function nameToCbor(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0, "SCHEMA_INVALID", `${field} cannot be empty`);
  protocolInvariant(!value.includes("\0"), "SCHEMA_INVALID", `${field} cannot contain U+0000`);
  protocolInvariant(utf82(value).length <= MAX_PLATFORM_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function idToCbor(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === PLATFORM_ID_BYTES, "SCHEMA_INVALID", `${field} must contain ${PLATFORM_ID_BYTES} bytes`);
  return Uint8Array.from(value);
}
function listToCbor(values, field, encode, minimum = 0) {
  protocolInvariant(isList2(values), "SCHEMA_INVALID", `${field} must be a list`);
  protocolInvariant(values.length >= minimum && values.length <= MAX_PLATFORM_LIST_ENTRIES, "SCHEMA_INVALID", `${field} has an invalid number of entries`);
  return values.map(encode);
}
function uniqueBy(values, key, field) {
  const seen = /* @__PURE__ */ new Set();
  for (const value of values) {
    const entry = key(value);
    protocolInvariant(!seen.has(entry), "SCHEMA_INVALID", `${field} contains a duplicate`);
    seen.add(entry);
  }
}
var hex = (value) => bytesToHex2(value);
var isList2 = (value) => Array.isArray(value);
function rowKeyToCbor(values, field) {
  protocolInvariant(isList2(values) && values.length >= 1 && values.length <= MAX_ROW_KEY_VALUES, "SCHEMA_INVALID", `${field} must have 1 to ${MAX_ROW_KEY_VALUES} values`);
  return values.map(sqlValueToCanonicalCbor);
}
function roleCode(role, field) {
  protocolInvariant(role === "member" || role === "admin", "SCHEMA_INVALID", `${field} must be member or admin`);
  return role === "member" ? 0n : 1n;
}
function platformOpToCanonicalCbor(op) {
  if (isSealedPlatformOp(op)) return sealedPlatformOpToCanonicalCbor(op);
  const code = OP_CODES.indexOf(op.op);
  protocolInvariant(code >= 0, "SCHEMA_INVALID", "Unknown platform operation");
  const entries = [[0, BigInt(code)]];
  switch (op.op) {
    case "grant_ddl": {
      protocolInvariant(op.scope.kind === "namespace" || op.scope.kind === "object", "SCHEMA_INVALID", "Unknown DDL scope");
      protocolInvariant(op.scope.kind !== "namespace" || op.scope.name === "main", "SCHEMA_INVALID", "Only the main namespace exists");
      protocolInvariant(isList2(op.operations) && op.operations.length > 0, "SCHEMA_INVALID", "DDL operations cannot be empty");
      uniqueBy(op.operations, (value) => value, "grant_ddl.operations");
      protocolInvariant(op.operations.every((operation) => DDL_OPERATIONS.includes(operation) && (op.scope.kind === "namespace" ? operation === "create" : operation !== "create")), "SCHEMA_INVALID", "Invalid DDL operation for scope");
      protocolInvariant(
        DDL_OPERATIONS.filter((operation) => op.operations.includes(operation)).every((operation, index) => op.operations[index] === operation),
        "SCHEMA_INVALID",
        "DDL operations must be in create, alter, drop, index, trigger order"
      );
      entries.push(
        [1, [op.scope.kind === "namespace" ? 0n : 1n, nameToCbor(op.scope.name, "grant_ddl.scope")]],
        [2, idToCbor(op.grantee, "grant_ddl.grantee")],
        [3, op.operations.map((operation) => BigInt(DDL_OPERATIONS.indexOf(operation)))]
      );
      break;
    }
    case "revoke_ddl":
      entries.push([1, idToCbor(op.grantId, "revoke_ddl.grant_id")]);
      break;
    case "grant": {
      protocolInvariant(isList2(op.operations) && op.operations.length > 0, "SCHEMA_INVALID", "grant.operations cannot be empty");
      uniqueBy(op.operations, (value) => value, "grant.operations");
      let mask = 0n;
      for (const operation of op.operations) {
        protocolInvariant(GRANT_OPERATIONS.includes(operation), "SCHEMA_INVALID", "grant.operations has an unknown operation");
        mask |= OPERATION_BITS[operation];
      }
      protocolInvariant(
        GRANT_OPERATIONS.filter((operation) => op.operations.includes(operation)).every((operation, index) => op.operations[index] === operation),
        "SCHEMA_INVALID",
        "grant.operations must be in insert, update, delete order"
      );
      if (op.columns !== void 0) uniqueBy(op.columns, (value) => value, "grant.columns");
      entries.push(
        [1, nameToCbor(op.table, "grant.table")],
        [2, idToCbor(op.grantee, "grant.grantee")],
        [3, mask],
        [4, op.grantor === void 0 ? void 0 : idToCbor(op.grantor, "grant.grantor")],
        [5, op.rowKey === void 0 ? void 0 : rowKeyToCbor(op.rowKey, "grant.row_key")],
        [6, op.columns === void 0 ? void 0 : listToCbor(op.columns, "grant.columns", (column) => nameToCbor(column, "grant.columns"), 1)]
      );
      break;
    }
    case "revoke_grant":
      entries.push([1, idToCbor(op.grantId, "revoke_grant.grant_id")]);
      break;
    case "create_collective":
      uniqueBy(op.invitees, hex, "create_collective.invitees");
      entries.push(
        [1, integerMap([
          [0, roleCode(op.governance.insert, "governance.insert")],
          [1, roleCode(op.governance.update, "governance.update")],
          [2, roleCode(op.governance.delete, "governance.delete")]
        ])],
        [2, listToCbor(op.invitees, "create_collective.invitees", (key) => idToCbor(key, "create_collective.invitees"))]
      );
      break;
    case "accept_membership":
    case "leave":
      entries.push([1, idToCbor(op.collectiveId, `${op.op}.collective_id`)]);
      break;
    case "set_members":
      uniqueBy(op.changes, (change) => hex(change.member), "set_members.changes");
      entries.push(
        [1, idToCbor(op.collectiveId, "set_members.collective_id")],
        [2, listToCbor(op.changes, "set_members.changes", (change) => [
          idToCbor(change.member, "set_members.member"),
          change.role === "remove" ? 2n : roleCode(change.role, "set_members.role")
        ], 1)]
      );
      break;
    case "transfer_offer": {
      protocolInvariant(typeof op.carry === "boolean", "SCHEMA_INVALID", "transfer_offer.carry must be a boolean");
      let scope;
      if (op.scope.kind === "all") {
        protocolInvariant(op.carry, "SCHEMA_INVALID", "A transfer of all rows always carries dependents");
        scope = [1n];
      } else {
        protocolInvariant(op.scope.kind === "row", "SCHEMA_INVALID", "transfer_offer.scope is unknown");
        scope = [0n, nameToCbor(op.scope.table, "transfer_offer.table"), rowKeyToCbor(op.scope.rowKey, "transfer_offer.row_key")];
      }
      entries.push(
        [1, scope],
        [2, op.fromOwner === void 0 ? void 0 : idToCbor(op.fromOwner, "transfer_offer.from_owner")],
        [3, idToCbor(op.toOwner, "transfer_offer.to_owner")],
        [4, op.carry ? 1n : 0n]
      );
      break;
    }
    case "transfer_accept":
    case "transfer_cancel":
      entries.push([1, idToCbor(op.offerId, `${op.op}.offer_id`)]);
      break;
    case "seed_rows": {
      uniqueBy(op.columns, (value) => value.toLowerCase(), "seed_rows.columns");
      protocolInvariant(isList2(op.rows) && op.rows.length >= 1 && op.rows.length <= MAX_SEED_ROWS, "SCHEMA_INVALID", "seed_rows.rows has an invalid number of rows");
      entries.push(
        [1, nameToCbor(op.table, "seed_rows.table")],
        [2, listToCbor(op.columns, "seed_rows.columns", (column) => nameToCbor(column, "seed_rows.columns"), 1)],
        [3, op.rows.map((row) => {
          protocolInvariant(isList2(row) && row.length === op.columns.length, "SCHEMA_INVALID", "seed_rows row width must match its columns");
          return row.map(sqlValueToCanonicalCbor);
        })]
      );
      break;
    }
    case "end_seeding":
      break;
  }
  return integerMap(entries);
}

// packages/protocol/src/program.ts
var MAX_EVENT_BYTES = 16384;
function canonicalJson(payload, limits) {
  for (const bound of [limits.maxBytes, limits.maxNodes, limits.maxDepth]) protocolInvariant(Number.isSafeInteger(bound) && bound > 0, "SCHEMA_INVALID", "Invalid JSON limits");
  let nodes = 0;
  const visit = (value, depth) => {
    protocolInvariant(depth <= limits.maxDepth && ++nodes <= limits.maxNodes, "SCHEMA_INVALID", "JSON payload is too complex");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "Event numbers must be finite");
      return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
      protocolInvariant(Reflect.ownKeys(value).length === value.length + 1, "SCHEMA_INVALID", "Event arrays cannot carry extra properties");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, i);
        protocolInvariant(
          descriptor !== void 0 && "value" in descriptor && descriptor.enumerable === true,
          "SCHEMA_INVALID",
          "Event arrays require dense data elements"
        );
        entries.push(visit(descriptor.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    protocolInvariant(
      typeof value === "object" && value !== null && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null),
      "SCHEMA_INVALID",
      "Event payload must contain JSON values"
    );
    protocolInvariant(Reflect.ownKeys(value).length === Object.keys(value).length, "SCHEMA_INVALID", "Event objects require enumerable string keys");
    return `{${Object.keys(value).sort().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      protocolInvariant("value" in descriptor, "SCHEMA_INVALID", "Event payload cannot contain accessors");
      return `${JSON.stringify(key)}:${visit(descriptor.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const encoded = visit(payload, 0);
  protocolInvariant(utf82(encoded).length <= limits.maxBytes, "SCHEMA_INVALID", "JSON payload is too large");
  return encoded;
}
function canonicalEventPayload(payload) {
  return canonicalJson(payload, { maxBytes: MAX_EVENT_BYTES, maxNodes: 4096, maxDepth: 32 });
}

// packages/protocol/src/primitives.ts
var ED25519 = { name: "Ed25519" };
function bufferSource2(value) {
  return Uint8Array.from(value).buffer;
}
async function importEd25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "Ed25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", bufferSource2(raw), ED25519, true, ["verify"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 public key");
  }
}

// packages/authority/src/codec.ts
function check(condition, code) {
  if (!condition) throw Object.assign(new Error(code), { code });
}
function hex2(value, length = 32) {
  check(typeof value === "string" && new RegExp(`^[0-9a-f]{${length * 2}}$`, "u").test(value), "AUTHORITY_HEX_INVALID");
}
function normalized(value, depth = 0) {
  check(depth < 32, "RECORD_DEPTH_LIMIT");
  if (value instanceof Uint8Array) return { $bytes: bytesToHex(value) };
  if (typeof value === "bigint") return { $integer: value.toString() };
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    check(Number.isSafeInteger(value), "RECORD_INTEGER_INVALID");
    return value;
  }
  if (Array.isArray(value)) return value.map((item) => normalized(item, depth + 1));
  check(value !== null && typeof value === "object" && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null), "RECORD_INVALID");
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, normalized(value[key], depth + 1)]));
}
function encodeRecord(value) {
  const bytes2 = new TextEncoder().encode(JSON.stringify(normalized(value)));
  check(bytes2.length <= 32 * 1024 * 1024, "RECORD_BYTES_LIMIT");
  return bytes2;
}
function decodeRecord(bytes2) {
  check(bytes2.length <= 32 * 1024 * 1024, "RECORD_BYTES_LIMIT");
  const value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes2), (_key, item) => {
    if (item !== null && typeof item === "object" && !Array.isArray(item)) {
      const record = item;
      if (Object.keys(record).length === 1 && typeof record.$bytes === "string") {
        check(/^(?:[0-9a-f]{2})*$/u.test(record.$bytes), "RECORD_BYTES_INVALID");
        return hexToBytes(record.$bytes);
      }
      if (Object.keys(record).length === 1 && typeof record.$integer === "string") {
        check(/^-?(?:0|[1-9][0-9]*)$/u.test(record.$integer), "RECORD_INTEGER_INVALID");
        return BigInt(record.$integer);
      }
    }
    return item;
  });
  check(equalRecord(value, decodeUncanonical(bytes2)), "RECORD_INVALID");
  check(equalBytes(encodeRecord(value), bytes2), "RECORD_NOT_CANONICAL");
  return value;
}
function decodeUncanonical(bytes2) {
  return JSON.parse(new TextDecoder().decode(bytes2));
}
function equalRecord(a, b) {
  return equalBytes(encodeRecord(a), encodeRecord(b));
}
async function recordDigest(value) {
  return bytesToHex(await sha256(encodeRecord(value)));
}
function signedBytes(domain, payload) {
  return encodeRecord(["chronolog/authored/v1", domain, payload]);
}
async function signRecord(domain, payload, identity) {
  hex2(identity.publicKey);
  const captured = structuredClone(payload);
  const signature = bytesToHex(new Uint8Array(await crypto.subtle.sign("Ed25519", identity.privateKey, Uint8Array.from(signedBytes(domain, captured)).buffer)));
  const result = { payload: captured, signer: identity.publicKey, signature };
  await verifyRecord(domain, result, identity.publicKey);
  return result;
}
async function verifyRecord(domain, signed, expectedSigner) {
  hex2(signed.signer);
  hex2(signed.signature, 64);
  check(expectedSigner === void 0 || signed.signer === expectedSigner, "AUTHORITY_SIGNER_MISMATCH");
  const key = await importEd25519PublicKey(hexToBytes(signed.signer));
  check(await crypto.subtle.verify("Ed25519", key, Uint8Array.from(hexToBytes(signed.signature)).buffer, Uint8Array.from(signedBytes(domain, signed.payload)).buffer), "AUTHORITY_SIGNATURE_INVALID");
}

// packages/authority/src/definition.ts
function isArray(value) {
  return Array.isArray(value);
}
function object(value, keys) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), "APPLICATION_DESCRIPTION_INVALID");
}
function parseApplicationInput(schema, value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  const visit = (spec, item, path) => {
    const invalid = () => {
      throw new Error(`APPLICATION_INPUT_INVALID:${path}`);
    };
    if ("anyOf" in spec) {
      for (const option of spec.anyOf) {
        try {
          visit(option, item, path);
          return;
        } catch {
        }
      }
      invalid();
    } else if (spec.type === "null") {
      if (item !== null) invalid();
    } else if (spec.type === "boolean") {
      if (typeof item !== "boolean") invalid();
    } else if (spec.type === "string") {
      if (typeof item !== "string") return invalid();
      const length = [...item].length;
      if (length < (spec.minLength ?? 0) || length > (spec.maxLength ?? 16384) || spec.enum !== void 0 && !spec.enum.includes(item)) invalid();
    } else if (spec.type === "number" || spec.type === "integer") {
      if (typeof item !== "number" || spec.type === "integer" && !Number.isSafeInteger(item) || item < (spec.minimum ?? -Infinity) || item > (spec.maximum ?? Infinity)) invalid();
    } else if (spec.type === "array") {
      if (!Array.isArray(item) || item.length < (spec.minItems ?? 0) || item.length > (spec.maxItems ?? 4096)) return invalid();
      const items = item;
      items.forEach((child, index) => visit(spec.items, child, `${path}[${index}]`));
    } else if (spec.type === "object") {
      if (item === null || typeof item !== "object" || Array.isArray(item)) return invalid();
      const object2 = item;
      for (const name2 of spec.required ?? []) if (!Object.hasOwn(object2, name2)) invalid();
      for (const [name2, child] of Object.entries(object2)) {
        if (!Object.hasOwn(spec.properties, name2)) invalid();
        visit(spec.properties[name2], child, `${path}.${name2}`);
      }
    }
  };
  visit(schema, copy, "$");
  return freeze(copy);
}
function checkedApplicationInputSchema(value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  let nodes = 0;
  const visit = (schema, depth) => {
    if (++nodes > 256 || depth > 16 || schema === null || typeof schema !== "object" || Array.isArray(schema)) throw new Error("APPLICATION_SCHEMA_INVALID");
    const keys = /* @__PURE__ */ new Set(["description"]);
    const allow = (...names) => {
      for (const name2 of names) keys.add(name2);
    };
    const bound = (value2, max) => {
      if (value2 !== void 0 && (!Number.isSafeInteger(value2) || value2 < 0 || value2 > max)) throw new Error("APPLICATION_SCHEMA_INVALID");
    };
    if (schema.description !== void 0 && typeof schema.description !== "string") throw new Error("APPLICATION_SCHEMA_INVALID");
    if ("anyOf" in schema) {
      allow("anyOf");
      if (!Array.isArray(schema.anyOf) || schema.anyOf.length < 1 || schema.anyOf.length > 16) throw new Error("APPLICATION_SCHEMA_INVALID");
      const alternatives = schema.anyOf;
      alternatives.forEach((option) => visit(option, depth + 1));
    } else {
      allow("type");
      switch (schema.type) {
        case "string":
          allow("minLength", "maxLength", "enum");
          bound(schema.minLength, 16384);
          bound(schema.maxLength, 16384);
          if ((schema.minLength ?? 0) > (schema.maxLength ?? 16384) || schema.enum !== void 0 && (!Array.isArray(schema.enum) || schema.enum.length === 0 || schema.enum.length > 256 || schema.enum.some((item) => typeof item !== "string"))) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "number":
        case "integer":
          allow("minimum", "maximum");
          if ([schema.minimum, schema.maximum].some((value2) => value2 !== void 0 && !Number.isFinite(value2)) || (schema.minimum ?? -Infinity) > (schema.maximum ?? Infinity)) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "boolean":
        case "null":
          break;
        case "array":
          allow("items", "minItems", "maxItems");
          bound(schema.minItems, 4096);
          bound(schema.maxItems, 4096);
          if ((schema.minItems ?? 0) > (schema.maxItems ?? 4096)) throw new Error("APPLICATION_SCHEMA_INVALID");
          visit(schema.items, depth + 1);
          break;
        case "object":
          allow("properties", "required", "additionalProperties");
          if (schema.properties === null || typeof schema.properties !== "object" || Array.isArray(schema.properties) || schema.additionalProperties !== void 0 && schema.additionalProperties !== false) throw new Error("APPLICATION_SCHEMA_INVALID");
          for (const child of Object.values(schema.properties)) visit(child, depth + 1);
          if (schema.required !== void 0 && (!Array.isArray(schema.required) || schema.required.some((name2) => typeof name2 !== "string" || !Object.hasOwn(schema.properties, name2)) || new Set(schema.required).size !== schema.required.length)) {
            throw new Error("APPLICATION_SCHEMA_INVALID");
          }
          Object.assign(schema, { additionalProperties: false });
          break;
        default:
          throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
      }
    }
    if (Object.keys(schema).some((key) => !keys.has(key))) throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
  };
  visit(copy, 0);
  return freeze(copy);
}
function freeze(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
function validateApplicationDescription(value) {
  const bytes2 = descriptionJson(value);
  check(new TextEncoder().encode(bytes2).length <= 262144, "APPLICATION_DESCRIPTION_TOO_LARGE");
  const copy = JSON.parse(bytes2);
  object(copy, ["id", "version", "commands", "queries"]);
  for (const text of [copy.id, copy.version]) check(typeof text === "string" && /^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(text), "APPLICATION_DEFINITION_ID_INVALID");
  for (const entries of [copy.commands, copy.queries]) {
    check(isArray(entries) && entries.length <= 128, "APPLICATION_DEFINITION_TOO_LARGE");
    let previous = "";
    for (const entry of entries) {
      object(entry, ["name", "description", "input"]);
      check(typeof entry.name === "string" && /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(entry.name) && !["__proto__", "constructor", "prototype"].includes(entry.name) && entry.name > previous, "APPLICATION_DEFINITION_NAME_INVALID");
      previous = entry.name;
      check(typeof entry.description === "string" && entry.description.length <= 4096, "APPLICATION_DESCRIPTION_INVALID");
      const checked3 = checkedApplicationInputSchema(entry.input);
      check(canonicalEventPayload(entry.input) === canonicalEventPayload(checked3), "APPLICATION_SCHEMA_NOT_CANONICAL");
    }
  }
  return freeze(copy);
}
async function applicationDescriptionDigest(value) {
  const description = validateApplicationDescription(value);
  return recordDigest(["application-description/v1", descriptionJson(description)]);
}
function descriptionJson(value) {
  return canonicalJson(value, { maxBytes: 262144, maxNodes: 65536, maxDepth: 32 });
}

// packages/authority/src/control.ts
function inviteGrant(role) {
  return { reader: true, writer: role !== "reader", administrator: role === "admin" };
}
var isList3 = (value) => Array.isArray(value);
function exactRecord(value, keys, code) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value)), code);
  check(Reflect.ownKeys(value).length === keys.length && keys.every((key) => {
    const field = Object.getOwnPropertyDescriptor(value, key);
    return field !== void 0 && "value" in field;
  }), code);
}
function validateFinalityPolicy(input) {
  check(input !== null && typeof input === "object", "FINALITY_POLICY_UNSUPPORTED");
  const kind = Object.getOwnPropertyDescriptor(input, "kind")?.value;
  if (kind === "none") {
    exactRecord(input, ["kind"], "FINALITY_POLICY_FIELDS_INVALID");
    return { kind: "none" };
  }
  check(kind === "fixed-validator" || kind === "signed-frontier", "FINALITY_POLICY_UNSUPPORTED");
  exactRecord(input, kind === "fixed-validator" ? ["kind", "validators", "threshold", "scopes"] : ["kind", "signer", "scopes"], "FINALITY_POLICY_FIELDS_INVALID");
  check(Array.isArray(input.scopes) && input.scopes.length > 0 && input.scopes.length <= 4096, "FINALITY_SCOPE_INVALID");
  const scopes = [], ids = /* @__PURE__ */ new Set();
  let bound = -1n;
  for (const value of input.scopes) {
    exactRecord(value, ["id", "authorTimeAfterMs"], "FINALITY_SCOPE_INVALID");
    hex2(value.id);
    check(typeof value.authorTimeAfterMs === "bigint" && value.authorTimeAfterMs >= bound && value.authorTimeAfterMs <= (1n << 63n) - 1n && (scopes.length > 0 || value.authorTimeAfterMs === -1n) && !ids.has(value.id), "FINALITY_SCOPE_INVALID");
    scopes.push({ id: value.id, authorTimeAfterMs: value.authorTimeAfterMs });
    ids.add(value.id);
    bound = value.authorTimeAfterMs;
  }
  if (kind === "signed-frontier") {
    hex2(input.signer);
    return { kind, signer: input.signer, scopes };
  }
  check(Array.isArray(input.validators) && input.validators.length > 0 && input.validators.length <= 4096, "FINALITY_VALIDATORS_INVALID");
  const validators = [];
  for (const key of input.validators) {
    hex2(key);
    validators.push(key);
  }
  check(new Set(validators).size === validators.length && typeof input.threshold === "number" && Number.isSafeInteger(input.threshold) && input.threshold > 0 && input.threshold <= validators.length, "FINALITY_VALIDATORS_INVALID");
  return { kind, validators, threshold: input.threshold, scopes };
}
function validateDescriptor(value) {
  exactRecord(value, ["applicationId", "rootPrincipal", "authorityPublicKey", "executionManifestDigest", "finalityPolicy"], "AUTHORITY_DESCRIPTOR_FIELDS_INVALID");
  hex2(value.applicationId);
  hex2(value.rootPrincipal);
  hex2(value.authorityPublicKey);
  hex2(value.executionManifestDigest);
  validateFinalityPolicy(value.finalityPolicy);
}
async function signAppDescriptor(descriptor, signer) {
  validateDescriptor(descriptor);
  check(signer.publicKey === descriptor.authorityPublicKey, "AUTHORITY_SIGNER_MISMATCH");
  return signRecord("descriptor", descriptor, signer);
}
async function signMembership(membership, signer) {
  return signRecord("membership", membership, signer);
}
function validateAdmissionPolicy(input) {
  exactRecord(input, ["mode", "hostKey", "accounts", "grant"], "ADMISSION_POLICY_INVALID");
  check(input.mode === "attested" || input.mode === "strict", "ADMISSION_POLICY_INVALID");
  hex2(input.hostKey);
  check(Array.isArray(input.accounts) && input.accounts.length <= 64 && input.accounts.every((value) => typeof value === "string" && value.length > 0 && value.length <= 320) && new Set(input.accounts).size === input.accounts.length, "ADMISSION_POLICY_INVALID");
  exactRecord(input.grant, ["reader", "writer", "administrator"], "ADMISSION_POLICY_INVALID");
  check(typeof input.grant.reader === "boolean" && typeof input.grant.writer === "boolean" && typeof input.grant.administrator === "boolean", "ADMISSION_POLICY_INVALID");
  return { mode: input.mode, hostKey: input.hostKey, accounts: [...input.accounts], grant: { reader: input.grant.reader, writer: input.grant.writer, administrator: input.grant.administrator } };
}
function validateInvites(input) {
  check(Array.isArray(input) && input.length <= 256, "INVITE_INVALID");
  const ids = /* @__PURE__ */ new Set();
  for (const invite of input) {
    exactRecord(invite, ["inviteId", "role", "binding", "expiresAt", "secretDigest", "revoked"], "INVITE_INVALID");
    hex2(invite.inviteId, 16);
    hex2(invite.secretDigest);
    check(!ids.has(invite.inviteId) && ["reader", "writer", "admin"].includes(invite.role) && typeof invite.expiresAt === "bigint" && invite.expiresAt > 0n && typeof invite.revoked === "boolean", "INVITE_INVALID");
    ids.add(invite.inviteId);
    const binding = invite.binding;
    check(binding !== null && typeof binding === "object", "INVITE_INVALID");
    if (binding.kind === "email") {
      exactRecord(binding, ["kind", "email"], "INVITE_INVALID");
      check(typeof binding.email === "string" && binding.email.length <= 254 && /^[^\s@]+@[^\s@]+$/u.test(binding.email) && binding.email === binding.email.toLowerCase(), "INVITE_INVALID");
    } else if (binding.kind === "open") exactRecord(binding, ["kind"], "INVITE_INVALID");
    else {
      check(binding.kind === "public", "INVITE_INVALID");
      exactRecord(binding, ["kind", "max"], "INVITE_INVALID");
      check(binding.max === null || typeof binding.max === "number" && Number.isSafeInteger(binding.max) && binding.max > 0 && binding.max <= 1e5, "INVITE_INVALID");
    }
  }
  return input;
}
function inviteRedemptions(memberships, inviteId) {
  return memberships.reduce((total, item) => total + item.payload.admitted.filter((admission) => admission.via === "invited" && admission.attestation.payload.inviteId === inviteId).length, 0);
}
function inviteAdmits(invite, attestation, activation) {
  return invite !== void 0 && !invite.revoked && activation < invite.expiresAt && (invite.binding.kind !== "email" || attestation.email === invite.binding.email);
}
function inviteCapacity(invite) {
  return invite.binding.kind === "public" ? invite.binding.max ?? Number.MAX_SAFE_INTEGER : 1;
}
async function signHostAttestation(value, host) {
  validateAttestation(value);
  return signRecord("host-attestation", value, host);
}
function validateAttestation(value) {
  exactRecord(value, ["subject", "pageId", "applicationId", "accountId", "email", "publicKey", "wrapKey", "label", "inviteId", "issuedAt", "expiresAt", "nonce"], "ATTESTATION_INVALID");
  check(value.inviteId === null || typeof value.inviteId === "string" && /^[0-9a-f]{32}$/u.test(value.inviteId), "ATTESTATION_INVALID");
  check((value.subject === "device" || value.subject === "agent") && typeof value.pageId === "string" && /^[a-z2-7]{1,64}$/u.test(value.pageId) && typeof value.accountId === "string" && value.accountId.length > 0 && value.accountId.length <= 128 && (value.email === null || typeof value.email === "string" && value.email.length <= 254 && value.email === value.email.toLowerCase()) && typeof value.label === "string" && value.label.length <= 128 && typeof value.issuedAt === "bigint" && typeof value.expiresAt === "bigint" && value.issuedAt >= 0n && value.expiresAt > value.issuedAt && value.expiresAt - value.issuedAt <= 86400000n, "ATTESTATION_INVALID");
  hex2(value.applicationId);
  hex2(value.publicKey);
  hex2(value.wrapKey);
  hex2(value.nonce);
}
async function verifyHostAttestation(value, expected) {
  validateAttestation(value.payload);
  await verifyRecord("host-attestation", value, expected.hostKey);
  check(value.payload.applicationId === expected.applicationId && (expected.pageId === void 0 || value.payload.pageId === expected.pageId), "ATTESTATION_SCOPE_MISMATCH");
  return value.payload;
}
function attestedAccountAuthorized(policy, attestation) {
  return policy.accounts.includes(attestation.accountId) || attestation.email !== null && policy.accounts.includes(`email:${attestation.email}`);
}
function attestedGrant(policy, attestation) {
  return { reader: policy.grant.reader, writer: policy.grant.writer, administrator: attestation.subject === "device" && policy.grant.administrator };
}
function sameGrant(a, b) {
  return a.publicKey === b.publicKey && a.wrapKey === b.wrapKey && a.reader === b.reader && a.writer === b.writer && a.administrator === b.administrator && a.publisher === b.publisher && a.finalizer === b.finalizer;
}
async function verifyAuthorityBundle(input, pinned) {
  const bundle = structuredClone(input), descriptor = bundle.descriptor.payload;
  validateDescriptor(descriptor);
  await verifyRecord("descriptor", bundle.descriptor, descriptor.authorityPublicKey);
  check(pinned === void 0 || equalRecord(pinned, bundle.descriptor), "AUTHORITY_DESCRIPTOR_MISMATCH");
  check(bundle.memberships.length > 0 && bundle.memberships.length <= 4096, "AUTHORITY_MEMBERSHIP_LIMIT");
  let previous = null;
  const nonces = /* @__PURE__ */ new Set();
  for (const [revision, signed] of bundle.memberships.entries()) {
    const value = signed.payload, prior = revision === 0 ? null : bundle.memberships[revision - 1].payload;
    exactRecord(value, ["applicationId", "revision", "authorTimeAfterMs", "previous", "members", "epoch", "epochKeyDigest", "admission", "admitted", "invites"], "AUTHORITY_CHAIN_INVALID");
    check(value.applicationId === descriptor.applicationId && value.revision === revision && value.previous === previous && Number.isSafeInteger(value.epoch) && value.epoch >= 0, "AUTHORITY_CHAIN_INVALID");
    hex2(value.epochKeyDigest);
    validateAdmissionPolicy(value.admission);
    validateInvites(value.invites);
    const priorEpoch = bundle.memberships.slice(0, revision).find((item) => item.payload.epoch === value.epoch);
    check(priorEpoch === void 0 || priorEpoch.payload.epochKeyDigest === value.epochKeyDigest, "AUTHORITY_EPOCH_COMMITMENT_CHANGED");
    check(typeof value.authorTimeAfterMs === "bigint" && (prior === null ? value.authorTimeAfterMs === -1n : value.authorTimeAfterMs > prior.authorTimeAfterMs), "AUTHORITY_ACTIVATION_INVALID");
    check(isList3(value.members) && value.members.length <= 4096 && new Set(value.members.map((member) => member.publicKey)).size === value.members.length, "AUTHORITY_MEMBERS_INVALID");
    for (const member of value.members) {
      exactRecord(member, ["publicKey", "wrapKey", "reader", "writer", "administrator", "publisher", "finalizer"], "AUTHORITY_MEMBERS_INVALID");
      hex2(member.publicKey);
      if (member.wrapKey !== null) hex2(member.wrapKey);
      for (const flag of [member.reader, member.writer, member.publisher, member.administrator, member.finalizer]) check(typeof flag === "boolean", "AUTHORITY_MEMBERS_INVALID");
    }
    if (prior === null) check(value.members.some((member) => member.publicKey === descriptor.rootPrincipal) && isList3(value.admitted) && value.admitted.length === 0, "AUTHORITY_ROOT_MISSING");
    check(isList3(value.admitted) && value.admitted.length <= 64, "AUTHORITY_ADMISSION_INVALID");
    const policy = prior?.admission ?? value.admission, added = /* @__PURE__ */ new Set();
    for (const admission of value.admitted) {
      exactRecord(admission, ["publicKey", "via", "attestation"], "AUTHORITY_ADMISSION_INVALID");
      check(admission.via === "attested" || admission.via === "invited" || admission.via === "approved", "AUTHORITY_ADMISSION_INVALID");
      const attestation = await verifyHostAttestation(admission.attestation, { hostKey: policy.hostKey, applicationId: descriptor.applicationId });
      const member = value.members.find((item) => item.publicKey === admission.publicKey);
      check(attestation.publicKey === admission.publicKey && member !== void 0 && member.wrapKey === attestation.wrapKey && !added.has(admission.publicKey) && !prior?.members.some((item) => item.publicKey === admission.publicKey), "AUTHORITY_ADMISSION_INVALID");
      check(attestation.issuedAt <= value.authorTimeAfterMs && value.authorTimeAfterMs < attestation.expiresAt, "AUTHORITY_ADMISSION_EXPIRED");
      check(!nonces.has(attestation.nonce), "AUTHORITY_ADMISSION_REPLAYED");
      nonces.add(attestation.nonce);
      added.add(admission.publicKey);
      if (admission.via === "attested") check(attestation.inviteId === null && attestedAccountAuthorized(policy, attestation), "AUTHORITY_ADMISSION_ACCOUNT_FORBIDDEN");
      if (admission.via === "invited") check(attestation.inviteId !== null && inviteAdmits(prior?.invites.find((item) => item.inviteId === attestation.inviteId), attestation, value.authorTimeAfterMs), "AUTHORITY_INVITE_INVALID");
    }
    if (prior !== null && signed.signer !== descriptor.authorityPublicKey && !prior.members.some((member) => member.publicKey === signed.signer && member.administrator)) {
      const grantFor = (item) => {
        if (item.via === "attested") return attestedGrant(prior.admission, item.attestation.payload);
        const invite = prior.invites.find((entry) => entry.inviteId === item.attestation.payload.inviteId);
        check(inviteRedemptions(bundle.memberships.slice(0, revision + 1), invite.inviteId) <= inviteCapacity(invite), "AUTHORITY_INVITE_EXHAUSTED");
        return inviteGrant(invite.role);
      };
      const everMember = new Set(bundle.memberships.slice(0, revision).flatMap((item) => item.payload.members.map((member) => member.publicKey)));
      check(prior.members.some((member) => member.publicKey === signed.signer && member.reader) && prior.admission.mode === "attested" && value.admitted.length > 0 && value.admitted.every((item) => item.via !== "approved" && !everMember.has(item.publicKey)) && value.epoch === prior.epoch && equalRecord(value.admission, prior.admission) && equalRecord(value.invites, prior.invites) && value.members.length === prior.members.length + value.admitted.length && prior.members.every((member, index) => sameGrant(member, value.members[index])) && value.admitted.every((item, index) => sameGrant(value.members[prior.members.length + index], { publicKey: item.publicKey, wrapKey: item.attestation.payload.wrapKey, ...grantFor(item), publisher: false, finalizer: false })), "AUTHORITY_ADMIN_REQUIRED");
    }
    await verifyRecord("membership", signed);
    previous = await recordDigest(signed);
  }
}
function writerAuthorizedAt(authority, publicKey, membershipId, authorTimestampMs, throughRevision = Number.MAX_SAFE_INTEGER) {
  const base = authority.membership(membershipId);
  if (base === null) return null;
  if (authorTimestampMs <= base.authorTimeAfterMs || base.members.find((member) => member.publicKey === publicKey)?.writer !== true) return false;
  for (const successor of authority.bundle().memberships.slice(base.revision + 1)) {
    if (successor.payload.revision > throughRevision || authorTimestampMs <= successor.payload.authorTimeAfterMs) break;
    if (successor.payload.members.find((member) => member.publicKey === publicKey)?.writer !== true) return false;
  }
  return true;
}
function finalizerAuthorizedAt(authority, publicKey, authorityHead, throughMs) {
  const head = authority.membership(authorityHead);
  if (head === null) return null;
  if (head.members.find((member) => member.publicKey === publicKey)?.finalizer !== true) return false;
  for (const successor of authority.bundle().memberships.slice(head.revision + 1)) {
    if (throughMs <= successor.payload.authorTimeAfterMs) break;
    if (successor.payload.members.find((member) => member.publicKey === publicKey)?.finalizer !== true) return false;
  }
  return true;
}
async function epochKeyCommitment(applicationId, epoch, key) {
  hex2(applicationId);
  check(Number.isSafeInteger(epoch) && epoch >= 0 && key.length === 32, "AUTHORITY_EPOCH_KEY_INVALID");
  return recordDigest(["epoch-key", applicationId, epoch, key]);
}
var owners = /* @__PURE__ */ new WeakSet();
async function createAuthorityProvider(options) {
  check(!owners.has(options.store), "AUTHORITY_STORE_BUSY");
  owners.add(options.store);
  try {
    const applicationId = options.bundle?.descriptor.payload.applicationId ?? options.applicationId;
    hex2(applicationId);
    const key = `authority/${applicationId}`, cached = await options.store.get(key);
    let bundle = cached === null ? options.bundle : decodeRecord(cached);
    check(bundle !== void 0, "AUTHORITY_CACHE_MISSING");
    await verifyAuthorityBundle(bundle);
    if (options.bundle !== void 0 && cached !== null) {
      await verifyAuthorityBundle(options.bundle, bundle.descriptor);
      for (let i = 0; i < Math.min(bundle.memberships.length, options.bundle.memberships.length); i++) check(equalRecord(bundle.memberships[i], options.bundle.memberships[i]), "AUTHORITY_CHAIN_FORK");
      if (options.bundle.memberships.length > bundle.memberships.length) bundle = structuredClone(options.bundle);
    }
    await options.store.put(key, encodeRecord(bundle));
    const keys = /* @__PURE__ */ new Map(), listeners = /* @__PURE__ */ new Set();
    const keyBytes = await options.store.get(`${key}/epoch-keys`);
    if (keyBytes !== null) for (const [epoch, bytes2] of decodeRecord(keyBytes)) keys.set(epoch, bytes2);
    const validateKey = async (epoch, bytes2) => {
      check(bytes2 instanceof Uint8Array && bytes2.length === 32 && Number.isSafeInteger(epoch) && epoch >= 0, "AUTHORITY_EPOCH_KEY_INVALID");
      const membership = bundle.memberships.find((item) => item.payload.epoch === epoch);
      check(membership !== void 0 && membership.payload.epochKeyDigest === await epochKeyCommitment(applicationId, epoch, bytes2), "AUTHORITY_EPOCH_KEY_COMMITMENT_MISMATCH");
    };
    for (const [epoch, bytes2] of keys) await validateKey(epoch, bytes2);
    const persistKeys = async () => {
      await options.store.put(`${key}/epoch-keys`, encodeRecord([...keys]));
    };
    for (const [epoch, bytes2] of options.epochKeys ?? []) {
      await validateKey(epoch, bytes2);
      check(!keys.has(epoch) || equalRecord(keys.get(epoch), bytes2), "AUTHORITY_EPOCH_KEY_CONFLICT");
      keys.set(epoch, bytes2.slice());
    }
    if (options.epochKeys !== void 0) await persistKeys();
    const ids = /* @__PURE__ */ new Map();
    const index = async () => {
      ids.clear();
      for (const signed of bundle.memberships) ids.set(await recordDigest(signed), signed.payload);
    };
    await index();
    if (cached === null) await options.store.put(key, encodeRecord(bundle));
    let tail = Promise.resolve();
    const provider = {
      get descriptor() {
        return structuredClone(bundle.descriptor.payload);
      },
      descriptorId: await recordDigest(bundle.descriptor),
      get currentMembershipId() {
        return [...ids.keys()].at(-1);
      },
      get currentMembership() {
        return structuredClone(bundle.memberships.at(-1).payload);
      },
      bundle: () => structuredClone(bundle),
      grant: (publicKey, id2) => structuredClone((id2 === void 0 ? bundle.memberships.at(-1).payload : ids.get(id2))?.members.find((member) => member.publicKey === publicKey) ?? null),
      hasMembership: (id2) => ids.has(id2),
      membership: (id2) => structuredClone(ids.get(id2) ?? null),
      epochKey: (epoch) => keys.get(epoch)?.slice() ?? null,
      installEpochKey(epoch, input) {
        const bytes2 = input.slice();
        const task = tail.then(async () => {
          await validateKey(epoch, bytes2);
          check(!keys.has(epoch) || equalRecord(keys.get(epoch), bytes2), "AUTHORITY_EPOCH_KEY_CONFLICT");
          const next = new Map(keys);
          next.set(epoch, bytes2);
          await options.store.put(`${key}/epoch-keys`, encodeRecord([...next]));
          keys.set(epoch, bytes2);
          for (const listener of listeners) {
            try {
              listener();
            } catch {
            }
          }
        });
        tail = task.catch(() => void 0);
        return task;
      },
      merge(input) {
        const captured = structuredClone(input);
        const task = tail.then(async () => {
          await verifyAuthorityBundle(captured, bundle.descriptor);
          for (let i = 0; i < Math.min(captured.memberships.length, bundle.memberships.length); i++) check(equalRecord(captured.memberships[i], bundle.memberships[i]), "AUTHORITY_CHAIN_FORK");
          if (captured.memberships.length <= bundle.memberships.length) return;
          await options.store.put(key, encodeRecord(captured));
          bundle = captured;
          await index();
          for (const listener of listeners) {
            try {
              listener();
            } catch {
            }
          }
        });
        tail = task.catch(() => void 0);
        return task;
      },
      subscribe(listener) {
        listeners.add(listener);
        return () => {
          listeners.delete(listener);
        };
      }
    };
    if (options.bundle !== void 0 && cached !== null) await provider.merge(options.bundle);
    return provider;
  } finally {
    owners.delete(options.store);
  }
}
function validateEnrollment(request) {
  exactRecord(request, ["applicationId", "publicKey", "wrapKey", "challenge"], "ENROLLMENT_REQUEST_INVALID");
  hex2(request.applicationId);
  hex2(request.publicKey);
  hex2(request.wrapKey);
  check(typeof request.challenge === "string" && request.challenge.length > 0 && request.challenge.length <= 512, "ENROLLMENT_REQUEST_INVALID");
}
async function signEnrollmentRequest(request, identity) {
  validateEnrollment(request);
  check(request.publicKey === identity.publicKey, "ENROLLMENT_REQUEST_INVALID");
  return signRecord("enrollment", request, identity);
}
async function verifyEnrollmentRequest(request) {
  validateEnrollment(request.payload);
  await verifyRecord("enrollment", request, request.payload.publicKey);
}
export {
  applicationDescriptionDigest,
  attestedAccountAuthorized,
  attestedGrant,
  checkedApplicationInputSchema,
  createAuthorityProvider,
  epochKeyCommitment,
  finalizerAuthorizedAt,
  inviteAdmits,
  inviteCapacity,
  inviteGrant,
  inviteRedemptions,
  parseApplicationInput,
  signAppDescriptor,
  signEnrollmentRequest,
  signHostAttestation,
  signMembership,
  validateAdmissionPolicy,
  validateApplicationDescription,
  validateDescriptor,
  validateFinalityPolicy,
  validateInvites,
  verifyAuthorityBundle,
  verifyEnrollmentRequest,
  verifyHostAttestation,
  writerAuthorizedAt
};
