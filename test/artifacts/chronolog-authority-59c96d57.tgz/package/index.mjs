var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name2 in all)
    __defProp(target, name2, { get: all[name2], enumerable: true });
};

// packages/canonical/src/errors.ts
function canonicalInvariant(condition, code, message, details) {
  if (!condition) throw new CanonicalError(code, message, details);
}
var CanonicalError;
var init_errors = __esm({
  "packages/canonical/src/errors.ts"() {
    "use strict";
    CanonicalError = class extends Error {
      constructor(code, message, details) {
        super(message);
        this.code = code;
        this.details = details;
        this.name = "CanonicalError";
      }
      code;
      details;
    };
  }
});

// packages/canonical/src/bytes.ts
function utf8(value) {
  const encoded = textEncoder.encode(value);
  try {
    if (fatalTextDecoder.decode(encoded) !== value) throw new CanonicalError("INVALID_UTF8", "Text contains an unpaired UTF-16 surrogate");
  } catch (error) {
    if (error instanceof CanonicalError) throw error;
    throw new CanonicalError("INVALID_UTF8", "Text cannot be represented as canonical UTF-8");
  }
  return encoded;
}
function decodeUtf8(value) {
  try {
    return fatalTextDecoder.decode(value);
  } catch {
    throw new CanonicalError("INVALID_UTF8", "Bytes are not valid UTF-8");
  }
}
function concatBytes(...parts) {
  const size = parts.reduce((sum, part) => sum + part.length, 0);
  const result = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}
function compareBytes(left, right) {
  const size = Math.min(left.length, right.length);
  for (let index = 0; index < size; index += 1) {
    const difference = left[index] - right[index];
    if (difference !== 0) return difference < 0 ? -1 : 1;
  }
  return left.length === right.length ? 0 : left.length < right.length ? -1 : 1;
}
function equalBytes(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}
function bytesToHex(value) {
  let result = "";
  for (const byte of value) result += hexPairs[byte];
  return result;
}
function hexToBytes(value) {
  if (!/^(?:[0-9a-fA-F]{2})*$/u.test(value)) throw new CanonicalError("SCHEMA_INVALID", "Hex text is malformed");
  return Uint8Array.from({ length: value.length / 2 }, (_unused, index) => Number.parseInt(value.slice(index * 2, index * 2 + 2), 16));
}
function copyBytes(value) {
  return Uint8Array.from(value);
}
var textEncoder, fatalTextDecoder, hexPairs;
var init_bytes = __esm({
  "packages/canonical/src/bytes.ts"() {
    "use strict";
    init_errors();
    textEncoder = new TextEncoder();
    fatalTextDecoder = new TextDecoder("utf-8", { fatal: true });
    hexPairs = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, "0"));
  }
});

// packages/canonical/src/cbor.ts
function encodeHead(major, value) {
  canonicalInvariant(value >= 0n && value <= MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR integer is outside uint64 range");
  if (value < 24n) return Uint8Array.of(major << 5 | Number(value));
  if (value <= 0xffn) return Uint8Array.of(major << 5 | 24, Number(value));
  if (value <= 0xffffn) return Uint8Array.of(major << 5 | 25, Number(value >> 8n), Number(value & 0xffn));
  if (value <= 0xffffffffn) {
    const bytes3 = new Uint8Array(5);
    bytes3[0] = major << 5 | 26;
    new DataView(bytes3.buffer).setUint32(1, Number(value), false);
    return bytes3;
  }
  const bytes2 = new Uint8Array(9);
  bytes2[0] = major << 5 | 27;
  new DataView(bytes2.buffer).setBigUint64(1, value, false);
  return bytes2;
}
function magnitudeBytes(value) {
  canonicalInvariant(value > MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR bignum must exceed uint64 range");
  const octets = [];
  for (let remaining = value; remaining > 0n; remaining >>= 8n) octets.push(Number(remaining & 0xffn));
  octets.reverse();
  return Uint8Array.from(octets);
}
function encodeBigint(value) {
  const negative = value < 0n;
  const magnitude = negative ? -1n - value : value;
  if (magnitude <= MAX_UINT64) return encodeHead(negative ? 1 : 0, magnitude);
  const bytes2 = magnitudeBytes(magnitude);
  return concatBytes(
    encodeHead(6, negative ? NEGATIVE_BIGNUM_TAG : POSITIVE_BIGNUM_TAG),
    encodeHead(2, BigInt(bytes2.length)),
    bytes2
  );
}
function isMap(value) {
  return value instanceof Map;
}
function encodeCanonicalCbor(value) {
  if (value === null) return Uint8Array.of(246);
  if (value === false) return Uint8Array.of(244);
  if (value === true) return Uint8Array.of(245);
  if (typeof value === "bigint") return encodeBigint(value);
  if (typeof value === "string") {
    const bytes2 = utf8(value);
    return concatBytes(encodeHead(3, BigInt(bytes2.length)), bytes2);
  }
  if (value instanceof Uint8Array) return concatBytes(encodeHead(2, BigInt(value.length)), value);
  if (Array.isArray(value)) return concatBytes(encodeHead(4, BigInt(value.length)), ...value.map(encodeCanonicalCbor));
  if (isMap(value)) {
    const entries = [...value].map(([key, item]) => ({ key: encodeCanonicalCbor(key), value: encodeCanonicalCbor(item) })).sort((a, b) => a.key.length === b.key.length ? compareBytes(a.key, b.key) : a.key.length - b.key.length);
    for (let index = 1; index < entries.length; index += 1) canonicalInvariant(!equalBytes(entries[index - 1].key, entries[index].key), "CBOR_NON_CANONICAL", "Duplicate canonical CBOR map key");
    return concatBytes(encodeHead(5, BigInt(entries.length)), ...entries.flatMap((entry) => [entry.key, entry.value]));
  }
  throw new CanonicalError("SCHEMA_INVALID", "Value is not supported by the deterministic CBOR profile");
}
function decodeCanonicalCbor(input, limits) {
  return new Decoder(input, limits).decode();
}
function assertCanonicalCbor(input, limits) {
  const value = decodeCanonicalCbor(input, limits);
  canonicalInvariant(equalBytes(encodeCanonicalCbor(value), input), "CBOR_NON_CANONICAL", "CBOR bytes are not canonical");
  return value;
}
var DEFAULT_DECODE_LIMITS, MAX_UINT64, POSITIVE_BIGNUM_TAG, NEGATIVE_BIGNUM_TAG, Decoder;
var init_cbor = __esm({
  "packages/canonical/src/cbor.ts"() {
    "use strict";
    init_bytes();
    init_errors();
    DEFAULT_DECODE_LIMITS = Object.freeze({
      maxBytes: 16 * 1024 * 1024,
      maxDepth: 64,
      maxArrayItems: 1e6,
      maxMapItems: 1e5,
      maxTextBytes: 4 * 1024 * 1024,
      maxBlobBytes: 16 * 1024 * 1024
    });
    MAX_UINT64 = (1n << 64n) - 1n;
    POSITIVE_BIGNUM_TAG = 2n;
    NEGATIVE_BIGNUM_TAG = 3n;
    Decoder = class {
      constructor(input, limits) {
        this.input = input;
        this.limits = limits;
        canonicalInvariant(input.length <= limits.maxBytes, "CBOR_LIMIT_EXCEEDED", "CBOR input exceeds byte limit");
      }
      input;
      limits;
      offset = 0;
      decode() {
        const value = this.value(0);
        canonicalInvariant(this.offset === this.input.length, "CBOR_INVALID", "Trailing bytes after CBOR value");
        return value;
      }
      byte() {
        canonicalInvariant(this.offset < this.input.length, "CBOR_INVALID", "Unexpected end of CBOR input");
        return this.input[this.offset++];
      }
      bytes(size) {
        canonicalInvariant(Number.isSafeInteger(size) && size >= 0 && this.offset + size <= this.input.length, "CBOR_INVALID", "Invalid or truncated CBOR byte range");
        const value = this.input.slice(this.offset, this.offset + size);
        this.offset += size;
        return value;
      }
      argument(additional) {
        if (additional < 24) return BigInt(additional);
        const read = (size) => {
          const bytes2 = this.bytes(size);
          const view = new DataView(bytes2.buffer, bytes2.byteOffset, size);
          return size === 1 ? BigInt(bytes2[0]) : size === 2 ? BigInt(view.getUint16(0, false)) : size === 4 ? BigInt(view.getUint32(0, false)) : view.getBigUint64(0, false);
        };
        if (additional === 24) {
          const v = read(1);
          canonicalInvariant(v >= 24n, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
          return v;
        }
        if (additional === 25) {
          const v = read(2);
          canonicalInvariant(v > 0xffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
          return v;
        }
        if (additional === 26) {
          const v = read(4);
          canonicalInvariant(v > 0xffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
          return v;
        }
        if (additional === 27) {
          const v = read(8);
          canonicalInvariant(v > 0xffffffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
          return v;
        }
        if (additional === 31) throw new CanonicalError("CBOR_NON_CANONICAL", "Indefinite-length CBOR is prohibited");
        throw new CanonicalError("CBOR_INVALID", "Reserved CBOR additional information");
      }
      bignum(tag, depth) {
        canonicalInvariant(tag === POSITIVE_BIGNUM_TAG || tag === NEGATIVE_BIGNUM_TAG, "CBOR_INVALID", "Unsupported CBOR tag");
        canonicalInvariant(depth < this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
        const initial = this.byte(), major = initial >> 5, additional = initial & 31;
        canonicalInvariant(major === 2, "CBOR_INVALID", "CBOR bignum payload must be a byte string");
        const argument = this.argument(additional);
        canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR bignum is too large");
        const size = Number(argument);
        canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR bignum exceeds blob limit");
        const bytes2 = this.bytes(size);
        canonicalInvariant(bytes2.length > 8 && bytes2[0] !== 0, "CBOR_NON_CANONICAL", "CBOR bignum is not minimally encoded");
        let magnitude = 0n;
        for (const byte of bytes2) magnitude = magnitude << 8n | BigInt(byte);
        canonicalInvariant(magnitude > MAX_UINT64, "CBOR_NON_CANONICAL", "CBOR bignum must use the ordinary integer representation");
        return tag === POSITIVE_BIGNUM_TAG ? magnitude : -1n - magnitude;
      }
      value(depth) {
        canonicalInvariant(depth <= this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
        const initial = this.byte(), major = initial >> 5, additional = initial & 31;
        if (major === 7) {
          if (additional === 20) return false;
          if (additional === 21) return true;
          if (additional === 22) return null;
          throw new CanonicalError("CBOR_INVALID", "Floating point and unsupported simple CBOR values are prohibited");
        }
        const argument = this.argument(additional);
        if (major === 6) return this.bignum(argument, depth + 1);
        if (major === 0) return argument;
        if (major === 1) return -1n - argument;
        canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR collection is too large");
        const size = Number(argument);
        if (major === 2) {
          canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR blob exceeds limit");
          return this.bytes(size);
        }
        if (major === 3) {
          canonicalInvariant(size <= this.limits.maxTextBytes, "CBOR_LIMIT_EXCEEDED", "CBOR text exceeds limit");
          return decodeUtf8(this.bytes(size));
        }
        if (major === 4) {
          canonicalInvariant(size <= this.limits.maxArrayItems, "CBOR_LIMIT_EXCEEDED", "CBOR array exceeds item limit");
          return Array.from({ length: size }, () => this.value(depth + 1));
        }
        if (major === 5) {
          canonicalInvariant(size <= this.limits.maxMapItems, "CBOR_LIMIT_EXCEEDED", "CBOR map exceeds item limit");
          const map = /* @__PURE__ */ new Map();
          let previous;
          for (let index = 0; index < size; index += 1) {
            const start = this.offset, key = this.value(depth + 1);
            canonicalInvariant(typeof key === "bigint" || typeof key === "string" || key instanceof Uint8Array, "CBOR_INVALID", "Unsupported CBOR map key");
            const encoded = this.input.slice(start, this.offset);
            if (previous !== void 0) canonicalInvariant(previous.length === encoded.length ? compareBytes(previous, encoded) < 0 : previous.length < encoded.length, "CBOR_NON_CANONICAL", "CBOR map keys are duplicate or incorrectly ordered");
            previous = encoded;
            map.set(key, this.value(depth + 1));
          }
          return map;
        }
        throw new CanonicalError("CBOR_INVALID", `Unsupported CBOR major type ${major}`);
      }
    };
  }
});

// packages/canonical/src/hash.ts
function bufferSource(value) {
  return Uint8Array.from(value).buffer;
}
function domainSeparatedBytes(domain, payload) {
  const name2 = utf8(HASH_DOMAINS[domain]);
  const size = new Uint8Array(4);
  new DataView(size.buffer).setUint32(0, name2.length, false);
  return concatBytes(size, name2, Uint8Array.of(0), payload);
}
async function sha256(payload) {
  return new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bufferSource(payload)));
}
async function hashDomain(domain, payload) {
  return sha256(domainSeparatedBytes(domain, payload));
}
var HASH_DOMAINS;
var init_hash = __esm({
  "packages/canonical/src/hash.ts"() {
    "use strict";
    init_bytes();
    HASH_DOMAINS = Object.freeze({
      transaction: "chronolog/transaction",
      schema: "chronolog/schema",
      executionManifest: "chronolog/execution-manifest",
      queryResult: "chronolog/query-result",
      expectation: "chronolog/expectation",
      module: "chronolog/module",
      entropy: "chronolog/entropy",
      platformObject: "chronolog/platform-object"
    });
  }
});

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/utils.js
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function abytes(b, ...lengths) {
  if (!isBytes(b))
    throw new Error("Uint8Array expected");
  if (lengths.length > 0 && !lengths.includes(b.length))
    throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
}
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput(out, instance) {
  abytes(out);
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error("digestInto() expects output buffer of length at least " + min);
  }
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word, shift) {
  return word << 32 - shift | word >>> shift;
}
function utf8ToBytes(str) {
  if (typeof str !== "string")
    throw new Error("string expected");
  return new Uint8Array(new TextEncoder().encode(str));
}
function toBytes(data) {
  if (typeof data === "string")
    data = utf8ToBytes(data);
  abytes(data);
  return data;
}
function createHasher(hashCons) {
  const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
  const tmp = hashCons();
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = () => hashCons();
  return hashC;
}
var Hash;
var init_utils = __esm({
  "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/utils.js"() {
    Hash = class {
    };
  }
});

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/_md.js
function setBigUint64(view, byteOffset, value, isLE) {
  if (typeof view.setBigUint64 === "function")
    return view.setBigUint64(byteOffset, value, isLE);
  const _32n = BigInt(32);
  const _u32_max = BigInt(4294967295);
  const wh = Number(value >> _32n & _u32_max);
  const wl = Number(value & _u32_max);
  const h = isLE ? 4 : 0;
  const l = isLE ? 0 : 4;
  view.setUint32(byteOffset + h, wh, isLE);
  view.setUint32(byteOffset + l, wl, isLE);
}
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD, SHA256_IV;
var init_md = __esm({
  "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/_md.js"() {
    init_utils();
    HashMD = class extends Hash {
      constructor(blockLen, outputLen, padOffset, isLE) {
        super();
        this.finished = false;
        this.length = 0;
        this.pos = 0;
        this.destroyed = false;
        this.blockLen = blockLen;
        this.outputLen = outputLen;
        this.padOffset = padOffset;
        this.isLE = isLE;
        this.buffer = new Uint8Array(blockLen);
        this.view = createView(this.buffer);
      }
      update(data) {
        aexists(this);
        data = toBytes(data);
        abytes(data);
        const { view, buffer, blockLen } = this;
        const len = data.length;
        for (let pos = 0; pos < len; ) {
          const take = Math.min(blockLen - this.pos, len - pos);
          if (take === blockLen) {
            const dataView = createView(data);
            for (; blockLen <= len - pos; pos += blockLen)
              this.process(dataView, pos);
            continue;
          }
          buffer.set(data.subarray(pos, pos + take), this.pos);
          this.pos += take;
          pos += take;
          if (this.pos === blockLen) {
            this.process(view, 0);
            this.pos = 0;
          }
        }
        this.length += data.length;
        this.roundClean();
        return this;
      }
      digestInto(out) {
        aexists(this);
        aoutput(out, this);
        this.finished = true;
        const { buffer, view, blockLen, isLE } = this;
        let { pos } = this;
        buffer[pos++] = 128;
        clean(this.buffer.subarray(pos));
        if (this.padOffset > blockLen - pos) {
          this.process(view, 0);
          pos = 0;
        }
        for (let i = pos; i < blockLen; i++)
          buffer[i] = 0;
        setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE);
        this.process(view, 0);
        const oview = createView(out);
        const len = this.outputLen;
        if (len % 4)
          throw new Error("_sha2: outputLen should be aligned to 32bit");
        const outLen = len / 4;
        const state = this.get();
        if (outLen > state.length)
          throw new Error("_sha2: outputLen bigger than state");
        for (let i = 0; i < outLen; i++)
          oview.setUint32(4 * i, state[i], isLE);
      }
      digest() {
        const { buffer, outputLen } = this;
        this.digestInto(buffer);
        const res = buffer.slice(0, outputLen);
        this.destroy();
        return res;
      }
      _cloneInto(to) {
        to || (to = new this.constructor());
        to.set(...this.get());
        const { blockLen, buffer, length, finished, destroyed, pos } = this;
        to.destroyed = destroyed;
        to.finished = finished;
        to.length = length;
        to.pos = pos;
        if (length % blockLen)
          to.buffer.set(buffer);
        return to;
      }
      clone() {
        return this._cloneInto();
      }
    };
    SHA256_IV = /* @__PURE__ */ Uint32Array.from([
      1779033703,
      3144134277,
      1013904242,
      2773480762,
      1359893119,
      2600822924,
      528734635,
      1541459225
    ]);
  }
});

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha2.js
var SHA256_K, SHA256_W, SHA256, sha2562;
var init_sha2 = __esm({
  "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha2.js"() {
    init_md();
    init_utils();
    SHA256_K = /* @__PURE__ */ Uint32Array.from([
      1116352408,
      1899447441,
      3049323471,
      3921009573,
      961987163,
      1508970993,
      2453635748,
      2870763221,
      3624381080,
      310598401,
      607225278,
      1426881987,
      1925078388,
      2162078206,
      2614888103,
      3248222580,
      3835390401,
      4022224774,
      264347078,
      604807628,
      770255983,
      1249150122,
      1555081692,
      1996064986,
      2554220882,
      2821834349,
      2952996808,
      3210313671,
      3336571891,
      3584528711,
      113926993,
      338241895,
      666307205,
      773529912,
      1294757372,
      1396182291,
      1695183700,
      1986661051,
      2177026350,
      2456956037,
      2730485921,
      2820302411,
      3259730800,
      3345764771,
      3516065817,
      3600352804,
      4094571909,
      275423344,
      430227734,
      506948616,
      659060556,
      883997877,
      958139571,
      1322822218,
      1537002063,
      1747873779,
      1955562222,
      2024104815,
      2227730452,
      2361852424,
      2428436474,
      2756734187,
      3204031479,
      3329325298
    ]);
    SHA256_W = /* @__PURE__ */ new Uint32Array(64);
    SHA256 = class extends HashMD {
      constructor(outputLen = 32) {
        super(64, outputLen, 8, false);
        this.A = SHA256_IV[0] | 0;
        this.B = SHA256_IV[1] | 0;
        this.C = SHA256_IV[2] | 0;
        this.D = SHA256_IV[3] | 0;
        this.E = SHA256_IV[4] | 0;
        this.F = SHA256_IV[5] | 0;
        this.G = SHA256_IV[6] | 0;
        this.H = SHA256_IV[7] | 0;
      }
      get() {
        const { A, B, C, D, E, F, G, H } = this;
        return [A, B, C, D, E, F, G, H];
      }
      // prettier-ignore
      set(A, B, C, D, E, F, G, H) {
        this.A = A | 0;
        this.B = B | 0;
        this.C = C | 0;
        this.D = D | 0;
        this.E = E | 0;
        this.F = F | 0;
        this.G = G | 0;
        this.H = H | 0;
      }
      process(view, offset) {
        for (let i = 0; i < 16; i++, offset += 4)
          SHA256_W[i] = view.getUint32(offset, false);
        for (let i = 16; i < 64; i++) {
          const W15 = SHA256_W[i - 15];
          const W2 = SHA256_W[i - 2];
          const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
          const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
          SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
        }
        let { A, B, C, D, E, F, G, H } = this;
        for (let i = 0; i < 64; i++) {
          const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
          const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
          const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
          const T2 = sigma0 + Maj(A, B, C) | 0;
          H = G;
          G = F;
          F = E;
          E = D + T1 | 0;
          D = C;
          C = B;
          B = A;
          A = T1 + T2 | 0;
        }
        A = A + this.A | 0;
        B = B + this.B | 0;
        C = C + this.C | 0;
        D = D + this.D | 0;
        E = E + this.E | 0;
        F = F + this.F | 0;
        G = G + this.G | 0;
        H = H + this.H | 0;
        this.set(A, B, C, D, E, F, G, H);
      }
      roundClean() {
        clean(SHA256_W);
      }
      destroy() {
        this.set(0, 0, 0, 0, 0, 0, 0, 0);
        clean(this.buffer);
      }
    };
    sha2562 = /* @__PURE__ */ createHasher(() => new SHA256());
  }
});

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha256.js
var sha2563;
var init_sha256 = __esm({
  "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha256.js"() {
    init_sha2();
    sha2563 = sha2562;
  }
});

// packages/canonical/src/sync-hash.ts
function sha256Sync(bytes2) {
  return sha2563(bytes2);
}
function createSha256() {
  const hash = sha2563.create();
  const writer = {
    update(bytes2) {
      hash.update(typeof bytes2 === "string" ? utf8(bytes2) : bytes2);
      return writer;
    },
    digest() {
      return hash.digest();
    }
  };
  return writer;
}
var init_sync_hash = __esm({
  "packages/canonical/src/sync-hash.ts"() {
    "use strict";
    init_sha256();
    init_bytes();
  }
});

// packages/canonical/src/schema.ts
function integerMap(entries) {
  const map = /* @__PURE__ */ new Map();
  for (const [key, value] of entries) if (value !== void 0) map.set(BigInt(key), value);
  return map;
}
function expectMap(value, name2) {
  canonicalInvariant(value instanceof Map, "SCHEMA_INVALID", `${name2} must be a map`);
  return value;
}
function expectArray(value, name2) {
  canonicalInvariant(Array.isArray(value), "SCHEMA_INVALID", `${name2} must be an array`);
  return value;
}
function expectBytes(value, name2, length) {
  canonicalInvariant(value instanceof Uint8Array, "SCHEMA_INVALID", `${name2} must be bytes`);
  if (length !== void 0) canonicalInvariant(value.length === length, "SCHEMA_INVALID", `${name2} must contain ${length} bytes`);
  return Uint8Array.from(value);
}
function expectString(value, name2) {
  canonicalInvariant(typeof value === "string", "SCHEMA_INVALID", `${name2} must be text`);
  return value;
}
function expectBoolean(value, name2) {
  canonicalInvariant(typeof value === "boolean", "SCHEMA_INVALID", `${name2} must be boolean`);
  return value;
}
function expectBigint(value, name2) {
  canonicalInvariant(typeof value === "bigint", "SCHEMA_INVALID", `${name2} must be integer`);
  return value;
}
function expectUint(value, name2, maximum = BigInt(Number.MAX_SAFE_INTEGER)) {
  const n = expectBigint(value, name2);
  canonicalInvariant(n >= 0n && n <= maximum && n <= BigInt(Number.MAX_SAFE_INTEGER), "INTEGER_OUT_OF_RANGE", `${name2} is outside range`);
  return Number(n);
}
function expectUint64(value, name2) {
  const n = expectBigint(value, name2);
  canonicalInvariant(n >= 0n && n <= (1n << 64n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside uint64`);
  return n;
}
function expectInt64(value, name2) {
  const n = expectBigint(value, name2);
  canonicalInvariant(n >= -(1n << 63n) && n <= (1n << 63n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside int64`);
  return n;
}
function required(map, key, name2) {
  const value = map.get(BigInt(key));
  if (value === void 0) throw new CanonicalError("SCHEMA_INVALID", `Missing required field ${name2}`);
  return value;
}
function optional(map, key) {
  return map.get(BigInt(key));
}
function assertKnownIntegerKeys(map, keys, name2) {
  const known = new Set(keys.map(BigInt));
  for (const key of map.keys()) canonicalInvariant(typeof key === "bigint" && known.has(key), "SCHEMA_INVALID", `${name2} contains an unknown field`);
}
var init_schema = __esm({
  "packages/canonical/src/schema.ts"() {
    "use strict";
    init_errors();
  }
});

// packages/canonical/src/index.ts
var src_exports = {};
__export(src_exports, {
  CanonicalError: () => CanonicalError,
  DEFAULT_DECODE_LIMITS: () => DEFAULT_DECODE_LIMITS,
  HASH_DOMAINS: () => HASH_DOMAINS,
  assertCanonicalCbor: () => assertCanonicalCbor,
  assertKnownIntegerKeys: () => assertKnownIntegerKeys,
  bytesToHex: () => bytesToHex,
  canonicalInvariant: () => canonicalInvariant,
  compareBytes: () => compareBytes,
  concatBytes: () => concatBytes,
  copyBytes: () => copyBytes,
  createSha256: () => createSha256,
  decodeCanonicalCbor: () => decodeCanonicalCbor,
  decodeUtf8: () => decodeUtf8,
  domainSeparatedBytes: () => domainSeparatedBytes,
  encodeCanonicalCbor: () => encodeCanonicalCbor,
  equalBytes: () => equalBytes,
  expectArray: () => expectArray,
  expectBigint: () => expectBigint,
  expectBoolean: () => expectBoolean,
  expectBytes: () => expectBytes,
  expectInt64: () => expectInt64,
  expectMap: () => expectMap,
  expectString: () => expectString,
  expectUint: () => expectUint,
  expectUint64: () => expectUint64,
  hashDomain: () => hashDomain,
  hexToBytes: () => hexToBytes,
  integerMap: () => integerMap,
  optional: () => optional,
  required: () => required,
  sha256: () => sha256,
  sha256Sync: () => sha256Sync,
  utf8: () => utf8
});
var init_src = __esm({
  "packages/canonical/src/index.ts"() {
    "use strict";
    init_bytes();
    init_cbor();
    init_errors();
    init_hash();
    init_sync_hash();
    init_schema();
  }
});

// packages/authority/src/codec.ts
init_src();

// packages/protocol/src/bytes.ts
init_src();

// packages/protocol/src/errors.ts
var ProtocolError = class extends Error {
  code;
  details;
  constructor(code, message, details) {
    super(message);
    this.name = "ProtocolError";
    this.code = code;
    this.details = details;
  }
  toJSON() {
    return this.details === void 0 ? { name: this.name, code: this.code, message: this.message } : { name: this.name, code: this.code, message: this.message, details: this.details };
  }
};
function protocolInvariant(condition, code, message, details) {
  if (!condition) throw new ProtocolError(code, message, details);
}

// packages/protocol/src/bytes.ts
function wrap(operation) {
  try {
    return operation();
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
    throw error;
  }
}
function utf82(value) {
  return wrap(() => utf8(value));
}
function bytesToHex2(value) {
  return bytesToHex(value);
}

// packages/protocol/src/cbor.ts
init_src();
function sharedLimits(limits) {
  return {
    maxBytes: limits.maxBytes ?? DEFAULT_DECODE_LIMITS.maxBytes,
    maxDepth: limits.maxDepth ?? DEFAULT_DECODE_LIMITS.maxDepth,
    maxArrayItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxArrayItems,
    maxMapItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxMapItems,
    maxTextBytes: limits.maxTextBytes ?? DEFAULT_DECODE_LIMITS.maxTextBytes,
    maxBlobBytes: limits.maxByteStringBytes ?? DEFAULT_DECODE_LIMITS.maxBlobBytes
  };
}
function protocolError(error) {
  if (error instanceof ProtocolError) throw error;
  if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
  throw error;
}
function assertCanonicalCbor2(input, limits = {}) {
  try {
    return assertCanonicalCbor(input, sharedLimits(limits));
  } catch (error) {
    return protocolError(error);
  }
}

// packages/protocol/src/messages.ts
init_src();

// packages/protocol/src/schema.ts
function integerMap2(entries) {
  const result = /* @__PURE__ */ new Map();
  for (const [key, value] of entries) {
    if (value !== void 0) result.set(BigInt(key), value);
  }
  return result;
}
function expectMap2(value, name2) {
  protocolInvariant(value instanceof Map, "SCHEMA_INVALID", `${name2} must be a CBOR map`);
  return value;
}
function expectArray2(value, name2) {
  protocolInvariant(Array.isArray(value), "SCHEMA_INVALID", `${name2} must be a CBOR array`);
  return value;
}
function expectBytes2(value, name2, length) {
  protocolInvariant(value instanceof Uint8Array, "SCHEMA_INVALID", `${name2} must be bytes`);
  if (length !== void 0) {
    protocolInvariant(value.length === length, "SCHEMA_INVALID", `${name2} must contain ${length} bytes`);
  }
  return value;
}
function expectString2(value, name2) {
  protocolInvariant(typeof value === "string", "SCHEMA_INVALID", `${name2} must be text`);
  return value;
}
function expectBigint2(value, name2) {
  protocolInvariant(typeof value === "bigint", "SCHEMA_INVALID", `${name2} must be an integer`);
  return value;
}
function expectUint642(value, name2) {
  const integer = expectBigint2(value, name2);
  protocolInvariant(integer >= 0n && integer <= (1n << 64n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside uint64 range`);
  return integer;
}
function expectInt642(value, name2) {
  const integer = expectBigint2(value, name2);
  protocolInvariant(integer >= -(1n << 63n) && integer <= (1n << 63n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside int64 range`);
  return integer;
}
function required2(map, key, name2) {
  const value = map.get(BigInt(key));
  if (value === void 0) throw new ProtocolError("SCHEMA_INVALID", `Missing required field ${name2}`, { field: name2 });
  return value;
}
function optional2(map, key) {
  return map.get(BigInt(key));
}
function assertKnownIntegerKeys2(map, knownKeys, name2) {
  const known = new Set(knownKeys.map(BigInt));
  for (const key of map.keys()) {
    protocolInvariant(typeof key === "bigint", "SCHEMA_INVALID", `${name2} contains a non-integer field key`);
    protocolInvariant(known.has(key), "SCHEMA_INVALID", `${name2} contains unknown critical field ${String(key)}`);
  }
}
function expectVersion(map, expected, name2) {
  const version2 = expectUint642(required2(map, 0, `${name2}.version`), `${name2}.version`);
  protocolInvariant(version2 === expected, "UNSUPPORTED_VERSION", `Unsupported ${name2} version`, { version: version2.toString() });
}

// packages/protocol/src/platform.ts
init_src();

// packages/protocol/src/sql.ts
init_src();
var MIN_INT64 = -(1n << 63n);
var MAX_INT64 = (1n << 63n) - 1n;
var sqlValue = Object.freeze({
  null: () => ({ kind: "null" }),
  integer: (value) => {
    const integer = typeof value === "bigint" ? value : BigInt(value);
    protocolInvariant(integer >= MIN_INT64 && integer <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
    return { kind: "integer", value: integer };
  },
  real: (value) => {
    protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "SQL REAL must be finite");
    return { kind: "real", value };
  },
  text: (value) => {
    utf82(value);
    return { kind: "text", value };
  },
  blob: (value) => ({ kind: "blob", value: Uint8Array.from(value) })
});
function toSqlValue(value) {
  if (value === null || value === void 0) return sqlValue.null();
  if (typeof value === "bigint") return sqlValue.integer(value);
  if (typeof value === "number") return Number.isSafeInteger(value) ? sqlValue.integer(value) : sqlValue.real(value);
  if (typeof value === "boolean") return sqlValue.integer(value ? 1n : 0n);
  if (typeof value === "string") return sqlValue.text(value);
  if (value instanceof Uint8Array) return sqlValue.blob(value);
  if (isSqlValue(value)) return value;
  throw new TypeError("SQL values must be null, boolean, bigint, number, string, Uint8Array or a tagged SqlValue");
}
function isSqlValue(value) {
  if (typeof value !== "object" || value === null || !("kind" in value)) return false;
  const tagged = value;
  switch (tagged.kind) {
    case "null":
      return true;
    case "integer":
      return typeof tagged.value === "bigint";
    case "real":
      return typeof tagged.value === "number";
    case "text":
      return typeof tagged.value === "string";
    case "blob":
      return tagged.value instanceof Uint8Array;
    default:
      return false;
  }
}
function realBits(value) {
  const bits = new Uint8Array(8);
  new DataView(bits.buffer).setFloat64(0, value, false);
  return bits;
}
function sqlValueToCanonicalCbor(value) {
  switch (value.kind) {
    case "null":
      return [0n];
    case "integer":
      protocolInvariant(value.value >= MIN_INT64 && value.value <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
      return [1n, value.value];
    case "real":
      protocolInvariant(Number.isFinite(value.value), "SCHEMA_INVALID", "SQL REAL must be finite");
      return [2n, realBits(value.value)];
    case "text":
      utf82(value.value);
      return [3n, value.value];
    case "blob":
      return [4n, Uint8Array.from(value.value)];
  }
}
function sqlValueFromCanonicalCbor(value, name2 = "sql_value") {
  const tuple = expectArray2(value, name2);
  const kind = expectUint642(tuple[0] ?? null, `${name2}.kind`);
  protocolInvariant(tuple.length === (kind === 0n ? 1 : 2), "SCHEMA_INVALID", `${name2} has invalid arity`);
  switch (kind) {
    case 0n:
      return { kind: "null" };
    case 1n:
      return { kind: "integer", value: expectInt642(tuple[1] ?? null, `${name2}.integer`) };
    case 2n: {
      const bits = expectBytes2(tuple[1] ?? null, `${name2}.real`, 8);
      const real = new DataView(bits.buffer, bits.byteOffset, 8).getFloat64(0, false);
      protocolInvariant(Number.isFinite(real), "SCHEMA_INVALID", `${name2}.real must be finite`);
      return { kind: "real", value: real };
    }
    case 3n:
      return { kind: "text", value: expectString2(tuple[1] ?? null, `${name2}.text`) };
    case 4n:
      return { kind: "blob", value: Uint8Array.from(expectBytes2(tuple[1] ?? null, `${name2}.blob`)) };
    default:
      protocolInvariant(false, "SCHEMA_INVALID", `${name2} has unknown kind`);
  }
}
var DEFAULT_EXECUTION_LIMITS = Object.freeze({
  maxSqlBytes: 1e6,
  maxVmSteps: 1e6,
  maxValueBytes: 16 * 1024 * 1024
});

// packages/protocol/src/sealed.ts
var MAX_SEALED_READERS = 256;
var MAX_SEALED_NAME_BYTES = 128;
var MAX_SEALED_ROW_KEY_VALUES = 64;
var MAX_SEALED_PLAINTEXT_BYTES = 1024 * 1024;
var MAX_SEALED_ENVELOPE_BYTES = MAX_SEALED_PLAINTEXT_BYTES + MAX_SEALED_READERS * 192 + 1024;
var MAX_SEALED_VERSION = (1n << 63n) - 1n;
var SEALED_OP_CODES = Object.freeze({
  register_reader_key: 64n,
  reader_policy: 65n,
  sealed_put: 66n
});
function isSealedPlatformOp(value) {
  return typeof value === "object" && value !== null && "op" in value && typeof value.op === "string" && Object.hasOwn(SEALED_OP_CODES, value.op);
}
var sealedOp = Object.freeze({
  registerReaderKey: (publicKey) => checked({ op: "register_reader_key", publicKey: id(publicKey, "register_reader_key.public_key") }),
  readerPolicy: (input) => checked({
    op: "reader_policy",
    table: input.table,
    rowKey: input.rowKey.map(toSqlValue),
    expectedVersion: input.expectedVersion,
    ...input.expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(input.expectedPolicyId, "reader_policy.expected_policy_id") },
    readers: input.readers.map((reader) => id(reader, "reader_policy.reader")).sort(compareBytes)
  }),
  put: (input) => checked({
    op: "sealed_put",
    policyId: id(input.policyId, "sealed_put.policy_id"),
    expectedPolicyVersion: input.expectedPolicyVersion,
    expectedDataVersion: input.expectedDataVersion,
    slot: input.slot,
    envelope: decodeSealedEnvelope(encodeSealedEnvelope(input.envelope))
  })
});
function checked(op) {
  return sealedPlatformOpFromCanonicalCbor(sealedPlatformOpToCanonicalCbor(op));
}
function id(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === 32, "SCHEMA_INVALID", `${field} must contain 32 bytes`);
  return Uint8Array.from(value);
}
function name(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0 && !value.includes("\0"), "SCHEMA_INVALID", `${field} must be nonempty text without U+0000`);
  protocolInvariant(utf82(value).length <= MAX_SEALED_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function version(value, field, minimum = 1n, maximum = MAX_SEALED_VERSION) {
  const parsed = expectUint642(value, field);
  protocolInvariant(parsed >= minimum && parsed <= maximum, "INTEGER_OUT_OF_RANGE", `${field} is outside the supported version range`);
  return parsed;
}
var isList = (value) => Array.isArray(value);
function orderedReaders(readers, field) {
  protocolInvariant(isList(readers) && readers.length <= MAX_SEALED_READERS, "SCHEMA_INVALID", `${field} has too many readers or is not an array`);
  return readers.map((reader, index) => {
    const key = id(reader, field);
    if (index > 0) protocolInvariant(compareBytes(readers[index - 1], reader) < 0, "SCHEMA_INVALID", `${field} must be sorted and unique`);
    return key;
  });
}
function sealedContextToCanonicalCbor(value) {
  return integerMap2([
    [0, 1n],
    [1, id(value.groupId, "sealed_context.group_id")],
    [2, id(value.policyId, "sealed_context.policy_id")],
    [3, version(value.policyVersion, "sealed_context.policy_version")],
    [4, name(value.slot, "sealed_context.slot")],
    [5, version(value.dataVersion, "sealed_context.data_version")]
  ]);
}
function sealedContextFromCanonicalCbor(value) {
  const map = expectMap2(value, "sealed_context");
  assertKnownIntegerKeys2(map, [0, 1, 2, 3, 4, 5], "sealed_context");
  expectVersion(map, 1n, "sealed_context");
  const context = {
    groupId: id(expectBytes2(required2(map, 1, "group_id"), "group_id", 32), "group_id"),
    policyId: id(expectBytes2(required2(map, 2, "policy_id"), "policy_id", 32), "policy_id"),
    policyVersion: expectUint642(required2(map, 3, "policy_version"), "policy_version"),
    slot: expectString2(required2(map, 4, "slot"), "slot"),
    dataVersion: expectUint642(required2(map, 5, "data_version"), "data_version")
  };
  sealedContextToCanonicalCbor(context);
  return context;
}
function sealedEnvelopeToCanonicalCbor(value) {
  protocolInvariant(value.nonce instanceof Uint8Array && value.nonce.length === 12, "SCHEMA_INVALID", "sealed_envelope.nonce must contain 12 bytes");
  protocolInvariant(
    value.ciphertext instanceof Uint8Array && value.ciphertext.length >= 16 && value.ciphertext.length <= MAX_SEALED_PLAINTEXT_BYTES + 16,
    "SCHEMA_INVALID",
    "sealed_envelope.ciphertext has an invalid length"
  );
  protocolInvariant(isList(value.wraps), "SCHEMA_INVALID", "sealed_envelope.wraps must be an array");
  orderedReaders(value.wraps.map((wrap2) => wrap2.readerId), "sealed_envelope.wraps");
  return integerMap2([
    [0, 1n],
    [1, sealedContextToCanonicalCbor(value.context)],
    [2, Uint8Array.from(value.nonce)],
    [3, Uint8Array.from(value.ciphertext)],
    [4, value.wraps.map((wrap2) => {
      protocolInvariant(wrap2.ciphertext instanceof Uint8Array && wrap2.ciphertext.length === 48, "SCHEMA_INVALID", "sealed_wrap.ciphertext must contain 48 bytes");
      return [
        id(wrap2.readerId, "sealed_wrap.reader_id"),
        id(wrap2.publicKey, "sealed_wrap.public_key"),
        id(wrap2.encapsulatedKey, "sealed_wrap.encapsulated_key"),
        Uint8Array.from(wrap2.ciphertext)
      ];
    })]
  ]);
}
function sealedEnvelopeFromCanonicalCbor(value) {
  const map = expectMap2(value, "sealed_envelope");
  assertKnownIntegerKeys2(map, [0, 1, 2, 3, 4], "sealed_envelope");
  expectVersion(map, 1n, "sealed_envelope");
  const envelope = {
    context: sealedContextFromCanonicalCbor(required2(map, 1, "context")),
    nonce: Uint8Array.from(expectBytes2(required2(map, 2, "nonce"), "nonce", 12)),
    ciphertext: Uint8Array.from(expectBytes2(required2(map, 3, "ciphertext"), "ciphertext")),
    wraps: expectArray2(required2(map, 4, "wraps"), "wraps").map((entry) => {
      const fields = expectArray2(entry, "sealed_wrap");
      protocolInvariant(fields.length === 4, "SCHEMA_INVALID", "sealed_wrap must contain four fields");
      return {
        readerId: id(expectBytes2(fields[0], "reader_id", 32), "reader_id"),
        publicKey: id(expectBytes2(fields[1], "public_key", 32), "public_key"),
        encapsulatedKey: id(expectBytes2(fields[2], "encapsulated_key", 32), "encapsulated_key"),
        ciphertext: Uint8Array.from(expectBytes2(fields[3], "wrapped_key", 48))
      };
    })
  };
  sealedEnvelopeToCanonicalCbor(envelope);
  return envelope;
}
function encodeSealedEnvelope(envelope) {
  return encodeCanonicalCbor(sealedEnvelopeToCanonicalCbor(envelope));
}
function decodeSealedEnvelope(bytes2) {
  protocolInvariant(bytes2.length <= MAX_SEALED_ENVELOPE_BYTES, "SCHEMA_INVALID", "sealed_envelope exceeds the encoded size limit");
  return sealedEnvelopeFromCanonicalCbor(assertCanonicalCbor2(bytes2));
}
function sealedPlatformOpToCanonicalCbor(op) {
  protocolInvariant(isSealedPlatformOp(op), "SCHEMA_INVALID", "Unknown sealed operation");
  const entries = [[0, SEALED_OP_CODES[op.op]]];
  switch (op.op) {
    case "register_reader_key":
      entries.push([1, id(op.publicKey, "register_reader_key.public_key")]);
      break;
    case "reader_policy": {
      const expected = version(op.expectedVersion, "reader_policy.expected_version", 0n, MAX_SEALED_VERSION - 1n);
      protocolInvariant(expected === 0n === (op.expectedPolicyId === void 0), "SCHEMA_INVALID", "reader_policy creation uses version 0 without an id; replacement requires an id and positive version");
      protocolInvariant(isList(op.rowKey) && op.rowKey.length >= 1 && op.rowKey.length <= MAX_SEALED_ROW_KEY_VALUES, "SCHEMA_INVALID", "reader_policy.row_key has an invalid length");
      entries.push(
        [1, name(op.table, "reader_policy.table")],
        [2, op.rowKey.map(sqlValueToCanonicalCbor)],
        [3, op.expectedPolicyId === void 0 ? void 0 : id(op.expectedPolicyId, "reader_policy.expected_policy_id")],
        [4, expected],
        [5, orderedReaders(op.readers, "reader_policy.readers")]
      );
      break;
    }
    case "sealed_put": {
      const policyId = id(op.policyId, "sealed_put.policy_id");
      const policyVersion = version(op.expectedPolicyVersion, "sealed_put.expected_policy_version");
      const dataVersion = version(op.expectedDataVersion, "sealed_put.expected_data_version", 0n, MAX_SEALED_VERSION - 1n);
      const slot = name(op.slot, "sealed_put.slot");
      const envelope = sealedEnvelopeToCanonicalCbor(op.envelope);
      protocolInvariant(
        equalBytes(op.envelope.context.policyId, policyId) && op.envelope.context.policyVersion === policyVersion && op.envelope.context.slot === slot && op.envelope.context.dataVersion === dataVersion + 1n,
        "SCHEMA_INVALID",
        "sealed_put envelope does not match its policy, slot or next data version"
      );
      entries.push([1, policyId], [2, policyVersion], [3, dataVersion], [4, slot], [5, envelope]);
      break;
    }
  }
  return integerMap2(entries);
}
function sealedPlatformOpFromCanonicalCbor(value, field = "sealed_op") {
  const map = expectMap2(value, field);
  const code = expectUint642(required2(map, 0, `${field}.op`), `${field}.op`);
  let op;
  if (code === SEALED_OP_CODES.register_reader_key) {
    assertKnownIntegerKeys2(map, [0, 1], field);
    op = { op: "register_reader_key", publicKey: id(expectBytes2(required2(map, 1, "public_key"), "public_key", 32), "public_key") };
  } else if (code === SEALED_OP_CODES.reader_policy) {
    assertKnownIntegerKeys2(map, [0, 1, 2, 3, 4, 5], field);
    const expectedPolicyId = optional2(map, 3);
    op = {
      op: "reader_policy",
      table: expectString2(required2(map, 1, "table"), "table"),
      rowKey: expectArray2(required2(map, 2, "row_key"), "row_key").map((item, index) => sqlValueFromCanonicalCbor(item, `row_key[${index}]`)),
      ...expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(expectBytes2(expectedPolicyId, "expected_policy_id", 32), "expected_policy_id") },
      expectedVersion: expectUint642(required2(map, 4, "expected_version"), "expected_version"),
      readers: expectArray2(required2(map, 5, "readers"), "readers").map((reader) => id(expectBytes2(reader, "reader", 32), "reader"))
    };
  } else if (code === SEALED_OP_CODES.sealed_put) {
    assertKnownIntegerKeys2(map, [0, 1, 2, 3, 4, 5], field);
    op = {
      op: "sealed_put",
      policyId: id(expectBytes2(required2(map, 1, "policy_id"), "policy_id", 32), "policy_id"),
      expectedPolicyVersion: expectUint642(required2(map, 2, "expected_policy_version"), "expected_policy_version"),
      expectedDataVersion: expectUint642(required2(map, 3, "expected_data_version"), "expected_data_version"),
      slot: expectString2(required2(map, 4, "slot"), "slot"),
      envelope: sealedEnvelopeFromCanonicalCbor(required2(map, 5, "envelope"))
    };
  } else {
    protocolInvariant(false, "SCHEMA_INVALID", `${field} has an unknown sealed operation`);
  }
  sealedPlatformOpToCanonicalCbor(op);
  return op;
}

// packages/protocol/src/platform.ts
var PLATFORM_ID_BYTES = 32;
var MAX_PLATFORM_NAME_BYTES = 128;
var MAX_PLATFORM_LIST_ENTRIES = 256;
var MAX_ROW_KEY_VALUES = 64;
var MAX_SEED_ROWS = 1e4;
var GROUP_COLLECTIVE_ID = new Uint8Array(PLATFORM_ID_BYTES);
var OP_CODES = [
  "grant",
  "revoke_grant",
  "create_collective",
  "accept_membership",
  "leave",
  "set_members",
  "transfer_offer",
  "transfer_accept",
  "seed_rows",
  "end_seeding",
  "transfer_cancel",
  "grant_ddl",
  "revoke_ddl"
];
var DDL_OPERATIONS = ["create", "alter", "drop", "index", "trigger"];
var OPERATION_BITS = { insert: 1n, update: 2n, delete: 4n };
var GRANT_OPERATIONS = ["insert", "update", "delete"];
var bytes = (value) => Uint8Array.from(value);
var rowKey = (values) => values.map(toSqlValue);
var platformOp = Object.freeze({
  ...sealedOp,
  grantDdl: (input) => checked2({ op: "grant_ddl", scope: { ...input.scope }, grantee: bytes(input.grantee), operations: [...input.operations] }),
  revokeDdl: (grantId) => checked2({ op: "revoke_ddl", grantId: bytes(grantId) }),
  grant: (input) => checked2({
    op: "grant",
    table: input.table,
    grantee: bytes(input.grantee),
    operations: [...input.operations],
    ...input.grantor === void 0 ? {} : { grantor: bytes(input.grantor) },
    ...input.rowKey === void 0 ? {} : { rowKey: rowKey(input.rowKey) },
    ...input.columns === void 0 ? {} : { columns: [...input.columns] }
  }),
  revokeGrant: (grantId) => checked2({ op: "revoke_grant", grantId: bytes(grantId) }),
  createCollective: (input) => checked2({ op: "create_collective", governance: { ...input.governance }, invitees: (input.invitees ?? []).map(bytes) }),
  acceptMembership: (collectiveId) => checked2({ op: "accept_membership", collectiveId: bytes(collectiveId) }),
  leave: (collectiveId) => checked2({ op: "leave", collectiveId: bytes(collectiveId) }),
  setMembers: (collectiveId, changes) => checked2({
    op: "set_members",
    collectiveId: bytes(collectiveId),
    changes: changes.map((change) => ({ member: bytes(change.member), role: change.role }))
  }),
  transferRow: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "row", table: input.table, rowKey: rowKey(input.rowKey) },
    toOwner: bytes(input.toOwner),
    carry: input.carry ?? false,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  transferAll: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "all" },
    toOwner: bytes(input.toOwner),
    carry: true,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  acceptTransfer: (offerId) => checked2({ op: "transfer_accept", offerId: bytes(offerId) }),
  cancelTransfer: (offerId) => checked2({ op: "transfer_cancel", offerId: bytes(offerId) }),
  seedRows: (table, columns, rows) => checked2({ op: "seed_rows", table, columns: [...columns], rows: rows.map(rowKey) }),
  endSeeding: () => checked2({ op: "end_seeding" })
});
function checked2(op) {
  platformOpToCanonicalCbor(op);
  return op;
}
function nameToCbor(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0, "SCHEMA_INVALID", `${field} cannot be empty`);
  protocolInvariant(!value.includes("\0"), "SCHEMA_INVALID", `${field} cannot contain U+0000`);
  protocolInvariant(utf82(value).length <= MAX_PLATFORM_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function idToCbor(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === PLATFORM_ID_BYTES, "SCHEMA_INVALID", `${field} must contain ${PLATFORM_ID_BYTES} bytes`);
  return Uint8Array.from(value);
}
function listToCbor(values, field, encode, minimum = 0) {
  protocolInvariant(isList2(values), "SCHEMA_INVALID", `${field} must be a list`);
  protocolInvariant(values.length >= minimum && values.length <= MAX_PLATFORM_LIST_ENTRIES, "SCHEMA_INVALID", `${field} has an invalid number of entries`);
  return values.map(encode);
}
function uniqueBy(values, key, field) {
  const seen = /* @__PURE__ */ new Set();
  for (const value of values) {
    const entry = key(value);
    protocolInvariant(!seen.has(entry), "SCHEMA_INVALID", `${field} contains a duplicate`);
    seen.add(entry);
  }
}
var hex = (value) => bytesToHex2(value);
var isList2 = (value) => Array.isArray(value);
function rowKeyToCbor(values, field) {
  protocolInvariant(isList2(values) && values.length >= 1 && values.length <= MAX_ROW_KEY_VALUES, "SCHEMA_INVALID", `${field} must have 1 to ${MAX_ROW_KEY_VALUES} values`);
  return values.map(sqlValueToCanonicalCbor);
}
function roleCode(role, field) {
  protocolInvariant(role === "member" || role === "admin", "SCHEMA_INVALID", `${field} must be member or admin`);
  return role === "member" ? 0n : 1n;
}
function platformOpToCanonicalCbor(op) {
  if (isSealedPlatformOp(op)) return sealedPlatformOpToCanonicalCbor(op);
  const code = OP_CODES.indexOf(op.op);
  protocolInvariant(code >= 0, "SCHEMA_INVALID", "Unknown platform operation");
  const entries = [[0, BigInt(code)]];
  switch (op.op) {
    case "grant_ddl": {
      protocolInvariant(op.scope.kind === "namespace" || op.scope.kind === "object", "SCHEMA_INVALID", "Unknown DDL scope");
      protocolInvariant(op.scope.kind !== "namespace" || op.scope.name === "main", "SCHEMA_INVALID", "Only the main namespace exists");
      protocolInvariant(isList2(op.operations) && op.operations.length > 0, "SCHEMA_INVALID", "DDL operations cannot be empty");
      uniqueBy(op.operations, (value) => value, "grant_ddl.operations");
      protocolInvariant(op.operations.every((operation) => DDL_OPERATIONS.includes(operation) && (op.scope.kind === "namespace" ? operation === "create" : operation !== "create")), "SCHEMA_INVALID", "Invalid DDL operation for scope");
      protocolInvariant(
        DDL_OPERATIONS.filter((operation) => op.operations.includes(operation)).every((operation, index) => op.operations[index] === operation),
        "SCHEMA_INVALID",
        "DDL operations must be in create, alter, drop, index, trigger order"
      );
      entries.push(
        [1, [op.scope.kind === "namespace" ? 0n : 1n, nameToCbor(op.scope.name, "grant_ddl.scope")]],
        [2, idToCbor(op.grantee, "grant_ddl.grantee")],
        [3, op.operations.map((operation) => BigInt(DDL_OPERATIONS.indexOf(operation)))]
      );
      break;
    }
    case "revoke_ddl":
      entries.push([1, idToCbor(op.grantId, "revoke_ddl.grant_id")]);
      break;
    case "grant": {
      protocolInvariant(isList2(op.operations) && op.operations.length > 0, "SCHEMA_INVALID", "grant.operations cannot be empty");
      uniqueBy(op.operations, (value) => value, "grant.operations");
      let mask = 0n;
      for (const operation of op.operations) {
        protocolInvariant(GRANT_OPERATIONS.includes(operation), "SCHEMA_INVALID", "grant.operations has an unknown operation");
        mask |= OPERATION_BITS[operation];
      }
      protocolInvariant(
        GRANT_OPERATIONS.filter((operation) => op.operations.includes(operation)).every((operation, index) => op.operations[index] === operation),
        "SCHEMA_INVALID",
        "grant.operations must be in insert, update, delete order"
      );
      if (op.columns !== void 0) uniqueBy(op.columns, (value) => value, "grant.columns");
      entries.push(
        [1, nameToCbor(op.table, "grant.table")],
        [2, idToCbor(op.grantee, "grant.grantee")],
        [3, mask],
        [4, op.grantor === void 0 ? void 0 : idToCbor(op.grantor, "grant.grantor")],
        [5, op.rowKey === void 0 ? void 0 : rowKeyToCbor(op.rowKey, "grant.row_key")],
        [6, op.columns === void 0 ? void 0 : listToCbor(op.columns, "grant.columns", (column) => nameToCbor(column, "grant.columns"), 1)]
      );
      break;
    }
    case "revoke_grant":
      entries.push([1, idToCbor(op.grantId, "revoke_grant.grant_id")]);
      break;
    case "create_collective":
      uniqueBy(op.invitees, hex, "create_collective.invitees");
      entries.push(
        [1, integerMap2([
          [0, roleCode(op.governance.insert, "governance.insert")],
          [1, roleCode(op.governance.update, "governance.update")],
          [2, roleCode(op.governance.delete, "governance.delete")]
        ])],
        [2, listToCbor(op.invitees, "create_collective.invitees", (key) => idToCbor(key, "create_collective.invitees"))]
      );
      break;
    case "accept_membership":
    case "leave":
      entries.push([1, idToCbor(op.collectiveId, `${op.op}.collective_id`)]);
      break;
    case "set_members":
      uniqueBy(op.changes, (change) => hex(change.member), "set_members.changes");
      entries.push(
        [1, idToCbor(op.collectiveId, "set_members.collective_id")],
        [2, listToCbor(op.changes, "set_members.changes", (change) => [
          idToCbor(change.member, "set_members.member"),
          change.role === "remove" ? 2n : roleCode(change.role, "set_members.role")
        ], 1)]
      );
      break;
    case "transfer_offer": {
      protocolInvariant(typeof op.carry === "boolean", "SCHEMA_INVALID", "transfer_offer.carry must be a boolean");
      let scope;
      if (op.scope.kind === "all") {
        protocolInvariant(op.carry, "SCHEMA_INVALID", "A transfer of all rows always carries dependents");
        scope = [1n];
      } else {
        protocolInvariant(op.scope.kind === "row", "SCHEMA_INVALID", "transfer_offer.scope is unknown");
        scope = [0n, nameToCbor(op.scope.table, "transfer_offer.table"), rowKeyToCbor(op.scope.rowKey, "transfer_offer.row_key")];
      }
      entries.push(
        [1, scope],
        [2, op.fromOwner === void 0 ? void 0 : idToCbor(op.fromOwner, "transfer_offer.from_owner")],
        [3, idToCbor(op.toOwner, "transfer_offer.to_owner")],
        [4, op.carry ? 1n : 0n]
      );
      break;
    }
    case "transfer_accept":
    case "transfer_cancel":
      entries.push([1, idToCbor(op.offerId, `${op.op}.offer_id`)]);
      break;
    case "seed_rows": {
      uniqueBy(op.columns, (value) => value.toLowerCase(), "seed_rows.columns");
      protocolInvariant(isList2(op.rows) && op.rows.length >= 1 && op.rows.length <= MAX_SEED_ROWS, "SCHEMA_INVALID", "seed_rows.rows has an invalid number of rows");
      entries.push(
        [1, nameToCbor(op.table, "seed_rows.table")],
        [2, listToCbor(op.columns, "seed_rows.columns", (column) => nameToCbor(column, "seed_rows.columns"), 1)],
        [3, op.rows.map((row) => {
          protocolInvariant(isList2(row) && row.length === op.columns.length, "SCHEMA_INVALID", "seed_rows row width must match its columns");
          return row.map(sqlValueToCanonicalCbor);
        })]
      );
      break;
    }
    case "end_seeding":
      break;
  }
  return integerMap2(entries);
}

// packages/protocol/src/program.ts
var MAX_EVENT_BYTES = 16384;
function canonicalJson(payload, limits) {
  for (const bound of [limits.maxBytes, limits.maxNodes, limits.maxDepth]) protocolInvariant(Number.isSafeInteger(bound) && bound > 0, "SCHEMA_INVALID", "Invalid JSON limits");
  let nodes = 0;
  const visit = (value, depth) => {
    protocolInvariant(depth <= limits.maxDepth && ++nodes <= limits.maxNodes, "SCHEMA_INVALID", "JSON payload is too complex");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "Event numbers must be finite");
      return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
      protocolInvariant(Reflect.ownKeys(value).length === value.length + 1, "SCHEMA_INVALID", "Event arrays cannot carry extra properties");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, i);
        protocolInvariant(
          descriptor !== void 0 && "value" in descriptor && descriptor.enumerable === true,
          "SCHEMA_INVALID",
          "Event arrays require dense data elements"
        );
        entries.push(visit(descriptor.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    protocolInvariant(
      typeof value === "object" && value !== null && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null),
      "SCHEMA_INVALID",
      "Event payload must contain JSON values"
    );
    protocolInvariant(Reflect.ownKeys(value).length === Object.keys(value).length, "SCHEMA_INVALID", "Event objects require enumerable string keys");
    return `{${Object.keys(value).sort().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      protocolInvariant("value" in descriptor, "SCHEMA_INVALID", "Event payload cannot contain accessors");
      return `${JSON.stringify(key)}:${visit(descriptor.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const encoded = visit(payload, 0);
  protocolInvariant(utf82(encoded).length <= limits.maxBytes, "SCHEMA_INVALID", "JSON payload is too large");
  return encoded;
}
function canonicalEventPayload(payload) {
  return canonicalJson(payload, { maxBytes: MAX_EVENT_BYTES, maxNodes: 4096, maxDepth: 32 });
}

// packages/protocol/src/primitives.ts
init_src();
var ED25519 = { name: "Ed25519" };
function bufferSource2(value) {
  return Uint8Array.from(value).buffer;
}
async function generateEd25519KeyPair(extractable = true) {
  const pair = await globalThis.crypto.subtle.generateKey(ED25519, extractable, ["sign", "verify"]);
  const publicKeyBytes = new Uint8Array(await globalThis.crypto.subtle.exportKey("raw", pair.publicKey));
  return { publicKey: pair.publicKey, privateKey: pair.privateKey, publicKeyBytes };
}
async function importEd25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "Ed25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", bufferSource2(raw), ED25519, true, ["verify"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 public key");
  }
}
async function importEd25519PrivateKey(pkcs8, extractable = true) {
  try {
    return await globalThis.crypto.subtle.importKey("pkcs8", bufferSource2(pkcs8), ED25519, extractable, ["sign"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 private key");
  }
}
async function exportEd25519PrivateKey(privateKey) {
  try {
    return new Uint8Array(await globalThis.crypto.subtle.exportKey("pkcs8", privateKey));
  } catch {
    throw new ProtocolError("INVALID_KEY", "Ed25519 private key is not extractable");
  }
}

// packages/authority/src/codec.ts
function check(condition, code) {
  if (!condition) throw Object.assign(new Error(code), { code });
}
function hex2(value, length = 32) {
  check(typeof value === "string" && new RegExp(`^[0-9a-f]{${length * 2}}$`, "u").test(value), "AUTHORITY_HEX_INVALID");
}
function normalized(value, depth = 0) {
  check(depth < 32, "RECORD_DEPTH_LIMIT");
  if (value instanceof Uint8Array) return { $bytes: bytesToHex(value) };
  if (typeof value === "bigint") return { $integer: value.toString() };
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    check(Number.isSafeInteger(value), "RECORD_INTEGER_INVALID");
    return value;
  }
  if (Array.isArray(value)) return value.map((item) => normalized(item, depth + 1));
  check(value !== null && typeof value === "object" && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null), "RECORD_INVALID");
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, normalized(value[key], depth + 1)]));
}
function encodeRecord(value) {
  const bytes2 = new TextEncoder().encode(JSON.stringify(normalized(value)));
  check(bytes2.length <= 32 * 1024 * 1024, "RECORD_BYTES_LIMIT");
  return bytes2;
}
function decodeRecord(bytes2) {
  check(bytes2.length <= 32 * 1024 * 1024, "RECORD_BYTES_LIMIT");
  const value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes2), (_key, item) => {
    if (item !== null && typeof item === "object" && !Array.isArray(item)) {
      const record = item;
      if (Object.keys(record).length === 1 && typeof record.$bytes === "string") {
        check(/^(?:[0-9a-f]{2})*$/u.test(record.$bytes), "RECORD_BYTES_INVALID");
        return hexToBytes(record.$bytes);
      }
      if (Object.keys(record).length === 1 && typeof record.$integer === "string") {
        check(/^-?(?:0|[1-9][0-9]*)$/u.test(record.$integer), "RECORD_INTEGER_INVALID");
        return BigInt(record.$integer);
      }
    }
    return item;
  });
  check(equalRecord(value, decodeUncanonical(bytes2)), "RECORD_INVALID");
  check(equalBytes(encodeRecord(value), bytes2), "RECORD_NOT_CANONICAL");
  return value;
}
function decodeUncanonical(bytes2) {
  return JSON.parse(new TextDecoder().decode(bytes2));
}
function equalRecord(a, b) {
  return equalBytes(encodeRecord(a), encodeRecord(b));
}
async function recordDigest(value) {
  return bytesToHex(await sha256(encodeRecord(value)));
}
function signedBytes(domain, payload) {
  return encodeRecord(["chronolog/authored/v1", domain, payload]);
}
async function signRecord(domain, payload, identity) {
  hex2(identity.publicKey);
  const captured = structuredClone(payload);
  const signature = bytesToHex(new Uint8Array(await crypto.subtle.sign("Ed25519", identity.privateKey, Uint8Array.from(signedBytes(domain, captured)).buffer)));
  const result = { payload: captured, signer: identity.publicKey, signature };
  await verifyRecord(domain, result, identity.publicKey);
  return result;
}
async function verifyRecord(domain, signed, expectedSigner) {
  hex2(signed.signer);
  hex2(signed.signature, 64);
  check(expectedSigner === void 0 || signed.signer === expectedSigner, "AUTHORITY_SIGNER_MISMATCH");
  const key = await importEd25519PublicKey(hexToBytes(signed.signer));
  check(await crypto.subtle.verify("Ed25519", key, Uint8Array.from(hexToBytes(signed.signature)).buffer, Uint8Array.from(signedBytes(domain, signed.payload)).buffer), "AUTHORITY_SIGNATURE_INVALID");
}
async function createSigningIdentity() {
  const pair = await generateEd25519KeyPair();
  return { publicKey: bytesToHex(pair.publicKeyBytes), privateKey: pair.privateKey };
}
async function exportSigningIdentity(identity) {
  return { publicKey: identity.publicKey, privateKey: bytesToHex(await exportEd25519PrivateKey(identity.privateKey)) };
}
async function importSigningIdentity(value) {
  hex2(value.publicKey);
  return { publicKey: value.publicKey, privateKey: await importEd25519PrivateKey(hexToBytes(value.privateKey)) };
}

// packages/authority/src/definition.ts
function isArray(value) {
  return Array.isArray(value);
}
function object(value, keys) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), "APPLICATION_DESCRIPTION_INVALID");
}
function parseApplicationInput(schema, value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  const visit = (spec, item, path2) => {
    const invalid = () => {
      throw new Error(`APPLICATION_INPUT_INVALID:${path2}`);
    };
    if ("anyOf" in spec) {
      for (const option of spec.anyOf) {
        try {
          visit(option, item, path2);
          return;
        } catch {
        }
      }
      invalid();
    } else if (spec.type === "null") {
      if (item !== null) invalid();
    } else if (spec.type === "boolean") {
      if (typeof item !== "boolean") invalid();
    } else if (spec.type === "string") {
      if (typeof item !== "string") return invalid();
      const length = [...item].length;
      if (length < (spec.minLength ?? 0) || length > (spec.maxLength ?? 16384) || spec.enum !== void 0 && !spec.enum.includes(item)) invalid();
    } else if (spec.type === "number" || spec.type === "integer") {
      if (typeof item !== "number" || spec.type === "integer" && !Number.isSafeInteger(item) || item < (spec.minimum ?? -Infinity) || item > (spec.maximum ?? Infinity)) invalid();
    } else if (spec.type === "array") {
      if (!Array.isArray(item) || item.length < (spec.minItems ?? 0) || item.length > (spec.maxItems ?? 4096)) return invalid();
      const items = item;
      items.forEach((child, index) => visit(spec.items, child, `${path2}[${index}]`));
    } else if (spec.type === "object") {
      if (item === null || typeof item !== "object" || Array.isArray(item)) return invalid();
      const object2 = item;
      for (const name2 of spec.required ?? []) if (!Object.hasOwn(object2, name2)) invalid();
      for (const [name2, child] of Object.entries(object2)) {
        if (!Object.hasOwn(spec.properties, name2)) invalid();
        visit(spec.properties[name2], child, `${path2}.${name2}`);
      }
    }
  };
  visit(schema, copy, "$");
  return freeze(copy);
}
function checkedApplicationInputSchema(value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  let nodes = 0;
  const visit = (schema, depth) => {
    if (++nodes > 256 || depth > 16 || schema === null || typeof schema !== "object" || Array.isArray(schema)) throw new Error("APPLICATION_SCHEMA_INVALID");
    const keys = /* @__PURE__ */ new Set(["description"]);
    const allow = (...names) => {
      for (const name2 of names) keys.add(name2);
    };
    const bound = (value2, max) => {
      if (value2 !== void 0 && (!Number.isSafeInteger(value2) || value2 < 0 || value2 > max)) throw new Error("APPLICATION_SCHEMA_INVALID");
    };
    if (schema.description !== void 0 && typeof schema.description !== "string") throw new Error("APPLICATION_SCHEMA_INVALID");
    if ("anyOf" in schema) {
      allow("anyOf");
      if (!Array.isArray(schema.anyOf) || schema.anyOf.length < 1 || schema.anyOf.length > 16) throw new Error("APPLICATION_SCHEMA_INVALID");
      const alternatives = schema.anyOf;
      alternatives.forEach((option) => visit(option, depth + 1));
    } else {
      allow("type");
      switch (schema.type) {
        case "string":
          allow("minLength", "maxLength", "enum");
          bound(schema.minLength, 16384);
          bound(schema.maxLength, 16384);
          if ((schema.minLength ?? 0) > (schema.maxLength ?? 16384) || schema.enum !== void 0 && (!Array.isArray(schema.enum) || schema.enum.length === 0 || schema.enum.length > 256 || schema.enum.some((item) => typeof item !== "string"))) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "number":
        case "integer":
          allow("minimum", "maximum");
          if ([schema.minimum, schema.maximum].some((value2) => value2 !== void 0 && !Number.isFinite(value2)) || (schema.minimum ?? -Infinity) > (schema.maximum ?? Infinity)) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "boolean":
        case "null":
          break;
        case "array":
          allow("items", "minItems", "maxItems");
          bound(schema.minItems, 4096);
          bound(schema.maxItems, 4096);
          if ((schema.minItems ?? 0) > (schema.maxItems ?? 4096)) throw new Error("APPLICATION_SCHEMA_INVALID");
          visit(schema.items, depth + 1);
          break;
        case "object":
          allow("properties", "required", "additionalProperties");
          if (schema.properties === null || typeof schema.properties !== "object" || Array.isArray(schema.properties) || schema.additionalProperties !== void 0 && schema.additionalProperties !== false) throw new Error("APPLICATION_SCHEMA_INVALID");
          for (const child of Object.values(schema.properties)) visit(child, depth + 1);
          if (schema.required !== void 0 && (!Array.isArray(schema.required) || schema.required.some((name2) => typeof name2 !== "string" || !Object.hasOwn(schema.properties, name2)) || new Set(schema.required).size !== schema.required.length)) {
            throw new Error("APPLICATION_SCHEMA_INVALID");
          }
          Object.assign(schema, { additionalProperties: false });
          break;
        default:
          throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
      }
    }
    if (Object.keys(schema).some((key) => !keys.has(key))) throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
  };
  visit(copy, 0);
  return freeze(copy);
}
function freeze(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
function validateApplicationDescription(value) {
  const bytes2 = descriptionJson(value);
  check(new TextEncoder().encode(bytes2).length <= 262144, "APPLICATION_DESCRIPTION_TOO_LARGE");
  const copy = JSON.parse(bytes2);
  object(copy, ["id", "version", "commands", "queries"]);
  for (const text of [copy.id, copy.version]) check(typeof text === "string" && /^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(text), "APPLICATION_DEFINITION_ID_INVALID");
  for (const entries of [copy.commands, copy.queries]) {
    check(isArray(entries) && entries.length <= 128, "APPLICATION_DEFINITION_TOO_LARGE");
    let previous = "";
    for (const entry of entries) {
      object(entry, ["name", "description", "input"]);
      check(typeof entry.name === "string" && /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(entry.name) && !["__proto__", "constructor", "prototype"].includes(entry.name) && entry.name > previous, "APPLICATION_DEFINITION_NAME_INVALID");
      previous = entry.name;
      check(typeof entry.description === "string" && entry.description.length <= 4096, "APPLICATION_DESCRIPTION_INVALID");
      const checked3 = checkedApplicationInputSchema(entry.input);
      check(canonicalEventPayload(entry.input) === canonicalEventPayload(checked3), "APPLICATION_SCHEMA_NOT_CANONICAL");
    }
  }
  return freeze(copy);
}
async function applicationDescriptionDigest(value) {
  const description = validateApplicationDescription(value);
  return recordDigest(["application-description/v1", descriptionJson(description)]);
}
function descriptionJson(value) {
  return canonicalJson(value, { maxBytes: 262144, maxNodes: 65536, maxDepth: 32 });
}

// packages/authority/src/control.ts
function inviteGrant(role) {
  return { reader: true, writer: role !== "reader", administrator: role === "admin" };
}
var isList3 = (value) => Array.isArray(value);
function exactRecord(value, keys, code) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value)), code);
  check(Reflect.ownKeys(value).length === keys.length && keys.every((key) => {
    const field = Object.getOwnPropertyDescriptor(value, key);
    return field !== void 0 && "value" in field;
  }), code);
}
function validateFinalityPolicy(input) {
  check(input !== null && typeof input === "object", "FINALITY_POLICY_UNSUPPORTED");
  const kind = Object.getOwnPropertyDescriptor(input, "kind")?.value;
  if (kind === "none") {
    exactRecord(input, ["kind"], "FINALITY_POLICY_FIELDS_INVALID");
    return { kind: "none" };
  }
  check(kind === "fixed-validator" || kind === "signed-frontier", "FINALITY_POLICY_UNSUPPORTED");
  exactRecord(input, kind === "fixed-validator" ? ["kind", "validators", "threshold", "scopes"] : ["kind", "signer", "scopes"], "FINALITY_POLICY_FIELDS_INVALID");
  check(Array.isArray(input.scopes) && input.scopes.length > 0 && input.scopes.length <= 4096, "FINALITY_SCOPE_INVALID");
  const scopes = [], ids = /* @__PURE__ */ new Set();
  let bound = -1n;
  for (const value of input.scopes) {
    exactRecord(value, ["id", "authorTimeAfterMs"], "FINALITY_SCOPE_INVALID");
    hex2(value.id);
    check(typeof value.authorTimeAfterMs === "bigint" && value.authorTimeAfterMs >= bound && value.authorTimeAfterMs <= (1n << 63n) - 1n && (scopes.length > 0 || value.authorTimeAfterMs === -1n) && !ids.has(value.id), "FINALITY_SCOPE_INVALID");
    scopes.push({ id: value.id, authorTimeAfterMs: value.authorTimeAfterMs });
    ids.add(value.id);
    bound = value.authorTimeAfterMs;
  }
  if (kind === "signed-frontier") {
    hex2(input.signer);
    return { kind, signer: input.signer, scopes };
  }
  check(Array.isArray(input.validators) && input.validators.length > 0 && input.validators.length <= 4096, "FINALITY_VALIDATORS_INVALID");
  const validators = [];
  for (const key of input.validators) {
    hex2(key);
    validators.push(key);
  }
  check(new Set(validators).size === validators.length && typeof input.threshold === "number" && Number.isSafeInteger(input.threshold) && input.threshold > 0 && input.threshold <= validators.length, "FINALITY_VALIDATORS_INVALID");
  return { kind, validators, threshold: input.threshold, scopes };
}
function validateDescriptor(value) {
  exactRecord(value, ["applicationId", "rootPrincipal", "authorityPublicKey", "executionManifestDigest", "finalityPolicy"], "AUTHORITY_DESCRIPTOR_FIELDS_INVALID");
  hex2(value.applicationId);
  hex2(value.rootPrincipal);
  hex2(value.authorityPublicKey);
  hex2(value.executionManifestDigest);
  validateFinalityPolicy(value.finalityPolicy);
}
async function signAppDescriptor(descriptor, signer) {
  validateDescriptor(descriptor);
  check(signer.publicKey === descriptor.authorityPublicKey, "AUTHORITY_SIGNER_MISMATCH");
  return signRecord("descriptor", descriptor, signer);
}
async function signMembership(membership, signer) {
  return signRecord("membership", membership, signer);
}
function validateAdmissionPolicy(input) {
  exactRecord(input, ["mode", "hostKey", "accounts", "grant"], "ADMISSION_POLICY_INVALID");
  check(input.mode === "attested" || input.mode === "strict", "ADMISSION_POLICY_INVALID");
  hex2(input.hostKey);
  check(Array.isArray(input.accounts) && input.accounts.length <= 64 && input.accounts.every((value) => typeof value === "string" && value.length > 0 && value.length <= 320) && new Set(input.accounts).size === input.accounts.length, "ADMISSION_POLICY_INVALID");
  exactRecord(input.grant, ["reader", "writer", "administrator"], "ADMISSION_POLICY_INVALID");
  check(typeof input.grant.reader === "boolean" && typeof input.grant.writer === "boolean" && typeof input.grant.administrator === "boolean", "ADMISSION_POLICY_INVALID");
  return { mode: input.mode, hostKey: input.hostKey, accounts: [...input.accounts], grant: { reader: input.grant.reader, writer: input.grant.writer, administrator: input.grant.administrator } };
}
function validateInvites(input) {
  check(Array.isArray(input) && input.length <= 256, "INVITE_INVALID");
  const ids = /* @__PURE__ */ new Set();
  for (const invite of input) {
    exactRecord(invite, ["inviteId", "role", "binding", "expiresAt", "secretDigest", "revoked"], "INVITE_INVALID");
    hex2(invite.inviteId, 16);
    hex2(invite.secretDigest);
    check(!ids.has(invite.inviteId) && ["reader", "writer", "admin"].includes(invite.role) && typeof invite.expiresAt === "bigint" && invite.expiresAt > 0n && typeof invite.revoked === "boolean", "INVITE_INVALID");
    ids.add(invite.inviteId);
    const binding = invite.binding;
    check(binding !== null && typeof binding === "object", "INVITE_INVALID");
    if (binding.kind === "email") {
      exactRecord(binding, ["kind", "email"], "INVITE_INVALID");
      check(typeof binding.email === "string" && binding.email.length <= 254 && /^[^\s@]+@[^\s@]+$/u.test(binding.email) && binding.email === binding.email.toLowerCase(), "INVITE_INVALID");
    } else if (binding.kind === "open") exactRecord(binding, ["kind"], "INVITE_INVALID");
    else {
      check(binding.kind === "public", "INVITE_INVALID");
      exactRecord(binding, ["kind", "max"], "INVITE_INVALID");
      check(binding.max === null || typeof binding.max === "number" && Number.isSafeInteger(binding.max) && binding.max > 0 && binding.max <= 1e5, "INVITE_INVALID");
    }
  }
  return input;
}
function inviteRedemptions(memberships, inviteId) {
  return memberships.reduce((total, item) => total + item.payload.admitted.filter((admission) => admission.via === "invited" && admission.attestation.payload.inviteId === inviteId).length, 0);
}
function inviteAdmits(invite, attestation, activation) {
  return invite !== void 0 && !invite.revoked && activation < invite.expiresAt && (invite.binding.kind !== "email" || attestation.email === invite.binding.email);
}
function inviteCapacity(invite) {
  return invite.binding.kind === "public" ? invite.binding.max ?? Number.MAX_SAFE_INTEGER : 1;
}
async function signHostAttestation(value, host) {
  validateAttestation(value);
  return signRecord("host-attestation", value, host);
}
function validateAttestation(value) {
  exactRecord(value, ["subject", "pageId", "applicationId", "accountId", "email", "publicKey", "wrapKey", "label", "inviteId", "issuedAt", "expiresAt", "nonce"], "ATTESTATION_INVALID");
  check(value.inviteId === null || typeof value.inviteId === "string" && /^[0-9a-f]{32}$/u.test(value.inviteId), "ATTESTATION_INVALID");
  check((value.subject === "device" || value.subject === "agent") && typeof value.pageId === "string" && /^[a-z2-7]{1,64}$/u.test(value.pageId) && typeof value.accountId === "string" && value.accountId.length > 0 && value.accountId.length <= 128 && (value.email === null || typeof value.email === "string" && value.email.length <= 254 && value.email === value.email.toLowerCase()) && typeof value.label === "string" && value.label.length <= 128 && typeof value.issuedAt === "bigint" && typeof value.expiresAt === "bigint" && value.issuedAt >= 0n && value.expiresAt > value.issuedAt && value.expiresAt - value.issuedAt <= 86400000n, "ATTESTATION_INVALID");
  hex2(value.applicationId);
  hex2(value.publicKey);
  hex2(value.wrapKey);
  hex2(value.nonce);
}
async function verifyHostAttestation(value, expected) {
  validateAttestation(value.payload);
  await verifyRecord("host-attestation", value, expected.hostKey);
  check(value.payload.applicationId === expected.applicationId && (expected.pageId === void 0 || value.payload.pageId === expected.pageId), "ATTESTATION_SCOPE_MISMATCH");
  return value.payload;
}
function attestedAccountAuthorized(policy, attestation) {
  return policy.accounts.includes(attestation.accountId) || attestation.email !== null && policy.accounts.includes(`email:${attestation.email}`);
}
function attestedGrant(policy, attestation) {
  return { reader: policy.grant.reader, writer: policy.grant.writer, administrator: attestation.subject === "device" && policy.grant.administrator };
}
function sameGrant(a, b) {
  return a.publicKey === b.publicKey && a.wrapKey === b.wrapKey && a.reader === b.reader && a.writer === b.writer && a.administrator === b.administrator && a.publisher === b.publisher && a.finalizer === b.finalizer;
}
async function verifyAuthorityBundle(input, pinned) {
  const bundle = structuredClone(input), descriptor = bundle.descriptor.payload;
  validateDescriptor(descriptor);
  await verifyRecord("descriptor", bundle.descriptor, descriptor.authorityPublicKey);
  check(pinned === void 0 || equalRecord(pinned, bundle.descriptor), "AUTHORITY_DESCRIPTOR_MISMATCH");
  check(bundle.memberships.length > 0 && bundle.memberships.length <= 4096, "AUTHORITY_MEMBERSHIP_LIMIT");
  let previous = null;
  const nonces = /* @__PURE__ */ new Set();
  for (const [revision, signed] of bundle.memberships.entries()) {
    const value = signed.payload, prior = revision === 0 ? null : bundle.memberships[revision - 1].payload;
    exactRecord(value, ["applicationId", "revision", "authorTimeAfterMs", "previous", "members", "epoch", "epochKeyDigest", "admission", "admitted", "invites"], "AUTHORITY_CHAIN_INVALID");
    check(value.applicationId === descriptor.applicationId && value.revision === revision && value.previous === previous && Number.isSafeInteger(value.epoch) && value.epoch >= 0, "AUTHORITY_CHAIN_INVALID");
    hex2(value.epochKeyDigest);
    validateAdmissionPolicy(value.admission);
    validateInvites(value.invites);
    const priorEpoch = bundle.memberships.slice(0, revision).find((item) => item.payload.epoch === value.epoch);
    check(priorEpoch === void 0 || priorEpoch.payload.epochKeyDigest === value.epochKeyDigest, "AUTHORITY_EPOCH_COMMITMENT_CHANGED");
    check(typeof value.authorTimeAfterMs === "bigint" && (prior === null ? value.authorTimeAfterMs === -1n : value.authorTimeAfterMs > prior.authorTimeAfterMs), "AUTHORITY_ACTIVATION_INVALID");
    check(isList3(value.members) && value.members.length <= 4096 && new Set(value.members.map((member) => member.publicKey)).size === value.members.length, "AUTHORITY_MEMBERS_INVALID");
    for (const member of value.members) {
      exactRecord(member, ["publicKey", "wrapKey", "reader", "writer", "administrator", "publisher", "finalizer"], "AUTHORITY_MEMBERS_INVALID");
      hex2(member.publicKey);
      if (member.wrapKey !== null) hex2(member.wrapKey);
      for (const flag of [member.reader, member.writer, member.publisher, member.administrator, member.finalizer]) check(typeof flag === "boolean", "AUTHORITY_MEMBERS_INVALID");
    }
    if (prior === null) check(value.members.some((member) => member.publicKey === descriptor.rootPrincipal) && isList3(value.admitted) && value.admitted.length === 0, "AUTHORITY_ROOT_MISSING");
    check(isList3(value.admitted) && value.admitted.length <= 64, "AUTHORITY_ADMISSION_INVALID");
    const policy = prior?.admission ?? value.admission, added = /* @__PURE__ */ new Set();
    for (const admission of value.admitted) {
      exactRecord(admission, ["publicKey", "via", "attestation"], "AUTHORITY_ADMISSION_INVALID");
      check(admission.via === "attested" || admission.via === "invited" || admission.via === "approved", "AUTHORITY_ADMISSION_INVALID");
      const attestation = await verifyHostAttestation(admission.attestation, { hostKey: policy.hostKey, applicationId: descriptor.applicationId });
      const member = value.members.find((item) => item.publicKey === admission.publicKey);
      check(attestation.publicKey === admission.publicKey && member !== void 0 && member.wrapKey === attestation.wrapKey && !added.has(admission.publicKey) && !prior?.members.some((item) => item.publicKey === admission.publicKey), "AUTHORITY_ADMISSION_INVALID");
      check(attestation.issuedAt <= value.authorTimeAfterMs && value.authorTimeAfterMs < attestation.expiresAt, "AUTHORITY_ADMISSION_EXPIRED");
      check(!nonces.has(attestation.nonce), "AUTHORITY_ADMISSION_REPLAYED");
      nonces.add(attestation.nonce);
      added.add(admission.publicKey);
      if (admission.via === "attested") check(attestation.inviteId === null && attestedAccountAuthorized(policy, attestation), "AUTHORITY_ADMISSION_ACCOUNT_FORBIDDEN");
      if (admission.via === "invited") check(attestation.inviteId !== null && inviteAdmits(prior?.invites.find((item) => item.inviteId === attestation.inviteId), attestation, value.authorTimeAfterMs), "AUTHORITY_INVITE_INVALID");
    }
    if (prior !== null && signed.signer !== descriptor.authorityPublicKey && !prior.members.some((member) => member.publicKey === signed.signer && member.administrator)) {
      const grantFor = (item) => {
        if (item.via === "attested") return attestedGrant(prior.admission, item.attestation.payload);
        const invite = prior.invites.find((entry) => entry.inviteId === item.attestation.payload.inviteId);
        check(inviteRedemptions(bundle.memberships.slice(0, revision + 1), invite.inviteId) <= inviteCapacity(invite), "AUTHORITY_INVITE_EXHAUSTED");
        return inviteGrant(invite.role);
      };
      const everMember = new Set(bundle.memberships.slice(0, revision).flatMap((item) => item.payload.members.map((member) => member.publicKey)));
      check(prior.members.some((member) => member.publicKey === signed.signer && member.reader) && prior.admission.mode === "attested" && value.admitted.length > 0 && value.admitted.every((item) => item.via !== "approved" && !everMember.has(item.publicKey)) && value.epoch === prior.epoch && equalRecord(value.admission, prior.admission) && equalRecord(value.invites, prior.invites) && value.members.length === prior.members.length + value.admitted.length && prior.members.every((member, index) => sameGrant(member, value.members[index])) && value.admitted.every((item, index) => sameGrant(value.members[prior.members.length + index], { publicKey: item.publicKey, wrapKey: item.attestation.payload.wrapKey, ...grantFor(item), publisher: false, finalizer: false })), "AUTHORITY_ADMIN_REQUIRED");
    }
    await verifyRecord("membership", signed);
    previous = await recordDigest(signed);
  }
}
function writerAuthorizedAt(authority, publicKey, membershipId, authorTimestampMs, throughRevision = Number.MAX_SAFE_INTEGER) {
  const base = authority.membership(membershipId);
  if (base === null) return null;
  if (authorTimestampMs <= base.authorTimeAfterMs || base.members.find((member) => member.publicKey === publicKey)?.writer !== true) return false;
  for (const successor of authority.bundle().memberships.slice(base.revision + 1)) {
    if (successor.payload.revision > throughRevision || authorTimestampMs <= successor.payload.authorTimeAfterMs) break;
    if (successor.payload.members.find((member) => member.publicKey === publicKey)?.writer !== true) return false;
  }
  return true;
}
function finalizerAuthorizedAt(authority, publicKey, authorityHead, throughMs) {
  const head = authority.membership(authorityHead);
  if (head === null) return null;
  if (head.members.find((member) => member.publicKey === publicKey)?.finalizer !== true) return false;
  for (const successor of authority.bundle().memberships.slice(head.revision + 1)) {
    if (throughMs <= successor.payload.authorTimeAfterMs) break;
    if (successor.payload.members.find((member) => member.publicKey === publicKey)?.finalizer !== true) return false;
  }
  return true;
}
async function epochKeyCommitment(applicationId, epoch, key) {
  hex2(applicationId);
  check(Number.isSafeInteger(epoch) && epoch >= 0 && key.length === 32, "AUTHORITY_EPOCH_KEY_INVALID");
  return recordDigest(["epoch-key", applicationId, epoch, key]);
}
var owners = /* @__PURE__ */ new WeakSet();
async function createAuthorityProvider(options) {
  check(!owners.has(options.store), "AUTHORITY_STORE_BUSY");
  owners.add(options.store);
  try {
    const applicationId = options.bundle?.descriptor.payload.applicationId ?? options.applicationId;
    hex2(applicationId);
    const key = `authority/${applicationId}`, cached = await options.store.get(key);
    let bundle = cached === null ? options.bundle : decodeRecord(cached);
    check(bundle !== void 0, "AUTHORITY_CACHE_MISSING");
    await verifyAuthorityBundle(bundle);
    if (options.bundle !== void 0 && cached !== null) {
      await verifyAuthorityBundle(options.bundle, bundle.descriptor);
      for (let i = 0; i < Math.min(bundle.memberships.length, options.bundle.memberships.length); i++) check(equalRecord(bundle.memberships[i], options.bundle.memberships[i]), "AUTHORITY_CHAIN_FORK");
      if (options.bundle.memberships.length > bundle.memberships.length) bundle = structuredClone(options.bundle);
    }
    await options.store.put(key, encodeRecord(bundle));
    const keys = /* @__PURE__ */ new Map(), listeners = /* @__PURE__ */ new Set();
    const keyBytes = await options.store.get(`${key}/epoch-keys`);
    if (keyBytes !== null) for (const [epoch, bytes2] of decodeRecord(keyBytes)) keys.set(epoch, bytes2);
    const validateKey = async (epoch, bytes2) => {
      check(bytes2 instanceof Uint8Array && bytes2.length === 32 && Number.isSafeInteger(epoch) && epoch >= 0, "AUTHORITY_EPOCH_KEY_INVALID");
      const membership = bundle.memberships.find((item) => item.payload.epoch === epoch);
      check(membership !== void 0 && membership.payload.epochKeyDigest === await epochKeyCommitment(applicationId, epoch, bytes2), "AUTHORITY_EPOCH_KEY_COMMITMENT_MISMATCH");
    };
    for (const [epoch, bytes2] of keys) await validateKey(epoch, bytes2);
    const persistKeys = async () => {
      await options.store.put(`${key}/epoch-keys`, encodeRecord([...keys]));
    };
    for (const [epoch, bytes2] of options.epochKeys ?? []) {
      await validateKey(epoch, bytes2);
      check(!keys.has(epoch) || equalRecord(keys.get(epoch), bytes2), "AUTHORITY_EPOCH_KEY_CONFLICT");
      keys.set(epoch, bytes2.slice());
    }
    if (options.epochKeys !== void 0) await persistKeys();
    const ids = /* @__PURE__ */ new Map();
    const index = async () => {
      ids.clear();
      for (const signed of bundle.memberships) ids.set(await recordDigest(signed), signed.payload);
    };
    await index();
    if (cached === null) await options.store.put(key, encodeRecord(bundle));
    let tail = Promise.resolve();
    const provider = {
      get descriptor() {
        return structuredClone(bundle.descriptor.payload);
      },
      descriptorId: await recordDigest(bundle.descriptor),
      get currentMembershipId() {
        return [...ids.keys()].at(-1);
      },
      get currentMembership() {
        return structuredClone(bundle.memberships.at(-1).payload);
      },
      bundle: () => structuredClone(bundle),
      grant: (publicKey, id2) => structuredClone((id2 === void 0 ? bundle.memberships.at(-1).payload : ids.get(id2))?.members.find((member) => member.publicKey === publicKey) ?? null),
      hasMembership: (id2) => ids.has(id2),
      membership: (id2) => structuredClone(ids.get(id2) ?? null),
      epochKey: (epoch) => keys.get(epoch)?.slice() ?? null,
      installEpochKey(epoch, input) {
        const bytes2 = input.slice();
        const task = tail.then(async () => {
          await validateKey(epoch, bytes2);
          check(!keys.has(epoch) || equalRecord(keys.get(epoch), bytes2), "AUTHORITY_EPOCH_KEY_CONFLICT");
          const next = new Map(keys);
          next.set(epoch, bytes2);
          await options.store.put(`${key}/epoch-keys`, encodeRecord([...next]));
          keys.set(epoch, bytes2);
          for (const listener of listeners) {
            try {
              listener();
            } catch {
            }
          }
        });
        tail = task.catch(() => void 0);
        return task;
      },
      merge(input) {
        const captured = structuredClone(input);
        const task = tail.then(async () => {
          await verifyAuthorityBundle(captured, bundle.descriptor);
          for (let i = 0; i < Math.min(captured.memberships.length, bundle.memberships.length); i++) check(equalRecord(captured.memberships[i], bundle.memberships[i]), "AUTHORITY_CHAIN_FORK");
          if (captured.memberships.length <= bundle.memberships.length) return;
          await options.store.put(key, encodeRecord(captured));
          bundle = captured;
          await index();
          for (const listener of listeners) {
            try {
              listener();
            } catch {
            }
          }
        });
        tail = task.catch(() => void 0);
        return task;
      },
      subscribe(listener) {
        listeners.add(listener);
        return () => {
          listeners.delete(listener);
        };
      }
    };
    if (options.bundle !== void 0 && cached !== null) await provider.merge(options.bundle);
    return provider;
  } finally {
    owners.delete(options.store);
  }
}
function validateEnrollment(request) {
  exactRecord(request, ["applicationId", "publicKey", "wrapKey", "challenge"], "ENROLLMENT_REQUEST_INVALID");
  hex2(request.applicationId);
  hex2(request.publicKey);
  hex2(request.wrapKey);
  check(typeof request.challenge === "string" && request.challenge.length > 0 && request.challenge.length <= 512, "ENROLLMENT_REQUEST_INVALID");
}
async function signEnrollmentRequest(request, identity) {
  validateEnrollment(request);
  check(request.publicKey === identity.publicKey, "ENROLLMENT_REQUEST_INVALID");
  return signRecord("enrollment", request, identity);
}
async function verifyEnrollmentRequest(request) {
  validateEnrollment(request.payload);
  await verifyRecord("enrollment", request, request.payload.publicKey);
}

// packages/authority/src/finality.ts
var isArray2 = (value) => Array.isArray(value);
async function finalityPolicyDigest(policy) {
  return recordDigest(["finality-policy", policy]);
}
async function signFinalityStatement(statement, signer) {
  return signRecord("finality", statement, signer);
}
async function finalityAdmissionScopes(authority) {
  const policy = authority.descriptor.finalityPolicy;
  if (policy.kind === "none") return [];
  const scopes = new Map(policy.scopes.map((scope) => [scope.id, scope]));
  for (const membership of authority.bundle().memberships) {
    const id2 = await recordDigest(membership);
    check(!scopes.has(id2), "FINALITY_SCOPE_COLLISION");
    scopes.set(id2, { id: id2, authorTimeAfterMs: membership.payload.authorTimeAfterMs });
  }
  return [...scopes.values()];
}
async function mergeFinalityProofs(...histories) {
  const statements = /* @__PURE__ */ new Map();
  for (const history of histories) for (const input of history) {
    const proof = structuredClone(input), id2 = await recordDigest(proof.statement);
    check(proof.signatures.length <= 4096, "FINALITY_SIGNATURE_LIMIT");
    let entry = statements.get(id2);
    if (entry === void 0) {
      entry = { statement: proof.statement, signatures: /* @__PURE__ */ new Map() };
      statements.set(id2, entry);
    }
    for (const signature of proof.signatures) {
      check(equalRecord(signature.payload, proof.statement), "FINALITY_SIGNATURE_SCOPE");
      await verifyRecord("finality", signature);
      const prior = entry.signatures.get(signature.signer);
      if (prior === void 0 || signature.signature < prior.signature) entry.signatures.set(signature.signer, signature);
    }
  }
  check(statements.size <= 65536, "FINALITY_PROOF_LIMIT");
  return [...statements.values()].map((entry) => ({ statement: entry.statement, signatures: [...entry.signatures.values()].sort((a, b) => a.signer.localeCompare(b.signer)) })).sort((a, b) => a.statement.scope.localeCompare(b.statement.scope) || a.statement.sequence - b.statement.sequence);
}
async function verifyFinalityProofs(descriptor, input, authority, knownProposals = []) {
  const policy = descriptor.finalityPolicy;
  if (policy.kind === "none") {
    check(input.length === 0, "FINALITY_UNSUPPORTED");
    return { closedThroughMs: null, included: /* @__PURE__ */ new Map(), excludedProposalIds: /* @__PURE__ */ new Set(), proofs: [] };
  }
  check(authority !== void 0, "FINALITY_AUTHORITY_REQUIRED");
  check(equalRecord(descriptor, authority.descriptor), "FINALITY_AUTHORITY_SCOPE_MISMATCH");
  const proofs = await mergeFinalityProofs(input), scopes = await finalityAdmissionScopes(authority), policyDigest = await finalityPolicyDigest(policy);
  const allowed = policy.kind === "signed-frontier" ? [policy.signer] : policy.validators, threshold = policy.kind === "signed-frontier" ? 1 : policy.threshold;
  const heads = /* @__PURE__ */ new Map(), first = /* @__PURE__ */ new Map();
  const candidates = /* @__PURE__ */ new Map(), dependencies = /* @__PURE__ */ new Set(), verifiedProofs = [];
  const candidate = (value) => {
    hex2(value.proposalId);
    hex2(value.membershipId);
    hex2(value.author);
    check(typeof value.authorTimestampMs === "bigint" && value.authorTimestampMs >= 0n && value.authorTimestampMs <= (1n << 63n) - 1n, "FINALITY_INCLUSION_INVALID");
    const prior = candidates.get(value.proposalId);
    check(prior === void 0 || prior.authorTimestampMs === value.authorTimestampMs && prior.membershipId === value.membershipId && prior.author === value.author, "FINALITY_INCLUSION_CONFLICT");
    candidates.set(value.proposalId, value);
  };
  for (const value of knownProposals) candidate(value);
  for (const proof of proofs) {
    const statement = proof.statement, scope = scopes.find((item) => item.id === statement.scope), head = heads.get(statement.scope);
    hex2(statement.scope);
    hex2(statement.authorityHead);
    check(statement.applicationId === descriptor.applicationId && statement.policyDigest === policyDigest, "FINALITY_SCOPE_MISMATCH");
    check(Number.isSafeInteger(statement.sequence) && statement.sequence >= 0 && typeof statement.closedThroughMs === "bigint" && statement.closedThroughMs >= -1n && statement.closedThroughMs <= (1n << 63n) - 1n && isArray2(statement.inclusions) && isArray2(statement.blockers) && statement.inclusions.length <= 65536 && statement.blockers.length <= 65536, "FINALITY_STATEMENT_INVALID");
    check(proof.signatures.length <= allowed.length, "FINALITY_SIGNATURE_LIMIT");
    for (const signature of proof.signatures) check(allowed.includes(signature.signer), "FINALITY_SIGNATURE_SCOPE");
    const headMembership = authority.membership(statement.authorityHead);
    if (headMembership === null) {
      dependencies.add(`authority/${statement.authorityHead}`);
      continue;
    }
    const eligible = proof.signatures.filter((signature) => finalizerAuthorizedAt(authority, signature.signer, statement.authorityHead, statement.closedThroughMs) === true);
    if (eligible.length < threshold) {
      dependencies.add(`quorum/${await recordDigest(statement)}`);
      continue;
    }
    check(scope !== void 0, "FINALITY_SCOPE_MISMATCH");
    {
      const membership = authority.membership(statement.scope);
      check(membership === null || membership.revision <= headMembership.revision, "FINALITY_SCOPE_NOT_ACTIVE");
    }
    if (statement.sequence > (head?.sequence ?? -1) + 1) {
      dependencies.add(`history/${statement.scope}/${(head?.sequence ?? -1) + 1}`);
      continue;
    }
    check(statement.sequence === (head?.sequence ?? -1) + 1 && statement.previous === (head?.id ?? null), "FINALITY_HISTORY_FORK");
    check(statement.closedThroughMs >= (head?.closed ?? scope.authorTimeAfterMs), "FINALITY_CLOSURE_INVALID");
    for (const blocker of statement.blockers) {
      candidate(blocker);
      check(statement.closedThroughMs < blocker.authorTimestampMs, "FINALITY_BLOCKER_NOT_RESPECTED");
    }
    const scopedFirst = first.get(statement.scope) ?? /* @__PURE__ */ new Map();
    first.set(statement.scope, scopedFirst);
    for (const inclusion of statement.inclusions) {
      candidate(inclusion);
      check(inclusion.authorTimestampMs > scope.authorTimeAfterMs, "FINALITY_INCLUSION_INVALID");
      {
        const membership = authority.membership(inclusion.membershipId);
        check(membership !== null && membership.revision <= headMembership.revision && writerAuthorizedAt(authority, inclusion.author, inclusion.membershipId, inclusion.authorTimestampMs, headMembership.revision) === true, "FINALITY_INCLUSION_SCOPE_INVALID");
        check(!authority.hasMembership(statement.scope) || statement.scope === inclusion.membershipId, "FINALITY_INCLUSION_SCOPE_INVALID");
      }
      check(!scopedFirst.has(inclusion.proposalId), "FINALITY_FIRST_INCLUSION_REPEATED");
      scopedFirst.set(inclusion.proposalId, { inclusion, late: inclusion.authorTimestampMs <= (head?.closed ?? scope.authorTimeAfterMs) });
    }
    heads.set(statement.scope, { sequence: statement.sequence, id: await recordDigest(statement), closed: statement.closedThroughMs });
    verifiedProofs.push(proof);
  }
  const memberships = authority.bundle().memberships, membershipIds = await Promise.all(memberships.map((membership) => recordDigest(membership)));
  for (let index = 1; index < memberships.length; index++) {
    const priorScopes = [...policy.scopes, ...memberships.slice(0, index).map((membership, position) => ({ id: membershipIds[position], authorTimeAfterMs: membership.payload.authorTimeAfterMs }))];
    let sealed = (1n << 63n) - 1n;
    for (const scope of priorScopes) {
      const prior = verifiedProofs.filter((proof) => proof.statement.scope === scope.id && (authority.membership(proof.statement.authorityHead)?.revision ?? Infinity) < index).at(-1)?.statement, cutoff = prior?.closedThroughMs ?? scope.authorTimeAfterMs;
      if (cutoff < sealed) sealed = cutoff;
    }
    check(memberships[index].payload.authorTimeAfterMs >= sealed, "FINALITY_MEMBERSHIP_BEHIND_SEAL");
  }
  const included = /* @__PURE__ */ new Map(), excluded = /* @__PURE__ */ new Set();
  for (const value of candidates.values()) {
    const applicable = policy.scopes.filter((scope) => value.authorTimestampMs > scope.authorTimeAfterMs).map((scope) => scope.id);
    {
      if (writerAuthorizedAt(authority, value.author, value.membershipId, value.authorTimestampMs) === false) excluded.add(value.proposalId);
      applicable.push(value.membershipId);
    }
    let complete = applicable.length > 0;
    for (const id2 of applicable) {
      const admission = first.get(id2)?.get(value.proposalId), closed = heads.get(id2)?.closed;
      if (admission?.late === true || admission === void 0 && closed !== void 0 && value.authorTimestampMs <= closed) excluded.add(value.proposalId);
      if (admission === void 0 || admission.late) complete = false;
    }
    if (complete && !excluded.has(value.proposalId)) included.set(value.proposalId, value);
  }
  let closedThroughMs = null;
  for (const scope of scopes) {
    const cutoff = heads.get(scope.id)?.closed ?? scope.authorTimeAfterMs;
    if (closedThroughMs === null || cutoff < closedThroughMs) closedThroughMs = cutoff;
  }
  if (closedThroughMs !== null && closedThroughMs < 0n) closedThroughMs = null;
  return { closedThroughMs, included, excludedProposalIds: excluded, proofs, certifiedProofs: verifiedProofs, pendingDependencies: [...dependencies].sort() };
}

// packages/authority/src/publication.ts
var PUBLICATION_LIMITS = Object.freeze({ files: 128, bytes: 8 * 1024 * 1024, manifestBytes: 256 * 1024, revisions: 4096 });
function path(value) {
  check(typeof value === "string" && value.length > 0 && value.length <= 1024 && !/[\\?#%]/u.test(value) && value.split("/").every((part) => part.length > 0 && part !== "." && part !== ".."), "PUBLICATION_PATH_INVALID");
}
function validatePublicationManifest(value) {
  hex2(value.applicationId);
  hex2(value.membershipId);
  hex2(value.author);
  hex2(value.executionManifestDigest);
  check(typeof value.operationId === "string" && value.operationId.length > 0 && value.operationId.length <= 512 && Number.isSafeInteger(value.revision) && value.revision >= 0, "PUBLICATION_INVALID");
  if (value.previous !== null) hex2(value.previous);
  check(value.previous === null === (value.revision === 0), "PUBLICATION_CHAIN_INVALID");
  path(value.entry);
  check(value.files.length > 0 && value.files.length <= PUBLICATION_LIMITS.files, "PUBLICATION_FILES_LIMIT");
  let previous = "", total = 0;
  for (const file of value.files) {
    path(file.path);
    hex2(file.hash);
    check(file.path > previous && Number.isSafeInteger(file.size) && file.size >= 0 && typeof file.type === "string" && /^[a-z][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*(?:;[ -~]*)?$/iu.test(file.type), "PUBLICATION_FILE_INVALID");
    previous = file.path;
    total += file.size;
  }
  check(total <= PUBLICATION_LIMITS.bytes && value.files.some((file) => file.path === value.entry) && encodeRecord(value).length <= PUBLICATION_LIMITS.manifestBytes, "PUBLICATION_BYTES_LIMIT");
  return structuredClone(value);
}
async function signPublicationManifest(value, identity) {
  const payload = validatePublicationManifest(value);
  check(payload.author === identity.publicKey, "PUBLICATION_SIGNER_MISMATCH");
  const signed = await signRecord("publication", payload, identity);
  return { ...signed, id: await recordDigest(["publication", payload]) };
}
function publicationScope(authority) {
  if ("descriptor" in authority) return { applicationId: authority.descriptor.applicationId, executionManifestDigest: authority.descriptor.executionManifestDigest, grantId: authority.currentMembershipId, publisherKeys: authority.currentMembership.members.filter((member) => member.publisher).map((member) => member.publicKey) };
  return authority;
}
async function verifyPublicationManifest(value, authority) {
  const payload = validatePublicationManifest(value.payload), scope = publicationScope(authority);
  check(payload.applicationId === scope.applicationId && payload.executionManifestDigest === scope.executionManifestDigest, "PUBLICATION_SCOPE_MISMATCH");
  check("descriptor" in authority ? authority.grant(payload.author, payload.membershipId)?.publisher : scope.grantId === payload.membershipId && scope.publisherKeys.includes(payload.author), "PUBLICATION_PUBLISHER_REQUIRED");
  check(value.id === await recordDigest(["publication", payload]), "PUBLICATION_ID_INVALID");
  await verifyRecord("publication", value, payload.author);
}
async function authorizePublication(value, authority, previous) {
  await verifyPublicationManifest(value, authority);
  const scope = publicationScope(authority);
  check(value.payload.membershipId === scope.grantId && scope.publisherKeys.includes(value.payload.author), "PUBLICATION_AUTHORITY_CHANGED");
  check(value.payload.previous === (previous?.id ?? null) && value.payload.revision === (previous === null ? 0 : previous.payload.revision + 1), "PUBLICATION_CONFLICT");
}
async function verifyPublicationAsset(file, bytes2) {
  path(file.path);
  hex2(file.hash);
  const { sha256: sha2564, bytesToHex: bytesToHex3 } = await Promise.resolve().then(() => (init_src(), src_exports));
  check(bytes2.length === file.size && bytesToHex3(await sha2564(bytes2)) === file.hash, "PUBLICATION_ASSET_MISMATCH");
}
async function createPublicationRegistry(options) {
  const key = `authority/${options.authority.descriptor.applicationId}/publications`;
  let tail = Promise.resolve();
  const read = async () => {
    const bytes2 = await options.store.get(key), values = bytes2 === null ? [] : decodeRecord(bytes2);
    check(values.length <= PUBLICATION_LIMITS.revisions, "PUBLICATION_HISTORY_LIMIT");
    for (const [i, value] of values.entries()) {
      await verifyPublicationManifest(value, options.authority);
      check(value.payload.revision === i && value.payload.previous === (values[i - 1]?.id ?? null), "PUBLICATION_CHAIN_INVALID");
    }
    return values;
  };
  return { read, publish(input) {
    const value = structuredClone(input);
    const task = tail.then(async () => {
      const values = await read(), retry = values.find((item) => item.payload.operationId === value.payload.operationId);
      if (retry !== void 0) {
        check(equalRecord(retry, value), "PUBLICATION_OPERATION_REUSED");
        return retry;
      }
      await authorizePublication(value, options.authority, values.at(-1) ?? null);
      check(values.length < PUBLICATION_LIMITS.revisions, "PUBLICATION_HISTORY_LIMIT");
      await options.store.put(key, encodeRecord([...values, value]));
      return structuredClone(value);
    });
    tail = task.catch(() => void 0);
    return task;
  } };
}

// packages/authority/src/participant.ts
async function signParticipantRequest(value, identity) {
  return signRecord("participant-request", value, identity);
}
function createAuthorityParticipant(options) {
  return { async handle(request) {
    await verifyRecord("participant-request", request);
    const value = request.payload, grant = options.authority.grant(request.signer);
    check(value.applicationId === options.authority.descriptor.applicationId && typeof value.requestId === "string" && value.requestId.length > 0 && value.requestId.length <= 128 && grant !== null, "PARTICIPANT_FORBIDDEN");
    switch (value.action) {
      case "authority.read":
        return { requestId: value.requestId, authority: options.authority.bundle() };
      case "publication.read":
        return { requestId: value.requestId, publications: await options.publications.read() };
      case "publication.publish":
        check(grant.publisher && value.publication !== void 0 && value.publication.signer === request.signer, "PARTICIPANT_PUBLISHER_REQUIRED");
        await options.publications.publish(value.publication);
        return { requestId: value.requestId };
      case "finality.read":
        check(options.finality !== void 0, "FINALITY_UNSUPPORTED");
        return { requestId: value.requestId, proofs: await options.finality.read() };
      case "finality.publish":
        check(grant.finalizer && options.finality !== void 0 && value.proof !== void 0, "PARTICIPANT_FINALIZER_REQUIRED");
        await options.finality.publish(value.proof);
        return { requestId: value.requestId };
      default:
        throw new Error("PARTICIPANT_ACTION_UNSUPPORTED");
    }
  } };
}
export {
  PUBLICATION_LIMITS,
  applicationDescriptionDigest,
  attestedAccountAuthorized,
  attestedGrant,
  authorizePublication,
  bytesToHex,
  check,
  checkedApplicationInputSchema,
  createAuthorityParticipant,
  createAuthorityProvider,
  createPublicationRegistry,
  createSigningIdentity,
  decodeRecord,
  encodeRecord,
  epochKeyCommitment,
  equalRecord,
  exportSigningIdentity,
  finalityAdmissionScopes,
  finalityPolicyDigest,
  finalizerAuthorizedAt,
  hex2 as hex,
  hexToBytes,
  importSigningIdentity,
  inviteAdmits,
  inviteCapacity,
  inviteGrant,
  inviteRedemptions,
  mergeFinalityProofs,
  parseApplicationInput,
  recordDigest,
  signAppDescriptor,
  signEnrollmentRequest,
  signFinalityStatement,
  signHostAttestation,
  signMembership,
  signParticipantRequest,
  signPublicationManifest,
  signRecord,
  validateAdmissionPolicy,
  validateApplicationDescription,
  validateDescriptor,
  validateFinalityPolicy,
  validateInvites,
  validatePublicationManifest,
  verifyAuthorityBundle,
  verifyEnrollmentRequest,
  verifyFinalityProofs,
  verifyHostAttestation,
  verifyPublicationAsset,
  verifyPublicationManifest,
  verifyRecord,
  writerAuthorizedAt
};
/*! Bundled license information:

@noble/hashes/esm/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)
*/
