// packages/canonical/src/errors.ts
var CanonicalError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.details = details;
    this.name = "CanonicalError";
  }
  code;
  details;
};

// packages/canonical/src/bytes.ts
var textEncoder = new TextEncoder();
var fatalTextDecoder = new TextDecoder("utf-8", { fatal: true });
function utf8(value) {
  const encoded = textEncoder.encode(value);
  try {
    if (fatalTextDecoder.decode(encoded) !== value) throw new CanonicalError("INVALID_UTF8", "Text contains an unpaired UTF-16 surrogate");
  } catch (error) {
    if (error instanceof CanonicalError) throw error;
    throw new CanonicalError("INVALID_UTF8", "Text cannot be represented as canonical UTF-8");
  }
  return encoded;
}
var hexPairs = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, "0"));
function bytesToHex(value) {
  let result = "";
  for (const byte of value) result += hexPairs[byte];
  return result;
}

// packages/canonical/src/cbor.ts
var DEFAULT_DECODE_LIMITS = Object.freeze({
  maxBytes: 16 * 1024 * 1024,
  maxDepth: 64,
  maxArrayItems: 1e6,
  maxMapItems: 1e5,
  maxTextBytes: 4 * 1024 * 1024,
  maxBlobBytes: 16 * 1024 * 1024
});
var MAX_UINT64 = (1n << 64n) - 1n;

// packages/canonical/src/hash.ts
var HASH_DOMAINS = Object.freeze({
  transaction: "chronolog/transaction",
  schema: "chronolog/schema",
  executionManifest: "chronolog/execution-manifest",
  queryResult: "chronolog/query-result",
  expectation: "chronolog/expectation",
  module: "chronolog/module",
  entropy: "chronolog/entropy",
  platformObject: "chronolog/platform-object",
  genesis: "chronolog/genesis/v1",
  op: "chronolog/op/v1",
  envelope: "chronolog/envelope/v1",
  state: "chronolog/state/v1",
  cas: "chronolog/cas/v1",
  history: "chronolog/history/v1",
  revision: "chronolog/revision/v1"
});
function bufferSource(value) {
  return Uint8Array.from(value).buffer;
}
async function sha256(payload) {
  return new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bufferSource(payload)));
}

// packages/protocol/src/errors.ts
var ProtocolError = class extends Error {
  code;
  details;
  constructor(code, message, details) {
    super(message);
    this.name = "ProtocolError";
    this.code = code;
    this.details = details;
  }
  toJSON() {
    return this.details === void 0 ? { name: this.name, code: this.code, message: this.message } : { name: this.name, code: this.code, message: this.message, details: this.details };
  }
};
function protocolInvariant(condition, code, message, details) {
  if (!condition) throw new ProtocolError(code, message, details);
}

// packages/protocol/src/v2.ts
var CONTROL_TOPICS = Object.freeze([
  "$reducers",
  "$permissions",
  "$keys",
  "$finality",
  "$publications",
  "$signal_policy"
]);
var CONTROL_TOPIC_SET = new Set(CONTROL_TOPICS);
var MAX_EVENT_BYTES = 16384;
function canonicalJson(payload, limits = { maxBytes: 65536, maxNodes: 8192, maxDepth: 32 }) {
  for (const bound of [limits.maxBytes, limits.maxNodes, limits.maxDepth]) {
    protocolInvariant(Number.isSafeInteger(bound) && bound > 0, "SCHEMA_INVALID", "Invalid JSON limits");
  }
  let nodes = 0;
  const visit = (value, depth) => {
    protocolInvariant(depth <= limits.maxDepth && ++nodes <= limits.maxNodes, "SCHEMA_INVALID", "JSON payload is too complex");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "Numbers must be finite");
      return JSON.stringify(Object.is(value, -0) ? 0 : value);
    }
    if (Array.isArray(value)) {
      protocolInvariant(Reflect.ownKeys(value).length === value.length + 1, "SCHEMA_INVALID", "Arrays cannot carry extra properties");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const desc = Object.getOwnPropertyDescriptor(value, i);
        protocolInvariant(desc !== void 0 && "value" in desc && desc.enumerable === true, "SCHEMA_INVALID", "Arrays require dense elements");
        entries.push(visit(desc.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    protocolInvariant(
      typeof value === "object" && value !== null && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null),
      "SCHEMA_INVALID",
      "Payload must contain JSON values"
    );
    const keys = Object.keys(value).sort();
    protocolInvariant(Reflect.ownKeys(value).length === keys.length, "SCHEMA_INVALID", "Objects require enumerable string keys");
    return `{${keys.map((key) => {
      const desc = Object.getOwnPropertyDescriptor(value, key);
      protocolInvariant("value" in desc, "SCHEMA_INVALID", "Accessors are prohibited");
      return `${JSON.stringify(key)}:${visit(desc.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const encoded = visit(payload, 0);
  protocolInvariant(utf8(encoded).length <= limits.maxBytes, "SCHEMA_INVALID", "JSON payload is too large");
  return encoded;
}
function canonicalEventPayload(payload) {
  return canonicalJson(payload, { maxBytes: MAX_EVENT_BYTES, maxNodes: 4096, maxDepth: 32 });
}
var DEFAULT_RUNTIME_MANIFEST = Object.freeze({
  js: "quickjs-ng@0.32.0",
  builtins: Object.freeze({
    "chronolog:crypto": "crypto@1",
    "chronolog:cas": "cas@1",
    "chronolog:sqlite": "sqlite-cas@1#sha256-bbc4674a5dd1d11962a8227ce5f1118e2e6ed7d00163ea92f1f35781caf46936"
  })
});
var DEFAULT_GENESIS_LIMITS = Object.freeze({
  maxMemoryBytes: 64 * 1024 * 1024,
  maxTopicStateBytes: 4 * 1024 * 1024,
  maxUpdatesPerOp: 16
});

// packages/authority/src/codec.ts
function check(condition, code) {
  if (!condition) throw Object.assign(new Error(code), { code });
}
function normalized(value, depth = 0) {
  check(depth < 32, "RECORD_DEPTH_LIMIT");
  if (value instanceof Uint8Array) return { $bytes: bytesToHex(value) };
  if (typeof value === "bigint") return { $integer: value.toString() };
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    check(Number.isSafeInteger(value), "RECORD_INTEGER_INVALID");
    return value;
  }
  if (Array.isArray(value)) return value.map((item) => normalized(item, depth + 1));
  check(value !== null && typeof value === "object" && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null), "RECORD_INVALID");
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, normalized(value[key], depth + 1)]));
}
function encodeRecord(value) {
  const bytes = new TextEncoder().encode(JSON.stringify(normalized(value)));
  check(bytes.length <= 32 * 1024 * 1024, "RECORD_BYTES_LIMIT");
  return bytes;
}
async function recordDigest(value) {
  return bytesToHex(await sha256(encodeRecord(value)));
}

// packages/authority/src/definition.ts
function isArray(value) {
  return Array.isArray(value);
}
function object(value, keys) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), "APPLICATION_DESCRIPTION_INVALID");
}
function parseApplicationInput(schema, value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  const visit = (spec, item, path) => {
    const invalid = () => {
      throw new Error(`APPLICATION_INPUT_INVALID:${path}`);
    };
    if ("anyOf" in spec) {
      for (const option of spec.anyOf) {
        try {
          visit(option, item, path);
          return;
        } catch {
        }
      }
      invalid();
    } else if (spec.type === "null") {
      if (item !== null) invalid();
    } else if (spec.type === "boolean") {
      if (typeof item !== "boolean") invalid();
    } else if (spec.type === "string") {
      if (typeof item !== "string") return invalid();
      const length = [...item].length;
      if (length < (spec.minLength ?? 0) || length > (spec.maxLength ?? 16384) || spec.enum !== void 0 && !spec.enum.includes(item)) invalid();
    } else if (spec.type === "number" || spec.type === "integer") {
      if (typeof item !== "number" || spec.type === "integer" && !Number.isSafeInteger(item) || item < (spec.minimum ?? -Infinity) || item > (spec.maximum ?? Infinity)) invalid();
    } else if (spec.type === "array") {
      if (!Array.isArray(item) || item.length < (spec.minItems ?? 0) || item.length > (spec.maxItems ?? 4096)) return invalid();
      const items = item;
      items.forEach((child, index) => visit(spec.items, child, `${path}[${index}]`));
    } else if (spec.type === "object") {
      if (item === null || typeof item !== "object" || Array.isArray(item)) return invalid();
      const object2 = item;
      for (const name of spec.required ?? []) if (!Object.hasOwn(object2, name)) invalid();
      for (const [name, child] of Object.entries(object2)) {
        if (!Object.hasOwn(spec.properties, name)) invalid();
        visit(spec.properties[name], child, `${path}.${name}`);
      }
    }
  };
  visit(schema, copy, "$");
  return freeze(copy);
}
function checkedApplicationInputSchema(value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  let nodes = 0;
  const visit = (schema, depth) => {
    if (++nodes > 256 || depth > 16 || schema === null || typeof schema !== "object" || Array.isArray(schema)) throw new Error("APPLICATION_SCHEMA_INVALID");
    const keys = /* @__PURE__ */ new Set(["description"]);
    const allow = (...names) => {
      for (const name of names) keys.add(name);
    };
    const bound = (value2, max) => {
      if (value2 !== void 0 && (!Number.isSafeInteger(value2) || value2 < 0 || value2 > max)) throw new Error("APPLICATION_SCHEMA_INVALID");
    };
    if (schema.description !== void 0 && typeof schema.description !== "string") throw new Error("APPLICATION_SCHEMA_INVALID");
    if ("anyOf" in schema) {
      allow("anyOf");
      if (!Array.isArray(schema.anyOf) || schema.anyOf.length < 1 || schema.anyOf.length > 16) throw new Error("APPLICATION_SCHEMA_INVALID");
      const alternatives = schema.anyOf;
      alternatives.forEach((option) => visit(option, depth + 1));
    } else {
      allow("type");
      switch (schema.type) {
        case "string":
          allow("minLength", "maxLength", "enum");
          bound(schema.minLength, 16384);
          bound(schema.maxLength, 16384);
          if ((schema.minLength ?? 0) > (schema.maxLength ?? 16384) || schema.enum !== void 0 && (!Array.isArray(schema.enum) || schema.enum.length === 0 || schema.enum.length > 256 || schema.enum.some((item) => typeof item !== "string"))) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "number":
        case "integer":
          allow("minimum", "maximum");
          if ([schema.minimum, schema.maximum].some((value2) => value2 !== void 0 && !Number.isFinite(value2)) || (schema.minimum ?? -Infinity) > (schema.maximum ?? Infinity)) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "boolean":
        case "null":
          break;
        case "array":
          allow("items", "minItems", "maxItems");
          bound(schema.minItems, 4096);
          bound(schema.maxItems, 4096);
          if ((schema.minItems ?? 0) > (schema.maxItems ?? 4096)) throw new Error("APPLICATION_SCHEMA_INVALID");
          visit(schema.items, depth + 1);
          break;
        case "object":
          allow("properties", "required", "additionalProperties");
          if (schema.properties === null || typeof schema.properties !== "object" || Array.isArray(schema.properties) || schema.additionalProperties !== void 0 && schema.additionalProperties !== false) throw new Error("APPLICATION_SCHEMA_INVALID");
          for (const child of Object.values(schema.properties)) visit(child, depth + 1);
          if (schema.required !== void 0 && (!Array.isArray(schema.required) || schema.required.some((name) => typeof name !== "string" || !Object.hasOwn(schema.properties, name)) || new Set(schema.required).size !== schema.required.length)) {
            throw new Error("APPLICATION_SCHEMA_INVALID");
          }
          Object.assign(schema, { additionalProperties: false });
          break;
        default:
          throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
      }
    }
    if (Object.keys(schema).some((key) => !keys.has(key))) throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
  };
  visit(copy, 0);
  return freeze(copy);
}
function freeze(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
function validateApplicationDescription(value) {
  const bytes = descriptionJson(value);
  check(new TextEncoder().encode(bytes).length <= 262144, "APPLICATION_DESCRIPTION_TOO_LARGE");
  const copy = JSON.parse(bytes);
  object(copy, ["id", "version", "commands", "queries"]);
  for (const text of [copy.id, copy.version]) check(typeof text === "string" && /^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(text), "APPLICATION_DEFINITION_ID_INVALID");
  for (const entries of [copy.commands, copy.queries]) {
    check(isArray(entries) && entries.length <= 128, "APPLICATION_DEFINITION_TOO_LARGE");
    let previous = "";
    for (const entry of entries) {
      object(entry, ["name", "description", "input"]);
      check(typeof entry.name === "string" && /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(entry.name) && !["__proto__", "constructor", "prototype"].includes(entry.name) && entry.name > previous, "APPLICATION_DEFINITION_NAME_INVALID");
      previous = entry.name;
      check(typeof entry.description === "string" && entry.description.length <= 4096, "APPLICATION_DESCRIPTION_INVALID");
      const checked = checkedApplicationInputSchema(entry.input);
      check(canonicalEventPayload(entry.input) === canonicalEventPayload(checked), "APPLICATION_SCHEMA_NOT_CANONICAL");
    }
  }
  return freeze(copy);
}
async function applicationDescriptionDigest(value) {
  const description = validateApplicationDescription(value);
  return recordDigest(["application-description/v1", descriptionJson(description)]);
}
function descriptionJson(value) {
  return canonicalJson(value, { maxBytes: 262144, maxNodes: 65536, maxDepth: 32 });
}
export {
  applicationDescriptionDigest,
  checkedApplicationInputSchema,
  parseApplicationInput,
  validateApplicationDescription
};
