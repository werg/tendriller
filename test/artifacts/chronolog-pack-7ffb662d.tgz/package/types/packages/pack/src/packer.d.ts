import { ContentAddressedStore, type CasPartition, type ChronologBuiltinName, type ChronologPackageNode } from '../../records/src/index.js';
import type { GenesisCasNode } from '../../peer-session/src/index.js';
import { type DeterminismDiagnostic } from './linter.js';
import { type ChronologLockfile } from './lockfile.js';
export declare const ESBUILD_BUILDER_ID = "esbuild-neutral-esm@0.28.2";
export declare const ESBUILD_BUILDER_REF: string;
export interface PackEntryInput {
    /** Absolute or cwd-relative path to an entry .ts/.js file on disk. */
    readonly path?: string;
    /** In-memory entry source (when packing virtual TS/JS reducers without temp files). */
    readonly source?: string;
    /** Optional multi-file virtual files map (relative POSIX path -> TS/JS source). */
    readonly files?: Readonly<Record<string, string>>;
    readonly name?: string;
    readonly version?: string;
    /** Bundle into 1 clean tree-shaken ESM file per package export (default: true). */
    readonly bundle?: boolean;
    /** Explicit package-scoped dependencies (bare specifier -> cas:sha256-...). */
    readonly dependencies?: Readonly<Record<string, string>>;
    /** Explicit capability allowlist (defaults to auto-detected minimal chronolog:* imports). */
    readonly builtins?: readonly ChronologBuiltinName[];
    readonly partition?: CasPartition;
}
export interface PackReducersOptions {
    readonly entries: Readonly<Record<string, string | PackEntryInput>>;
    readonly cwd?: string;
    readonly cas?: ContentAddressedStore;
    /** Determinism lint policy: 'error' (default), 'warn', or 'off'. */
    readonly lint?: 'error' | 'warn' | 'off';
    /** Record chronolog-drv/v1 provenance back-links & canonical source trees (default: true). */
    readonly includeDerivation?: boolean;
    /** Additional bare specifiers to keep external (always keeps chronolog:* and chronolog/* external). */
    readonly external?: readonly string[];
}
export interface PackedEntryResult {
    readonly alias: string;
    readonly pkgHash: string;
    readonly pkgRef: string;
    readonly drvHash?: string;
    readonly drvRef?: string;
    readonly manifest: ChronologPackageNode;
    readonly diagnostics: readonly DeterminismDiagnostic[];
}
export interface PackedBundleResult {
    readonly imports: Readonly<Record<string, string>>;
    readonly casNodes: readonly GenesisCasNode[];
    readonly entries: Readonly<Record<string, PackedEntryResult>>;
    readonly lockfile: ChronologLockfile;
    readonly diagnostics: readonly DeterminismDiagnostic[];
}
/**
 * Deterministically compile, lint, and pack TypeScript/JS reducers (including real npm dependencies)
 * into capability-attenuated `chronolog-pkg/v1` + `chronolog-drv/v1` CAS Merkle-DAGs and a lockfile.
 */
export declare function packReducers(options: PackReducersOptions): Promise<PackedBundleResult>;
/**
 * Ingest a canonical npm/JSR tarball into CAS (verifying optional integrity), deterministically
 * bundle its entry point into a clean tree-shaken ESM `chronolog-pkg/v1`, and record its `chronolog-drv/v1`.
 */
export declare function packNpmTarball(options: {
    readonly tarball: Uint8Array;
    readonly integrity?: string;
    readonly entry?: string;
    readonly name?: string;
    readonly version?: string;
    readonly cas?: ContentAddressedStore;
    readonly lint?: 'error' | 'warn' | 'off';
}): Promise<PackedEntryResult & {
    readonly casNodes: readonly GenesisCasNode[];
    readonly sourceTreeRef: string;
}>;
/**
 * A pure-JS lightweight deterministic builder that executes RIGHT INSIDE QuickJS-NG
 * as a zero-authority `profile: 'quickjs-inline'` chronolog-drv/v1 derivation!
 * Strips simple TypeScript type annotations / `as Type` casts / interfaces and writes
 * the resulting ESM source straight to CAS.
 */
export declare const INLINE_TS_BUILDER_SOURCE: string;
