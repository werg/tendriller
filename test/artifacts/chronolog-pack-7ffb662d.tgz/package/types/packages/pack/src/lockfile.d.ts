import { type ChronologBuiltinName, type ChronologPackageRuntime } from '../../records/src/index.js';
export interface ChronologLockEntry {
    readonly pkgRef: string;
    readonly drvRef?: string;
    readonly runtime: ChronologPackageRuntime;
    readonly builtins: readonly ChronologBuiltinName[];
    readonly dependencies: Readonly<Record<string, string>>;
    readonly integrity?: string;
}
export interface ChronologLockfile {
    readonly format: 'chronolog-lock/v1';
    readonly packages: Readonly<Record<string, ChronologLockEntry>>;
}
export declare function createLockfile(packages: Readonly<Record<string, ChronologLockEntry>>): ChronologLockfile;
export declare function formatLockfile(lockfile: ChronologLockfile): string;
export declare function parseLockfile(raw: string): ChronologLockfile;
