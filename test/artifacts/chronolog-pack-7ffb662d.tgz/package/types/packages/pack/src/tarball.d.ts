import { type CasPartition, type ChronologTreeNode, type ContentAddressedStore } from '../../records/src/index.js';
export interface TarEntry {
    readonly path: string;
    readonly bytes: Uint8Array;
}
/**
 * Deterministically parse a POSIX USTAR/PAX tar (or .tgz/.tar.gz) archive into sorted file entries,
 * stripping all non-deterministic tar metadata (mtime, uid, gid, permissions, uname/gname).
 */
export declare function parseCanonicalTarball(archiveBytes: Uint8Array, options?: {
    readonly stripPrefix?: string;
    readonly integrity?: string;
}): readonly TarEntry[];
/**
 * Ingest an npm/JSR tarball (or uncompressed tar) into CAS as a canonical, reproducible `chronolog-tree/v1`.
 * Identical file contents always produce the exact same `cas:sha256-...` hash regardless of tar timestamps.
 */
export declare function ingestTarballToCas(cas: ContentAddressedStore, archiveBytes: Uint8Array, options?: {
    readonly stripPrefix?: string;
    readonly integrity?: string;
    readonly partition?: CasPartition;
}): Promise<{
    readonly hash: string;
    readonly ref: string;
    readonly tree: ChronologTreeNode;
    readonly fileCount: number;
}>;
/** Helper to construct a deterministic POSIX tar archive from a map of files (useful for tests & packaging). */
export declare function createDeterministicTar(files: Readonly<Record<string, string | Uint8Array>>, prefix?: string): Uint8Array;
