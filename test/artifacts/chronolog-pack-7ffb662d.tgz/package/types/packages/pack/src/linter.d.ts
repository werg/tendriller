import type { ChronologBuiltinName } from '../../records/src/index.js';
export interface DeterminismDiagnostic {
    readonly code: 'nondeterministic:date' | 'nondeterministic:random' | 'nondeterministic:intl' | 'nondeterministic:clock' | 'forbidden:host-io' | 'forbidden:async-reducer';
    readonly file: string;
    readonly line: number;
    readonly column: number;
    readonly message: string;
    readonly suggestion: string;
}
/** Statically lint JS/TS source for non-deterministic or sandbox-forbidden constructs. */
export declare function lintDeterminism(source: string, file?: string): readonly DeterminismDiagnostic[];
/** Auto-detect minimal chronolog:* builtins imported by JS/TS source files. */
export declare function detectRequiredBuiltins(sources: Iterable<string>): readonly ChronologBuiltinName[];
