import { type SignedAuditAttestation, type SignedBuildAttestation } from '../../materializer/src/index.js';
import type { ApplicationOperation, ApplicationSession, SessionCasNode } from '../../peer-session/src/index.js';
import type { JsonValue } from '../../protocol/src/index.js';
import { type ChronologBuiltinName, type ChronologPackageRuntime } from '../../records/src/index.js';
export interface RegistryPackageMatch {
    readonly name: string;
    readonly description: string;
    readonly latestVersion: string;
    readonly publisher: string;
    readonly updatedAt: number;
}
export interface RegistryResolvedPackage {
    readonly name: string;
    readonly version: string;
    readonly pkgRef: string;
    readonly drvRef: string | null;
    readonly runtime: ChronologPackageRuntime;
    readonly builtins: readonly ChronologBuiltinName[];
    readonly describeSchema: JsonValue | null;
    readonly publisher: string;
    readonly publishedAt: number;
    readonly revoked: boolean;
    readonly attestations: readonly {
        readonly kind: 'build' | 'audit';
        readonly verdict: string | null;
        readonly signer: string;
        readonly signature: string;
        readonly drvRef: string | null;
        readonly runtime: string | null;
        readonly notes: string | null;
    }[];
}
/**
 * Ergonomic client wrapper around a dogfooded Chronolog Registry session (`createRegistryGenesis`).
 * Supports publishing packages + CAS DAGs, recording signed build/audit attestations,
 * FTS5 search, version resolution, and one-call verified install into any target ApplicationSession.
 */
export declare class RegistryClient {
    readonly session: ApplicationSession;
    constructor(session: ApplicationSession);
    publish(options: {
        readonly name: string;
        readonly version: string;
        readonly pkgRef: string;
        readonly drvRef?: string;
        readonly runtime?: ChronologPackageRuntime;
        readonly builtins?: readonly ChronologBuiltinName[];
        readonly description?: string;
        readonly describeSchema?: JsonValue;
        readonly casNodes?: readonly SessionCasNode[];
    }): Promise<ApplicationOperation>;
    attestBuild(options: {
        readonly drvRef: string;
        readonly outputRef: string;
        readonly runtime: string;
        readonly signer?: string;
        readonly privateKey?: CryptoKey;
    }): Promise<{
        readonly attestation: SignedBuildAttestation;
        readonly operation: ApplicationOperation;
    }>;
    attestAudit(options: {
        readonly pkgRef: string;
        readonly verdict: 'approved' | 'revoked';
        readonly notes?: string;
        readonly signer?: string;
        readonly privateKey?: CryptoKey;
    }): Promise<{
        readonly attestation: SignedAuditAttestation;
        readonly operation: ApplicationOperation;
    }>;
    search(q: string, limit?: number): Promise<readonly RegistryPackageMatch[]>;
    resolve(name: string, version?: string): Promise<RegistryResolvedPackage | null>;
    resolveByHash(pkgRef: string): Promise<JsonValue>;
    /**
     * Resolve a package from this Registry Chronolog, verify optional attestation policy,
     * transfer its CAS Merkle-DAG subgraph to `targetSession`, and install it into `$reducers`.
     */
    installInto(targetSession: ApplicationSession, options: {
        readonly name: string;
        readonly version?: string;
        readonly alias?: string;
        readonly topics?: Readonly<Record<string, {
            readonly export?: string;
            readonly config?: JsonValue;
        }>>;
        readonly minBuildAttestations?: number;
        readonly requireAudit?: boolean;
        readonly trustedBuilders?: readonly string[];
        readonly trustedAuditors?: readonly string[];
    }): Promise<{
        readonly resolved: RegistryResolvedPackage;
        readonly operation: ApplicationOperation;
    }>;
}
