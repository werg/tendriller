// packages/peer-session/src/worker-application-protocol.ts
var PROTOCOL = "chronolog/peer-session/worker-application/v1";
var MAX_REQUESTS = 64;
var MAX_RELEASES = 16;
var MAX_STREAMS = 16;
var MAX_BYTES = 1048576;
var releasesResource = (method) => method === "projection.close" || method === "view.release";
function bounded(value) {
  const seen = /* @__PURE__ */ new Set();
  let bytes = 0, nodes = 0;
  const visit = (item, depth) => {
    if (++nodes > 65536 || depth > 32 || bytes > MAX_BYTES) throw new Error("APPLICATION_WORKER_MESSAGE_LIMIT");
    if (typeof item === "string") bytes += new TextEncoder().encode(item).length;
    else if (typeof item === "bigint") bytes += item.toString().length;
    else if (item === null || item === void 0 || typeof item === "number" || typeof item === "boolean") bytes += 8;
    else if (item instanceof Uint8Array) bytes += item.byteLength;
    else if (typeof item === "object") {
      if (seen.has(item)) throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
      seen.add(item);
      for (const [key, child] of Object.entries(item)) {
        bytes += new TextEncoder().encode(key).length;
        visit(child, depth + 1);
      }
      seen.delete(item);
    } else throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
    if (bytes > MAX_BYTES) throw new Error("APPLICATION_WORKER_MESSAGE_LIMIT");
  };
  visit(value, 0);
}

export {
  PROTOCOL,
  MAX_REQUESTS,
  MAX_RELEASES,
  MAX_STREAMS,
  releasesResource,
  bounded
};
