import {
  assertAuthorityExtension,
  createSignedAttempt,
  generationStartRoot,
  validateHistoryPoint,
  validatePeerRevision,
  verifyAttempt,
  verifyAuthorityBundle,
  verifyOrderReceipt
} from "./chunk-4SXHXSRR.mjs";
import {
  PEER_MAX_HISTORY_BYTES,
  PEER_MAX_RECORDS,
  PeerGenerationError,
  Serial,
  boundedText,
  bytesDigest,
  check,
  decodePeerValue,
  encodePeerValue,
  hex,
  isArray,
  object,
  peerDigest,
  samePeerValue,
  signPeerValue,
  verifyPeerValue
} from "./chunk-TF4JHBDD.mjs";
import {
  DOMAINS,
  encodeChangeProgram,
  encodeTransactionCore,
  transactionDigest
} from "./chunk-Q44B5CP6.mjs";
import {
  bytesToHex,
  hexToBytes
} from "./chunk-DACCYORU.mjs";

// packages/peer-generation/src/replica.ts
var activeOwners = /* @__PURE__ */ new WeakMap();
var operationKey = (author, operationId) => `${author}\0${operationId}`;
var Replica = class {
  queryCapabilities;
  #options;
  #serial = new Serial();
  #authority;
  #closed = false;
  #disposed = false;
  #ready = false;
  #publishedRevision = null;
  #pendingRecovery = null;
  #journalHead = 0;
  #retainedBytes = 0;
  #heads = /* @__PURE__ */ new Map();
  #records = /* @__PURE__ */ new Map();
  #attempts = /* @__PURE__ */ new Map();
  #operations = /* @__PURE__ */ new Map();
  #receipts = /* @__PURE__ */ new Map();
  #selected = [];
  #selectedIds = /* @__PURE__ */ new Set();
  #lastOutcomes = /* @__PURE__ */ new Map();
  #fenced = /* @__PURE__ */ new Set();
  #coverage = /* @__PURE__ */ new Map();
  #listeners = /* @__PURE__ */ new Set();
  #recoveryListeners = /* @__PURE__ */ new Set();
  #recoveries = [];
  #prefix;
  constructor(options, authority) {
    this.#options = options;
    this.#authority = authority;
    this.queryCapabilities = Object.freeze({ sql: options.materializer.queries.capabilities.sql });
    this.#prefix = `peer-generation/replica/${authority.descriptor.applicationId}`;
  }
  get descriptor() {
    return this.#authority.descriptor;
  }
  get device() {
    return this.#options.device;
  }
  get storageId() {
    return this.#options.storageId;
  }
  get requiredEpochs() {
    return [...new Set(this.#authority.selectedSegments().filter((segment) => segment.cutoff?.sequence !== 0).map((segment) => this.#authority.controlAt(segment.generation.payload.controlRevision).payload.epoch))].sort((a, b) => a - b);
  }
  get authority() {
    return this.#authority.bundle;
  }
  get generation() {
    const generation = this.#authority.current;
    check(generation !== null, "PEER_NO_SELECTED_GENERATION");
    return generation;
  }
  get isCoordinator() {
    return this.generation.payload.coordinator === this.device.publicKey;
  }
  grant(publicKey) {
    this.#assertOpen();
    return this.#authority.grant(publicKey);
  }
  get closed() {
    return this.#closed;
  }
  get ready() {
    return !this.#closed && this.#ready;
  }
  get retainedPoint() {
    this.#assertOpen();
    let point = null;
    for (const segment of this.#authority.selectedSegments()) {
      const head = this.#heads.get(segment.generation.id), records = this.#records.get(segment.generation.id);
      check(head !== void 0 && records !== void 0, "PEER_RECOVERY_PREFIX_INCOMPLETE");
      const requested = segment.cutoff?.sequence ?? head.sequence;
      const through = Math.min(requested, head.sequence);
      if (through > 0) {
        const command = records.get(through)?.command;
        check(command !== void 0, "PEER_HISTORY_INCOMPLETE");
        point = { generation: segment.generation.id, sequence: through, root: command.receipt.root };
      }
      if (through < requested) break;
    }
    return point;
  }
  get revision() {
    this.#assertOpen();
    check(this.#ready && this.#publishedRevision !== null, "PEER_RECOVERING");
    return structuredClone(this.#publishedRevision);
  }
  async initialize() {
    const stored = await this.#options.store.get(`${this.#prefix}/selection`);
    let previous;
    if (stored !== null) {
      const selection = decodePeerValue(stored);
      object(selection, ["authority", "recovery"]);
      previous = await verifyAuthorityBundle(selection.authority, this.#authority.bundle.descriptor);
      if (previous.bundle.generations.length > this.#authority.bundle.generations.length) {
        assertAuthorityExtension(this.#authority, previous);
        this.#authority = previous;
      } else assertAuthorityExtension(previous, this.#authority);
      if (selection.recovery !== null) {
        object(selection.recovery, ["previousGeneration", "generation", "knownAttemptId"]);
        hex(selection.recovery.previousGeneration);
        hex(selection.recovery.generation);
        if (selection.recovery.knownAttemptId !== null) hex(selection.recovery.knownAttemptId);
        check(selection.recovery.generation === previous.current?.id, "PEER_RECOVERY_JOURNAL_INVALID");
        previous.generation(selection.recovery.previousGeneration);
        this.#pendingRecovery = { ...selection.recovery, generation: this.generation.id };
      }
    }
    check(this.#authority.current !== null, "PEER_NO_SELECTED_GENERATION");
    check(
      bytesToHex(this.#options.materializer.queries.executionManifestDigest) === this.descriptor.executionManifestDigest,
      "PEER_EXECUTION_MANIFEST_MISMATCH"
    );
    const journal = await this.#options.store.get(`${this.#prefix}/journal-head`);
    this.#journalHead = journal === null ? 0 : decodePeerValue(journal);
    check(Number.isSafeInteger(this.#journalHead) && this.#journalHead >= 0 && this.#journalHead <= this.#maxRecords, "PEER_JOURNAL_INVALID");
    for (let index = 1; index <= this.#journalHead; index++) {
      const bytes = await this.#options.store.get(`${this.#prefix}/journal/${index}`);
      check(bytes !== null, "PEER_JOURNAL_INCOMPLETE");
      const attempt = decodePeerValue(bytes);
      await verifyAttempt(attempt, this.#authority, this.#options.epochKeys);
      this.#remember(attempt);
    }
    for (const generation of this.#authority.bundle.generations) await this.#loadGeneration(generation, this.#authority);
    const previousGeneration = previous?.current;
    if (previous !== void 0 && previousGeneration !== null && previousGeneration !== void 0 && previousGeneration.id !== this.generation.id && this.#pendingRecovery === null) {
      const known = this.#selectedHistory(previous, false).at(-1)?.command.attempt.id ?? null;
      this.#pendingRecovery = { previousGeneration: previousGeneration.id, generation: this.generation.id, knownAttemptId: known };
    }
    if (this.#pendingRecovery?.knownAttemptId !== void 0 && this.#pendingRecovery.knownAttemptId !== null) {
      check(this.#attempts.has(this.#pendingRecovery.knownAttemptId), "PEER_RECOVERY_JOURNAL_INVALID");
    }
    const recoveryBytes = await this.#options.store.get(`${this.#prefix}/recoveries`);
    if (recoveryBytes !== null) {
      const notices = decodePeerValue(recoveryBytes);
      check(isArray(notices) && notices.length <= 32, "PEER_RECOVERY_JOURNAL_INVALID");
      this.#recoveries.push(...notices);
    }
    await this.#writeSelection(this.#authority, this.#pendingRecovery);
    try {
      await this.#materialize(this.#authority);
      await this.#finishRecovery(false);
    } catch (error) {
      if (!(error instanceof PeerGenerationError) || error.code !== "PEER_RECOVERY_PREFIX_INCOMPLETE") throw error;
    }
  }
  get #maxRecords() {
    return this.#options.maxRecords ?? PEER_MAX_RECORDS;
  }
  #assertOpen() {
    check(!this.#closed, "PEER_REPLICA_CLOSED");
  }
  #fail(error) {
    if (!this.#closed) {
      this.#closed = true;
      this.#ready = false;
      this.#publish();
    }
    throw error;
  }
  #assertReady() {
    this.#assertOpen();
    check(this.#ready, "PEER_RECOVERING");
    check(this.#authority.grant(this.device.publicKey)?.reader === true, "PEER_READER_FORBIDDEN");
  }
  async #checkCurrentKey() {
    const control = this.#authority.control, key = this.#options.epochKeys.get(control.payload.epoch);
    check(key !== void 0, "PEER_EPOCH_KEY_UNAVAILABLE");
    check(key.length === 32 && await bytesDigest(key) === control.payload.keyDigest, "PEER_EPOCH_KEY_MISMATCH");
  }
  async #write(key, bytes) {
    try {
      await this.#options.store.put(key, bytes);
    } catch (error) {
      this.#fail(error);
    }
  }
  #writeSelection(authority, recovery) {
    return this.#write(`${this.#prefix}/selection`, encodePeerValue({ authority: authority.bundle, recovery }));
  }
  #remember(attempt) {
    const key = operationKey(attempt.payload.header.author, attempt.payload.header.operationId);
    const previous = this.#operations.get(key);
    check(previous === void 0 || previous === attempt.id, "PEER_OPERATION_ID_REUSED");
    this.#operations.set(key, attempt.id);
    this.#attempts.set(attempt.id, structuredClone(attempt));
  }
  async #loadGeneration(generation, authority) {
    if (this.#heads.has(generation.id)) return;
    const start = await generationStartRoot(generation);
    const bytes = await this.#options.store.get(`${this.#prefix}/head/${generation.id}`);
    const head = bytes === null ? { sequence: 0, root: start, bytes: 0 } : decodePeerValue(bytes);
    check(Number.isSafeInteger(head.sequence) && head.sequence >= 0 && head.sequence <= this.#maxRecords && Number.isSafeInteger(head.bytes) && head.bytes >= 0, "PEER_HEAD_INVALID");
    this.#heads.set(generation.id, { sequence: 0, root: start, bytes: 0 });
    this.#records.set(generation.id, /* @__PURE__ */ new Map());
    for (let index = 1; index <= head.sequence; index++) {
      const retained = await this.#options.store.get(`${this.#prefix}/record/${generation.id}/${index}`);
      check(retained !== null, "PEER_HISTORY_INCOMPLETE");
      await this.#retain(decodePeerValue(retained), authority, false);
      const command = this.#records.get(generation.id).get(index).command;
      const resultBytes = await this.#options.store.get(`${this.#prefix}/result/${command.attempt.id}`);
      if (resultBytes !== null) {
        const result = decodePeerValue(resultBytes);
        check(result.status === "applied" && result.attemptId === command.attempt.id && result.generation === generation.id && result.sequence === index && result.operationId === command.receipt.payload.operationId && result.author === command.receipt.payload.author && (result.outcome === "accepted" || result.outcome === "rejected"), "PEER_RESULT_JOURNAL_INVALID");
        this.#lastOutcomes.set(command.attempt.id, result);
      }
    }
    check(samePeerValue(this.#heads.get(generation.id), head), "PEER_HEAD_ROOT_MISMATCH");
    if (await this.#options.store.get(`${this.#prefix}/fence/${generation.id}`) !== null) this.#fenced.add(generation.id);
  }
  async #retain(command, authority, persist) {
    const { receipt, attempt } = command, generation = authority.generation(receipt.payload.generation);
    await verifyOrderReceipt(receipt, generation, this.descriptor);
    const core = await verifyAttempt(attempt, authority, this.#options.epochKeys);
    check(
      receipt.payload.attemptId === attempt.id && receipt.payload.author === attempt.payload.header.author && receipt.payload.operationId === attempt.payload.header.operationId && receipt.payload.generation === attempt.payload.header.generation && receipt.payload.bodyHash === await bytesDigest(encodePeerValue(attempt)) && receipt.payload.bodyBytes === encodePeerValue(attempt).length,
      "PEER_ORDER_BODY_MISMATCH"
    );
    const entries = this.#records.get(generation.id), head = this.#heads.get(generation.id);
    check(entries !== void 0 && head !== void 0, "PEER_GENERATION_NOT_LOADED");
    const previous = entries.get(receipt.payload.sequence);
    if (previous !== void 0) {
      if (previous.command.receipt.root !== receipt.root) {
        this.#fenced.add(generation.id);
        if (persist) await this.#write(`${this.#prefix}/fence/${generation.id}`, encodePeerValue(receipt));
        throw new PeerGenerationError("PEER_COORDINATOR_EQUIVOCATION");
      }
      check(samePeerValue(previous.command, command), "PEER_ORDER_IDENTITY_CONFLICT");
      return;
    }
    check(receipt.payload.sequence === head.sequence + 1 && receipt.payload.previousRoot === head.root, "PEER_HISTORY_GAP");
    const recordBytes = encodePeerValue(command);
    check(this.#receipts.size < this.#maxRecords && this.#retainedBytes + recordBytes.length + 2 <= (this.#options.maxHistoryBytes ?? PEER_MAX_HISTORY_BYTES), "PEER_STORAGE_QUOTA");
    const key = operationKey(receipt.payload.author, receipt.payload.operationId), existing = this.#operations.get(key);
    check(existing === void 0 || existing === attempt.id, "PEER_OPERATION_ID_REUSED");
    const knownOrder = this.#receipts.get(attempt.id);
    check(knownOrder === void 0 || samePeerValue(knownOrder.receipt, receipt), "PEER_ATTEMPT_ORDERED_TWICE");
    const next = { sequence: receipt.payload.sequence, root: receipt.root, bytes: head.bytes + receipt.payload.bodyBytes };
    if (persist) {
      await this.#write(`${this.#prefix}/record/${generation.id}/${next.sequence}`, recordBytes);
      await this.#write(`${this.#prefix}/head/${generation.id}`, encodePeerValue(next));
    }
    this.#heads.set(generation.id, next);
    entries.set(next.sequence, { command: structuredClone(command), proposal: {
      txId: hexToBytes(attempt.id),
      candidateDigest: hexToBytes(attempt.payload.header.coreDigest),
      canonicalCandidate: encodeTransactionCore(core),
      core
    } });
    this.#remember(attempt);
    this.#receipts.set(attempt.id, structuredClone(command));
    this.#retainedBytes += recordBytes.length + 2;
  }
  /** Describe retained selected segments without visiting their individual records. */
  #selectedRanges(authority, complete = true) {
    const ranges = [];
    let offset = 0;
    for (const segment of authority.selectedSegments()) {
      const head = this.#heads.get(segment.generation.id), records = this.#records.get(segment.generation.id);
      check(head !== void 0 && records !== void 0, "PEER_RECOVERY_PREFIX_INCOMPLETE");
      const requested = segment.cutoff?.sequence ?? head.sequence;
      if (complete) check(requested <= head.sequence, "PEER_RECOVERY_PREFIX_INCOMPLETE");
      const through = Math.min(requested, head.sequence);
      if (segment.cutoff !== null && requested <= head.sequence) {
        const root = through === 0 ? records.get(1)?.command.receipt.payload.previousRoot ?? head.root : records.get(through)?.command.receipt.root;
        check(root === segment.cutoff.root, "PEER_RECOVERY_PREFIX_INCOMPLETE");
      }
      ranges.push({ generation: segment.generation.id, offset, length: through, records });
      offset += through;
      if (through < requested) break;
    }
    return ranges;
  }
  #selectedHistory(authority, complete = true) {
    const result = [];
    for (const range of this.#selectedRanges(authority, complete)) {
      for (let sequence = 1; sequence <= range.length; sequence++) {
        const retained = range.records.get(sequence);
        check(retained !== void 0, "PEER_RECOVERY_PREFIX_INCOMPLETE");
        result.push(retained);
      }
    }
    return result;
  }
  async #materialize(authority) {
    const generation = authority.current, head = this.#heads.get(generation.id), published = this.#publishedRevision;
    const continuing = this.#ready && published !== null && published.generation === generation.id && published.controlRevision === generation.payload.controlRevision;
    let selected;
    if (continuing) {
      check(head.sequence >= published.point.sequence, "PEER_HISTORY_REGRESSION");
      if (head.sequence === published.point.sequence) {
        check(head.root === published.point.root, "PEER_HEAD_ROOT_MISMATCH");
        return;
      }
      selected = this.#selected.slice();
      const records = this.#records.get(generation.id);
      for (let sequence = published.point.sequence + 1; sequence <= head.sequence; sequence++) {
        const retained = records.get(sequence);
        check(retained !== void 0, "PEER_RECOVERY_PREFIX_INCOMPLETE");
        selected.push(retained);
      }
    } else selected = this.#selectedHistory(authority);
    const previousLength = this.#selected.length;
    await this.#replay(selected, authority, continuing);
    this.#authority = authority;
    this.#selected = selected;
    if (continuing) for (let index = previousLength; index < selected.length; index++) this.#selectedIds.add(selected[index].command.attempt.id);
    else this.#selectedIds = new Set(selected.map((value) => value.command.attempt.id));
    this.#publishedRevision = {
      applicationId: authority.descriptor.applicationId,
      historyId: authority.descriptor.historyId,
      generation: generation.id,
      point: { generation: generation.id, sequence: head.sequence, root: head.root },
      controlRevision: generation.payload.controlRevision,
      materializationRevision: String(this.#options.materializer.queries.revision)
    };
    this.#ready = true;
  }
  /** Replay also validates a recovery candidate without publishing it as the selected application view. */
  async #replay(selected, authority, continuing = false) {
    const admitted = selected.map((value) => value.proposal);
    const controls = {
      applicationId: hexToBytes(authority.descriptor.applicationId),
      currentRevision: authority.current.payload.controlRevision,
      revisions: await Promise.all(authority.bundle.controls.map(async (control) => ({
        revision: control.payload.revision,
        digest: hexToBytes(await peerDigest(control)),
        members: control.payload.grants.flatMap((grant) => grant.dataRole === null ? [] : [{ publicKey: hexToBytes(grant.publicKey), role: grant.dataRole }])
      })))
    };
    const output = await this.#options.materializer.coordinator.materialize(admitted, controls);
    if (output !== null) await this.#options.materializer.publications.publish(output.publication);
    const previousLength = this.#selected.length, changedFrom = output?.revision.earliestChangedOrderIndex ?? previousLength;
    check(Number.isSafeInteger(changedFrom) && changedFrom >= 0 && (output === null || changedFrom <= selected.length), "PEER_MATERIALIZATION_BOUNDARY_INVALID");
    const inspectFrom = continuing ? Math.min(previousLength, changedFrom) : 0;
    for (const item of selected.slice(inspectFrom)) {
      const { receipt, attempt } = item.command;
      const outcome = this.#options.materializer.queries.outcome(hexToBytes(attempt.id));
      check(outcome !== null, "PEER_OUTCOME_MISSING");
      const result = {
        status: "applied",
        attemptId: attempt.id,
        operationId: receipt.payload.operationId,
        author: receipt.payload.author,
        generation: receipt.payload.generation,
        sequence: receipt.payload.sequence,
        outcome: outcome.outcome,
        rejectionCode: outcome.rejectionCode
      };
      const previous = this.#lastOutcomes.get(attempt.id);
      check(previous === void 0 || samePeerValue(previous, result), "PEER_REPLAY_OUTCOME_CONFLICT");
      if (previous === void 0) await this.#write(`${this.#prefix}/result/${attempt.id}`, encodePeerValue(result));
      this.#lastOutcomes.set(attempt.id, result);
    }
  }
  async #finishRecovery(notify) {
    const pending = this.#pendingRecovery;
    if (pending === null) return null;
    let notice = this.#recoveries.find((value) => value.previousGeneration === pending.previousGeneration && value.generation === pending.generation);
    if (notice === void 0) {
      const abandoned = [];
      for (const [id, attempt] of this.#attempts) {
        if (!this.#selectedIds.has(id) && attempt.payload.header.generation !== this.generation.id) abandoned.push(this.#state(attempt));
      }
      notice = {
        previousGeneration: pending.previousGeneration,
        generation: pending.generation,
        adopted: this.generation.payload.adopted,
        revision: this.revision,
        abandoned: abandoned.slice(0, 1024),
        unknownLoss: true
      };
      const recoveries = [...this.#recoveries, structuredClone(notice)].slice(-32);
      await this.#write(`${this.#prefix}/recoveries`, encodePeerValue(recoveries));
      this.#recoveries.splice(0, this.#recoveries.length, ...recoveries);
    }
    await this.#writeSelection(this.#authority, null);
    this.#pendingRecovery = null;
    if (notify) {
      for (const listener of [...this.#recoveryListeners]) {
        try {
          listener(structuredClone(notice));
        } catch {
        }
      }
    }
    return structuredClone(notice);
  }
  #publish() {
    for (const listener of [...this.#listeners]) {
      try {
        listener();
      } catch {
      }
    }
  }
  #pointAvailable(point, authority = this.#authority) {
    if (!authority.contains(point)) return false;
    const head = this.#heads.get(point.generation), records = this.#records.get(point.generation);
    if (head === void 0 || records === void 0 || point.sequence > head.sequence) return false;
    const root = point.sequence === 0 ? records.get(1)?.command.receipt.payload.previousRoot ?? head.root : records.get(point.sequence)?.command.receipt.root;
    return root === point.root;
  }
  #checkView(revision) {
    validatePeerRevision(revision);
    check(revision.applicationId === this.descriptor.applicationId && revision.historyId === this.descriptor.historyId && this.#pointAvailable(revision.point), "PEER_VIEW_RECOVERY_REQUIRED");
  }
  prepare(input) {
    const captured = structuredClone(input);
    return this.#serial.run(async () => {
      this.#assertReady();
      boundedText(captured.operationId);
      const previousId = this.#operations.get(operationKey(this.device.publicKey, captured.operationId));
      if (previousId !== void 0) {
        const previous = this.#attempts.get(previousId), core2 = await verifyAttempt(previous, this.#authority, this.#options.epochKeys);
        check(bytesToHex(encodeChangeProgram(core2.program)) === bytesToHex(encodeChangeProgram(captured.program)) && previous.payload.header.command === (captured.command ?? "raw") && previous.payload.header.commandVersion === (captured.commandVersion ?? "1") && previous.payload.header.reapplyOf === (captured.reapplyOf ?? null) && (captured.basedOn === void 0 || samePeerValue(previous.payload.header.basedOn, captured.basedOn)), "PEER_OPERATION_ID_REUSED");
        return structuredClone(previous);
      }
      const generation = this.generation, control = this.#authority.controlAt(generation.payload.controlRevision);
      check(this.#authority.grant(this.device.publicKey, control.payload.revision)?.writer === true, "PEER_AUTHOR_FORBIDDEN");
      if (captured.basedOn !== void 0) this.#checkView(captured.basedOn);
      if (captured.reapplyOf !== void 0) {
        const old = this.#attempts.get(captured.reapplyOf);
        check(old !== void 0 && !this.#selectedIds.has(old.id) && old.payload.header.generation !== generation.id, "PEER_REAPPLY_SOURCE_INVALID");
      }
      const key = this.#options.epochKeys.get(control.payload.epoch);
      check(key !== void 0, "PEER_EPOCH_KEY_UNAVAILABLE");
      const core = {
        operationId: captured.operationId,
        groupId: hexToBytes(this.descriptor.applicationId),
        membershipRevision: hexToBytes(await peerDigest(control)),
        validationPolicy: hexToBytes(await peerDigest([this.descriptor.profile, this.descriptor.policy])),
        authorId: hexToBytes(this.device.publicKey),
        authorTimestampMs: captured.authorTimestampMs ?? BigInt(this.#now()),
        nonce: crypto.getRandomValues(new Uint8Array(16)),
        executionManifestDigest: hexToBytes(this.descriptor.executionManifestDigest),
        program: captured.program
      };
      const attempt = await createSignedAttempt({
        applicationId: this.descriptor.applicationId,
        profile: "peer-generation-v1",
        generation: generation.id,
        controlRevision: control.payload.revision,
        epoch: control.payload.epoch,
        author: this.device.publicKey,
        operationId: captured.operationId,
        definitionDigest: this.descriptor.definitionDigest,
        command: captured.command ?? "raw",
        commandVersion: captured.commandVersion ?? "1",
        basedOn: captured.basedOn ?? null,
        reapplyOf: captured.reapplyOf ?? null,
        coreDigest: bytesToHex(await transactionDigest(core))
      }, core, key, this.device);
      await verifyAttempt(attempt, this.#authority, this.#options.epochKeys);
      check(this.#journalHead < this.#maxRecords, "PEER_STORAGE_QUOTA");
      await this.#write(`${this.#prefix}/journal/${this.#journalHead + 1}`, encodePeerValue(attempt));
      await this.#write(`${this.#prefix}/journal-head`, encodePeerValue(this.#journalHead + 1));
      this.#journalHead++;
      this.#remember(attempt);
      this.#publish();
      return structuredClone(attempt);
    });
  }
  order(input) {
    const attempt = structuredClone(input);
    return this.#serial.run(async () => {
      this.#assertReady();
      check(this.isCoordinator, "PEER_NOT_COORDINATOR");
      check(!this.#fenced.has(this.generation.id), "PEER_COORDINATOR_FENCED");
      await verifyAttempt(attempt, this.#authority, this.#options.epochKeys);
      const existing = this.#receipts.get(attempt.id);
      if (existing !== void 0) {
        check(this.#selectedIds.has(attempt.id), "PEER_ATTEMPT_ABANDONED");
        return structuredClone(existing);
      }
      check(attempt.payload.header.generation === this.generation.id, "PEER_ATTEMPT_NEEDS_REAPPLY");
      if (attempt.payload.header.basedOn !== null) this.#checkView(attempt.payload.header.basedOn);
      const head = this.#heads.get(this.generation.id);
      const payload = {
        applicationId: this.descriptor.applicationId,
        profile: "peer-generation-v1",
        generation: this.generation.id,
        sequence: head.sequence + 1,
        previousRoot: head.root,
        attemptId: attempt.id,
        author: attempt.payload.header.author,
        operationId: attempt.payload.header.operationId,
        bodyHash: await bytesDigest(encodePeerValue(attempt)),
        bodyBytes: encodePeerValue(attempt).length
      };
      const receipt = { ...await signPeerValue(DOMAINS.peerOrder, payload, this.device), root: await peerDigest(["chronolog/peer-generation/order/v1", payload]) };
      const command = { receipt, attempt };
      await this.#retain(command, this.#authority, true);
      try {
        await this.#materialize(this.#authority);
      } catch (error) {
        this.#fail(error);
      }
      this.#publish();
      return structuredClone(command);
    });
  }
  ingest(input) {
    const commands = structuredClone(input);
    return this.#serial.run(async () => {
      this.#assertOpen();
      check(commands.length <= 4096, "PEER_REPLICATION_BATCH_LIMIT");
      for (const command of commands) await this.#retain(command, this.#authority, true);
      try {
        await this.#materialize(this.#authority);
      } catch (error) {
        if (!(error instanceof PeerGenerationError) || error.code !== "PEER_RECOVERY_PREFIX_INCOMPLETE") this.#fail(error);
        throw error;
      }
      await this.#finishRecovery(true);
      this.#publish();
    });
  }
  adopt(authority) {
    return this.synchronize(authority, []);
  }
  async synchronize(input, inputCommands, options = {}) {
    const result = await this.#receive(input, inputCommands, options);
    check(result.ready, "PEER_RECOVERY_PREFIX_INCOMPLETE");
    return result.recovery;
  }
  receiveHistory(input, inputCommands) {
    return this.#receive(input, inputCommands);
  }
  async #receive(input, inputCommands, options = {}) {
    const bundle = structuredClone(input), at = structuredClone(options.at);
    const commands = isArray(inputCommands) ? structuredClone(inputCommands) : inputCommands;
    const next = await verifyAuthorityBundle(bundle, this.#authority.bundle.descriptor);
    if (at !== void 0) {
      validatePeerRevision(at);
      check(
        at.applicationId === this.descriptor.applicationId && at.historyId === this.descriptor.historyId && at.generation === next.current?.id && at.point.generation === at.generation && at.controlRevision === next.current.payload.controlRevision,
        "PEER_REPLICATION_TARGET_INVALID"
      );
    }
    await this.#serial.run(async () => {
      this.#assertOpen();
      assertAuthorityExtension(this.#authority, next);
      const previous = this.generation;
      if (previous.id !== next.current.id) {
        const pending = this.#pendingRecovery === null ? { previousGeneration: previous.id, generation: next.current.id, knownAttemptId: this.#selected.at(-1)?.command.attempt.id ?? null } : { ...this.#pendingRecovery, generation: next.current.id };
        await this.#writeSelection(next, pending);
        this.#authority = next;
        this.#pendingRecovery = pending;
        this.#ready = false;
        this.#coverage.clear();
        this.#publish();
      } else if (!samePeerValue(this.#authority.bundle, next.bundle)) {
        await this.#writeSelection(next, this.#pendingRecovery);
        this.#authority = next;
      }
      for (const generation of next.bundle.generations) await this.#loadGeneration(generation, next);
    });
    let count = 0;
    for await (const inputPage of replicationPages(commands)) {
      check(isArray(inputPage) && inputPage.length > 0 && inputPage.length <= PEER_MAX_RECORDS, "PEER_REPLICATION_BATCH_LIMIT");
      count += inputPage.length;
      check(count <= this.#maxRecords, "PEER_REPLICATION_BATCH_LIMIT");
      const page = structuredClone(inputPage);
      await this.#serial.run(async () => {
        this.#assertOpen();
        assertAuthorityExtension(this.#authority, next);
        for (const command of page) await this.#retain(command, next, true);
      });
    }
    return this.#serial.run(async () => {
      this.#assertOpen();
      assertAuthorityExtension(this.#authority, next);
      if (at !== void 0) check(this.#pointAvailable(at.point, next), "PEER_REPLICATION_TARGET_INCOMPLETE");
      try {
        await this.#materialize(next);
      } catch (error) {
        if (error instanceof PeerGenerationError && error.code === "PEER_RECOVERY_PREFIX_INCOMPLETE") {
          this.#publish();
          return { ready: false, recovery: null };
        }
        this.#fail(error);
      }
      const recovery = await this.#finishRecovery(true);
      this.#publish();
      return { ready: true, recovery };
    });
  }
  #state(attempt) {
    const header = attempt.payload.header, previous = this.#lastOutcomes.get(attempt.id);
    if (this.#selectedIds.has(attempt.id)) {
      check(previous !== void 0, "PEER_OUTCOME_MISSING");
      return structuredClone(previous);
    }
    if (header.generation === this.generation.id) return { status: "saved", attemptId: attempt.id, operationId: header.operationId, generation: header.generation };
    return {
      status: this.#receipts.has(attempt.id) ? "abandoned" : "needsReapply",
      attemptId: attempt.id,
      operationId: header.operationId,
      generation: header.generation,
      selectedGeneration: this.generation.id,
      previous: structuredClone(previous ?? null)
    };
  }
  operation(operationId, author = this.device.publicKey) {
    return this.#serial.run(async () => {
      this.#assertReady();
      const id = this.#operations.get(operationKey(author, operationId));
      return id === void 0 ? null : this.#state(this.#attempts.get(id));
    });
  }
  attempt(operationId, author = this.device.publicKey) {
    return this.#serial.run(async () => {
      this.#assertOpen();
      const id = this.#operations.get(operationKey(author, operationId));
      return structuredClone(id === void 0 ? null : this.#attempts.get(id));
    });
  }
  pendingAttempts() {
    return this.#serial.run(async () => {
      this.#assertOpen();
      return [...this.#attempts.values()].filter((value) => value.payload.header.generation === this.generation.id && !this.#receipts.has(value.id)).map((value) => structuredClone(value));
    });
  }
  capture() {
    return this.#serial.run(async () => {
      this.#assertReady();
      check(this.#options.materializer.queries.captureRead !== void 0, "PEER_CAPTURE_UNSUPPORTED");
      const read = this.#options.materializer.queries.captureRead({ view: "local" });
      return { authority: this.authority, revision: this.revision, read, release: () => read.release() };
    });
  }
  async #proof(point) {
    validateHistoryPoint(point);
    check(this.#pointAvailable(point), "PEER_RECOVERY_PREFIX_INCOMPLETE");
    const records = this.#records.get(point.generation), segment = this.#authority.selectedSegments().find((value) => value.generation.id === point.generation);
    const receipt = point.sequence === 0 ? null : records.get(point.sequence).command.receipt;
    const length = segment.cutoff === null ? 0 : segment.cutoff.sequence - point.sequence;
    check(length <= 4096, "PEER_PREFIX_PROOF_TOO_LARGE");
    const bridge = Array.from({ length }, (_, index) => {
      const retained = records.get(point.sequence + index + 1);
      check(retained !== void 0, "PEER_RECOVERY_PREFIX_INCOMPLETE");
      return retained.command.receipt;
    });
    return structuredClone({ point, receipt, bridge });
  }
  recoveryPoint() {
    return this.#serial.run(async () => {
      this.#assertOpen();
      check(this.#authority.grant(this.device.publicKey)?.reader === true, "PEER_READER_FORBIDDEN");
      await this.#checkCurrentKey();
      if (this.#ready) return this.#proof(this.revision.point);
      const selected = [], segments = this.#authority.selectedSegments();
      let point = null;
      for (const [index, range] of this.#selectedRanges(this.#authority, false).entries()) {
        const segment = segments[index];
        if (segment.cutoff !== null && range.length < segment.cutoff.sequence) break;
        for (let sequence = 1; sequence <= range.length; sequence++) {
          const retained = range.records.get(sequence);
          check(retained !== void 0, "PEER_RECOVERY_PREFIX_INCOMPLETE");
          selected.push(retained);
        }
        const head = this.#heads.get(range.generation);
        point = segment.cutoff ?? { generation: range.generation, sequence: head.sequence, root: head.root };
      }
      check(point !== null && selected.length > 0, "PEER_RECOVERY_PREFIX_INCOMPLETE");
      const proof = await this.#proof(point);
      await this.#authority.verifyPrefix(proof);
      const floor = this.#authority.control.payload.recoveryFloor;
      check(floor === null || this.#authority.atOrAfter(point, floor), "PEER_RECOVERY_FLOOR_UNAVAILABLE");
      await this.#replay(selected, this.#authority);
      return proof;
    });
  }
  prefixProof(point) {
    return this.#serial.run(async () => {
      this.#assertReady();
      return this.#proof(point);
    });
  }
  exportCommands(options = {}) {
    return this.#serial.run(async () => {
      this.#assertOpen();
      check(this.#authority.grant(this.device.publicKey)?.reader === true, "PEER_READER_FORBIDDEN");
      const ranges = this.#selectedRanges(this.#authority, false), last = ranges.at(-1);
      let start = 0, end = last === void 0 ? 0 : last.offset + last.length;
      if (options.at !== void 0) {
        this.#assertReady();
        this.#checkView(options.at);
        check(options.at.generation === this.generation.id && options.at.point.generation === this.generation.id, "PEER_VIEW_RECOVERY_REQUIRED");
        end -= this.#heads.get(this.generation.id).sequence - options.at.point.sequence;
      }
      if (options.offset !== void 0) {
        check(options.after === void 0 && Number.isSafeInteger(options.offset) && options.offset >= 0 && options.offset <= end, "PEER_RANGE_OFFSET_INVALID");
        start = options.offset;
      }
      if (options.after !== void 0) {
        check(this.#pointAvailable(options.after), "PEER_CURSOR_RECOVERY_REQUIRED");
        const range = ranges.find((value) => value.generation === options.after.generation);
        check(options.after.sequence === 0 || range !== void 0 && options.after.sequence <= range.length, "PEER_CURSOR_RECOVERY_REQUIRED");
        start = range === void 0 ? end : range.offset + options.after.sequence;
      }
      const limit = options.limit ?? this.#maxRecords;
      check(Number.isSafeInteger(limit) && limit > 0 && limit <= this.#maxRecords, "PEER_RANGE_LIMIT_INVALID");
      const maxBytes = options.maxBytes ?? Number.MAX_SAFE_INTEGER;
      check(Number.isSafeInteger(maxBytes) && maxBytes > 0, "PEER_RANGE_BYTES_INVALID");
      const result = [];
      const through = Math.min(end, start + limit);
      let bytes = 0;
      for (const range of ranges) {
        const first = Math.max(1, start - range.offset + 1), last2 = Math.min(range.length, through - range.offset);
        for (let sequence = first; sequence <= last2; sequence++) {
          const value = range.records.get(sequence);
          check(value !== void 0, "PEER_RECOVERY_PREFIX_INCOMPLETE");
          const size = encodePeerValue(value.command).byteLength;
          if (bytes + size > maxBytes) {
            check(result.length > 0, "PEER_RANGE_RECORD_TOO_LARGE");
            return result;
          }
          bytes += size;
          result.push(structuredClone(value.command));
        }
      }
      return result;
    });
  }
  retainedCoverage(point) {
    const requested = point === void 0 ? void 0 : structuredClone(point);
    return this.#serial.run(async () => {
      this.#assertOpen();
      check(this.#authority.grant(this.device.publicKey)?.reader === true, "PEER_READER_FORBIDDEN");
      const retained = requested ?? this.revision.point;
      validateHistoryPoint(retained);
      check(this.#pointAvailable(retained), "PEER_RECOVERY_PREFIX_INCOMPLETE");
      await this.#checkCurrentKey();
      return signPeerValue(DOMAINS.peerCoverage, {
        applicationId: this.descriptor.applicationId,
        generation: this.generation.id,
        point: retained,
        peer: this.device.publicKey,
        storageId: this.#options.storageId,
        retainedAt: this.#now()
      }, this.device);
    });
  }
  observeCoverage(input) {
    const coverage = structuredClone(input);
    return this.#serial.run(async () => {
      this.#assertReady();
      const value = coverage.payload;
      await verifyPeerValue(DOMAINS.peerCoverage, coverage, value.peer);
      boundedText(value.storageId, 256);
      check(
        value.applicationId === this.descriptor.applicationId && value.generation === this.generation.id && this.#authority.grant(value.peer)?.reader === true && this.#pointAvailable(value.point) && Number.isSafeInteger(value.retainedAt) && value.retainedAt >= 0,
        "PEER_COVERAGE_INVALID"
      );
      const previous = this.#coverage.get(value.peer);
      if (previous !== void 0 && !this.#authority.atOrAfter(value.point, previous.payload.point)) return;
      this.#coverage.set(value.peer, coverage);
      this.#publish();
    });
  }
  shared(point = this.revision.point) {
    this.#assertReady();
    return [...this.#coverage.values()].filter((value) => value.payload.storageId !== this.#options.storageId && value.payload.peer !== this.device.publicKey && value.payload.generation === this.generation.id && this.#authority.grant(value.payload.peer)?.reader === true && this.#pointAvailable(value.payload.point) && this.#authority.atOrAfter(value.payload.point, point)).map((value) => structuredClone(value));
  }
  #now() {
    const now = (this.#options.now ?? Date.now)();
    check(Number.isSafeInteger(now) && now >= 0, "PEER_CLOCK_INVALID");
    return now;
  }
  subscribe(listener) {
    this.#listeners.add(listener);
    return () => this.#listeners.delete(listener);
  }
  onRecovery(listener) {
    this.#recoveryListeners.add(listener);
    return () => this.#recoveryListeners.delete(listener);
  }
  inspectRecovery() {
    return structuredClone(this.#recoveries);
  }
  async close() {
    await this.#serial.run(async () => {
      if (this.#disposed) return;
      this.#disposed = true;
      this.#closed = true;
      this.#listeners.clear();
      this.#recoveryListeners.clear();
      try {
        await this.#options.materializer.close();
      } finally {
        activeOwners.get(this.#options.store)?.delete(this.descriptor.applicationId);
      }
    });
  }
};
async function* replicationPages(commands) {
  if (isArray(commands)) {
    const values = commands;
    for (let offset = 0; offset < values.length; offset += PEER_MAX_RECORDS) yield values.slice(offset, offset + PEER_MAX_RECORDS);
  } else yield* commands;
}
async function createPeerReplica(options) {
  check(typeof options.materializer.queries.capabilities?.sql === "boolean", "PEER_QUERY_CAPABILITIES_INVALID");
  check(options.maxRecords === void 0 || Number.isSafeInteger(options.maxRecords) && options.maxRecords >= 1 && options.maxRecords <= PEER_MAX_RECORDS, "PEER_RECORD_LIMIT_INVALID");
  check(options.maxHistoryBytes === void 0 || Number.isSafeInteger(options.maxHistoryBytes) && options.maxHistoryBytes >= 1024 && options.maxHistoryBytes <= PEER_MAX_HISTORY_BYTES, "PEER_HISTORY_LIMIT_INVALID");
  const authority = await verifyAuthorityBundle(options.authority);
  boundedText(options.storageId, 256);
  let owners = activeOwners.get(options.store);
  if (owners === void 0) {
    owners = /* @__PURE__ */ new Set();
    activeOwners.set(options.store, owners);
  }
  check(!owners.has(authority.descriptor.applicationId), "PEER_STORAGE_BUSY");
  owners.add(authority.descriptor.applicationId);
  const replica = new Replica(options, authority);
  try {
    await replica.initialize();
    return replica;
  } catch (error) {
    await replica.close();
    throw error;
  }
}
export {
  createPeerReplica
};
