import { type SignalPayload } from './payload.js';
export { assertSignalTopic, canonicalSignalPayload, type SignalPayload } from './payload.js';
export declare const SIGNAL_DOMAIN = "chronolog/signal/v1";
export declare const MAX_SIGNAL_BYTES = 16384;
export interface SignalIdentity {
    readonly publicKeyBytes: Uint8Array;
    readonly privateKey: CryptoKey;
}
/** A standalone identity; persistence is an explicit application responsibility. */
export declare function generateSignalIdentity(): Promise<SignalIdentity>;
export interface EphemeralSignal {
    readonly scope: string;
    readonly authorId: string;
    readonly sessionId: string;
    readonly sequence: number;
    readonly topic: string;
    readonly payload: SignalPayload;
    readonly issuedAtMs: number;
    readonly expiresAtMs: number;
}
export interface SignalSendOptions {
    readonly ttlMs?: number;
    readonly signal?: AbortSignal;
}
export interface SignalSubscribeOptions {
    readonly topics?: readonly string[];
    readonly mode?: 'all' | 'latest';
    readonly signal?: AbortSignal;
}
export interface Signals {
    send(topic: string, payload: SignalPayload, options?: SignalSendOptions): Promise<EphemeralSignal>;
    subscribe(options?: SignalSubscribeOptions): AsyncIterable<EphemeralSignal>;
}
export declare class SignalError extends Error {
    readonly code: string;
    constructor(code: string, message?: string);
}
/** Credentials are authenticated opaque bytes; only the supplied policy interprets them. */
export interface SignalAuthorization {
    readonly scope: string;
    readonly authorId: Uint8Array;
    readonly topic: string;
    readonly credential: Uint8Array | null;
}
/** Lifetime of this attempt, including caller cancellation, channel close and its deadline. */
export interface SignalPolicyContext {
    readonly signal: AbortSignal;
}
export interface SignalTransport {
    /** False refuses congestion before queueing or dispatching. Actual failures throw. Honor cancellation. */
    trySend(frame: Uint8Array, options: {
        readonly signal: AbortSignal;
    }): Promise<boolean>;
    /** Retire an underlying connection that cannot complete a dispatched write. */
    close?(): void | Promise<void>;
}
export interface SignalRoute {
    /**
     * Verify once, deliver locally and relay unchanged to the other live routes.
     * Returns null for duplicate/expired/unauthorized frames or a capacity drop before delivery.
     * Capacity drops do not evict retained replay protection or queue a retry.
     */
    receive(frame: Uint8Array): Promise<EphemeralSignal | null>;
    close(): void;
}
export interface SignalChannelOptions extends SignalLimits {
    readonly scope: string;
    readonly identity: SignalIdentity;
    readonly authorize: (input: SignalAuthorization, context: SignalPolicyContext) => boolean | Promise<boolean>;
    readonly credential?: Uint8Array | ((topic: string, context: SignalPolicyContext) => Uint8Array | undefined | Promise<Uint8Array | undefined>);
    /** Optional standalone outgoing transport. Attach routes for bidirectional relay. */
    readonly trySend?: SignalTransport['trySend'];
    readonly relay?: boolean;
    readonly now?: () => number;
}
/** Independent live-resource budgets; no database or finality configuration. */
export interface SignalLimits {
    readonly maxTtlMs?: number;
    readonly maxClockSkewMs?: number;
    readonly maxSessions?: number;
    readonly maxSequencesPerSession?: number;
    readonly maxRememberedSignals?: number;
    readonly maxPendingSends?: number;
    readonly maxPendingReceives?: number;
    readonly maxRoutes?: number;
    readonly maxSubscriptions?: number;
    readonly maxQueuedSignals?: number;
    readonly maxQueuedBytes?: number;
    readonly sendTimeoutMs?: number;
}
/** Live signed JSON, with no durable storage, history policy or reconnect outbox. */
export declare class SignalChannel implements Signals {
    #private;
    constructor(options: SignalChannelOptions);
    attachRoute(transport: SignalTransport): SignalRoute;
    send(topic: string, payload: SignalPayload, options?: SignalSendOptions): Promise<EphemeralSignal>;
    /** Standalone receive validates and delivers without inferring a relay source. */
    receive(frame: Uint8Array): Promise<EphemeralSignal | null>;
    subscribe(options?: SignalSubscribeOptions): AsyncIterable<EphemeralSignal>;
    close(): void;
}
