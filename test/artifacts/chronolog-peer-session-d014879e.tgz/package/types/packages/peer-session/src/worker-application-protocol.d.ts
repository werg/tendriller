import type { OperationState, PeerRevision } from '../../peer-generation/src/index.js';
import type { ApplicationSession } from './session.js';
import type { SessionStatus } from './session-types.js';
import type { ApplicationWorkerEndpoint } from './worker-transport.js';
import type { ApplicationParticipationStatus } from './participation-types.js';
export declare const PROTOCOL = "chronolog/peer-session/worker-application/v1";
export declare const MAX_REQUESTS = 64, MAX_RELEASES = 16, MAX_STREAMS = 16, MAX_BYTES = 1048576;
export declare const releasesResource: (method: string) => boolean;
export type Endpoint = ApplicationWorkerEndpoint & {
    start?(): void;
};
export type Description = ReturnType<ApplicationSession['describe']>;
export interface Snapshot {
    readonly status: SessionStatus;
    readonly revision: PeerRevision | null;
    readonly participation: ApplicationParticipationStatus | null;
}
export interface Metadata extends Snapshot {
    readonly protocol: typeof PROTOCOL;
    readonly applicationId: string;
    readonly historyId: string;
    readonly deviceId: string;
    readonly storageId: string;
    readonly description: Description;
}
export interface WireError {
    readonly name: string;
    readonly message: string;
    readonly code?: string;
    readonly operation?: OperationState;
    readonly revision?: PeerRevision;
}
export interface Request {
    readonly id: number;
    readonly method: string;
    readonly args: readonly unknown[];
}
export interface Response {
    readonly id: number;
    readonly value?: unknown;
    readonly error?: WireError;
    readonly snapshot: Snapshot;
}
/** Structured-clone payload budget, including binary values and SQL integers. */
export declare function bounded(value: unknown): void;
