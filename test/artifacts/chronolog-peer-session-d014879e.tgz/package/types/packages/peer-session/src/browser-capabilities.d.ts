export interface BrowserCapabilityReport {
    readonly secureContext: boolean;
    readonly dedicatedWorker: boolean;
    readonly indexedDb: {
        readonly supported: boolean;
        readonly writable: boolean;
    };
    readonly webLocks: boolean;
    readonly opfs: {
        readonly directory: boolean;
        readonly createWritable: boolean;
        readonly syncAccessHandle: boolean;
    };
    readonly crypto: {
        readonly ed25519: boolean;
        readonly x25519: boolean;
    };
    readonly wasm: boolean;
    /** For a new store only. This does not inspect a device's persisted backend pin. */
    readonly events: {
        readonly supported: boolean;
        readonly backend: 'opfs' | 'indexeddb' | null;
        readonly reason?: string;
    };
    /** API eligibility is not an application SQL/WASM qualification. */
    readonly sql: {
        readonly apiEligible: boolean;
        readonly qualified: false;
        readonly reason: string;
    };
}
/**
 * Explicit scratch-only probe for an owning dedicated Worker. No application
 * metadata, signer, Web Lock, backend pin, SQL pool or real data store is opened.
 */
export declare function probeBrowserCapabilities(): Promise<BrowserCapabilityReport>;
