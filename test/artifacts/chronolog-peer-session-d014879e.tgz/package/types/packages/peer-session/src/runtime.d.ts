import type { AuthorityBundle } from '../../peer-generation/src/control.js';
import type { ChronologMaterializationRuntime } from '../../materializer/src/index.js';
import { type ApplicationDefinition } from './definition.js';
import { type ApplicationDevice } from './device.js';
import { ApplicationSession } from './session.js';
export interface OpenPeerApplicationOptions<D extends ApplicationDefinition = ApplicationDefinition> {
    readonly device: ApplicationDevice;
    readonly definition: D;
    readonly authority: AuthorityBundle;
    /** Optional explicit bootstrap. Enrolled keys persist when the durable facet opens. */
    readonly epochKeys?: ReadonlyMap<number, Uint8Array>;
    /** Invoked only on durable demand. Import the SQL implementation inside this factory. */
    readonly createMaterializer?: (options: {
        readonly signal: AbortSignal;
    }) => ChronologMaterializationRuntime | Promise<ChronologMaterializationRuntime>;
    readonly maxRecords?: number;
    readonly maxHistoryBytes?: number;
}
/** Start the protocol participant; database code and storage remain unopened. */
export declare function openPeerApplication<const D extends ApplicationDefinition>(options: OpenPeerApplicationOptions<D>): Promise<ApplicationSession<D>>;
