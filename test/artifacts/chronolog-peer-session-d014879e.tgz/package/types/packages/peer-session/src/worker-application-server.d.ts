import type { ApplicationSession } from './session.js';
import type { ApplicationControlHost } from './recovery.js';
import { type Endpoint } from './worker-application-protocol.js';
/**
 * Serve one page facade beside the owned application. A dedicated port isolates
 * application RPC from RTC handoff and application-owned UI messages. The same
 * pull/cancel contract keeps streams bounded within that one owner.
 */
export declare function serveApplicationWorker(session: ApplicationSession, endpoint: Endpoint, options?: {
    readonly host?: ApplicationControlHost;
}): {
    close(): Promise<void>;
};
