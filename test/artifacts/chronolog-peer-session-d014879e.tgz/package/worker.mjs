import {
  openApplicationDevice,
  openPeerApplication
} from "./chunks/chunk-YIBQIPX5.mjs";
import {
  APPLICATION_PROJECTION_LIMITS
} from "./chunks/chunk-54YIRZVN.mjs";
import {
  MAX_RELEASES,
  MAX_REQUESTS,
  MAX_STREAMS,
  PROTOCOL,
  bounded,
  releasesResource
} from "./chunks/chunk-TWP6P5ES.mjs";
import {
  AbandonedOperationError,
  RecoveredViewError
} from "./chunks/chunk-TLZH7OYA.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-PFEHSVTG.mjs";
import "./chunks/chunk-4SXHXSRR.mjs";
import "./chunks/chunk-TF4JHBDD.mjs";
import "./chunks/chunk-Q44B5CP6.mjs";
import "./chunks/chunk-DACCYORU.mjs";

// packages/peer-session/src/browser-metadata.ts
var TABLE = "metadata";
var MAX_BYTES = 16 * 1024 * 1024;
var BrowserMetadataStore = class _BrowserMetadataStore {
  #database;
  #closed = false;
  constructor(database) {
    this.#database = database;
    database.onversionchange = () => {
      this.close();
    };
  }
  static open(name) {
    if (typeof indexedDB === "undefined") return Promise.reject(new Error("BROWSER_IDENTITY_STORAGE_UNAVAILABLE"));
    return new Promise((resolve, reject) => {
      let failed = false;
      const request = indexedDB.open(`chronolog-metadata:${name}`, 1);
      request.onupgradeneeded = () => {
        request.result.createObjectStore(TABLE);
      };
      request.onerror = () => {
        reject(request.error ?? new Error("BROWSER_IDENTITY_STORAGE_UNAVAILABLE"));
      };
      request.onblocked = () => {
        failed = true;
        reject(new Error("BROWSER_IDENTITY_STORAGE_BLOCKED"));
      };
      request.onsuccess = () => {
        if (failed) request.result.close();
        else resolve(new _BrowserMetadataStore(request.result));
      };
    });
  }
  get(key) {
    return this.#transaction("readonly", (table) => {
      const request = table.get(key);
      return () => {
        if (request.result === void 0) return null;
        if (!(request.result instanceof Uint8Array) || request.result.length > MAX_BYTES) throw new Error("BROWSER_METADATA_INVALID");
        return request.result.slice();
      };
    });
  }
  put(key, value) {
    this.#validate(key, value);
    const captured = value.slice();
    return this.#transaction("readwrite", (table) => {
      table.put(captured, key);
      return () => void 0;
    });
  }
  initialize(input) {
    const entries = input.map(({ key, value }) => {
      this.#validate(key, value);
      return { key, value: value.slice() };
    });
    if (entries.length === 0 || entries.length > 8 || new Set(entries.map((entry) => entry.key)).size !== entries.length) {
      return Promise.reject(new Error("BROWSER_METADATA_INITIALIZATION_INVALID"));
    }
    return this.#transaction("readwrite", (table) => {
      let remaining = entries.length, present = false;
      for (const entry of entries) {
        const request = table.get(entry.key);
        request.onsuccess = () => {
          present ||= request.result !== void 0;
          if (--remaining === 0 && !present) for (const candidate of entries) table.add(candidate.value, candidate.key);
        };
      }
      return () => void 0;
    });
  }
  compareAndSwap(key, expected, value) {
    this.#validate(key, value);
    const before = expected?.slice() ?? null, after = value.slice();
    return this.#transaction("readwrite", (table) => {
      let written = false;
      const request = table.get(key);
      request.onsuccess = () => {
        const current = request.result;
        if (before === null ? current === void 0 : current instanceof Uint8Array && before.length === current.length && before.every((byte, index) => byte === current[index])) {
          table.put(after, key);
          written = true;
        }
      };
      return () => written;
    });
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#database.close();
    }
  }
  #validate(key, value) {
    if (!key || key.length > 4096 || value.length > MAX_BYTES) throw new Error("BROWSER_METADATA_LIMIT");
  }
  #transaction(mode, enqueue) {
    if (this.#closed) return Promise.reject(new Error("BROWSER_METADATA_CLOSED"));
    return new Promise((resolve, reject) => {
      const transaction = this.#database.transaction(TABLE, mode, { durability: "strict" });
      const value = enqueue(transaction.objectStore(TABLE));
      transaction.oncomplete = () => {
        try {
          resolve(value());
        } catch (error) {
          reject(error);
        }
      };
      transaction.onabort = () => {
        reject(transaction.error ?? new Error("BROWSER_METADATA_ABORTED"));
      };
      transaction.onerror = () => {
      };
    });
  }
};

// packages/peer-session/src/browser-device.ts
async function openBrowserDevice(options) {
  if (typeof document !== "undefined") throw new Error("BROWSER_PEER_WORKER_REQUIRED");
  if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/u.test(options.name)) throw new Error("BROWSER_STORAGE_NAME_INVALID");
  const metadata = await BrowserMetadataStore.open(options.name);
  try {
    return await openApplicationDevice({
      store: metadata,
      ...options.create === void 0 ? {} : { create: options.create },
      async openStorage() {
        const { openSelectedBrowserStorage } = await import("./chunks/browser-storage-selector-QYEUA4EG.mjs");
        return openSelectedBrowserStorage(options.name, metadata);
      },
      close: () => {
        metadata.close();
      }
    });
  } catch (error) {
    metadata.close();
    throw error;
  }
}

// packages/peer-session/src/worker-application-server.ts
function serveApplicationWorker(session, endpoint, options = {}) {
  let port, closed = false, lastId = 0, nextView = 0, nextProjection = 0;
  let closing;
  const calls = /* @__PURE__ */ new Map(), streams = /* @__PURE__ */ new Map();
  const views = /* @__PURE__ */ new Map();
  const projections = /* @__PURE__ */ new Map();
  const send = (value) => {
    bounded(value);
    port?.postMessage(value);
  };
  const respond = (id, value) => {
    send({ id, value, snapshot: snapshot(session) });
  };
  const cancelStream = async (id) => {
    const stream = streams.get(id);
    if (stream === void 0) return;
    streams.delete(id);
    stream.controller.abort(new Error("APPLICATION_WORKER_CANCELLED"));
    await stream.iterator.return?.().catch(() => void 0);
  };
  const stop = (reason) => {
    if (closing !== void 0) return closing;
    closed = true;
    endpoint.removeEventListener("message", connect);
    session.signal.removeEventListener("abort", aborted);
    for (const call of calls.values()) call.controller.abort(reason);
    for (const view2 of views.values()) view2.handle.release();
    views.clear();
    projections.clear();
    port?.removeEventListener("message", receive);
    port?.removeEventListener("messageerror", messageError);
    closing = Promise.allSettled([...streams.keys()].map(cancelStream)).then(async () => {
      try {
        await session.close();
      } finally {
        try {
          send({ ended: errorValue(reason) });
        } catch {
        }
        port?.close();
      }
    });
    return closing;
  };
  const aborted = () => {
    void stop(session.signal.reason).catch(() => void 0);
  };
  const messageError = () => {
    void stop(new Error("APPLICATION_WORKER_MESSAGE_INVALID")).catch(() => void 0);
  };
  const controlHost = () => {
    if (options.host === void 0) throw new Error("APPLICATION_CONTROL_HOST_UNAVAILABLE");
    return options.host;
  };
  const participation = () => {
    if (session.participation === void 0) throw new Error("APPLICATION_PARTICIPATION_UNAVAILABLE");
    return session.participation;
  };
  const view = (id) => {
    const result = typeof id === "number" ? views.get(id) : void 0;
    if (result === void 0) throw new Error("APPLICATION_VIEW_RELEASED");
    return result.handle;
  };
  const captureProjection = (name) => {
    const current = session.projection(name);
    for (const [id2, handle2] of projections) {
      try {
        if (session.projection(handle2.id) !== handle2) projections.delete(id2);
      } catch {
        projections.delete(id2);
      }
      if (handle2 === current) return id2;
    }
    if (projections.size >= APPLICATION_PROJECTION_LIMITS.active) throw new Error("APPLICATION_PROJECTION_LIMIT");
    const id = ++nextProjection;
    if (!Number.isSafeInteger(id)) throw new Error("APPLICATION_WORKER_REQUEST_ID_EXHAUSTED");
    projections.set(id, current);
    return id;
  };
  const projection = (id) => {
    const handle2 = typeof id === "number" ? projections.get(id) : void 0;
    if (handle2 === void 0) throw new Error("APPLICATION_PROJECTION_CLOSED");
    return handle2;
  };
  const invoke = async (method, args, signal, requestId) => {
    switch (method) {
      case "command":
        return (await session.command(args[0], args[1], args[2])).operationId;
      case "reapply":
        return (await session.reapply(args[0], args[1], args[2], args[3])).operationId;
      case "query":
        return session.query(args[0], args[1]);
      case "operation.get":
        return session.operations.get(args[0], args[1]);
      case "operation.inspect":
        return session.operations.inspect(args[0], args[1]);
      case "operation.wait":
        return session.operations.wait(args[0], { ...args[1], signal });
      case "operation.shared":
        return session.waitForCoverage(await session.operations.wait(args[0], { signal }), { signal });
      case "retry":
        return session.retry(args[0]);
      case "resume":
        return session.resume();
      case "inspectRecovery":
        return session.inspectRecovery();
      case "recoveryPoint":
        return session.recoveryPoint();
      case "adopt":
        return session.adopt(args[0]);
      case "recovery.inspect":
        return session.recovery.inspect();
      case "recovery.takeover":
        return session.recovery.takeover(controlHost(), { ...args[0], signal });
      case "recovery.handover":
        return session.recovery.handover(controlHost(), { ...args[0], signal });
      case "participation.approve":
        return participation().approveRecovery(args[0]);
      case "participation.close":
        return participation().close();
      case "signals.send":
        return session.signals.send(args[0], args[1], { ...args[2], signal });
      case "view.open": {
        const captured = await session.readView();
        if (signal.aborted) {
          captured.release();
          signal.throwIfAborted();
        }
        const id = ++nextView;
        views.set(id, { handle: captured, requestId });
        return { id, revision: captured.revision };
      }
      case "view.query":
        return view(args[0]).query(args[1], args[2]);
      case "view.events":
        return view(args[0]).readEvents(args[1]);
      case "view.release": {
        const captured = views.get(args[0]);
        views.delete(args[0]);
        captured?.handle.release();
        return null;
      }
      case "projection.open":
        return captureProjection(args[0]);
      case "projection.read":
        return projection(args[0]).read({ signal });
      case "projection.close": {
        const id = args[0], captured = projections.get(id);
        await captured?.close();
        projections.delete(id);
        return null;
      }
      case "content.stage":
        return (await session.content.stage(args[0])).id;
      case "content.resume":
        return (await session.content.resume(args[0])).id;
      case "content.write":
        return (await session.content.resume(args[0])).write(args[1], args[2]);
      case "content.progress":
        return (await session.content.resume(args[0])).progress();
      case "content.commit":
        return (await session.content.resume(args[0])).commit();
      case "content.retain":
        return session.content.retain(args[0], { signal });
      case "content.retained":
        return session.content.retained(args[0]);
      case "content.retention":
        return session.content.retention(args[0]);
      default:
        throw new Error("APPLICATION_WORKER_METHOD_UNKNOWN");
    }
  };
  const openStream = (name, args, signal) => {
    switch (name) {
      case "changes":
        return session.changes({ signal })[Symbol.asyncIterator]();
      case "signals":
        return session.signals.subscribe({ ...args[0], signal })[Symbol.asyncIterator]();
      case "status":
        return observe((listener) => session.onStatus(listener), signal);
      case "participation":
        return observe((listener) => participation().onStatus(listener), signal);
      case "recovery":
        return observe((listener) => session.onRecovery(listener), signal);
      case "content":
        return session.content.read(args[0], { ...args[1], signal })[Symbol.asyncIterator]();
      case "projection": {
        const captured = projections.get(args[0]);
        return captured?.changes({ signal })[Symbol.asyncIterator]() ?? { next: async () => ({ done: true, value: void 0 }) };
      }
      default:
        throw new Error("APPLICATION_WORKER_STREAM_UNKNOWN");
    }
  };
  const handle = async (request) => {
    if (closed) throw new Error("APPLICATION_SESSION_CLOSED");
    if (request.method === "close") {
      await stop(new Error("APPLICATION_SESSION_CLOSED"));
      return;
    }
    const release = releasesResource(request.method);
    if ([...calls.values()].filter((call) => call.release === release).length >= (release ? MAX_RELEASES : MAX_REQUESTS)) throw new Error("APPLICATION_WORKER_REQUEST_LIMIT");
    const controller = new AbortController();
    calls.set(request.id, { controller, release });
    try {
      let result;
      if (request.method === "stream.open") {
        if (streams.size >= MAX_STREAMS) throw new Error("APPLICATION_WORKER_STREAM_LIMIT");
        const iterator = openStream(request.args[0], request.args.slice(1), controller.signal);
        streams.set(request.id, { iterator, controller, busy: false });
        result = request.id;
      } else if (request.method === "stream.next") {
        const stream = streams.get(request.args[0]);
        if (stream === void 0) throw new Error("APPLICATION_WORKER_STREAM_CLOSED");
        if (stream.busy) throw new Error("APPLICATION_WORKER_STREAM_BUSY");
        stream.busy = true;
        try {
          result = await stream.iterator.next();
        } finally {
          stream.busy = false;
        }
        if (result.done) await cancelStream(request.args[0]);
      } else result = await invoke(request.method, request.args, controller.signal, request.id);
      if (!closed && !controller.signal.aborted) respond(request.id, result);
    } finally {
      calls.delete(request.id);
    }
  };
  const receive = (event) => {
    const input = event.data;
    try {
      bounded(input);
      if (input?.cancel !== void 0) {
        if (!Number.isSafeInteger(input.cancel)) throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
        calls.get(input.cancel)?.controller.abort(new Error("APPLICATION_WORKER_CANCELLED"));
        void cancelStream(input.cancel);
        for (const [id, captured] of views) {
          if (captured.requestId === input.cancel) {
            views.delete(id);
            captured.handle.release();
          }
        }
        return;
      }
      if (!input || !Number.isSafeInteger(input.id) || input.id <= lastId || typeof input.method !== "string" || !Array.isArray(input.args)) {
        throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
      }
      lastId = input.id;
      void handle(input).catch((error) => {
        if (!closed) {
          try {
            send({ id: input.id, error: errorValue(error), snapshot: snapshot(session) });
          } catch {
            void stop(error).catch(() => void 0);
          }
        }
      });
    } catch (error) {
      void stop(error).catch(() => void 0);
    }
  };
  const connect = (event) => {
    const input = event.data;
    if (input?.protocol !== PROTOCOL || !input.port || typeof input.port.postMessage !== "function") return;
    if (closed || port !== void 0) {
      input.port.postMessage({ ended: errorValue(new Error(closed ? "APPLICATION_SESSION_CLOSED" : "APPLICATION_WORKER_CLIENT_IN_USE")) });
      input.port.close();
      return;
    }
    port = input.port;
    port.addEventListener("message", receive);
    port.addEventListener("messageerror", messageError);
    port.start();
    try {
      send({ ready: {
        ...snapshot(session),
        protocol: PROTOCOL,
        applicationId: session.applicationId,
        historyId: session.historyId,
        deviceId: session.deviceId,
        storageId: session.storageId,
        description: session.describe()
      } });
    } catch (error) {
      void stop(error).catch(() => void 0);
    }
  };
  endpoint.addEventListener("message", connect);
  endpoint.start?.();
  session.signal.addEventListener("abort", aborted, { once: true });
  if (session.signal.aborted) aborted();
  return { close: () => stop(new Error("APPLICATION_SESSION_CLOSED")) };
}
function snapshot(session) {
  return { status: session.status, revision: session.revision, participation: session.participation?.status ?? null };
}
function errorValue(error) {
  if (!(error instanceof Error)) return { name: "Error", message: String(error) };
  return {
    name: error.name,
    message: error.message,
    ..."code" in error && typeof error.code === "string" ? { code: error.code } : {},
    ...error instanceof AbandonedOperationError ? { operation: error.operation } : {},
    ...error instanceof RecoveredViewError ? { revision: error.revision } : {}
  };
}
function observe(subscribe, signal) {
  let pending, hasValue = false, closed = false, wake;
  const unsubscribe = subscribe((value) => {
    pending = value;
    hasValue = true;
    wake?.();
    wake = void 0;
  });
  const close = () => {
    if (closed) return;
    closed = true;
    unsubscribe();
    signal.removeEventListener("abort", close);
    wake?.();
    wake = void 0;
  };
  signal.addEventListener("abort", close, { once: true });
  if (signal.aborted) close();
  return {
    async next() {
      while (!hasValue && !closed) await new Promise((resolve) => {
        wake = resolve;
      });
      signal.throwIfAborted();
      if (closed) return { done: true, value: void 0 };
      const value = pending;
      pending = void 0;
      hasValue = false;
      return { done: false, value };
    },
    async return() {
      close();
      return { done: true, value: void 0 };
    }
  };
}

// packages/peer-session/src/worker.ts
async function probeBrowserCapabilities() {
  return (await import("./chunks/browser-capabilities-6VP7OIGE.mjs")).probeBrowserCapabilities();
}
export {
  openPeerApplication as openBrowserApplication,
  openBrowserDevice,
  probeBrowserCapabilities,
  serveApplicationWorker
};
