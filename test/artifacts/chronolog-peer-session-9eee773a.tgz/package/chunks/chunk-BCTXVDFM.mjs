// packages/peer-session/src/live-view.ts
function isRecovering(failure) {
  if (failure === null || typeof failure !== "object") return false;
  const record = failure;
  return (record.code ?? record.message) === "PEER_RECOVERING";
}
function createLiveView(session, options) {
  const { query, input = null, onSnapshot, onStatus, onRecovery, onError, signal } = options;
  if (typeof query !== "string" || !query) throw new TypeError("A declared query name is required.");
  const capturedInput = structuredClone(input);
  const lifetime = new AbortController();
  const signals = [lifetime.signal, ...session.signal === void 0 ? [] : [session.signal], ...signal === void 0 ? [] : [signal]];
  const owned = AbortSignal.any(signals);
  let closed = false;
  let running = false;
  let dirty = false;
  let requested = 0;
  let snapshot = null;
  let status = null;
  let currentError = null;
  let hasError = false;
  let statusKey;
  let stopStatus = () => void 0;
  let stopRecovery = () => void 0;
  let iterator;
  const waiting = /* @__PURE__ */ new Set();
  const initial = /* @__PURE__ */ new Set();
  const listeners = /* @__PURE__ */ new Set();
  const settleInitial = (failed, value) => {
    for (const finish of [...initial]) finish(failed, value);
  };
  const notify = (listener, value) => {
    if (closed || listener === void 0) return;
    try {
      listener(value);
    } catch (err) {
      if (listener !== onError) notify(onError, err);
    }
  };
  const settle = (err, value, failed = false) => {
    for (const held of waiting) {
      if (failed) held.reject(err);
      else if (value !== void 0) held.resolve(value);
    }
    waiting.clear();
  };
  const invalidate = () => {
    if (closed) return;
    requested++;
    dirty = true;
    queueMicrotask(() => {
      void pump();
    });
  };
  async function pump() {
    if (running || closed) return;
    running = true;
    try {
      while (dirty && !closed) {
        dirty = false;
        const request = requested;
        try {
          const result = await session.query(query, capturedInput);
          if (closed || request !== requested) continue;
          snapshot = Object.freeze({ revision: result.revision, value: result.value });
          currentError = null;
          hasError = false;
          settle(null, snapshot);
          settleInitial(false, snapshot);
          notify(onSnapshot, snapshot);
          for (const listener of listeners) notify(listener, snapshot);
        } catch (failure) {
          if (closed || request !== requested) continue;
          const quietRecovery = isRecovering(failure) && snapshot === null && initial.size > 0 && waiting.size === 0;
          currentError = failure;
          hasError = true;
          settle(failure, void 0, true);
          if (!isRecovering(failure)) settleInitial(true, failure);
          if (!quietRecovery) notify(onError, failure);
        }
      }
    } finally {
      running = false;
    }
  }
  function refresh() {
    if (closed) return Promise.reject(owned.reason);
    const task = new Promise((resolve, reject) => {
      waiting.add({ resolve, reject });
    });
    invalidate();
    return task;
  }
  function ready(readyOptions = {}) {
    const { signal: readySignal, timeoutMs = 3e4 } = readyOptions;
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 12e4) {
      return Promise.reject(new TypeError("Initial read timeout must be 1..120000 milliseconds."));
    }
    if (readySignal?.aborted === true) return Promise.reject(readySignal.reason);
    if (closed) return Promise.reject(owned.reason);
    if (snapshot !== null) return Promise.resolve(snapshot);
    if (hasError && !isRecovering(currentError)) return Promise.reject(currentError);
    return new Promise((resolve, reject) => {
      const finish = (failed, value) => {
        clearTimeout(timer);
        readySignal?.removeEventListener("abort", abort);
        initial.delete(finish);
        if (failed) reject(value);
        else resolve(value);
      };
      const abort = () => {
        finish(true, readySignal?.reason);
      };
      const timer = setTimeout(() => {
        finish(true, Object.assign(new Error("INITIAL_READ_TIMEOUT"), { code: "INITIAL_READ_TIMEOUT" }));
      }, timeoutMs);
      initial.add(finish);
      readySignal?.addEventListener("abort", abort, { once: true });
      if (readySignal?.aborted === true) abort();
    });
  }
  function subscribe(listener) {
    if (typeof listener !== "function") throw new TypeError("A snapshot listener is required.");
    if (closed) throw new Error("Live view is closed.");
    listeners.add(listener);
    if (snapshot !== null) notify(listener, snapshot);
    return () => {
      listeners.delete(listener);
    };
  }
  function close() {
    if (closed) return;
    closed = true;
    owned.removeEventListener("abort", close);
    lifetime.abort(new Error("Live view is closed."));
    stopStatus();
    stopRecovery();
    listeners.clear();
    settle(owned.reason, void 0, true);
    settleInitial(true, owned.reason);
    void Promise.resolve().then(() => iterator?.return?.()).catch(() => void 0);
  }
  owned.addEventListener("abort", close, { once: true });
  if (owned.aborted) {
    close();
  } else {
    try {
      stopStatus = session.onStatus((value) => {
        const generationChanged = status !== null && status.generation !== value.generation;
        const becameReady = status?.phase !== "ready" && value.phase === "ready";
        status = value;
        notify(onStatus, value);
        const next = `${value.generation}/${value.database}/${value.phase}`;
        if (generationChanged || becameReady || next !== statusKey && value.database === "ready" && value.phase === "ready") invalidate();
        statusKey = next;
        if (value.phase === "closed" || value.database === "closed") close();
      });
      if (closed) {
        stopStatus();
      } else {
        stopRecovery = session.onRecovery((notice) => {
          notify(onRecovery, notice);
          invalidate();
        });
        iterator = session.changes({ signal: owned })[Symbol.asyncIterator]();
        void (async () => {
          try {
            while (!closed) {
              const change = await iterator.next();
              if (change.done === true) break;
              invalidate();
            }
          } catch (failure) {
            if (!closed) {
              currentError = failure;
              hasError = true;
              if (!isRecovering(failure)) settleInitial(true, failure);
              notify(onError, failure);
            }
          }
        })();
        invalidate();
      }
    } catch (err) {
      close();
      throw err;
    }
  }
  return Object.freeze({
    refresh,
    ready,
    subscribe,
    close,
    get snapshot() {
      return snapshot;
    },
    get status() {
      return status;
    },
    get error() {
      return currentError;
    }
  });
}

// packages/peer-session/src/view-store.ts
var DEFAULT_PAYLOAD_BYTES = 8192;
var sessionActions = {
  OWNER_BUSY: "Attach to the existing owner or deliberately enroll a separate profile.",
  ENDPOINT_STALE: "Reattach and inspect the original operation before acting again.",
  RECOVERY_REVIEW_REQUIRED: "Inspect the original operation and deliberately rebind or reapply."
};
var SessionError = class extends Error {
  code;
  scope;
  retrySafe;
  nextAction;
  constructor(code, message = code, scope = {}, actions = sessionActions) {
    super(message);
    this.name = "SessionError";
    this.code = code;
    this.scope = scope;
    this.retrySafe = code === "OWNER_BUSY" || code === "RECIPIENT_UNAVAILABLE";
    this.nextAction = actions[code] ?? sessionActions[code] ?? "Inspect the supplied scope and correct the request.";
  }
};
function identifier(value, name = "identity") {
  if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}$/u.test(value)) {
    throw new SessionError("INVALID_IDENTITY", `Invalid ${name}`);
  }
  return value;
}
function signerId(value) {
  if (typeof value !== "string" || !/^[0-9a-f]{64}$/u.test(value)) {
    throw new SessionError("INVALID_SIGNER", "A verified signing public key is required");
  }
  return value;
}
function canonicalJson(value, maxBytes = DEFAULT_PAYLOAD_BYTES) {
  let nodes = 0;
  function visit(item, depth) {
    if (++nodes > 4096 || depth > 24) throw new SessionError("PAYLOAD_TOO_COMPLEX");
    if (item === null || typeof item === "boolean" || typeof item === "string") return JSON.stringify(item);
    if (typeof item === "number" && Number.isFinite(item)) return JSON.stringify(item);
    if (Array.isArray(item)) {
      if (Object.keys(item).length !== item.length) throw new SessionError("INVALID_PAYLOAD");
      return `[${item.map((child) => visit(child, depth + 1)).join(",")}]`;
    }
    if (item === null || typeof item !== "object") {
      throw new SessionError("INVALID_PAYLOAD");
    }
    const proto = Object.getPrototypeOf(item);
    if (proto !== Object.prototype && proto !== null) {
      throw new SessionError("INVALID_PAYLOAD");
    }
    const record = item;
    if (Reflect.ownKeys(record).length !== Object.keys(record).length) throw new SessionError("INVALID_PAYLOAD");
    return `{${Object.keys(record).sort().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(record, key);
      if (descriptor === void 0 || !("value" in descriptor)) throw new SessionError("INVALID_PAYLOAD");
      return `${JSON.stringify(key)}:${visit(descriptor.value, depth + 1)}`;
    }).join(",")}}`;
  }
  const encoded = visit(value, 0);
  if (new TextEncoder().encode(encoded).length > maxBytes) throw new SessionError("PAYLOAD_TOO_LARGE");
  return encoded;
}
function operationReference(session, operationId, state) {
  const applicationId = session.applicationId ?? session.id;
  const historyId = session.historyId;
  if (typeof applicationId !== "string" || !applicationId || typeof historyId !== "string" || !historyId) {
    throw new SessionError("OPERATION_SCOPE_MISMATCH", "An attached application and verified history are required");
  }
  const author = signerId(state?.author ?? session.deviceId);
  const scopedId = author === session.deviceId && typeof session.scopeOperationId === "function" ? session.scopeOperationId(operationId) : operationId;
  if (state?.operationId !== void 0 && state.operationId !== scopedId) {
    throw new SessionError("OPERATION_REFERENCE_CONFLICT", "The saved state belongs to a different operation");
  }
  return Object.freeze({
    applicationId,
    historyId,
    author,
    operationId: identifier(scopedId, "operation"),
    ...state?.attemptId === void 0 ? {} : { attemptId: state.attemptId },
    ...state?.generation === void 0 ? {} : { generation: state.generation }
  });
}
function createViewStore(options) {
  const { storage, applicationId, historyId, profileId, viewId } = options;
  if (storage === null || typeof storage !== "object" || typeof storage.getItem !== "function" || typeof storage.setItem !== "function") {
    throw new SessionError("LOCAL_STORAGE_UNAVAILABLE");
  }
  identifier(applicationId);
  identifier(profileId);
  identifier(viewId);
  const segment = (value) => encodeURIComponent(identifier(value));
  const hasControlChar = (value) => {
    for (let i = 0; i < value.length; i++) {
      const code = value.charCodeAt(i);
      if (code <= 31 || code === 127) return true;
    }
    return false;
  };
  const historySegment = (value) => {
    if (typeof value !== "string" || !value || value.length > 128 || hasControlChar(value)) {
      throw new SessionError("OPERATION_SCOPE_MISMATCH", "A verified history identity is required");
    }
    return encodeURIComponent(value);
  };
  const prefix = `chronolog:view-store:${segment(applicationId)}:${segment(profileId)}:` + (historyId === void 0 ? "unbound:" : `history:${historySegment(historyId)}:`);
  const viewPrefix = `${prefix}view:${segment(viewId)}:`;
  function read(key) {
    const value = storage.getItem(key);
    if (value === null) return null;
    try {
      return JSON.parse(value);
    } catch {
      throw new SessionError("LOCAL_REFERENCE_CORRUPT", "Preserve and inspect the local record before replacing it");
    }
  }
  function write(key, value) {
    try {
      storage.setItem(key, canonicalJson(value, 65536));
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      throw new SessionError("LOCAL_STORAGE_UNAVAILABLE", `Could not retain the local record: ${detail}`);
    }
  }
  function operationKey(reference) {
    if (reference.applicationId !== applicationId || historyId !== void 0 && reference.historyId !== historyId) {
      throw new SessionError("OPERATION_SCOPE_MISMATCH");
    }
    return `${prefix}operation:${historySegment(reference.historyId)}:${signerId(reference.author)}:${segment(reference.operationId)}:view:${segment(viewId)}`;
  }
  return Object.freeze({
    viewId,
    ...historyId === void 0 ? {} : { historyId },
    readDraft(draftId = "main") {
      return read(`${viewPrefix}draft:${segment(draftId)}`);
    },
    writeDraft(value, draftId = "main") {
      write(`${viewPrefix}draft:${segment(draftId)}`, value);
    },
    removeDraft(draftId = "main") {
      storage.removeItem(`${viewPrefix}draft:${segment(draftId)}`);
    },
    retainOperation(reference, context = {}) {
      const key = operationKey(reference);
      const existing = read(key);
      const value = { reference, viewId, context };
      if (existing !== null && canonicalJson(existing.context, 65536) !== canonicalJson(context, 65536)) {
        throw new SessionError("OPERATION_REFERENCE_CONFLICT", "The original operation input must remain unchanged");
      }
      for (const field of ["attemptId", "generation"]) {
        if (existing?.reference[field] !== void 0 && reference[field] !== void 0 && existing.reference[field] !== reference[field]) {
          throw new SessionError("OPERATION_REFERENCE_CONFLICT", "The original signed attempt must remain unchanged");
        }
      }
      const retained = existing !== null ? { ...existing, reference: { ...existing.reference, ...reference } } : value;
      write(key, retained);
      return retained;
    },
    inspectOperation(reference) {
      return read(operationKey(reference));
    },
    removeOperation(reference) {
      storage.removeItem(operationKey(reference));
    },
    pending(pendingOptions = {}) {
      const allViews = pendingOptions.allViews ?? false;
      const values = [];
      for (let i = 0; i < storage.length; i++) {
        const key = storage.key(i);
        if (key?.startsWith(`${prefix}operation:`) === true) {
          const value = read(key);
          if (value !== null && (allViews || value.viewId === viewId)) values.push(value);
        }
      }
      return values.sort((a, b) => a.reference.operationId.localeCompare(b.reference.operationId));
    }
  });
}

export {
  createLiveView,
  SessionError,
  identifier,
  signerId,
  canonicalJson,
  operationReference,
  createViewStore
};
