import {
  eventExecutionManifest
} from "./chunks/chunk-RCDYELQW.mjs";
import {
  createApplicationOwner
} from "./chunks/chunk-NAZMEIFF.mjs";
import {
  ApplicationControlParticipant,
  ApplicationSession,
  applicationDefinitionDigest,
  claimApplicationDevice,
  connectApplications,
  defineApplication,
  defineCommand,
  defineQuery,
  describeApplication,
  openApplicationDevice,
  openPeerApplication
} from "./chunks/chunk-KJC2MVTP.mjs";
import {
  APPLICATION_EVENT_CURSOR_LIMIT,
  APPLICATION_PROJECTION_LIMITS,
  ApplicationOperation,
  createPeerReplica
} from "./chunks/chunk-5C2UDZJY.mjs";
import {
  acquireApplicationOwnerLock
} from "./chunks/chunk-2ZKHAZYZ.mjs";
import {
  AbandonedOperationError,
  ApplicationControlConflictError,
  RecoveredViewError
} from "./chunks/chunk-TLZH7OYA.mjs";
import {
  awaitOwnedTask
} from "./chunks/chunk-KSC4KBWO.mjs";
import {
  MemoryBytesStore
} from "./chunks/chunk-PFEHSVTG.mjs";
import {
  CONTROL_PARTICIPANT_POLICY,
  PARTICIPANT_LIMITS,
  PARTICIPANT_PROTOCOL,
  PEER_PARTICIPANT_POLICY,
  PUBLICATION_LIMITS,
  ParticipantProtocolError,
  PeerAuthority,
  RELEASE_LIMITS,
  RELEASE_PROFILE,
  assertAuthorityExtension,
  assertReleaseStateExtension,
  authorizePublication,
  controlParticipantGrant,
  createGenerationRegistry,
  createParticipantRequest,
  createParticipantResponse,
  createParticipantTransport,
  createPublicationRegistry,
  createReleaseRegistry,
  generationStartRoot,
  participantAccepts,
  participantGrant,
  signApplicationDescriptor,
  signApplicationSchema,
  signControlRevision,
  signPublicationManifest,
  signReleaseActivationRequest,
  signReleaseManifest,
  signReleasePolicy,
  signTransitionRequest,
  validateHistoryPoint,
  validateParticipantRequest,
  validateParticipantResponse,
  validatePeerRevision,
  validatePublicationManifest,
  validateReleaseActivationRequest,
  validateReleaseApplicationBinding,
  validateReleaseAsset,
  validateReleaseManifest,
  validateReleasePath,
  validateReleasePolicy,
  validateReleasePolicyRequest,
  verifyApplicationSchema,
  verifyAuthorityBundle,
  verifyOrderReceipt,
  verifyPublicationAsset,
  verifyPublicationManifest,
  verifyReleaseActivation,
  verifyReleaseActivationRequest,
  verifyReleaseAsset,
  verifyReleaseContent,
  verifyReleaseManifest,
  verifyReleasePolicy,
  verifyReleaseState
} from "./chunks/chunk-4SXHXSRR.mjs";
import {
  PEER_GENERATION_CAPABILITIES,
  PEER_GENERATION_POLICY,
  PEER_GENERATION_PROFILE,
  PEER_MAX_HISTORY_BYTES,
  PEER_MAX_RECORDS,
  PeerGenerationError,
  applicationDescriptionDigest,
  bytesDigest,
  checkedApplicationInputSchema,
  createPeerIdentity,
  decodePeerValue,
  encodePeerValue,
  exportPeerIdentity,
  importPeerIdentity,
  parseApplicationInput,
  peerDigest,
  samePeerValue,
  validateApplicationDescription
} from "./chunks/chunk-TF4JHBDD.mjs";
import {
  APPLICATION_COLLECTIVE_ID,
  bytesToHex,
  emit,
  executionManifestArtifacts,
  hexToBytes,
  program,
  sqlStatement
} from "./chunks/chunk-Q44B5CP6.mjs";
import "./chunks/chunk-DACCYORU.mjs";

// packages/peer-session/src/tools.ts
var digestSchema = { type: "string", pattern: "^[0-9a-f]{64}$" };
var unsignedSchema = { type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER };
var revisionSchema = {
  type: "object",
  additionalProperties: false,
  required: ["applicationId", "historyId", "generation", "point", "controlRevision", "materializationRevision"],
  properties: {
    applicationId: digestSchema,
    historyId: { type: "string", minLength: 1, maxLength: 128, pattern: "^[^\\u0000-\\u001f\\u007f]+$" },
    generation: digestSchema,
    controlRevision: unsignedSchema,
    materializationRevision: { type: "string", pattern: "^[0-9]{1,32}$" },
    point: {
      type: "object",
      additionalProperties: false,
      required: ["generation", "sequence", "root"],
      properties: { generation: digestSchema, sequence: unsignedSchema, root: digestSchema }
    }
  }
};
function inputRevision(session, value) {
  if (value === void 0) return void 0;
  const revision = value;
  validatePeerRevision(revision);
  if (revision.applicationId !== session.applicationId || revision.historyId !== session.historyId) {
    throw new Error("APPLICATION_TOOL_REVISION_SCOPE_MISMATCH");
  }
  return revision;
}
function sameRevision(left, right) {
  return left.applicationId === right.applicationId && left.historyId === right.historyId && left.generation === right.generation && left.controlRevision === right.controlRevision && left.materializationRevision === right.materializationRevision && left.point.generation === right.point.generation && left.point.sequence === right.point.sequence && left.point.root === right.point.root;
}
async function observeChange(session, after, waitMs, signal) {
  if (typeof waitMs !== "number" || !Number.isSafeInteger(waitMs) || waitMs < 0 || waitMs > 3e4) {
    throw new Error("APPLICATION_TOOL_INPUT_INVALID");
  }
  const deadline = new AbortController(), observation = AbortSignal.any([signal, deadline.signal]);
  const iterator = session.changes({ signal: observation })[Symbol.asyncIterator]();
  const timer = setTimeout(() => {
    deadline.abort();
  }, waitMs);
  try {
    while (true) {
      const next = await iterator.next();
      signal.throwIfAborted();
      if (next.done === true) return { change: null, resetRequired: false };
      const change = next.value;
      if (after !== void 0 && sameRevision(after, change.revision)) continue;
      const resetRequired = after !== void 0 && after.generation !== change.revision.generation;
      const recovery = change.recovery ?? (resetRequired ? (await session.inspectRecovery()).findLast((notice) => notice.generation === change.revision.generation) ?? null : null);
      return { change: recovery === null ? change : { ...change, kind: "recovery", recovery }, resetRequired };
    }
  } finally {
    clearTimeout(timer);
    await iterator.return?.();
  }
}
function createApplicationTools(session, options = {}) {
  const description = session.describe(), operationId = { type: "string", minLength: 1, maxLength: 256 };
  const object = (properties, required = Object.keys(properties)) => ({ type: "object", properties, required, additionalProperties: false });
  const entries = (kind, fields, required = Object.keys(fields)) => ({ oneOf: description[kind].map((entry) => object({
    name: { type: "string", const: entry.name, description: entry.description },
    input: entry.input,
    ...fields
  }, ["name", "input", ...required])) });
  const tools = [
    { name: "describe", description: "Inspect authenticated application definitions, current role and supported guarantees.", inputSchema: object({}) },
    { name: "query", description: "Execute a declared query against one coherent captured application revision.", inputSchema: entries("queries", {}) },
    { name: "command", description: "Save one signed command under a caller-owned operation ID, optionally guarded by a captured revision. Returns saved or currently applied state.", inputSchema: entries("commands", { operationId, basedOn: revisionSchema }, ["operationId"]) },
    { name: "operation", description: "Inspect saved attempt bytes, current outcome and explicit reapplication linkage. Author defaults to this device; specify the original signer to inspect another participant's retained work.", inputSchema: object({ operationId, author: digestSchema }, ["operationId"]) },
    { name: "retry", description: "Retry this device's exact saved command. Never recreates an abandoned operation.", inputSchema: object({ operationId }) },
    { name: "wait", description: "Wait for the current applied result of this device or an explicit original author. Cancellation only cancels this wait.", inputSchema: object({ operationId, author: digestSchema }, ["operationId"]) },
    {
      name: "changes",
      description: "Observe one coalesced coherent revision, optionally waiting after a captured revision. A generation change requires a reread; this is not an event replay cursor.",
      inputSchema: object({ after: revisionSchema, waitMs: { type: "integer", minimum: 0, maximum: 3e4, default: 0 } }, [])
    },
    { name: "recoveries", description: "Inspect generation recovery notices and preserved abandoned operations.", inputSchema: object({}) },
    { name: "reapply", description: "Deliberately create a newly signed, linked command from current input after abandonment, optionally guarded by a captured revision. Specify originalAuthor for another participant's work; the new command is always signed by this device.", inputSchema: entries("commands", { operationId, originalOperationId: operationId, originalAuthor: digestSchema, basedOn: revisionSchema }, ["operationId", "originalOperationId"]) },
    ...options.host === void 0 ? [] : [{ name: "takeover", description: "Select this eligible device's complete recovery point through the hosted authority; may abandon a recent suffix.", inputSchema: object({ transitionId: { type: "string", minLength: 1, maxLength: 128 } }) }]
  ];
  return {
    list() {
      return structuredClone(tools);
    },
    async call(name, input, callOptions = {}) {
      const signal = callOptions.signal === void 0 ? session.signal : AbortSignal.any([session.signal, callOptions.signal]);
      return awaitOwnedTask(signal, async () => {
        if (input === null || typeof input !== "object" || Array.isArray(input)) throw new Error("APPLICATION_TOOL_INPUT_INVALID");
        const value = input;
        const text = (key) => {
          if (typeof value[key] !== "string") throw new Error("APPLICATION_TOOL_INPUT_INVALID");
          return value[key];
        };
        const author = (key) => {
          if (value[key] === void 0) return void 0;
          const identity = text(key);
          if (!/^[0-9a-f]{64}$/u.test(identity)) throw new Error("APPLICATION_TOOL_INPUT_INVALID");
          return identity;
        };
        const fields = (...keys) => {
          if (Object.keys(value).some((key) => !keys.includes(key))) throw new Error("APPLICATION_TOOL_INPUT_INVALID");
        };
        switch (name) {
          case "describe":
            fields();
            return { definition: description, status: session.status };
          case "query":
            fields("name", "input");
            return session.query(text("name"), value.input);
          case "command": {
            fields("name", "input", "operationId", "basedOn");
            const basedOn = inputRevision(session, value.basedOn);
            const operation = await session.command(text("name"), value.input, {
              operationId: text("operationId"),
              ...basedOn === void 0 ? {} : { basedOn }
            });
            return operation.get();
          }
          case "operation": {
            fields("operationId", "author");
            const signer = author("author");
            return session.operations.inspect(text("operationId"), signer === void 0 ? {} : { author: signer });
          }
          case "retry":
            fields("operationId");
            await session.retry(text("operationId"));
            return session.operations.get(text("operationId"));
          case "wait": {
            fields("operationId", "author");
            const signer = author("author");
            return session.operations.wait(text("operationId"), { signal, ...signer === void 0 ? {} : { author: signer } });
          }
          case "changes":
            fields("after", "waitMs");
            return observeChange(session, inputRevision(session, value.after), value.waitMs === void 0 ? 0 : value.waitMs, signal);
          case "recoveries":
            fields();
            return session.inspectRecovery();
          case "reapply": {
            fields("name", "input", "operationId", "originalOperationId", "originalAuthor", "basedOn");
            const basedOn = inputRevision(session, value.basedOn);
            const originalAuthor = author("originalAuthor");
            const operation = await session.reapply(text("originalOperationId"), text("name"), value.input, {
              operationId: text("operationId"),
              ...originalAuthor === void 0 ? {} : { originalAuthor },
              ...basedOn === void 0 ? {} : { basedOn }
            });
            return operation.get();
          }
          case "takeover":
            fields("transitionId");
            if (options.host === void 0) throw new Error("APPLICATION_TOOL_UNAVAILABLE");
            return session.recovery.takeover(options.host, { transitionId: text("transitionId") });
          default:
            throw new Error("APPLICATION_TOOL_UNKNOWN");
        }
      });
    }
  };
}
function formatApplicationToolResult(value) {
  return JSON.stringify(value, (_key, item) => {
    if (typeof item === "bigint") return { $integer: String(item) };
    if (item instanceof Uint8Array) return { $bytes: Array.from(item, (byte) => byte.toString(16).padStart(2, "0")).join("") };
    return item;
  });
}
async function serveApplicationToolLines(session, options) {
  const tools = createApplicationTools(session, options);
  const lifetime = options.signal === void 0 ? session.signal : AbortSignal.any([session.signal, options.signal]);
  lifetime.throwIfAborted();
  const iterator = options.input[Symbol.asyncIterator]();
  let ended = false;
  try {
    while (true) {
      const next = await awaitOwnedTask(lifetime, () => iterator.next());
      if (next.done) {
        ended = true;
        return;
      }
      const line = next.value;
      let id = null;
      let response;
      try {
        if (new TextEncoder().encode(line).length > 262144) throw new Error("APPLICATION_TOOL_LINE_TOO_LARGE");
        const request = JSON.parse(line);
        if (request === null || typeof request !== "object" || Array.isArray(request) || typeof request.id !== "string" && (typeof request.id !== "number" || !Number.isSafeInteger(request.id))) throw new Error("APPLICATION_TOOL_REQUEST_INVALID");
        id = request.id;
        const timeoutMs = request.timeoutMs ?? 3e4;
        if (typeof timeoutMs !== "number" || !Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 6e4) throw new Error("APPLICATION_TOOL_TIMEOUT_INVALID");
        const value = request.tool === "list" ? tools.list() : typeof request.tool === "string" ? await tools.call(request.tool, request.input ?? {}, { signal: AbortSignal.any([lifetime, AbortSignal.timeout(timeoutMs)]) }) : (() => {
          throw new Error("APPLICATION_TOOL_REQUEST_INVALID");
        })();
        response = { id, result: value };
      } catch (error) {
        lifetime.throwIfAborted();
        const state = error instanceof Error && "operation" in error ? { operation: error.operation } : {};
        response = { id, error: error instanceof Error ? error.message : "APPLICATION_TOOL_FAILED", ...state };
      }
      await awaitOwnedTask(lifetime, () => options.write(`${formatApplicationToolResult(response)}
`));
    }
  } finally {
    if (!ended && iterator.return !== void 0) {
      try {
        void Promise.resolve(iterator.return()).catch(() => void 0);
      } catch {
      }
    }
  }
}
export {
  APPLICATION_COLLECTIVE_ID,
  APPLICATION_EVENT_CURSOR_LIMIT,
  APPLICATION_PROJECTION_LIMITS,
  AbandonedOperationError,
  ApplicationControlConflictError,
  ApplicationControlParticipant,
  ApplicationOperation,
  ApplicationSession,
  CONTROL_PARTICIPANT_POLICY,
  MemoryBytesStore,
  PARTICIPANT_LIMITS,
  PARTICIPANT_PROTOCOL,
  PEER_GENERATION_CAPABILITIES,
  PEER_GENERATION_POLICY,
  PEER_GENERATION_PROFILE,
  PEER_MAX_HISTORY_BYTES,
  PEER_MAX_RECORDS,
  PEER_PARTICIPANT_POLICY,
  PUBLICATION_LIMITS,
  ParticipantProtocolError,
  PeerAuthority,
  PeerGenerationError,
  RELEASE_LIMITS,
  RELEASE_PROFILE,
  RecoveredViewError,
  acquireApplicationOwnerLock,
  applicationDefinitionDigest,
  applicationDescriptionDigest,
  assertAuthorityExtension,
  assertReleaseStateExtension,
  authorizePublication,
  bytesDigest,
  bytesToHex,
  checkedApplicationInputSchema,
  claimApplicationDevice,
  connectApplications,
  controlParticipantGrant,
  createApplicationOwner,
  createApplicationTools,
  createGenerationRegistry,
  createParticipantRequest,
  createParticipantResponse,
  createParticipantTransport,
  createPeerIdentity,
  createPeerReplica,
  createPublicationRegistry,
  createReleaseRegistry,
  decodePeerValue,
  defineApplication,
  defineCommand,
  defineQuery,
  describeApplication,
  emit,
  encodePeerValue,
  eventExecutionManifest,
  executionManifestArtifacts,
  exportPeerIdentity,
  formatApplicationToolResult,
  generationStartRoot,
  hexToBytes,
  importPeerIdentity,
  openApplicationDevice,
  openPeerApplication,
  parseApplicationInput,
  participantAccepts,
  participantGrant,
  peerDigest,
  program,
  samePeerValue,
  serveApplicationToolLines,
  signApplicationDescriptor,
  signApplicationSchema,
  signControlRevision,
  signPublicationManifest,
  signReleaseActivationRequest,
  signReleaseManifest,
  signReleasePolicy,
  signTransitionRequest,
  sqlStatement,
  validateApplicationDescription,
  validateHistoryPoint,
  validateParticipantRequest,
  validateParticipantResponse,
  validatePeerRevision,
  validatePublicationManifest,
  validateReleaseActivationRequest,
  validateReleaseApplicationBinding,
  validateReleaseAsset,
  validateReleaseManifest,
  validateReleasePath,
  validateReleasePolicy,
  validateReleasePolicyRequest,
  verifyApplicationSchema,
  verifyAuthorityBundle,
  verifyOrderReceipt,
  verifyPublicationAsset,
  verifyPublicationManifest,
  verifyReleaseActivation,
  verifyReleaseActivationRequest,
  verifyReleaseAsset,
  verifyReleaseContent,
  verifyReleaseManifest,
  verifyReleasePolicy,
  verifyReleaseState
};
