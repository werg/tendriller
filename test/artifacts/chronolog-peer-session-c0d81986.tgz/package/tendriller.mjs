import {
  createApplicationBackend
} from "./chunks/chunk-IHPZTZVT.mjs";
import "./chunks/chunk-3HEURE6I.mjs";
import "./chunks/chunk-HYFY2E3E.mjs";
export {
  createApplicationBackend
};
