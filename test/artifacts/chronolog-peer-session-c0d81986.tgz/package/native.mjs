import {
  createApplicationSession
} from "./chunks/chunk-5SNOO3GU.mjs";
import {
  openApplicationDevice
} from "./chunks/chunk-S2M2LZ5C.mjs";
import "./chunks/chunk-VSKMMUX7.mjs";
import "./chunks/chunk-OR5FPE5F.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import {
  MemoryBytesStore
} from "./chunks/chunk-MCU2YKH4.mjs";
import "./chunks/chunk-IHPZTZVT.mjs";
import "./chunks/chunk-3HEURE6I.mjs";
import "./chunks/chunk-HYFY2E3E.mjs";

// packages/peer-session/src/native.ts
import { randomUUID } from "node:crypto";
import { mkdirSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

// packages/records/src/native.ts
import { createRequire } from "node:module";
import { Worker } from "node:worker_threads";

// packages/records/src/native-worker.ts
var nativeWorkerSource = String.raw`
(async () => {
const { parentPort, workerData } = await import('node:worker_threads')
const { createRequire } = await import('node:module')
const require = createRequire(workerData.sqliteModule)
const { mkdirSync } = require('node:fs')
const { dirname } = require('node:path')
const Database = require(workerData.sqliteModule)
const stores = new Map()
function error(message) { throw new Error(message) }
function validate(store, key, value) {
  if (typeof key !== 'string' || key.length === 0 || key.length > 4096 || [...key].some(c => c.charCodeAt(0) < 32)) error('BYTES_STORE_KEY_INVALID')
  if (value !== undefined && (!(value instanceof Uint8Array) || value.length > store.maxValue)) error('BYTES_STORE_VALUE_TOO_LARGE')
}
function reply(id, store, value, cause) {
  parentPort.postMessage({ id, value, used: store?.used ?? 0, ...(cause ? { error: { message: cause.message, code: cause.code } } : {}) })
}
function open(handle, { path, options }) {
  if (stores.has(handle)) error('BYTES_STORE_HANDLE_IN_USE')
  let db
  try {
    if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true })
    db = new Database(path, { timeout: 0 })
    db.exec('PRAGMA locking_mode=EXCLUSIVE; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; BEGIN EXCLUSIVE; CREATE TABLE IF NOT EXISTS stored_bytes (key TEXT PRIMARY KEY, value BLOB NOT NULL); COMMIT')
  } catch (cause) {
    try { db?.close() } catch {}
    if (/locked|busy/i.test(cause.message)) throw Object.assign(new Error('BYTES_STORE_IN_USE', { cause }), { code: 'BYTES_STORE_IN_USE' })
    throw cause
  }
  const store = {
    db, restoring: false, restoredBytes: 0,
    quota: options.quotaBytes ?? 256 * 1024 * 1024,
    maxValue: options.maxValueBytes ?? 128 * 1024 * 1024,
    used: db.prepare('SELECT coalesce(sum(length(value)), 0) AS bytes FROM stored_bytes').get().bytes,
    get: db.prepare('SELECT value FROM stored_bytes WHERE key = ?'),
    size: db.prepare('SELECT length(value) AS bytes FROM stored_bytes WHERE key = ?'),
    put: db.prepare('INSERT INTO stored_bytes (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value'),
    insert: db.prepare('INSERT INTO stored_bytes (key,value) VALUES (?,?)'),
    remove: db.prepare('DELETE FROM stored_bytes WHERE key = ?'),
    count: db.prepare('SELECT count(*) AS count FROM stored_bytes'),
    page: db.prepare('SELECT key,value FROM stored_bytes WHERE key > ? ORDER BY key'),
  }
  stores.set(handle, store)
  return store
}
function run(store, method, args) {
  const db = store.db
  if (method === 'getMany') {
    if (!Array.isArray(args.keys) || args.keys.length > 128) error('BYTES_STORE_BATCH_LIMIT')
    return args.keys.map(key => { validate(store, key); return store.get.get(key)?.value ?? null })
  }
  if (method === 'get') { validate(store, args.key); return store.get.get(args.key)?.value ?? null }
  if (method === 'put') {
    validate(store, args.key, args.value)
    const next = store.used - (store.size.get(args.key)?.bytes ?? 0) + args.value.length
    if (next > store.quota) error('BYTES_STORE_QUOTA_EXCEEDED')
    store.put.run(args.key, args.value); store.used = next
    return undefined
  }
  if (method === 'putMany') {
    if (!Array.isArray(args.entries) || args.entries.length > 128) error('BYTES_STORE_BATCH_LIMIT')
    const staged = new Map()
    for (const entry of args.entries) { validate(store, entry.key, entry.value); staged.set(entry.key, entry.value) }
    let next = store.used
    for (const [k, v] of staged) next = next - (store.size.get(k)?.bytes ?? 0) + v.length
    if (next > store.quota) error('BYTES_STORE_QUOTA_EXCEEDED')
    db.exec('BEGIN IMMEDIATE')
    try {
      for (const [k, v] of staged) store.put.run(k, v)
      db.exec('COMMIT')
      store.used = next
    } catch (cause) { try { db.exec('ROLLBACK') } catch {} throw cause }
    return undefined
  }
  if (method === 'delete') {
    validate(store, args.key)
    const prior = store.size.get(args.key)?.bytes ?? 0
    store.remove.run(args.key); store.used -= prior
    return undefined
  }
  if (method === 'page') {
    const value = []; let bytes = 0
    for (const row of store.page.iterate(args.after)) {
      value.push(row); bytes += row.value.length
      if (value.length >= 64 || bytes >= 1024 * 1024) break
    }
    return value
  }
  if (method === 'restoreBegin') {
    if (store.restoring) error('BYTES_STORE_RESTORE_IN_PROGRESS')
    db.exec('BEGIN IMMEDIATE')
    if (store.count.get().count !== 0) { db.exec('ROLLBACK'); return false }
    store.restoring = true; store.restoredBytes = 0
    return true
  }
  if (method === 'restorePut') {
    if (!store.restoring) error('BYTES_STORE_RESTORE_NOT_STARTED')
    validate(store, args.key, args.value)
    if (store.restoredBytes + args.value.length > store.quota) error('BYTES_STORE_QUOTA_EXCEEDED')
    try { store.insert.run(args.key, args.value) } catch (cause) {
      if (cause.code === 'SQLITE_CONSTRAINT_PRIMARYKEY') error('BYTES_STORE_DUPLICATE_KEY')
      throw cause
    }
    store.restoredBytes += args.value.length
    return undefined
  }
  if (method === 'restoreCommit') {
    if (!store.restoring) error('BYTES_STORE_RESTORE_NOT_STARTED')
    db.exec('COMMIT'); store.restoring = false; store.used = store.restoredBytes
    return undefined
  }
  if (method === 'restoreAbort') {
    if (store.restoring) { db.exec('ROLLBACK'); store.restoring = false }
    return undefined
  }
  if (method === 'checkpoint') { db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); return undefined }
  error('BYTES_STORE_METHOD_INVALID')
}
parentPort.on('message', ({ id, handle, method, args }) => {
  let store
  try {
    if (method === 'open') { store = open(handle, args); reply(id, store); return }
    store = stores.get(handle)
    if (store === undefined) error('BYTES_STORE_CLOSED')
    if (method === 'close') {
      stores.delete(handle)
      if (store.restoring) { try { store.db.exec('ROLLBACK') } catch {} store.restoring = false }
      store.db.close()
      reply(id, store)
      return
    }
    reply(id, store, run(store, method, args))
  } catch (cause) { reply(id, store, undefined, cause) }
})
parentPort.postMessage({ id: 0, used: 0 })
})()
`;

// packages/records/src/native.ts
var NativeStorePool = class {
  worker;
  #requests = /* @__PURE__ */ new Map();
  #ready;
  #nextId = 0;
  #nextHandle = 0;
  #stores = 0;
  #terminating = false;
  failure;
  constructor() {
    this.worker = new Worker(nativeWorkerSource, {
      eval: true,
      workerData: { sqliteModule: createRequire(import.meta.url).resolve("better-sqlite3") }
    });
    this.#ready = new Promise((resolve, reject) => {
      this.#requests.set(0, { resolve: () => resolve(), reject });
    });
    void this.#ready.catch(() => void 0);
    this.worker.on("message", (response) => {
      const request = this.#requests.get(response.id);
      this.#requests.delete(response.id);
      if (response.error === void 0) request?.resolve({ value: response.value, used: response.used });
      else request?.reject(Object.assign(new Error(response.error.message), response.error.code === void 0 ? {} : { code: response.error.code }));
      if (this.#requests.size === 0) this.worker.unref();
    });
    this.worker.on("error", (error) => this.#fail(error));
    this.worker.on("exit", (code) => {
      if (!this.#terminating || this.#requests.size !== 0) this.#fail(new Error(`BYTES_STORE_WORKER_EXIT: ${code}`));
    });
  }
  get stores() {
    return this.#stores;
  }
  acquire() {
    this.#stores++;
    return ++this.#nextHandle;
  }
  release() {
    if (--this.#stores !== 0) return;
    this.#terminating = true;
    if (pool === this) pool = void 0;
    void this.worker.terminate();
  }
  #fail(error) {
    this.failure ??= error;
    if (pool === this) pool = void 0;
    for (const request of this.#requests.values()) request.reject(error);
    this.#requests.clear();
  }
  async request(handle, method, args = {}) {
    await this.#ready;
    if (this.failure !== void 0) throw this.failure;
    const id = ++this.#nextId;
    return new Promise((resolve, reject) => {
      this.#requests.set(id, { resolve, reject });
      this.worker.ref();
      try {
        this.worker.postMessage({ id, handle, method, args });
      } catch (error) {
        this.#requests.delete(id);
        if (this.#requests.size === 0) this.worker.unref();
        reject(error);
      }
    });
  }
};
var pool;
var NativeBytesStore = class _NativeBytesStore {
  #pool;
  #handle;
  #ready;
  #maxValueBytes;
  #pending = Promise.resolve();
  #usedBytes = 0;
  #closed = false;
  #closing;
  constructor(path, options = {}) {
    if (path.length === 0) throw new Error("BYTES_STORE_PATH_REQUIRED");
    for (const value of [options.quotaBytes, options.maxValueBytes]) {
      if (value !== void 0 && (!Number.isSafeInteger(value) || value < 1)) throw new Error("BYTES_STORE_QUOTA_INVALID");
    }
    this.#maxValueBytes = options.maxValueBytes ?? 128 * 1024 * 1024;
    const limits = {
      ...options.quotaBytes === void 0 ? {} : { quotaBytes: options.quotaBytes },
      ...options.maxValueBytes === void 0 ? {} : { maxValueBytes: options.maxValueBytes }
    };
    this.#pool = pool ??= new NativeStorePool();
    this.#handle = this.#pool.acquire();
    this.#ready = this.#pool.request(this.#handle, "open", { path, options: limits }).then(
      (reply) => {
        this.#usedBytes = reply.used;
      },
      (error) => {
        this.#pool.release();
        throw error;
      }
    );
    void this.#ready.catch(() => void 0);
  }
  static async open(path, options = {}) {
    const store = new _NativeBytesStore(path, options);
    await store.#ready;
    return store;
  }
  /** The shared worker and how many stores it currently serves. */
  static poolStatus() {
    return Object.freeze({ threadId: pool?.worker.threadId ?? null, stores: pool?.stores ?? 0 });
  }
  async #request(method, args = {}) {
    await this.#ready;
    const reply = await this.#pool.request(this.#handle, method, args);
    this.#usedBytes = reply.used;
    return reply.value;
  }
  #enqueue(work) {
    if (this.#closed) return Promise.reject(new Error("BYTES_STORE_CLOSED"));
    const task = this.#pending.then(work);
    this.#pending = task.catch(() => void 0);
    return task;
  }
  get(key) {
    return this.#enqueue(() => this.#request("get", { key }));
  }
  getMany(keys) {
    const captured = [...keys];
    return this.#enqueue(() => this.#request("getMany", { keys: captured }));
  }
  put(key, value) {
    if (!(value instanceof Uint8Array) || value.length > this.#maxValueBytes) return Promise.reject(new Error("BYTES_STORE_VALUE_TOO_LARGE"));
    const copy = Uint8Array.from(value);
    return this.#enqueue(() => this.#request("put", { key, value: copy }));
  }
  putMany(entries) {
    if (entries.length === 0) return Promise.resolve();
    if (entries.length > 128) return Promise.reject(new Error("BYTES_STORE_BATCH_LIMIT"));
    const captured = [];
    for (const entry of entries) {
      if (!(entry.value instanceof Uint8Array) || entry.value.length > this.#maxValueBytes) return Promise.reject(new Error("BYTES_STORE_VALUE_TOO_LARGE"));
      captured.push({ key: entry.key, value: Uint8Array.from(entry.value) });
    }
    return this.#enqueue(() => this.#request("putMany", { entries: captured }));
  }
  delete(key) {
    return this.#enqueue(() => this.#request("delete", { key }));
  }
  async *iterateEntries() {
    let release, started;
    const held = new Promise((resolve) => {
      release = resolve;
    }), ready = new Promise((resolve) => {
      started = resolve;
    });
    const owner = this.#enqueue(async () => {
      started();
      await held;
    });
    await Promise.race([ready, owner]);
    try {
      let after = "";
      for (; ; ) {
        const page = await this.#request("page", { after });
        if (page.length === 0) break;
        for (const entry of page) {
          after = entry.key;
          yield entry;
        }
      }
    } finally {
      release();
      await owner;
    }
  }
  async entries() {
    const entries = [];
    for await (const entry of this.iterateEntries()) entries.push(entry);
    return entries;
  }
  putAllIfEmpty(entries) {
    if (entries.some((entry) => !(entry.value instanceof Uint8Array) || entry.value.length > this.#maxValueBytes)) return Promise.reject(new Error("BYTES_STORE_VALUE_TOO_LARGE"));
    const captured = entries.map((entry) => ({ key: entry.key, value: Uint8Array.from(entry.value) }));
    return this.putStreamIfEmpty((async function* () {
      yield* captured;
    })());
  }
  putStreamIfEmpty(entries) {
    return this.#enqueue(async () => {
      if (!await this.#request("restoreBegin")) return false;
      try {
        for await (const entry of entries) await this.#request("restorePut", entry);
        await this.#request("restoreCommit");
        return true;
      } catch (error) {
        await this.#request("restoreAbort");
        throw error;
      }
    });
  }
  checkpointWal() {
    return this.#enqueue(() => this.#request("checkpoint"));
  }
  usageBytes() {
    if (this.#closed) throw new Error("BYTES_STORE_CLOSED");
    return this.#usedBytes;
  }
  close() {
    if (this.#closing !== void 0) return this.#closing;
    this.#closed = true;
    this.#closing = this.#pending.then(async () => {
      try {
        await this.#ready;
      } catch {
        return;
      }
      try {
        await this.#request("close");
      } finally {
        this.#pool.release();
      }
    });
    return this.#closing;
  }
};

// packages/peer-session/src/exit-cleanup.ts
var cleanups = /* @__PURE__ */ new Set();
function runCleanups() {
  for (const cleanup of [...cleanups]) {
    cleanups.delete(cleanup);
    try {
      cleanup();
    } catch {
    }
  }
}
function registerExitCleanup(cleanup) {
  const entry = () => {
    cleanup();
  };
  if (cleanups.size === 0) process.on("exit", runCleanups);
  cleanups.add(entry);
  return () => {
    if (cleanups.delete(entry) && cleanups.size === 0) process.removeListener("exit", runCleanups);
  };
}

// packages/peer-session/src/native.ts
async function openNativeDevice(options) {
  const limits = {
    ...options.quotaBytes === void 0 ? {} : { quotaBytes: options.quotaBytes },
    ...options.maxValueBytes === void 0 ? {} : { maxValueBytes: options.maxValueBytes }
  };
  const store = await NativeBytesStore.open(options.path, limits);
  try {
    return await openApplicationDevice({
      store,
      ...options.create === void 0 ? {} : { create: options.create },
      ...options.managedSigner === void 0 ? {} : { managedSigner: options.managedSigner },
      close: () => store.close()
    });
  } catch (error) {
    await store.close();
    throw error;
  }
}
async function openDisposableNativeDevice(options = {}) {
  const signer = options.managedSigner === void 0 ? {} : { managedSigner: options.managedSigner };
  if (options.sql !== true) {
    const store2 = new MemoryBytesStore(options);
    const device = await openApplicationDevice({ store: store2, create: true, ...signer });
    return Object.freeze({
      ...device,
      ephemeral: true,
      resumable: false,
      storageMode: "disposable-events",
      temporaryDirectory: null,
      databasePath: null
    });
  }
  const temporaryDirectory = join(tmpdir(), `tendriller-disposable-${randomUUID()}`);
  mkdirSync(temporaryDirectory, { recursive: true, mode: 448 });
  const storePath = join(temporaryDirectory, "device.sqlite");
  const databasePath = join(temporaryDirectory, "app.sqlite");
  const limits = {
    ...options.quotaBytes === void 0 ? {} : { quotaBytes: options.quotaBytes },
    ...options.maxValueBytes === void 0 ? {} : { maxValueBytes: options.maxValueBytes }
  };
  let store;
  try {
    store = await NativeBytesStore.open(storePath, limits);
  } catch (error) {
    rmSync(temporaryDirectory, { recursive: true, force: true });
    throw error;
  }
  let cleaned = false;
  const cleanupDir = () => {
    if (cleaned) return;
    cleaned = true;
    try {
      void store.close().catch(() => void 0);
    } catch {
    }
    try {
      rmSync(temporaryDirectory, { recursive: true, force: true });
    } catch {
    }
  };
  const unregister = registerExitCleanup(cleanupDir);
  try {
    const device = await openApplicationDevice({
      store,
      create: true,
      ...signer,
      async close() {
        await store.close();
        unregister();
        cleanupDir();
      }
    });
    return Object.freeze({
      ...device,
      ephemeral: true,
      resumable: false,
      storageMode: "disposable-sql",
      temporaryDirectory,
      databasePath
    });
  } catch (error) {
    unregister();
    try {
      await store.close();
    } catch {
    }
    cleanupDir();
    throw error;
  }
}
export {
  NativeBytesStore,
  createApplicationSession,
  openDisposableNativeDevice,
  openNativeDevice
};
