import type { GenesisBlock } from '../../protocol/src/index.js';
import type { BlockchainAnchorVerifier } from '../../authority/src/index.js';
import type { QuickJsSandboxOptions } from '../../materializer/src/index.js';
import { type ApplicationDevice } from './device.js';
import type { ApplicationDefinition } from './definition.js';
import { ApplicationSession, type SessionCasNode } from './session.js';
export interface CreateApplicationSessionOptions<D extends ApplicationDefinition = ApplicationDefinition> extends QuickJsSandboxOptions {
    readonly device: ApplicationDevice;
    readonly genesis?: GenesisBlock | Uint8Array;
    readonly chainId?: string;
    /** Optional host-level application scope ID (defaults to `chainId`). */
    readonly applicationId?: string;
    readonly casNodes?: readonly SessionCasNode[];
    readonly epochKeys?: ReadonlyMap<number, Uint8Array>;
    readonly definition?: D;
    readonly blindHostMode?: boolean;
    readonly blockchainVerifier?: BlockchainAnchorVerifier;
    readonly sqliteWasmModule?: WebAssembly.Module;
    readonly sqliteWasmBytes?: Uint8Array;
    readonly maxOperations?: number;
}
/** Opens a Chronolog v2 local-first ApplicationSession on the claimed device. */
export declare function createApplicationSession<const D extends ApplicationDefinition = ApplicationDefinition>(options: CreateApplicationSessionOptions<D>): Promise<ApplicationSession<D>>;
