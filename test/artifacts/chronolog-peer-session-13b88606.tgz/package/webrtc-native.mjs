import {
  WEBRTC_LIMITS,
  connectApplicationWebRtc
} from "./chunks/chunk-UYBPNY7I.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-IEAQOO7O.mjs";

// packages/transport-webrtc/src/native.ts
import { RTCPeerConnection } from "werift";
function createNativePeerConnection(configuration = {}, native = {}) {
  if (configuration.certificates !== void 0) throw new Error("WEBRTC_NATIVE_CERTIFICATES_UNSUPPORTED");
  const peer = new RTCPeerConnection({
    ...native,
    iceStunGatherTimeout: native.iceStunGatherTimeout ?? WEBRTC_LIMITS.gatheringMs / 1e3,
    iceUseDefaultStunServer: false,
    certificateScope: "peerConnection",
    iceServers: configuration.iceServers?.map((server) => ({
      urls: server.urls,
      ...server.username === void 0 ? {} : { username: server.username },
      ...server.credential === void 0 ? {} : { credential: server.credential }
    })) ?? [],
    ...configuration.iceTransportPolicy === void 0 ? {} : { iceTransportPolicy: configuration.iceTransportPolicy },
    ...configuration.bundlePolicy === void 0 ? {} : { bundlePolicy: configuration.bundlePolicy },
    ...configuration.iceCandidatePoolSize === void 0 ? {} : { iceCandidatePoolSize: configuration.iceCandidatePoolSize }
  });
  const events = new EventTarget(), channels = /* @__PURE__ */ new Set();
  const wrap = (channel) => {
    const value = new NativeDataChannel(channel);
    channels.add(value);
    return value;
  };
  const subscriptions = [
    peer.onDataChannel.subscribe((channel) => events.dispatchEvent(Object.assign(new Event("datachannel"), { channel: wrap(channel) }))),
    peer.connectionStateChange.subscribe(() => events.dispatchEvent(new Event("connectionstatechange"))),
    peer.iceGatheringStateChange.subscribe(() => events.dispatchEvent(new Event("icegatheringstatechange")))
  ];
  return {
    get localDescription() {
      return peer.localDescription;
    },
    get iceGatheringState() {
      return peer.iceGatheringState;
    },
    get connectionState() {
      return peer.connectionState;
    },
    getStats: () => peer.getStats(),
    createDataChannel: (label, options) => wrap(peer.createDataChannel(label, options)),
    createOffer: () => peer.createOffer(),
    createAnswer: () => peer.createAnswer(),
    async setLocalDescription(description) {
      if (description.type !== "offer" && description.type !== "answer" || description.sdp === void 0) throw new Error("WEBRTC_DESCRIPTION_INVALID");
      await peer.setLocalDescription({ type: description.type, sdp: description.sdp });
    },
    async setRemoteDescription(description) {
      if (description.type !== "offer" && description.type !== "answer" || description.sdp === void 0) throw new Error("WEBRTC_DESCRIPTION_INVALID");
      await peer.setRemoteDescription({ type: description.type, sdp: description.sdp });
    },
    addEventListener: (type, listener) => events.addEventListener(type, listener),
    removeEventListener: (type, listener) => events.removeEventListener(type, listener),
    async close() {
      for (const subscription of subscriptions) subscription.unSubscribe();
      for (const channel of channels) channel.close();
      await peer.close();
    }
  };
}
var NativeDataChannel = class extends EventTarget {
  binaryType = "arraybuffer";
  #closed = false;
  #channel;
  #subscriptions;
  constructor(channel) {
    super();
    this.#channel = channel;
    this.#subscriptions = [
      channel.onMessage.subscribe((data) => {
        const value = typeof data === "string" ? data : new Uint8Array(data).buffer;
        this.dispatchEvent(new MessageEvent("message", { data: value }));
      }),
      channel.stateChanged.subscribe((state) => {
        if (state === "open") this.dispatchEvent(new Event("open"));
        else if (state === "closed") this.close();
      }),
      channel.bufferedAmountLow.subscribe(() => this.dispatchEvent(new Event("bufferedamountlow"))),
      channel.error.subscribe(() => this.dispatchEvent(new Event("error")))
    ];
  }
  get label() {
    return this.#channel.label;
  }
  get ordered() {
    return this.#channel.ordered;
  }
  get maxPacketLifeTime() {
    return this.#channel.maxPacketLifeTime;
  }
  get maxRetransmits() {
    return this.#channel.maxRetransmits;
  }
  get readyState() {
    return this.#channel.readyState;
  }
  get bufferedAmount() {
    return this.#channel.bufferedAmount;
  }
  get bufferedAmountLowThreshold() {
    return this.#channel.bufferedAmountLowThreshold;
  }
  set bufferedAmountLowThreshold(value) {
    this.#channel.bufferedAmountLowThreshold = value;
  }
  send(data) {
    this.#channel.send(Buffer.from(data));
  }
  close() {
    if (this.#closed) return;
    this.#closed = true;
    this.dispatchEvent(new Event("close"));
    for (const subscription of this.#subscriptions) subscription.unSubscribe();
    this.#channel.close();
  }
};

// packages/peer-session/src/webrtc-native.ts
function connectNativeApplicationWebRtc(session, options) {
  return connectApplicationWebRtc(session, { ...options, createPeerConnection: (configuration) => createNativePeerConnection(configuration, options.native) });
}
export {
  connectNativeApplicationWebRtc,
  createNativePeerConnection
};
