import {
  openApplicationDevice,
  openPeerApplication
} from "./chunks/chunk-GZRGH5GA.mjs";
import "./chunks/chunk-DDWT6CDC.mjs";
import "./chunks/chunk-Q6DWSCSA.mjs";
import "./chunks/chunk-G2YASPQR.mjs";
import "./chunks/chunk-F2F5EOFI.mjs";
import "./chunks/chunk-Q5HDMKTI.mjs";
import "./chunks/chunk-LR76T2KY.mjs";
import "./chunks/chunk-DEFS6EFN.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import {
  MemoryBytesStore
} from "./chunks/chunk-IEAQOO7O.mjs";

// packages/peer-session/src/native.ts
import { randomUUID } from "node:crypto";
import { mkdirSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

// packages/records/src/native.ts
import { createRequire } from "node:module";
import { Worker } from "node:worker_threads";

// packages/records/src/native-worker.ts
var nativeWorkerSource = String.raw`
(async () => {
const { parentPort, workerData } = await import('node:worker_threads')
const { createRequire } = await import('node:module')
const require = createRequire(workerData.sqliteModule)
const { mkdirSync } = require('node:fs')
const { dirname } = require('node:path')
const Database = require(workerData.sqliteModule)
let db, used = 0, restoring = false, restoredBytes = 0
const quota = workerData.options.quotaBytes ?? 256 * 1024 * 1024
const maxValue = workerData.options.maxValueBytes ?? 128 * 1024 * 1024
function error(message) { throw new Error(message) }
function validate(key, value) {
  if (typeof key !== 'string' || key.length === 0 || key.length > 4096 || [...key].some(c => c.charCodeAt(0) < 32)) error('BYTES_STORE_KEY_INVALID')
  if (value !== undefined && (!(value instanceof Uint8Array) || value.length > maxValue)) error('BYTES_STORE_VALUE_TOO_LARGE')
}
function reply(id, value, cause) {
  parentPort.postMessage({ id, value, used, ...(cause ? { error: { message: cause.message, code: cause.code } } : {}) })
}
try {
  if (workerData.path !== ':memory:') mkdirSync(dirname(workerData.path), { recursive: true })
  db = new Database(workerData.path, { timeout: 0 })
  db.exec('PRAGMA locking_mode=EXCLUSIVE; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; BEGIN EXCLUSIVE; CREATE TABLE IF NOT EXISTS stored_bytes (key TEXT PRIMARY KEY, value BLOB NOT NULL); COMMIT')
  used = db.prepare('SELECT coalesce(sum(length(value)), 0) AS bytes FROM stored_bytes').get().bytes
} catch (cause) {
  try { db?.close() } catch {}
  if (/locked|busy/i.test(cause.message)) cause = new Error('BYTES_STORE_IN_USE', { cause })
  reply(0, undefined, cause)
  parentPort.close()
  return
}
const get = db.prepare('SELECT value FROM stored_bytes WHERE key = ?')
const size = db.prepare('SELECT length(value) AS bytes FROM stored_bytes WHERE key = ?')
const put = db.prepare('INSERT INTO stored_bytes (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
const insert = db.prepare('INSERT INTO stored_bytes (key,value) VALUES (?,?)')
const remove = db.prepare('DELETE FROM stored_bytes WHERE key = ?')
const count = db.prepare('SELECT count(*) AS count FROM stored_bytes')
const page = db.prepare('SELECT key,value FROM stored_bytes WHERE key > ? ORDER BY key')
reply(0)
parentPort.on('message', ({ id, method, args }) => {
  try {
    let value
    if (method === 'getMany') {
      if (!Array.isArray(args.keys) || args.keys.length > 128) error('BYTES_STORE_BATCH_LIMIT')
      value = args.keys.map(key => { validate(key); return get.get(key)?.value ?? null })
    } else if (method === 'get') { validate(args.key); value = get.get(args.key)?.value ?? null }
    else if (method === 'put') {
      validate(args.key, args.value)
      const next = used - (size.get(args.key)?.bytes ?? 0) + args.value.length
      if (next > quota) error('BYTES_STORE_QUOTA_EXCEEDED')
      put.run(args.key, args.value); used = next
    } else if (method === 'putMany') {
      if (!Array.isArray(args.entries) || args.entries.length > 128) error('BYTES_STORE_BATCH_LIMIT')
      const staged = new Map()
      for (const entry of args.entries) { validate(entry.key, entry.value); staged.set(entry.key, entry.value) }
      let next = used
      for (const [k, v] of staged) next = next - (size.get(k)?.bytes ?? 0) + v.length
      if (next > quota) error('BYTES_STORE_QUOTA_EXCEEDED')
      db.exec('BEGIN IMMEDIATE')
      try {
        for (const [k, v] of staged) put.run(k, v)
        db.exec('COMMIT')
        used = next
      } catch (cause) { try { db.exec('ROLLBACK') } catch {} throw cause }
    } else if (method === 'delete') {
      validate(args.key)
      const prior = size.get(args.key)?.bytes ?? 0
      remove.run(args.key); used -= prior
    } else if (method === 'page') {
      value = []; let bytes = 0
      for (const row of page.iterate(args.after)) {
        value.push(row); bytes += row.value.length
        if (value.length >= 64 || bytes >= 1024 * 1024) break
      }
    } else if (method === 'restoreBegin') {
      if (restoring) error('BYTES_STORE_RESTORE_IN_PROGRESS')
      db.exec('BEGIN IMMEDIATE')
      if (count.get().count !== 0) { db.exec('ROLLBACK'); value = false }
      else { restoring = true; restoredBytes = 0; value = true }
    } else if (method === 'restorePut') {
      if (!restoring) error('BYTES_STORE_RESTORE_NOT_STARTED')
      validate(args.key, args.value)
      if (restoredBytes + args.value.length > quota) error('BYTES_STORE_QUOTA_EXCEEDED')
      try { insert.run(args.key, args.value) } catch (cause) {
        if (cause.code === 'SQLITE_CONSTRAINT_PRIMARYKEY') error('BYTES_STORE_DUPLICATE_KEY')
        throw cause
      }
      restoredBytes += args.value.length
    } else if (method === 'restoreCommit') {
      if (!restoring) error('BYTES_STORE_RESTORE_NOT_STARTED')
      db.exec('COMMIT'); restoring = false; used = restoredBytes
    } else if (method === 'restoreAbort') {
      if (restoring) { db.exec('ROLLBACK'); restoring = false }
    } else if (method === 'checkpoint') db.exec('PRAGMA wal_checkpoint(TRUNCATE)')
    else if (method === 'close') {
      if (restoring) { db.exec('ROLLBACK'); restoring = false }
      db.close()
    } else error('BYTES_STORE_METHOD_INVALID')
    reply(id, value)
    if (method === 'close') parentPort.close()
  } catch (cause) { reply(id, undefined, cause) }
})
})()
`;

// packages/records/src/native.ts
var NativeBytesStore = class _NativeBytesStore {
  #worker;
  #requests = /* @__PURE__ */ new Map();
  #ready;
  #maxValueBytes;
  #pending = Promise.resolve();
  #nextId = 0;
  #usedBytes = 0;
  #closed = false;
  #closing;
  #failure;
  constructor(path, options = {}) {
    if (path.length === 0) throw new Error("BYTES_STORE_PATH_REQUIRED");
    for (const value of [options.quotaBytes, options.maxValueBytes]) {
      if (value !== void 0 && (!Number.isSafeInteger(value) || value < 1)) throw new Error("BYTES_STORE_QUOTA_INVALID");
    }
    this.#maxValueBytes = options.maxValueBytes ?? 128 * 1024 * 1024;
    this.#worker = new Worker(nativeWorkerSource, {
      eval: true,
      workerData: { path, options, sqliteModule: createRequire(import.meta.url).resolve("better-sqlite3") }
    });
    this.#ready = new Promise((resolve, reject) => {
      this.#requests.set(0, { resolve: () => resolve(), reject });
    });
    void this.#ready.catch(() => void 0);
    this.#worker.on("message", (response) => {
      this.#usedBytes = response.used;
      const request = this.#requests.get(response.id);
      this.#requests.delete(response.id);
      if (response.error === void 0) request?.resolve(response.value);
      else request?.reject(Object.assign(new Error(response.error.message), response.error.code === void 0 ? {} : { code: response.error.code }));
      if (this.#requests.size === 0) this.#worker.unref();
    });
    this.#worker.on("error", (error) => this.#fail(error));
    this.#worker.on("exit", (code) => {
      if (!this.#closed || this.#requests.size !== 0) this.#fail(new Error(`BYTES_STORE_WORKER_EXIT: ${code}`));
    });
  }
  static async open(path, options = {}) {
    const store = new _NativeBytesStore(path, options);
    try {
      await store.#ready;
      return store;
    } catch (error) {
      await store.#worker.terminate();
      throw error;
    }
  }
  #fail(error) {
    this.#failure = error;
    for (const request of this.#requests.values()) request.reject(error);
    this.#requests.clear();
  }
  async #request(method, args = {}) {
    await this.#ready;
    if (this.#failure !== void 0) throw this.#failure;
    const id = ++this.#nextId;
    return new Promise((resolve, reject) => {
      this.#requests.set(id, { resolve: (value) => resolve(value), reject });
      this.#worker.ref();
      try {
        this.#worker.postMessage({ id, method, args });
      } catch (error) {
        this.#requests.delete(id);
        if (this.#requests.size === 0) this.#worker.unref();
        reject(error);
      }
    });
  }
  #enqueue(work) {
    if (this.#closed) return Promise.reject(new Error("BYTES_STORE_CLOSED"));
    const task = this.#pending.then(work);
    this.#pending = task.catch(() => void 0);
    return task;
  }
  get(key) {
    return this.#enqueue(() => this.#request("get", { key }));
  }
  getMany(keys) {
    const captured = [...keys];
    return this.#enqueue(() => this.#request("getMany", { keys: captured }));
  }
  put(key, value) {
    if (!(value instanceof Uint8Array) || value.length > this.#maxValueBytes) return Promise.reject(new Error("BYTES_STORE_VALUE_TOO_LARGE"));
    const copy = Uint8Array.from(value);
    return this.#enqueue(() => this.#request("put", { key, value: copy }));
  }
  putMany(entries) {
    if (entries.length === 0) return Promise.resolve();
    if (entries.length > 128) return Promise.reject(new Error("BYTES_STORE_BATCH_LIMIT"));
    const captured = [];
    for (const entry of entries) {
      if (!(entry.value instanceof Uint8Array) || entry.value.length > this.#maxValueBytes) return Promise.reject(new Error("BYTES_STORE_VALUE_TOO_LARGE"));
      captured.push({ key: entry.key, value: Uint8Array.from(entry.value) });
    }
    return this.#enqueue(() => this.#request("putMany", { entries: captured }));
  }
  delete(key) {
    return this.#enqueue(() => this.#request("delete", { key }));
  }
  async *iterateEntries() {
    let release, started;
    const held = new Promise((resolve) => {
      release = resolve;
    }), ready = new Promise((resolve) => {
      started = resolve;
    });
    const owner = this.#enqueue(async () => {
      started();
      await held;
    });
    await Promise.race([ready, owner]);
    try {
      let after = "";
      for (; ; ) {
        const page = await this.#request("page", { after });
        if (page.length === 0) break;
        for (const entry of page) {
          after = entry.key;
          yield entry;
        }
      }
    } finally {
      release();
      await owner;
    }
  }
  async entries() {
    const entries = [];
    for await (const entry of this.iterateEntries()) entries.push(entry);
    return entries;
  }
  putAllIfEmpty(entries) {
    if (entries.some((entry) => !(entry.value instanceof Uint8Array) || entry.value.length > this.#maxValueBytes)) return Promise.reject(new Error("BYTES_STORE_VALUE_TOO_LARGE"));
    const captured = entries.map((entry) => ({ key: entry.key, value: Uint8Array.from(entry.value) }));
    return this.putStreamIfEmpty((async function* () {
      yield* captured;
    })());
  }
  putStreamIfEmpty(entries) {
    return this.#enqueue(async () => {
      if (!await this.#request("restoreBegin")) return false;
      try {
        for await (const entry of entries) await this.#request("restorePut", entry);
        await this.#request("restoreCommit");
        return true;
      } catch (error) {
        await this.#request("restoreAbort");
        throw error;
      }
    });
  }
  checkpointWal() {
    return this.#enqueue(() => this.#request("checkpoint"));
  }
  usageBytes() {
    if (this.#closed) throw new Error("BYTES_STORE_CLOSED");
    return this.#usedBytes;
  }
  close() {
    if (this.#closing !== void 0) return this.#closing;
    this.#closed = true;
    this.#closing = this.#pending.then(async () => {
      try {
        await this.#request("close");
      } finally {
        await this.#worker.terminate();
      }
    });
    return this.#closing;
  }
};

// packages/peer-session/src/native.ts
async function openNativeDevice(options) {
  const limits = {
    ...options.quotaBytes === void 0 ? {} : { quotaBytes: options.quotaBytes },
    ...options.maxValueBytes === void 0 ? {} : { maxValueBytes: options.maxValueBytes }
  };
  const store = await NativeBytesStore.open(options.path, limits);
  try {
    return await openApplicationDevice({ store, ...options.create === void 0 ? {} : { create: options.create }, close: () => store.close() });
  } catch (error) {
    await store.close();
    throw error;
  }
}
async function openDisposableNativeDevice(options = {}) {
  if (options.sql !== true) {
    const store2 = new MemoryBytesStore(options);
    const device = await openApplicationDevice({ store: store2, create: true });
    return Object.freeze({
      ...device,
      ephemeral: true,
      resumable: false,
      storageMode: "disposable-events",
      temporaryDirectory: null,
      databasePath: null
    });
  }
  const temporaryDirectory = join(tmpdir(), `tendriller-disposable-${randomUUID()}`);
  mkdirSync(temporaryDirectory, { recursive: true, mode: 448 });
  const storePath = join(temporaryDirectory, "device.sqlite");
  const databasePath = join(temporaryDirectory, "app.sqlite");
  const limits = {
    ...options.quotaBytes === void 0 ? {} : { quotaBytes: options.quotaBytes },
    ...options.maxValueBytes === void 0 ? {} : { maxValueBytes: options.maxValueBytes }
  };
  let store;
  try {
    store = await NativeBytesStore.open(storePath, limits);
  } catch (error) {
    rmSync(temporaryDirectory, { recursive: true, force: true });
    throw error;
  }
  let cleaned = false;
  const cleanupDir = () => {
    if (cleaned) return;
    cleaned = true;
    try {
      void store.close().catch(() => void 0);
    } catch {
    }
    try {
      rmSync(temporaryDirectory, { recursive: true, force: true });
    } catch {
    }
  };
  const onExit = () => {
    cleanupDir();
  };
  process.once("exit", onExit);
  try {
    const device = await openApplicationDevice({
      store,
      create: true,
      async close() {
        await store.close();
        process.removeListener("exit", onExit);
        cleanupDir();
      }
    });
    return Object.freeze({
      ...device,
      ephemeral: true,
      resumable: false,
      storageMode: "disposable-sql",
      temporaryDirectory,
      databasePath
    });
  } catch (error) {
    process.removeListener("exit", onExit);
    try {
      await store.close();
    } catch {
    }
    cleanupDir();
    throw error;
  }
}
export {
  NativeBytesStore,
  openDisposableNativeDevice,
  openPeerApplication as openNativeApplication,
  openNativeDevice
};
