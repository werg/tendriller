// packages/peer-session/src/errors.ts
var AbandonedOperationError = class extends Error {
  constructor(operation) {
    super("APPLICATION_OPERATION_ABANDONED");
    this.operation = operation;
    this.name = "AbandonedOperationError";
  }
  operation;
};
var RecoveredViewError = class extends Error {
  constructor(revision, recovery = null) {
    super("APPLICATION_VIEW_RECOVERED");
    this.revision = revision;
    this.name = "RecoveredViewError";
    this.recovery = structuredClone(recovery);
  }
  revision;
  code = "APPLICATION_VIEW_RECOVERED";
  recovery;
};
var ApplicationControlConflictError = class extends Error {
  code = "peer_generation_conflict";
  constructor(message = "The expected application generation is no longer selected.", options) {
    super(message, options);
    this.name = "ApplicationControlConflictError";
  }
};

export {
  AbandonedOperationError,
  RecoveredViewError,
  ApplicationControlConflictError
};
