import {
  APPLICATION_PROJECTION_LIMITS
} from "./chunk-DDWT6CDC.mjs";
import {
  APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES,
  APPLICATION_OWNER_PROTOCOL,
  MAX_RELEASES,
  MAX_REQUESTS,
  MAX_STREAMS,
  PROTOCOL,
  bounded,
  releasesResource
} from "./chunk-2ZKHAZYZ.mjs";
import {
  AbandonedOperationError,
  RecoveredViewError
} from "./chunk-F2F5EOFI.mjs";

// packages/peer-session/src/worker-application-server.ts
function serveApplicationWorker(session, endpoint, options = {}) {
  let port, closed = false, lastId = 0, nextView = 0, nextProjection = 0, openingViews = 0;
  let closing;
  const calls = /* @__PURE__ */ new Map(), streams = /* @__PURE__ */ new Map();
  const views = /* @__PURE__ */ new Map();
  const projections = /* @__PURE__ */ new Map();
  const protocol = options.binding === void 0 ? PROTOCOL : APPLICATION_OWNER_PROTOCOL;
  const reserve = (kind) => options.reserve?.(kind) ?? (() => void 0);
  const allowed = (capability) => {
    if (options.capabilities !== void 0 && !options.capabilities.includes(capability)) throw new Error("APPLICATION_ATTACHMENT_FORBIDDEN");
  };
  const preparedInput = (name, input) => {
    allowed("commands");
    if (options.commands !== void 0 && !options.commands.includes(name)) throw new Error("APPLICATION_ATTACHMENT_COMMAND_FORBIDDEN");
    return options.binding === void 0 || options.prepareCommand === void 0 ? input : options.prepareCommand(options.binding, name, input);
  };
  const send = (value) => {
    bounded(value);
    port?.postMessage(value);
  };
  const respond = (id, value) => {
    send({ id, value, snapshot: snapshot(session) });
  };
  const cancelStream = async (id) => {
    const stream = streams.get(id);
    if (stream === void 0) return;
    streams.delete(id);
    stream.release();
    stream.controller.abort(new Error("APPLICATION_WORKER_CANCELLED"));
    await stream.iterator.return?.().catch(() => void 0);
  };
  const stop = (reason) => {
    if (closing !== void 0) return closing;
    closed = true;
    endpoint.removeEventListener("message", connect);
    session.signal.removeEventListener("abort", aborted);
    for (const call of calls.values()) call.controller.abort(reason);
    for (const view2 of views.values()) {
      view2.handle.release();
      view2.release();
    }
    views.clear();
    projections.clear();
    port?.removeEventListener("message", receive);
    port?.removeEventListener("messageerror", messageError);
    closing = Promise.allSettled([...streams.keys()].map(cancelStream)).then(async () => {
      try {
        if (options.closeSession !== false) await session.close();
      } finally {
        try {
          send({ ended: errorValue(reason) });
        } catch {
        }
        port?.close();
        options.onClose?.();
      }
    });
    return closing;
  };
  const aborted = () => {
    void stop(session.signal.reason).catch(() => void 0);
  };
  const messageError = () => {
    void stop(new Error("APPLICATION_WORKER_MESSAGE_INVALID")).catch(() => void 0);
  };
  const controlHost = () => {
    if (options.host === void 0) throw new Error("APPLICATION_CONTROL_HOST_UNAVAILABLE");
    return options.host;
  };
  const participation = () => {
    if (session.participation === void 0) throw new Error("APPLICATION_PARTICIPATION_UNAVAILABLE");
    return session.participation;
  };
  const view = (id) => {
    const result = typeof id === "number" ? views.get(id) : void 0;
    if (result === void 0) throw new Error("APPLICATION_VIEW_RELEASED");
    return result.handle;
  };
  const captureProjection = (name) => {
    const current = session.projection(name);
    for (const [id2, handle2] of projections) {
      try {
        if (session.projection(handle2.id) !== handle2) projections.delete(id2);
      } catch {
        projections.delete(id2);
      }
      if (handle2 === current) return id2;
    }
    if (projections.size >= APPLICATION_PROJECTION_LIMITS.active) throw new Error("APPLICATION_PROJECTION_LIMIT");
    const id = ++nextProjection;
    if (!Number.isSafeInteger(id)) throw new Error("APPLICATION_WORKER_REQUEST_ID_EXHAUSTED");
    projections.set(id, current);
    return id;
  };
  const projection = (id) => {
    const handle2 = typeof id === "number" ? projections.get(id) : void 0;
    if (handle2 === void 0) throw new Error("APPLICATION_PROJECTION_CLOSED");
    return handle2;
  };
  const invoke = async (method, args, signal, requestId) => {
    if (["adopt", "recovery.takeover", "recovery.handover", "participation.approve", "participation.close"].includes(method)) allowed("ownerAdmin");
    if (method.startsWith("operation.") || ["retry", "resume"].includes(method)) allowed("operations");
    if (method.startsWith("content.")) allowed("content");
    if (method.startsWith("projection.")) allowed("events");
    if (method === "signals.send") allowed("signals");
    switch (method) {
      case "authority":
        allowed("diagnostics");
        return session.authority();
      case "command":
        return (await session.command(args[0], preparedInput(args[0], args[1]), args[2])).operationId;
      case "reapply":
        return (await session.reapply(args[0], args[1], preparedInput(args[1], args[2]), args[3])).operationId;
      case "query": {
        allowed("queries");
        if (options.queries !== void 0 && !options.queries.includes(args[0])) throw new Error("APPLICATION_ATTACHMENT_QUERY_FORBIDDEN");
        return session.query(args[0], args[1]);
      }
      case "endpoint.suspend":
        options.onState?.("suspended");
        return null;
      case "endpoint.resume":
        options.onState?.("active");
        return options.binding ?? null;
      case "endpoints.list":
        allowed("diagnostics");
        return options.listEndpoints?.() ?? [];
      case "owner.shutdown":
        allowed("ownerAdmin");
        await options.shutdown?.();
        return null;
      case "operation.get":
        return session.operations.get(args[0], args[1]);
      case "operation.inspect":
        return session.operations.inspect(args[0], args[1]);
      case "operation.wait":
        return session.operations.wait(args[0], { ...args[1], signal });
      case "operation.shared":
        return session.waitForCoverage(await session.operations.wait(args[0], { signal }), { signal });
      case "retry":
        return session.retry(args[0]);
      case "resume":
        return session.resume();
      case "inspectRecovery":
        return session.inspectRecovery();
      case "recoveryPoint":
        return session.recoveryPoint();
      case "adopt":
        return session.adopt(args[0]);
      case "recovery.inspect":
        return session.recovery.inspect();
      case "recovery.takeover":
        return session.recovery.takeover(controlHost(), { ...args[0], signal });
      case "recovery.handover":
        return session.recovery.handover(controlHost(), { ...args[0], signal });
      case "participation.diagnostics":
        allowed("diagnostics");
        return participation().diagnostics();
      case "participation.reconsider":
        allowed("diagnostics");
        return participation().reconsiderConnections();
      case "participation.approve":
        return participation().approveRecovery(args[0]);
      case "participation.close":
        return participation().close();
      case "signals.send": {
        const input = args[2], binding = options.binding;
        return session.signals.send(args[0], args[1], {
          ...input,
          signal,
          ...binding === void 0 ? {} : { stream: { ...input.stream, streamId: input.stream?.streamId ?? binding.context.runId ?? "default", endpointId: binding.endpointId, endpointIncarnation: binding.endpointIncarnation } }
        });
      }
      case "view.open": {
        if (options.capabilities !== void 0 && !options.capabilities.some((value) => value === "queries" || value === "events")) throw new Error("APPLICATION_ATTACHMENT_FORBIDDEN");
        if (views.size + openingViews >= (options.maxViews ?? 16)) throw new Error("APPLICATION_WORKER_VIEW_LIMIT");
        const release = reserve("views");
        openingViews++;
        let captured;
        try {
          captured = await session.readView();
        } catch (error) {
          release();
          throw error;
        } finally {
          openingViews--;
        }
        if (signal.aborted) {
          captured.release();
          release();
          signal.throwIfAborted();
        }
        const id = ++nextView;
        views.set(id, { handle: captured, requestId, release });
        return { id, revision: captured.revision };
      }
      case "view.query":
        allowed("queries");
        if (options.queries !== void 0) throw new Error("APPLICATION_ATTACHMENT_QUERY_FORBIDDEN");
        return view(args[0]).query(args[1], args[2]);
      case "view.events":
        allowed("events");
        return view(args[0]).readEvents(args[1]);
      case "view.release": {
        const captured = views.get(args[0]);
        views.delete(args[0]);
        captured?.handle.release();
        captured?.release();
        return null;
      }
      case "projection.open":
        return captureProjection(args[0]);
      case "projection.read":
        return projection(args[0]).read({ signal });
      case "projection.close": {
        const id = args[0], captured = projections.get(id);
        if (options.closeSession !== false) await captured?.close();
        for (const [streamId, stream] of streams) if (stream.projectionId === id) await cancelStream(streamId);
        projections.delete(id);
        return null;
      }
      case "content.stage":
        return (await session.content.stage(args[0])).id;
      case "content.resume":
        return (await session.content.resume(args[0])).id;
      case "content.write":
        return (await session.content.resume(args[0])).write(args[1], args[2]);
      case "content.prune":
        return session.content.prune(args[0]);
      case "content.discard":
        return session.content.discard(args[0]);
      case "content.progress":
        return (await session.content.resume(args[0])).progress();
      case "content.commit":
        return (await session.content.resume(args[0])).commit();
      case "content.retain":
        return session.content.retain(args[0], { signal });
      case "content.retained":
        return session.content.retained(args[0]);
      case "content.retention":
        return session.content.retention(args[0]);
      default:
        throw new Error("APPLICATION_WORKER_METHOD_UNKNOWN");
    }
  };
  const openStream = (name, args, signal) => {
    if (name === "signals") allowed("signals");
    else if (name === "content") allowed("content");
    else if (name === "changes" || name === "projection") allowed("events");
    else allowed("diagnostics");
    switch (name) {
      case "changes":
        return session.changes({ signal })[Symbol.asyncIterator]();
      case "signals":
        return session.signals.subscribe({ ...args[0], signal })[Symbol.asyncIterator]();
      case "status":
        return observe((listener) => session.onStatus(listener), signal);
      case "participation":
        return observe((listener) => participation().onStatus(listener), signal);
      case "recovery":
        return observe((listener) => session.onRecovery(listener), signal);
      case "content":
        return session.content.read(args[0], { ...args[1], signal })[Symbol.asyncIterator]();
      case "projection": {
        const captured = projections.get(args[0]);
        return captured?.changes({ signal })[Symbol.asyncIterator]() ?? { next: async () => ({ done: true, value: void 0 }) };
      }
      default:
        throw new Error("APPLICATION_WORKER_STREAM_UNKNOWN");
    }
  };
  const handle = async (request) => {
    if (closed) throw new Error("APPLICATION_SESSION_CLOSED");
    if (request.method === "close") {
      await stop(new Error("APPLICATION_SESSION_CLOSED"));
      return;
    }
    const release = releasesResource(request.method);
    if ([...calls.values()].filter((call) => call.release === release).length >= (release ? MAX_RELEASES : options.maxRequests ?? MAX_REQUESTS)) throw new Error("APPLICATION_WORKER_REQUEST_LIMIT");
    const releaseRequest = release ? () => void 0 : reserve("requests");
    const controller = new AbortController();
    calls.set(request.id, { controller, release });
    try {
      let result;
      if (request.method === "stream.open") {
        if (streams.size >= (options.maxStreams ?? MAX_STREAMS)) throw new Error("APPLICATION_WORKER_STREAM_LIMIT");
        const releaseStream = reserve("streams");
        let iterator;
        try {
          iterator = openStream(request.args[0], request.args.slice(1), controller.signal);
        } catch (error) {
          releaseStream();
          throw error;
        }
        streams.set(request.id, { iterator, controller, release: releaseStream, busy: false, ...request.args[0] === "projection" ? { projectionId: request.args[1] } : {} });
        result = request.id;
      } else if (request.method === "stream.next") {
        const stream = streams.get(request.args[0]);
        if (stream === void 0) throw new Error("APPLICATION_WORKER_STREAM_CLOSED");
        if (stream.busy) throw new Error("APPLICATION_WORKER_STREAM_BUSY");
        stream.busy = true;
        try {
          result = await stream.iterator.next();
        } finally {
          stream.busy = false;
        }
        if (result.done) await cancelStream(request.args[0]);
      } else result = await invoke(request.method, request.args, controller.signal, request.id);
      if (!closed && !controller.signal.aborted) respond(request.id, result);
    } finally {
      calls.delete(request.id);
      releaseRequest();
    }
  };
  const receive = (event) => {
    const input = event.data;
    try {
      bounded(input);
      if (input?.cancel !== void 0) {
        if (!Number.isSafeInteger(input.cancel)) throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
        calls.get(input.cancel)?.controller.abort(new Error("APPLICATION_WORKER_CANCELLED"));
        void cancelStream(input.cancel);
        for (const [id, captured] of views) {
          if (captured.requestId === input.cancel) {
            views.delete(id);
            captured.handle.release();
            captured.release();
          }
        }
        return;
      }
      if (!input || !Number.isSafeInteger(input.id) || input.id <= lastId || typeof input.method !== "string" || !Array.isArray(input.args)) {
        throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
      }
      lastId = input.id;
      void handle(input).catch((error) => {
        if (!closed) {
          try {
            send({ id: input.id, error: errorValue(error), snapshot: snapshot(session) });
          } catch {
            void stop(error).catch(() => void 0);
          }
        }
      });
    } catch (error) {
      void stop(error).catch(() => void 0);
    }
  };
  const connect = (event) => {
    const input = event.data;
    if (input?.protocol !== protocol || !input.port || typeof input.port.postMessage !== "function") return;
    if (closed || port !== void 0) {
      input.port.postMessage({ ended: errorValue(new Error(closed ? "APPLICATION_SESSION_CLOSED" : "APPLICATION_WORKER_CLIENT_IN_USE")) });
      input.port.close();
      return;
    }
    port = input.port;
    port.addEventListener("message", receive);
    port.addEventListener("messageerror", messageError);
    port.start();
    try {
      send({ ready: {
        ...snapshot(session),
        protocol,
        applicationId: session.applicationId,
        historyId: session.historyId,
        deviceId: session.deviceId,
        storageId: session.storageId,
        description: session.describe(),
        ...options.binding === void 0 ? {} : { endpoint: options.binding },
        signalDelivery: session.signals.delivery ?? "neighbors"
      } });
    } catch (error) {
      void stop(error).catch(() => void 0);
    }
  };
  if (options.initialPort === void 0) {
    endpoint.addEventListener("message", connect);
    endpoint.start?.();
  } else connect({ data: { protocol, port: options.initialPort } });
  session.signal.addEventListener("abort", aborted, { once: true });
  if (session.signal.aborted) aborted();
  return { close: () => stop(new Error("APPLICATION_SESSION_CLOSED")) };
}
function snapshot(session) {
  return { status: session.status, revision: session.revision, participation: session.participation?.status ?? null };
}
function errorValue(error) {
  if (!(error instanceof Error)) return { name: "Error", message: String(error) };
  return {
    name: error.name,
    message: error.message,
    ..."code" in error && typeof error.code === "string" ? { code: error.code } : {},
    ...error instanceof AbandonedOperationError ? { operation: error.operation } : {},
    ...error instanceof RecoveredViewError ? { revision: error.revision, recovery: error.recovery } : {}
  };
}
function observe(subscribe, signal) {
  let pending, hasValue = false, closed = false, wake;
  const unsubscribe = subscribe((value) => {
    pending = value;
    hasValue = true;
    wake?.();
    wake = void 0;
  });
  const close = () => {
    if (closed) return;
    closed = true;
    unsubscribe();
    signal.removeEventListener("abort", close);
    wake?.();
    wake = void 0;
  };
  signal.addEventListener("abort", close, { once: true });
  if (signal.aborted) close();
  return {
    async next() {
      while (!hasValue && !closed) await new Promise((resolve) => {
        wake = resolve;
      });
      signal.throwIfAborted();
      if (closed) return { done: true, value: void 0 };
      const value = pending;
      pending = void 0;
      hasValue = false;
      return { done: false, value };
    },
    async return() {
      close();
      return { done: true, value: void 0 };
    }
  };
}

// packages/peer-session/src/session-owner.ts
var owners = /* @__PURE__ */ new WeakMap();
var CAPABILITIES = [...APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES, "ownerAdmin"];
var LIMITS = { requests: 512, streams: 256, views: 128 };
function createApplicationOwner(session, options = {}) {
  session.signal.throwIfAborted();
  if (owners.has(session)) throw new Error("OWNER_BUSY");
  const ownerInstanceId = crypto.randomUUID(), maxAttachments = limit(options.maxAttachments, 32, 128);
  const bounds = { requests: limit(options.maxRequests, LIMITS.requests, 4096), streams: limit(options.maxStreams, LIMITS.streams, 1024), views: limit(options.maxViews, LIMITS.views, 1024) };
  const used = { requests: 0, streams: 0, views: 0 };
  const attachments = /* @__PURE__ */ new Map();
  const listeners = /* @__PURE__ */ new Set();
  let closing, closed = false;
  const reserve = (kind) => {
    if (closed) throw new Error("OWNER_UNREACHABLE");
    if (used[kind] >= bounds[kind]) throw Object.assign(new Error("OWNER_BUSY"), { code: "OWNER_BUSY" });
    used[kind]++;
    let released = false;
    return () => {
      if (!released) {
        released = true;
        used[kind]--;
      }
    };
  };
  const owner = {
    ownerInstanceId,
    session,
    attach(endpoint, fixed = {}) {
      if (closed) throw new Error("OWNER_UNREACHABLE");
      validatePolicy(fixed);
      const owned = /* @__PURE__ */ new Set();
      let detached = false;
      const receive = (event) => {
        const frame = event.data;
        if (typeof frame?.protocol !== "string" || !frame.protocol.startsWith("chronolog/peer-session/")) return;
        const port = frame.port;
        if (port === void 0 || typeof port.postMessage !== "function" || typeof port.close !== "function") return;
        try {
          if (closed || detached) throw new Error("OWNER_UNREACHABLE");
          if (frame.protocol !== APPLICATION_OWNER_PROTOCOL) throw new Error("CONTRACT_INCOMPATIBLE");
          bounded(frame.handshake);
          const handshake = validateHandshake(frame.handshake);
          const description = session.describe();
          if (handshake.applicationId !== session.applicationId || handshake.definitionId !== description.id || handshake.definitionVersion !== description.version) throw new Error("CONTRACT_INCOMPATIBLE");
          if (attachments.size >= maxAttachments) throw new Error("APPLICATION_OWNER_ATTACHMENT_LIMIT");
          const approved = options.authorize?.(structuredClone(handshake)) ?? {};
          validatePolicy(approved);
          const policy = mergePolicy(fixed, approved);
          if ((policy.capabilities ?? APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES).includes("diagnostics")) {
            const observers = session.participation === void 0 ? 2 : 3;
            if ((policy.maxStreams ?? 8) <= observers || (policy.maxRequests ?? 16) <= observers || bounds.streams <= observers || bounds.requests <= observers) throw new Error("APPLICATION_ATTACHMENT_OBSERVER_LIMIT");
          }
          const claimedContext = checkedContext(policy.context ?? handshake.context ?? {});
          const requestedView = claimedContext.viewId;
          const viewId = requestedView !== void 0 && ![...attachments.values()].some((value) => value.binding.context.viewId === requestedView) ? requestedView : crypto.randomUUID();
          const binding = Object.freeze({
            ownerInstanceId,
            endpointId: crypto.randomUUID(),
            endpointIncarnation: crypto.randomUUID(),
            context: Object.freeze({ ...claimedContext, viewId }),
            ...policy.identity === void 0 ? {} : { identity: Object.freeze(structuredClone(policy.identity)) },
            evidence: "owner-bound",
            contextEvidence: policy.contextEvidence ?? "caller-asserted",
            capabilities: Object.freeze([...policy.capabilities ?? APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES])
          });
          const record = { binding, state: "active", close: async () => void 0 };
          attachments.set(binding.endpointId, record);
          owned.add(binding.endpointId);
          const server = serveApplicationWorker(session, endpoint, {
            ...policy,
            ...options.host === void 0 ? {} : { host: options.host },
            capabilities: binding.capabilities,
            closeSession: false,
            initialPort: port,
            binding,
            reserve,
            maxRequests: limit(policy.maxRequests, 16, 64),
            maxStreams: limit(policy.maxStreams, 8, 16),
            maxViews: limit(policy.maxViews, 8, 32),
            ...options.prepareCommand === void 0 ? {} : { prepareCommand: options.prepareCommand },
            listEndpoints: () => owner.endpoints(),
            shutdown: () => owner.close(),
            onState(state) {
              record.state = state;
            },
            onClose() {
              record.state = "detached";
              attachments.delete(binding.endpointId);
              owned.delete(binding.endpointId);
              if (!closed && attachments.size === 0 && options.lastClient === "shutdown") void owner.close().catch(() => void 0);
            }
          });
          record.close = () => server.close();
        } catch (error) {
          const code = error instanceof Error ? error.message : "APPLICATION_OWNER_HANDSHAKE_INVALID";
          try {
            port.postMessage({ ended: { name: "Error", message: code, code } });
          } finally {
            port.close();
          }
        }
      };
      const detach = () => {
        if (detached) return;
        detached = true;
        endpoint.removeEventListener("message", receive);
        listeners.delete(detach);
        for (const id of owned) void attachments.get(id)?.close().catch(() => void 0);
      };
      endpoint.addEventListener("message", receive);
      endpoint.start?.();
      listeners.add(detach);
      return detach;
    },
    endpoints: () => [...attachments.values()].map(({ binding, state }) => ({ ...structuredClone(binding), state })),
    close() {
      if (closing !== void 0) return closing;
      closed = true;
      session.signal.removeEventListener("abort", abort);
      const pending = [...attachments.values()].map((value) => value.close());
      for (const detach of [...listeners]) detach();
      closing = Promise.allSettled(pending).then(async () => {
        try {
          await session.close();
        } finally {
          owners.delete(session);
        }
      });
      return closing;
    }
  };
  const abort = () => {
    void owner.close().catch(() => void 0);
  };
  session.signal.addEventListener("abort", abort, { once: true });
  owners.set(session, owner);
  if (session.signal.aborted) abort();
  return owner;
}
function limit(value, fallback, maximum) {
  const result = value ?? fallback;
  if (!Number.isSafeInteger(result) || result < 1 || result > maximum) throw new Error("APPLICATION_OWNER_LIMIT_INVALID");
  return result;
}
function checkedContext(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value) || Object.entries(value).some(([key, item]) => !["viewId", "documentPath", "publicationId", "runId"].includes(key) || typeof item !== "string" || item.length === 0 || item.length > (key === "documentPath" ? 1024 : 128) || [...item].some((character) => character.charCodeAt(0) < 32))) throw new Error("APPLICATION_ENDPOINT_CONTEXT_INVALID");
  return structuredClone(value);
}
function validateHandshake(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) throw new Error("APPLICATION_OWNER_HANDSHAKE_INVALID");
  const input = value;
  if (Object.keys(input).some((key) => !["applicationId", "definitionId", "definitionVersion", "context"].includes(key)) || !/^[0-9a-f]{64}$/u.test(input.applicationId) || typeof input.definitionId !== "string" || typeof input.definitionVersion !== "string" || input.definitionId.length > 128 || input.definitionVersion.length > 128) throw new Error("APPLICATION_OWNER_HANDSHAKE_INVALID");
  if (input.context !== void 0) checkedContext(input.context);
  return input;
}
function validatePolicy(policy) {
  if (policy === null || typeof policy !== "object" || Array.isArray(policy) || policy.capabilities !== void 0 && (!Array.isArray(policy.capabilities) || policy.capabilities.some((value) => typeof value !== "string" || !CAPABILITIES.includes(value))) || [policy.commands, policy.queries].some((values) => values !== void 0 && (!Array.isArray(values) || values.length > 128 || values.some((value) => typeof value !== "string" || value.length > 128))) || policy.contextEvidence !== void 0 && !["caller-asserted", "owner-validated"].includes(policy.contextEvidence)) throw new Error("APPLICATION_ATTACHMENT_POLICY_INVALID");
  if (policy.identity !== void 0 && (policy.identity === null || typeof policy.identity !== "object" || Array.isArray(policy.identity) || Object.entries(policy.identity).some(([key, value]) => !["principalId", "agentBindingId", "deviceProfileId"].includes(key) || typeof value !== "string" || value.length === 0 || value.length > 128))) throw new Error("APPLICATION_ATTACHMENT_IDENTITY_INVALID");
  if (policy.context !== void 0) checkedContext(policy.context);
  limit(policy.maxRequests, 16, 64);
  limit(policy.maxStreams, 8, 16);
  limit(policy.maxViews, 8, 32);
}
function mergePolicy(a, b) {
  const intersection = (left, right) => left === void 0 ? right : right === void 0 ? left : left.filter((value) => right.includes(value));
  const capabilities = intersection(a.capabilities, b.capabilities), commands = intersection(a.commands, b.commands), queries = intersection(a.queries, b.queries);
  return {
    ...a,
    ...b,
    ...capabilities === void 0 ? {} : { capabilities },
    ...commands === void 0 ? {} : { commands },
    ...queries === void 0 ? {} : { queries },
    maxRequests: Math.min(a.maxRequests ?? 16, b.maxRequests ?? 16),
    maxStreams: Math.min(a.maxStreams ?? 8, b.maxStreams ?? 8),
    maxViews: Math.min(a.maxViews ?? 8, b.maxViews ?? 8)
  };
}

export {
  serveApplicationWorker,
  createApplicationOwner
};
