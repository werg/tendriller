import {
  boundedText,
  bytesDigest,
  check,
  encodePeerValue,
  hex,
  object,
  peerDigest,
  signPeerValue,
  uint,
  validateHistoryPoint,
  verifyPeerValue
} from "./chunk-Q5HDMKTI.mjs";
import {
  DOMAINS,
  ProtocolError,
  decodeTransactionCore,
  encodeTransactionCore,
  integerMap,
  isPlatformOp,
  protocolInvariant,
  transactionDigest,
  utf8
} from "./chunk-LR76T2KY.mjs";
import {
  bytesToHex,
  concatBytes,
  encodeCanonicalCbor,
  equalBytes,
  hexToBytes
} from "./chunk-DEFS6EFN.mjs";

// packages/crypto/src/epoch.ts
function source(value) {
  return Uint8Array.from(value).buffer;
}
function payloadAad(epoch, associatedData) {
  return encodeCanonicalCbor(integerMap([[0, 1n], [1, epoch], [2, associatedData]]));
}
async function encryptEpochPayload(contentKey, epoch, plaintext, associatedData) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  const key = await globalThis.crypto.subtle.importKey("raw", source(contentKey), "AES-GCM", false, ["encrypt"]);
  const nonce = globalThis.crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source(nonce), additionalData: source(payloadAad(epoch, associatedData)), tagLength: 128 },
    key,
    source(plaintext)
  ));
  return { epoch, nonce, ciphertext };
}
async function decryptEpochPayload(contentKey, payload, associatedData) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  protocolInvariant(payload.nonce.length === 12, "SCHEMA_INVALID", "Epoch payload nonce must contain 12 bytes");
  try {
    const key = await globalThis.crypto.subtle.importKey("raw", source(contentKey), "AES-GCM", false, ["decrypt"]);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source(payload.nonce), additionalData: source(payloadAad(payload.epoch, associatedData)), tagLength: 128 },
      key,
      source(payload.ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "Epoch payload authentication failed");
  }
}

// packages/crypto/src/hpke.ts
var HPKE_SUITE = "DHKEM(X25519,HKDF-SHA256)/HKDF-SHA256/AES-256-GCM";
var KEM_ID = Uint8Array.of(0, 32);
var KDF_ID = Uint8Array.of(0, 1);
var AEAD_ID = Uint8Array.of(0, 2);
var KEM_SUITE_ID = concatBytes(utf8("KEM"), KEM_ID);
var HPKE_SUITE_ID = concatBytes(utf8("HPKE"), KEM_ID, KDF_ID, AEAD_ID);
var HPKE_VERSION = utf8("HPKE-v1");
var HASH_SIZE = 32;
var X25519 = { name: "X25519" };
function source2(value) {
  return Uint8Array.from(value).buffer;
}
function i2osp(value, length) {
  protocolInvariant(Number.isSafeInteger(value) && value >= 0 && value < 2 ** (8 * length), "INTEGER_OUT_OF_RANGE", "Integer does not fit HPKE field");
  const result = new Uint8Array(length);
  let remainder = value;
  for (let index = length - 1; index >= 0; index -= 1) {
    result[index] = remainder & 255;
    remainder = Math.floor(remainder / 256);
  }
  return result;
}
async function hmac(keyBytes, data) {
  const key = await globalThis.crypto.subtle.importKey(
    "raw",
    source2(keyBytes),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return new Uint8Array(await globalThis.crypto.subtle.sign("HMAC", key, source2(data)));
}
async function hkdfExtract(salt, ikm) {
  return hmac(salt.length === 0 ? new Uint8Array(HASH_SIZE) : salt, ikm);
}
async function hkdfExpand(prk, info, length) {
  protocolInvariant(length <= 255 * HASH_SIZE, "INTEGER_OUT_OF_RANGE", "HKDF output is too long");
  let previous = new Uint8Array();
  const blocks = [];
  for (let counter = 1; blocks.reduce((sum, block) => sum + block.length, 0) < length; counter += 1) {
    previous = await hmac(prk, concatBytes(previous, info, Uint8Array.of(counter)));
    blocks.push(previous);
  }
  return concatBytes(...blocks).slice(0, length);
}
async function labeledExtract(suiteId, salt, label, ikm) {
  return hkdfExtract(salt, concatBytes(HPKE_VERSION, suiteId, utf8(label), ikm));
}
async function labeledExpand(suiteId, prk, label, info, length) {
  return hkdfExpand(prk, concatBytes(i2osp(length, 2), HPKE_VERSION, suiteId, utf8(label), info), length);
}
async function generateX25519KeyPair(extractable = true) {
  const pair = await globalThis.crypto.subtle.generateKey(X25519, extractable, ["deriveBits"]);
  return {
    publicKey: pair.publicKey,
    privateKey: pair.privateKey,
    publicKeyBytes: new Uint8Array(await globalThis.crypto.subtle.exportKey("raw", pair.publicKey))
  };
}
async function importX25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "X25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", source2(raw), X25519, true, []);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import X25519 public key");
  }
}
async function dh(privateKey, publicKey) {
  try {
    const bits = await globalThis.crypto.subtle.deriveBits({ name: "X25519", public: publicKey }, privateKey, 256);
    const result = new Uint8Array(bits);
    protocolInvariant(result.some((byte) => byte !== 0), "INVALID_KEY", "X25519 produced the prohibited all-zero shared secret");
    return result;
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    throw new ProtocolError("INVALID_KEY", "X25519 key agreement failed");
  }
}
async function extractAndExpand(dhValue, kemContext) {
  const eaePrk = await labeledExtract(KEM_SUITE_ID, new Uint8Array(), "eae_prk", dhValue);
  return labeledExpand(KEM_SUITE_ID, eaePrk, "shared_secret", kemContext, HASH_SIZE);
}
async function keySchedule(sharedSecret, info) {
  const pskIdHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "psk_id_hash", new Uint8Array());
  const infoHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "info_hash", info);
  const keyScheduleContext = concatBytes(Uint8Array.of(0), pskIdHash, infoHash);
  const secret = await labeledExtract(HPKE_SUITE_ID, sharedSecret, "secret", new Uint8Array());
  return {
    key: await labeledExpand(HPKE_SUITE_ID, secret, "key", keyScheduleContext, 32),
    nonce: await labeledExpand(HPKE_SUITE_ID, secret, "base_nonce", keyScheduleContext, 12),
    exporterSecret: await labeledExpand(HPKE_SUITE_ID, secret, "exp", keyScheduleContext, HASH_SIZE)
  };
}
async function aesGcmSeal(keyBytes, nonce, plaintext, aad) {
  const key = await globalThis.crypto.subtle.importKey("raw", source2(keyBytes), "AES-GCM", false, ["encrypt"]);
  return new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source2(nonce), additionalData: source2(aad), tagLength: 128 },
    key,
    source2(plaintext)
  ));
}
async function aesGcmOpen(keyBytes, nonce, ciphertext, aad) {
  try {
    const key = await globalThis.crypto.subtle.importKey("raw", source2(keyBytes), "AES-GCM", false, ["decrypt"]);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source2(nonce), additionalData: source2(aad), tagLength: 128 },
      key,
      source2(ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "HPKE ciphertext authentication failed");
  }
}
async function senderContext(recipientPublicKeyBytes, info) {
  const recipientPublicKey = await importX25519PublicKey(recipientPublicKeyBytes);
  const ephemeral = await generateX25519KeyPair(false);
  const sharedSecret = await extractAndExpand(
    await dh(ephemeral.privateKey, recipientPublicKey),
    concatBytes(ephemeral.publicKeyBytes, recipientPublicKeyBytes)
  );
  try {
    return { encapsulatedKey: ephemeral.publicKeyBytes, context: await keySchedule(sharedSecret, info) };
  } finally {
    sharedSecret.fill(0);
  }
}
async function recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info) {
  protocolInvariant(recipientPublicKeyBytes.length === 32 && encapsulatedKey.length === 32, "INVALID_KEY", "HPKE X25519 keys must contain 32 bytes");
  const ephemeralPublicKey = await importX25519PublicKey(encapsulatedKey);
  const sharedSecret = await extractAndExpand(
    await dh(recipientPrivateKey, ephemeralPublicKey),
    concatBytes(encapsulatedKey, recipientPublicKeyBytes)
  );
  try {
    return await keySchedule(sharedSecret, info);
  } finally {
    sharedSecret.fill(0);
  }
}
function clearContext(context) {
  context.key.fill(0);
  context.nonce.fill(0);
  context.exporterSecret.fill(0);
}
async function hpkeSealBase(recipientPublicKeyBytes, plaintext, info, aad) {
  const { encapsulatedKey, context } = await senderContext(recipientPublicKeyBytes, info);
  try {
    return { encapsulatedKey, ciphertext: await aesGcmSeal(context.key, context.nonce, plaintext, aad) };
  } finally {
    clearContext(context);
  }
}
async function hpkeOpenBase(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, ciphertext, info, aad) {
  const context = await recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info);
  try {
    return await aesGcmOpen(context.key, context.nonce, ciphertext, aad);
  } finally {
    clearContext(context);
  }
}
async function hpkeSendExportBase(recipientPublicKeyBytes, info, exporterContext, length) {
  const { encapsulatedKey, context } = await senderContext(recipientPublicKeyBytes, info);
  try {
    return { encapsulatedKey, exportedSecret: await labeledExpand(HPKE_SUITE_ID, context.exporterSecret, "sec", exporterContext, length) };
  } finally {
    clearContext(context);
  }
}
async function hpkeReceiveExportBase(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info, exporterContext, length) {
  const context = await recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info);
  try {
    return await labeledExpand(HPKE_SUITE_ID, context.exporterSecret, "sec", exporterContext, length);
  } finally {
    clearContext(context);
  }
}

// packages/peer-generation/src/attempt.ts
function validatePeerRevision(value) {
  object(value, ["applicationId", "historyId", "generation", "point", "controlRevision", "materializationRevision"]);
  hex(value.applicationId);
  boundedText(value.historyId, 128);
  hex(value.generation);
  uint(value.controlRevision);
  validateHistoryPoint(value.point);
  check(typeof value.materializationRevision === "string" && /^[0-9]{1,32}$/u.test(value.materializationRevision), "PEER_REVISION_INVALID");
}
function validateHeader(value) {
  object(value, [
    "applicationId",
    "profile",
    "generation",
    "controlRevision",
    "epoch",
    "author",
    "operationId",
    "definitionDigest",
    "command",
    "commandVersion",
    "basedOn",
    "reapplyOf",
    "coreDigest"
  ]);
  hex(value.applicationId);
  hex(value.generation);
  uint(value.controlRevision);
  uint(value.epoch);
  hex(value.author);
  boundedText(value.operationId);
  hex(value.definitionDigest);
  hex(value.coreDigest);
  boundedText(value.command, 128);
  boundedText(value.commandVersion, 128);
  if (value.basedOn !== null) validatePeerRevision(value.basedOn);
  if (value.reapplyOf !== null) hex(value.reapplyOf);
  check(value.profile === "peer-generation-v1", "PEER_PROFILE_UNSUPPORTED");
}
async function createSignedAttempt(header, core, key, device) {
  validateHeader(header);
  check(header.author === device.publicKey && header.operationId === core.operationId, "PEER_AUTHOR_MISMATCH");
  const plaintext = encodeTransactionCore(core);
  check(header.coreDigest === bytesToHex(await transactionDigest(plaintext)), "PEER_ATTEMPT_CORE_MISMATCH");
  const encrypted = await encryptEpochPayload(key, BigInt(header.epoch), plaintext, encodePeerValue(header));
  const payload = { header: structuredClone(header), nonce: bytesToHex(encrypted.nonce), ciphertext: bytesToHex(encrypted.ciphertext) };
  const signed = await signPeerValue(DOMAINS.peerAttempt, payload, device);
  return { ...signed, id: await peerDigest(["chronolog/peer-generation/attempt/v1", payload]) };
}
async function verifyAttempt(attempt, authority, epochKeys) {
  object(attempt, ["payload", "signature", "id"]);
  hex(attempt.id);
  object(attempt.payload, ["header", "nonce", "ciphertext"]);
  validateHeader(attempt.payload.header);
  hex(attempt.payload.nonce, 12);
  check(typeof attempt.payload.ciphertext === "string" && attempt.payload.ciphertext.length <= 2 * 524288 && attempt.payload.ciphertext.length >= 32 && /^(?:[0-9a-f]{2})+$/u.test(attempt.payload.ciphertext), "PEER_ATTEMPT_BODY_INVALID");
  const { header } = attempt.payload, descriptor = authority.descriptor;
  const generation = authority.generation(header.generation), control = authority.controlAt(generation.payload.controlRevision);
  check(header.applicationId === descriptor.applicationId && header.definitionDigest === authority.definitionDigestAt(control.payload.revision), "PEER_SCOPE_MISMATCH");
  check(header.controlRevision === control.payload.revision && header.epoch === control.payload.epoch, "PEER_ATTEMPT_CONTROL_MISMATCH");
  check(authority.grant(header.author, header.controlRevision)?.writer === true, "PEER_AUTHOR_FORBIDDEN");
  check(attempt.id === await peerDigest(["chronolog/peer-generation/attempt/v1", attempt.payload]), "PEER_ATTEMPT_ID_INVALID");
  await verifyPeerValue(DOMAINS.peerAttempt, { payload: attempt.payload, signature: attempt.signature }, header.author);
  const key = epochKeys.get(header.epoch);
  check(key !== void 0, "PEER_EPOCH_KEY_UNAVAILABLE");
  check(await bytesDigest(key) === control.payload.keyDigest, "PEER_EPOCH_KEY_MISMATCH");
  const encoded = await decryptEpochPayload(key, {
    epoch: BigInt(header.epoch),
    nonce: hexToBytes(attempt.payload.nonce),
    ciphertext: hexToBytes(attempt.payload.ciphertext)
  }, encodePeerValue(header));
  const core = decodeTransactionCore(encoded);
  check(header.coreDigest === bytesToHex(await transactionDigest(encoded)) && core.operationId === header.operationId && bytesToHex(core.authorId) === header.author && bytesToHex(core.groupId) === descriptor.applicationId && bytesToHex(core.executionManifestDigest) === descriptor.executionManifestDigest && bytesToHex(core.membershipRevision) === await peerDigest(control) && bytesToHex(core.validationPolicy) === await peerDigest([descriptor.profile, descriptor.policy]) && equalBytes(encodeTransactionCore(core), encoded), "PEER_ATTEMPT_CORE_MISMATCH");
  check(!core.program.steps.some(isPlatformOp), "PEER_PROTECTED_CHANGE_REQUIRED");
  return core;
}

export {
  decryptEpochPayload,
  HPKE_SUITE,
  generateX25519KeyPair,
  hpkeSealBase,
  hpkeOpenBase,
  hpkeSendExportBase,
  hpkeReceiveExportBase,
  validatePeerRevision,
  createSignedAttempt,
  verifyAttempt
};
