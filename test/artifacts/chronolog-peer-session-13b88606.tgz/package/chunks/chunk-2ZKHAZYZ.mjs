// packages/peer-session/src/owner-lock.ts
function acquireApplicationOwnerLock(profileId, options = {}) {
  if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/u.test(profileId)) return Promise.reject(new Error("APPLICATION_OWNER_PROFILE_INVALID"));
  if (options.signal?.aborted) return Promise.reject(options.signal.reason);
  const locks = options.locks ?? (typeof navigator === "undefined" ? void 0 : navigator.locks);
  if (locks === void 0 || typeof locks.request !== "function") return Promise.reject(new Error("APPLICATION_OWNER_LOCK_UNAVAILABLE"));
  return new Promise((resolve, reject) => {
    let settled = false;
    const abort = () => {
      if (!settled) {
        settled = true;
        reject(options.signal?.reason);
      }
    };
    options.signal?.addEventListener("abort", abort, { once: true });
    const clean = () => options.signal?.removeEventListener("abort", abort);
    let completed;
    try {
      completed = locks.request("chronolog-owner:" + profileId, { mode: "exclusive", ...options.wait === true ? options.signal === void 0 ? {} : { signal: options.signal } : { ifAvailable: true } }, async (lock) => {
        if (settled) return;
        settled = true;
        clean();
        if (lock === null) {
          reject(Object.assign(new Error("OWNER_BUSY"), { code: "OWNER_BUSY" }));
          return;
        }
        const lifetime = new AbortController();
        let release, closing;
        const held = new Promise((done) => {
          release = done;
        });
        resolve(Object.freeze({ profileId, signal: lifetime.signal, close() {
          if (closing !== void 0) return closing;
          lifetime.abort(new Error("OWNER_UNREACHABLE"));
          release();
          closing = completed.then(() => void 0);
          return closing;
        } }));
        await held;
      });
      void completed.catch((error) => {
        if (!settled) {
          settled = true;
          clean();
          reject(error);
        }
      });
    } catch (error) {
      settled = true;
      clean();
      reject(error);
    }
  });
}

// packages/peer-session/src/owner-types.ts
var APPLICATION_OWNER_PROTOCOL = "chronolog/peer-session/owner/v2";
var APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES = Object.freeze([
  "commands",
  "queries",
  "events",
  "content",
  "signals",
  "operations",
  "diagnostics"
]);

// packages/peer-session/src/worker-application-protocol.ts
var PROTOCOL = "chronolog/peer-session/worker-application/v1";
var MAX_REQUESTS = 64;
var MAX_RELEASES = 16;
var MAX_STREAMS = 16;
var MAX_BYTES = 1048576;
var releasesResource = (method) => method === "projection.close" || method === "view.release";
function bounded(value) {
  const seen = /* @__PURE__ */ new Set();
  let bytes = 0, nodes = 0;
  const visit = (item, depth) => {
    if (++nodes > 65536 || depth > 32 || bytes > MAX_BYTES) throw new Error("APPLICATION_WORKER_MESSAGE_LIMIT");
    if (typeof item === "string") bytes += new TextEncoder().encode(item).length;
    else if (typeof item === "bigint") bytes += item.toString().length;
    else if (item === null || item === void 0 || typeof item === "number" || typeof item === "boolean") bytes += 8;
    else if (item instanceof Uint8Array) bytes += item.byteLength;
    else if (typeof item === "object") {
      if (seen.has(item)) throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
      seen.add(item);
      for (const [key, child] of Object.entries(item)) {
        bytes += new TextEncoder().encode(key).length;
        visit(child, depth + 1);
      }
      seen.delete(item);
    } else throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
    if (bytes > MAX_BYTES) throw new Error("APPLICATION_WORKER_MESSAGE_LIMIT");
  };
  visit(value, 0);
}

export {
  APPLICATION_OWNER_PROTOCOL,
  APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES,
  PROTOCOL,
  MAX_REQUESTS,
  MAX_RELEASES,
  MAX_STREAMS,
  releasesResource,
  bounded,
  acquireApplicationOwnerLock
};
