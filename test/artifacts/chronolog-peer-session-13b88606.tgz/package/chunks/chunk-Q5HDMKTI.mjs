import {
  DOMAINS,
  canonicalEventPayload,
  canonicalJson,
  decodeChangeProgram,
  exportEd25519PrivateKey,
  generateEd25519KeyPair,
  importEd25519PrivateKey,
  signDomain,
  verifyDomain
} from "./chunk-LR76T2KY.mjs";
import {
  bytesToHex,
  hexToBytes,
  sha256
} from "./chunk-DEFS6EFN.mjs";

// packages/peer-generation/src/codec.ts
var PeerGenerationError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "PeerGenerationError";
  }
  code;
};
function check(condition, code) {
  if (!condition) throw new PeerGenerationError(code);
}
function object(value, keys) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null), "PEER_RECORD_INVALID");
  const record = value;
  check(Object.keys(record).length === keys.length && keys.every((key) => Object.hasOwn(record, key)), "PEER_RECORD_FIELDS_INVALID");
  return record;
}
function boundedText(value, max = 512) {
  check(typeof value === "string" && value.length > 0 && value.length <= max && [...value].every((character) => character.charCodeAt(0) >= 32 && character.charCodeAt(0) !== 127), "PEER_TEXT_INVALID");
}
function hex(value, bytes = 32) {
  check(typeof value === "string" && value.length === bytes * 2 && /^[0-9a-f]+$/u.test(value), "PEER_HEX_INVALID");
}
function uint(value, maximum = Number.MAX_SAFE_INTEGER) {
  check(Number.isSafeInteger(value) && value >= 0 && value <= maximum, "PEER_INTEGER_INVALID");
}
function canonical(value, depth) {
  check(depth <= 24, "PEER_RECORD_TOO_DEEP");
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") {
    check(Number.isSafeInteger(value), "PEER_INTEGER_INVALID");
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map((item) => canonical(item, depth + 1)).join(",")}]`;
  check(typeof value === "object" && value !== null && Object.getPrototypeOf(value) === Object.prototype, "PEER_RECORD_INVALID");
  const record = value;
  return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonical(record[key], depth + 1)}`).join(",")}}`;
}
function encodePeerValue(value) {
  const bytes = new TextEncoder().encode(canonical(value, 0));
  check(bytes.length <= 32 * 1024 * 1024, "PEER_RECORD_TOO_LARGE");
  return bytes;
}
function decodePeerValue(bytes) {
  check(bytes.length <= 32 * 1024 * 1024, "PEER_RECORD_TOO_LARGE");
  const value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  check(bytesToHex(encodePeerValue(value)) === bytesToHex(bytes), "PEER_RECORD_NOT_CANONICAL");
  return value;
}
function samePeerValue(left, right) {
  return canonical(left, 0) === canonical(right, 0);
}
async function peerDigest(value) {
  return bytesToHex(await sha256(encodePeerValue(value)));
}
async function bytesDigest(value) {
  return bytesToHex(await sha256(value));
}
async function signPeerValue(domain, payload, identity) {
  const captured = structuredClone(payload);
  return { payload: captured, signature: bytesToHex(await signDomain(domain, encodePeerValue(captured), identity.privateKey)) };
}
async function verifyPeerValue(domain, value, publicKey) {
  object(value, ["payload", "signature"]);
  hex(value.signature, 64);
  hex(publicKey);
  check(await verifyDomain(domain, encodePeerValue(value.payload), hexToBytes(value.signature), hexToBytes(publicKey)), "PEER_SIGNATURE_INVALID");
}
async function createPeerIdentity() {
  const pair = await generateEd25519KeyPair();
  return { publicKey: bytesToHex(pair.publicKeyBytes), privateKey: pair.privateKey };
}
async function exportPeerIdentity(identity) {
  return { publicKey: identity.publicKey, privateKey: bytesToHex(await exportEd25519PrivateKey(identity.privateKey)) };
}
async function importPeerIdentity(value) {
  object(value, ["publicKey", "privateKey"]);
  hex(value.publicKey);
  check(typeof value.privateKey === "string" && /^[0-9a-f]{96,512}$/u.test(value.privateKey), "PEER_PRIVATE_KEY_INVALID");
  const identity = { publicKey: value.publicKey, privateKey: await importEd25519PrivateKey(hexToBytes(value.privateKey)) };
  const test = new TextEncoder().encode("chronolog/peer-identity/check");
  const signature = await signDomain("chronolog/peer-generation/descriptor/v1", test, identity.privateKey);
  check(await verifyDomain("chronolog/peer-generation/descriptor/v1", test, signature, hexToBytes(identity.publicKey)), "PEER_IDENTITY_KEY_MISMATCH");
  return identity;
}
var Serial = class {
  #tail = Promise.resolve();
  async run(task) {
    const prior = this.#tail;
    let release;
    this.#tail = new Promise((resolve) => {
      release = resolve;
    });
    await prior;
    try {
      return await task();
    } finally {
      release();
    }
  }
};
function isArray(value) {
  return Array.isArray(value);
}

// packages/peer-generation/src/control-types.ts
var PEER_GENERATION_PROFILE = "peer-generation-v1";
var PEER_GENERATION_POLICY = "eligible-members-v1";
var PEER_MAX_RECORDS = 16384;
var PEER_MAX_HISTORY_BYTES = 128 * 1024 * 1024;
var PEER_GENERATION_CAPABILITIES = Object.freeze({
  ordering: "generation-sequence",
  applied: true,
  shared: true,
  finality: false,
  automaticExternalEffects: false,
  recovery: "selected-prefix"
});

// packages/peer-generation/src/definition.ts
function parseApplicationInput(schema, value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  const visit = (spec, item, path2) => {
    const invalid = () => {
      throw new Error(`APPLICATION_INPUT_INVALID:${path2}`);
    };
    if ("anyOf" in spec) {
      for (const option of spec.anyOf) {
        try {
          visit(option, item, path2);
          return;
        } catch {
        }
      }
      invalid();
    } else if (spec.type === "null") {
      if (item !== null) invalid();
    } else if (spec.type === "boolean") {
      if (typeof item !== "boolean") invalid();
    } else if (spec.type === "string") {
      if (typeof item !== "string") return invalid();
      const length = [...item].length;
      if (length < (spec.minLength ?? 0) || length > (spec.maxLength ?? 16384) || spec.enum !== void 0 && !spec.enum.includes(item)) invalid();
    } else if (spec.type === "number" || spec.type === "integer") {
      if (typeof item !== "number" || spec.type === "integer" && !Number.isSafeInteger(item) || item < (spec.minimum ?? -Infinity) || item > (spec.maximum ?? Infinity)) invalid();
    } else if (spec.type === "array") {
      if (!Array.isArray(item) || item.length < (spec.minItems ?? 0) || item.length > (spec.maxItems ?? 4096)) return invalid();
      const items = item;
      items.forEach((child, index) => visit(spec.items, child, `${path2}[${index}]`));
    } else if (spec.type === "object") {
      if (item === null || typeof item !== "object" || Array.isArray(item)) return invalid();
      const object2 = item;
      for (const name of spec.required ?? []) if (!Object.hasOwn(object2, name)) invalid();
      for (const [name, child] of Object.entries(object2)) {
        if (!Object.hasOwn(spec.properties, name)) invalid();
        visit(spec.properties[name], child, `${path2}.${name}`);
      }
    }
  };
  visit(schema, copy, "$");
  return freeze(copy);
}
function checkedApplicationInputSchema(value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  let nodes = 0;
  const visit = (schema, depth) => {
    if (++nodes > 256 || depth > 16 || schema === null || typeof schema !== "object" || Array.isArray(schema)) throw new Error("APPLICATION_SCHEMA_INVALID");
    const keys = /* @__PURE__ */ new Set(["description"]);
    const allow = (...names) => {
      for (const name of names) keys.add(name);
    };
    const bound = (value2, max) => {
      if (value2 !== void 0 && (!Number.isSafeInteger(value2) || value2 < 0 || value2 > max)) throw new Error("APPLICATION_SCHEMA_INVALID");
    };
    if (schema.description !== void 0 && typeof schema.description !== "string") throw new Error("APPLICATION_SCHEMA_INVALID");
    if ("anyOf" in schema) {
      allow("anyOf");
      if (!Array.isArray(schema.anyOf) || schema.anyOf.length < 1 || schema.anyOf.length > 16) throw new Error("APPLICATION_SCHEMA_INVALID");
      const alternatives = schema.anyOf;
      alternatives.forEach((option) => visit(option, depth + 1));
    } else {
      allow("type");
      switch (schema.type) {
        case "string":
          allow("minLength", "maxLength", "enum");
          bound(schema.minLength, 16384);
          bound(schema.maxLength, 16384);
          if ((schema.minLength ?? 0) > (schema.maxLength ?? 16384) || schema.enum !== void 0 && (!Array.isArray(schema.enum) || schema.enum.length === 0 || schema.enum.length > 256 || schema.enum.some((item) => typeof item !== "string"))) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "number":
        case "integer":
          allow("minimum", "maximum");
          if ([schema.minimum, schema.maximum].some((value2) => value2 !== void 0 && !Number.isFinite(value2)) || (schema.minimum ?? -Infinity) > (schema.maximum ?? Infinity)) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "boolean":
        case "null":
          break;
        case "array":
          allow("items", "minItems", "maxItems");
          bound(schema.minItems, 4096);
          bound(schema.maxItems, 4096);
          if ((schema.minItems ?? 0) > (schema.maxItems ?? 4096)) throw new Error("APPLICATION_SCHEMA_INVALID");
          visit(schema.items, depth + 1);
          break;
        case "object":
          allow("properties", "required", "additionalProperties");
          if (schema.properties === null || typeof schema.properties !== "object" || Array.isArray(schema.properties) || schema.additionalProperties !== void 0 && schema.additionalProperties !== false) throw new Error("APPLICATION_SCHEMA_INVALID");
          for (const child of Object.values(schema.properties)) visit(child, depth + 1);
          if (schema.required !== void 0 && (!Array.isArray(schema.required) || schema.required.some((name) => typeof name !== "string" || !Object.hasOwn(schema.properties, name)) || new Set(schema.required).size !== schema.required.length)) {
            throw new Error("APPLICATION_SCHEMA_INVALID");
          }
          Object.assign(schema, { additionalProperties: false });
          break;
        default:
          throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
      }
    }
    if (Object.keys(schema).some((key) => !keys.has(key))) throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
  };
  visit(copy, 0);
  return freeze(copy);
}
function freeze(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
function validateApplicationDescription(value) {
  const bytes = descriptionJson(value);
  check(new TextEncoder().encode(bytes).length <= 262144, "APPLICATION_DESCRIPTION_TOO_LARGE");
  const copy = JSON.parse(bytes);
  object(copy, ["id", "version", "schema", "commands", "queries"]);
  for (const text of [copy.id, copy.version]) check(typeof text === "string" && /^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(text), "APPLICATION_DEFINITION_ID_INVALID");
  if (copy.schema !== null) {
    check(typeof copy.schema === "string" && /^(?:[0-9a-f]{2})+$/u.test(copy.schema), "APPLICATION_SCHEMA_PROGRAM_INVALID");
    decodeChangeProgram(hexToBytes(copy.schema));
  }
  for (const entries of [copy.commands, copy.queries]) {
    check(isArray(entries) && entries.length <= 128, "APPLICATION_DEFINITION_TOO_LARGE");
    let previous = "";
    for (const entry of entries) {
      object(entry, ["name", "description", "input"]);
      check(typeof entry.name === "string" && /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(entry.name) && !["__proto__", "constructor", "prototype"].includes(entry.name) && entry.name > previous, "APPLICATION_DEFINITION_NAME_INVALID");
      previous = entry.name;
      check(typeof entry.description === "string" && entry.description.length <= 4096, "APPLICATION_DESCRIPTION_INVALID");
      const checked = checkedApplicationInputSchema(entry.input);
      check(canonicalEventPayload(entry.input) === canonicalEventPayload(checked), "APPLICATION_SCHEMA_NOT_CANONICAL");
    }
  }
  return freeze(copy);
}
async function applicationDescriptionDigest(value) {
  const description = validateApplicationDescription(value);
  return bytesDigest(new TextEncoder().encode(descriptionJson(description)));
}
function assertCompatibleDefinitionEvolution(previous, next) {
  const prior = validateApplicationDescription(previous), updated = validateApplicationDescription(next);
  check(prior.id === updated.id, "APPLICATION_DEFINITION_ID_MISMATCH");
  check(prior.schema === null === (updated.schema === null), "APPLICATION_DEFINITION_PROFILE_MISMATCH");
  if (prior.schema !== null) check(prior.schema === updated.schema, "APPLICATION_DEFINITION_SCHEMA_CHANGED");
}
function descriptionJson(value) {
  return canonicalJson(value, { maxBytes: 262144, maxNodes: 65536, maxDepth: 32 });
}

// packages/peer-generation/src/schema.ts
function validateSchema(value) {
  object(value, ["applicationId", "definitionDigest", "executionManifestDigest", "program"]);
  hex(value.applicationId);
  hex(value.definitionDigest);
  hex(value.executionManifestDigest);
  check(typeof value.program === "string" && value.program.length <= 2 * 262144 && /^(?:[0-9a-f]{2})+$/u.test(value.program), "PEER_SCHEMA_PROGRAM_INVALID");
  decodeChangeProgram(hexToBytes(value.program));
}
async function signApplicationSchema(payload, signer) {
  validateSchema(payload);
  return signPeerValue(DOMAINS.peerSchema, payload, signer);
}
async function verifyApplicationSchema(schema, descriptor) {
  validateSchema(schema.payload);
  check(schema.payload.applicationId === descriptor.applicationId && schema.payload.definitionDigest === descriptor.definitionDigest && schema.payload.executionManifestDigest === descriptor.executionManifestDigest && descriptor.schemaDigest === await peerDigest(schema), "PEER_SCHEMA_BINDING_MISMATCH");
  await verifyPeerValue(DOMAINS.peerSchema, schema, descriptor.schemaAdministrator);
  return decodeChangeProgram(hexToBytes(schema.payload.program));
}

// packages/peer-generation/src/participant.ts
var PARTICIPANT_PROTOCOL = "chronolog-participant-v1";
var PARTICIPANT_LIMITS = Object.freeze({
  pending: 4,
  depth: 32,
  bytes: Object.freeze({
    control: 16 * 1024 * 1024,
    publication: 12 * 1024 * 1024,
    discovery: 256 * 1024,
    ephemeral: 64 * 1024,
    database: 32 * 1024 * 1024,
    content: 512 * 1024
  })
});
function policy(role, actions) {
  return Object.freeze({ role, interests: Object.freeze(Object.entries(actions).flatMap(([facet, names]) => names.map((action) => Object.freeze({ facet, action })))) });
}
var CONTROL_PARTICIPANT_POLICY = policy("control", {
  control: ["read", "configure", "select", "administer"],
  publication: ["definition", "read", "publish"],
  discovery: ["read", "advertise", "withdraw"],
  ephemeral: ["invite"]
});
var PEER_PARTICIPANT_POLICY = policy("peer", {
  control: ["state", "keyShare"],
  publication: ["definition", "read"],
  database: ["open", "submit", "range", "coverage"],
  content: ["manifest", "chunk", "retained", "observeRetention"],
  ephemeral: ["signal", "hint"]
});
var ParticipantProtocolError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "ParticipantProtocolError";
  }
  code;
};
function requireParticipant(condition, code) {
  if (!condition) throw new ParticipantProtocolError(code);
}
function applicationId(value) {
  requireParticipant(typeof value === "string" && /^[0-9a-f]{64}$/u.test(value), "PEER_PARTICIPANT_SCOPE_INVALID");
}
function jsonValue(value, depth = 0) {
  requireParticipant(depth <= PARTICIPANT_LIMITS.depth, "PEER_PARTICIPANT_DEPTH_LIMIT");
  if (value === null || typeof value === "string" || typeof value === "boolean") return;
  if (typeof value === "number") {
    requireParticipant(Number.isFinite(value), "PEER_PARTICIPANT_PAYLOAD_INVALID");
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) jsonValue(item, depth + 1);
    return;
  }
  requireParticipant(
    value !== null && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype,
    "PEER_PARTICIPANT_PAYLOAD_INVALID"
  );
  for (const item of Object.values(value)) jsonValue(item, depth + 1);
}
function participantAccepts(policy2, interest) {
  return policy2.interests.some((value) => value.facet === interest.facet && value.action === interest.action);
}
function validateParticipantRequest(value, selected = CONTROL_PARTICIPANT_POLICY) {
  requireParticipant(
    value !== null && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype,
    "PEER_PARTICIPANT_ENVELOPE_INVALID"
  );
  const request = value;
  const fields = ["protocol", "applicationId", "requestId", "facet", "action", "payload"];
  requireParticipant(
    Object.keys(request).length === fields.length && fields.every((key) => Object.hasOwn(request, key)),
    "PEER_PARTICIPANT_ENVELOPE_INVALID"
  );
  requireParticipant(request.protocol === PARTICIPANT_PROTOCOL, "PEER_PARTICIPANT_PROTOCOL_UNSUPPORTED");
  applicationId(request.applicationId);
  requireParticipant(
    typeof request.requestId === "string" && /^[A-Za-z0-9_.:-]{1,128}$/u.test(request.requestId),
    "PEER_PARTICIPANT_REQUEST_INVALID"
  );
  requireParticipant(typeof request.facet === "string" && Object.hasOwn(PARTICIPANT_LIMITS.bytes, request.facet) && typeof request.action === "string" && /^[a-z][A-Za-z-]{0,47}$/u.test(request.action), "PEER_PARTICIPANT_INTEREST_INVALID");
  requireParticipant(participantAccepts(selected, request), "PEER_PARTICIPANT_FACET_FORBIDDEN");
  jsonValue(request.payload);
  requireParticipant(
    new TextEncoder().encode(JSON.stringify(request)).length <= PARTICIPANT_LIMITS.bytes[request.facet],
    "PEER_PARTICIPANT_SIZE_LIMIT"
  );
  return structuredClone(request);
}
function createParticipantRequest(input, selected = CONTROL_PARTICIPANT_POLICY) {
  return validateParticipantRequest({
    protocol: PARTICIPANT_PROTOCOL,
    applicationId: input.applicationId,
    requestId: input.requestId ?? crypto.randomUUID(),
    facet: input.facet,
    action: input.action,
    payload: input.payload
  }, selected);
}
function createParticipantResponse(request, payload, selected = CONTROL_PARTICIPANT_POLICY) {
  return validateParticipantRequest({ ...validateParticipantRequest(request, selected), payload }, selected);
}
function validateParticipantResponse(value, request, selected = CONTROL_PARTICIPANT_POLICY) {
  const response = validateParticipantRequest(value, selected);
  requireParticipant(response.applicationId === request.applicationId && response.requestId === request.requestId && response.facet === request.facet && response.action === request.action, "PEER_PARTICIPANT_RESPONSE_MISMATCH");
  return response;
}
function createParticipantTransport(options) {
  applicationId(options.applicationId);
  const scope2 = options.applicationId, dispatch = options.exchange;
  const selected = structuredClone(options.policy ?? CONTROL_PARTICIPANT_POLICY);
  let pending = 0;
  const exchange = async (input, inputOptions = {}) => {
    const request = validateParticipantRequest(input, selected);
    requireParticipant(request.applicationId === scope2, "PEER_PARTICIPANT_SCOPE_MISMATCH");
    inputOptions.signal?.throwIfAborted();
    requireParticipant(pending < PARTICIPANT_LIMITS.pending, "PEER_PARTICIPANT_BUSY");
    pending++;
    try {
      const response = await dispatch(request, inputOptions);
      inputOptions.signal?.throwIfAborted();
      return validateParticipantResponse(response, request, selected);
    } finally {
      pending--;
    }
  };
  return Object.freeze({
    applicationId: scope2,
    policy: policy(
      selected.role,
      Object.fromEntries([...new Set(selected.interests.map((value) => value.facet))].map((facet) => [facet, selected.interests.filter((value) => value.facet === facet).map((value) => value.action)]))
    ),
    exchange,
    async request(facet, action, payload, inputOptions = {}) {
      return (await exchange(createParticipantRequest({ applicationId: scope2, facet, action, payload }, selected), inputOptions)).payload;
    }
  });
}

// packages/peer-generation/src/control.ts
function assertAuthorityExtension(previous, next) {
  const old = previous.bundle, current = next.bundle;
  check(samePeerValue(old.descriptor, current.descriptor), "PEER_DESCRIPTOR_MISMATCH");
  check(current.generations.length >= old.generations.length && current.controls.length >= old.controls.length, "PEER_AUTHORITY_REGRESSION");
  for (let index = 0; index < old.generations.length; index++) check(samePeerValue(old.generations[index], current.generations[index]), "PEER_CONTROL_EQUIVOCATION");
  for (let index = 0; index < old.controls.length; index++) check(samePeerValue(old.controls[index], current.controls[index]), "PEER_CONTROL_EQUIVOCATION");
}
function scope(value, descriptor) {
  check(value.applicationId === descriptor.applicationId && value.profile === PEER_GENERATION_PROFILE && (value.policy === void 0 || value.policy === descriptor.policy), "PEER_SCOPE_MISMATCH");
}
function validateDescriptor(value) {
  object(value, ["applicationId", "historyId", "profile", "policy", "controlPublicKey", "schemaAdministrator", "executionManifestDigest", "definitionDigest", "schemaDigest"]);
  hex(value.applicationId);
  boundedText(value.historyId, 128);
  hex(value.controlPublicKey);
  hex(value.schemaAdministrator);
  hex(value.executionManifestDigest);
  hex(value.definitionDigest);
  if (value.schemaDigest !== null) hex(value.schemaDigest);
  check(value.profile === PEER_GENERATION_PROFILE && value.policy === PEER_GENERATION_POLICY, "PEER_PROFILE_UNSUPPORTED");
}
function validateHistoryPoint(point) {
  object(point, ["generation", "sequence", "root"]);
  hex(point.generation);
  uint(point.sequence);
  hex(point.root);
}
function validateControl(value) {
  const controlFields = ["applicationId", "profile", "policy", "revision", "previous", "epoch", "keyDigest", "grants", "recoveryFloor"];
  if (value?.definitionDigest !== void 0) controlFields.push("definitionDigest");
  object(value, controlFields);
  hex(value.applicationId);
  uint(value.revision);
  uint(value.epoch);
  hex(value.keyDigest);
  if (value.previous !== null) hex(value.previous);
  if (value.definitionDigest !== void 0) hex(value.definitionDigest);
  check(isArray(value.grants) && value.grants.length > 0 && value.grants.length <= 1024, "PEER_GRANTS_INVALID");
  const keys = /* @__PURE__ */ new Set();
  for (const grant of value.grants) {
    const fields = ["publicKey", "reader", "writer", "coordinator", "recovery", "administrator", "publisher", "dataRole"];
    if (grant?.relay !== void 0) {
      fields.push("relay");
      check(grant.relay === true && grant.reader, "PEER_GRANT_INVALID");
    }
    object(grant, fields);
    hex(grant.publicKey);
    for (const key of ["reader", "writer", "coordinator", "recovery", "administrator", "publisher"]) check(typeof grant[key] === "boolean", "PEER_GRANT_INVALID");
    check(!keys.has(grant.publicKey), "PEER_DUPLICATE_GRANT");
    keys.add(grant.publicKey);
    check(!grant.coordinator || grant.reader, "PEER_COORDINATOR_MUST_READ");
    check(grant.dataRole === null || grant.dataRole === "member" || grant.dataRole === "admin", "PEER_DATA_ROLE_INVALID");
  }
  check(value.grants.some((grant) => grant.administrator), "PEER_ADMINISTRATOR_REQUIRED");
  if (value.recoveryFloor !== null) validateHistoryPoint(value.recoveryFloor);
}
function validateRequest(value) {
  object(value, ["applicationId", "profile", "policy", "transitionId", "expectedGeneration", "coordinator", "requester", "controlRevision", "reason", "base"]);
  hex(value.applicationId);
  boundedText(value.transitionId, 128);
  hex(value.coordinator);
  hex(value.requester);
  uint(value.controlRevision);
  if (value.expectedGeneration !== null) hex(value.expectedGeneration);
  check(["create", "handover", "takeover", "control-change"].includes(value.reason), "PEER_TRANSITION_REASON_INVALID");
  if (value.base !== null) {
    object(value.base, ["point", "receipt", "bridge"]);
    validateHistoryPoint(value.base.point);
    check(isArray(value.base.bridge) && value.base.bridge.length <= 4096, "PEER_PREFIX_PROOF_TOO_LARGE");
  }
}
function validateGeneration(value) {
  object(value, ["applicationId", "profile", "policy", "number", "previous", "coordinator", "controlRevision", "controlDigest", "adopted", "recoveryFloor", "executionManifestDigest", "transition"]);
  hex(value.applicationId);
  uint(value.number);
  hex(value.coordinator);
  uint(value.controlRevision);
  hex(value.controlDigest);
  hex(value.executionManifestDigest);
  if (value.previous !== null) hex(value.previous);
  if (value.adopted !== null) validateHistoryPoint(value.adopted);
  if (value.recoveryFloor !== null) validateHistoryPoint(value.recoveryFloor);
}
async function signApplicationDescriptor(payload, signer) {
  validateDescriptor(payload);
  check(payload.controlPublicKey === signer.publicKey, "PEER_CONTROL_KEY_MISMATCH");
  return signPeerValue(DOMAINS.peerDescriptor, payload, signer);
}
function participantGrant(publicKey, options = {}) {
  hex(publicKey);
  return {
    publicKey,
    reader: true,
    writer: true,
    coordinator: true,
    recovery: true,
    administrator: options.administrator ?? false,
    publisher: options.publisher ?? false,
    ...options.relay === true ? { relay: true } : {},
    dataRole: options.dataRole === void 0 ? "member" : options.dataRole
  };
}
function controlParticipantGrant(publicKey) {
  hex(publicKey);
  return { publicKey, reader: false, writer: false, coordinator: false, recovery: true, administrator: true, publisher: false, dataRole: null };
}
async function signControlRevision(payload, signer) {
  validateControl(payload);
  return signPeerValue(DOMAINS.peerControl, payload, signer);
}
async function signTransitionRequest(payload, signer) {
  validateRequest(payload);
  check(payload.requester === signer.publicKey, "PEER_REQUESTER_KEY_MISMATCH");
  return signPeerValue(DOMAINS.peerTransition, payload, signer);
}
async function generationStartRoot(generation) {
  return peerDigest(["chronolog/peer-generation/start/v1", generation.id, generation.payload.adopted]);
}
async function verifyOrderReceipt(receipt, generation, descriptor) {
  object(receipt, ["payload", "signature", "root"]);
  hex(receipt.root);
  const value = receipt.payload;
  object(value, ["applicationId", "profile", "generation", "sequence", "previousRoot", "attemptId", "author", "operationId", "bodyHash", "bodyBytes"]);
  scope(value, descriptor);
  hex(value.generation);
  uint(value.sequence);
  check(value.sequence > 0, "PEER_ORDER_POSITION_INVALID");
  hex(value.previousRoot);
  hex(value.attemptId);
  hex(value.author);
  boundedText(value.operationId);
  hex(value.bodyHash);
  uint(value.bodyBytes, 2 * 1024 * 1024);
  check(value.bodyBytes > 0 && value.generation === generation.id, "PEER_ORDER_GENERATION_MISMATCH");
  check(receipt.root === await peerDigest(["chronolog/peer-generation/order/v1", value]), "PEER_ORDER_ROOT_MISMATCH");
  await verifyPeerValue(DOMAINS.peerOrder, { payload: value, signature: receipt.signature }, generation.payload.coordinator);
}
var PeerAuthority = class _PeerAuthority {
  #bundle;
  #byId = /* @__PURE__ */ new Map();
  #transitions = /* @__PURE__ */ new Map();
  #depth = /* @__PURE__ */ new Map();
  #ancestors = /* @__PURE__ */ new Map();
  // Construction uses cloned wire data or an already verified private prefix.
  constructor(bundle) {
    this.#bundle = { ...bundle, controls: [...bundle.controls], generations: [...bundle.generations] };
  }
  get signedDescriptor() {
    return structuredClone(this.#bundle.descriptor);
  }
  get generationCount() {
    return this.#bundle.generations.length;
  }
  get controlCount() {
    return this.#bundle.controls.length;
  }
  generationAt(index) {
    return structuredClone(this.#bundle.generations[index] ?? null);
  }
  suffix(controls, generations) {
    uint(controls, this.controlCount);
    uint(generations, this.generationCount);
    return { controls: structuredClone(this.#bundle.controls.slice(controls)), generations: structuredClone(this.#bundle.generations.slice(generations)) };
  }
  transition(id) {
    return structuredClone(this.#transitions.get(id) ?? null);
  }
  get bundle() {
    return structuredClone(this.#bundle);
  }
  get descriptor() {
    return structuredClone(this.#bundle.descriptor.payload);
  }
  get current() {
    return structuredClone(this.#bundle.generations.at(-1) ?? null);
  }
  get control() {
    return structuredClone(this.#bundle.controls.at(-1));
  }
  generation(id) {
    const value = this.#byId.get(id);
    check(value !== void 0, "PEER_GENERATION_UNKNOWN");
    return structuredClone(value);
  }
  controlAt(revision) {
    const value = this.#bundle.controls[revision];
    check(value !== void 0, "PEER_CONTROL_UNKNOWN");
    return structuredClone(value);
  }
  definitionDigestAt(revision = this.control.payload.revision) {
    uint(revision, this.#bundle.controls.length - 1);
    for (let index = revision; index >= 0; index--) {
      const digest = this.#bundle.controls[index].payload.definitionDigest;
      if (digest !== void 0) return digest;
    }
    return this.#bundle.descriptor.payload.definitionDigest;
  }
  get currentDefinitionDigest() {
    return this.definitionDigestAt();
  }
  grant(publicKey, revision = this.control.payload.revision) {
    return structuredClone(this.controlAt(revision).payload.grants.find((grant) => grant.publicKey === publicKey) ?? null);
  }
  #append(generation) {
    const parent = generation.payload.adopted?.generation;
    const ancestors = parent === void 0 ? [] : [parent];
    for (let level = 1; ancestors[level - 1] !== void 0; level++) {
      const ancestor = this.#ancestors.get(ancestors[level - 1])?.[level - 1];
      if (ancestor === void 0) break;
      ancestors.push(ancestor);
    }
    this.#transitions.set(generation.payload.transition.payload.transitionId, generation);
    this.#byId.set(generation.id, generation);
    this.#depth.set(generation.id, parent === void 0 ? 0 : this.#depth.get(parent) + 1);
    this.#ancestors.set(generation.id, ancestors);
    this.#bundle.generations.push(generation);
  }
  #lift(id, distance) {
    let current = id;
    for (let level = 0; distance > 0 && current !== void 0; level++, distance = Math.floor(distance / 2)) {
      if (distance % 2 === 1) current = this.#ancestors.get(current)?.[level];
    }
    return current;
  }
  #segment(id) {
    const current = this.#bundle.generations.at(-1), generation = this.#byId.get(id);
    if (current === void 0 || generation === void 0) return void 0;
    if (id === current.id) return { generation, cutoff: null };
    const distance = this.#depth.get(current.id) - this.#depth.get(id);
    if (distance < 1) return void 0;
    const child = this.#lift(current.id, distance - 1);
    const cutoff = child === void 0 ? void 0 : this.#byId.get(child).payload.adopted;
    return cutoff?.generation === id ? { generation, cutoff } : void 0;
  }
  selectedSegments() {
    const current = this.#bundle.generations.at(-1);
    if (current === void 0) return [];
    const reversed = [{ generation: current, cutoff: null }];
    let adopted = current.payload.adopted;
    while (adopted !== null) {
      const generation = this.#byId.get(adopted.generation);
      reversed.push({ generation, cutoff: adopted });
      adopted = generation.payload.adopted;
    }
    return structuredClone(reversed.reverse());
  }
  /** Structural inclusion; a complete replica additionally checks the local retained root. */
  contains(point) {
    validateHistoryPoint(point);
    const segment = this.#segment(point.generation);
    return segment !== void 0 && (segment.cutoff === null || point.sequence <= segment.cutoff.sequence && (point.sequence !== segment.cutoff.sequence || point.root === segment.cutoff.root));
  }
  async verifyPrefix(proof) {
    object(proof, ["point", "receipt", "bridge"]);
    validateHistoryPoint(proof.point);
    check(isArray(proof.bridge) && proof.bridge.length <= 4096, "PEER_PREFIX_PROOF_TOO_LARGE");
    const segment = this.#segment(proof.point.generation);
    check(segment !== void 0 && this.contains(proof.point), "PEER_PREFIX_EXCLUDED");
    const { point } = proof;
    if (point.sequence === 0) {
      check(proof.receipt === null && point.root === await generationStartRoot(segment.generation), "PEER_PREFIX_ROOT_MISMATCH");
    } else {
      check(proof.receipt !== null, "PEER_PREFIX_RECEIPT_REQUIRED");
      await verifyOrderReceipt(proof.receipt, segment.generation, this.descriptor);
      check(proof.receipt.payload.sequence === point.sequence && proof.receipt.root === point.root, "PEER_PREFIX_ROOT_MISMATCH");
    }
    let position = point.sequence, root = point.root;
    for (const receipt of proof.bridge) {
      await verifyOrderReceipt(receipt, segment.generation, this.descriptor);
      check(receipt.payload.sequence === position + 1 && receipt.payload.previousRoot === root, "PEER_PREFIX_BRIDGE_INVALID");
      position++;
      root = receipt.root;
    }
    if (segment.cutoff === null) check(proof.bridge.length === 0, "PEER_PREFIX_BRIDGE_UNNECESSARY");
    else check(position === segment.cutoff.sequence && root === segment.cutoff.root, "PEER_PREFIX_BRIDGE_INCOMPLETE");
  }
  /** Compare points on the selected history after their roots have been authenticated. */
  atOrAfter(point, floor) {
    const left = this.#segment(point.generation), right = this.#segment(floor.generation);
    return left !== void 0 && right !== void 0 && (left.generation.payload.number > right.generation.payload.number || point.generation === floor.generation && point.sequence >= floor.sequence);
  }
  async authorizeTransition(request, nextControl = this.control) {
    validateRequest(request.payload);
    scope(request.payload, this.descriptor);
    await verifyPeerValue(DOMAINS.peerTransition, request, request.payload.requester);
    const value = request.payload, current = this.current, currentControl = this.control;
    check(value.expectedGeneration === (current?.id ?? null), "PEER_GENERATION_CONFLICT");
    check(value.controlRevision === nextControl.payload.revision, "PEER_CONTROL_REVISION_MISMATCH");
    const requester = this.grant(value.requester, currentControl.payload.revision);
    const candidate = nextControl.payload.grants.find((grant) => grant.publicKey === value.coordinator);
    check(requester?.recovery === true, "PEER_RECOVERY_FORBIDDEN");
    check(candidate?.coordinator === true && candidate.reader, "PEER_COORDINATOR_FORBIDDEN");
    if (current === null) {
      check(value.reason === "create" && value.base === null && nextControl.payload.revision === 0, "PEER_INITIAL_SELECTION_INVALID");
    } else {
      check(value.reason !== "create" && value.base !== null, "PEER_RECOVERY_BASE_REQUIRED");
      await this.verifyPrefix(value.base);
      if (value.reason === "handover") check(value.requester === current.payload.coordinator, "PEER_HANDOVER_FORBIDDEN");
      if (nextControl.payload.revision !== currentControl.payload.revision) {
        check(value.reason === "control-change" && requester.administrator, "PEER_CONTROL_CHANGE_FORBIDDEN");
        await verifyNextControl(this.descriptor, currentControl, nextControl);
      } else check(value.reason !== "control-change", "PEER_CONTROL_CHANGE_REQUIRED");
      const previousFloor = currentControl.payload.recoveryFloor;
      const floor = nextControl.payload.recoveryFloor;
      if (previousFloor !== null) {
        check(floor !== null && this.contains(floor) && this.atOrAfter(floor, previousFloor), "PEER_RECOVERY_FLOOR_REGRESSION");
      }
      if (floor !== null) check(this.contains(floor) && this.atOrAfter(value.base.point, floor), "PEER_RECOVERY_FLOOR_UNAVAILABLE");
      if (floor !== null && !samePeerValue(floor, previousFloor)) check(samePeerValue(floor, value.base.point), "PEER_NEW_FLOOR_MUST_MATCH_BASE");
    }
  }
  /** Verify only new signed suffix records, preserving the verified prefix by reference. */
  async extend(inputControls, inputGenerations) {
    if (inputControls.length === 0 && inputGenerations.length === 0) return this;
    const controls = structuredClone(inputControls), generations = structuredClone(inputGenerations);
    check(this.controlCount + controls.length <= 4096 && this.generationCount + generations.length <= 4096, "PEER_AUTHORITY_LIMIT");
    const next = new _PeerAuthority(this.#bundle);
    for (const [id, value] of this.#byId) next.#byId.set(id, value);
    for (const [id, value] of this.#depth) next.#depth.set(id, value);
    for (const [id, value] of this.#ancestors) next.#ancestors.set(id, value);
    for (const [id, value] of this.#transitions) next.#transitions.set(id, value);
    const allControls = [...this.#bundle.controls, ...controls], descriptor = this.descriptor;
    for (let index = this.controlCount; index < allControls.length; index++) await verifyNextControl(descriptor, allControls[index - 1], allControls[index]);
    for (const generation of generations) {
      object(generation, ["payload", "signature", "id"]);
      hex(generation.id);
      validateGeneration(generation.payload);
      const value = generation.payload;
      scope(value, descriptor);
      await verifyPeerValue(DOMAINS.peerGeneration, { payload: value, signature: generation.signature }, descriptor.controlPublicKey);
      check(generation.id === await peerDigest(["chronolog/peer-generation/generation/v1", value]), "PEER_GENERATION_ID_INVALID");
      check(value.number === next.generationCount && value.previous === (next.current?.id ?? null), "PEER_GENERATION_CHAIN_INVALID");
      const control = allControls[value.controlRevision];
      check(control !== void 0 && value.controlDigest === await peerDigest(control), "PEER_CONTROL_DIGEST_MISMATCH");
      check(value.controlRevision === next.controlCount - 1 || value.controlRevision === next.controlCount, "PEER_CONTROL_CHAIN_INVALID");
      await next.authorizeTransition(value.transition, control);
      check(value.coordinator === value.transition.payload.coordinator && samePeerValue(value.adopted, value.transition.payload.base?.point ?? null) && samePeerValue(value.recoveryFloor, control.payload.recoveryFloor) && value.executionManifestDigest === descriptor.executionManifestDigest, "PEER_DELEGATION_MISMATCH");
      check(!next.#transitions.has(value.transition.payload.transitionId), "PEER_TRANSITION_DUPLICATE");
      if (value.controlRevision === next.controlCount) next.#bundle.controls.push(control);
      next.#append(generation);
    }
    check(next.controlCount === allControls.length, "PEER_CONTROL_NOT_ACTIVATED");
    return next;
  }
  static async verify(input, pinned) {
    const bundle = structuredClone(input);
    object(bundle, ["descriptor", "controls", "generations"]);
    validateDescriptor(bundle.descriptor.payload);
    await verifyPeerValue(DOMAINS.peerDescriptor, bundle.descriptor, bundle.descriptor.payload.controlPublicKey);
    if (pinned !== void 0) check(samePeerValue(bundle.descriptor, pinned), "PEER_DESCRIPTOR_CHANGED");
    check(isArray(bundle.controls) && bundle.controls.length > 0 && bundle.controls.length <= 4096 && isArray(bundle.generations) && bundle.generations.length <= 4096, "PEER_AUTHORITY_LIMIT");
    const descriptor = bundle.descriptor.payload;
    for (const [index, control] of bundle.controls.entries()) {
      validateControl(control.payload);
      scope(control.payload, descriptor);
      await verifyPeerValue(DOMAINS.peerControl, control, descriptor.controlPublicKey);
      check(control.payload.revision === index, "PEER_CONTROL_CHAIN_INVALID");
      if (index === 0) check(control.payload.previous === null && control.payload.recoveryFloor === null, "PEER_INITIAL_CONTROL_INVALID");
      else await verifyNextControl(descriptor, bundle.controls[index - 1], control);
    }
    const verified = new _PeerAuthority({ descriptor: bundle.descriptor, controls: [bundle.controls[0]], generations: [] });
    const transitions = /* @__PURE__ */ new Set();
    for (const [number, generation] of bundle.generations.entries()) {
      object(generation, ["payload", "signature", "id"]);
      hex(generation.id);
      validateGeneration(generation.payload);
      const value = generation.payload;
      scope(value, descriptor);
      await verifyPeerValue(DOMAINS.peerGeneration, { payload: value, signature: generation.signature }, descriptor.controlPublicKey);
      check(generation.id === await peerDigest(["chronolog/peer-generation/generation/v1", value]), "PEER_GENERATION_ID_INVALID");
      check(value.number === number && value.previous === (verified.current?.id ?? null), "PEER_GENERATION_CHAIN_INVALID");
      const control = bundle.controls[value.controlRevision];
      check(control !== void 0 && value.controlDigest === await peerDigest(control), "PEER_CONTROL_DIGEST_MISMATCH");
      check(value.controlRevision === verified.control.payload.revision || value.controlRevision === verified.control.payload.revision + 1, "PEER_CONTROL_CHAIN_INVALID");
      await verified.authorizeTransition(value.transition, control);
      check(value.coordinator === value.transition.payload.coordinator && samePeerValue(value.adopted, value.transition.payload.base?.point ?? null) && samePeerValue(value.recoveryFloor, control.payload.recoveryFloor) && value.executionManifestDigest === descriptor.executionManifestDigest, "PEER_DELEGATION_MISMATCH");
      check(!transitions.has(value.transition.payload.transitionId), "PEER_TRANSITION_DUPLICATE");
      transitions.add(value.transition.payload.transitionId);
      if (value.controlRevision >= verified.#bundle.controls.length) verified.#bundle.controls.push(control);
      verified.#append(generation);
    }
    check(verified.control.payload.revision === bundle.controls.length - 1, "PEER_CONTROL_NOT_ACTIVATED");
    return verified;
  }
};
async function verifyNextControl(descriptor, previous, next) {
  validateControl(next.payload);
  scope(next.payload, descriptor);
  await verifyPeerValue(DOMAINS.peerControl, next, descriptor.controlPublicKey);
  check(
    next.payload.revision === previous.payload.revision + 1 && next.payload.previous === await peerDigest(previous) && next.payload.epoch >= previous.payload.epoch,
    "PEER_CONTROL_CHAIN_INVALID"
  );
  const revokedReader = previous.payload.grants.some((old) => old.reader && !next.payload.grants.some((grant) => grant.publicKey === old.publicKey && grant.reader));
  if (revokedReader) check(next.payload.epoch > previous.payload.epoch && next.payload.keyDigest !== previous.payload.keyDigest, "PEER_REVOCATION_REQUIRES_KEY_ROTATION");
  if (next.payload.epoch === previous.payload.epoch) check(next.payload.keyDigest === previous.payload.keyDigest, "PEER_EPOCH_KEY_CHANGED");
}
function verifyAuthorityBundle(bundle, pinned) {
  return PeerAuthority.verify(bundle, pinned);
}
var registryLocks = /* @__PURE__ */ new WeakMap();
function registryLock(store, key) {
  let keys = registryLocks.get(store);
  if (keys === void 0) {
    keys = /* @__PURE__ */ new Map();
    registryLocks.set(store, keys);
  }
  let lock = keys.get(key);
  if (lock === void 0) {
    lock = new Serial();
    keys.set(key, lock);
  }
  return lock;
}
var registryCaches = /* @__PURE__ */ new WeakMap();
async function createGenerationRegistry(options) {
  const key = `peer-generation/registry/${options.descriptor.payload.applicationId}`, lock = registryLock(options.store, key);
  let caches = registryCaches.get(options.store);
  if (caches === void 0) {
    caches = /* @__PURE__ */ new Map();
    registryCaches.set(options.store, caches);
  }
  const cache = caches;
  check(options.signer.publicKey === options.descriptor.payload.controlPublicKey, "PEER_CONTROL_KEY_MISMATCH");
  const read = async () => {
    const bytes = await options.store.get(key);
    check(bytes !== null, "PEER_CONTROL_STATE_MISSING");
    const head = bytesToHex(bytes), retained = cache.get(key);
    if (retained?.head === head) {
      check(samePeerValue(retained.authority.signedDescriptor, options.descriptor), "PEER_DESCRIPTOR_CHANGED");
      return retained.authority;
    }
    const decoded = decodePeerValue(bytes);
    let bundle;
    if ("format" in decoded) {
      object(decoded, ["format", "length"]);
      check(decoded.format === "chronolog-authority-log-v1", "PEER_CONTROL_STATE_INVALID");
      uint(decoded.length, 4096);
      const base = await options.store.get(`${key}/base`);
      check(base !== null, "PEER_CONTROL_STATE_MISSING");
      bundle = decodePeerValue(base);
      check(bundle.generations.length <= decoded.length, "PEER_CONTROL_STATE_INVALID");
      const controls = [...bundle.controls], generations = [...bundle.generations];
      for (let index = generations.length; index < decoded.length; index++) {
        const raw = await options.store.get(`${key}/log/${index}`);
        check(raw !== null, "PEER_CONTROL_STATE_MISSING");
        const entry = decodePeerValue(raw);
        object(entry, ["generation", "control"]);
        generations.push(entry.generation);
        if (entry.control !== null) controls.push(entry.control);
      }
      bundle = { descriptor: bundle.descriptor, controls, generations };
    } else bundle = decoded;
    const authority = await verifyAuthorityBundle(bundle, options.descriptor);
    cache.set(key, { head, authority });
    return authority;
  };
  await lock.run(async () => {
    if (await options.store.get(key) === null) {
      check(options.requireExisting !== true, "PEER_CONTROL_STATE_MISSING");
      const initial = { descriptor: options.descriptor, controls: options.controls, generations: [] };
      await verifyAuthorityBundle(initial);
      await options.store.put(`${key}/base`, encodePeerValue(initial));
      await options.store.put(key, encodePeerValue({ format: "chronolog-authority-log-v1", length: 0 }));
    }
    await read();
  });
  return {
    read: () => lock.run(async () => (await read()).bundle),
    async select(input, inputOptions = {}) {
      const request = structuredClone(input), next = structuredClone(inputOptions.control);
      return lock.run(async () => {
        const authority = await read();
        validateRequest(request.payload);
        await verifyPeerValue(DOMAINS.peerTransition, request, request.payload.requester);
        const retry = authority.transition(request.payload.transitionId);
        if (retry !== null) {
          check(samePeerValue(retry.payload.transition, request), "PEER_TRANSITION_ID_REUSED");
          if (next !== void 0) check(samePeerValue(authority.controlAt(retry.payload.controlRevision), next), "PEER_TRANSITION_ID_REUSED");
          return retry;
        }
        const control = next ?? authority.control;
        await authority.authorizeTransition(request, control);
        const payload = {
          applicationId: authority.descriptor.applicationId,
          profile: PEER_GENERATION_PROFILE,
          policy: PEER_GENERATION_POLICY,
          number: authority.generationCount,
          previous: authority.current?.id ?? null,
          coordinator: request.payload.coordinator,
          controlRevision: control.payload.revision,
          controlDigest: await peerDigest(control),
          adopted: request.payload.base?.point ?? null,
          recoveryFloor: control.payload.recoveryFloor,
          executionManifestDigest: authority.descriptor.executionManifestDigest,
          transition: request
        };
        const signed = await signPeerValue(DOMAINS.peerGeneration, payload, options.signer);
        const generation = { ...signed, id: await peerDigest(["chronolog/peer-generation/generation/v1", payload]) };
        const updated = await authority.extend(next === void 0 ? [] : [next], [generation]);
        const currentBytes = await options.store.get(key);
        check(currentBytes !== null, "PEER_CONTROL_STATE_MISSING");
        if (!("format" in decodePeerValue(currentBytes))) {
          await options.store.put(`${key}/base`, encodePeerValue(authority.bundle));
        }
        await options.store.put(`${key}/log/${generation.payload.number}`, encodePeerValue({ generation, control: next ?? null }));
        const head = encodePeerValue({ format: "chronolog-authority-log-v1", length: updated.generationCount });
        await options.store.put(key, head);
        cache.set(key, { head: bytesToHex(head), authority: updated });
        return structuredClone(generation);
      });
    }
  };
}

// packages/peer-generation/src/publication.ts
var PUBLICATION_LIMITS = Object.freeze({
  files: 128,
  bytes: 8 * 1024 * 1024,
  manifestBytes: 256 * 1024,
  revisions: 256,
  historyBytes: 16 * 1024 * 1024
});
function path(value) {
  boundedText(value, 1024);
  check(
    !/[\\?#%]/u.test(value) && value.split("/").every((part) => part.length > 0 && part !== "." && part !== ".."),
    "PEER_PUBLICATION_PATH_INVALID"
  );
}
function validatePublicationManifest(input) {
  object(input, [
    "applicationId",
    "historyId",
    "profile",
    "controlRevision",
    "author",
    "operationId",
    "revision",
    "previous",
    "definitionDigest",
    "executionManifestDigest",
    "entry",
    "files"
  ]);
  const value = input;
  hex(value.applicationId);
  boundedText(value.historyId, 128);
  hex(value.author);
  boundedText(value.operationId, 128);
  check(value.profile === PEER_GENERATION_PROFILE, "PEER_PROFILE_UNSUPPORTED");
  uint(value.controlRevision);
  uint(value.revision, PUBLICATION_LIMITS.revisions - 1);
  if (value.previous !== null) hex(value.previous);
  check(value.revision === 0 === (value.previous === null), "PEER_PUBLICATION_CHAIN_INVALID");
  hex(value.definitionDigest);
  hex(value.executionManifestDigest);
  path(value.entry);
  check(isArray(value.files) && value.files.length > 0 && value.files.length <= PUBLICATION_LIMITS.files, "PEER_PUBLICATION_FILES_LIMIT");
  let previous, total = 0;
  for (const file of value.files) {
    object(file, ["path", "hash", "size", "type"]);
    path(file.path);
    hex(file.hash);
    uint(file.size, PUBLICATION_LIMITS.bytes);
    boundedText(file.type, 256);
    check(/^[a-z][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*(?:;[ -~]*)?$/iu.test(file.type), "PEER_PUBLICATION_TYPE_INVALID");
    check(previous === void 0 || previous < file.path, "PEER_PUBLICATION_FILES_NOT_ORDERED");
    previous = file.path;
    total += file.size;
  }
  check(total <= PUBLICATION_LIMITS.bytes, "PEER_PUBLICATION_BYTES_LIMIT");
  check(value.files.some((file) => file.path === value.entry), "PEER_PUBLICATION_ENTRY_MISSING");
  check(encodePeerValue(value).length <= PUBLICATION_LIMITS.manifestBytes, "PEER_PUBLICATION_MANIFEST_LIMIT");
  return structuredClone(value);
}
async function signPublicationManifest(input, signer) {
  const payload = validatePublicationManifest(input);
  check(payload.author === signer.publicKey, "PEER_PUBLICATION_AUTHOR_MISMATCH");
  const signed = await signPeerValue(DOMAINS.peerPublication, payload, signer);
  return { ...signed, id: await peerDigest(["chronolog/publication/v1", signed.payload]) };
}
async function verifyPublicationManifest(input, authority) {
  const publication = structuredClone(input);
  object(publication, ["payload", "signature", "id"]);
  hex(publication.id);
  const value = validatePublicationManifest(publication.payload), descriptor = authority.descriptor;
  check(value.applicationId === descriptor.applicationId && value.historyId === descriptor.historyId && value.profile === descriptor.profile, "PEER_PUBLICATION_SCOPE_MISMATCH");
  check(
    value.definitionDigest === authority.definitionDigestAt(value.controlRevision) && value.executionManifestDigest === descriptor.executionManifestDigest,
    "PEER_PUBLICATION_SEMANTICS_MISMATCH"
  );
  check(authority.grant(value.author, value.controlRevision)?.publisher === true, "PEER_PUBLICATION_FORBIDDEN");
  check(publication.id === await peerDigest(["chronolog/publication/v1", value]), "PEER_PUBLICATION_ID_INVALID");
  await verifyPeerValue(DOMAINS.peerPublication, { payload: value, signature: publication.signature }, value.author);
}
async function authorizePublication(input, authority, previous) {
  const publication = structuredClone(input), head = structuredClone(previous);
  await verifyPublicationManifest(publication, authority);
  check(
    publication.payload.controlRevision === authority.control.payload.revision && authority.grant(publication.payload.author)?.publisher === true,
    "PEER_PUBLICATION_CONTROL_CHANGED"
  );
  if (head !== null) await verifyPublicationManifest(head, authority);
  check(
    publication.payload.previous === (head?.id ?? null) && publication.payload.revision === (head === null ? 0 : head.payload.revision + 1),
    "PEER_PUBLICATION_CONFLICT"
  );
}
async function verifyPublicationAsset(file, input) {
  object(file, ["path", "hash", "size", "type"]);
  path(file.path);
  hex(file.hash);
  uint(file.size, PUBLICATION_LIMITS.bytes);
  const bytes = input.slice();
  check(bytes.length === file.size && await bytesDigest(bytes) === file.hash, "PEER_PUBLICATION_ASSET_MISMATCH");
}
var locks = /* @__PURE__ */ new WeakMap();
function publicationLock(store, key) {
  let keys = locks.get(store);
  if (keys === void 0) {
    keys = /* @__PURE__ */ new Map();
    locks.set(store, keys);
  }
  let lock = keys.get(key);
  if (lock === void 0) {
    lock = new Serial();
    keys.set(key, lock);
  }
  return lock;
}
async function createPublicationRegistry(options) {
  const store = options.store, readAuthority = options.authority;
  const initial = await verifyAuthorityBundle(await readAuthority()), descriptor = initial.bundle.descriptor;
  const key = `peer-generation/publications/${descriptor.payload.applicationId}`, lock = publicationLock(store, key);
  const authority = async () => verifyAuthorityBundle(await readAuthority(), descriptor);
  const read = async (verified) => {
    const bytes = await store.get(key);
    check(bytes !== null, "PEER_PUBLICATION_STATE_MISSING");
    check(bytes.length <= PUBLICATION_LIMITS.historyBytes, "PEER_PUBLICATION_HISTORY_LIMIT");
    const values = decodePeerValue(bytes);
    check(isArray(values) && values.length <= PUBLICATION_LIMITS.revisions, "PEER_PUBLICATION_HISTORY_LIMIT");
    const operations = /* @__PURE__ */ new Set();
    for (const [index, publication] of values.entries()) {
      await verifyPublicationManifest(publication, verified);
      check(publication.payload.revision === index && publication.payload.previous === (values[index - 1]?.id ?? null), "PEER_PUBLICATION_CHAIN_INVALID");
      check(!operations.has(publication.payload.operationId), "PEER_PUBLICATION_OPERATION_REUSED");
      operations.add(publication.payload.operationId);
    }
    return values;
  };
  await lock.run(async () => {
    if (await store.get(key) === null) {
      check(options.requireExisting !== true, "PEER_PUBLICATION_STATE_MISSING");
      await store.put(key, encodePeerValue([]));
    }
    await read(await authority());
  });
  return {
    read: () => lock.run(async () => structuredClone(await read(await authority()))),
    async publish(input) {
      const publication = structuredClone(input);
      return lock.run(async () => {
        const verified = await authority(), values = await read(verified);
        await verifyPublicationManifest(publication, verified);
        const retry = values.find((value) => value.payload.operationId === publication.payload.operationId);
        if (retry !== void 0) {
          check(samePeerValue(retry, publication), "PEER_PUBLICATION_OPERATION_REUSED");
          return structuredClone(retry);
        }
        await authorizePublication(publication, verified, values.at(-1) ?? null);
        check(values.length < PUBLICATION_LIMITS.revisions, "PEER_PUBLICATION_HISTORY_LIMIT");
        const bytes = encodePeerValue([...values, publication]);
        check(bytes.length <= PUBLICATION_LIMITS.historyBytes, "PEER_PUBLICATION_HISTORY_LIMIT");
        const latest = await authority();
        assertAuthorityExtension(verified, latest);
        await authorizePublication(publication, latest, values.at(-1) ?? null);
        await store.put(key, bytes);
        return structuredClone(publication);
      });
    }
  };
}

export {
  PeerGenerationError,
  check,
  object,
  boundedText,
  hex,
  uint,
  encodePeerValue,
  decodePeerValue,
  samePeerValue,
  peerDigest,
  bytesDigest,
  signPeerValue,
  verifyPeerValue,
  createPeerIdentity,
  exportPeerIdentity,
  importPeerIdentity,
  Serial,
  isArray,
  PEER_GENERATION_PROFILE,
  PEER_GENERATION_POLICY,
  PEER_MAX_RECORDS,
  PEER_MAX_HISTORY_BYTES,
  PEER_GENERATION_CAPABILITIES,
  parseApplicationInput,
  checkedApplicationInputSchema,
  validateApplicationDescription,
  applicationDescriptionDigest,
  assertCompatibleDefinitionEvolution,
  signApplicationSchema,
  verifyApplicationSchema,
  PARTICIPANT_PROTOCOL,
  PARTICIPANT_LIMITS,
  CONTROL_PARTICIPANT_POLICY,
  PEER_PARTICIPANT_POLICY,
  ParticipantProtocolError,
  participantAccepts,
  validateParticipantRequest,
  createParticipantRequest,
  createParticipantResponse,
  validateParticipantResponse,
  createParticipantTransport,
  PUBLICATION_LIMITS,
  validatePublicationManifest,
  signPublicationManifest,
  verifyPublicationManifest,
  authorizePublication,
  verifyPublicationAsset,
  createPublicationRegistry,
  assertAuthorityExtension,
  validateHistoryPoint,
  signApplicationDescriptor,
  participantGrant,
  controlParticipantGrant,
  signControlRevision,
  signTransitionRequest,
  generationStartRoot,
  verifyOrderReceipt,
  PeerAuthority,
  verifyAuthorityBundle,
  createGenerationRegistry
};
