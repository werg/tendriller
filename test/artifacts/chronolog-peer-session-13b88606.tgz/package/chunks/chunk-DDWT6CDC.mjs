// packages/peer-session/src/projection-types.ts
var APPLICATION_PROJECTION_LIMITS = Object.freeze({ active: 8, pending: 8, stateBytes: 524288, checkpointBytes: 2097152 });

// packages/peer-generation/src/index.ts
async function createPeerReplica(options) {
  return (await import("./replica-HIBNSNJD.mjs")).createPeerReplica(options);
}

// packages/peer-session/src/session-types.ts
var APPLICATION_EVENT_CURSOR_LIMIT = 128 * 1024;

// packages/peer-session/src/operation.ts
var ApplicationOperation = class {
  constructor(session, operationId, author) {
    this.session = session;
    this.operationId = operationId;
    this.author = author;
  }
  session;
  operationId;
  author;
  get() {
    return this.session.operations.get(this.operationId, this.author === void 0 ? {} : { author: this.author });
  }
  applied(options = {}) {
    return this.session.waitFor(this.operationId, this.author === void 0 ? options : { ...options, author: this.author });
  }
  retry() {
    return this.session.retry(this.operationId, this.author);
  }
  async shared(options = {}) {
    const applied = await this.applied(options);
    return this.session.waitForCoverage(applied, options);
  }
};

export {
  APPLICATION_PROJECTION_LIMITS,
  createPeerReplica,
  APPLICATION_EVENT_CURSOR_LIMIT,
  ApplicationOperation
};
