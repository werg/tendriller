import type { BytesStore } from '../../records/src/index.js';
import { type ChronologMaterializationRuntime } from './runtime.js';
export type { BytesStore } from '../../records/src/index.js';
export { eventExecutionManifest } from './manifest.js';
export declare function createEventMaterializationRuntime(options: {
    readonly store: BytesStore;
    readonly namespace: string;
    readonly maxHistoryBytes?: number;
}): Promise<ChronologMaterializationRuntime>;
