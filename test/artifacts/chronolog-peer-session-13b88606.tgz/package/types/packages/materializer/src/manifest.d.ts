/** Pure execution metadata; no database or materialization implementation is imported. */
export declare function eventExecutionManifest(): Promise<import("../../protocol/src/index.js").ExecutionManifest>;
