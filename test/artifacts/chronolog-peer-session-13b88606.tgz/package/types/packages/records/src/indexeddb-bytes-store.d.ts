import type { BytesStore, BytesStoreEntry } from './bytes-store.js';
/** Transaction-complete, per-key atomic durable records; no signer or protocol state lives here. */
export declare class IndexedDbBytesStore implements BytesStore {
    #private;
    private constructor();
    static open(name: string, { create }?: {
        create?: boolean | undefined;
    }): Promise<IndexedDbBytesStore>;
    get(key: string): Promise<Uint8Array | null>;
    getMany(keys: readonly string[]): Promise<readonly (Uint8Array | null)[]>;
    put(key: string, input: Uint8Array): Promise<void>;
    putMany(entries: readonly BytesStoreEntry[]): Promise<void>;
    delete(key: string): Promise<void>;
    putAllIfEmpty(entries: readonly {
        readonly key: string;
        readonly value: Uint8Array;
    }[]): Promise<boolean>;
    iterateEntries(): AsyncIterable<BytesStoreEntry>;
    entries(): Promise<readonly BytesStoreEntry[]>;
    putStreamIfEmpty(entries: AsyncIterable<BytesStoreEntry>): Promise<boolean>;
    close(): Promise<void>;
}
/** Scratch-only conformance probe; never opens the device's actual database. */
export declare function probeIndexedDbBytesStore(): Promise<boolean>;
/**
 * Read-only existence inspection for a data database whose metadata/pin may
 * have been erased. Abort the version-0 upgrade rather than creating a
 * replacement; callers must fail closed when an orphaned data DB exists.
 */
export declare function inspectExistingIndexedDbRecords(name: string): Promise<boolean>;
