import type { BytesStore, BytesStoreEntry } from './bytes-store.js';
export interface NativeBytesStoreOptions {
    readonly quotaBytes?: number;
    readonly maxValueBytes?: number;
}
/** Stable SQLite in a dedicated worker. Await open() for acquisition and close() for release. */
export declare class NativeBytesStore implements BytesStore {
    #private;
    constructor(path: string, options?: NativeBytesStoreOptions);
    static open(path: string, options?: NativeBytesStoreOptions): Promise<NativeBytesStore>;
    get(key: string): Promise<Uint8Array | null>;
    getMany(keys: readonly string[]): Promise<readonly (Uint8Array | null)[]>;
    put(key: string, value: Uint8Array): Promise<void>;
    putMany(entries: readonly BytesStoreEntry[]): Promise<void>;
    delete(key: string): Promise<void>;
    iterateEntries(): AsyncIterable<BytesStoreEntry>;
    entries(): Promise<readonly BytesStoreEntry[]>;
    putAllIfEmpty(entries: readonly BytesStoreEntry[]): Promise<boolean>;
    putStreamIfEmpty(entries: AsyncIterable<BytesStoreEntry>): Promise<boolean>;
    checkpointWal(): Promise<void>;
    usageBytes(): number;
    close(): Promise<void>;
}
