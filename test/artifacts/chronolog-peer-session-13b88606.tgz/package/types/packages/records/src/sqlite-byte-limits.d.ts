export interface SqliteBytesStoreOptions {
    readonly quotaBytes?: number;
    readonly maxValueBytes?: number;
}
export declare function sqliteByteLimits(options: SqliteBytesStoreOptions): {
    quotaBytes: number;
    maxValueBytes: number;
};
export declare function validateSqliteByteKey(key: string): void;
