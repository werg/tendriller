import type { PeerLiveLane, FramedPeerConnection } from './connection.js';
export interface PeerStreamOptions {
    readonly readable: ReadableStream<Uint8Array>;
    readonly writable: WritableStream<Uint8Array>;
    readonly maxFrameBytes?: number;
    readonly maxPendingSends?: number;
}
/** A dedicated live stream permits one write in flight and refuses further writes while busy. */
export declare function frameLivePeerStream(options: Omit<PeerStreamOptions, 'maxPendingSends'>): PeerLiveLane;
/**
 * Four-byte network-order length framing over a reliable browser/native byte
 * stream. It has no database identity or permission semantics: signed Chronolog
 * records, evidence and ephemeral domains remain independently authenticated.
 */
export declare function framePeerStream(options: PeerStreamOptions): FramedPeerConnection;
