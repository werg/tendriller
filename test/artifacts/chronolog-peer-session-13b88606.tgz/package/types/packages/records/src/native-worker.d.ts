export declare const nativeWorkerSource: string;
