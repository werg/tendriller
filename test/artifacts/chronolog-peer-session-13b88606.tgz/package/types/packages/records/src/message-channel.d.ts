import type { FramedPeerConnection } from './connection.js';
import { type LiveMessageConnection } from './live-channel.js';
/** A binary message transport with a writable-buffer low-water notification. */
export interface PeerMessageChannel {
    readonly readyState: string;
    readonly bufferedAmount: number;
    bufferedAmountLowThreshold: number;
    binaryType: string;
    send(data: ArrayBuffer): void;
    close(): void;
    addEventListener(type: string, listener: EventListener): void;
    removeEventListener(type: string, listener: EventListener): void;
}
export interface PeerMessageChannels {
    readonly reliable: PeerMessageChannel;
    readonly live: PeerMessageChannel;
}
export declare const PEER_MESSAGE_LIMITS: Readonly<{
    frameBytes: number;
    packetBytes: number;
    queueBytes: number;
    queueFrames: 16;
    bufferedBytes: number;
}>;
export interface MessageChannelStats {
    readonly sentBytes: number;
    readonly receivedBytes: number;
    readonly sentPackets: number;
    readonly receivedPackets: number;
    readonly queuedSendBytes: number;
    readonly queuedReceiveBytes: number;
    readonly queuedReceiveFrames: number;
}
export interface MessageConnection extends FramedPeerConnection {
    readonly ready: Promise<void>;
    /** Ends on framing failure or physical channel closure. */
    readonly signal: AbortSignal;
    readonly stats: MessageChannelStats;
}
export interface PeerMessageConnection extends MessageConnection {
    readonly live: LiveMessageConnection;
}
/** Compose separate traffic lanes while retaining one close/authentication lifetime. */
export declare function framePeerMessageChannels(channels: PeerMessageChannels, options?: Parameters<typeof frameMessageChannel>[1]): PeerMessageConnection;
/**
 * One reliable ordered binary message channel. Whole-frame receive credit bounds
 * allocation and object count; transport bufferedAmount separately bounds writes.
 * Credits are returned only after the application advances its frame iterator.
 */
export declare function frameMessageChannel(channel: PeerMessageChannel, options?: {
    readonly maxFrameBytes?: number;
    readonly queueBytes?: number;
    readonly queueFrames?: number;
    readonly sendTimeoutMs?: number;
    /** Starts when the local channel opens, independently of transport admission. */
    readonly helloTimeoutMs?: number;
}): MessageConnection;
