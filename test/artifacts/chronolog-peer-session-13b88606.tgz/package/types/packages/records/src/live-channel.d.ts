import type { MessageChannelStats, PeerMessageChannel } from './message-channel.js';
import type { PeerLiveLane } from './connection.js';
export declare const PEER_LIVE_MESSAGE_LIMITS: Readonly<{
    frameBytes: 16448;
    queueFrames: 64;
    bufferedBytes: 65536;
}>;
export interface LiveMessageConnection extends PeerLiveLane {
    readonly ready: Promise<void>;
    readonly signal: AbortSignal;
    readonly stats: MessageChannelStats & {
        readonly droppedPackets: number;
    };
}
/**
 * Disposable frames on an independent message channel. The physical transport
 * determines delivery ordering; this lane never adds a queue, credit wait or retry.
 * Congestion refuses dispatch; a slow reader loses oldest pending datagrams.
 */
export declare function frameLiveMessageChannel(channel: PeerMessageChannel): LiveMessageConnection;
