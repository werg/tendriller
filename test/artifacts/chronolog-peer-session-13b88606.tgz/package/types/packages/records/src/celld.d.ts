import type { BytesStore } from './bytes-store.js';
import { type SqliteBytesStoreOptions } from './sqlite-byte-limits.js';
export type CelldBytesStoreOptions = SqliteBytesStoreOptions;
type SqlValue = string | number | Uint8Array | null;
/** Managed SQLite storage of a single celld Durable Object or SQLite facet. */
export interface CelldBytesStorage {
    readonly sql: {
        exec(query: string, ...bindings: SqlValue[]): {
            toArray(): Record<string, unknown>[];
        };
    };
    transactionSync<T>(operation: () => T): T;
}
/** Runtime KV is outside the SQL namespace visible to a signed application. */
export interface CelldPrivateBytesStorage {
    readonly kv: {
        get(key: string): unknown;
        put(key: string, value: unknown): void;
    };
    transactionSync<T>(operation: () => T): T;
}
interface Entry {
    readonly key: string;
    readonly value: Uint8Array;
}
/** Atomic records for the owning object's current activation. */
export declare class CelldBytesStore implements BytesStore {
    #private;
    private readonly storage;
    constructor(storage: CelldBytesStorage, options?: CelldBytesStoreOptions);
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, value: Uint8Array): Promise<void>;
    /** Persist a device signer and its immutable binding together. */
    initialize(entries: readonly Entry[]): Promise<void>;
    compareAndSwap(key: string, expected: Uint8Array | null, value: Uint8Array): Promise<boolean>;
    usageBytes(): number;
    close(): void;
}
/**
 * Device and transport records held by the same activation as a Dolt
 * application. The runtime carries these bytes across branch switches in KV.
 */
export declare class CelldPrivateBytesStore implements BytesStore {
    #private;
    private readonly storage;
    constructor(storage: CelldPrivateBytesStorage, options?: CelldBytesStoreOptions & {
        readonly namespace?: string;
    });
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, value: Uint8Array): Promise<void>;
    initialize(entries: readonly Entry[]): Promise<void>;
    compareAndSwap(key: string, expected: Uint8Array | null, value: Uint8Array): Promise<boolean>;
    usageBytes(): number;
    close(): void;
}
export {};
