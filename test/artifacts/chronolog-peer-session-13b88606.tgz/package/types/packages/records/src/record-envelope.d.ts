export declare const MAX_RECORD_VALUE_BYTES: number;
export declare const MAX_RECORD_ENVELOPE_BYTES: number;
export declare function assertRecordKey(key: string): void;
export declare function recordFilename(key: string): Promise<string>;
/** Both durable backends store the same bounded, authenticated logical record envelope. */
export declare function encodeRecordValue(key: string, bytes: Uint8Array): Promise<Uint8Array>;
export declare function decodeRecordValue(key: string, raw: Uint8Array, corruptionCode: string): Promise<Uint8Array>;
/** Recover a logical key for bounded OPFS enumeration; authenticate the same envelope. */
export declare function decodeRecordEntry(raw: Uint8Array, corruptionCode: string): Promise<{
    key: string;
    value: Uint8Array;
}>;
