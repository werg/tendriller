import type { BytesStore } from '../../records/src/index.js';
import { type PeerAuthority } from './control.js';
import { PEER_GENERATION_PROFILE, type AuthorityBundle, type PeerIdentity, type Signed } from './control-types.js';
export declare const PUBLICATION_LIMITS: Readonly<{
    files: 128;
    bytes: number;
    manifestBytes: number;
    revisions: 256;
    historyBytes: number;
}>;
export interface PublicationFile {
    readonly path: string;
    readonly hash: string;
    readonly size: number;
    readonly type: string;
}
/** Presentation can evolve independently; executable application semantics stay descriptor-bound. */
export interface PublicationManifest {
    readonly applicationId: string;
    readonly historyId: string;
    readonly profile: typeof PEER_GENERATION_PROFILE;
    readonly controlRevision: number;
    readonly author: string;
    readonly operationId: string;
    readonly revision: number;
    readonly previous: string | null;
    readonly definitionDigest: string;
    readonly executionManifestDigest: string;
    readonly entry: string;
    readonly files: readonly PublicationFile[];
}
export interface SignedPublication extends Signed<PublicationManifest> {
    readonly id: string;
}
export declare function validatePublicationManifest(input: unknown): PublicationManifest;
export declare function signPublicationManifest(input: PublicationManifest, signer: PeerIdentity): Promise<SignedPublication>;
/** Historical validity survives a later publisher revocation; acceptance uses authorizePublication. */
export declare function verifyPublicationManifest(input: SignedPublication, authority: PeerAuthority): Promise<void>;
/** Select a new release only under the current control and exact retained publication head. */
export declare function authorizePublication(input: SignedPublication, authority: PeerAuthority, previous: SignedPublication | null): Promise<void>;
/** Publication references authenticate bytes; they never grant access to a provider. */
export declare function verifyPublicationAsset(file: PublicationFile, input: Uint8Array): Promise<void>;
export interface PublicationRegistry {
    read(): Promise<readonly SignedPublication[]>;
    publish(publication: SignedPublication): Promise<SignedPublication>;
}
/** An exclusive control store publishes occasional metadata atomically; asset storage is a transport concern. */
export declare function createPublicationRegistry(options: {
    readonly store: BytesStore;
    readonly authority: () => Promise<AuthorityBundle>;
    readonly requireExisting?: boolean;
}): Promise<PublicationRegistry>;
