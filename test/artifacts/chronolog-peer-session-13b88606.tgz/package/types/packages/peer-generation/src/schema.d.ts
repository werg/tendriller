import { type ChangeProgram } from '../../protocol/src/index.js';
import type { ApplicationDescriptor, ApplicationSchema, PeerIdentity, SignedApplicationSchema } from './control-types.js';
export declare function signApplicationSchema(payload: ApplicationSchema, signer: PeerIdentity): Promise<SignedApplicationSchema>;
/** A trusted schema authority signs genesis state, independently of the control host. */
export declare function verifyApplicationSchema(schema: SignedApplicationSchema, descriptor: ApplicationDescriptor): Promise<ChangeProgram>;
