export * from './control.js';
export * from './types.js';
export { MemoryBytesStore } from '../../records/src/index.js';
import type { PeerReplica, PeerReplicaOptions } from './types.js';
/** Database machinery loads only when an owner explicitly asks for a replica. */
export declare function createPeerReplica(options: PeerReplicaOptions): Promise<PeerReplica>;
export * from './schema.js';
export { validatePeerRevision } from './attempt.js';
export { samePeerValue } from './codec.js';
