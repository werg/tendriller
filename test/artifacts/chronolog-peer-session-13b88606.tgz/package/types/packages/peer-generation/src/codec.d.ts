import { bytesToHex, hexToBytes } from '../../canonical/src/index.js';
import { type ProtocolDomain } from '../../protocol/src/index.js';
import type { PeerIdentity, Signed } from './control-types.js';
export { bytesToHex, hexToBytes };
export declare class PeerGenerationError extends Error {
    readonly code: string;
    constructor(code: string);
}
export declare function check(condition: unknown, code: string): asserts condition;
export declare function object(value: unknown, keys: readonly string[]): Record<string, unknown>;
export declare function boundedText(value: unknown, max?: number): asserts value is string;
export declare function hex(value: unknown, bytes?: number): asserts value is string;
export declare function uint(value: unknown, maximum?: number): asserts value is number;
export declare function encodePeerValue(value: unknown): Uint8Array;
export declare function decodePeerValue<T>(bytes: Uint8Array): T;
export declare function samePeerValue(left: unknown, right: unknown): boolean;
export declare function peerDigest(value: unknown): Promise<string>;
export declare function bytesDigest(value: Uint8Array): Promise<string>;
export declare function signPeerValue<T>(domain: ProtocolDomain, payload: T, identity: PeerIdentity): Promise<Signed<T>>;
export declare function verifyPeerValue<T>(domain: ProtocolDomain, value: Signed<T>, publicKey: string): Promise<void>;
export declare function createPeerIdentity(): Promise<PeerIdentity>;
export declare function exportPeerIdentity(identity: PeerIdentity): Promise<{
    publicKey: string;
    privateKey: string;
}>;
export declare function importPeerIdentity(value: {
    readonly publicKey: string;
    readonly privateKey: string;
}): Promise<PeerIdentity>;
export declare class Serial {
    #private;
    run<T>(task: () => Promise<T>): Promise<T>;
}
/** Boolean guard avoids widening typed readonly lists to any[]. */
export declare function isArray(value: unknown): boolean;
