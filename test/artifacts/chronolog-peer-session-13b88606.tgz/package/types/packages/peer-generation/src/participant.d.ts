/** Delivery interests are separate from signed authority and application history. */
export declare const PARTICIPANT_PROTOCOL: "chronolog-participant-v1";
export type ParticipantFacet = 'control' | 'publication' | 'discovery' | 'ephemeral' | 'database' | 'content';
export interface ParticipantInterest {
    readonly facet: ParticipantFacet;
    readonly action: string;
}
export interface ParticipantPolicy {
    readonly role: 'control' | 'peer';
    readonly interests: readonly ParticipantInterest[];
}
export interface ParticipantRequest extends ParticipantInterest {
    readonly protocol: typeof PARTICIPANT_PROTOCOL;
    readonly applicationId: string;
    readonly requestId: string;
    readonly payload: unknown;
}
export type ParticipantResponse = ParticipantRequest;
export interface ParticipantExchangeOptions {
    readonly signal?: AbortSignal;
}
export interface ParticipantTransport {
    readonly applicationId: string;
    readonly policy: ParticipantPolicy;
    exchange(request: ParticipantRequest, options?: ParticipantExchangeOptions): Promise<ParticipantResponse>;
    request<T = unknown>(facet: ParticipantFacet, action: string, payload: unknown, options?: ParticipantExchangeOptions): Promise<T>;
}
export declare const PARTICIPANT_LIMITS: Readonly<{
    pending: 4;
    depth: 32;
    bytes: Readonly<{
        control: number;
        publication: number;
        discovery: number;
        ephemeral: number;
        database: number;
        content: number;
    }>;
}>;
/** The host receives lifecycle/control traffic; ordinary data and live UI activity are excluded. */
export declare const CONTROL_PARTICIPANT_POLICY: ParticipantPolicy;
export declare const PEER_PARTICIPANT_POLICY: ParticipantPolicy;
export declare class ParticipantProtocolError extends Error {
    readonly code: string;
    constructor(code: string);
}
export declare function participantAccepts(policy: ParticipantPolicy, interest: ParticipantInterest): boolean;
/** Validate before routing or dispatch. A transport policy does not confer author permissions. */
export declare function validateParticipantRequest(value: unknown, selected?: ParticipantPolicy): ParticipantRequest;
export declare function createParticipantRequest(input: Omit<ParticipantRequest, 'protocol' | 'requestId'> & {
    readonly requestId?: string;
}, selected?: ParticipantPolicy): ParticipantRequest;
export declare function createParticipantResponse(request: ParticipantRequest, payload: unknown, selected?: ParticipantPolicy): ParticipantResponse;
export declare function validateParticipantResponse(value: unknown, request: ParticipantRequest, selected?: ParticipantPolicy): ParticipantResponse;
/** One bounded request transport. It never polls or substitutes a data-plane fallback. */
export declare function createParticipantTransport(options: {
    readonly applicationId: string;
    readonly policy?: ParticipantPolicy;
    readonly exchange: (request: ParticipantRequest, options: ParticipantExchangeOptions) => Promise<unknown>;
}): ParticipantTransport;
