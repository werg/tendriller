import { type BytesStore } from '../../records/src/index.js';
import { type TransactionCore } from '../../protocol/src/index.js';
import { type PeerAuthority } from './control.js';
import type { OrderReceipt, PeerIdentity, SignedAttempt } from './types.js';
interface Verified {
    readonly core: TransactionCore;
    readonly encoded: Uint8Array;
    readonly source: string;
    readonly control: string;
    receipt: string | null;
    dirty: boolean;
}
/** Local-only authenticated acceleration. Original bytes are still read and hashed on reopen. */
export declare class VerifiedReplayCache {
    #private;
    readonly store: BytesStore;
    readonly prefix: string;
    readonly device: PeerIdentity;
    readonly epochKeys: ReadonlyMap<number, Uint8Array>;
    readonly enabled: boolean;
    constructor(store: BytesStore, prefix: string, device: PeerIdentity, epochKeys: ReadonlyMap<number, Uint8Array>, enabled?: boolean);
    prefetch(attempts: readonly SignedAttempt[]): Promise<void>;
    attempt(attempt: SignedAttempt, authority: PeerAuthority): Promise<Verified>;
    receipt(receipt: OrderReceipt, attempt: SignedAttempt, authority: PeerAuthority): Promise<Verified>;
    get dirtyCount(): number;
    /** Optional acceleration written periodically and at clean close, never blocking the command critical path. */
    flush(): Promise<void>;
}
export {};
