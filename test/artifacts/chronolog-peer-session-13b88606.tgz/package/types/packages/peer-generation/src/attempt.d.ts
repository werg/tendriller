import { type TransactionCore } from '../../protocol/src/index.js';
import { type PeerAuthority } from './control.js';
import type { AttemptHeader, PeerIdentity, PeerRevision, SignedAttempt } from './types.js';
export declare function validatePeerRevision(value: PeerRevision): void;
export declare function createSignedAttempt(header: AttemptHeader, core: TransactionCore, key: Uint8Array, device: PeerIdentity): Promise<SignedAttempt>;
/** Checks origin and historical authorization; ordering/admission checks are separate. */
export declare function verifyAttempt(attempt: SignedAttempt, authority: PeerAuthority, epochKeys: ReadonlyMap<number, Uint8Array>): Promise<TransactionCore>;
