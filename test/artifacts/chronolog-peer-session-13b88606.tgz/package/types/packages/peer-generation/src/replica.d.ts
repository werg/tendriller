import type { PeerReplica, PeerReplicaOptions } from './types.js';
export declare function createPeerReplica(options: PeerReplicaOptions): Promise<PeerReplica>;
