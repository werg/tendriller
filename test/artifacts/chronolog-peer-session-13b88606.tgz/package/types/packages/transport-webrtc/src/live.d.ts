import { type LiveMessageConnection } from '../../records/src/index.js';
import type { RtcDataChannel } from './types.js';
export declare const WEBRTC_LIVE_LIMITS: Readonly<{
    frameBytes: 16448;
    queueFrames: 64;
    bufferedBytes: 65536;
}>;
export type LiveDataChannelConnection = LiveMessageConnection;
export declare function requireRtcLiveChannel(channel: RtcDataChannel): void;
export declare function frameRtcLiveChannel(channel: RtcDataChannel): LiveDataChannelConnection;
