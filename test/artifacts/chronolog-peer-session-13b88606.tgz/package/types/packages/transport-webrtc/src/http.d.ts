import type { DataChannelConnection } from './channel.js';
import type { PeerSignaling, RtcPeerConnection } from './types.js';
export declare const WEBRTC_HTTP_PROTOCOL = "chronolog.webrtc.v1";
export declare const WEBRTC_HTTP_LIMITS: Readonly<{
    messageBytes: number;
    pending: 8;
    connections: 32;
    timeoutMs: 30000;
}>;
export interface HttpWebRtcSignaling extends PeerSignaling {
    readonly stats: {
        readonly requests: number;
        readonly requestBytes: number;
        readonly responseBytes: number;
        readonly closed: boolean;
    };
    close(): void;
}
/** One direct offer/answer request to a reachable resident; no polling or live host subscription. */
export declare function createHttpWebRtcSignaling(options: {
    readonly url: string;
    readonly headers?: HeadersInit;
    readonly fetch?: typeof globalThis.fetch;
    readonly signal?: AbortSignal;
    readonly timeoutMs?: number;
}): HttpWebRtcSignaling;
export interface AcceptedWebRtcPeer {
    readonly completion: Promise<void>;
    close(): Promise<void>;
}
export interface WebRtcOfferHandler {
    fetch(request: Request): Promise<Response>;
    readonly stats: {
        readonly requests: number;
        readonly offers: number;
        readonly accepted: number;
        readonly rejected: number;
        readonly failed: number;
        readonly pending: number;
        readonly active: number;
        readonly closed: boolean;
    };
    close(): Promise<void>;
}
/**
 * A resident-owned introduction endpoint. The answer is returned before ICE or
 * authentication completes, so the caller can install it and finish connecting.
 * Introduction permission is separate from the accepted peer's read capability.
 */
export declare function createWebRtcOfferHandler(options: {
    readonly createPeerConnection: (configuration: RTCConfiguration) => RtcPeerConnection;
    readonly accept: (connection: DataChannelConnection, signal: AbortSignal) => Promise<AcceptedWebRtcPeer>;
    readonly authorize: (request: Request, signal: AbortSignal) => boolean | Promise<boolean>;
    readonly allowedOrigins: readonly string[];
    readonly configuration?: RTCConfiguration;
    readonly maxPending?: number;
    readonly maxConnections?: number;
    readonly timeoutMs?: number;
    /** Per-introduction or per-peer diagnostics; failure retires only that session. */
    readonly onError?: (error: unknown) => void | Promise<void>;
}): WebRtcOfferHandler;
