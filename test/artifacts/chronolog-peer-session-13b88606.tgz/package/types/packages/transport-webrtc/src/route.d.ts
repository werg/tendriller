import type { RtcPeerConnection, WebRtcRoute } from './types.js';
/**
 * A successful RTC handshake or a supplied ICE configuration is not route
 * evidence. Only the currently selected candidate pair can identify a relay.
 */
export declare function observeWebRtcRoute(connection: Pick<RtcPeerConnection, 'connectionState' | 'getStats'>): Promise<WebRtcRoute>;
