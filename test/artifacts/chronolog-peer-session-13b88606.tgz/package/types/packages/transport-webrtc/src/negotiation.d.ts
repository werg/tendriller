import type { PeerDataChannelConnection } from './channel.js';
import type { WebRtcChannels, WebRtcOptions, WebRtcSession } from './types.js';
/**
 * Both fixed negotiated channels are created synchronously on each endpoint.
 * The callback attaches raw framing synchronously. The portable Worker bridge
 * forwards opaque frames; it does not transfer these channels.
 */
export declare function negotiateWebRtc(options: WebRtcOptions & {
    readonly onDataChannels: (channels: WebRtcChannels) => void;
}): Promise<WebRtcSession>;
export declare function openWebRtcConnection(options: WebRtcOptions): Promise<PeerDataChannelConnection & {
    readonly session: WebRtcSession;
}>;
