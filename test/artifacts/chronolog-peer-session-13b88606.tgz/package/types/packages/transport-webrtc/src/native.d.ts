import type { PeerConfig } from 'werift';
import type { RtcPeerConnection } from './types.js';
export type NativeRtcOptions = Partial<Pick<PeerConfig, 'icePortRange' | 'iceInterfaceAddresses' | 'iceAdditionalHostAddresses' | 'iceUseIpv4' | 'iceUseIpv6' | 'iceUseTcp' | 'iceTcpPassive' | 'iceStunGatherTimeout' | 'iceTurnConnectTimeout' | 'turnUdpFamily'>>;
/** Explicit native entrypoint: no Node or Werift bytes enter browser bundles. */
export declare function createNativePeerConnection(configuration?: RTCConfiguration, native?: NativeRtcOptions): RtcPeerConnection;
