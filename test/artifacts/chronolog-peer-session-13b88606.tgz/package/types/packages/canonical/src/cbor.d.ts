export type CborMapKey = bigint | string | Uint8Array;
export type CborValue = null | boolean | bigint | string | Uint8Array | readonly CborValue[] | ReadonlyMap<CborMapKey, CborValue>;
export interface DecodeLimits {
    readonly maxBytes: number;
    readonly maxDepth: number;
    readonly maxArrayItems: number;
    readonly maxMapItems: number;
    readonly maxTextBytes: number;
    readonly maxBlobBytes: number;
}
export declare const DEFAULT_DECODE_LIMITS: Readonly<DecodeLimits>;
export declare function encodeCanonicalCbor(value: CborValue): Uint8Array;
export declare function decodeCanonicalCbor(input: Uint8Array, limits: DecodeLimits): CborValue;
export declare function assertCanonicalCbor(input: Uint8Array, limits: DecodeLimits): CborValue;
