export type CanonicalErrorCode = 'CBOR_INVALID' | 'CBOR_NON_CANONICAL' | 'CBOR_LIMIT_EXCEEDED' | 'SCHEMA_INVALID' | 'INTEGER_OUT_OF_RANGE' | 'INVALID_UTF8' | 'DIGEST_MISMATCH';
export declare class CanonicalError extends Error {
    readonly code: string;
    readonly details?: Readonly<Record<string, unknown>> | undefined;
    constructor(code: string, message: string, details?: Readonly<Record<string, unknown>> | undefined);
}
export declare function canonicalInvariant(condition: unknown, code: string, message: string, details?: Readonly<Record<string, unknown>>): asserts condition;
