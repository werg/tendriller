export declare function utf8(value: string): Uint8Array;
export declare function decodeUtf8(value: Uint8Array): string;
export declare function concatBytes(...parts: readonly Uint8Array[]): Uint8Array;
export declare function compareBytes(left: Uint8Array, right: Uint8Array): number;
export declare function equalBytes(left: Uint8Array, right: Uint8Array): boolean;
export declare function bytesToHex(value: Uint8Array): string;
export declare function hexToBytes(value: string): Uint8Array;
export declare function copyBytes(value: Uint8Array): Uint8Array;
