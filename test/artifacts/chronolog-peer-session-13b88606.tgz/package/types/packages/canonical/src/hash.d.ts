export declare const HASH_DOMAINS: Readonly<{
    readonly transaction: "chronolog/transaction";
    readonly schema: "chronolog/schema";
    readonly executionManifest: "chronolog/execution-manifest";
    readonly queryResult: "chronolog/query-result";
    readonly expectation: "chronolog/expectation";
    readonly module: "chronolog/module";
    readonly entropy: "chronolog/entropy";
    readonly platformObject: "chronolog/platform-object";
}>;
export type HashDomainKey = keyof typeof HASH_DOMAINS;
export declare function domainSeparatedBytes(domain: HashDomainKey, payload: Uint8Array): Uint8Array;
export declare function sha256(payload: Uint8Array): Promise<Uint8Array>;
export declare function hashDomain(domain: HashDomainKey, payload: Uint8Array): Promise<Uint8Array>;
