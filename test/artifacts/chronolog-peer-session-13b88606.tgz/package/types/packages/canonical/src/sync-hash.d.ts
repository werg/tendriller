/** Synchronous hashing for synchronous SQL engine callbacks on native and WASM. */
export declare function sha256Sync(bytes: Uint8Array): Uint8Array;
export declare function createSha256(): {
    update(bytes: Uint8Array | string): ReturnType<typeof createSha256>;
    digest(): Uint8Array;
};
