import { type PeerMessageConnection } from '../../records/src/index.js';
/** The standard browser/Worker/native WebSocket surface, including relay socket ports. */
export interface PeerWebSocket {
    readonly readyState: number;
    readonly bufferedAmount: number;
    binaryType: string;
    send(data: ArrayBuffer): void;
    close(): void;
    addEventListener(type: string, listener: EventListener): void;
    removeEventListener(type: string, listener: EventListener): void;
}
export interface WebSocketPeerChannels {
    readonly reliable: PeerWebSocket;
    readonly live: PeerWebSocket;
}
export interface WebSocketPeerOptions {
    /** Transport admission may finish after listeners have been installed. */
    readonly ready?: Promise<unknown>;
    readonly signal?: AbortSignal;
    readonly openTimeoutMs?: number;
}
/** Acquire both lanes synchronously, then return only after bounded admission and framing. */
export declare function openWebSocketConnection(sockets: WebSocketPeerChannels, options?: WebSocketPeerOptions): Promise<PeerMessageConnection>;
/**
 * Two independent WebSockets use the same bounded framing owner as WebRTC.
 * Install this synchronously when acquiring the sockets: no frame may arrive
 * before its reader is attached. Peer authentication/encryption belongs to the
 * application session above this byte transport.
 */
export declare function frameWebSocketPeerConnection(sockets: WebSocketPeerChannels, options?: WebSocketPeerOptions): PeerMessageConnection;
