export { frameWebSocketPeerConnection, openWebSocketConnection, type PeerWebSocket, type WebSocketPeerChannels, type WebSocketPeerOptions, } from '../../transport-websocket/src/index.js';
