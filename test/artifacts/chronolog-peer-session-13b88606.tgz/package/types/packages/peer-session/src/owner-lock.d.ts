/** A protocol-owner lease is distinct from the lazy durable-data storage lock. */
export interface ApplicationOwnerLock {
    readonly profileId: string;
    readonly signal: AbortSignal;
    close(): Promise<void>;
}
export interface ApplicationOwnerLockManager {
    request(name: string, options: {
        readonly mode: 'exclusive';
        readonly ifAvailable?: true;
        readonly signal?: AbortSignal;
    }, callback: (lock: object | null) => Promise<void>): Promise<void>;
}
/**
 * Never steals a suspended owner's lease. Acquire before opening profile identity,
 * then release only after the owner's session closes. No OPFS/SQL import or access.
 * Caller cancellation affects acquisition, not an already acquired owner lifetime.
 */
export declare function acquireApplicationOwnerLock(profileId: string, options?: {
    readonly locks?: ApplicationOwnerLockManager;
    /** Queue a fenced takeover until the previous owner actually releases its lease. */
    readonly wait?: boolean;
    readonly signal?: AbortSignal;
}): Promise<ApplicationOwnerLock>;
