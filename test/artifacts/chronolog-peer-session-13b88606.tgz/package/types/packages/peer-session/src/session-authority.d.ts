import { type AuthorityBundle, type PeerAuthority } from '../../peer-generation/src/control.js';
import type { ApplicationDevice } from './device.js';
/** All protocol lifetimes share one monotonic signed authority anchor. */
export declare function retainApplicationAuthority(device: ApplicationDevice, input: AuthorityBundle): Promise<PeerAuthority>;
