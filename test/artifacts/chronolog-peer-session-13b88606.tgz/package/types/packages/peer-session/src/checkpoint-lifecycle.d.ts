import type { BytesStore } from '../../records/src/index.js';
export declare function useDeviceStore(store: BytesStore): () => void;
export declare function reserveCheckpointStore(store: BytesStore): () => void;
export declare function retireDeviceStore(store: BytesStore): void;
