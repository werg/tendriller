import { type PeerReplica, type PeerRevision, type AppliedResult, type OperationState, type AuthorityBundle, type RecoveryNotice, type SignedAttempt, type SignedRetainedCoverage, type PrefixProof, type HistoryCompactionOptions, type HistoryCompactionResult } from '../../peer-generation/src/index.js';
import type { PeerIdentity } from '../../peer-generation/src/control.js';
import { type ChangeProgram, type EventPayload } from '../../protocol/src/index.js';
import type { ApplicationCommand, ApplicationDefinition, ApplicationQuery } from './definition.js';
import type { ApplicationStorage } from './device.js';
import type { ApplicationSession } from './session.js';
import type { OpenPeerApplicationOptions } from './runtime.js';
import type { ApplicationDataPort } from './participant-types.js';
import { type ApplicationChange, type ApplicationEvent, type ApplicationReadView, type CommandOptions } from './session-types.js';
import { ApplicationOperation, type ApplicationSubmission } from './operation.js';
import { ApplicationRecovery } from './recovery.js';
import { ApplicationContent } from './content.js';
import { ApplicationKeyring } from './keys.js';
import { ApplicationProjection, type ApplicationProjectionDefinition, type ApplicationProjectionHandle } from './projection.js';
type CommandArguments<T> = T extends ApplicationCommand<infer I> ? I : never;
type QueryArguments<T> = T extends ApplicationQuery<infer I, unknown, never> ? I : never;
type QueryResult<T> = T extends ApplicationQuery<never, infer R, never> ? Awaited<R> : never;
/** The one durable journal, materializer and local-view implementation. */
export declare class ApplicationData<D extends ApplicationDefinition = ApplicationDefinition> implements ApplicationDataPort {
    #private;
    readonly signal: AbortSignal;
    readonly content: ApplicationContent;
    readonly keys: ApplicationKeyring;
    readonly recovery: ApplicationRecovery;
    readonly operations: {
        get(operationId: string, options?: {
            readonly author?: string;
        }): Promise<OperationState | null>;
        inspect(operationId: string, options?: {
            readonly author?: string;
        }): Promise<{
            readonly state: OperationState;
            readonly attempt: SignedAttempt;
        } | null>;
        wait(operationId: string, options?: {
            readonly author?: string;
            readonly signal?: AbortSignal;
        }): Promise<AppliedResult>;
    };
    constructor(options: {
        readonly replica: PeerReplica;
        readonly definition: D;
        readonly storage: ApplicationStorage;
        readonly content: ApplicationContent;
        readonly keys: ApplicationKeyring;
        readonly session: ApplicationSession<D>;
        readonly submit: (attempt: SignedAttempt) => Promise<void>;
        readonly adoptAuthority: (authority: AuthorityBundle) => Promise<void>;
    });
    get replica(): PeerReplica;
    get applicationId(): string;
    get historyId(): string;
    command<Name extends keyof D['commands'] & string>(name: Name, input: CommandArguments<D['commands'][Name]>, options: CommandOptions): Promise<ApplicationOperation>;
    submitProgramAs(program: ChangeProgram, author: PeerIdentity, options: CommandOptions): Promise<ApplicationSubmission>;
    reapply<Name extends keyof D['commands'] & string>(operationId: string, name: Name, input: CommandArguments<D['commands'][Name]>, options: CommandOptions & {
        readonly originalAuthor?: string;
    }): Promise<ApplicationOperation>;
    query<Name extends keyof D['queries'] & string>(name: Name, input: QueryArguments<D['queries'][Name]>): Promise<{
        readonly revision: PeerRevision;
        readonly value: QueryResult<D['queries'][Name]>;
    }>;
    readView(): Promise<ApplicationReadView>;
    onRecovery(listener: (notice: RecoveryNotice) => void): () => void;
    inspectRecovery(): readonly RecoveryNotice[];
    recoveryPoint(): Promise<PrefixProof>;
    adopt(authority: AuthorityBundle): Promise<RecoveryNotice | null>;
    /** Compact older history records and abandoned generations, optionally retaining a summary command first. */
    compact(options?: HistoryCompactionOptions & {
        readonly summarize?: (events: readonly ApplicationEvent[]) => ChangeProgram | null | Promise<ChangeProgram | null>;
        readonly operationId?: string;
        readonly signal?: AbortSignal;
    }): Promise<HistoryCompactionResult>;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
    /** Register a pure reducer in the owning Worker or native session. */
    project<State extends EventPayload>(definition: ApplicationProjectionDefinition<State>): ApplicationProjection<State>;
    /** Read a registered projection without moving reducer callbacks across a transport. */
    projection<State extends EventPayload = EventPayload>(id: string): ApplicationProjectionHandle<State>;
    retry(operationId: string, author?: string): Promise<void>;
    resume(): Promise<void>;
    waitFor(operationId: string, options?: {
        readonly author?: string;
        readonly signal?: AbortSignal;
    }): Promise<AppliedResult>;
    waitForCoverage(applied: AppliedResult, options?: {
        readonly signal?: AbortSignal;
    }): Promise<readonly SignedRetainedCoverage[]>;
    close(reason?: Error): Promise<void>;
}
/** Called exactly once, on the participant's first durable operation. */
export declare function openApplicationData<const D extends ApplicationDefinition>(options: OpenPeerApplicationOptions<D> & {
    readonly session: ApplicationSession<D>;
    readonly authority: AuthorityBundle;
    readonly submit: (attempt: SignedAttempt) => Promise<void>;
    readonly adoptAuthority: (authority: AuthorityBundle) => Promise<void>;
}): Promise<ApplicationData<D>>;
export {};
