import { type ApplicationOwnerHandshake, type ApplicationEndpointBinding, type ApplicationEndpointState } from './owner-types.js';
import type { AuthorityBundle, AppliedResult, OperationState, PeerRevision, PrefixProof, RecoveryNotice, SignedAttempt, SignedRetainedCoverage } from '../../peer-generation/src/index.js';
import type { Signals } from '../../signals/src/index.js';
import type { EventPayload } from '../../protocol/src/index.js';
import type { ApplicationCommand, ApplicationDefinition, ApplicationQuery } from './definition.js';
import type { ContentReference, ContentRetention, ContentUpload } from './content.js';
import { type ContentPutBytesOptions, type ContentReadBytesOptions } from './content-bytes.js';
import type { ApplicationRecoveryExpectation, ApplicationTransition } from './recovery.js';
import type { ApplicationChange, ApplicationEventBatch, ApplicationEventOptions, CommandOptions, QueryParameter, QueryRows, SessionStatus } from './session-types.js';
import type { ApplicationParticipation } from './participation-types.js';
import type { ApplicationProjectionHandle } from './projection-types.js';
import { type Endpoint, type Description, type Metadata } from './worker-application-protocol.js';
type CommandArguments<T> = T extends ApplicationCommand<infer I> ? I : never;
type QueryArguments<T> = T extends ApplicationQuery<infer I, unknown, never> ? I : never;
type QueryResult<T> = T extends ApplicationQuery<never, infer R, never> ? Awaited<R> : never;
/** Captured SQL/events stay in the Worker until explicitly released. */
export interface WorkerApplicationReadView {
    readonly revision: PeerRevision;
    query(sql: string, parameters?: readonly QueryParameter[]): Promise<QueryRows>;
    readEvents(options?: ApplicationEventOptions): Promise<ApplicationEventBatch>;
    release(): Promise<void>;
}
/** A saved operation remains in the owning Worker when its page stops waiting. */
export interface WorkerApplicationOperation {
    readonly operationId: string;
    get(): Promise<OperationState | null>;
    applied(options?: {
        readonly signal?: AbortSignal;
    }): Promise<AppliedResult>;
    retry(): Promise<void>;
    shared(options?: {
        readonly signal?: AbortSignal;
    }): Promise<readonly SignedRetainedCoverage[]>;
}
/** Page-facing facade; the Worker owns signing keys, durable work and projections. */
export declare class WorkerApplicationSession<D extends ApplicationDefinition = ApplicationDefinition> {
    #private;
    readonly applicationId: string;
    readonly historyId: string;
    readonly deviceId: string;
    readonly storageId: string;
    readonly endpoint: ApplicationEndpointBinding | undefined;
    readonly capabilities: Description['capabilities'];
    readonly participation: ApplicationParticipation | undefined;
    readonly operations: {
        get: (id: string, options?: {
            readonly author?: string;
        }) => Promise<OperationState | null>;
        inspect: (id: string, options?: {
            readonly author?: string;
        }) => Promise<{
            readonly state: OperationState;
            readonly attempt: SignedAttempt;
        } | null>;
        wait: (id: string, options?: {
            readonly author?: string;
            readonly signal?: AbortSignal;
        }) => Promise<AppliedResult>;
    };
    readonly recovery: {
        inspect: () => Promise<readonly ApplicationTransition[]>;
        takeover: (options?: {
            readonly coordinator?: string;
            readonly transitionId?: string;
            readonly expected?: ApplicationRecoveryExpectation;
            readonly signal?: AbortSignal;
        }) => Promise<RecoveryNotice | null>;
        handover: (options: {
            readonly coordinator: string;
            readonly transitionId?: string;
            readonly signal?: AbortSignal;
        }) => Promise<RecoveryNotice | null>;
    };
    readonly signals: Signals;
    readonly content: {
        putBytes: (bytes: Uint8Array, options?: ContentPutBytesOptions) => Promise<ContentReference>;
        readBytes: (reference: ContentReference, options: ContentReadBytesOptions) => Promise<Uint8Array>;
        prune: (reference: ContentReference) => Promise<void>;
        stage: (options: {
            readonly bytes: number;
            readonly mediaType?: string;
        }) => Promise<ContentUpload>;
        resume: (id: string) => Promise<ContentUpload>;
        discard: (id: string) => Promise<void>;
        read: (reference: ContentReference, options?: {
            readonly offset?: number;
            readonly length?: number;
            readonly signal?: AbortSignal;
        }) => AsyncIterable<Uint8Array>;
        retain: (reference: ContentReference, options?: {
            readonly signal?: AbortSignal;
        }) => Promise<ContentRetention>;
        retained: (reference: ContentReference) => Promise<ContentRetention>;
        retention: (reference: ContentReference) => Promise<readonly ContentRetention[]>;
    };
    /** Construct through connectApplicationWorker so readiness is authenticated to the owned port. */
    constructor(port: MessagePort, metadata: Metadata, timeoutMs: number, signal?: AbortSignal);
    /** Oldest finite facade call, in this realm's performance.now() clock.
     * Passive stream/operation waits never count. This is a caller deadline,
     * not evidence that the owner received or began executing the request.
     */
    get boundedRequest(): {
        readonly startedAt: number;
        readonly deadline: number;
    } | null;
    get signal(): AbortSignal;
    get status(): SessionStatus;
    get revision(): PeerRevision | null;
    describe(): Description;
    authority(): Promise<AuthorityBundle>;
    onStatus(listener: (status: SessionStatus) => void): () => void;
    onRecovery(listener: (notice: RecoveryNotice) => void): () => void;
    command<Name extends keyof D['commands'] & string>(name: Name, input: CommandArguments<D['commands'][Name]>, options: CommandOptions): Promise<WorkerApplicationOperation>;
    reapply<Name extends keyof D['commands'] & string>(id: string, name: Name, input: CommandArguments<D['commands'][Name]>, options: CommandOptions & {
        readonly originalAuthor?: string;
    }): Promise<WorkerApplicationOperation>;
    query<Name extends keyof D['queries'] & string>(name: Name, input: QueryArguments<D['queries'][Name]>): Promise<{
        readonly revision: PeerRevision;
        readonly value: QueryResult<D['queries'][Name]>;
    }>;
    retry(id: string): Promise<void>;
    resume(): Promise<void>;
    inspectRecovery(): Promise<readonly RecoveryNotice[]>;
    recoveryPoint(): Promise<PrefixProof>;
    adopt(authority: AuthorityBundle): Promise<RecoveryNotice | null>;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
    projection<State extends EventPayload = EventPayload>(id: string): ApplicationProjectionHandle<State>;
    readView(): Promise<WorkerApplicationReadView>;
    /** Detach cancels this endpoint's observation only; the owner's journal survives. */
    detach(): Promise<void>;
    suspend(): Promise<void>;
    resumeAttachment(): Promise<ApplicationEndpointBinding | null>;
    endpoints(): Promise<readonly (ApplicationEndpointBinding & {
        readonly state: ApplicationEndpointState;
    })[]>;
    close(): Promise<void>;
}
/** Connect to a ready Worker without exposing or transferring its signing keys. */
export declare function connectApplicationWorker<D extends ApplicationDefinition = ApplicationDefinition>(endpoint: Endpoint, options?: {
    readonly signal?: AbortSignal;
    readonly timeoutMs?: number;
}): Promise<WorkerApplicationSession<D>>;
/** Attach to an existing owner without opening a signer store or creating a session. */
export declare function connectApplicationOwner<D extends ApplicationDefinition = ApplicationDefinition>(endpoint: Endpoint, options: ApplicationOwnerHandshake & {
    readonly signal?: AbortSignal;
    readonly timeoutMs?: number;
}): Promise<WorkerApplicationSession<D>>;
export {};
