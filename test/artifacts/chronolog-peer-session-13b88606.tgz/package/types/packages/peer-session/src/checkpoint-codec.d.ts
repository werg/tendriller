import type { CheckpointMetadata, CheckpointOutboxRecord } from './checkpoint.js';
export declare function deriveAesKey(secret: Uint8Array | string, salt: Uint8Array, usage: readonly KeyUsage[], iterations?: number): Promise<CryptoKey>;
export declare function validateMetadata(metadata: CheckpointMetadata, outbox: readonly CheckpointOutboxRecord[]): void;
