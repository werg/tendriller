import { type AuthorityBundle, type PeerIdentity } from '../../peer-generation/src/control.js';
import type { CelldPeerEndpoint } from './celld-peer.js';
import type { ApplicationDevice } from './device.js';
import type { ApplicationPeerHint } from './participation-types.js';
interface InvitationPayload {
    readonly version: 1;
    readonly memberPublicKey: string;
    readonly inviterPublicKey: string;
    readonly generation: string;
    readonly endpoint: CelldPeerEndpoint;
    readonly authority: AuthorityBundle;
}
export interface CelldApplicationInvitation {
    readonly payload: InvitationPayload;
    readonly signature: string;
}
export interface AcceptedCelldApplicationInvitation {
    readonly authority: AuthorityBundle;
    readonly peer: ApplicationPeerHint;
    readonly endpoint: CelldPeerEndpoint;
}
export declare function validateCelldPeerEndpoint(endpoint: CelldPeerEndpoint): void;
/** Seal a route for a member already admitted by the selected signed control record. */
export declare function signCelldApplicationInvitation(input: {
    readonly authority: AuthorityBundle;
    readonly memberPublicKey: string;
    readonly endpoint: CelldPeerEndpoint;
    readonly inviter: PeerIdentity;
}): Promise<CelldApplicationInvitation>;
/** Persist the admitted authority anchor before connecting to the authenticated peer. */
export declare function acceptCelldApplicationInvitation(device: ApplicationDevice, invitation: CelldApplicationInvitation): Promise<AcceptedCelldApplicationInvitation>;
export {};
