import type { ApplicationSession } from './session.js';
import { type ApplicationOwnerOptions, type ApplicationSessionOwner } from './owner-types.js';
export * from './owner-types.js';
/** One protocol/session/journal owner, with isolated attachment lifetimes and quotas. */
export declare function createApplicationOwner(session: ApplicationSession, options?: ApplicationOwnerOptions): ApplicationSessionOwner;
