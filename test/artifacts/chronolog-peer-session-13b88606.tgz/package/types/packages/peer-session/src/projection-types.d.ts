import type { PeerRevision } from '../../peer-generation/src/index.js';
import type { EventPayload } from '../../protocol/src/index.js';
import type { ApplicationEvent } from './session-types.js';
export declare const APPLICATION_PROJECTION_LIMITS: Readonly<{
    active: 8;
    pending: 8;
    stateBytes: 524288;
    checkpointBytes: 2097152;
}>;
/** A local derived view. Reducers may replay after recovery and must have no external effects. */
export interface ApplicationProjectionDefinition<State extends EventPayload> {
    readonly id: string;
    readonly version: string;
    readonly topics?: readonly string[];
    readonly initial: State;
    readonly reduce: (state: State, event: ApplicationEvent) => State;
}
export interface ApplicationProjectionReset {
    readonly reason: 'recovery' | 'definition';
    readonly previousRevision: PeerRevision;
}
export interface ApplicationProjectionSnapshot<State extends EventPayload = EventPayload> {
    readonly revision: PeerRevision;
    readonly state: State;
    readonly reset: ApplicationProjectionReset | null;
}
export interface ApplicationProjectionHandle<State extends EventPayload = EventPayload> {
    readonly id: string;
    read(options?: {
        readonly signal?: AbortSignal;
    }): Promise<ApplicationProjectionSnapshot<State>>;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationProjectionSnapshot<State>>;
    close(): Promise<void>;
}
