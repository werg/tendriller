import type { PeerRevision, RecoveryNotice } from '../../peer-generation/src/index.js';
import type { ApplicationChange, SessionStatus } from './session-types.js';
export interface LiveViewSnapshot<Value = unknown> {
    readonly revision: PeerRevision;
    readonly value: Value;
}
export interface LiveViewSession<Name extends string = string, Input = unknown, Value = unknown> {
    readonly signal?: AbortSignal;
    query(name: Name, input: Input): Promise<LiveViewSnapshot<Value>>;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
    onStatus(listener: (status: SessionStatus) => void): () => void;
    onRecovery(listener: (notice: RecoveryNotice) => void): () => void;
}
export interface LiveViewOptions<Name extends string = string, Input = unknown, Value = unknown> {
    readonly query: Name;
    readonly input?: Input;
    readonly onSnapshot?: (snapshot: LiveViewSnapshot<Value>) => void;
    readonly onStatus?: (status: SessionStatus) => void;
    readonly onRecovery?: (notice: RecoveryNotice) => void;
    readonly onError?: (error: unknown) => void;
    readonly signal?: AbortSignal;
}
export interface LiveView<Value = unknown> {
    readonly snapshot: LiveViewSnapshot<Value> | null;
    readonly status: SessionStatus | null;
    readonly error: unknown;
    refresh(): Promise<LiveViewSnapshot<Value>>;
    ready(options?: {
        readonly signal?: AbortSignal;
        readonly timeoutMs?: number;
    }): Promise<LiveViewSnapshot<Value>>;
    subscribe(listener: (snapshot: LiveViewSnapshot<Value>) => void): () => void;
    close(): void;
}
/**
 * Reactive coherent query observer over any native or Worker peer session.
 * Owns only subscription invalidation, never storage, transport or identity.
 */
export declare function createLiveView<Name extends string, Input = null, Value = unknown>(session: LiveViewSession<Name, Input, Value>, options: LiveViewOptions<NoInfer<Name>, NoInfer<Input>, NoInfer<Value>>): LiveView<Value>;
