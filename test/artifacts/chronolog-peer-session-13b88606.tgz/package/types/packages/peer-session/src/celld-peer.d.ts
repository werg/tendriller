import { type FramedPeerConnection } from '../../records/src/index.js';
import type { ApplicationPeerHint, ApplicationTransportPort } from './participation-types.js';
export interface CelldPeerStream {
    readonly readable: ReadableStream<Uint8Array>;
    readonly writable: WritableStream<Uint8Array>;
    readonly remoteNodeId: string;
    readonly alpn?: string;
    readonly closed: Promise<void>;
    close(): Promise<void>;
}
/** Carry a peer session on an object-owned celld stream. The session authenticates its application peer. */
export declare function frameCelldPeerStream(stream: CelldPeerStream): FramedPeerConnection;
export interface CelldPeerEndpoint {
    readonly nodeId: string;
    readonly addrs?: readonly string[];
    readonly relay?: string;
}
export interface CelldPeerBinding {
    connect(nodeId: string, options?: {
        addrs?: string[];
        relay?: string;
    }): Promise<CelldPeerStream>;
}
/** Use the application's admitted endpoint directory for both outgoing and handed-off streams. */
export declare function createCelldPeerTransport(options: {
    readonly binding: CelldPeerBinding;
    readonly resolveEndpoint: (peer: ApplicationPeerHint, signal: AbortSignal) => Promise<CelldPeerEndpoint>;
    readonly takeInvitation: (peer: ApplicationPeerHint, invitation: unknown, signal: AbortSignal) => Promise<CelldPeerStream>;
}): ApplicationTransportPort;
