import type { BytesStore } from '../../records/src/index.js';
/** Preserve one monotonic metadata record across async verification and tabs. */
export declare function updateDeviceMetadata(store: BytesStore, key: string, update: (current: Uint8Array | null) => Promise<Uint8Array>): Promise<Uint8Array>;
