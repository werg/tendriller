import { type CelldBytesStorage, type CelldBytesStoreOptions } from '../../records/src/celld.js';
import type { PeerIdentity } from '../../peer-generation/src/control.js';
import { type ApplicationDevice } from './device.js';
export { openPeerApplication as openCelldApplication } from './runtime.js';
export type { OpenPeerApplicationOptions } from './runtime.js';
export { openCelldApplicationControl, type CelldApplicationControl } from './celld-control.js';
export { createCelldPeerTransport, frameCelldPeerStream, type CelldPeerBinding, type CelldPeerEndpoint, type CelldPeerStream, } from './celld-peer.js';
export { acceptCelldApplicationInvitation, signCelldApplicationInvitation, type CelldApplicationInvitation, type AcceptedCelldApplicationInvitation, } from './celld-invitation.js';
export { signCelldWorkspacePublication, verifyCelldWorkspacePublication, type CelldWorkspacePublication, type SignedCelldWorkspacePublication, } from './celld-workspace-publication.js';
export { CelldBytesStore, type CelldBytesStorage, type CelldBytesStoreOptions } from '../../records/src/celld.js';
/** Import a per-class secret against the public key admitted by the host. */
export declare function importCelldSigningIdentity(publicKey: string, pkcs8Hex: string | undefined): Promise<PeerIdentity>;
/** Open one device under its celld object, optionally using a SQLite facet for application data. */
export declare function openCelldDevice(options: {
    readonly storage: CelldBytesStorage;
    readonly create?: true;
    readonly managedSigner?: PeerIdentity;
    readonly metadataLimits?: CelldBytesStoreOptions;
    readonly dataLimits?: CelldBytesStoreOptions;
    readonly openDataStorage?: () => CelldBytesStorage;
}): Promise<ApplicationDevice>;
export { celldDoltPublicationPeer, serveCelldDoltPublication, type CelldDoltPublicationGrant, } from './celld-dolt-carrier.js';
