import type { ApplicationAttachmentPolicy, ApplicationEndpointBinding, ApplicationEndpointState } from './owner-types.js';
import type { ApplicationSession } from './session.js';
import type { ApplicationControlHost } from './recovery.js';
import { type Endpoint } from './worker-application-protocol.js';
export interface ApplicationWorkerServerOptions extends ApplicationAttachmentPolicy {
    readonly host?: ApplicationControlHost;
    readonly closeSession?: boolean;
    readonly initialPort?: MessagePort;
    readonly binding?: ApplicationEndpointBinding;
    readonly prepareCommand?: (endpoint: ApplicationEndpointBinding, name: string, input: unknown) => unknown;
    readonly reserve?: (kind: 'requests' | 'streams' | 'views') => () => void;
    readonly onClose?: () => void;
    readonly onState?: (state: ApplicationEndpointState) => void;
    readonly listEndpoints?: () => unknown;
    readonly shutdown?: () => Promise<void>;
}
/**
 * Serve one page facade beside the owned application. A dedicated port isolates
 * application RPC from RTC handoff and application-owned UI messages. The same
 * pull/cancel contract keeps streams bounded within that one owner.
 */
export declare function serveApplicationWorker(session: ApplicationSession, endpoint: Endpoint, options?: ApplicationWorkerServerOptions): {
    close(): Promise<void>;
};
