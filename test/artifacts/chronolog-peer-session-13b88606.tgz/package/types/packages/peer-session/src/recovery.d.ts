import type { BytesStore } from '../../records/src/index.js';
import { type AuthorityBundle, type PeerReplica, type RecoveryNotice, type HistoryPoint, type SignedGeneration, type SignedTransitionRequest } from '../../peer-generation/src/index.js';
/** The small hosted control port. Calls occur only at explicit lifecycle boundaries. */
export interface ApplicationControlHost {
    application(options?: {
        readonly signal?: AbortSignal;
    }): Promise<AuthorityBundle>;
    /** A lost generation CAS rejects with code `peer_generation_conflict`.
     * Other failures preserve the saved request for an exact retry. Messages are
     * diagnostic only; transport adapters must preserve or map the typed code. */
    selectGeneration(request: SignedTransitionRequest, options?: {
        readonly signal?: AbortSignal;
    }): Promise<SignedGeneration>;
}
/** A displayed recovery choice cannot silently cross a changed authority or prefix. */
export interface ApplicationRecoveryExpectation {
    /** Current selected generation used by the control CAS; the usable point may belong to an ancestor. */
    readonly generation: string;
    readonly controlRevision: number;
    readonly point: HistoryPoint;
}
export { ApplicationControlConflictError } from './errors.js';
export interface ApplicationTransition {
    readonly request: SignedTransitionRequest;
    readonly selected: string | null;
    readonly superseded: boolean;
}
/** Exact transition retries use the same durable device journal as ordinary work. */
export declare class ApplicationRecovery {
    #private;
    constructor(options: {
        readonly replica: PeerReplica;
        readonly store: BytesStore;
        readonly signal: AbortSignal;
        readonly adoptAuthority: (authority: AuthorityBundle) => Promise<void>;
    });
    inspect(): Promise<readonly ApplicationTransition[]>;
    /** Select this device's complete usable prefix after the caller's reconnect grace policy. */
    takeover(host: ApplicationControlHost, options?: {
        readonly coordinator?: string;
        readonly transitionId?: string;
        readonly signal?: AbortSignal;
        readonly expected?: ApplicationRecoveryExpectation;
    }): Promise<RecoveryNotice | null>;
    /** Planned retirement requires the successor's signed retention of the exact current prefix. */
    handover(host: ApplicationControlHost, options: {
        readonly coordinator: string;
        readonly transitionId?: string;
        readonly signal?: AbortSignal;
    }): Promise<RecoveryNotice | null>;
    /** Fence new work and finish local journal work without waiting for a remote reply. */
    close(): Promise<void>;
}
