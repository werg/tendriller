import type { HistoryPoint, OperationState, PeerRevision, TransitionReason } from '../../peer-generation/src/index.js';
export declare class AbandonedOperationError extends Error {
    readonly operation: Extract<OperationState, {
        status: 'abandoned' | 'needsReapply';
    }>;
    constructor(operation: Extract<OperationState, {
        status: 'abandoned' | 'needsReapply';
    }>);
}
/** Selected-transition evidence only; never a claim that an old cursor is safe. */
export interface ApplicationRecoveryEvidence {
    readonly reason: TransitionReason | null;
    readonly adopted: HistoryPoint | null;
    readonly unknownLoss: boolean;
}
export declare class RecoveredViewError extends Error {
    readonly revision: PeerRevision;
    readonly code: "APPLICATION_VIEW_RECOVERED";
    readonly recovery: ApplicationRecoveryEvidence | null;
    constructor(revision: PeerRevision, recovery?: ApplicationRecoveryEvidence | null);
}
/** The portable control-port conflict; adapters may preserve an equivalent typed error. */
export declare class ApplicationControlConflictError extends Error {
    readonly code: "peer_generation_conflict";
    constructor(message?: string, options?: ErrorOptions);
}
