import type { BytesStore } from '../../records/src/index.js';
import { type CheckpointMetadata, type CheckpointOutboxRecord } from './checkpoint.js';
export declare const STREAM_CHECKPOINT_FORMAT = "chronolog-device-checkpoint-v2";
export interface CheckpointLimits {
    /** Optional application budget; streaming has no fixed aggregate size or entry cap. */
    readonly maxBytes?: number;
    readonly maxEntries?: number;
    /** A BytesStore value is yielded as one buffer; use this budget for untrusted imports. */
    readonly maxValueBytes?: number;
}
export interface CheckpointSink {
    write(bytes: Uint8Array): void | Promise<void>;
    /** Resolve only after every written byte is durable. */
    commit(metadata: CheckpointMetadata): void | Promise<void>;
    abort?(reason: unknown): void | Promise<void>;
}
export interface ExportCheckpointStreamOptions {
    readonly secret: Uint8Array | string;
    readonly sink: CheckpointSink;
    readonly applicationId?: string | null;
    readonly deviceId?: string | null;
    readonly outbox?: readonly CheckpointOutboxRecord[];
    readonly retireSource?: boolean;
    readonly limits?: CheckpointLimits;
    readonly sqlDatabase?: {
        readonly bytes: number;
        readonly chunks: AsyncIterable<Uint8Array>;
    };
}
export interface RestoreCheckpointStreamOptions {
    readonly secret: Uint8Array | string;
    readonly limits?: CheckpointLimits;
    /** Stage SQL outside memory. commit is called only after the complete input authenticates. */
    readonly sqlSink?: CheckpointSink;
}
/** Stream authenticated binary frames; durable sink commit precedes source retirement. */
export declare function exportDeviceCheckpointStream(store: BytesStore, options: ExportCheckpointStreamOptions): Promise<{
    readonly metadata: CheckpointMetadata;
    readonly retiredSource: boolean;
}>;
/** Authenticates the footer before atomic target publication; failed imports leave no identity. */
export declare function restoreDeviceCheckpointStream(target: BytesStore, source: AsyncIterable<Uint8Array>, options: RestoreCheckpointStreamOptions): Promise<{
    readonly metadata: CheckpointMetadata;
    readonly restoredEntries: number;
    readonly sqlDatabaseBytes: Uint8Array | null;
    readonly outbox: readonly CheckpointOutboxRecord[];
}>;
