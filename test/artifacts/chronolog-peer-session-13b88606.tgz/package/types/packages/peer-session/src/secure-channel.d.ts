import type { FramedPeerConnection } from '../../records/src/index.js';
export declare const APPLICATION_CHANNEL_SUITE: "DHKEM(X25519,HKDF-SHA256)/HKDF-SHA256/AES-256-GCM/peer-record-v1";
export declare const APPLICATION_CHANNEL_LIMITS: Readonly<{
    overheadBytes: 22;
    records: number;
    plaintextBytes: number;
}>;
export interface ApplicationChannelHello {
    readonly suite: typeof APPLICATION_CHANNEL_SUITE;
    readonly receiverKey: string;
}
/**
 * Transport-independent channel beneath the single application wire. Public
 * hello/proof messages establish fresh keys; every following record is encrypted.
 * Ed25519 proof verification is owned by NetworkPeer, before accepting an export.
 */
export declare class ApplicationSecureChannel {
    #private;
    readonly connection: FramedPeerConnection;
    constructor(raw: FramedPeerConnection, signal: AbortSignal);
    hello(): Promise<ApplicationChannelHello>;
    prepare(peerReceiverKey: string, sender: unknown, receiver: unknown): Promise<string>;
    /** Called only when every public proof fragment has been dispatched. */
    enableSending(): void;
    accept(encapsulatedKey: string, sender: unknown, receiver: unknown): Promise<void>;
    clear(): void;
}
