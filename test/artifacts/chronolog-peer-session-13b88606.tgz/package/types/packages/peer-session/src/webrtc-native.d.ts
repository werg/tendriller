import { type NativeRtcOptions } from '../../transport-webrtc/src/native.js';
import type { ApplicationSession } from './session.js';
import { type WebRtcOptions } from './webrtc.js';
export { createNativePeerConnection, type NativeRtcOptions } from '../../transport-webrtc/src/native.js';
/** Node RTC adapter included in the standard archive with its exact Werift dependency. */
export declare function connectNativeApplicationWebRtc(session: ApplicationSession, options: Omit<WebRtcOptions, 'createPeerConnection'> & {
    readonly peerIdentity?: string;
    readonly native?: NativeRtcOptions;
}): Promise<import("./network.js").ApplicationPeerLink & {
    readonly rtc: import("../../transport-webrtc/src/index.js").WebRtcSession;
}>;
