import { type AuthorityBundle, type PeerIdentity } from '../../peer-generation/src/control.js';
/** The exact canonical ref transition between two authenticated workspace nodes. */
export interface CelldWorkspacePublication {
    readonly sourceNodeId: string;
    readonly destinationNodeId: string;
    readonly workspaceId: string;
    readonly previousHead: string;
    readonly proposedHead: string;
}
interface WorkspacePublicationPayload extends CelldWorkspacePublication {
    readonly version: 1;
    readonly applicationId: string;
    readonly generation: string;
    readonly publisherPublicKey: string;
}
export interface SignedCelldWorkspacePublication {
    readonly payload: WorkspacePublicationPayload;
    readonly signature: string;
}
/** Sign one named workspace's main transition as a publisher in the selected generation. */
export declare function signCelldWorkspacePublication(input: {
    readonly authority: AuthorityBundle;
    readonly transition: CelldWorkspacePublication;
    readonly publisher: PeerIdentity;
}): Promise<SignedCelldWorkspacePublication>;
/** Verify against the receiver's selected authority and independently reviewed heads. */
export declare function verifyCelldWorkspacePublication(input: {
    readonly authority: AuthorityBundle;
    readonly transition: CelldWorkspacePublication;
    readonly publication: SignedCelldWorkspacePublication;
}): Promise<string>;
export {};
