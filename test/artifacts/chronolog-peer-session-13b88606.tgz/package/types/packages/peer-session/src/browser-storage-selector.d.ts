import type { ApplicationStorage } from './device.js';
import type { BrowserMetadataStore } from './browser-metadata.js';
/** Select once under the same exclusive lock that owns every subsequent record write. */
export declare function openSelectedBrowserStorage(name: string, metadata: BrowserMetadataStore): Promise<ApplicationStorage>;
