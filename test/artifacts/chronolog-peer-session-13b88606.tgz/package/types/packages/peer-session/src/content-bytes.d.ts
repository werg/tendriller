import type { ContentReference, ContentUpload } from './content.js';
export declare const CONTENT_CHUNK_BYTES = 65536;
export declare const MAX_CONTENT_BYTES: number;
export interface ContentPutBytesOptions {
    readonly mediaType?: string;
    readonly signal?: AbortSignal;
}
export interface ContentReadBytesOptions {
    readonly maxBytes: number;
    readonly signal?: AbortSignal;
}
interface ByteContent {
    stage(options: {
        readonly bytes: number;
        readonly mediaType?: string;
    }): Promise<ContentUpload>;
    read(reference: ContentReference, options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<Uint8Array>;
}
/** Shared by the native owner and the page facade; Worker messages stay one chunk each. */
export declare function putContentBytes(content: Pick<ByteContent, 'stage'>, bytes: Uint8Array, options?: ContentPutBytesOptions): Promise<ContentReference>;
/** Allocate once, before fetching, under the caller's explicit byte ceiling. */
export declare function readContentBytes(content: Pick<ByteContent, 'read'>, reference: ContentReference, options: ContentReadBytesOptions): Promise<Uint8Array>;
export {};
