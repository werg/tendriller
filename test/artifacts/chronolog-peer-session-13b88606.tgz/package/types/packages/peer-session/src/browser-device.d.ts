import { type ApplicationDevice } from './device.js';
/** Open the protocol identity in its Worker; application files remain unopened. */
export declare function openBrowserDevice(options: {
    readonly name: string;
    readonly create?: true;
}): Promise<ApplicationDevice>;
