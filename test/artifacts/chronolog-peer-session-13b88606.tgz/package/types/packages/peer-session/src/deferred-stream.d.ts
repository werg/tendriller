/** Lazy acquisition preserves the underlying stream's cancellation and pull bound. */
export declare function deferredStream<T>(open: (signal: AbortSignal) => Promise<AsyncIterable<T>>, options: {
    readonly signal: AbortSignal;
    readonly concurrentNextError: string;
    readonly abort: 'done' | 'throw';
}): AsyncIterable<T>;
