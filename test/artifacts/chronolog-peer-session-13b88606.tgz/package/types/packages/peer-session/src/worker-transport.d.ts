import { type RtcPeerConnection, type WebRtcOptions, type WebRtcRoute } from '../../transport-webrtc/src/index.js';
import type { FramedPeerConnection } from '../../records/src/index.js';
/** Ordered, authenticated endpoint: Worker, started SharedWorker port, or a virtual endpoint.
 * The RTC bridge calls postMessage with one argument only; it transfers no resources.
 * Optional transfer is used by the separate application-RPC API, not this protocol. */
export interface ApplicationWorkerEndpoint {
    postMessage(message: unknown, transfer?: Transferable[]): void;
    addEventListener(type: 'message', listener: (event: MessageEvent) => void): void;
    removeEventListener(type: 'message', listener: (event: MessageEvent) => void): void;
}
export interface WorkerWebRtcConnection extends FramedPeerConnection {
    getRoute(): Promise<WebRtcRoute>;
}
/** Page-side RTC and raw framing only. Peer crypto, keys and state stay in the owner.
 * Opaque frames use bounded multiplexed messages; no RTCDataChannel/MessagePort transfer. */
export declare function serveWorkerWebRtcConnections(endpoint: ApplicationWorkerEndpoint, options?: {
    readonly createPeerConnection?: (configuration: RTCConfiguration) => RtcPeerConnection;
    readonly signal?: AbortSignal;
}): {
    close(): Promise<void>;
};
/** Owner-side framed connection. Only bounded signaling and opaque peer frames cross the endpoint. */
export declare function openWorkerWebRtcConnection(endpoint: ApplicationWorkerEndpoint, options: Omit<WebRtcOptions, 'createPeerConnection'>): Promise<WorkerWebRtcConnection>;
