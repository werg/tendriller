import { type AuthorityBundle, type PeerReplica, type Signed } from '../../peer-generation/src/index.js';
import type { ApplicationDevice } from './device.js';
export type ApplicationKeyRequest = Signed<{
    readonly applicationId: string;
    readonly historyId: string;
    readonly generation: string;
    readonly controlDigest: string;
    readonly recipient: string;
    readonly receiverKey: string;
    readonly nonce: string;
    readonly epochs: readonly number[];
}>;
export type ApplicationKeyShare = Signed<{
    readonly requestDigest: string;
    readonly issuer: string;
    readonly keys: readonly {
        readonly epoch: number;
        readonly encapsulatedKey: string;
        readonly ciphertext: string;
    }[];
}>;
/** Durable enrolled keys, with peer exchange independent of command retry and host storage. */
export declare class ApplicationKeyring {
    #private;
    private constructor();
    static open(options: {
        readonly device: ApplicationDevice;
        readonly authority: AuthorityBundle;
        readonly epochKeys?: ReadonlyMap<number, Uint8Array>;
    }): Promise<ApplicationKeyring>;
    /** This live read-only port is shared by the replica and encrypted content owner. */
    get epochKeys(): ReadonlyMap<number, Uint8Array>;
    bind(replica: PeerReplica): void;
    missing(requiredEpochs?: readonly number[]): readonly number[];
    validate(): Promise<void>;
    subscribe(listener: () => void): () => void;
    /** Maintained peer transports supply key sources; content can acquire older epochs lazily. */
    attachSource(peerId: string, offer: (request: ApplicationKeyRequest) => Promise<ApplicationKeyShare>): () => void;
    ensure(requiredEpochs?: readonly number[]): Promise<void>;
    /** Explicit bootstrap/rotation input must match already authenticated control commitments. */
    install(input: ReadonlyMap<number, Uint8Array>): Promise<void>;
    /** A fresh ephemeral HPKE receiver is bound to the actual device's signed request. */
    request(requiredEpochs?: readonly number[]): Promise<{
        readonly request: ApplicationKeyRequest;
        accept(share: ApplicationKeyShare): Promise<void>;
        cancel(): void;
    } | null>;
    /** Any current reader holding the committed key can enroll another granted reader. */
    offer(request: ApplicationKeyRequest): Promise<ApplicationKeyShare>;
    close(): Promise<void>;
}
