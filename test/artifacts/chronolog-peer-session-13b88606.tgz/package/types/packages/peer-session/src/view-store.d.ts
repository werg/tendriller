export declare class SessionError extends Error {
    readonly code: string;
    readonly scope: Readonly<Record<string, unknown>>;
    readonly retrySafe: boolean;
    readonly nextAction: string;
    constructor(code: string, message?: string, scope?: Readonly<Record<string, unknown>>, actions?: Readonly<Record<string, string>>);
}
export declare function identifier(value: unknown, name?: string): string;
export declare function signerId(value: unknown): string;
export declare function canonicalJson(value: unknown, maxBytes?: number): string;
export interface OperationReference {
    readonly applicationId: string;
    readonly historyId: string;
    readonly author: string;
    readonly operationId: string;
    readonly attemptId?: string;
    readonly generation?: string;
}
export interface RetainedOperation {
    readonly reference: OperationReference;
    readonly viewId: string;
    readonly context: Readonly<Record<string, unknown>>;
}
export interface ViewStorage {
    readonly length: number;
    key(index: number): string | null;
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
export interface ViewStore<Draft = unknown> {
    readonly viewId: string;
    readonly historyId?: string;
    readDraft(draftId?: string): Draft | null;
    writeDraft(value: Draft, draftId?: string): void;
    removeDraft(draftId?: string): void;
    retainOperation(reference: OperationReference, context?: Record<string, unknown>): RetainedOperation;
    inspectOperation(reference: OperationReference): RetainedOperation | null;
    removeOperation(reference: OperationReference): void;
    pending(options?: {
        readonly allViews?: boolean;
    }): readonly RetainedOperation[];
}
export declare function operationReference(session: {
    readonly applicationId?: string;
    readonly id?: string;
    readonly historyId?: string;
    readonly deviceId: string;
    readonly scopeOperationId?: (localOperationId: string) => string;
}, operationId: string, state?: {
    readonly operationId?: string;
    readonly author?: string;
    readonly attemptId?: string;
    readonly generation?: string;
} | null): OperationReference;
/** Per-key writes avoid a shared read/modify/write list that loses sibling references. */
export declare function createViewStore<Draft = unknown>(options: {
    readonly storage: ViewStorage;
    readonly applicationId: string;
    readonly historyId?: string;
    readonly profileId: string;
    readonly viewId: string;
}): ViewStore<Draft>;
