/** Stop this owner's wait without claiming that an already started effect was cancelled. */
export declare function awaitOwnedTask<T>(signal: AbortSignal, call: () => T | PromiseLike<T>): Promise<T>;
