import type { BytesStore } from '../../records/src/index.js';
import { type EventPayload } from '../../protocol/src/index.js';
import { type ApplicationChange, type ApplicationReadView } from './session-types.js';
export * from './projection-types.js';
import { type ApplicationProjectionDefinition, type ApplicationProjectionHandle, type ApplicationProjectionSnapshot } from './projection-types.js';
interface ProjectionSource {
    readonly applicationId: string;
    readonly historyId: string;
    readonly signal: AbortSignal;
    readView(): Promise<ApplicationReadView>;
    changes(options: {
        readonly signal: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
}
/** One session-owned checkpoint atomically binds reducer state to a verified event cursor. */
export declare class ApplicationProjection<State extends EventPayload> implements ApplicationProjectionHandle<State> {
    #private;
    readonly id: string;
    constructor(options: {
        readonly source: ProjectionSource;
        readonly store: BytesStore;
        readonly definition: ApplicationProjectionDefinition<State>;
        readonly release: () => void;
    });
    read(options?: {
        readonly signal?: AbortSignal;
    }): Promise<ApplicationProjectionSnapshot<State>>;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationProjectionSnapshot<State>>;
    close(): Promise<void>;
}
