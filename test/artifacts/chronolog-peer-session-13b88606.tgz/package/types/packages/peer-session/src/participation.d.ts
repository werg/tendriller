import type { PeerRevision } from '../../peer-generation/src/index.js';
import type { BytesStore } from '../../records/src/index.js';
import { type ApplicationPeerConnectOptions, type ApplicationPeerLink } from './network.js';
import type { ApplicationParticipant } from './participant-types.js';
import type { ApplicationParticipation, ApplicationParticipationOptions, ApplicationParticipationStatus, ApplicationConnectionDiagnostic } from './participation-types.js';
interface Owner {
    readonly participant: ApplicationParticipant;
    readonly store: BytesStore;
    readonly signal: AbortSignal;
    connect(options: ApplicationPeerConnectOptions): Promise<ApplicationPeerLink>;
    links(): readonly ApplicationPeerLink[];
    resume(): Promise<void>;
}
/** One session owner for discovery, connection attempts and verified recovery policy. */
export declare class OwnedApplicationParticipation implements ApplicationParticipation {
    #private;
    readonly signal: AbortSignal;
    constructor(owner: Owner, input: ApplicationParticipationOptions);
    get status(): ApplicationParticipationStatus;
    onStatus(listener: (status: ApplicationParticipationStatus) => void): () => void;
    diagnostics(): Promise<readonly ApplicationConnectionDiagnostic[]>;
    reconsiderConnections(): Promise<void>;
    approveRecovery(proposalId: string): Promise<void>;
    /** Called only after this exact coordinator's authenticated head has been fully verified locally. */
    observeHead(peerId: string, revision: PeerRevision, requestedAt: number): void;
    close(): Promise<void>;
}
export {};
