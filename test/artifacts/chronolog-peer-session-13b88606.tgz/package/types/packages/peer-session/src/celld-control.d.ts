import { type PeerIdentity, type SignedApplicationDescriptor, type SignedControlRevision, type SignedGeneration, type SignedTransitionRequest } from '../../peer-generation/src/control.js';
import { type CelldBytesStorage, type CelldBytesStoreOptions } from '../../records/src/celld.js';
import type { ApplicationControlHost } from './recovery.js';
export interface CelldApplicationControl extends ApplicationControlHost {
    selectGeneration(request: SignedTransitionRequest, options?: {
        readonly signal?: AbortSignal;
        readonly control?: SignedControlRevision;
    }): Promise<SignedGeneration>;
    close(): Promise<void>;
}
/** Own the current signed generation registry in a celld control object. */
export declare function openCelldApplicationControl(options: {
    readonly storage: CelldBytesStorage;
    readonly descriptor: SignedApplicationDescriptor;
    readonly controls: readonly SignedControlRevision[];
    readonly signer: PeerIdentity;
    readonly create?: true;
    readonly limits?: CelldBytesStoreOptions;
}): Promise<CelldApplicationControl>;
