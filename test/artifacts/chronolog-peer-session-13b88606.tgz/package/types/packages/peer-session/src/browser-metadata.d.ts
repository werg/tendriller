import type { DeviceMetadataStore } from './device.js';
/** Browser-owned key/value metadata. No OPFS, SQL engine or long-lived lock. */
export declare class BrowserMetadataStore implements DeviceMetadataStore {
    #private;
    private constructor();
    static open(name: string): Promise<BrowserMetadataStore>;
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, value: Uint8Array): Promise<void>;
    initialize(input: readonly {
        readonly key: string;
        readonly value: Uint8Array;
    }[]): Promise<void>;
    compareAndSwap(key: string, expected: Uint8Array | null, value: Uint8Array): Promise<boolean>;
    close(): void;
}
