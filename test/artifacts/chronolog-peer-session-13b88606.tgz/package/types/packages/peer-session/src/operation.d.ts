import type { AppliedResult, OperationState, SignedRetainedCoverage } from '../../peer-generation/src/index.js';
import type { ApplicationSession } from './session.js';
export type ApplicationSubmission = ApplicationOperation & {
    readonly attemptId: string;
};
/** A saved immutable attempt. Cancelling a waiter never cancels its command. */
export declare class ApplicationOperation {
    readonly session: ApplicationSession;
    readonly operationId: string;
    readonly author?: string | undefined;
    constructor(session: ApplicationSession, operationId: string, author?: string | undefined);
    get(): Promise<OperationState | null>;
    applied(options?: {
        readonly signal?: AbortSignal;
    }): Promise<AppliedResult>;
    retry(): Promise<void>;
    shared(options?: {
        readonly signal?: AbortSignal;
    }): Promise<readonly SignedRetainedCoverage[]>;
}
