import type { SignedCelldWorkspacePublication } from './celld-workspace-publication.js';
import type { CelldPeerBinding, CelldPeerEndpoint, CelldPeerStream } from './celld-peer.js';
export type CelldDoltPublicationGrant = {
    readonly kind: 'applied';
    readonly head: string;
} | {
    readonly kind: 'staged';
    readonly head: string;
} | {
    readonly kind: 'grant';
    readonly id: string;
    readonly ref: string;
    readonly token: string;
    readonly branch?: string;
};
export type CelldWorkspaceHistoryRequest = 'grant' | 'push' | 'missing' | 'blob' | 'publish';
export interface AuthorizeDoltPublication {
    (input: {
        readonly peer: string;
        readonly proof: SignedCelldWorkspacePublication;
        readonly kind: CelldWorkspaceHistoryRequest;
        readonly digest?: string;
        readonly bytes: number;
    }): Promise<{
        grant(): Promise<CelldDoltPublicationGrant>;
        push(bytes: Uint8Array): Promise<Uint8Array>;
        missing?(): Promise<readonly string[]>;
        blob?(digest: string, bytes: Uint8Array): Promise<void>;
        publish?(): Promise<string>;
    }>;
}
/** The receiver checks the proof and the authenticated Iroh peer before reading a pack. */
export declare function serveCelldDoltPublication(stream: CelldPeerStream, authorize: AuthorizeDoltPublication): Promise<void>;
/** One exact grant and the raw Dolt requests share the same signed Iroh scope. */
export declare function celldDoltPublicationPeer(binding: CelldPeerBinding, destination: CelldPeerEndpoint, input: SignedCelldWorkspacePublication): Readonly<{
    grant(): Promise<{
        readonly kind: "applied";
        readonly head: string;
    } | {
        readonly kind: "staged";
        readonly head: string;
    } | {
        readonly kind: "grant";
        readonly id: string;
        readonly ref: string;
        readonly token: string;
        readonly branch?: string;
    }>;
    push(bytes: Uint8Array): Promise<Uint8Array<ArrayBufferLike>>;
    missing(): Promise<string[]>;
    blob(contentDigest: string, bytes: Uint8Array): Promise<void>;
    publish(): Promise<string>;
}>;
