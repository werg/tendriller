import { type CborValue } from './cbor.js';
import { type PlatformOp } from './platform.js';
import { type SqlStatement } from './sql.js';
export type EventPayload = null | boolean | number | string | readonly EventPayload[] | {
    readonly [key: string]: EventPayload;
};
export interface EmitStep {
    readonly op: 'emit';
    readonly topic: string;
    readonly payload: EventPayload;
}
/** One signed program, one outcome, and one atomic SQL/event visibility boundary. */
export type ProgramStep = SqlStatement | PlatformOp | EmitStep;
export interface ChangeProgram {
    readonly version: 3;
    readonly steps: readonly ProgramStep[];
}
export declare const MAX_PROGRAM_STEPS = 256;
export declare const MAX_PROGRAM_BYTES = 262144;
export declare const MAX_PROGRAM_EVENTS = 64;
export declare const MAX_EVENT_BYTES = 16384;
export declare const MAX_TOPIC_BYTES = 128;
export declare function assertEventTopic(topic: string): void;
/** Bounded canonical JSON, shared by event bodies and public application metadata. */
export declare function canonicalJson(payload: EventPayload, limits: {
    readonly maxBytes: number;
    readonly maxNodes: number;
    readonly maxDepth: number;
}): string;
/** Canonical JSON embedded in canonical CBOR; rejects lossy/non-JSON inputs. */
export declare function canonicalEventPayload(payload: EventPayload): string;
export declare function emit(topic: string, payload: EventPayload): EmitStep;
export declare function isEmitStep(step: unknown): step is EmitStep;
export declare function isSqlStatementStep(step: ProgramStep): step is SqlStatement;
export declare function program(...steps: readonly (ProgramStep | string)[]): ChangeProgram;
export declare function assertValidChangeProgram(value: ChangeProgram): void;
export declare function changeProgramToCanonicalCbor(value: ChangeProgram): CborValue;
export declare function changeProgramFromCanonicalCbor(value: CborValue): ChangeProgram;
export declare function encodeChangeProgram(value: ChangeProgram): Uint8Array;
export declare function decodeChangeProgram(bytes: Uint8Array): ChangeProgram;
