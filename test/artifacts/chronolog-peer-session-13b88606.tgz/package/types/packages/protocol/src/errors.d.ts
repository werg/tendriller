export type ProtocolErrorCode = 'CBOR_INVALID' | 'CBOR_NON_CANONICAL' | 'CBOR_LIMIT_EXCEEDED' | 'SCHEMA_INVALID' | 'UNSUPPORTED_VERSION' | 'INTEGER_OUT_OF_RANGE' | 'INVALID_UTF8' | 'INVALID_KEY' | 'INVALID_SIGNATURE' | 'DIGEST_MISMATCH' | 'WRONG_DOMAIN' | 'DUPLICATE_TRANSACTION';
export declare class ProtocolError extends Error {
    readonly code: ProtocolErrorCode;
    readonly details: Readonly<Record<string, unknown>> | undefined;
    constructor(code: ProtocolErrorCode, message: string, details?: Readonly<Record<string, unknown>>);
    toJSON(): Readonly<Record<string, unknown>>;
}
export declare function protocolInvariant(condition: unknown, code: ProtocolErrorCode, message: string, details?: Readonly<Record<string, unknown>>): asserts condition;
