import { type CborValue } from './cbor.js';
/** SQLite's five storage classes; the only values a transaction can bind. */
export type SqlValue = {
    readonly kind: 'null';
} | {
    readonly kind: 'integer';
    readonly value: bigint;
} | {
    readonly kind: 'real';
    readonly value: number;
} | {
    readonly kind: 'text';
    readonly value: string;
} | {
    readonly kind: 'blob';
    readonly value: Uint8Array;
};
export interface SqlBinding {
    readonly parameter: {
        readonly kind: 'index';
        readonly index: number;
    } | {
        readonly kind: 'name';
        readonly name: string;
    };
    readonly value: SqlValue;
}
export interface SqlStatement {
    readonly sql: string;
    readonly bindings: readonly SqlBinding[];
}
export declare const MAX_SQL_STATEMENT_BINDINGS = 1000;
export declare const MAX_ASSERT_CODE_BYTES = 128;
export declare const sqlValue: Readonly<{
    null: () => SqlValue;
    integer: (value: bigint | number) => SqlValue;
    real: (value: number) => SqlValue;
    text: (value: string) => SqlValue;
    blob: (value: Uint8Array) => SqlValue;
}>;
/**
 * The natural SQLite value of a JavaScript value: safe-integer numbers and
 * bigints are INTEGER, other finite numbers REAL, strings TEXT, bytes BLOB.
 * Use `sqlValue.real(1)` for an integral REAL.
 */
export declare function toSqlValue(value: unknown): SqlValue;
export declare function isSqlValue(value: unknown): value is SqlValue;
/** Positional or named bindings in the shape SQL builders produce. */
export declare function sqlStatement(sql: string, parameters?: readonly unknown[] | Readonly<Record<string, unknown>>): SqlStatement;
export declare function sqlValueToCanonicalCbor(value: SqlValue): CborValue;
export declare function sqlValueFromCanonicalCbor(value: CborValue, name?: string): SqlValue;
export declare function sqlStatementToCanonicalCbor(value: SqlStatement): CborValue;
export declare function sqlStatementFromCanonicalCbor(value: CborValue, name?: string): SqlStatement;
export interface ExecutionLimits {
    /** Maximum UTF-8 bytes of one statement's SQL source. */
    readonly maxSqlBytes: number;
    /** Deterministic VM-step budget for one statement. */
    readonly maxVmSteps: number;
    /** Maximum bytes of any one string or BLOB value. */
    readonly maxValueBytes: number;
}
/**
 * What a transaction was authored for: the exact engine build, the platform
 * code that enforces row ownership, the SQL profile and the execution limits.
 * A replica only executes transactions for the manifest it runs; changing any
 * of them is a group-wide upgrade.
 */
export interface ExecutionManifest {
    readonly version: 2;
    readonly profile: string;
    /** Engine build identity, e.g. the native patch profile. */
    readonly engine: string;
    /** SHA-256 over the native engine descriptor. */
    readonly engineDigest: Uint8Array;
    readonly programVersion: 3;
    /** SHA-256 over the platform operations and the trigger and view generators. */
    readonly platformDigest: Uint8Array;
    /** `PRAGMA recursive_triggers` during consensus execution; always on. */
    readonly recursiveTriggers: true;
    readonly limits: ExecutionLimits;
}
export declare const DEFAULT_EXECUTION_LIMITS: Readonly<ExecutionLimits>;
export declare function createExecutionManifest(options: {
    readonly profile: string;
    readonly engineDigest: Uint8Array;
    readonly platformDigest: Uint8Array;
    readonly engine?: string;
    readonly limits?: Partial<ExecutionLimits>;
}): ExecutionManifest;
export declare function executionManifestToCbor(value: ExecutionManifest): CborValue;
export declare function executionManifestFromCbor(value: CborValue): ExecutionManifest;
export declare function encodeExecutionManifest(value: ExecutionManifest): Uint8Array;
export declare function decodeExecutionManifest(bytes: Uint8Array): ExecutionManifest;
export declare function digestExecutionManifest(value: ExecutionManifest): Promise<Uint8Array>;
export interface ManifestArtifacts {
    readonly executionManifestDigest: Uint8Array;
    readonly canonicalExecutionManifest: Uint8Array;
}
export declare function executionManifestArtifacts(value: ExecutionManifest): Promise<ManifestArtifacts>;
