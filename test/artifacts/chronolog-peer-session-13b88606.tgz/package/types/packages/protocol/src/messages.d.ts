import { type ChangeProgram } from './program.js';
export interface TransactionCore {
    readonly operationId: string;
    readonly groupId: Uint8Array;
    readonly membershipRevision: Uint8Array;
    readonly validationPolicy: Uint8Array;
    readonly authorId: Uint8Array;
    readonly writerCapability?: Uint8Array;
    readonly authorTimestampMs: bigint;
    readonly nonce: Uint8Array;
    readonly executionManifestDigest: Uint8Array;
    readonly program: ChangeProgram;
    readonly metadata?: ReadonlyMap<string, Uint8Array>;
}
/** Deterministic tie-break key for an authored transaction. */
export interface TransactionOrderKey {
    readonly authorTimestampMs: bigint;
    readonly authorId: Uint8Array;
    readonly txId: Uint8Array;
}
export declare function encodeTransactionCore(value: TransactionCore): Uint8Array;
export declare function decodeTransactionCore(bytes: Uint8Array): TransactionCore;
export declare function transactionDigest(value: TransactionCore | Uint8Array): Promise<Uint8Array>;
export declare function transactionOrderKey(core: Pick<TransactionCore, 'authorTimestampMs' | 'authorId'>, txId: Uint8Array): TransactionOrderKey;
export declare function compareTransactionOrder(left: TransactionOrderKey, right: TransactionOrderKey): number;
export declare function assertUniqueOrderKeys(keys: readonly TransactionOrderKey[]): void;
