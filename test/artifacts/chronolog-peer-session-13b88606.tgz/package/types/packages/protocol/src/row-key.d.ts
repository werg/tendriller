/** Opaque, versioned keys shared with the native chronolog_row_key() function. */
export declare const ROW_KEY_PREFIX = "rk1:";
export declare const MAX_ROW_KEY_PARTS = 64;
/** TEXT stays as UTF-8 bytes so even SQLite text made from invalid UTF-8 is lossless. */
export type RowKeyPart = {
    readonly kind: 'null';
} | {
    readonly kind: 'integer';
    readonly value: bigint;
} | {
    readonly kind: 'real';
    readonly value: number;
} | {
    readonly kind: 'text' | 'blob';
    readonly value: Uint8Array;
};
/**
 * Encode values in their stored SQLite types. For a key containing
 * chronolog_owner, supply the owner's 32-byte key instead of its local id.
 * Resolve affinity/coercion with SQL before encoding an existing row.
 */
export declare function encodeRowKey(values: readonly unknown[]): string;
/** Decode the exact typed tuple, rejecting unknown versions, truncation and trailing data. */
export declare function decodeRowKey(key: string): readonly RowKeyPart[];
