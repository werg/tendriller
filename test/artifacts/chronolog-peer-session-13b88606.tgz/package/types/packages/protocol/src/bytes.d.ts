import { compareBytes, concatBytes, copyBytes, equalBytes } from '../../canonical/src/index.js';
export { compareBytes, concatBytes, copyBytes, equalBytes };
export declare function utf8(value: string): Uint8Array;
export declare function decodeUtf8(value: Uint8Array): string;
export declare function bytesToHex(value: Uint8Array): string;
export declare function hexToBytes(value: string): Uint8Array;
/** Canonical unpadded base64url using only APIs shared by browsers and Node. */
export declare function bytesToBase64Url(value: Uint8Array): string;
export declare function base64UrlToBytes(value: string): Uint8Array;
export declare function assertByteLength(value: Uint8Array, length: number, field: string): Uint8Array;
