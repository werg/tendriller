import { type CborValue } from './cbor.js';
import { type SqlValue } from './sql.js';
import { type SealedPlatformOp } from './sealed.js';
/**
 * Platform operations: typed steps of a transaction program that change the
 * row-ownership state (registered tables, collectives, grants, transfers).
 * Every replica executes them with the same trusted code, as the
 * transaction's signer. See docs/design-owner-rows.md §6.
 */
/** Node keys, collective ids, grant ids and offer ids are all 32 bytes. */
export declare const PLATFORM_ID_BYTES = 32;
export declare const MAX_PLATFORM_NAME_BYTES = 128;
export declare const MAX_PLATFORM_LIST_ENTRIES = 256;
export declare const MAX_ROW_KEY_VALUES = 64;
export declare const MAX_SEED_ROWS = 10000;
/** The `group` collective: created at genesis; its admins are the schema administrators. */
export declare const GROUP_COLLECTIVE_ID: Uint8Array;
/** Durable shared-data owner for peer-generation applications; controlled by signed revisions. */
export declare const APPLICATION_COLLECTIVE_ID: Uint8Array;
export type GrantOperation = 'insert' | 'update' | 'delete';
export type CollectiveRole = 'member' | 'admin';
/** The least role a collective member needs to insert, update or delete the collective's rows. */
export interface CollectiveGovernance {
    readonly insert: CollectiveRole;
    readonly update: CollectiveRole;
    readonly delete: CollectiveRole;
}
export interface MemberChange {
    readonly member: Uint8Array;
    /** A new role (inviting the key if it is not an active member), or `remove`. */
    readonly role: CollectiveRole | 'remove';
}
export type TransferScope = {
    readonly kind: 'row';
    readonly table: string;
    readonly rowKey: readonly SqlValue[];
}
/** Snapshot of every row the owner holds when offered; changes invalidate acceptance. */
 | {
    readonly kind: 'all';
};
type OwnershipPlatformOp = {
    readonly op: 'grant';
    readonly table: string;
    readonly grantee: Uint8Array;
    /** Whose rows the grant covers; defaults to the signer. A row grant's grantor is the row's owner. */
    readonly grantor?: Uint8Array;
    /** Primary-key values of one row; absent for a whole-table grant. */
    readonly rowKey?: readonly SqlValue[];
    readonly operations: readonly GrantOperation[];
    /** Columns an update may change; absent means every column. */
    readonly columns?: readonly string[];
} | {
    readonly op: 'revoke_grant';
    readonly grantId: Uint8Array;
} | {
    readonly op: 'create_collective';
    readonly governance: CollectiveGovernance;
    readonly invitees: readonly Uint8Array[];
} | {
    readonly op: 'accept_membership';
    readonly collectiveId: Uint8Array;
} | {
    readonly op: 'leave';
    readonly collectiveId: Uint8Array;
} | {
    readonly op: 'set_members';
    readonly collectiveId: Uint8Array;
    readonly changes: readonly MemberChange[];
} | {
    readonly op: 'transfer_offer';
    readonly scope: TransferScope;
    /** Defaults to the signer (a row offer: the row's owner). */
    readonly fromOwner?: Uint8Array;
    readonly toOwner: Uint8Array;
    /** Move same-owner dependents along owner-composite ON UPDATE CASCADE foreign keys. */
    readonly carry: boolean;
} | {
    readonly op: 'transfer_accept';
    readonly offerId: Uint8Array;
} | {
    readonly op: 'transfer_cancel';
    readonly offerId: Uint8Array;
} | {
    readonly op: 'seed_rows';
    readonly table: string;
    /** Must include chronolog_owner: seeded rows keep their source owners. */
    readonly columns: readonly string[];
    readonly rows: readonly (readonly SqlValue[])[];
}
/** Closes fork seeding for good; the fork-seed plan ends with it. Genesis root only. */
 | {
    readonly op: 'end_seeding';
};
export type PlatformOp = OwnershipPlatformOp | SealedPlatformOp;
export type PlatformOpName = PlatformOp['op'];
export declare function isPlatformOp(value: unknown): value is PlatformOp;
/** Typed builders for every platform operation; each validates its input. */
export declare const platformOp: Readonly<{
    grant: (input: {
        readonly table: string;
        readonly grantee: Uint8Array;
        readonly operations: readonly GrantOperation[];
        readonly grantor?: Uint8Array;
        readonly rowKey?: readonly unknown[];
        readonly columns?: readonly string[];
    }) => PlatformOp;
    revokeGrant: (grantId: Uint8Array) => PlatformOp;
    createCollective: (input: {
        readonly governance: CollectiveGovernance;
        readonly invitees?: readonly Uint8Array[];
    }) => PlatformOp;
    acceptMembership: (collectiveId: Uint8Array) => PlatformOp;
    leave: (collectiveId: Uint8Array) => PlatformOp;
    setMembers: (collectiveId: Uint8Array, changes: readonly MemberChange[]) => PlatformOp;
    transferRow: (input: {
        readonly table: string;
        readonly rowKey: readonly unknown[];
        readonly toOwner: Uint8Array;
        readonly carry?: boolean;
        readonly fromOwner?: Uint8Array;
    }) => PlatformOp;
    transferAll: (input: {
        readonly toOwner: Uint8Array;
        readonly fromOwner?: Uint8Array;
    }) => PlatformOp;
    acceptTransfer: (offerId: Uint8Array) => PlatformOp;
    cancelTransfer: (offerId: Uint8Array) => PlatformOp;
    seedRows: (table: string, columns: readonly string[], rows: readonly (readonly unknown[])[]) => PlatformOp;
    endSeeding: () => PlatformOp;
    registerReaderKey: (publicKey: Uint8Array) => SealedPlatformOp;
    readerPolicy: (input: {
        readonly table: string;
        readonly rowKey: readonly unknown[];
        readonly expectedPolicyId?: Uint8Array;
        readonly expectedVersion: bigint;
        readonly readers: readonly Uint8Array[];
    }) => SealedPlatformOp;
    put: (input: {
        readonly policyId: Uint8Array;
        readonly expectedPolicyVersion: bigint;
        readonly expectedDataVersion: bigint;
        readonly slot: string;
        readonly envelope: import("./sealed.js").SealedEnvelope;
    }) => SealedPlatformOp;
}>;
export declare function platformOpToCanonicalCbor(op: PlatformOp): CborValue;
export declare function platformOpFromCanonicalCbor(value: CborValue, name?: string): PlatformOp;
export declare function encodePlatformOp(op: PlatformOp): Uint8Array;
export declare function decodePlatformOp(bytes: Uint8Array): PlatformOp;
/** The hash preimage of the id of the grant, collective or offer created by step `stepIndex` of `txId`. */
export declare function platformObjectIdPreimage(txId: Uint8Array, stepIndex: number): Uint8Array;
/** The 32-byte id of the grant, collective or offer created by step `stepIndex` of transaction `txId`. */
export declare function platformObjectId(txId: Uint8Array, stepIndex: number): Promise<Uint8Array>;
/** The domain-separated bytes whose SHA-256 is the platform object id (for synchronous hashing). */
export declare function platformObjectIdHashInput(txId: Uint8Array, stepIndex: number): Uint8Array;
export {};
