import { type CborValue } from './cbor.js';
import { type SqlValue } from './sql.js';
/** Sealed values contain client ciphertext; no plaintext or secret key enters a transaction. */
export declare const MAX_SEALED_READERS = 256;
export declare const MAX_SEALED_NAME_BYTES = 128;
export declare const MAX_SEALED_ROW_KEY_VALUES = 64;
export declare const MAX_SEALED_PLAINTEXT_BYTES: number;
export declare const MAX_SEALED_ENVELOPE_BYTES: number;
/** Versions are stored in SQLite INTEGER columns, so they use the positive int64 range. */
export declare const MAX_SEALED_VERSION: bigint;
export interface SealedContext {
    readonly groupId: Uint8Array;
    readonly policyId: Uint8Array;
    readonly policyVersion: bigint;
    readonly slot: string;
    readonly dataVersion: bigint;
}
/** A policy snapshots each reader's registered HPKE key; key registration alone changes no policy. */
export interface SealedRecipient {
    readonly readerId: Uint8Array;
    readonly publicKey: Uint8Array;
}
export interface SealedKeyWrap extends SealedRecipient {
    readonly encapsulatedKey: Uint8Array;
    readonly ciphertext: Uint8Array;
}
export interface SealedEnvelope {
    readonly context: SealedContext;
    readonly nonce: Uint8Array;
    readonly ciphertext: Uint8Array;
    /** Strictly increasing reader ids. Every current policy reader has exactly one wrap. */
    readonly wraps: readonly SealedKeyWrap[];
}
/** Reserved codes leave the original ownership operation encoding unchanged. */
export declare const SEALED_OP_CODES: Readonly<{
    register_reader_key: 64n;
    reader_policy: 65n;
    sealed_put: 66n;
}>;
export type SealedPlatformOp = {
    readonly op: 'register_reader_key';
    readonly publicKey: Uint8Array;
} | {
    readonly op: 'reader_policy';
    readonly table: string;
    readonly rowKey: readonly SqlValue[];
    /** Absent only when creating a new policy generation (expectedVersion = 0). */
    readonly expectedPolicyId?: Uint8Array;
    readonly expectedVersion: bigint;
    /** Signing-key ids, strictly sorted and unique. No owner or administrator is added implicitly. */
    readonly readers: readonly Uint8Array[];
} | {
    readonly op: 'sealed_put';
    readonly policyId: Uint8Array;
    readonly expectedPolicyVersion: bigint;
    readonly expectedDataVersion: bigint;
    readonly slot: string;
    readonly envelope: SealedEnvelope;
};
export declare function isSealedPlatformOp(value: unknown): value is SealedPlatformOp;
export declare const sealedOp: Readonly<{
    registerReaderKey: (publicKey: Uint8Array) => SealedPlatformOp;
    readerPolicy: (input: {
        readonly table: string;
        readonly rowKey: readonly unknown[];
        readonly expectedPolicyId?: Uint8Array;
        readonly expectedVersion: bigint;
        readonly readers: readonly Uint8Array[];
    }) => SealedPlatformOp;
    put: (input: {
        readonly policyId: Uint8Array;
        readonly expectedPolicyVersion: bigint;
        readonly expectedDataVersion: bigint;
        readonly slot: string;
        readonly envelope: SealedEnvelope;
    }) => SealedPlatformOp;
}>;
export declare function sealedContextToCanonicalCbor(value: SealedContext): CborValue;
export declare function sealedContextFromCanonicalCbor(value: CborValue): SealedContext;
export declare function encodeSealedContext(context: SealedContext): Uint8Array;
export declare function sealedEnvelopeToCanonicalCbor(value: SealedEnvelope): CborValue;
export declare function sealedEnvelopeFromCanonicalCbor(value: CborValue): SealedEnvelope;
export declare function encodeSealedEnvelope(envelope: SealedEnvelope): Uint8Array;
export declare function decodeSealedEnvelope(bytes: Uint8Array): SealedEnvelope;
export declare function sealedPlatformOpToCanonicalCbor(op: SealedPlatformOp): CborValue;
export declare function sealedPlatformOpFromCanonicalCbor(value: CborValue, field?: string): SealedPlatformOp;
