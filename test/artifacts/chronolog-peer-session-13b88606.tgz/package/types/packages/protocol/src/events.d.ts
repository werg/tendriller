import type { EventPayload } from './program.js';
/** Authenticated proposal facts, supplied by the replica rather than an emit payload. */
export interface ChronologEventOrigin {
    readonly kind: 'chronolog';
    /** Canonical unpadded base64url group digest. */
    readonly groupId: string;
    /** Lowercase hex public key, identical to Signals.authorId for the same signer. */
    readonly authorId: string;
    readonly operationId: string;
    /** Signed ordering timestamp as an exact decimal integer, not delivery time. */
    readonly authorTimestampMs: string;
    /** Canonical unpadded base64url membership revision digest. */
    readonly membershipRevision: string;
    /** Canonical unpadded base64url signed grant digest; null only for explicit static membership. */
    readonly writerCapability: string | null;
}
/** Validate and copy a serialized origin. Authentication remains the source's responsibility. */
export declare function cloneEventOrigin(value: ChronologEventOrigin): ChronologEventOrigin;
export interface EffectiveEvent {
    readonly id: string;
    readonly proposalId: string;
    readonly eventOrdinal: number;
    readonly topic: string;
    readonly payload: EventPayload;
    readonly origin: ChronologEventOrigin;
}
export interface EventTransaction {
    readonly proposalId: string;
    readonly events: readonly EffectiveEvent[];
}
export interface EventReadOptions {
    readonly cursor?: string;
    readonly topics?: readonly string[];
    /** Maximum matching whole proposals, not an event count. */
    readonly limit?: number;
}
export interface EventBatch {
    readonly transactions: readonly EventTransaction[];
    readonly scannedThrough: string;
    readonly hasMore: boolean;
    readonly revision: string;
}
