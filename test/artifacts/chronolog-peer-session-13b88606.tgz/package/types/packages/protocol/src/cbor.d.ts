import { encodeCanonicalCbor, type CborMapKey, type CborValue } from '../../canonical/src/index.js';
export type { CborMapKey, CborValue };
export { encodeCanonicalCbor };
/** Protocol CBOR decode limits mapped onto the shared bounded decoder. */
export interface CborDecodeLimits {
    readonly maxBytes?: number;
    readonly maxDepth?: number;
    readonly maxItems?: number;
    readonly maxTextBytes?: number;
    readonly maxByteStringBytes?: number;
}
export declare function decodeCanonicalCbor(input: Uint8Array, limits?: CborDecodeLimits): CborValue;
export declare function assertCanonicalCbor(input: Uint8Array, limits?: CborDecodeLimits): CborValue;
