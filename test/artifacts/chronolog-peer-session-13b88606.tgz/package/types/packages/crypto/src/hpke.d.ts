export declare const HPKE_SUITE: "DHKEM(X25519,HKDF-SHA256)/HKDF-SHA256/AES-256-GCM";
export interface X25519KeyPair {
    readonly publicKey: CryptoKey;
    readonly privateKey: CryptoKey;
    readonly publicKeyBytes: Uint8Array;
}
export interface HpkeCiphertext {
    readonly encapsulatedKey: Uint8Array;
    readonly ciphertext: Uint8Array;
}
export declare function generateX25519KeyPair(extractable?: boolean): Promise<X25519KeyPair>;
export declare function importX25519PublicKey(raw: Uint8Array): Promise<CryptoKey>;
export declare function importX25519PrivateKey(pkcs8: Uint8Array, extractable?: boolean): Promise<CryptoKey>;
export declare function exportX25519PrivateKey(privateKey: CryptoKey): Promise<Uint8Array>;
export declare function hpkeSealBase(recipientPublicKeyBytes: Uint8Array, plaintext: Uint8Array, info: Uint8Array, aad: Uint8Array): Promise<HpkeCiphertext>;
export declare function hpkeOpenBase(recipientPrivateKey: CryptoKey, recipientPublicKeyBytes: Uint8Array, encapsulatedKey: Uint8Array, ciphertext: Uint8Array, info: Uint8Array, aad: Uint8Array): Promise<Uint8Array>;
/** RFC 9180 §6.2: application keys use the exporter, never the HPKE traffic key. */
export declare function hpkeSendExportBase(recipientPublicKeyBytes: Uint8Array, info: Uint8Array, exporterContext: Uint8Array, length: number): Promise<{
    readonly encapsulatedKey: Uint8Array;
    readonly exportedSecret: Uint8Array;
}>;
/** The caller authenticates the encapsulation and its complete application context. */
export declare function hpkeReceiveExportBase(recipientPrivateKey: CryptoKey, recipientPublicKeyBytes: Uint8Array, encapsulatedKey: Uint8Array, info: Uint8Array, exporterContext: Uint8Array, length: number): Promise<Uint8Array>;
