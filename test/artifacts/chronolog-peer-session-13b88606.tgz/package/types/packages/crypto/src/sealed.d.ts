import { type SealedContext, type SealedEnvelope, type SealedRecipient } from '../../protocol/src/index.js';
/**
 * Encrypt one value on the client with a fresh random AES-256-GCM key, wrapped
 * independently to every explicit reader using HPKE. The owner is not added.
 * Callers cannot supply/reuse the content key. The result is safe to replicate.
 */
export declare function sealSealedValue(input: {
    readonly context: SealedContext;
    readonly plaintext: Uint8Array;
    readonly recipients: readonly SealedRecipient[];
}): Promise<SealedEnvelope>;
/**
 * Open only a value matching externally expected group, policy, policy version,
 * column and data version. Supplying the envelope's own context as the expected
 * context defeats substitution protection; use trusted row/revision metadata.
 */
export declare function openSealedValue(input: {
    readonly envelope: SealedEnvelope;
    readonly expectedContext: SealedContext;
    readonly readerId: Uint8Array;
    readonly recipientPrivateKey: CryptoKey;
}): Promise<Uint8Array>;
