export interface EncryptedEpochPayload {
    readonly epoch: bigint;
    readonly nonce: Uint8Array;
    readonly ciphertext: Uint8Array;
}
export declare function encryptEpochPayload(contentKey: Uint8Array, epoch: bigint, plaintext: Uint8Array, associatedData: Uint8Array): Promise<EncryptedEpochPayload>;
export declare function decryptEpochPayload(contentKey: Uint8Array, payload: EncryptedEpochPayload, associatedData: Uint8Array): Promise<Uint8Array>;
