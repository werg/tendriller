export type SignalPayload = null | boolean | number | string | readonly SignalPayload[] | {
    readonly [key: string]: SignalPayload;
};
export declare function assertSignalTopic(topic: string): void;
/** Strict JSON, copied before asynchronous work; no accessors or lossy values. */
export declare function canonicalSignalPayload(payload: SignalPayload): string;
