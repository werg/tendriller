import {
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
} from "./chunks/chunk-UYBPNY7I.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-IEAQOO7O.mjs";
export {
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
