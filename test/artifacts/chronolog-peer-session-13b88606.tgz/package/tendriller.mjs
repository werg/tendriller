// packages/peer-session/src/tendriller.ts
function createApplicationBackend(options) {
  const session = options.session;
  if (!/^[0-9a-f]{64}$/u.test(options.id)) throw new Error("APPLICATION_BACKEND_ID_INVALID");
  if (options.id !== session.applicationId) throw new Error("APPLICATION_BACKEND_SCOPE_MISMATCH");
  if (options.eventCommand !== void 0 && !session.describe().commands.some((command) => command.name === options.eventCommand)) {
    throw new Error("APPLICATION_EVENT_COMMAND_UNKNOWN");
  }
  const submit = async (program, input) => {
    if (program === null || typeof program !== "object" || typeof program.name !== "string") throw new Error("APPLICATION_COMMAND_INVALID");
    const operation = await session.command(program.name, program.input, {
      operationId: input.operationId,
      ...input.basedOn === void 0 ? {} : { basedOn: JSON.parse(input.basedOn) }
    });
    const state = await operation.get();
    if (state === null) throw new Error("APPLICATION_OPERATION_NOT_FOUND");
    return state;
  };
  const read = async (input = {}) => {
    input.signal?.throwIfAborted();
    const view = await session.readView();
    try {
      input.signal?.throwIfAborted();
      return eventBatch(await view.readEvents(input));
    } finally {
      await view.release();
    }
  };
  return Object.freeze({
    id: options.id,
    capabilities: Object.freeze([
      "events",
      "revision-views",
      "operation-status",
      "recovery",
      ...session.capabilities.sql ? ["sql"] : [],
      ...options.eventCommand === void 0 ? [] : ["event-publication"]
    ]),
    get status() {
      return session.status;
    },
    get endpoint() {
      return "endpoint" in session ? session.endpoint : void 0;
    },
    onStatus: session.onStatus.bind(session),
    submit,
    changes(input = {}) {
      assertView(input);
      return { async *[Symbol.asyncIterator]() {
        for await (const change of session.changes(input)) yield {
          view: "applied",
          revision: JSON.stringify(change.revision),
          generation: change.revision.generation,
          kind: change.kind === "recovery" ? "recovery" : "update",
          ...change.recovery === null ? {} : { recovery: recoveryNotice(change.recovery) }
        };
      } };
    },
    async readView(input = {}) {
      assertView(input);
      const view = await session.readView();
      return Object.freeze({
        view: "applied",
        revision: JSON.stringify(view.revision),
        generation: view.revision.generation,
        async query(sql, parameters = []) {
          if (!session.capabilities.sql) throw new Error("SQL_NOT_AVAILABLE");
          return await view.query(sql, parameters);
        },
        async readEvents(input2 = {}) {
          input2.signal?.throwIfAborted();
          return eventBatch(await view.readEvents(input2));
        },
        release: async () => {
          await view.release();
        }
      });
    },
    onRecovery: (listener) => session.onRecovery((notice) => {
      listener(recoveryNotice(notice));
    }),
    inspectRecovery: async () => (await session.inspectRecovery()).map(recoveryNotice),
    operations: Object.freeze({
      get: (id) => session.operations.get(id),
      subscribe(input) {
        return { async *[Symbol.asyncIterator]() {
          let previous;
          for await (const _change of session.changes(input)) {
            const state = await session.operations.get(input.operationId), encoded = JSON.stringify(state);
            if (state !== null && encoded !== previous) {
              previous = encoded;
              yield state;
            }
          }
        } };
      }
    }),
    events: Object.freeze({
      async publish(topic, payload, input) {
        if (options.eventCommand === void 0) throw new Error("APPLICATION_EVENT_PUBLICATION_NOT_CONFIGURED");
        return submit({ name: options.eventCommand, input: { topic, payload } }, input);
      },
      read,
      subscribe(input = {}) {
        return { async *[Symbol.asyncIterator]() {
          let cursor = input.cursor;
          for await (const _change of session.changes(input)) {
            for (; ; ) {
              const batch = await read({ ...input, ...cursor === void 0 ? {} : { cursor } });
              if (batch.scannedThrough === cursor) break;
              cursor = batch.scannedThrough;
              yield batch;
              if (!batch.hasMore) break;
            }
          }
        } };
      }
    })
  });
}
function assertView(input) {
  if (input.view !== void 0 && input.view !== "applied") throw new Error("APPLICATION_VIEW_UNSUPPORTED");
}
function recoveryNotice(notice) {
  return { ...notice, revision: JSON.stringify(notice.revision) };
}
function eventBatch(batch) {
  const transactions = /* @__PURE__ */ new Map();
  for (const event of batch.events) {
    let transaction = transactions.get(event.attemptId);
    if (transaction === void 0) {
      transaction = { proposalId: event.attemptId, events: [] };
      transactions.set(event.attemptId, transaction);
    }
    transaction.events.push({
      id: event.id,
      proposalId: event.attemptId,
      eventOrdinal: Number(event.id.slice(event.id.lastIndexOf(":") + 1)),
      topic: event.topic,
      payload: event.payload,
      origin: { kind: "peer-generation", authorId: event.author, operationId: event.operationId }
    });
  }
  return { transactions: [...transactions.values()], scannedThrough: batch.cursor, hasMore: batch.hasMore, revision: JSON.stringify(batch.revision) };
}
export {
  createApplicationBackend
};
