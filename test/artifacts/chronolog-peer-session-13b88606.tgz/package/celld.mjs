import {
  openApplicationDevice,
  openPeerApplication,
  retainApplicationAuthority,
  verifyDeviceSigner
} from "./chunks/chunk-GZRGH5GA.mjs";
import "./chunks/chunk-DDWT6CDC.mjs";
import "./chunks/chunk-Q6DWSCSA.mjs";
import "./chunks/chunk-G2YASPQR.mjs";
import "./chunks/chunk-F2F5EOFI.mjs";
import {
  createGenerationRegistry,
  decodePeerValue,
  encodePeerValue,
  verifyAuthorityBundle
} from "./chunks/chunk-Q5HDMKTI.mjs";
import {
  DOMAINS,
  bytesToHex,
  hexToBytes,
  importEd25519PrivateKey,
  signDomain,
  verifyDomain
} from "./chunks/chunk-LR76T2KY.mjs";
import "./chunks/chunk-DEFS6EFN.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import {
  framePeerStream
} from "./chunks/chunk-IEAQOO7O.mjs";

// packages/records/src/sqlite-byte-limits.ts
function sqliteByteLimits(options) {
  const quotaBytes = options.quotaBytes ?? 256 * 1024 * 1024;
  const maxValueBytes = options.maxValueBytes ?? 128 * 1024 * 1024;
  for (const value of [quotaBytes, maxValueBytes]) {
    if (!Number.isSafeInteger(value) || value < 1) throw new Error("BYTES_STORE_QUOTA_INVALID");
  }
  return { quotaBytes, maxValueBytes };
}
function validateSqliteByteKey(key2) {
  if (key2.length === 0 || key2.length > 2048 || [...key2].some((character) => character.charCodeAt(0) < 32)) {
    throw new Error("BYTES_STORE_KEY_INVALID");
  }
}

// packages/records/src/celld.ts
var CelldBytesStore = class {
  constructor(storage, options = {}) {
    this.storage = storage;
    this.#limits = sqliteByteLimits(options);
    this.storage.transactionSync(() => {
      this.storage.sql.exec(`CREATE TABLE IF NOT EXISTS chronolog_records (
        key TEXT PRIMARY KEY, value BLOB NOT NULL
      ) STRICT`).toArray();
      this.storage.sql.exec(`CREATE TABLE IF NOT EXISTS chronolog_record_usage (
        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
        used_bytes INTEGER NOT NULL CHECK (used_bytes >= 0)
      ) STRICT`).toArray();
      this.storage.sql.exec(`
        INSERT INTO chronolog_record_usage
        SELECT 1, (SELECT coalesce(sum(length(value)), 0) FROM chronolog_records)
        WHERE NOT EXISTS (SELECT 1 FROM chronolog_record_usage WHERE singleton = 1)
      `).toArray();
    });
  }
  storage;
  #limits;
  #closed = false;
  async get(key2) {
    this.#assertOpen();
    validateSqliteByteKey(key2);
    return this.#read(key2);
  }
  async put(key2, value) {
    this.#validate(key2, value);
    this.storage.transactionSync(() => this.#write([{ key: key2, value }]));
  }
  /** Persist a device signer and its immutable binding together. */
  async initialize(entries) {
    this.#assertOpen();
    validateInitialEntries(entries);
    for (const { key: key2, value } of entries) this.#validate(key2, value);
    this.storage.transactionSync(() => {
      if (entries.every(({ key: key2 }) => this.#size(key2) === null)) this.#write(entries);
    });
  }
  async compareAndSwap(key2, expected, value) {
    this.#validate(key2, value);
    return this.storage.transactionSync(() => {
      const current = this.#read(key2);
      const matches = expected === null ? current === null : current !== null && expected.byteLength === current.byteLength && expected.every((byte, index) => byte === current[index]);
      if (matches) this.#write([{ key: key2, value }]);
      return matches;
    });
  }
  usageBytes() {
    this.#assertOpen();
    const value = this.storage.sql.exec("SELECT used_bytes FROM chronolog_record_usage WHERE singleton = 1").toArray()[0]?.used_bytes;
    return readNonnegativeBytes(value);
  }
  close() {
    this.#closed = true;
  }
  #assertOpen() {
    if (this.#closed) throw new Error("BYTES_STORE_CLOSED");
  }
  #validate(key2, value) {
    this.#assertOpen();
    validateSqliteByteKey(key2);
    if (!(value instanceof Uint8Array) || value.byteLength > this.#limits.maxValueBytes) {
      throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    }
  }
  #read(key2) {
    const row = this.storage.sql.exec("SELECT value FROM chronolog_records WHERE key = ?", key2).toArray()[0];
    if (!row) return null;
    if (row.value instanceof Uint8Array) return Uint8Array.from(row.value);
    if (row.value instanceof ArrayBuffer) return new Uint8Array(row.value.slice(0));
    throw new Error("BYTES_STORE_VALUE_CORRUPT");
  }
  #size(key2) {
    const row = this.storage.sql.exec("SELECT length(value) AS size FROM chronolog_records WHERE key = ?", key2).toArray()[0];
    return row ? readNonnegativeBytes(row.size) : null;
  }
  #write(entries) {
    const used = entries.reduce((bytes, { key: key2, value }) => bytes - (this.#size(key2) ?? 0) + value.byteLength, this.usageBytes());
    if (used > this.#limits.quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    for (const { key: key2, value } of entries) {
      this.storage.sql.exec(
        "INSERT INTO chronolog_records VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        key2,
        value
      ).toArray();
    }
    this.storage.sql.exec("UPDATE chronolog_record_usage SET used_bytes = ? WHERE singleton = 1", used).toArray();
  }
};
function validateInitialEntries(entries) {
  if (entries.length === 0 || entries.length > 8 || new Set(entries.map(({ key: key2 }) => key2)).size !== entries.length) {
    throw new Error("BYTES_STORE_INITIALIZATION_INVALID");
  }
}
function readNonnegativeBytes(value) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0)
    throw new Error("BYTES_STORE_USAGE_CORRUPT");
  return value;
}

// packages/peer-session/src/celld-control.ts
var hostedApplications = /* @__PURE__ */ new WeakMap();
async function openCelldApplicationControl(options) {
  const { storage } = options;
  const descriptor = structuredClone(options.descriptor);
  const controls = structuredClone(options.controls);
  const applicationId = descriptor.payload.applicationId;
  let applications = hostedApplications.get(storage);
  if (!applications) {
    applications = /* @__PURE__ */ new Set();
    hostedApplications.set(storage, applications);
  }
  if (applications.has(applicationId)) throw new Error("CELLD_CONTROL_ALREADY_OPEN");
  const ownedApplications = applications;
  ownedApplications.add(applicationId);
  let store;
  try {
    const ownedStore = new CelldBytesStore(storage, options.limits);
    store = ownedStore;
    const registry = await createGenerationRegistry({
      store: ownedStore,
      descriptor,
      controls,
      signer: { ...options.signer },
      requireExisting: options.create !== true
    });
    const pending = /* @__PURE__ */ new Set();
    let closing;
    const run = (signal, operation) => {
      if (closing) return Promise.reject(new Error("CELLD_CONTROL_CLOSED"));
      const task = Promise.resolve().then(async () => {
        signal?.throwIfAborted();
        const result = await operation();
        signal?.throwIfAborted();
        return result;
      });
      pending.add(task);
      void task.then(() => pending.delete(task), () => pending.delete(task));
      return task;
    };
    return {
      application(request = {}) {
        return run(request.signal, () => registry.read());
      },
      selectGeneration(request, { control, signal } = {}) {
        const input = structuredClone(request);
        const revision = structuredClone(control);
        return run(signal, () => registry.select(input, revision === void 0 ? void 0 : { control: revision }));
      },
      close() {
        return closing ??= Promise.allSettled([...pending]).then(() => {
          ownedStore.close();
          ownedApplications.delete(applicationId);
        });
      }
    };
  } catch (error) {
    store?.close();
    ownedApplications.delete(applicationId);
    throw error;
  }
}

// packages/peer-session/src/celld-peer.ts
function frameCelldPeerStream(stream) {
  const framed = framePeerStream(stream);
  const transportLifetime = new AbortController();
  const signal = AbortSignal.any([transportLifetime.signal, framed.signal]);
  let closing;
  const close = () => closing ??= Promise.resolve().then(async () => {
    transportLifetime.abort(new Error("PEER_CONNECTION_CLOSED"));
    await Promise.allSettled([framed.close(), Promise.resolve().then(() => stream.close())]);
  });
  void stream.closed.then(
    () => {
      transportLifetime.abort(new Error("PEER_CONNECTION_ENDED"));
      return close();
    },
    (reason) => {
      transportLifetime.abort(reason);
      return close();
    }
  );
  framed.signal.addEventListener("abort", () => {
    void close();
  }, { once: true });
  return { ...framed, signal, close };
}
function createCelldPeerTransport(options) {
  const connect = options.binding.connect.bind(options.binding);
  const { resolveEndpoint, takeInvitation } = options;
  return {
    async open({ peer, invitation }, { signal }) {
      signal.throwIfAborted();
      const endpoint = await resolveEndpoint(peer, signal);
      signal.throwIfAborted();
      const { nodeId, addrs, relay } = endpoint;
      if (!/^[0-9a-f]{64}$/u.test(nodeId)) throw new Error("CELLD_PEER_ENDPOINT_INVALID");
      const stream = invitation === void 0 ? await connect(nodeId, {
        ...addrs === void 0 ? {} : { addrs: [...addrs] },
        ...relay === void 0 ? {} : { relay }
      }) : await takeInvitation(peer, invitation, signal);
      try {
        signal.throwIfAborted();
        if (stream.remoteNodeId !== nodeId) throw new Error("CELLD_PEER_ENDPOINT_MISMATCH");
        return frameCelldPeerStream(stream);
      } catch (error) {
        await Promise.allSettled([Promise.resolve().then(() => stream.close()), stream.closed]);
        throw error;
      }
    }
  };
}

// packages/peer-session/src/celld-invitation.ts
function exactKeys(value, keys) {
  return value !== null && typeof value === "object" && Object.keys(value).length === keys.length && keys.every((key2) => Object.hasOwn(value, key2));
}
function key(value) {
  return typeof value === "string" && /^[0-9a-f]{64}$/u.test(value);
}
function routeText(value) {
  return typeof value === "string" && value.length > 0 && value.length <= 512 && [...value].every((character) => character.charCodeAt(0) > 32 && character.charCodeAt(0) !== 127);
}
function validateCelldPeerEndpoint(endpoint) {
  if (!endpoint || typeof endpoint !== "object" || !key(endpoint.nodeId) || Object.keys(endpoint).some((field) => field !== "nodeId" && field !== "addrs" && field !== "relay") || endpoint.relay !== void 0 && !routeText(endpoint.relay) || endpoint.addrs !== void 0 && (!Array.isArray(endpoint.addrs) || endpoint.addrs.length > 16 || !endpoint.addrs.every(routeText))) {
    throw new Error("CELLD_INVITATION_ENDPOINT_INVALID");
  }
}
function verifyMembers(authority, member, inviter) {
  if (authority.grant(member)?.reader !== true) throw new Error("CELLD_INVITATION_MEMBER_FORBIDDEN");
  const grant = authority.grant(inviter);
  if (grant?.reader !== true || !grant.administrator) throw new Error("CELLD_INVITATION_ADMINISTRATOR_REQUIRED");
}
async function signCelldApplicationInvitation(input) {
  const { memberPublicKey, inviter } = input;
  const endpoint = structuredClone(input.endpoint);
  if (!key(memberPublicKey)) throw new Error("CELLD_INVITATION_MEMBER_INVALID");
  validateCelldPeerEndpoint(endpoint);
  const authority = await verifyAuthorityBundle(input.authority);
  if (authority.current === null) throw new Error("CELLD_INVITATION_GENERATION_REQUIRED");
  verifyMembers(authority, memberPublicKey, inviter.publicKey);
  const payload = {
    version: 1,
    memberPublicKey,
    inviterPublicKey: inviter.publicKey,
    generation: authority.current.id,
    endpoint,
    authority: authority.bundle
  };
  const signature = await signDomain(DOMAINS.celldApplicationInvitation, encodePeerValue(payload), inviter.privateKey);
  return { payload, signature: bytesToHex(signature) };
}
async function acceptCelldApplicationInvitation(device, invitation) {
  const captured = structuredClone(invitation);
  if (!exactKeys(captured, ["payload", "signature"]) || typeof captured.signature !== "string" || !/^[0-9a-f]{128}$/u.test(captured.signature)) throw new Error("CELLD_INVITATION_INVALID");
  const { payload } = captured;
  if (!exactKeys(payload, ["version", "memberPublicKey", "inviterPublicKey", "generation", "endpoint", "authority"]) || payload.version !== 1 || !key(payload.inviterPublicKey) || !key(payload.generation)) {
    throw new Error("CELLD_INVITATION_INVALID");
  }
  if (payload.memberPublicKey !== device.identity.publicKey) throw new Error("CELLD_INVITATION_MEMBER_MISMATCH");
  validateCelldPeerEndpoint(payload.endpoint);
  const valid = await verifyDomain(
    DOMAINS.celldApplicationInvitation,
    encodePeerValue(payload),
    hexToBytes(captured.signature),
    hexToBytes(payload.inviterPublicKey)
  );
  if (!valid) throw new Error("CELLD_INVITATION_SIGNATURE_INVALID");
  const included = await verifyAuthorityBundle(payload.authority);
  if (included.current?.id !== payload.generation) throw new Error("CELLD_INVITATION_GENERATION_MISMATCH");
  verifyMembers(included, payload.memberPublicKey, payload.inviterPublicKey);
  const retained = await retainApplicationAuthority(device, included.bundle);
  verifyMembers(retained, payload.memberPublicKey, payload.inviterPublicKey);
  return {
    authority: retained.bundle,
    peer: { identity: payload.inviterPublicKey, route: payload.endpoint.nodeId },
    endpoint: payload.endpoint
  };
}

// packages/peer-session/src/celld-workspace-publication.ts
var publicationFields = ["sourceNodeId", "destinationNodeId", "workspaceId", "previousHead", "proposedHead"];
var payloadFields = ["version", "applicationId", "generation", "publisherPublicKey", ...publicationFields];
function exactKeys2(value, keys) {
  return value !== null && typeof value === "object" && Object.keys(value).length === keys.length && keys.every((key2) => Object.hasOwn(value, key2));
}
function hex(value, length) {
  return typeof value === "string" && value.length === length && /^[0-9a-f]+$/u.test(value);
}
function validatePublication(value) {
  if (!hex(value.sourceNodeId, 64) || !hex(value.destinationNodeId, 64) || value.sourceNodeId === value.destinationNodeId || typeof value.workspaceId !== "string" || !/^[a-zA-Z0-9_-]{1,128}$/u.test(value.workspaceId) || !hex(value.previousHead, 40) || !hex(value.proposedHead, 40) || value.previousHead === value.proposedHead) {
    throw new Error("CELLD_WORKSPACE_PUBLICATION_TRANSITION_INVALID");
  }
}
async function signCelldWorkspacePublication(input) {
  const transition = structuredClone(input.transition);
  if (!exactKeys2(transition, publicationFields)) throw new Error("CELLD_WORKSPACE_PUBLICATION_TRANSITION_INVALID");
  validatePublication(transition);
  const publisher = { ...input.publisher };
  const authority = await verifyAuthorityBundle(structuredClone(input.authority));
  if (!authority.current) throw new Error("CELLD_WORKSPACE_PUBLICATION_GENERATION_REQUIRED");
  if (authority.grant(publisher.publicKey)?.publisher !== true) throw new Error("CELLD_WORKSPACE_PUBLICATION_FORBIDDEN");
  const payload = {
    version: 1,
    applicationId: authority.bundle.descriptor.payload.applicationId,
    generation: authority.current.id,
    publisherPublicKey: publisher.publicKey,
    ...transition
  };
  const signature = bytesToHex(await signDomain(DOMAINS.celldWorkspacePublication, encodePeerValue(payload), publisher.privateKey));
  return { payload, signature };
}
async function verifyCelldWorkspacePublication(input) {
  const expected = structuredClone(input.transition);
  if (!exactKeys2(expected, publicationFields)) throw new Error("CELLD_WORKSPACE_PUBLICATION_TRANSITION_INVALID");
  validatePublication(expected);
  const proof = structuredClone(input.publication);
  if (!exactKeys2(proof, ["payload", "signature"]) || !hex(proof.signature, 128) || !exactKeys2(proof.payload, payloadFields)) throw new Error("CELLD_WORKSPACE_PUBLICATION_INVALID");
  const { payload, signature } = proof;
  if (payload.version !== 1 || !hex(payload.publisherPublicKey, 64) || publicationFields.some((field) => payload[field] !== expected[field])) {
    throw new Error("CELLD_WORKSPACE_PUBLICATION_TRANSITION_MISMATCH");
  }
  const authority = await verifyAuthorityBundle(structuredClone(input.authority));
  if (payload.applicationId !== authority.bundle.descriptor.payload.applicationId || !authority.current || payload.generation !== authority.current.id) {
    throw new Error("CELLD_WORKSPACE_PUBLICATION_AUTHORITY_CHANGED");
  }
  if (authority.grant(payload.publisherPublicKey)?.publisher !== true) throw new Error("CELLD_WORKSPACE_PUBLICATION_FORBIDDEN");
  const valid = await verifyDomain(
    DOMAINS.celldWorkspacePublication,
    encodePeerValue(payload),
    hexToBytes(signature),
    hexToBytes(payload.publisherPublicKey)
  );
  if (!valid) throw new Error("CELLD_WORKSPACE_PUBLICATION_SIGNATURE_INVALID");
  return payload.publisherPublicKey;
}

// packages/peer-session/src/celld-dolt-carrier.ts
var maxHeader = 4096;
var maxBody = 1 << 30;
var code = /^[A-Z][A-Z0-9_]{0,127}$/u;
var digest = /^[a-f0-9]{64}$/u;
var head = /^[a-f0-9]{40}$/u;
var CarrierReader = class {
  #reader;
  #rest = new Uint8Array(0);
  constructor(stream) {
    this.#reader = stream.readable.getReader();
  }
  async read(size) {
    if (!Number.isSafeInteger(size) || size < 0 || size > maxBody) throw new Error("CELLD_DOLT_PACKET_LIMIT");
    const result = new Uint8Array(size);
    let at = 0;
    while (at < size) {
      if (this.#rest.byteLength === 0) {
        const chunk = await this.#reader.read();
        if (chunk.done) throw new Error("CELLD_DOLT_PACKET_TRUNCATED");
        this.#rest = chunk.value;
      }
      const count = Math.min(size - at, this.#rest.byteLength);
      result.set(this.#rest.subarray(0, count), at);
      this.#rest = this.#rest.subarray(count);
      at += count;
    }
    return result;
  }
  async header() {
    const prefix = await this.read(4);
    const size = new DataView(prefix.buffer).getUint32(0);
    if (size === 0 || size > maxHeader) throw new Error("CELLD_DOLT_HEADER_LIMIT");
    return decodePeerValue(await this.read(size));
  }
  async eof() {
    if (this.#rest.byteLength !== 0 || !(await this.#reader.read()).done)
      throw new Error("CELLD_DOLT_PACKET_TRAILING_BYTES");
  }
  release() {
    this.#reader.releaseLock();
  }
};
async function write(stream, header, body) {
  const encoded = encodePeerValue(header);
  if (encoded.byteLength > maxHeader) throw new Error("CELLD_DOLT_HEADER_LIMIT");
  if (body !== void 0 && body.byteLength > maxBody) throw new Error("CELLD_DOLT_PACKET_LIMIT");
  const prefix = new Uint8Array(4);
  new DataView(prefix.buffer).setUint32(0, encoded.byteLength);
  const writer = stream.writable.getWriter();
  try {
    await writer.write(prefix);
    await writer.write(encoded);
    if (body !== void 0) await writer.write(body);
    await writer.close();
  } finally {
    writer.releaseLock();
  }
}
async function serveCelldDoltPublication(stream, authorize) {
  const reader = new CarrierReader(stream);
  try {
    const request = await reader.header();
    if (request?.v !== 1 || !["grant", "push", "missing", "blob", "publish"].includes(request.kind) || !Number.isSafeInteger(request.size) || request.size < 0 || request.size > maxBody || request.kind !== "blob" && request.digest !== void 0 || request.kind === "blob" && (typeof request.digest !== "string" || !digest.test(request.digest)) || (request.kind === "push" ? request.size === 0 : request.kind !== "blob" && request.size !== 0) || request.proof === null || typeof request.proof !== "object") throw new Error("CELLD_DOLT_REQUEST_INVALID");
    if (request.proof.payload?.sourceNodeId !== stream.remoteNodeId)
      throw new Error("CELLD_WORKSPACE_PUBLICATION_SOURCE_MISMATCH");
    const handler = await authorize({
      peer: stream.remoteNodeId,
      proof: request.proof,
      kind: request.kind,
      bytes: request.size,
      ...request.digest === void 0 ? {} : { digest: request.digest }
    });
    const bytes = request.kind === "push" || request.kind === "blob" ? await reader.read(request.size) : new Uint8Array(0);
    await reader.eof();
    if (request.kind === "grant") {
      await write(stream, { v: 1, kind: "granted", value: await handler.grant() });
      return;
    }
    let result;
    if (request.kind === "push") result = await handler.push(bytes);
    else if (request.kind === "missing" && handler.missing) result = encodePeerValue(await handler.missing());
    else if (request.kind === "publish" && handler.publish) result = encodePeerValue(await handler.publish());
    else if (request.kind === "blob" && handler.blob && request.digest !== void 0) {
      await handler.blob(request.digest, bytes);
      result = new Uint8Array(0);
    } else throw new Error("CELLD_WORKSPACE_HISTORY_OPERATION_UNAVAILABLE");
    await write(stream, { v: 1, kind: "bytes", size: result.byteLength }, result);
  } catch (error) {
    const nativeCode = error?.code;
    const message = typeof nativeCode === "string" ? nativeCode : error instanceof Error ? error.message : "";
    try {
      await write(stream, { v: 1, kind: "refused", code: code.test(message) ? message : "CELLD_DOLT_PUBLICATION_REFUSED" });
    } catch {
    }
  } finally {
    reader.release();
    await stream.close().catch(() => void 0);
  }
}
function celldDoltPublicationPeer(binding, destination, input) {
  const proof = structuredClone(input), endpoint = structuredClone(destination);
  const exchange = async (kind, bytes, contentDigest) => {
    const stream = await binding.connect(endpoint.nodeId, {
      ...endpoint.addrs === void 0 ? {} : { addrs: [...endpoint.addrs] },
      ...endpoint.relay === void 0 ? {} : { relay: endpoint.relay }
    });
    const reader = new CarrierReader(stream);
    let writer;
    try {
      if (stream.remoteNodeId !== endpoint.nodeId) throw new Error("CELLD_PEER_ENDPOINT_MISMATCH");
      writer = write(stream, {
        v: 1,
        kind,
        proof,
        size: bytes?.byteLength ?? 0,
        ...contentDigest === void 0 ? {} : { digest: contentDigest }
      }, bytes);
      void writer.catch(() => stream.close().catch(() => void 0));
      const response = await reader.header();
      if (response?.v !== 1) throw new Error("CELLD_DOLT_RESPONSE_INVALID");
      if (response.kind === "refused") {
        if (!code.test(response.code)) throw new Error("CELLD_DOLT_RESPONSE_INVALID");
        throw new Error(response.code);
      }
      let result;
      if (kind === "grant" && response.kind === "granted") result = response.value;
      else if (kind !== "grant" && response.kind === "bytes") result = await reader.read(response.size);
      else throw new Error("CELLD_DOLT_RESPONSE_INVALID");
      await reader.eof();
      await writer;
      return result;
    } finally {
      reader.release();
      await stream.close().catch(() => void 0);
      await writer?.catch(() => void 0);
    }
  };
  return Object.freeze({
    async grant() {
      const result = await exchange("grant");
      if (result instanceof Uint8Array || result?.kind !== "grant" && result?.kind !== "staged" && result?.kind !== "applied")
        throw new Error("CELLD_DOLT_RESPONSE_INVALID");
      return result;
    },
    async push(bytes) {
      const result = await exchange("push", bytes);
      if (!(result instanceof Uint8Array)) throw new Error("CELLD_DOLT_RESPONSE_INVALID");
      return result;
    },
    async missing() {
      const result = await exchange("missing");
      if (!(result instanceof Uint8Array)) throw new Error("CELLD_DOLT_RESPONSE_INVALID");
      const hashes = decodePeerValue(result);
      if (!Array.isArray(hashes) || hashes.some((hash) => typeof hash !== "string" || !digest.test(hash)) || new Set(hashes).size !== hashes.length) throw new Error("CELLD_DOLT_RESPONSE_INVALID");
      return hashes;
    },
    async blob(contentDigest, bytes) {
      const result = await exchange("blob", bytes, contentDigest);
      if (!(result instanceof Uint8Array) || result.byteLength !== 0) throw new Error("CELLD_DOLT_RESPONSE_INVALID");
    },
    async publish() {
      const result = await exchange("publish");
      if (!(result instanceof Uint8Array)) throw new Error("CELLD_DOLT_RESPONSE_INVALID");
      const revision = decodePeerValue(result);
      if (typeof revision !== "string" || !head.test(revision) || revision !== proof.payload.proposedHead)
        throw new Error("CELLD_DOLT_RESPONSE_INVALID");
      return revision;
    }
  });
}

// packages/peer-session/src/celld.ts
async function importCelldSigningIdentity(publicKey, pkcs8Hex) {
  if (pkcs8Hex === void 0) throw new Error("CELLD_SIGNING_SECRET_MISSING");
  if (pkcs8Hex.length < 2 || pkcs8Hex.length > 512 || !/^(?:[0-9a-f]{2})+$/u.test(pkcs8Hex)) {
    throw new Error("CELLD_SIGNING_SECRET_INVALID");
  }
  const bytes = hexToBytes(pkcs8Hex);
  try {
    const privateKey = await importEd25519PrivateKey(bytes, false);
    const identity = { publicKey, privateKey };
    await verifyDeviceSigner(identity);
    return Object.freeze(identity);
  } catch {
    throw new Error("CELLD_SIGNING_SECRET_INVALID");
  } finally {
    bytes.fill(0);
  }
}
async function openCelldDevice(options) {
  const store = new CelldBytesStore(options.storage, options.metadataLimits);
  const openDataStorage = options.openDataStorage;
  try {
    return await openApplicationDevice({
      store,
      ...options.create === void 0 ? {} : { create: options.create },
      ...options.managedSigner === void 0 ? {} : { managedSigner: options.managedSigner },
      ...openDataStorage === void 0 ? {} : {
        openStorage: () => {
          const data = new CelldBytesStore(openDataStorage(), options.dataLimits);
          return { store: data, close: () => data.close() };
        }
      },
      close: () => store.close()
    });
  } catch (error) {
    store.close();
    throw error;
  }
}
export {
  CelldBytesStore,
  acceptCelldApplicationInvitation,
  celldDoltPublicationPeer,
  createCelldPeerTransport,
  frameCelldPeerStream,
  importCelldSigningIdentity,
  openPeerApplication as openCelldApplication,
  openCelldApplicationControl,
  openCelldDevice,
  serveCelldDoltPublication,
  signCelldApplicationInvitation,
  signCelldWorkspacePublication,
  verifyCelldWorkspacePublication
};
