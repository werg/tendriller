import { type ContentAddressedStore } from '../../records/src/index.js';
export declare const STD_PERMISSIONS_SOURCE: string;
export declare const STD_KEYS_SOURCE: string;
export declare const STD_FINALITY_SOURCE: string;
export declare const STD_PUBLICATIONS_SOURCE: string;
export declare const STD_RLS_SOURCE: string;
export declare const STD_SQL_SOURCE: string;
export declare const STANDARD_MODULE_SOURCES: Readonly<Record<string, string>>;
export declare const STANDARD_MODULE_IMPORTS: Readonly<Record<string, string>>;
/** Seed all standard audited ES modules into CAS (public partition) and return their pinned import map entries. */
export declare function seedStandardModules(cas: ContentAddressedStore): Promise<Record<string, string>>;
