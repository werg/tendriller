import type { BytesStore } from '../../records/src/index.js';
import { type Signed, type SigningIdentity } from '../../authority/src/index.js';
import { type BlobGetOptions, type BlobInfo, type BlobPutOptions, type BlobReference, type ContentGetOptions, type ContentPutBytesOptions, type ContentPutOptions, type ContentReadBytesOptions } from './content-bytes.js';
export { CONTENT_CHUNK_BYTES, MAX_BLOB_BYTES, MAX_BLOB_CHUNKS, isPublicBlobReference, isPrivateContentReference } from './content-bytes.js';
export type { BlobGetOptions, BlobInfo, BlobPutOptions, BlobReference, ContentGetOptions, ContentPutBytesOptions, ContentPutOptions, ContentReadBytesOptions, PublicBlobReference, } from './content-bytes.js';
export interface ContentAuthority {
    readonly applicationId: string;
    isReader(publicKey: string): boolean;
    currentEpoch(): number;
    epochKey(epoch: number): Uint8Array | null;
}
export declare const MAX_CONTENT_CHUNKS: number;
/** Canonical encrypted-envelope bytes: 64 KiB plaintext, AES tag, hex encoding and bounded metadata. */
export declare const MAX_CONTENT_ENCRYPTED_CHUNK_BYTES: number;
export declare const MAX_CONTENT_MANIFEST_BYTES: number;
export interface ContentReference {
    readonly profile: 'authored-content-v1';
    readonly applicationId: string;
    readonly id: string;
    readonly epoch: number;
    readonly bytes: number;
    readonly mediaType: string;
}
export interface ContentManifest {
    readonly stageId: string;
    readonly reference: Omit<ContentReference, 'id'>;
    readonly chunks: readonly {
        readonly hash: string;
        readonly bytes: number;
    }[];
}
export type ContentRetention = Signed<{
    readonly reference: ContentReference;
    readonly peer: string;
    readonly storageId: string;
}>;
export interface ContentOptions {
    readonly signal?: AbortSignal;
}
export interface ContentSource {
    manifest(reference: ContentReference, options?: ContentOptions): Promise<ContentManifest | null>;
    chunk(reference: ContentReference, index: number, options?: ContentOptions): Promise<Uint8Array | null>;
    retained?(reference: ContentReference, options?: ContentOptions): Promise<ContentRetention>;
    blobInfo?(hash: string, options?: ContentOptions): Promise<BlobInfo | null>;
    blobChunk?(hash: string, index: number, options?: ContentOptions): Promise<Uint8Array | null>;
}
export interface ContentUpload {
    readonly id: string;
    write(index: number, bytes: Uint8Array): Promise<void>;
    progress(): Promise<{
        readonly bytes: number;
        readonly storedBytes: number;
        readonly missingChunks: readonly number[];
    }>;
    commit(): Promise<ContentReference>;
    /** Release this upload's staging records; an already committed object remains independently retained. */
    discard(): Promise<void>;
}
export declare function assertContentReference(value: unknown): asserts value is ContentReference;
export declare function assertContentManifest(value: unknown): asserts value is ContentManifest;
export declare function assertContentRetention(value: unknown): asserts value is ContentRetention;
export declare function assertBlobInfo(value: unknown): asserts value is BlobInfo;
/** Durable encrypted content is independent of operation execution, peer delivery and finality. */
export declare class ApplicationContent {
    #private;
    constructor(options: {
        readonly store: BytesStore;
        readonly authority: ContentAuthority;
        readonly identity: SigningIdentity;
        readonly storageId: string;
    });
    attachSource(id: string, source: ContentSource): () => void;
    stage(options: {
        readonly bytes: number;
        readonly mediaType?: string;
    }): Promise<ContentUpload>;
    resumeUpload(id: string): Promise<ContentUpload>;
    read(input: ContentReference, options?: ContentOptions): AsyncIterable<Uint8Array>;
    /** Transfer/check the entire encrypted object before claiming local retention. */
    retain(input: ContentReference, options?: ContentOptions): Promise<ContentRetention>;
    verifyRetention(input: ContentReference, receipt: ContentRetention, expectedPeer?: string): Promise<void>;
    /** Ask attached sources to retain the object; these signed availability facts are not finality. */
    retention(input: ContentReference, options?: ContentOptions): Promise<readonly ContentRetention[]>;
    retained(input: ContentReference): Promise<readonly ContentRetention[]>;
    discard(input: ContentReference): Promise<void>;
    /** Store raw bytes locally indexed by SHA-256 hash so peers can recover historical blobs by hash. */
    putBlob(input: Uint8Array, options?: BlobPutOptions): Promise<BlobInfo>;
    hasBlob(hash: string): Promise<boolean>;
    /** Retrieve a SHA-256 hash-addressed blob locally, falling back to connected peers and verifying the digest. */
    getBlob(hash: string, options?: BlobGetOptions): Promise<Uint8Array | null>;
    deleteBlob(hash: string): Promise<void>;
    /** Serve only verified local bytes. Serving never recursively consults remote sources. */
    source(): ContentSource;
    putBytes(bytes: Uint8Array, options?: ContentPutBytesOptions): Promise<ContentReference>;
    readBytes(reference: ContentReference, options: ContentReadBytesOptions): Promise<Uint8Array>;
    /** Unified lazy-pull blob write: supports both public raw-SHA-256 blobs and private epoch-encrypted blobs. */
    put(bytes: Uint8Array, options?: ContentPutOptions): Promise<BlobReference>;
    /** Unified lazy-pull blob read: accepts a raw SHA-256 hex hash, a PublicBlobReference, or a private ContentReference. */
    get(target: BlobReference | string, options?: ContentGetOptions): Promise<Uint8Array | null>;
    close(): Promise<void>;
}
