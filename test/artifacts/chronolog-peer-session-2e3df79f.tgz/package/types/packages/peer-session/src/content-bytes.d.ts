import type { ContentReference, ContentUpload } from './content.js';
export declare const CONTENT_CHUNK_BYTES = 65536;
export declare const MAX_CONTENT_BYTES: number;
export declare const MAX_BLOB_BYTES: number;
export declare const MAX_BLOB_CHUNKS: number;
export interface ContentPutBytesOptions {
    readonly mediaType?: string;
    readonly signal?: AbortSignal;
}
export interface ContentReadBytesOptions {
    readonly maxBytes: number;
    readonly signal?: AbortSignal;
}
export interface BlobInfo {
    readonly hash: string;
    readonly bytes: number;
}
export interface BlobPutOptions {
    readonly signal?: AbortSignal;
}
export interface BlobGetOptions {
    readonly expectedBytes?: number;
    readonly maxBytes?: number;
    readonly localOnly?: boolean;
    readonly cache?: boolean;
    readonly signal?: AbortSignal;
}
export interface PublicBlobReference {
    readonly profile: 'chronolog-blob-v2';
    readonly visibility: 'public';
    readonly hash: string;
    readonly bytes: number;
    readonly mediaType: string;
}
export type BlobReference = PublicBlobReference | ContentReference;
export interface ContentPutOptions {
    readonly visibility?: 'public' | 'private';
    readonly mediaType?: string;
    readonly deduplicate?: boolean;
    readonly signal?: AbortSignal;
}
export interface ContentGetOptions {
    readonly expectedBytes?: number;
    readonly maxBytes?: number;
    readonly localOnly?: boolean;
    readonly cache?: boolean;
    readonly signal?: AbortSignal;
}
export declare function isPublicBlobReference(value: unknown): value is PublicBlobReference;
export declare function isPrivateContentReference(value: unknown): value is ContentReference;
interface ByteContent {
    stage(options: {
        readonly bytes: number;
        readonly mediaType?: string;
    }): Promise<ContentUpload>;
    read(reference: ContentReference, options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<Uint8Array>;
}
/** Shared by the native owner and the page facade; Worker messages stay one chunk each. */
export declare function putContentBytes(content: Pick<ByteContent, 'stage'>, bytes: Uint8Array, options?: ContentPutBytesOptions): Promise<ContentReference>;
/** Allocate once, before fetching, under the caller's explicit byte ceiling. */
export declare function readContentBytes(content: Pick<ByteContent, 'read'>, reference: ContentReference, options: ContentReadBytesOptions): Promise<Uint8Array>;
export {};
