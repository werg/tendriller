import {
  APPLICATION_OWNER_PROTOCOL,
  forwardSessionEvents
} from "./chunk-3DYQXBHD.mjs";
import {
  CONTENT_CHUNK_BYTES,
  MAX_BLOB_BYTES,
  check
} from "./chunk-RHNTU73B.mjs";
import {
  awaitOwnedTask
} from "./chunk-KSC4KBWO.mjs";

// packages/peer-session/src/owner-types.ts
var APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES = ["commands", "queries", "events", "content", "signals", "operations", "diagnostics", "finality", "extensions", "replication"];

// packages/peer-session/src/session-owner.ts
var isArray = (value) => Array.isArray(value);
var CONTROLS = /* @__PURE__ */ new Set(["close", "attachment.ping", "attachment.suspend", "attachment.resume", "view.release", "content.cancel", "content.blobAbortWrite", "content.blobCloseRead", "signals.close", "upload.discard"]);
function requestBudget(value) {
  let nodes = 0, bytes = 0;
  const walk = (item, depth) => {
    check(++nodes <= 16384 && depth <= 32, "ENDPOINT_REQUEST_SIZE_LIMIT");
    if (item instanceof Uint8Array) bytes += item.length;
    else if (typeof item === "string") bytes += item.length * 3;
    else if (Array.isArray(item)) for (const child of item) walk(child, depth + 1);
    else if (item !== null && typeof item === "object") for (const [key, child] of Object.entries(item)) {
      bytes += key.length * 3;
      walk(child, depth + 1);
    }
    else check(item === null || typeof item === "number" || typeof item === "boolean" || typeof item === "bigint" || item === void 0, "ENDPOINT_REQUEST_INVALID");
    check(bytes <= 4 * 1024 * 1024, "ENDPOINT_REQUEST_SIZE_LIMIT");
  };
  walk(value, 0);
}
function checkedContext(value) {
  check(
    value !== null && typeof value === "object" && !Array.isArray(value) && Object.entries(value).every(
      ([key, item]) => ["viewId", "documentPath", "publicationId", "runId"].includes(key) && typeof item === "string" && item.length > 0 && item.length <= (key === "documentPath" ? 1024 : 128) && ![...item].some((character) => character.charCodeAt(0) < 32)
    ),
    "APPLICATION_ENDPOINT_CONTEXT_INVALID"
  );
  return structuredClone(value);
}
function limit(value, fallback, maximum) {
  const result = value ?? fallback;
  check(Number.isSafeInteger(result) && result > 0 && result <= maximum, "OWNER_CONFIGURATION_INVALID");
  return result;
}
function createApplicationOwner(session, options = {}) {
  const ownerInstanceId = crypto.randomUUID(), maxAttachments = limit(options.maxAttachments, 16, 64);
  const attachments = /* @__PURE__ */ new Map();
  const heldViewIds = /* @__PURE__ */ new Map();
  let closed = false, closing;
  const owner = {
    ownerInstanceId,
    session,
    endpoints: () => [...attachments.values()].map((value) => ({ ...value.binding(), state: value.state() })),
    close: () => closing ??= (async () => {
      closed = true;
      for (const attachment of [...attachments.values()]) attachment.close();
      await session.close();
    })(),
    attach(endpoint, policy = {}) {
      check(!closed && attachments.size < maxAttachments, "OWNER_ATTACHMENT_LIMIT");
      const endpointId = crypto.randomUUID(), endpointIncarnation = crypto.randomUUID(), lifetime = new AbortController();
      const views = /* @__PURE__ */ new Map(), uploads = /* @__PURE__ */ new Map(), completedUploads = /* @__PURE__ */ new Map(), readers = /* @__PURE__ */ new Map(), blobWrites = /* @__PURE__ */ new Map(), blobReads = /* @__PURE__ */ new Map(), streams = /* @__PURE__ */ new Map(), pending = /* @__PURE__ */ new Map();
      let effective = policy, attachment = "", initialized = false, detached = false, suspended = false, highestRequest = 0, viewReservations = 0, uploadReservations = 0, lastReceived = performance.now(), context = policy.context ?? {};
      let claimedViewId;
      let stopStatus, stopChange, stopExtension;
      const physical = endpoint;
      const binding = () => ({
        ownerInstanceId,
        endpointId,
        endpointIncarnation,
        context: structuredClone(context),
        evidence: "owner-bound",
        contextEvidence: effective.contextEvidence ?? "caller-asserted",
        capabilities: [...effective.capabilities ?? APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES],
        ...effective.identity === void 0 ? {} : { identity: structuredClone(effective.identity) }
      });
      const has = (capability) => (effective.capabilities ?? APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES).includes(capability);
      const allow = (capability) => check(has(capability), "ENDPOINT_CAPABILITY_FORBIDDEN");
      const post = (message) => {
        if (!detached) endpoint.postMessage(message);
      };
      const releaseResources = () => {
        for (const view of views.values()) view.release();
        views.clear();
        for (const reader of readers.values()) {
          reader.lifetime.abort();
          void reader.iterator.return?.().catch(() => void 0);
        }
        ;
        readers.clear();
        blobWrites.clear();
        blobReads.clear();
        for (const stream of streams.values()) {
          stream.lifetime.abort();
          void stream.iterator.return?.().catch(() => void 0);
        }
        ;
        streams.clear();
      };
      const close = () => {
        if (detached) return;
        try {
          post({ protocol: APPLICATION_OWNER_PROTOCOL, attachment, kind: "notice", topic: "closed", value: "ENDPOINT_CLOSED" });
        } catch {
        }
        detached = true;
        clearInterval(expiry);
        lifetime.abort(new Error("ENDPOINT_CLOSED"));
        for (const request of pending.values()) request.lifetime.abort(new Error("ENDPOINT_CLOSED"));
        pending.clear();
        endpoint.removeEventListener("message", receive);
        physical.removeEventListener("close", physicalClose);
        physical.removeEventListener("messageerror", physicalClose);
        physical.off?.("close", close);
        physical.off?.("messageerror", close);
        if (claimedViewId !== void 0 && heldViewIds.get(claimedViewId) === endpointId) heldViewIds.delete(claimedViewId);
        stopStatus?.();
        stopChange?.();
        stopExtension?.();
        releaseResources();
        uploads.clear();
        completedUploads.clear();
        attachments.delete(endpointId);
        endpoint.close?.();
        if (!closed && attachments.size === 0 && options.lastClient === "shutdown") void owner.close();
      };
      const physicalClose = () => close();
      const active = (request) => {
        request.signal.throwIfAborted();
        check(!detached, "ENDPOINT_CLOSED");
      };
      const invoke = async (method, args, request) => {
        active(request);
        if (method === "hello") {
          check(!initialized && typeof args[0] === "object" && args[0] !== null, "ENDPOINT_HANDSHAKE_INVALID");
          const handshake = args[0];
          check(handshake.applicationId === session.applicationId, "ENDPOINT_APPLICATION_MISMATCH");
          effective = { ...policy, ...options.authorize?.(handshake) };
          limit(effective.maxRequests, 32, 64);
          limit(effective.maxViews, 8, 32);
          check(
            effective.capabilities === void 0 || isArray(effective.capabilities) && effective.capabilities.length <= APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES.length && new Set(effective.capabilities).size === effective.capabilities.length && effective.capabilities.every((capability) => APPLICATION_DEFAULT_ATTACHMENT_CAPABILITIES.includes(capability)),
            "OWNER_CONFIGURATION_INVALID"
          );
          const requested = checkedContext(effective.context ?? handshake.context ?? {});
          let viewId = requested.viewId ?? crypto.randomUUID();
          while (heldViewIds.has(viewId)) viewId = crypto.randomUUID();
          heldViewIds.set(viewId, endpointId);
          claimedViewId = viewId;
          context = { ...requested, viewId };
          initialized = true;
          stopStatus = session.onStatus((value) => {
            if (!suspended) post({ protocol: APPLICATION_OWNER_PROTOCOL, attachment, kind: "notice", topic: "status", value });
          });
          stopChange = session.onChange((value) => {
            if (!suspended) post({ protocol: APPLICATION_OWNER_PROTOCOL, attachment, kind: "notice", topic: "change", value });
          });
          if (has("extensions")) stopExtension = options.extensions?.subscribe?.((value) => {
            if (!suspended) post({ protocol: APPLICATION_OWNER_PROTOCOL, attachment, kind: "notice", topic: "extension", value });
          });
          const description = await session.describe();
          return { applicationId: session.applicationId, identity: session.identity, definition: description, status: session.status, binding: binding() };
        }
        if (method === "close") return null;
        check(initialized, "ENDPOINT_HANDSHAKE_REQUIRED");
        if (method === "attachment.ping") return { ...binding(), state: suspended ? "suspended" : "active" };
        if (method === "attachment.suspend") {
          suspended = true;
          for (const work of pending.values()) if (!work.control) work.lifetime.abort(new Error("ENDPOINT_SUSPENDED"));
          releaseResources();
          return null;
        }
        if (method === "attachment.resume") {
          suspended = false;
          return session.status;
        }
        if (method === "view.release") {
          const id = String(args[0]), view = views.get(id);
          views.delete(id);
          view?.release();
          return null;
        }
        if (method === "content.cancel") {
          const id = String(args[0]), reader = readers.get(id);
          readers.delete(id);
          reader?.lifetime.abort();
          await reader?.iterator.return?.();
          return null;
        }
        if (method === "content.blobAbortWrite") {
          blobWrites.delete(String(args[0]));
          return null;
        }
        if (method === "content.blobCloseRead") {
          blobReads.delete(String(args[0]));
          return null;
        }
        if (method === "signals.close") {
          const id = String(args[0]), stream = streams.get(id);
          streams.delete(id);
          stream?.lifetime.abort();
          await stream?.iterator.return?.();
          return null;
        }
        if (method === "upload.discard") {
          const id = String(args[0]), upload = uploads.get(id) ?? completedUploads.get(id);
          uploads.delete(id);
          completedUploads.delete(id);
          await upload?.discard();
          return null;
        }
        check(!suspended, "ENDPOINT_SUSPENDED");
        if (method === "submit") {
          allow("commands");
          check(effective.rawSubmit ?? effective.commands === void 0, "ENDPOINT_RAW_SUBMIT_FORBIDDEN");
          const operation = await session.submit(args[0]);
          return { id: operation.id, operationId: operation.operationId };
        }
        if (method === "command") {
          allow("commands");
          const name = String(args[0]);
          check(effective.commands === void 0 || effective.commands.includes(name), "ENDPOINT_COMMAND_FORBIDDEN");
          const input = options.prepareCommand === void 0 ? args[1] : options.prepareCommand(binding(), name, args[1]);
          const operation = await session.command(name, input, args[2]);
          return { id: operation.id, operationId: operation.operationId };
        }
        if (method === "query") {
          allow("queries");
          const name = String(args[0]);
          check(effective.queries === void 0 || effective.queries.includes(name), "ENDPOINT_QUERY_FORBIDDEN");
          return session.query(name, args[1], { signal: request.signal });
        }
        if (method === "topic") {
          allow("queries");
          return session.topic(String(args[0]));
        }
        if (method === "readEvents") {
          allow("events");
          return session.readEvents(args[0]);
        }
        if (method === "readView") {
          check(has("queries") || has("events"), "ENDPOINT_CAPABILITY_FORBIDDEN");
          check(views.size + viewReservations < (effective.maxViews ?? 8), "ENDPOINT_VIEW_LIMIT");
          viewReservations++;
          let view, deferred = false;
          const opening = session.readView(args[0]);
          try {
            view = await awaitOwnedTask(request.signal, () => opening);
            active(request);
            const id = crypto.randomUUID();
            views.set(id, view);
            const result = { id, revision: view.revision };
            view = void 0;
            return result;
          } catch (error) {
            if (request.signal.aborted && view === void 0) {
              deferred = true;
              void opening.then((late) => late.release()).catch(() => void 0).finally(() => {
                viewReservations--;
              });
            }
            throw error;
          } finally {
            if (!deferred) viewReservations--;
            view?.release();
          }
        }
        if (method === "view.topic" || method === "view.query" || method === "view.events") {
          const view = views.get(String(args[0]));
          check(view !== void 0, "ENDPOINT_VIEW_STALE");
          if (method === "view.topic") {
            allow("queries");
            return view.topic(String(args[1]));
          }
          if (method === "view.query") {
            allow("queries");
            return view.query(String(args[1]), args[2]);
          }
          allow("events");
          return view.readEvents(args[1]);
        }
        if (method === "operation.retry") {
          allow("operations");
          const operation = await session.operations.retry(String(args[0]));
          return { id: operation.id, operationId: operation.operationId };
        }
        if (method === "operation.get") {
          allow("operations");
          const operation = session.operations.get(String(args[0]));
          return operation === null ? null : { id: operation.id, operationId: operation.operationId, inspection: operation.inspect() };
        }
        if (method === "operation.inspect") {
          allow("operations");
          return session.inspectOperation(String(args[0]));
        }
        if (method === "operation.wait") {
          allow("operations");
          const operation = session.operations.get(String(args[0]));
          check(operation !== null, "OPERATION_UNKNOWN");
          const fact = args[1];
          check(fact === "materialized" || fact === "retained" || fact === "finalized", "OPERATION_FACT_INVALID");
          return operation[fact]({ signal: request.signal, timeoutMs: Number(args[2] ?? 3e4) });
        }
        if (method === "diagnostics.peers") {
          allow("diagnostics");
          return session.diagnostics();
        }
        if (method === "endpoints.list") {
          allow("diagnostics");
          return owner.endpoints();
        }
        if (method === "facts.export") {
          allow("replication");
          return session.exportFacts(args[0]);
        }
        if (method === "facts.merge") {
          allow("replication");
          return session.mergeFacts(args[0]);
        }
        if (method === "finality.status") {
          allow("finality");
          return session.finality.status();
        }
        if (method === "finality.createCheckpoint") {
          allow("finality");
          return session.finality.createCheckpoint(args[0]);
        }
        if (method === "finality.submitCheckpoints") {
          allow("finality");
          return session.finality.submitCheckpoints(args[0]);
        }
        if (method === "extension.call") {
          allow("extensions");
          check(options.extensions !== void 0, "ENDPOINT_METHOD_UNKNOWN");
          const name = args[0], input = args[1];
          check(typeof name === "string" && /^[A-Za-z][A-Za-z0-9_.:-]{0,127}$/u.test(name) && Array.isArray(input), "ENDPOINT_REQUEST_INVALID");
          return options.extensions.call(name, input, { endpoint: binding(), signal: request.signal });
        }
        if (["content.retain", "content.retention", "content.retained", "content.discard"].includes(method)) {
          allow("content");
          const reference = args[0];
          if (method === "content.retain") return session.content.retain(reference, { signal: request.signal });
          if (method === "content.retention") return session.content.retention(reference, { signal: request.signal });
          if (method === "content.retained") return session.content.retained(reference);
          return session.content.discard(reference);
        }
        if (method === "content.stage") {
          allow("content");
          check(uploads.size + uploadReservations < 4, "ENDPOINT_UPLOAD_LIMIT");
          uploadReservations++;
          let upload;
          try {
            upload = await session.content.stage(args[0]);
            active(request);
            uploads.set(upload.id, upload);
            const id = upload.id;
            upload = void 0;
            return id;
          } finally {
            uploadReservations--;
            if (upload !== void 0) await upload.discard();
          }
        }
        if (["upload.write", "upload.progress", "upload.commit"].includes(method)) {
          allow("content");
          const id = String(args[0]), upload = uploads.get(id) ?? completedUploads.get(id);
          check(upload !== void 0, "CONTENT_UPLOAD_UNKNOWN");
          if (method === "upload.write") {
            check(args[2] instanceof Uint8Array && args[2].length <= 65536, "CONTENT_CHUNK_LIMIT");
            return upload.write(Number(args[1]), args[2]);
          }
          if (method === "upload.progress") return upload.progress();
          const reference = await upload.commit();
          uploads.delete(id);
          completedUploads.set(id, upload);
          while (completedUploads.size > 32) completedUploads.delete(completedUploads.keys().next().value);
          return reference;
        }
        if (method === "content.openRead") {
          allow("content");
          check(readers.size < 4, "ENDPOINT_READER_LIMIT");
          const id = crypto.randomUUID(), owned = new AbortController();
          const iterator = session.content.read(args[0], { signal: AbortSignal.any([owned.signal, lifetime.signal]) })[Symbol.asyncIterator]();
          readers.set(id, { iterator, lifetime: owned, busy: false });
          return id;
        }
        if (method === "content.next") {
          allow("content");
          const id = String(args[0]), reader = readers.get(id);
          check(reader !== void 0 && !reader.busy, "CONTENT_READER_UNKNOWN");
          reader.busy = true;
          const abort = () => {
            reader.lifetime.abort();
            readers.delete(id);
          };
          request.signal.addEventListener("abort", abort, { once: true });
          try {
            const next = await reader.iterator.next();
            active(request);
            if (next.done) {
              readers.delete(id);
              return null;
            }
            check(next.value.length <= 65536, "CONTENT_CHUNK_LIMIT");
            return next.value;
          } finally {
            request.signal.removeEventListener("abort", abort);
            reader.busy = false;
          }
        }
        if (method === "content.hasBlob") {
          allow("content");
          return session.content.hasBlob(String(args[0]));
        }
        if (method === "content.deleteBlob") {
          allow("content");
          return session.content.deleteBlob(String(args[0]));
        }
        if (method === "content.blobOpenWrite") {
          allow("content");
          check(blobWrites.size < 4, "ENDPOINT_UPLOAD_LIMIT");
          const totalBytes = Number(args[0]);
          check(Number.isSafeInteger(totalBytes) && totalBytes >= 0 && totalBytes <= MAX_BLOB_BYTES, "CONTENT_RANGE_INVALID");
          const id = crypto.randomUUID(), count = Math.ceil(totalBytes / CONTENT_CHUNK_BYTES);
          blobWrites.set(id, { totalBytes, chunks: new Array(count) });
          return id;
        }
        if (method === "content.blobWriteChunk") {
          allow("content");
          const write = blobWrites.get(String(args[0]));
          check(write !== void 0, "CONTENT_UPLOAD_UNKNOWN");
          const index = Number(args[1]), chunk = args[2];
          check(Number.isSafeInteger(index) && index >= 0 && index < write.chunks.length && chunk instanceof Uint8Array && chunk.byteLength === Math.min(CONTENT_CHUNK_BYTES, write.totalBytes - index * CONTENT_CHUNK_BYTES), "CONTENT_CHUNK_SIZE_INVALID");
          write.chunks[index] = chunk.slice();
          return null;
        }
        if (method === "content.blobCommitWrite") {
          allow("content");
          const id = String(args[0]), write = blobWrites.get(id);
          check(write !== void 0, "CONTENT_UPLOAD_UNKNOWN");
          blobWrites.delete(id);
          const assembled = new Uint8Array(write.totalBytes);
          for (let index = 0; index < write.chunks.length; index++) {
            const chunk = write.chunks[index];
            check(chunk !== void 0, "CONTENT_INCOMPLETE");
            assembled.set(chunk, index * CONTENT_CHUNK_BYTES);
          }
          return session.content.putBlob(assembled, { signal: request.signal });
        }
        if (method === "content.blobCommitPrivate") {
          allow("content");
          const id = String(args[0]), write = blobWrites.get(id);
          check(write !== void 0, "CONTENT_UPLOAD_UNKNOWN");
          blobWrites.delete(id);
          const assembled = new Uint8Array(write.totalBytes);
          for (let index = 0; index < write.chunks.length; index++) {
            const chunk = write.chunks[index];
            check(chunk !== void 0, "CONTENT_INCOMPLETE");
            assembled.set(chunk, index * CONTENT_CHUNK_BYTES);
          }
          const mediaType = typeof args[1] === "string" ? args[1] : void 0;
          return session.content.put(assembled, {
            visibility: "private",
            deduplicate: true,
            ...mediaType === void 0 ? {} : { mediaType },
            signal: request.signal
          });
        }
        if (method === "content.blobOpenRead") {
          allow("content");
          check(blobReads.size < 4, "ENDPOINT_READER_LIMIT");
          const rawOptions = args[1] ?? {};
          const bytes = await session.content.getBlob(String(args[0]), { ...rawOptions, signal: request.signal });
          if (bytes === null) return null;
          const id = crypto.randomUUID();
          blobReads.set(id, { bytes, offset: 0 });
          return { id, bytes: bytes.byteLength };
        }
        if (method === "content.blobNextChunk") {
          allow("content");
          const id = String(args[0]), read = blobReads.get(id);
          check(read !== void 0, "CONTENT_READER_UNKNOWN");
          if (read.offset >= read.bytes.byteLength) {
            blobReads.delete(id);
            return null;
          }
          const nextOffset = Math.min(read.bytes.byteLength, read.offset + CONTENT_CHUNK_BYTES);
          const slice = read.bytes.subarray(read.offset, nextOffset).slice();
          read.offset = nextOffset;
          if (read.offset >= read.bytes.byteLength) blobReads.delete(id);
          return slice;
        }
        if (method === "signals.send") {
          allow("signals");
          const supplied = args[2] ?? {};
          return session.signals.send(String(args[0]), args[1], {
            ...supplied,
            signal: request.signal,
            stream: { ...supplied.stream, streamId: supplied.stream?.streamId ?? endpointId, endpointId, endpointIncarnation }
          });
        }
        if (method === "signals.open") {
          allow("signals");
          check(streams.size < 4, "ENDPOINT_STREAM_LIMIT");
          const id = crypto.randomUUID(), owned = new AbortController();
          const iterator = session.signals.subscribe({ ...args[0] ?? {}, signal: AbortSignal.any([owned.signal, lifetime.signal]) })[Symbol.asyncIterator]();
          streams.set(id, { iterator, lifetime: owned, pending: null, busy: false });
          return id;
        }
        if (method === "signals.next") {
          allow("signals");
          const id = String(args[0]), stream = streams.get(id);
          check(stream !== void 0 && !stream.busy, "SIGNAL_STREAM_UNKNOWN");
          stream.busy = true;
          try {
            const next = await awaitOwnedTask(request.signal, () => stream.pending ??= stream.iterator.next());
            stream.pending = null;
            active(request);
            if (next.done) {
              streams.delete(id);
              return null;
            }
            return next.value;
          } finally {
            stream.busy = false;
          }
        }
        throw new Error("ENDPOINT_METHOD_UNKNOWN");
      };
      const receive = (event) => {
        const message = event.data;
        if (message?.protocol !== APPLICATION_OWNER_PROTOCOL || detached) return;
        if (attachment === "" && typeof message.attachment === "string" && message.attachment.length > 0 && message.attachment.length <= 128) attachment = message.attachment;
        if (message.attachment !== attachment) return;
        lastReceived = performance.now();
        if (message.kind === "cancel" && typeof message.id === "number") {
          pending.get(message.id)?.lifetime.abort(new Error("ENDPOINT_REQUEST_CANCELLED"));
          return;
        }
        if (message.kind !== "request" || typeof message.id !== "number" || !Number.isSafeInteger(message.id) || message.id <= highestRequest || typeof message.method !== "string" || !Array.isArray(message.args)) return;
        const requestId = message.id;
        const requestMethod = message.method;
        highestRequest = requestId;
        const control = CONTROLS.has(requestMethod), inFlight = [...pending.values()].filter((value) => value.control === control).length;
        if (inFlight >= (control ? 8 : effective.maxRequests ?? 32)) {
          post({ protocol: APPLICATION_OWNER_PROTOCOL, attachment, kind: "response", id: requestId, error: "ENDPOINT_REQUEST_LIMIT" });
          return;
        }
        try {
          requestBudget(message.args);
        } catch (error) {
          post({ protocol: APPLICATION_OWNER_PROTOCOL, attachment, kind: "response", id: requestId, error: error instanceof Error ? error.message : "ENDPOINT_REQUEST_INVALID" });
          return;
        }
        const requestLifetime = new AbortController(), request = { lifetime: requestLifetime, signal: AbortSignal.any([lifetime.signal, requestLifetime.signal]), method: requestMethod, control };
        pending.set(requestId, request);
        void invoke(requestMethod, message.args, request).then(
          (value) => {
            pending.delete(requestId);
            post({ protocol: APPLICATION_OWNER_PROTOCOL, attachment, kind: "response", id: requestId, value });
            if (requestMethod === "close") close();
          },
          (error) => {
            pending.delete(requestId);
            post({ protocol: APPLICATION_OWNER_PROTOCOL, attachment, kind: "response", id: requestId, error: error instanceof Error ? error.message : String(error) });
            if (requestMethod === "hello" || requestMethod === "close") close();
          }
        );
      };
      const expiry = setInterval(() => {
        if (!suspended && performance.now() - lastReceived > 6e4) close();
      }, 15e3);
      expiry.unref?.();
      attachments.set(endpointId, { binding, state: () => suspended ? "suspended" : "active", close });
      endpoint.addEventListener("message", receive);
      physical.addEventListener("close", physicalClose);
      physical.addEventListener("messageerror", physicalClose);
      physical.on?.("close", close);
      physical.on?.("messageerror", close);
      endpoint.start?.();
      return close;
    }
  };
  return owner;
}

// packages/peer-session/src/multi-session.ts
function mergeSessionChanges(source = [], options = {}) {
  const owner = new AbortController();
  const lifetime = options.signal === void 0 ? owner.signal : AbortSignal.any([owner.signal, options.signal]);
  const members = /* @__PURE__ */ new Map();
  const ready = [];
  let failure;
  let wake = () => void 0;
  let iterating = false;
  const notify = () => {
    const resolve = wake;
    wake = () => void 0;
    resolve();
  };
  lifetime.addEventListener("abort", () => {
    for (const member of members.values()) member.abort();
    members.clear();
    notify();
  }, { once: true });
  async function follow(session, member) {
    const signal = AbortSignal.any([member.signal, ...session.signal === void 0 ? [] : [session.signal]]);
    try {
      for await (const change of session.changes({ signal })) {
        if (signal.aborted) return;
        await new Promise((resolve) => {
          const taken = () => {
            signal.removeEventListener("abort", taken);
            resolve();
          };
          signal.addEventListener("abort", taken, { once: true });
          ready.push({ session, taken, change: Object.freeze({ applicationId: session.applicationId, kind: change.kind, revision: change.revision, revisedProposalIds: change.revisedProposalIds }) });
          notify();
        });
        if (signal.aborted) return;
      }
    } catch (error) {
      if (signal.aborted) return;
      if (options.onError !== void 0) options.onError(error, session);
      else {
        failure ??= { error };
        notify();
      }
    } finally {
      if (members.get(session) === member) members.delete(session);
    }
  }
  function add(session) {
    if (lifetime.aborted || members.has(session)) return;
    const member = new AbortController();
    members.set(session, member);
    void follow(session, member);
  }
  function remove(session) {
    const member = members.get(session);
    if (member === void 0) return;
    members.delete(session);
    member.abort();
    for (let index = ready.length - 1; index >= 0; index--) if (ready[index].session === session) ready.splice(index, 1);
  }
  if (Symbol.asyncIterator in source) {
    void (async () => {
      try {
        for await (const session of source) {
          if (lifetime.aborted) return;
          add(session);
        }
      } catch (error) {
        failure ??= { error };
        notify();
      }
    })();
  } else for (const session of source) add(session);
  return {
    add,
    remove,
    get size() {
      return members.size;
    },
    close() {
      owner.abort();
    },
    [Symbol.asyncIterator]() {
      if (iterating) throw new Error("SESSION_CHANGES_SINGLE_CONSUMER");
      iterating = true;
      return {
        async next() {
          for (; ; ) {
            if (failure !== void 0) {
              const { error } = failure;
              failure = void 0;
              owner.abort();
              throw error;
            }
            if (lifetime.aborted) return { done: true, value: void 0 };
            const entry = ready.shift();
            if (entry !== void 0) {
              entry.taken();
              return { done: false, value: entry.change };
            }
            await new Promise((resolve) => {
              wake = resolve;
            });
          }
        },
        async return() {
          owner.abort();
          return { done: true, value: void 0 };
        }
      };
    }
  };
}
function sessionCheckpointKey(applicationId) {
  return applicationId;
}
function forwardManySessionEvents(options) {
  const { sessions = [], checkpoints, onError, signal, ...forwarder } = options;
  const owner = new AbortController();
  const lifetime = signal === void 0 ? owner.signal : AbortSignal.any([owner.signal, signal]);
  let sourceFailure;
  const running = /* @__PURE__ */ new Map();
  function add(session) {
    if (lifetime.aborted || running.has(session)) return;
    const stop = new AbortController();
    const scope = Object.freeze({ applicationId: session.applicationId, key: sessionCheckpointKey(session.applicationId) });
    const done = forwardSessionEvents({
      ...forwarder,
      session,
      signal: AbortSignal.any([lifetime, stop.signal]),
      checkpoint: { load: () => checkpoints.load(scope), save: (state) => checkpoints.save(scope, state) }
    }).catch((error) => {
      if (!stop.signal.aborted && !lifetime.aborted && !session.signal.aborted) onError(error, session);
    }).finally(() => {
      if (running.get(session)?.stop === stop) running.delete(session);
    });
    running.set(session, { stop, done });
  }
  function remove(session) {
    const entry = running.get(session);
    if (entry === void 0) return;
    running.delete(session);
    entry.stop.abort();
  }
  if (Symbol.asyncIterator in sessions) {
    void (async () => {
      try {
        for await (const session of sessions) {
          if (lifetime.aborted) return;
          add(session);
        }
      } catch (error) {
        sourceFailure = { error };
        owner.abort(error);
      }
    })();
  } else for (const session of sessions) add(session);
  return {
    add,
    remove,
    get size() {
      return running.size;
    },
    async close() {
      const settled = [...running.values()].map((entry) => entry.done);
      owner.abort();
      await Promise.all(settled);
      if (sourceFailure !== void 0) throw sourceFailure.error;
    }
  };
}

// packages/peer-session/src/index.ts
async function createApplicationSession(options) {
  return (await import("./runtime-2LHMLR24.mjs")).createApplicationSession(options);
}

export {
  createApplicationOwner,
  mergeSessionChanges,
  sessionCheckpointKey,
  forwardManySessionEvents,
  createApplicationSession
};
