import {
  verifyEd25519Sync
} from "./chunk-7QDEMFRX.mjs";
import {
  assertValidReducersConfig,
  canonicalEventPayload,
  compareOperationOrder,
  decodeLogGenesis,
  encodeCanonicalJsonCbor,
  encodeLogGenesis,
  genesisLogId,
  isControlTopic,
  jsonToCbor,
  normalizeJsonValue,
  operationIdDigest
} from "./chunk-37AJJO3T.mjs";
import {
  bytesToHex,
  decodeUtf8,
  encodeCanonicalCbor,
  hashDomainSync,
  hexToBytes,
  sha256Sync,
  utf8
} from "./chunk-ICYUPG2X.mjs";

// packages/materializer/src/quickjs-sandbox.ts
import {
  newQuickJSWASMModuleFromVariant,
  newVariant
} from "quickjs-emscripten-core";
import baseVariant from "@jitl/quickjs-ng-wasmfile-release-sync";
var MissingDependencyError = class extends Error {
  constructor(hash, kind = "cas") {
    super(`MISSING_DEPENDENCY:${kind}/${hash}`);
    this.hash = hash;
    this.kind = kind;
    this.name = "MissingDependencyError";
  }
  hash;
  kind;
  code = "MISSING_DEPENDENCY";
};
var OperationalTimeoutError = class extends Error {
  code = "OPERATIONAL_TIMEOUT";
  constructor(message = "REDUCER_WATCHDOG_TIMEOUT") {
    super(message);
    this.name = "OperationalTimeoutError";
  }
};
var CRYPTO_MODULE_SHIM = `
export function sha256(input) { return globalThis.__chronologHost.sha256(input); }
export function verifyEd25519(pubKeyHex, message, sigHex) { return globalThis.__chronologHost.verifyEd25519(pubKeyHex, message, sigHex); }
export function canonicalJson(value) { return globalThis.__chronologHost.canonicalJson(value); }
`;
var CAS_MODULE_SHIM = `
export function put(bytes, links = []) { return globalThis.__chronologHost.casPut(bytes, links); }
export function get(hash) { return globalThis.__chronologHost.casGet(hash); }
`;
var SQLITE_MODULE_SHIM = `
export function openDb(dbRoot = null) {
  const handleId = globalThis.__chronologHost.sqlOpen(dbRoot);
  return {
    exec(sql, params = [], options = {}) {
      return JSON.parse(globalThis.__chronologHost.sqlExec(handleId, String(sql), JSON.stringify(params ?? []), JSON.stringify(options ?? {})));
    },
    query(sql, params = []) {
      return JSON.parse(globalThis.__chronologHost.sqlQuery(handleId, String(sql), JSON.stringify(params ?? [])));
    },
    validateExpr(table, sqlOp, expr) {
      globalThis.__chronologHost.sqlValidateExpr(handleId, String(table), String(sqlOp), String(expr));
    },
    commit() {
      return globalThis.__chronologHost.sqlCommit(handleId);
    },
    close() {
      globalThis.__chronologHost.sqlClose(handleId);
    },
  };
}
`;
var DETERMINISM_PRELUDE = `
Object.defineProperty(globalThis, 'Date', { value: undefined, writable: false, configurable: false });
Object.defineProperty(Math, 'random', { value: () => { throw new Error('NONDETERMINISTIC_MATH_RANDOM'); }, writable: false, configurable: false });
if (typeof Intl !== 'undefined') {
  Object.defineProperty(globalThis, 'Intl', { value: undefined, writable: false, configurable: false });
}
`;
var defaultQuickJsPromise = null;
async function loadQuickJsModule(wasmModule) {
  const syncBase = baseVariant;
  if (wasmModule !== void 0) {
    const variant = newVariant(syncBase, { wasmModule });
    return newQuickJSWASMModuleFromVariant(variant);
  }
  if (defaultQuickJsPromise === null) {
    defaultQuickJsPromise = newQuickJSWASMModuleFromVariant(syncBase).catch((err) => {
      defaultQuickJsPromise = null;
      throw err;
    });
  }
  return defaultQuickJsPromise;
}
var QuickJsSandbox = class {
  #wasmPromise;
  #sqliteDriver;
  #watchdogMs;
  constructor(options = {}) {
    this.#wasmPromise = loadQuickJsModule(options.wasmModule);
    this.#sqliteDriver = options.sqliteDriver;
    this.#watchdogMs = options.watchdogMs ?? 2e3;
  }
  get sqliteBuiltinId() {
    return this.#sqliteDriver?.builtinId ?? null;
  }
  /**
   * Execute one deterministic reduce/query/describe call in a brand-new isolated QuickJSRuntime + Context.
   * Zero live module state is ever shared across invocations.
   */
  async invoke(input) {
    const qjs = await this.#wasmPromise;
    return this.#invokeSync(qjs, input, 0);
  }
  #invokeSync(qjs, input, depth) {
    const runtime = qjs.newRuntime();
    const openDbs = /* @__PURE__ */ new Map();
    let nextDbId = 1;
    let missingDep = null;
    let timedOut = false;
    const deadline = Date.now() + this.#watchdogMs;
    const readPartition = input.casPartition === "public" ? "public" : "any";
    const writePartition = input.casPartition;
    const tripMissing = (hash, kind) => {
      const err = new MissingDependencyError(hash, kind);
      missingDep ??= err;
      throw err;
    };
    try {
      runtime.setMemoryLimit(input.maxMemoryBytes);
      runtime.setMaxStackSize(512 * 1024);
      runtime.setInterruptHandler(() => {
        if (missingDep !== null) return true;
        if (Date.now() > deadline) {
          timedOut = true;
          return true;
        }
        return false;
      });
      runtime.setModuleLoader((moduleName) => {
        if (moduleName === "chronolog:crypto") {
          if (!Object.hasOwn(input.builtins, "chronolog:crypto")) return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:crypto") };
          return CRYPTO_MODULE_SHIM;
        }
        if (moduleName === "chronolog:cas") {
          if (!Object.hasOwn(input.builtins, "chronolog:cas")) return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:cas") };
          return CAS_MODULE_SHIM;
        }
        if (moduleName === "chronolog:sqlite") {
          if (!Object.hasOwn(input.builtins, "chronolog:sqlite") || this.#sqliteDriver === void 0) {
            return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:sqlite") };
          }
          return SQLITE_MODULE_SHIM;
        }
        if (moduleName === "__chronolog_entry__") {
          const exp = input.exportName === "default" ? `import __target from ${JSON.stringify(input.moduleSpecifier)};` : `import { ${input.exportName} as __target } from ${JSON.stringify(input.moduleSpecifier)};`;
          return `${exp}
globalThis.__chronologRun = () => { const env = JSON.parse(globalThis.__chronologEnvJson); const ctx = Object.freeze({ topic(name) { return Object.prototype.hasOwnProperty.call(env.topics, name) ? env.topics[name] : null; }, query(name, input = null) { return JSON.parse(globalThis.__chronologHost.queryTopic(String(name), JSON.stringify(input === undefined ? null : input))); }, config: env.config ?? null }); const fn = __target && __target[${JSON.stringify(input.method)}]; if (typeof fn !== 'function') { return JSON.stringify({ __missingMethod: true }); } const out = ${input.method === "reduce" ? "fn(env.state, env.tx, ctx)" : input.method === "query" ? "fn(env.state, env.payload, ctx)" : "fn(env.state, ctx)"}; return JSON.stringify({ __ok: true, value: out }); };`;
        }
        const ref = input.imports[moduleName];
        if (ref === void 0) return { error: new Error(`MODULE_NOT_FOUND:${moduleName}`) };
        const match = /^cas:sha256-([0-9a-f]{64})$/u.exec(ref);
        if (match === null) return { error: new Error(`MODULE_REF_INVALID:${moduleName}`) };
        const hash = match[1];
        const node = input.cas.getSync(hash, readPartition);
        if (node === null) {
          missingDep ??= new MissingDependencyError(hash, "module");
          return { error: missingDep };
        }
        return decodeUtf8(node.bytes);
      });
      const ctx = runtime.newContext();
      try {
        const preludeRes = ctx.evalCode(DETERMINISM_PRELUDE, "__prelude__.js");
        if (preludeRes.error) {
          preludeRes.error.dispose();
          return { ok: false, code: "vm:prelude_failed" };
        }
        preludeRes.value.dispose();
        const hostObj = ctx.newObject();
        const bindFn = (name, fn) => {
          const handle = ctx.newFunction(name, (...args) => {
            if (missingDep !== null) throw missingDep;
            return fn(...args);
          });
          ctx.setProp(hostObj, name, handle);
          handle.dispose();
        };
        bindFn("queryTopic", (topicH, inputJsonH) => {
          if (depth >= 4) throw new Error("TOPIC_QUERY_DEPTH_EXCEEDED");
          const topicName = ctx.getString(topicH);
          if (readPartition === "public" && !isControlTopic(topicName)) {
            return ctx.newString("null");
          }
          const rawQueryInput = JSON.parse(ctx.getString(inputJsonH));
          const topicState = Object.hasOwn(input.topics, topicName) ? input.topics[topicName] : null;
          const binding = input.topicBindings?.[topicName];
          if (binding === void 0) {
            return ctx.newString(JSON.stringify(topicState));
          }
          const nestedPartition = readPartition === "public" || isControlTopic(topicName) ? "public" : input.casPartition;
          let nestedRes;
          try {
            nestedRes = this.#invokeSync(qjs, {
              imports: input.imports,
              builtins: input.builtins,
              ...input.topicBindings === void 0 ? {} : { topicBindings: input.topicBindings },
              moduleSpecifier: binding.module,
              exportName: binding.export ?? "default",
              method: "query",
              state: topicState,
              payload: normalizeJsonValue(rawQueryInput),
              topics: input.topics,
              ...binding.config === void 0 ? {} : { config: binding.config },
              cas: input.cas,
              casPartition: nestedPartition,
              readOnly: true,
              maxMemoryBytes: input.maxMemoryBytes
            }, depth + 1);
          } catch (err) {
            if (err instanceof MissingDependencyError) {
              missingDep ??= err;
              throw err;
            }
            throw err;
          }
          if (!nestedRes.ok) {
            if (nestedRes.code === "vm:missing_method:query") {
              return ctx.newString(JSON.stringify(topicState));
            }
            throw new Error(`TOPIC_QUERY_FAILED:${nestedRes.code}:${nestedRes.detail ?? ""}`);
          }
          return ctx.newString(JSON.stringify(nestedRes.value));
        });
        bindFn("sha256", (dataHandle) => {
          const raw = ctx.dump(dataHandle);
          const bytes = typeof raw === "string" ? utf8(raw) : raw instanceof Uint8Array ? raw : utf8(JSON.stringify(raw));
          return ctx.newString(bytesToHex(sha256Sync(bytes)));
        });
        bindFn("verifyEd25519", (pubH, msgH, sigH) => {
          const pubHex = ctx.getString(pubH);
          const msgRaw = ctx.dump(msgH);
          const sigHex = ctx.getString(sigH);
          if (!/^[0-9a-f]{64}$/u.test(pubHex) || !/^[0-9a-f]{128}$/u.test(sigHex)) return ctx.false;
          const msgBytes = typeof msgRaw === "string" ? utf8(msgRaw) : msgRaw instanceof Uint8Array ? msgRaw : utf8(JSON.stringify(msgRaw));
          return verifyEd25519Sync(hexToBytes(pubHex), msgBytes, hexToBytes(sigHex)) ? ctx.true : ctx.false;
        });
        bindFn("canonicalJson", (valH) => {
          const val = normalizeJsonValue(ctx.dump(valH));
          return ctx.newString(canonicalEventPayload(val));
        });
        bindFn("casPut", (bytesH, linksH) => {
          if (input.readOnly) throw new Error("CAS_READ_ONLY");
          const raw = ctx.dump(bytesH);
          const bytes = typeof raw === "string" ? utf8(raw) : raw instanceof Uint8Array ? raw : Array.isArray(raw) ? Uint8Array.from(raw) : (() => {
            throw new Error("CAS_PUT_BYTES_INVALID");
          })();
          const rawLinks = linksH === void 0 ? [] : ctx.dump(linksH);
          if (!Array.isArray(rawLinks) || !rawLinks.every((l) => typeof l === "string")) throw new Error("CAS_PUT_LINKS_INVALID");
          const hash = input.cas.putSync(bytes, rawLinks, writePartition);
          return ctx.newString(hash);
        });
        bindFn("casGet", (hashH) => {
          const hash = ctx.getString(hashH);
          if (!/^[0-9a-f]{64}$/u.test(hash)) throw new Error("CAS_HASH_INVALID");
          const node = input.cas.getSync(hash, readPartition);
          if (node === null) {
            tripMissing(hash, "cas");
            return ctx.undefined;
          }
          return ctx.newString(JSON.stringify({ bytesHex: bytesToHex(node.bytes), links: node.links }));
        });
        if (this.#sqliteDriver !== void 0) {
          const driver = this.#sqliteDriver;
          bindFn("sqlOpen", (rootH) => {
            const rawRoot = ctx.dump(rootH);
            const dbRoot = typeof rawRoot === "string" ? rawRoot : null;
            const db = driver.openDb({
              dbRoot,
              cas: input.cas,
              partition: input.casPartition,
              actor: input.tx?.author ?? "0".repeat(64),
              opId: input.tx?.opId ?? "0".repeat(64),
              opTimeMs: BigInt(input.tx?.authorTimestampMs ?? 0),
              readOnly: input.readOnly,
              onMissingCas: (hash) => tripMissing(hash, "sqlite")
            });
            const id = nextDbId++;
            openDbs.set(id, db);
            return ctx.newNumber(id);
          });
          bindFn("sqlExec", (idH, sqlH, paramsH, optsH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            const sql = ctx.getString(sqlH);
            const params = JSON.parse(ctx.getString(paramsH));
            const opts = JSON.parse(ctx.getString(optsH));
            const res = db.exec(sql, params, opts);
            return ctx.newString(JSON.stringify(res));
          });
          bindFn("sqlQuery", (idH, sqlH, paramsH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            const sql = ctx.getString(sqlH);
            const params = JSON.parse(ctx.getString(paramsH));
            const res = db.query(sql, params);
            return ctx.newString(JSON.stringify(res));
          });
          bindFn("sqlValidateExpr", (idH, tableH, opH, exprH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            db.validateExpr(ctx.getString(tableH), ctx.getString(opH), ctx.getString(exprH));
          });
          bindFn("sqlCommit", (idH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            return ctx.newString(db.commit());
          });
          bindFn("sqlClose", (idH) => {
            const id = ctx.getNumber(idH);
            const db = openDbs.get(id);
            if (db !== void 0) {
              db.close();
              openDbs.delete(id);
            }
          });
        }
        ctx.setProp(ctx.global, "__chronologHost", hostObj);
        hostObj.dispose();
        const envJson = JSON.stringify({
          state: input.state,
          payload: input.payload,
          tx: input.tx === void 0 ? null : { ...input.tx, payload: input.payload },
          topics: input.topics,
          config: input.config ?? null
        });
        const envHandle = ctx.newString(envJson);
        ctx.setProp(ctx.global, "__chronologEnvJson", envHandle);
        envHandle.dispose();
        const loadRes = ctx.evalCode(
          `import '__chronolog_entry__';`,
          "__bootstrap__.mjs",
          { type: "module" }
        );
        if (loadRes.error) {
          const dumped = ctx.dump(loadRes.error);
          loadRes.error.dispose();
          if (missingDep !== null) throw missingDep;
          if (timedOut) throw new OperationalTimeoutError();
          return { ok: false, code: "vm:module_load_error", detail: formatJsError(dumped) };
        }
        loadRes.value.dispose();
        if (missingDep !== null) throw missingDep;
        if (timedOut) throw new OperationalTimeoutError();
        const runRes = ctx.evalCode("globalThis.__chronologRun()", "__run__.js");
        if (runRes.error) {
          const dumped = ctx.dump(runRes.error);
          runRes.error.dispose();
          if (missingDep !== null) throw missingDep;
          if (timedOut) throw new OperationalTimeoutError();
          const detail = formatJsError(dumped);
          const code = /out of memory|memory limit/i.test(detail) ? "vm:limit" : "reducer:throw";
          return { ok: false, code, detail };
        }
        const rawOut = ctx.getString(runRes.value);
        runRes.value.dispose();
        if (missingDep !== null) throw missingDep;
        if (timedOut) throw new OperationalTimeoutError();
        const parsed = JSON.parse(rawOut);
        if (parsed.__missingMethod) {
          return { ok: false, code: `vm:missing_method:${input.method}` };
        }
        try {
          const normalized = normalizeJsonValue(parsed.value);
          return { ok: true, value: normalized };
        } catch (err) {
          return { ok: false, code: "vm:invalid_output", detail: err instanceof Error ? err.message : String(err) };
        }
      } finally {
        for (const db of openDbs.values()) {
          try {
            db.close();
          } catch {
          }
        }
        openDbs.clear();
        ctx.dispose();
      }
    } finally {
      runtime.dispose();
    }
  }
};
function formatJsError(dumped) {
  if (typeof dumped === "string") return dumped;
  if (dumped !== null && typeof dumped === "object" && "message" in dumped) {
    return String(dumped.message);
  }
  try {
    return JSON.stringify(dumped);
  } catch {
    return String(dumped);
  }
}

// packages/materializer/src/kernel.ts
var ZERO_HASH = "0".repeat(64);
function seenOpKey(visibility, authorHex, operationId) {
  return `${visibility}:${authorHex}:${operationId}`;
}
function hashSeenOpsSet(seen, cas, partition) {
  const sorted = [...seen].sort();
  const bytes = encodeCanonicalCbor(sorted);
  return cas.putSync(bytes, [], partition);
}
function computeStateRoot(topics, seenOpsRoot) {
  const payload = encodeCanonicalCbor(/* @__PURE__ */ new Map([
    ["seenOpsRoot", seenOpsRoot],
    ["topics", jsonToCbor(normalizeJsonValue(topics))]
  ]));
  return bytesToHex(hashDomainSync("state", payload));
}
function advanceHistoryDigest(prev, opId, outcome, rejectionCode, events) {
  const eventsBytes = encodeCanonicalJsonCbor(
    events.map((e) => ({ o: e.eventOrdinal, t: e.topic, p: e.payload }))
  );
  const payload = encodeCanonicalCbor([prev, opId, outcome, rejectionCode ?? "", eventsBytes]);
  return bytesToHex(hashDomainSync("history", payload));
}
function computeRevisionDigest(historyDigest, stateRoot, view, policyContextDigest) {
  const payload = encodeCanonicalCbor([historyDigest, stateRoot, view, policyContextDigest]);
  return bytesToHex(hashDomainSync("revision", payload));
}
function filterPublicTopics(topics) {
  const out = {};
  for (const [k, v] of Object.entries(topics)) {
    if (isControlTopic(k)) out[k] = v;
  }
  return out;
}
function extractCasHashes(value, out) {
  if (typeof value === "string") {
    if (/^[0-9a-f]{64}$/u.test(value)) out.add(value);
    else if (value.startsWith("cas:sha256-") && value.length === 75) out.add(value.slice(11));
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) extractCasHashes(item, out);
    return;
  }
  if (value !== null && typeof value === "object") {
    for (const v of Object.values(value)) extractCasHashes(v, out);
  }
}
var TopicKernel = class {
  genesis;
  genesisBytes;
  logId;
  logIdHex;
  cas;
  sandbox;
  blindHostMode;
  #snapshotInterval;
  #policyContextDigest;
  #order = [];
  #outcomes = [];
  #topics;
  #seenOps = /* @__PURE__ */ new Set();
  #seenOpsRoot;
  #historyDigest = ZERO_HASH;
  #stateRoot;
  #pendingDependencies = /* @__PURE__ */ new Set();
  #skippedOpIds = /* @__PURE__ */ new Set();
  #snapshots = /* @__PURE__ */ new Map();
  #cachedDescribe = null;
  #queryCacheStateRoot = "";
  #queryCache = /* @__PURE__ */ new Map();
  constructor(options) {
    this.genesisBytes = options.genesis instanceof Uint8Array ? options.genesis.slice() : encodeLogGenesis(options.genesis);
    this.genesis = decodeLogGenesis(this.genesisBytes);
    this.logId = genesisLogId(this.genesisBytes);
    this.logIdHex = bytesToHex(this.logId);
    this.cas = options.cas;
    this.blindHostMode = options.blindHostMode ?? false;
    this.#snapshotInterval = options.snapshotInterval ?? 16;
    this.#policyContextDigest = options.policyContextDigest ?? ZERO_HASH;
    this.sandbox = new QuickJsSandbox(options);
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(this.genesis.initialTopics)) : structuredClone(this.genesis.initialTopics);
    this.#seenOpsRoot = hashSeenOpsSet(this.#seenOps, this.cas, "public");
    this.#stateRoot = computeStateRoot(this.#topics, this.#seenOpsRoot);
    this.#snapshots.set(0, this.#captureSnapshot(0));
  }
  #captureSnapshotFrom(state, orderLength) {
    return {
      topics: structuredClone(state.topics),
      seenOps: new Set(state.seenOps),
      seenOpsRoot: state.seenOpsRoot,
      historyDigest: state.historyDigest,
      stateRoot: state.stateRoot,
      orderLength
    };
  }
  #captureSnapshot(orderLength) {
    return {
      topics: structuredClone(this.#topics),
      seenOps: new Set(this.#seenOps),
      seenOpsRoot: this.#seenOpsRoot,
      historyDigest: this.#historyDigest,
      stateRoot: this.#stateRoot,
      orderLength
    };
  }
  get topics() {
    return structuredClone(this.#topics);
  }
  get seenOpsRoot() {
    return this.#seenOpsRoot;
  }
  snapshot() {
    return {
      topics: structuredClone(this.#topics),
      seenOpsRoot: this.#seenOpsRoot,
      historyDigest: this.#historyDigest,
      stateRoot: this.#stateRoot
    };
  }
  topic(name) {
    return Object.hasOwn(this.#topics, name) ? structuredClone(this.#topics[name]) : null;
  }
  get outcomes() {
    return this.#outcomes.slice();
  }
  get pendingDependencies() {
    return [...this.#pendingDependencies].sort();
  }
  revision(view = "local", policyContextDigest = this.#policyContextDigest) {
    return {
      stateRoot: this.#stateRoot,
      historyDigest: this.#historyDigest,
      digest: computeRevisionDigest(this.#historyDigest, this.#stateRoot, view, policyContextDigest),
      view,
      orderLength: this.#order.length
    };
  }
  /** Collect all CAS root hashes reachable from current state + retained suffix snapshots (for local GC). */
  gcRoots() {
    const roots = /* @__PURE__ */ new Set();
    roots.add(this.#seenOpsRoot);
    extractCasHashes(this.#topics, roots);
    for (const snap of this.#snapshots.values()) {
      roots.add(snap.seenOpsRoot);
      extractCasHashes(snap.topics, roots);
    }
    return roots;
  }
  /**
   * Bootstrap kernel state directly from a verified FinalityCheckpoint snapshot.
   * Restores both topicsMap, seenOpsRoot (consumed handles), and rolling historyDigest
   * so subsequent suffix replay produces identical stateRoot AND revision.digest.
   */
  async bootstrapFromCheckpoint(checkpoint) {
    const seenNode = await this.cas.get(checkpoint.seenOpsRoot, "any");
    if (seenNode === null) throw new MissingDependencyError(checkpoint.seenOpsRoot, "cas");
    const decodedSeen = normalizeJsonValue(
      JSON.parse(JSON.stringify(
        // Decode CBOR array of strings stored in seenOpsRoot
        await import("./src-ZNNATASY.mjs").then((m) => m.assertCanonicalCbor(seenNode.bytes, m.DEFAULT_DECODE_LIMITS))
      ))
    );
    const computedStateRoot = computeStateRoot(checkpoint.topics, checkpoint.seenOpsRoot);
    if (computedStateRoot !== checkpoint.stateRoot) {
      throw new Error(`CHECKPOINT_STATE_ROOT_MISMATCH: expected ${checkpoint.stateRoot}, got ${computedStateRoot}`);
    }
    this.#order = [];
    this.#outcomes = [];
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(checkpoint.topics)) : structuredClone(checkpoint.topics);
    this.#seenOps = new Set(decodedSeen);
    this.#seenOpsRoot = checkpoint.seenOpsRoot;
    this.#historyDigest = checkpoint.historyDigest;
    this.#stateRoot = checkpoint.stateRoot;
    this.#snapshots.clear();
    this.#snapshots.set(0, this.#captureSnapshot(0));
  }
  /**
   * Deterministically materialize an eligible operation set (arbitrary input order; sorted internally).
   * Rewinds only to the earliest snapshot before the first changed position (suffix replay).
   */
  async materialize(inputs) {
    const eligible = [];
    const seenIds = /* @__PURE__ */ new Set();
    for (const item of inputs) {
      if (bytesToHex(item.core.logId) !== this.logIdHex) continue;
      if (this.blindHostMode && this.genesis.privateLog && item.core.visibility !== "public") continue;
      const opIdHex = bytesToHex(item.opId);
      if (bytesToHex(operationIdDigest(item.core)) !== opIdHex) throw new Error("KERNEL_OP_ID_MISMATCH");
      if (seenIds.has(opIdHex)) continue;
      seenIds.add(opIdHex);
      eligible.push(item);
    }
    eligible.sort((a, b) => compareOperationOrder(
      { authorTimestampMs: a.core.authorTimestampMs, author: a.core.author, opId: a.opId },
      { authorTimestampMs: b.core.authorTimestampMs, author: b.core.author, opId: b.opId }
    ));
    let diff = 0;
    while (diff < this.#order.length && diff < eligible.length) {
      if (bytesToHex(this.#order[diff].opId) !== bytesToHex(eligible[diff].opId)) break;
      diff++;
    }
    if (diff === eligible.length && this.#order.length === eligible.length && this.#pendingDependencies.size === 0) {
      return {
        revision: this.revision("local"),
        outcomes: this.#outcomes.slice(),
        pendingDependencies: this.pendingDependencies,
        skippedOpIds: [...this.#skippedOpIds]
      };
    }
    if (this.#pendingDependencies.size > 0) diff = 0;
    let snapIndex = 0;
    for (const idx of this.#snapshots.keys()) {
      if (idx <= diff && idx > snapIndex) snapIndex = idx;
    }
    const snap = this.#snapshots.get(snapIndex);
    const work = {
      topics: structuredClone(snap.topics),
      seenOps: new Set(snap.seenOps),
      seenOpsRoot: snap.seenOpsRoot,
      historyDigest: snap.historyDigest,
      stateRoot: snap.stateRoot
    };
    const nextSnapshots = /* @__PURE__ */ new Map();
    for (const [idx, s] of this.#snapshots) {
      if (idx <= snapIndex) nextSnapshots.set(idx, s);
    }
    const nextOutcomes = this.#outcomes.slice(0, snapIndex);
    const nextOrder = this.#order.slice(0, snapIndex);
    const nextPendingDeps = /* @__PURE__ */ new Set();
    const nextSkippedOps = /* @__PURE__ */ new Set();
    this.cas.beginBatch();
    try {
      for (let i = snapIndex; i < eligible.length; i++) {
        const entry = eligible[i];
        const opIdHex = bytesToHex(entry.opId);
        const authorHex = bytesToHex(entry.core.author);
        const step = await this.#applyOne(work, entry, opIdHex, authorHex);
        if (step.kind === "missing") {
          nextPendingDeps.add(step.dependency);
          nextSkippedOps.add(opIdHex);
          break;
        }
        nextOrder.push(entry);
        nextOutcomes.push(step.outcome);
        if (nextOrder.length % this.#snapshotInterval === 0) {
          nextSnapshots.set(nextOrder.length, this.#captureSnapshotFrom(work, nextOrder.length));
        }
      }
      await this.cas.flushBatch();
      this.#topics = work.topics;
      this.#seenOps = work.seenOps;
      this.#seenOpsRoot = work.seenOpsRoot;
      this.#historyDigest = work.historyDigest;
      this.#stateRoot = work.stateRoot;
      this.#order = nextOrder;
      this.#outcomes = nextOutcomes;
      this.#pendingDependencies = nextPendingDeps;
      this.#skippedOpIds = nextSkippedOps;
      this.#snapshots = nextSnapshots;
    } catch (err) {
      this.cas.rollbackBatch();
      throw err;
    }
    return {
      revision: this.revision("local"),
      outcomes: this.#outcomes.slice(),
      pendingDependencies: this.pendingDependencies,
      skippedOpIds: [...this.#skippedOpIds]
    };
  }
  async #applyOne(work, entry, opIdHex, authorHex) {
    const core = entry.core;
    const makeRejected = (code, detail) => {
      const outcome = {
        opId: opIdHex,
        author: authorHex,
        operationId: core.operationId,
        authorTimestampMs: core.authorTimestampMs,
        visibility: core.visibility,
        outcome: "rejected",
        rejectionCode: code,
        ...detail === void 0 ? {} : { rejectionDetail: detail },
        events: []
      };
      work.historyDigest = advanceHistoryDigest(work.historyDigest, opIdHex, "rejected", code, []);
      return { kind: "done", outcome };
    };
    if (this.genesis.privateLog) {
      if (core.visibility === "public") {
        if (core.updates.some((u) => !isControlTopic(u.topic))) {
          return makeRejected("partition:public_op_private_topic");
        }
      } else {
        if (core.updates.some((u) => isControlTopic(u.topic))) {
          return makeRejected("partition:encrypted_op_control_topic");
        }
      }
    }
    if (core.updates.length > this.genesis.limits.maxUpdatesPerOp) {
      return makeRejected("limit:max_updates_per_op");
    }
    const dedupKey = seenOpKey(core.visibility, authorHex, core.operationId);
    if (work.seenOps.has(dedupKey)) {
      return makeRejected("operation_conflict");
    }
    const casPartition = this.genesis.privateLog && core.visibility === "public" ? "public" : "private";
    const workingTopics = structuredClone(work.topics);
    const emitted = [];
    let ordinal = 0;
    for (const update of core.updates) {
      let reducersConfig;
      try {
        reducersConfig = assertValidReducersConfig(workingTopics.$reducers);
      } catch (err) {
        return makeRejected("reducers_config_invalid", err instanceof Error ? err.message : String(err));
      }
      const binding = reducersConfig.topics[update.topic];
      if (binding === void 0) {
        return makeRejected(update.topic === "$reducers" ? "reducers_frozen" : `no_reducer:${update.topic}`);
      }
      const visibleTopics = this.genesis.privateLog && core.visibility === "public" ? filterPublicTopics(workingTopics) : workingTopics;
      const curTopicState = Object.hasOwn(workingTopics, update.topic) ? workingTopics[update.topic] : null;
      let res;
      try {
        res = await this.sandbox.invoke({
          imports: reducersConfig.imports,
          builtins: reducersConfig.runtime.builtins,
          topicBindings: reducersConfig.topics,
          moduleSpecifier: binding.module,
          exportName: binding.export ?? "default",
          method: "reduce",
          state: curTopicState,
          payload: update.input,
          tx: {
            opId: opIdHex,
            author: authorHex,
            authorTimestampMs: Number(core.authorTimestampMs),
            operationId: core.operationId
          },
          topics: visibleTopics,
          ...binding.config === void 0 ? {} : { config: binding.config },
          cas: this.cas,
          casPartition,
          readOnly: false,
          maxMemoryBytes: this.genesis.limits.maxMemoryBytes
        });
      } catch (err) {
        if (err instanceof MissingDependencyError) {
          return { kind: "missing", dependency: `${err.kind}/${err.hash}` };
        }
        throw err;
      }
      if (!res.ok) {
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected(res.code, res.detail);
      }
      const outObj = res.value;
      if (outObj === null || typeof outObj !== "object" || Array.isArray(outObj)) {
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected("vm:invalid_reducer_return");
      }
      const outRec = outObj;
      if (typeof outRec.ok !== "boolean") {
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected("vm:invalid_reducer_return");
      }
      if (!outRec.ok) {
        const rejCode = typeof outRec.code === "string" && outRec.code.length > 0 ? outRec.code : "reducer:rejected";
        const rejDetail = typeof outRec.detail === "string" ? outRec.detail : void 0;
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected(rejCode, rejDetail);
      }
      const nextTopicState = outRec.state === void 0 ? null : outRec.state;
      const encodedTopic = encodeCanonicalJsonCbor(nextTopicState);
      if (encodedTopic.length > this.genesis.limits.maxTopicStateBytes) {
        work.seenOps.add(dedupKey);
        work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
        work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
        return makeRejected("limit:max_topic_state_bytes");
      }
      if (update.topic === "$reducers") {
        try {
          assertValidReducersConfig(nextTopicState);
        } catch (err) {
          work.seenOps.add(dedupKey);
          work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
          work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
          return makeRejected("reducers_config_invalid", err instanceof Error ? err.message : String(err));
        }
      }
      workingTopics[update.topic] = nextTopicState;
      if (Array.isArray(outRec.events)) {
        for (const rawEv of outRec.events) {
          if (rawEv !== null && typeof rawEv === "object" && !Array.isArray(rawEv)) {
            const ev = rawEv;
            if (typeof ev.topic === "string") {
              emitted.push({
                opId: opIdHex,
                eventOrdinal: ordinal++,
                topic: ev.topic,
                payload: ev.payload ?? null,
                author: authorHex,
                operationId: core.operationId,
                authorTimestampMs: core.authorTimestampMs
              });
            }
          }
        }
      }
    }
    work.seenOps.add(dedupKey);
    work.seenOpsRoot = hashSeenOpsSet(work.seenOps, this.cas, casPartition);
    work.topics = workingTopics;
    work.stateRoot = computeStateRoot(work.topics, work.seenOpsRoot);
    work.historyDigest = advanceHistoryDigest(work.historyDigest, opIdHex, "accepted", null, emitted);
    return {
      kind: "done",
      outcome: {
        opId: opIdHex,
        author: authorHex,
        operationId: core.operationId,
        authorTimestampMs: core.authorTimestampMs,
        visibility: core.visibility,
        outcome: "accepted",
        rejectionCode: null,
        events: emitted
      }
    };
  }
  /** Execute a pure read-only query against a topic's query() export (or return raw topic state if no query export). */
  async query(topic, input = null, topicsOverride) {
    const sourceTopics = topicsOverride ?? this.#topics;
    const normalizedInput = normalizeJsonValue(input);
    let cacheKey = null;
    if (topicsOverride === void 0) {
      if (this.#queryCacheStateRoot !== this.#stateRoot) {
        this.#queryCache.clear();
        this.#queryCacheStateRoot = this.#stateRoot;
      }
      cacheKey = `${topic}\0${bytesToHex(encodeCanonicalJsonCbor(normalizedInput))}`;
      const hit = this.#queryCache.get(cacheKey);
      if (hit !== void 0) {
        this.#queryCache.delete(cacheKey);
        this.#queryCache.set(cacheKey, hit);
        return structuredClone(hit);
      }
    }
    const reducersConfig = assertValidReducersConfig(sourceTopics.$reducers);
    const binding = reducersConfig.topics[topic];
    const state = Object.hasOwn(sourceTopics, topic) ? sourceTopics[topic] : null;
    if (binding === void 0) return structuredClone(state);
    const casPartition = this.genesis.privateLog && isControlTopic(topic) ? "public" : "private";
    const visibleTopics = this.genesis.privateLog && isControlTopic(topic) ? filterPublicTopics(sourceTopics) : sourceTopics;
    const res = await this.sandbox.invoke({
      imports: reducersConfig.imports,
      builtins: reducersConfig.runtime.builtins,
      topicBindings: reducersConfig.topics,
      moduleSpecifier: binding.module,
      exportName: binding.export ?? "default",
      method: "query",
      state,
      payload: normalizedInput,
      topics: visibleTopics,
      ...binding.config === void 0 ? {} : { config: binding.config },
      cas: this.cas,
      casPartition,
      readOnly: true,
      maxMemoryBytes: this.genesis.limits.maxMemoryBytes
    });
    if (!res.ok) {
      if (res.code === "vm:missing_method:query") return structuredClone(state);
      throw new Error(`KERNEL_QUERY_FAILED:${res.code}:${res.detail ?? ""}`);
    }
    if (cacheKey !== null && this.#queryCacheStateRoot === this.#stateRoot) {
      this.#queryCache.set(cacheKey, structuredClone(res.value));
      if (this.#queryCache.size > 128) {
        const oldest = this.#queryCache.keys().next().value;
        if (oldest !== void 0) this.#queryCache.delete(oldest);
      }
    }
    return res.value;
  }
  /** Collect exported command/query descriptions across all bound topics (for MCP & scoped tools). */
  async describe() {
    if (this.#cachedDescribe !== null && this.#cachedDescribe.stateRoot === this.#stateRoot) {
      return structuredClone(this.#cachedDescribe.value);
    }
    const reducersConfig = assertValidReducersConfig(this.#topics.$reducers);
    const out = {};
    for (const [topic, binding] of Object.entries(reducersConfig.topics)) {
      if (this.blindHostMode && this.genesis.privateLog && !isControlTopic(topic)) continue;
      const state = Object.hasOwn(this.#topics, topic) ? this.#topics[topic] : null;
      const casPartition = this.genesis.privateLog && isControlTopic(topic) ? "public" : "private";
      const res = await this.sandbox.invoke({
        imports: reducersConfig.imports,
        builtins: reducersConfig.runtime.builtins,
        topicBindings: reducersConfig.topics,
        moduleSpecifier: binding.module,
        exportName: binding.export ?? "default",
        method: "describe",
        state,
        payload: null,
        topics: this.blindHostMode ? filterPublicTopics(this.#topics) : this.#topics,
        ...binding.config === void 0 ? {} : { config: binding.config },
        cas: this.cas,
        casPartition,
        readOnly: true,
        maxMemoryBytes: this.genesis.limits.maxMemoryBytes
      });
      if (res.ok) out[topic] = res.value;
    }
    this.#cachedDescribe = { stateRoot: this.#stateRoot, value: structuredClone(out) };
    return out;
  }
  /** Evaluate signal authorization policy for the current stateRoot (cached by caller per stateRoot). */
  async signalPolicy() {
    const reducersConfig = assertValidReducersConfig(this.#topics.$reducers);
    if (reducersConfig.topics.$signal_policy !== void 0) {
      const val = await this.query("$signal_policy", null);
      if (val !== null && typeof val === "object" && !Array.isArray(val) && Array.isArray(val.rules)) {
        return val;
      }
    }
    const queriedReaders = await this.query("$permissions", { list: "readers" }).catch(() => null);
    if (Array.isArray(queriedReaders) && queriedReaders.every((x) => typeof x === "string")) {
      return {
        rules: [{ topicPattern: "*", allowedAuthors: queriedReaders, maxTtlMs: 3e4, allowRelay: true }]
      };
    }
    const perms = this.#topics.$permissions;
    const readers = (perms?.members ?? []).filter((m) => m.reader).map((m) => m.publicKey);
    return {
      rules: [{ topicPattern: "*", allowedAuthors: readers, maxTtlMs: 3e4, allowRelay: true }]
    };
  }
};

export {
  MissingDependencyError,
  OperationalTimeoutError,
  QuickJsSandbox,
  TopicKernel
};
