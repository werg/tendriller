import {
  verifyEd25519Sync
} from "./chunk-RFZQY6CX.mjs";
import {
  casRef,
  computeCasHash,
  decodeCasNode,
  decodeTreeNode,
  encodeCasNode,
  hashCasNode,
  normalizePosixPath,
  parseCasRef,
  tryParseCasRef
} from "./chunk-OWL5GQ66.mjs";
import {
  canonicalJson
} from "./chunk-XIVHZVOM.mjs";
import {
  DEFAULT_DECODE_LIMITS,
  assertCanonicalCbor,
  encodeCanonicalCbor,
  equalBytes,
  hexToBytes,
  utf8
} from "./chunk-VRR2HFJY.mjs";

// packages/peer-session/src/cas-mirror.ts
var HEX32 = /^[0-9a-f]{64}$/u;
var HEX64 = /^[0-9a-f]{128}$/u;
var CAS_NODE_MEDIA_TYPE = "application/vnd.chronolog.cas-node+cbor";
var CAS_SUBGRAPH_MEDIA_TYPE = "application/vnd.chronolog.cas-subgraph+cbor";
function verifyMirrorBuildAttestation(att) {
  if (att === null || typeof att !== "object") return false;
  const rec = att;
  const payload = rec.payload;
  if (payload === null || typeof payload !== "object") return false;
  const p = payload;
  if (p.format !== "chronolog-attestation/v1" || p.kind !== "build") return false;
  if (typeof p.drvRef !== "string" || tryParseCasRef(p.drvRef) === null) return false;
  if (typeof p.outputRef !== "string" || tryParseCasRef(p.outputRef) === null) return false;
  if (typeof p.runtime !== "string" || p.runtime.length === 0 || p.runtime.length > 256) return false;
  if (typeof rec.signer !== "string" || !HEX32.test(rec.signer)) return false;
  if (typeof rec.signature !== "string" || !HEX64.test(rec.signature)) return false;
  const msg = utf8(`chronolog/attestation/v1:${canonicalJson(p)}`);
  return verifyEd25519Sync(hexToBytes(rec.signer), msg, hexToBytes(rec.signature));
}
function verifyMirrorAuditAttestation(att) {
  if (att === null || typeof att !== "object") return false;
  const rec = att;
  const payload = rec.payload;
  if (payload === null || typeof payload !== "object") return false;
  const p = payload;
  if (p.format !== "chronolog-attestation/v1" || p.kind !== "audit") return false;
  if (typeof p.pkgRef !== "string" || tryParseCasRef(p.pkgRef) === null) return false;
  if (p.verdict !== "approved" && p.verdict !== "revoked") return false;
  if (p.notes !== void 0 && typeof p.notes !== "string") return false;
  if (typeof rec.signer !== "string" || !HEX32.test(rec.signer)) return false;
  if (typeof rec.signature !== "string" || !HEX64.test(rec.signature)) return false;
  const msg = utf8(`chronolog/attestation/v1:${canonicalJson(p)}`);
  return verifyEd25519Sync(hexToBytes(rec.signer), msg, hexToBytes(rec.signature));
}
function normalizeVerifiedCasNode(expectedHash, raw, maxBytes = 4 * 1024 * 1024) {
  if (!HEX32.test(expectedHash)) return null;
  if (raw.byteLength > maxBytes + 65536) return null;
  if (hashCasNode(raw) === expectedHash) {
    try {
      const node = decodeCasNode(raw);
      if (!equalBytes(encodeCasNode(node.bytes, node.links), raw)) return null;
      return raw.slice();
    } catch {
      return null;
    }
  }
  if (raw.byteLength <= maxBytes && computeCasHash(raw, []) === expectedHash) {
    return encodeCasNode(raw, []);
  }
  return null;
}
function encodeCasSubgraphBundle(rootHash, nodes) {
  const entries = nodes.map((n) => [n.hash, n.bytes]);
  return encodeCanonicalCbor(/* @__PURE__ */ new Map([
    ["format", "chronolog-cas-subgraph/v1"],
    ["nodes", entries],
    ["root", rootHash]
  ]));
}
function decodeCasSubgraphBundle(bytes) {
  const decoded = assertCanonicalCbor(bytes, { ...DEFAULT_DECODE_LIMITS, maxBytes: 32 * 1024 * 1024 });
  if (!(decoded instanceof Map)) throw new Error("CAS_SUBGRAPH_BUNDLE_INVALID");
  const map = decoded;
  if (map.get("format") !== "chronolog-cas-subgraph/v1") throw new Error("CAS_SUBGRAPH_BUNDLE_INVALID");
  const root = map.get("root");
  const rawNodes = map.get("nodes");
  if (typeof root !== "string" || !HEX32.test(root) || !Array.isArray(rawNodes)) {
    throw new Error("CAS_SUBGRAPH_BUNDLE_INVALID");
  }
  const nodes = [];
  for (const item of rawNodes) {
    if (!Array.isArray(item) || item.length !== 2 || typeof item[0] !== "string" || !(item[1] instanceof Uint8Array)) {
      throw new Error("CAS_SUBGRAPH_BUNDLE_INVALID");
    }
    if (!HEX32.test(item[0])) throw new Error("CAS_SUBGRAPH_BUNDLE_INVALID");
    nodes.push({ hash: item[0], bytes: item[1].slice() });
  }
  return { root, nodes };
}
function resolveTrustedBuildOutput(drvRef, attestations, trustedBuilders, threshold = 1) {
  const allowed = new Set(trustedBuilders);
  const required = Math.max(1, Math.floor(threshold));
  const byOutput = /* @__PURE__ */ new Map();
  for (const att of attestations) {
    if (!verifyMirrorBuildAttestation(att)) continue;
    if (att.payload.drvRef !== drvRef) continue;
    if (!allowed.has(att.signer)) continue;
    const set = byOutput.get(att.payload.outputRef) ?? /* @__PURE__ */ new Set();
    set.add(att.signer);
    byOutput.set(att.payload.outputRef, set);
  }
  for (const [outputRef, signers] of [...byOutput.entries()].sort(([a], [b]) => a.localeCompare(b))) {
    if (signers.size >= required) {
      return {
        outputRef,
        outputHash: parseCasRef(outputRef),
        signers: [...signers].sort()
      };
    }
  }
  return null;
}
function createBytesStoreCasMirrorStore(store, prefix = "mirror/") {
  const dec = new TextDecoder();
  return {
    async getNode(hash) {
      return store.get(`${prefix}cas/${hash}`);
    },
    async hasNode(hash) {
      return await store.get(`${prefix}cas/${hash}`) !== null;
    },
    async putNode(hash, encodedNode) {
      await store.put(`${prefix}cas/${hash}`, encodedNode);
    },
    async listAttestations(drvHash) {
      const raw = await store.get(`${prefix}drv/${drvHash}`);
      if (raw === null) return [];
      try {
        const parsed = JSON.parse(dec.decode(raw));
        return Array.isArray(parsed) ? parsed.filter(verifyMirrorBuildAttestation) : [];
      } catch {
        return [];
      }
    },
    async putAttestation(drvHash, attestation) {
      const existing = await this.listAttestations(drvHash);
      const dup = existing.some(
        (a) => a.signer === attestation.signer && a.payload.outputRef === attestation.payload.outputRef && a.payload.runtime === attestation.payload.runtime
      );
      if (dup) return;
      const next = [...existing, attestation];
      await store.put(`${prefix}drv/${drvHash}`, utf8(JSON.stringify(next)));
    },
    async listAudits(pkgHash) {
      const raw = await store.get(`${prefix}audit/${pkgHash}`);
      if (raw === null) return [];
      try {
        const parsed = JSON.parse(dec.decode(raw));
        return Array.isArray(parsed) ? parsed.filter(verifyMirrorAuditAttestation) : [];
      } catch {
        return [];
      }
    },
    async putAudit(pkgHash, audit) {
      const existing = await this.listAudits(pkgHash);
      const dup = existing.some(
        (a) => a.signer === audit.signer && a.payload.verdict === audit.payload.verdict && (a.payload.notes ?? "") === (audit.payload.notes ?? "")
      );
      if (dup) return;
      const next = [...existing, audit];
      await store.put(`${prefix}audit/${pkgHash}`, utf8(JSON.stringify(next)));
    }
  };
}
function createCasAdapterMirrorStore(cas, options = {}) {
  const partition = options.partition ?? "public";
  const attStore = options.attestationStore !== void 0 ? createBytesStoreCasMirrorStore(options.attestationStore, options.prefix ?? "mirror/") : void 0;
  return {
    getNode: (hash) => cas.getRaw(hash, partition),
    hasNode: async (hash) => cas.hasSync(hash, partition) || await cas.getRaw(hash, partition) !== null,
    putNode: async (hash, encodedNode) => {
      await cas.putRaw(hash, encodedNode, partition);
    },
    ...attStore === void 0 ? {} : {
      listAttestations: (drvHash) => attStore.listAttestations(drvHash),
      putAttestation: (drvHash, att) => attStore.putAttestation(drvHash, att),
      listAudits: (pkgHash) => attStore.listAudits(pkgHash),
      putAudit: (pkgHash, audit) => attStore.putAudit(pkgHash, audit)
    }
  };
}
function parseHashSegment(segment) {
  const stripped = segment.startsWith("sha256-") ? segment.slice("sha256-".length) : segment;
  return HEX32.test(stripped) ? stripped : null;
}
function etagMatches(condition, etag) {
  if (condition === null) return false;
  const cleanTarget = etag.replace(/^W\//u, "");
  return condition.split(",").some((part) => {
    const t = part.trim();
    return t === "*" || t.replace(/^W\//u, "") === cleanTarget;
  });
}
function guessMediaType(path) {
  const ext = path.slice(path.lastIndexOf(".") + 1).toLowerCase();
  switch (ext) {
    case "html":
    case "htm":
      return "text/html; charset=utf-8";
    case "js":
    case "mjs":
      return "text/javascript; charset=utf-8";
    case "css":
      return "text/css; charset=utf-8";
    case "json":
      return "application/json; charset=utf-8";
    case "svg":
      return "image/svg+xml";
    case "png":
      return "image/png";
    case "jpg":
    case "jpeg":
      return "image/jpeg";
    case "webp":
      return "image/webp";
    case "wasm":
      return "application/wasm";
    case "txt":
    case "md":
      return "text/plain; charset=utf-8";
    default:
      return "application/octet-stream";
  }
}
async function readBlobBytesFromMirrorStore(store, hash, maxBytes, depth = 0) {
  if (depth > 8) throw new Error("CAS_BLOB_DEPTH_EXCEEDED");
  const raw = await store.getNode(hash);
  if (raw === null) return null;
  const verified = normalizeVerifiedCasNode(hash, raw, maxBytes);
  if (verified === null) throw new Error(`CAS_CORRUPT:${hash}`);
  const node = decodeCasNode(verified);
  if (node.links.length === 0) {
    if (node.bytes.byteLength > maxBytes) throw new Error("CAS_BLOB_TOO_LARGE");
    return node.bytes;
  }
  try {
    const decoded = assertCanonicalCbor(node.bytes, DEFAULT_DECODE_LIMITS);
    if (decoded instanceof Map && decoded.get("format") === "chronolog-blob/v1") {
      const map = decoded;
      const totalBytes = map.get("bytes");
      const children = map.get("children");
      if (typeof totalBytes === "bigint" && Number(totalBytes) <= maxBytes && Array.isArray(children)) {
        const out = new Uint8Array(Number(totalBytes));
        let offset = 0;
        for (const child of children) {
          if (!Array.isArray(child) || child.length !== 2 || typeof child[0] !== "string") {
            throw new Error("CAS_BLOB_INVALID");
          }
          const part = await readBlobBytesFromMirrorStore(store, child[0], maxBytes - offset, depth + 1);
          if (part === null) return null;
          out.set(part, offset);
          offset += part.byteLength;
        }
        return out;
      }
    }
  } catch (err) {
    if (err instanceof Error && err.message.startsWith("CAS_BLOB_")) throw err;
  }
  return node.bytes;
}
function applyRangeResponse(request, bytes, headers) {
  const size = bytes.byteLength;
  headers.set("Accept-Ranges", "bytes");
  const rangeHeader = request.headers.get("Range");
  const match = rangeHeader === null ? null : /^bytes=(\d*)-(\d*)$/u.exec(rangeHeader);
  if (match !== null && (match[1] !== "" || match[2] !== "")) {
    const start = match[1] !== "" ? Number(match[1]) : Math.max(0, size - Number(match[2]));
    const end = match[1] !== "" && match[2] !== "" ? Math.min(size - 1, Number(match[2])) : size - 1;
    if (Number.isSafeInteger(start) && Number.isSafeInteger(end)) {
      if (start >= size || end < start) {
        headers.set("Content-Range", `bytes */${size}`);
        headers.set("Content-Length", "0");
        return new Response(null, { status: 416, headers });
      }
      const slice = bytes.subarray(start, end + 1);
      headers.set("Content-Range", `bytes ${start}-${end}/${size}`);
      headers.set("Content-Length", String(slice.byteLength));
      return new Response(slice.slice(), { status: 206, headers });
    }
  }
  headers.set("Content-Length", String(size));
  return new Response(bytes.slice(), { status: 200, headers });
}
function jsonResponse(body, status = 200, extra) {
  const headers = new Headers(extra);
  headers.set("Content-Type", "application/json; charset=utf-8");
  headers.set("X-Content-Type-Options", "nosniff");
  return new Response(JSON.stringify(body), { status, headers });
}
function createCasMirrorHandler(options) {
  const basePath = (options.basePath ?? "").replace(/\/+$/u, "");
  const maxNodeBytes = options.maxNodeBytes ?? 4 * 1024 * 1024;
  const maxSubgraphNodes = options.maxSubgraphNodes ?? 256;
  const maxSubgraphBytes = options.maxSubgraphBytes ?? 8 * 1024 * 1024;
  const maxTreeFileBytes = options.maxTreeFileBytes ?? 16 * 1024 * 1024;
  const canWrite = async (request, kind) => {
    if (options.authorizeWrite !== void 0) return Boolean(await options.authorizeWrite(request, kind));
    return options.allowWrites === true;
  };
  return async (request) => {
    const url = new URL(request.url);
    let path = url.pathname;
    if (basePath.length > 0) {
      if (!path.startsWith(`${basePath}/`) && path !== basePath) {
        return jsonResponse({ error: "not_found" }, 404, options.headers);
      }
      path = path.slice(basePath.length);
    }
    if (path === "/cas/batch" && request.method === "POST") {
      if (!await canWrite(request, "cas") || options.store.putNode === void 0) {
        return jsonResponse({ error: "forbidden" }, 403, options.headers);
      }
      const raw = new Uint8Array(await request.arrayBuffer());
      if (raw.byteLength > maxSubgraphBytes + 65536) {
        return jsonResponse({ error: "payload_too_large" }, 413, options.headers);
      }
      let bundle;
      try {
        bundle = decodeCasSubgraphBundle(raw);
      } catch {
        return jsonResponse({ error: "invalid_subgraph_bundle" }, 400, options.headers);
      }
      if (bundle.nodes.length > maxSubgraphNodes) {
        return jsonResponse({ error: "too_many_nodes" }, 413, options.headers);
      }
      let stored = 0;
      for (const item of bundle.nodes) {
        const verified = normalizeVerifiedCasNode(item.hash, item.bytes, maxNodeBytes);
        if (verified === null) return jsonResponse({ error: "hash_mismatch", hash: item.hash }, 400, options.headers);
        await options.store.putNode(item.hash, verified);
        stored += 1;
      }
      return jsonResponse({ ok: true, root: bundle.root, stored }, 201, options.headers);
    }
    if (path.startsWith("/cas/")) {
      const seg = path.slice("/cas/".length);
      const hash = parseHashSegment(seg);
      if (hash === null) return jsonResponse({ error: "invalid_cas_hash" }, 400, options.headers);
      if (request.method === "PUT") {
        if (!await canWrite(request, "cas") || options.store.putNode === void 0) {
          return jsonResponse({ error: "forbidden" }, 403, options.headers);
        }
        const body = new Uint8Array(await request.arrayBuffer());
        const verified2 = normalizeVerifiedCasNode(hash, body, maxNodeBytes);
        if (verified2 === null) return jsonResponse({ error: "hash_mismatch" }, 400, options.headers);
        const existed = options.store.hasNode !== void 0 ? await options.store.hasNode(hash) : false;
        if (!existed) await options.store.putNode(hash, verified2);
        return jsonResponse({ ok: true, hash, ref: casRef(hash) }, existed ? 200 : 201, options.headers);
      }
      if (request.method !== "GET" && request.method !== "HEAD") {
        return jsonResponse({ error: "method_not_allowed" }, 405, options.headers);
      }
      const wantsSubgraph = url.searchParams.get("subgraph") === "1" || url.searchParams.get("subgraph") === "true";
      const etag = `"${hash}"`;
      if (!wantsSubgraph && etagMatches(request.headers.get("If-None-Match"), etag)) {
        const exists = options.store.hasNode !== void 0 ? await options.store.hasNode(hash) : await options.store.getNode(hash) !== null;
        if (!exists) return jsonResponse({ error: "not_found" }, 404, options.headers);
        const headers2 = new Headers(options.headers);
        headers2.set("ETag", etag);
        headers2.set("Cache-Control", "public, max-age=31536000, immutable");
        headers2.set("X-Content-Type-Options", "nosniff");
        return new Response(null, { status: 304, headers: headers2 });
      }
      if (wantsSubgraph) {
        const limitNodes = Math.min(maxSubgraphNodes, Math.max(1, Number(url.searchParams.get("maxNodes") ?? maxSubgraphNodes) || maxSubgraphNodes));
        const limitBytes = Math.min(maxSubgraphBytes, Math.max(1024, Number(url.searchParams.get("maxBytes") ?? maxSubgraphBytes) || maxSubgraphBytes));
        const visited = /* @__PURE__ */ new Set([hash]);
        const queue = [hash];
        const collected = [];
        let totalBytes = 0;
        while (queue.length > 0 && collected.length < limitNodes) {
          const cur = queue.shift();
          const raw2 = await options.store.getNode(cur);
          if (raw2 === null) {
            if (cur === hash) return jsonResponse({ error: "not_found" }, 404, options.headers);
            continue;
          }
          const verified2 = normalizeVerifiedCasNode(cur, raw2, maxNodeBytes);
          if (verified2 === null) return jsonResponse({ error: "integrity_mismatch", hash: cur }, 503, options.headers);
          if (totalBytes + verified2.byteLength > limitBytes && collected.length > 0) break;
          collected.push({ hash: cur, bytes: verified2 });
          totalBytes += verified2.byteLength;
          const decoded = decodeCasNode(verified2);
          for (const link of decoded.links) {
            if (!visited.has(link)) {
              visited.add(link);
              queue.push(link);
            }
          }
        }
        const encoded = encodeCasSubgraphBundle(hash, collected);
        const headers2 = new Headers(options.headers);
        headers2.set("Content-Type", CAS_SUBGRAPH_MEDIA_TYPE);
        headers2.set("Cache-Control", "public, max-age=31536000, immutable");
        headers2.set("ETag", `"subgraph:${hash}:${collected.length}"`);
        headers2.set("X-Content-Type-Options", "nosniff");
        headers2.set("Content-Length", String(encoded.byteLength));
        if (request.method === "HEAD") return new Response(null, { status: 200, headers: headers2 });
        return new Response(encoded.slice(), { status: 200, headers: headers2 });
      }
      const raw = await options.store.getNode(hash);
      if (raw === null) return jsonResponse({ error: "not_found" }, 404, options.headers);
      const verified = normalizeVerifiedCasNode(hash, raw, maxNodeBytes);
      if (verified === null) return jsonResponse({ error: "integrity_mismatch" }, 503, options.headers);
      const headers = new Headers(options.headers);
      headers.set("Content-Type", CAS_NODE_MEDIA_TYPE);
      headers.set("ETag", etag);
      headers.set("Cache-Control", "public, max-age=31536000, immutable");
      headers.set("X-Content-Type-Options", "nosniff");
      if (request.method === "HEAD") {
        headers.set("Content-Length", String(verified.byteLength));
        return new Response(null, { status: 200, headers });
      }
      return applyRangeResponse(request, verified, headers);
    }
    if (path.startsWith("/derivations/")) {
      const seg = path.slice("/derivations/".length);
      const drvHash = parseHashSegment(seg);
      if (drvHash === null) return jsonResponse({ error: "invalid_derivation_hash" }, 400, options.headers);
      const drvRef = casRef(drvHash);
      if (request.method === "PUT") {
        if (!await canWrite(request, "derivation") || options.store.putAttestation === void 0) {
          return jsonResponse({ error: "forbidden" }, 403, options.headers);
        }
        let body;
        try {
          body = await request.json();
        } catch {
          return jsonResponse({ error: "invalid_json" }, 400, options.headers);
        }
        if (!verifyMirrorBuildAttestation(body) || body.payload.drvRef !== drvRef) {
          return jsonResponse({ error: "invalid_attestation" }, 400, options.headers);
        }
        await options.store.putAttestation(drvHash, body);
        return jsonResponse({ ok: true, drvRef, outputRef: body.payload.outputRef, signer: body.signer }, 201, options.headers);
      }
      if (request.method !== "GET") return jsonResponse({ error: "method_not_allowed" }, 405, options.headers);
      const all = options.store.listAttestations !== void 0 ? (await options.store.listAttestations(drvHash)).filter((a) => verifyMirrorBuildAttestation(a) && a.payload.drvRef === drvRef) : [];
      const buildersParam = url.searchParams.get("builders");
      const builders = buildersParam !== null && buildersParam.length > 0 ? buildersParam.split(",").map((s) => s.trim()).filter((s) => HEX32.test(s)) : null;
      const filtered = builders !== null ? all.filter((a) => builders.includes(a.signer)) : all;
      const threshold = Number(url.searchParams.get("threshold") ?? "1") || 1;
      const trusted = builders !== null ? resolveTrustedBuildOutput(drvRef, filtered, builders, threshold) : null;
      return jsonResponse({
        format: "chronolog-derivation-cache/v1",
        drvRef,
        attestations: filtered,
        ...trusted === null ? {} : { trustedOutputRef: trusted.outputRef, trustedSigners: trusted.signers }
      }, 200, options.headers);
    }
    if (path.startsWith("/audits/")) {
      const seg = path.slice("/audits/".length);
      const pkgHash = parseHashSegment(seg);
      if (pkgHash === null) return jsonResponse({ error: "invalid_package_hash" }, 400, options.headers);
      const pkgRef = casRef(pkgHash);
      if (request.method === "PUT") {
        if (!await canWrite(request, "audit") || options.store.putAudit === void 0) {
          return jsonResponse({ error: "forbidden" }, 403, options.headers);
        }
        let body;
        try {
          body = await request.json();
        } catch {
          return jsonResponse({ error: "invalid_json" }, 400, options.headers);
        }
        if (!verifyMirrorAuditAttestation(body) || body.payload.pkgRef !== pkgRef) {
          return jsonResponse({ error: "invalid_audit" }, 400, options.headers);
        }
        await options.store.putAudit(pkgHash, body);
        return jsonResponse({ ok: true, pkgRef, verdict: body.payload.verdict, signer: body.signer }, 201, options.headers);
      }
      if (request.method !== "GET") return jsonResponse({ error: "method_not_allowed" }, 405, options.headers);
      const audits = options.store.listAudits !== void 0 ? (await options.store.listAudits(pkgHash)).filter((a) => verifyMirrorAuditAttestation(a) && a.payload.pkgRef === pkgRef) : [];
      return jsonResponse({ format: "chronolog-audit-cache/v1", pkgRef, audits }, 200, options.headers);
    }
    if (path.startsWith("/trees/")) {
      if (request.method !== "GET" && request.method !== "HEAD") {
        return jsonResponse({ error: "method_not_allowed" }, 405, options.headers);
      }
      const rest = path.slice("/trees/".length);
      const slash = rest.indexOf("/");
      const treeSeg = slash < 0 ? rest : rest.slice(0, slash);
      const rawFilePath = slash < 0 ? "index.html" : rest.slice(slash + 1) || "index.html";
      const treeHash = parseHashSegment(treeSeg);
      if (treeHash === null) return jsonResponse({ error: "invalid_tree_hash" }, 400, options.headers);
      let filePath;
      try {
        filePath = normalizePosixPath(decodeURIComponent(rawFilePath));
      } catch {
        return jsonResponse({ error: "invalid_path" }, 400, options.headers);
      }
      const rawTree = await options.store.getNode(treeHash);
      if (rawTree === null) return jsonResponse({ error: "not_found" }, 404, options.headers);
      const verifiedTree = normalizeVerifiedCasNode(treeHash, rawTree, maxNodeBytes);
      if (verifiedTree === null) return jsonResponse({ error: "integrity_mismatch" }, 503, options.headers);
      let treeEntries;
      try {
        treeEntries = decodeTreeNode(decodeCasNode(verifiedTree).bytes).entries;
      } catch {
        return jsonResponse({ error: "not_a_tree" }, 400, options.headers);
      }
      const targetRef = treeEntries[filePath];
      if (targetRef === void 0) return jsonResponse({ error: "not_found" }, 404, options.headers);
      const targetHash = parseCasRef(targetRef);
      const etag = `"${targetHash}"`;
      const mediaType = options.resolveMediaType !== void 0 ? options.resolveMediaType(filePath) : guessMediaType(filePath);
      if (etagMatches(request.headers.get("If-None-Match"), etag)) {
        const headers2 = new Headers(options.headers);
        headers2.set("ETag", etag);
        headers2.set("Content-Type", mediaType);
        headers2.set("Cache-Control", "public, max-age=31536000, immutable");
        headers2.set("X-Content-Type-Options", "nosniff");
        return new Response(null, { status: 304, headers: headers2 });
      }
      const fileBytes = await readBlobBytesFromMirrorStore(options.store, targetHash, maxTreeFileBytes);
      if (fileBytes === null) return jsonResponse({ error: "not_found" }, 404, options.headers);
      const headers = new Headers(options.headers);
      headers.set("Content-Type", mediaType);
      headers.set("ETag", etag);
      headers.set("Cache-Control", "public, max-age=31536000, immutable");
      headers.set("X-Content-Type-Options", "nosniff");
      if (request.method === "HEAD") {
        headers.set("Content-Length", String(fileBytes.byteLength));
        return new Response(null, { status: 200, headers });
      }
      return applyRangeResponse(request, fileBytes, headers);
    }
    return jsonResponse({ error: "not_found" }, 404, options.headers);
  };
}
function createCasMirrorClient(baseUrl, options = {}) {
  const base = baseUrl.replace(/\/+$/u, "");
  const doFetch = options.fetch ?? fetch;
  const baseHeaders = options.headers ?? {};
  const fetchNode = async (hash) => {
    const clean = tryParseCasRef(hash) ?? hash;
    if (!HEX32.test(clean)) return null;
    const resp = await doFetch(`${base}/cas/sha256-${clean}`, { headers: baseHeaders });
    if (!resp.ok) return null;
    const raw = new Uint8Array(await resp.arrayBuffer());
    const verified = normalizeVerifiedCasNode(clean, raw);
    return verified === null ? null : { hash: clean, bytes: verified };
  };
  const fetchSubgraph = async (hash, opts = {}) => {
    const clean = tryParseCasRef(hash) ?? hash;
    if (!HEX32.test(clean)) return [];
    const params = new URLSearchParams({ subgraph: "1" });
    if (opts.maxNodes !== void 0) params.set("maxNodes", String(opts.maxNodes));
    if (opts.maxBytes !== void 0) params.set("maxBytes", String(opts.maxBytes));
    try {
      const resp = await doFetch(`${base}/cas/sha256-${clean}?${params.toString()}`, { headers: baseHeaders });
      if (resp.ok) {
        const contentType = resp.headers.get("Content-Type") ?? "";
        const buf = new Uint8Array(await resp.arrayBuffer());
        if (contentType.includes("cas-subgraph")) {
          const decoded = decodeCasSubgraphBundle(buf);
          const verified = [];
          for (const item of decoded.nodes) {
            const norm = normalizeVerifiedCasNode(item.hash, item.bytes);
            if (norm !== null) verified.push({ hash: item.hash, bytes: norm });
          }
          if (verified.length > 0) return verified;
        } else {
          const norm = normalizeVerifiedCasNode(clean, buf);
          if (norm !== null) {
            const out2 = [{ hash: clean, bytes: norm }];
            const seen2 = /* @__PURE__ */ new Set([clean]);
            const queue2 = [...decodeCasNode(norm).links];
            const limit2 = opts.maxNodes ?? 128;
            while (queue2.length > 0 && out2.length < limit2) {
              const next = queue2.shift();
              if (seen2.has(next)) continue;
              seen2.add(next);
              const child = await fetchNode(next);
              if (child === null) continue;
              out2.push(child);
              for (const link of decodeCasNode(child.bytes).links) {
                if (!seen2.has(link)) queue2.push(link);
              }
            }
            return out2;
          }
        }
      }
    } catch {
    }
    const root = await fetchNode(clean);
    if (root === null) return [];
    const out = [root];
    const seen = /* @__PURE__ */ new Set([clean]);
    const queue = [...decodeCasNode(root.bytes).links];
    const limit = opts.maxNodes ?? 128;
    while (queue.length > 0 && out.length < limit) {
      const next = queue.shift();
      if (seen.has(next)) continue;
      seen.add(next);
      const child = await fetchNode(next);
      if (child === null) continue;
      out.push(child);
      for (const link of decodeCasNode(child.bytes).links) {
        if (!seen.has(link)) queue.push(link);
      }
    }
    return out;
  };
  return {
    baseUrl: base,
    fetchNode,
    fetchSubgraph,
    async pushNode(hash, bytes) {
      const clean = tryParseCasRef(hash) ?? hash;
      const resp = await doFetch(`${base}/cas/sha256-${clean}`, {
        method: "PUT",
        headers: { ...baseHeaders, "Content-Type": CAS_NODE_MEDIA_TYPE },
        body: bytes.slice()
      });
      return resp.ok;
    },
    async pushSubgraph(rootHash, nodes) {
      const clean = tryParseCasRef(rootHash) ?? rootHash;
      const bundle = encodeCasSubgraphBundle(clean, nodes);
      const resp = await doFetch(`${base}/cas/batch`, {
        method: "POST",
        headers: { ...baseHeaders, "Content-Type": CAS_SUBGRAPH_MEDIA_TYPE },
        body: bundle.slice()
      });
      return resp.ok;
    },
    async fetchDerivationAttestations(drvRefOrHash, opts = {}) {
      const drvHash = tryParseCasRef(drvRefOrHash) ?? drvRefOrHash;
      const drvRef = casRef(drvHash);
      const params = new URLSearchParams();
      if (opts.trustedBuilders !== void 0 && opts.trustedBuilders.length > 0) {
        params.set("builders", opts.trustedBuilders.join(","));
      }
      if (opts.threshold !== void 0) params.set("threshold", String(opts.threshold));
      const qs = params.toString();
      const resp = await doFetch(`${base}/derivations/sha256-${drvHash}${qs ? `?${qs}` : ""}`, { headers: baseHeaders });
      if (!resp.ok) return { attestations: [], trusted: null };
      const data = await resp.json();
      const verified = Array.isArray(data.attestations) ? data.attestations.filter(verifyMirrorBuildAttestation).filter((a) => a.payload.drvRef === drvRef) : [];
      const trusted = opts.trustedBuilders !== void 0 && opts.trustedBuilders.length > 0 ? resolveTrustedBuildOutput(drvRef, verified, opts.trustedBuilders, opts.threshold ?? 1) : null;
      return { attestations: verified, trusted };
    },
    async publishDerivationAttestation(attestation) {
      const drvHash = parseCasRef(attestation.payload.drvRef);
      const resp = await doFetch(`${base}/derivations/sha256-${drvHash}`, {
        method: "PUT",
        headers: { ...baseHeaders, "Content-Type": "application/json" },
        body: JSON.stringify(attestation)
      });
      return resp.ok;
    },
    async fetchAuditAttestations(pkgRefOrHash) {
      const pkgHash = tryParseCasRef(pkgRefOrHash) ?? pkgRefOrHash;
      const pkgRef = casRef(pkgHash);
      const resp = await doFetch(`${base}/audits/sha256-${pkgHash}`, { headers: baseHeaders });
      if (!resp.ok) return [];
      const data = await resp.json();
      return Array.isArray(data.audits) ? data.audits.filter(verifyMirrorAuditAttestation).filter((a) => a.payload.pkgRef === pkgRef) : [];
    },
    async publishAuditAttestation(audit) {
      const pkgHash = parseCasRef(audit.payload.pkgRef);
      const resp = await doFetch(`${base}/audits/sha256-${pkgHash}`, {
        method: "PUT",
        headers: { ...baseHeaders, "Content-Type": "application/json" },
        body: JSON.stringify(audit)
      });
      return resp.ok;
    }
  };
}

// packages/peer-session/src/reconcile.ts
var HEX = /^[0-9a-f]{64}$/u;
var RECONCILE_LIST_THRESHOLD = 32;
var RECONCILE_MAX_PREFIX = 16;
function words(hex) {
  return [
    Number.parseInt(hex.slice(0, 8), 16) >>> 0,
    Number.parseInt(hex.slice(8, 16), 16) >>> 0,
    Number.parseInt(hex.slice(16, 24), 16) >>> 0,
    Number.parseInt(hex.slice(24, 32), 16) >>> 0
  ];
}
function lowerBound(ids, target) {
  let lo = 0, hi = ids.length;
  while (lo < hi) {
    const mid = lo + hi >>> 1;
    if (ids[mid] < target) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
var FactIdSet = class {
  #set = /* @__PURE__ */ new Set();
  #sorted = [];
  #words = new Uint32Array(0);
  get size() {
    return this.#set.size;
  }
  has(id) {
    return this.#set.has(id);
  }
  add(id) {
    if (this.#set.has(id)) return false;
    if (!HEX.test(id)) throw new Error("FACT_ID_INVALID");
    this.#set.add(id);
    this.#sorted = null;
    return true;
  }
  delete(id) {
    if (!this.#set.delete(id)) return false;
    this.#sorted = null;
    return true;
  }
  clear() {
    this.#set.clear();
    this.#sorted = [];
    this.#words = new Uint32Array(0);
  }
  #index() {
    if (this.#sorted === null) {
      const sorted = [...this.#set].sort();
      const packed = new Uint32Array(sorted.length * 4);
      for (let i = 0; i < sorted.length; i++) packed.set(words(sorted[i]), i * 4);
      this.#sorted = sorted;
      this.#words = packed;
    }
    return this.#sorted;
  }
  #range(prefix) {
    const ids = this.#index();
    if (prefix === "") return [0, ids.length];
    return [lowerBound(ids, prefix), lowerBound(ids, `${prefix}g`)];
  }
  ids(prefix = "") {
    const [start, end] = this.#range(prefix);
    return this.#index().slice(start, end);
  }
  count(prefix = "") {
    const [start, end] = this.#range(prefix);
    return end - start;
  }
  summary(prefix = "") {
    const [start, end] = this.#range(prefix);
    const w = this.#words;
    let a = 0, b = 0, c = 0, d = 0;
    for (let i = start; i < end; i++) {
      a ^= w[i * 4];
      b ^= w[i * 4 + 1];
      c ^= w[i * 4 + 2];
      d ^= w[i * 4 + 3];
    }
    const fp = new Uint8Array(16), view = new DataView(fp.buffer);
    view.setUint32(0, a >>> 0);
    view.setUint32(4, b >>> 0);
    view.setUint32(8, c >>> 0);
    view.setUint32(12, d >>> 0);
    return { prefix, count: end - start, fp };
  }
};
function sameFingerprint(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}
var CHILDREN = "0123456789abcdef";
function reconcileRanges(local, ranges) {
  const reply = [], push = [], want = [];
  for (const range of ranges) {
    if (typeof range.prefix !== "string" || range.prefix.length > RECONCILE_MAX_PREFIX || !/^[0-9a-f]*$/u.test(range.prefix)) {
      throw new Error("RECONCILE_RANGE_INVALID");
    }
    if ("ids" in range) {
      const theirs = /* @__PURE__ */ new Set();
      for (const id of range.ids) {
        if (!HEX.test(id) || !id.startsWith(range.prefix)) throw new Error("RECONCILE_RANGE_INVALID");
        theirs.add(id);
        if (!local.has(id)) want.push(id);
      }
      for (const id of local.ids(range.prefix)) if (!theirs.has(id)) push.push(id);
      continue;
    }
    const mine = local.summary(range.prefix);
    if (mine.count === range.count && sameFingerprint(mine.fp, range.fp)) continue;
    if (range.count === 0) {
      push.push(...local.ids(range.prefix));
      continue;
    }
    if (mine.count <= RECONCILE_LIST_THRESHOLD || range.prefix.length >= RECONCILE_MAX_PREFIX) {
      reply.push({ prefix: range.prefix, ids: local.ids(range.prefix) });
      continue;
    }
    for (const nibble of CHILDREN) reply.push(local.summary(range.prefix + nibble));
  }
  return { reply, push, want };
}
function rangesNeedReply(ranges) {
  return ranges.some((range) => !("ids" in range));
}

export {
  CAS_NODE_MEDIA_TYPE,
  CAS_SUBGRAPH_MEDIA_TYPE,
  verifyMirrorBuildAttestation,
  verifyMirrorAuditAttestation,
  normalizeVerifiedCasNode,
  encodeCasSubgraphBundle,
  decodeCasSubgraphBundle,
  resolveTrustedBuildOutput,
  createBytesStoreCasMirrorStore,
  createCasAdapterMirrorStore,
  createCasMirrorHandler,
  createCasMirrorClient,
  FactIdSet,
  reconcileRanges,
  rangesNeedReply
};
