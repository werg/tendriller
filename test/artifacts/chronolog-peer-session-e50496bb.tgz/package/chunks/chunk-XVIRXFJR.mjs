import {
  computeCasHash,
  putPackageDag
} from "./chunk-OWL5GQ66.mjs";
import {
  utf8
} from "./chunk-VRR2HFJY.mjs";

// packages/materializer/src/std/crdt.ts
var STD_CRDT_SOURCE = `
function hasWriter(ctx, author) {
  const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
  if (cfg.allowPublicWrite === true) return true;
  const checked = ctx.query('$permissions', { check: 'writer', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  return perms.members.some(m => m.publicKey === author && (m.writer === true || m.administrator === true));
}

function compareStamp(a, b) {
  if (a.ts !== b.ts) return a.ts < b.ts ? -1 : 1;
  if (a.author !== b.author) return a.author < b.author ? -1 : 1;
  if (a.opId !== b.opId) return a.opId < b.opId ? -1 : 1;
  return 0;
}

/**
 * Out-of-order-safe Last-Write-Wins Map CRDT.
 * Each key resolves deterministically by (authorTimestampMs, author, opId).
 */
export const lwwMap = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.entries && typeof state.entries === 'object'
      ? state
      : { entries: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object' || Array.isArray(input)) return { ok: false, code: 'invalid_input' };
    const stamp = { ts: Number(tx.authorTimestampMs || 0), author: tx.author, opId: tx.opId };
    const nextEntries = { ...cur.entries };
    const action = typeof input.action === 'string' ? input.action : 'set';

    if (action === 'set') {
      if (typeof input.key !== 'string' || input.key.length === 0) return { ok: false, code: 'crdt:invalid_key' };
      const existing = nextEntries[input.key];
      if (!existing || compareStamp(stamp, existing) >= 0) {
        nextEntries[input.key] = { value: input.value === undefined ? null : input.value, deleted: false, ...stamp };
      }
      return { ok: true, state: { entries: nextEntries }, events: [{ topic: 'crdt.map.set', payload: { key: input.key } }] };
    }

    if (action === 'delete') {
      if (typeof input.key !== 'string' || input.key.length === 0) return { ok: false, code: 'crdt:invalid_key' };
      const existing = nextEntries[input.key];
      if (!existing || compareStamp(stamp, existing) >= 0) {
        nextEntries[input.key] = { value: null, deleted: true, ...stamp };
      }
      return { ok: true, state: { entries: nextEntries }, events: [{ topic: 'crdt.map.delete', payload: { key: input.key } }] };
    }

    if (action === 'merge') {
      if (!input.values || typeof input.values !== 'object' || Array.isArray(input.values)) {
        return { ok: false, code: 'crdt:invalid_values' };
      }
      const keys = Object.keys(input.values).sort();
      for (const k of keys) {
        const existing = nextEntries[k];
        if (!existing || compareStamp(stamp, existing) >= 0) {
          nextEntries[k] = { value: input.values[k], deleted: false, ...stamp };
        }
      }
      return { ok: true, state: { entries: nextEntries }, events: [{ topic: 'crdt.map.merge', payload: { keys } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const entries = state && state.entries && typeof state.entries === 'object' ? state.entries : {};
    if (input && typeof input === 'object' && typeof input.key === 'string') {
      const e = entries[input.key];
      return !e || e.deleted ? null : e.value;
    }
    const out = {};
    for (const k of Object.keys(entries).sort()) {
      const e = entries[k];
      if (e && !e.deleted) out[k] = e.value;
    }
    return out;
  },
  describe() {
    const anyScalar = { anyOf: [{ type: 'string' }, { type: 'number' }, { type: 'boolean' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'set', description: 'Set a key in the LWW map.', input: { type: 'object', properties: { key: { type: 'string' }, value: anyScalar }, required: ['key'] } },
        { name: 'delete', description: 'Tombstone a key in the LWW map.', input: { type: 'object', properties: { key: { type: 'string' } }, required: ['key'] } },
        { name: 'merge', description: 'Merge multiple key-value pairs into the LWW map.', input: { type: 'object', properties: { values: { type: 'object', properties: {} } }, required: ['values'] } },
      ],
      queries: [
        { name: 'get', description: 'Read all live entries or a single key.', input: { type: 'object', properties: { key: { type: 'string' } } } },
      ],
    };
  },
};

/**
 * Observed-Remove Set (OR-Set) CRDT.
 * Each add receives a unique opId tag; remove clears either explicitly observed tags or all tags present at replay time.
 */
export const orSet = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.tags && typeof state.tags === 'object'
      ? state
      : { tags: {}, removed: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const action = typeof input.action === 'string' ? input.action : 'add';
    const value = typeof input.value === 'string' ? input.value : null;
    if (value === null || value.length === 0) return { ok: false, code: 'crdt:invalid_value' };

    const nextTags = { ...cur.tags };
    const nextRemoved = { ...cur.removed };

    if (action === 'add') {
      const tag = tx.opId;
      if (!nextRemoved[tag]) {
        const list = Array.isArray(nextTags[value]) ? nextTags[value].slice() : [];
        if (!list.includes(tag)) list.push(tag);
        list.sort();
        nextTags[value] = list;
      }
      return { ok: true, state: { tags: nextTags, removed: nextRemoved }, events: [{ topic: 'crdt.set.add', payload: { value } }] };
    }

    if (action === 'remove') {
      const existing = Array.isArray(nextTags[value]) ? nextTags[value] : [];
      const toRemove = Array.isArray(input.observedTags) ? input.observedTags.filter(t => typeof t === 'string') : existing;
      for (const t of toRemove) nextRemoved[t] = true;
      const remaining = existing.filter(t => !nextRemoved[t]);
      if (remaining.length === 0) delete nextTags[value];
      else nextTags[value] = remaining;
      return { ok: true, state: { tags: nextTags, removed: nextRemoved }, events: [{ topic: 'crdt.set.remove', payload: { value } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const tags = state && state.tags && typeof state.tags === 'object' ? state.tags : {};
    const values = Object.keys(tags).filter(k => Array.isArray(tags[k]) && tags[k].length > 0).sort();
    if (input && typeof input === 'object' && typeof input.has === 'string') {
      return values.includes(input.has);
    }
    return { values, tags };
  },
  describe() {
    return {
      commands: [
        { name: 'add', description: 'Add a value with a unique op tag.', input: { type: 'object', properties: { value: { type: 'string' } }, required: ['value'] } },
        { name: 'remove', description: 'Remove observed tags for a value.', input: { type: 'object', properties: { value: { type: 'string' }, observedTags: { type: 'array', items: { type: 'string' } } }, required: ['value'] } },
      ],
      queries: [
        { name: 'values', description: 'List live set values or check membership.', input: { type: 'object', properties: { has: { type: 'string' } } } },
      ],
    };
  },
};

/**
 * Positive-Negative Counter (PN-Counter) CRDT.
 */
export const pnCounter = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.p && state.n ? state : { p: {}, n: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const action = typeof input.action === 'string' ? input.action : 'add';
    const amount = Number(input.amount === undefined ? 1 : input.amount);
    if (!Number.isSafeInteger(amount) || amount < 0) return { ok: false, code: 'crdt:invalid_amount' };

    const p = { ...cur.p };
    const n = { ...cur.n };
    if (action === 'increment' || action === 'add') {
      p[tx.author] = (Number(p[tx.author]) || 0) + amount;
      return { ok: true, state: { p, n }, events: [{ topic: 'crdt.counter.increment', payload: { amount } }] };
    }
    if (action === 'decrement' || action === 'sub') {
      n[tx.author] = (Number(n[tx.author]) || 0) + amount;
      return { ok: true, state: { p, n }, events: [{ topic: 'crdt.counter.decrement', payload: { amount } }] };
    }
    return { ok: false, code: 'unknown_action' };
  },
  query(state) {
    const p = state && state.p && typeof state.p === 'object' ? state.p : {};
    const n = state && state.n && typeof state.n === 'object' ? state.n : {};
    let total = 0;
    for (const v of Object.values(p)) total += Number(v) || 0;
    for (const v of Object.values(n)) total -= Number(v) || 0;
    return { value: total, p, n };
  },
  describe() {
    return {
      commands: [
        { name: 'increment', description: 'Increment the counter.', input: { type: 'object', properties: { amount: { type: 'integer', minimum: 0 } } } },
        { name: 'decrement', description: 'Decrement the counter.', input: { type: 'object', properties: { amount: { type: 'integer', minimum: 0 } } } },
      ],
      queries: [
        { name: 'value', description: 'Read the converged total and per-author vectors.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};

function linearizeOrderedNodes(nodes) {
  const byParent = {};
  for (const id of Object.keys(nodes)) {
    const node = nodes[id];
    const parentKey = node.afterId && nodes[node.afterId] ? node.afterId : '__root__';
    if (!byParent[parentKey]) byParent[parentKey] = [];
    byParent[parentKey].push(node);
  }
  for (const key of Object.keys(byParent)) {
    // RGA tie-break: newer (higher ts/author/opId) concurrent siblings come FIRST right after their parent
    byParent[key].sort((a, b) => compareStamp(b, a));
  }
  const result = [];
  const visited = {};
  function walk(parentKey) {
    const children = byParent[parentKey];
    if (!children) return;
    for (const child of children) {
      if (visited[child.id]) continue;
      visited[child.id] = true;
      if (!child.deleted) result.push(child);
      walk(child.id);
    }
  }
  walk('__root__');
  return result;
}

/**
 * RGA Ordered List CRDT with deterministic concurrent insert and move support (Kanban / checklists).
 */
export const orderedList = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.nodes && typeof state.nodes === 'object'
      ? state
      : { nodes: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const action = typeof input.action === 'string' ? input.action : 'insert';
    const stamp = { ts: Number(tx.authorTimestampMs || 0), author: tx.author, opId: tx.opId };
    const nextNodes = { ...cur.nodes };

    if (action === 'insert') {
      const id = typeof input.id === 'string' && input.id.length > 0 ? input.id : tx.opId;
      if (nextNodes[id]) return { ok: false, code: 'crdt:duplicate_id' };
      const afterId = typeof input.afterId === 'string' && input.afterId.length > 0 ? input.afterId : null;
      nextNodes[id] = { id, afterId, value: input.value === undefined ? null : input.value, deleted: false, ...stamp };
      return { ok: true, state: { nodes: nextNodes }, events: [{ topic: 'crdt.list.insert', payload: { id } }] };
    }

    if (action === 'move') {
      const id = typeof input.id === 'string' ? input.id : '';
      const existing = nextNodes[id];
      if (!existing || existing.deleted) return { ok: false, code: 'crdt:item_not_found' };
      const afterId = typeof input.afterId === 'string' && input.afterId.length > 0 ? input.afterId : null;
      if (afterId === id) return { ok: false, code: 'crdt:cycle_forbidden' };
      // Prevent cycle by walking ancestors of afterId
      let cursor = afterId;
      let guard = 0;
      while (cursor && nextNodes[cursor] && guard++ < 10000) {
        if (cursor === id) return { ok: false, code: 'crdt:cycle_forbidden' };
        cursor = nextNodes[cursor].afterId;
      }
      nextNodes[id] = { ...existing, afterId, ...stamp };
      return { ok: true, state: { nodes: nextNodes }, events: [{ topic: 'crdt.list.move', payload: { id, afterId } }] };
    }

    if (action === 'update') {
      const id = typeof input.id === 'string' ? input.id : '';
      const existing = nextNodes[id];
      if (!existing || existing.deleted) return { ok: false, code: 'crdt:item_not_found' };
      nextNodes[id] = { ...existing, value: input.value === undefined ? null : input.value };
      return { ok: true, state: { nodes: nextNodes }, events: [{ topic: 'crdt.list.update', payload: { id } }] };
    }

    if (action === 'delete') {
      const id = typeof input.id === 'string' ? input.id : '';
      const existing = nextNodes[id];
      if (!existing) return { ok: false, code: 'crdt:item_not_found' };
      nextNodes[id] = { ...existing, deleted: true };
      return { ok: true, state: { nodes: nextNodes }, events: [{ topic: 'crdt.list.delete', payload: { id } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state) {
    const nodes = state && state.nodes && typeof state.nodes === 'object' ? state.nodes : {};
    const items = linearizeOrderedNodes(nodes).map(n => ({ id: n.id, value: n.value }));
    return { items };
  },
  describe() {
    const anyScalar = { anyOf: [{ type: 'string' }, { type: 'number' }, { type: 'boolean' }, { type: 'null' }] };
    const optStr = { anyOf: [{ type: 'string' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'insert', description: 'Insert an item after an anchor ID (or null for head).', input: { type: 'object', properties: { id: { type: 'string' }, afterId: optStr, value: anyScalar } } },
        { name: 'move', description: 'Move an existing item after another anchor ID.', input: { type: 'object', properties: { id: { type: 'string' }, afterId: optStr }, required: ['id'] } },
        { name: 'update', description: 'Update an item value.', input: { type: 'object', properties: { id: { type: 'string' }, value: anyScalar }, required: ['id'] } },
        { name: 'delete', description: 'Tombstone an item.', input: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
      ],
      queries: [
        { name: 'items', description: 'Return the converged ordered list.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/text.ts
var STD_TEXT_SOURCE = `
function hasWriter(ctx, author) {
  const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
  if (cfg.allowPublicWrite === true) return true;
  const checked = ctx.query('$permissions', { check: 'writer', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  return perms.members.some(m => m.publicKey === author && (m.writer === true || m.administrator === true));
}

function compareStamp(a, b) {
  if (a.ts !== b.ts) return a.ts < b.ts ? -1 : 1;
  if (a.author !== b.author) return a.author < b.author ? -1 : 1;
  if (a.opId !== b.opId) return a.opId < b.opId ? -1 : 1;
  if (a.seq !== b.seq) return a.seq < b.seq ? -1 : 1;
  return 0;
}

/**
 * Linearize RGA character/token nodes deterministically.
 * Each character node has a stable ID "<opId>:<offset>" so concurrent edits merge cleanly
 * without index drift under arbitrary out-of-order replay.
 */
function linearize(nodes) {
  const byParent = {};
  for (const id of Object.keys(nodes)) {
    const n = nodes[id];
    const parent = n.afterId && nodes[n.afterId] ? n.afterId : '__root__';
    if (!byParent[parent]) byParent[parent] = [];
    byParent[parent].push(n);
  }
  for (const key of Object.keys(byParent)) {
    byParent[key].sort((a, b) => compareStamp(b, a));
  }
  const ordered = [];
  const visited = {};
  function walk(parent) {
    const children = byParent[parent];
    if (!children) return;
    for (const child of children) {
      if (visited[child.id]) continue;
      visited[child.id] = true;
      ordered.push(child);
      walk(child.id);
    }
  }
  walk('__root__');
  return ordered;
}

function visibleNodes(nodes) {
  return linearize(nodes).filter(n => !n.deleted);
}

/**
 * Deterministic RGA Collaborative Text CRDT for prose, notes, and code co-editing.
 * Supports stable node-anchored edits (insert/delete) and index convenience helpers (insertAt/deleteRange).
 */
export const collaborativeText = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.nodes && typeof state.nodes === 'object'
      ? state
      : { nodes: {}, anchors: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const action = typeof input.action === 'string' ? input.action : 'insert';
    const nextNodes = { ...cur.nodes };
    const nextAnchors = { ...(cur.anchors || {}) };
    const baseTs = Number(tx.authorTimestampMs || 0);

    if (action === 'insert' || action === 'insertAt') {
      if (typeof input.text !== 'string' || input.text.length === 0) {
        return { ok: false, code: 'text:empty_insert' };
      }
      if (input.text.length > 4096) return { ok: false, code: 'text:insert_too_large' };
      let afterId = null;
      if (action === 'insert') {
        afterId = typeof input.afterId === 'string' && input.afterId.length > 0 ? input.afterId : null;
      } else {
        const vis = visibleNodes(nextNodes);
        const idx = Number.isSafeInteger(input.index) ? Math.max(0, Math.min(input.index, vis.length)) : vis.length;
        afterId = idx === 0 ? null : vis[idx - 1].id;
      }
      const chars = Array.from(input.text);
      let prevId = afterId;
      const insertedIds = [];
      for (let i = 0; i < chars.length; i++) {
        const id = tx.opId + ':' + i;
        nextNodes[id] = {
          id,
          afterId: prevId,
          ch: chars[i],
          deleted: false,
          ts: baseTs,
          author: tx.author,
          opId: tx.opId,
          seq: i,
        };
        insertedIds.push(id);
        prevId = id;
      }
      return {
        ok: true,
        state: { nodes: nextNodes, anchors: nextAnchors },
        events: [{ topic: 'text.insert', payload: { count: chars.length, firstId: insertedIds[0], lastId: insertedIds[insertedIds.length - 1] } }],
      };
    }

    if (action === 'delete') {
      if (!Array.isArray(input.ids) || input.ids.length === 0) return { ok: false, code: 'text:ids_required' };
      let deletedCount = 0;
      for (const id of input.ids) {
        if (typeof id === 'string' && nextNodes[id] && !nextNodes[id].deleted) {
          nextNodes[id] = { ...nextNodes[id], deleted: true };
          deletedCount++;
        }
      }
      return {
        ok: true,
        state: { nodes: nextNodes, anchors: nextAnchors },
        events: [{ topic: 'text.delete', payload: { count: deletedCount } }],
      };
    }

    if (action === 'deleteRange') {
      const vis = visibleNodes(nextNodes);
      const index = Number(input.index);
      const length = Number(input.length);
      if (!Number.isSafeInteger(index) || !Number.isSafeInteger(length) || index < 0 || length < 0) {
        return { ok: false, code: 'text:invalid_range' };
      }
      const slice = vis.slice(index, index + length);
      for (const node of slice) {
        nextNodes[node.id] = { ...node, deleted: true };
      }
      return {
        ok: true,
        state: { nodes: nextNodes, anchors: nextAnchors },
        events: [{ topic: 'text.delete', payload: { count: slice.length } }],
      };
    }

    if (action === 'setAnchor') {
      if (typeof input.name !== 'string' || input.name.length === 0) return { ok: false, code: 'text:invalid_anchor' };
      const nodeId = typeof input.nodeId === 'string' && input.nodeId.length > 0 ? input.nodeId : null;
      nextAnchors[input.name] = { nodeId, updatedBy: tx.author, updatedAtMs: baseTs };
      return { ok: true, state: { nodes: nextNodes, anchors: nextAnchors } };
    }

    return { ok: false, code: 'unknown_action' };
  },

  query(state, input) {
    const nodes = state && state.nodes && typeof state.nodes === 'object' ? state.nodes : {};
    const anchors = state && state.anchors && typeof state.anchors === 'object' ? state.anchors : {};
    const vis = visibleNodes(nodes);
    const kind = input && typeof input === 'object' ? (input.query || input.kind) : 'text';
    if (kind === 'nodes') {
      return { nodes: vis.map(n => ({ id: n.id, ch: n.ch })) };
    }
    if (kind === 'anchors') {
      const idxById = {};
      for (let i = 0; i < vis.length; i++) idxById[vis[i].id] = i;
      const resolved = {};
      for (const name of Object.keys(anchors).sort()) {
        const a = anchors[name];
        resolved[name] = {
          ...a,
          index: a.nodeId && Object.prototype.hasOwnProperty.call(idxById, a.nodeId) ? idxById[a.nodeId] + 1 : 0,
        };
      }
      return { anchors: resolved };
    }
    const text = vis.map(n => n.ch).join('');
    if (kind === 'stats') {
      return { length: vis.length, totalNodes: Object.keys(nodes).length, text };
    }
    return { text, length: vis.length, lastNodeId: vis.length > 0 ? vis[vis.length - 1].id : null };
  },

  describe() {
    const optStr = { anyOf: [{ type: 'string' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'insert', description: 'Insert text anchored after a stable node ID (or null for start).', input: { type: 'object', properties: { afterId: optStr, text: { type: 'string' } }, required: ['text'] } },
        { name: 'insertAt', description: 'Insert text at a character index.', input: { type: 'object', properties: { index: { type: 'integer', minimum: 0 }, text: { type: 'string' } }, required: ['text'] } },
        { name: 'delete', description: 'Delete characters by stable node IDs.', input: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' } } }, required: ['ids'] } },
        { name: 'deleteRange', description: 'Delete a visible character range.', input: { type: 'object', properties: { index: { type: 'integer', minimum: 0 }, length: { type: 'integer', minimum: 0 } }, required: ['index', 'length'] } },
        { name: 'setAnchor', description: 'Save a named cursor/comment anchor on a stable node ID.', input: { type: 'object', properties: { name: { type: 'string' }, nodeId: optStr }, required: ['name'] } },
      ],
      queries: [
        { name: 'text', description: 'Read the converged string and tail node ID.', input: { type: 'object', properties: {} } },
        { name: 'nodes', description: 'Read visible character nodes with stable IDs.', input: { type: 'object', properties: {} } },
        { name: 'anchors', description: 'Resolve saved anchors to current character indices.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/ledger.ts
var STD_LEDGER_SOURCE = `
function hasCap(ctx, cap, author) {
  const checked = ctx.query('$permissions', { check: cap, actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  const m = perms.members.find(x => x.publicKey === author);
  if (!m) return false;
  if (cap === 'administrator') return m.administrator === true;
  if (cap === 'writer') return m.writer === true || m.administrator === true;
  return false;
}

function normalizeState(state) {
  const s = state && typeof state === 'object' ? state : {};
  return {
    accounts: s.accounts && typeof s.accounts === 'object' ? { ...s.accounts } : {},
    holds: s.holds && typeof s.holds === 'object' ? { ...s.holds } : {},
    allowances: s.allowances && typeof s.allowances === 'object' ? { ...s.allowances } : {},
    entries: Array.isArray(s.entries) ? s.entries.slice() : [],
  };
}

function reservedAmount(state, accountId, nowMs) {
  let reserved = 0;
  for (const h of Object.values(state.holds)) {
    if (h.status === 'active' && h.from === accountId && (h.expiresAtMs === null || nowMs <= h.expiresAtMs)) {
      reserved += h.amount;
    }
  }
  for (const a of Object.values(state.allowances)) {
    if (a.status === 'active' && a.fromAccount === accountId && (a.expiresAtMs === null || nowMs <= a.expiresAtMs)) {
      reserved += a.remaining;
    }
  }
  return reserved;
}

function availableBalance(state, accountId, nowMs) {
  const acct = state.accounts[accountId];
  if (!acct) return 0;
  return acct.balance - reservedAmount(state, accountId, nowMs);
}

/**
 * Deterministic Double-Entry Ledger with:
 * - Balanced integer postings (sum === 0) and per-account non-negative invariants
 * - Expiring holds/escrows (automatically release when authorTimestampMs > expiresAtMs)
 * - Offline Escrow CRDT allowances (grantee spends autonomously offline up to reserved quota)
 */
export const doubleEntryLedger = {
  reduce(state, tx, ctx) {
    const cur = normalizeState(state);
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const isAdmin = hasCap(ctx, 'administrator', tx.author);
    const isWriter = isAdmin || hasCap(ctx, 'writer', tx.author);
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = typeof input.action === 'string' ? input.action : 'post';

    if (action === 'createAccount') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const id = typeof input.id === 'string' && input.id.length > 0 ? input.id : null;
      if (!id) return { ok: false, code: 'ledger:invalid_account_id' };
      if (cur.accounts[id]) return { ok: false, code: 'ledger:account_exists' };
      const allowNegative = input.allowNegative === true;
      if (allowNegative && !isAdmin) return { ok: false, code: 'admin_required' };
      cur.accounts[id] = {
        id,
        currency: typeof input.currency === 'string' && input.currency.length > 0 ? input.currency : 'USD',
        balance: 0,
        allowNegative,
        owner: typeof input.owner === 'string' ? input.owner : tx.author,
      };
      return { ok: true, state: cur, events: [{ topic: 'ledger.account_created', payload: { id } }] };
    }

    if (action === 'post') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      if (!Array.isArray(input.postings) || input.postings.length < 2) return { ok: false, code: 'ledger:postings_required' };
      let sum = 0;
      const currencies = new Set();
      const deltas = {};
      for (const p of input.postings) {
        if (!p || typeof p.account !== 'string' || !Number.isSafeInteger(p.delta) || p.delta === 0) {
          return { ok: false, code: 'ledger:invalid_posting' };
        }
        const acct = cur.accounts[p.account];
        if (!acct) return { ok: false, code: 'ledger:account_not_found', detail: p.account };
        currencies.add(acct.currency);
        sum += p.delta;
        deltas[p.account] = (deltas[p.account] || 0) + p.delta;
      }
      if (currencies.size !== 1) return { ok: false, code: 'ledger:currency_mismatch' };
      if (sum !== 0) return { ok: false, code: 'ledger:unbalanced' };
      for (const [acctId, delta] of Object.entries(deltas)) {
        const acct = cur.accounts[acctId];
        if (!acct.allowNegative && availableBalance(cur, acctId, nowMs) + delta < 0) {
          return { ok: false, code: 'ledger:insufficient_funds', detail: acctId };
        }
      }
      for (const [acctId, delta] of Object.entries(deltas)) {
        cur.accounts[acctId] = { ...cur.accounts[acctId], balance: cur.accounts[acctId].balance + delta };
      }
      const entry = {
        opId: tx.opId,
        author: tx.author,
        ts: nowMs,
        memo: typeof input.memo === 'string' ? input.memo : '',
        postings: input.postings.map(p => ({ account: p.account, delta: p.delta })),
      };
      cur.entries = cur.entries.concat([entry]).slice(-512);
      return { ok: true, state: cur, events: [{ topic: 'ledger.posted', payload: { opId: tx.opId } }] };
    }

    if (action === 'hold') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const holdId = typeof input.holdId === 'string' && input.holdId.length > 0 ? input.holdId : tx.opId;
      if (cur.holds[holdId]) return { ok: false, code: 'ledger:hold_exists' };
      const amount = Number(input.amount);
      if (!Number.isSafeInteger(amount) || amount <= 0) return { ok: false, code: 'ledger:invalid_amount' };
      const fromAcct = cur.accounts[input.from];
      const toAcct = cur.accounts[input.to];
      if (!fromAcct || !toAcct) return { ok: false, code: 'ledger:account_not_found' };
      if (fromAcct.currency !== toAcct.currency) return { ok: false, code: 'ledger:currency_mismatch' };
      if (!fromAcct.allowNegative && availableBalance(cur, fromAcct.id, nowMs) < amount) {
        return { ok: false, code: 'ledger:insufficient_funds', detail: fromAcct.id };
      }
      const expiresAtMs = input.expiresAtMs === undefined || input.expiresAtMs === null ? null : Number(input.expiresAtMs);
      if (expiresAtMs !== null && !Number.isSafeInteger(expiresAtMs)) return { ok: false, code: 'ledger:invalid_expiry' };
      cur.holds[holdId] = {
        holdId,
        from: fromAcct.id,
        to: toAcct.id,
        amount,
        expiresAtMs,
        status: 'active',
        createdBy: tx.author,
        createdAtMs: nowMs,
      };
      return { ok: true, state: cur, events: [{ topic: 'ledger.hold_created', payload: { holdId, amount } }] };
    }

    if (action === 'captureHold') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const h = cur.holds[input.holdId];
      if (!h || h.status !== 'active') return { ok: false, code: 'ledger:hold_not_active' };
      if (h.expiresAtMs !== null && nowMs > h.expiresAtMs) return { ok: false, code: 'ledger:hold_expired' };
      const captureAmt = input.amount === undefined ? h.amount : Number(input.amount);
      if (!Number.isSafeInteger(captureAmt) || captureAmt <= 0 || captureAmt > h.amount) {
        return { ok: false, code: 'ledger:invalid_amount' };
      }
      cur.accounts[h.from] = { ...cur.accounts[h.from], balance: cur.accounts[h.from].balance - captureAmt };
      cur.accounts[h.to] = { ...cur.accounts[h.to], balance: cur.accounts[h.to].balance + captureAmt };
      cur.holds[h.holdId] = { ...h, status: 'captured', capturedAmount: captureAmt };
      cur.entries = cur.entries.concat([{
        opId: tx.opId,
        author: tx.author,
        ts: nowMs,
        memo: 'capture:' + h.holdId,
        postings: [{ account: h.from, delta: -captureAmt }, { account: h.to, delta: captureAmt }],
      }]).slice(-512);
      return { ok: true, state: cur, events: [{ topic: 'ledger.hold_captured', payload: { holdId: h.holdId, amount: captureAmt } }] };
    }

    if (action === 'releaseHold') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const h = cur.holds[input.holdId];
      if (!h || h.status !== 'active') return { ok: false, code: 'ledger:hold_not_active' };
      if (!isAdmin && h.createdBy !== tx.author) return { ok: false, code: 'admin_or_creator_required' };
      cur.holds[h.holdId] = { ...h, status: 'released' };
      return { ok: true, state: cur, events: [{ topic: 'ledger.hold_released', payload: { holdId: h.holdId } }] };
    }

    if (action === 'grantAllowance') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const allowanceId = typeof input.allowanceId === 'string' && input.allowanceId.length > 0 ? input.allowanceId : tx.opId;
      if (cur.allowances[allowanceId]) return { ok: false, code: 'ledger:allowance_exists' };
      const amount = Number(input.amount);
      if (!Number.isSafeInteger(amount) || amount <= 0) return { ok: false, code: 'ledger:invalid_amount' };
      const fromAcct = cur.accounts[input.fromAccount];
      if (!fromAcct) return { ok: false, code: 'ledger:account_not_found' };
      if (typeof input.grantee !== 'string' || input.grantee.length === 0) return { ok: false, code: 'ledger:invalid_grantee' };
      if (!fromAcct.allowNegative && availableBalance(cur, fromAcct.id, nowMs) < amount) {
        return { ok: false, code: 'ledger:insufficient_funds', detail: fromAcct.id };
      }
      const expiresAtMs = input.expiresAtMs === undefined || input.expiresAtMs === null ? null : Number(input.expiresAtMs);
      cur.allowances[allowanceId] = {
        allowanceId,
        fromAccount: fromAcct.id,
        grantee: input.grantee,
        granted: amount,
        remaining: amount,
        expiresAtMs,
        status: 'active',
        grantedBy: tx.author,
        grantedAtMs: nowMs,
      };
      return { ok: true, state: cur, events: [{ topic: 'ledger.allowance_granted', payload: { allowanceId, grantee: input.grantee, amount } }] };
    }

    if (action === 'spendFromAllowance') {
      const al = cur.allowances[input.allowanceId];
      if (!al || al.status !== 'active') return { ok: false, code: 'ledger:allowance_not_active' };
      if (al.grantee !== tx.author && !isAdmin) return { ok: false, code: 'ledger:grantee_required' };
      if (al.expiresAtMs !== null && nowMs > al.expiresAtMs) return { ok: false, code: 'ledger:allowance_expired' };
      const amount = Number(input.amount);
      if (!Number.isSafeInteger(amount) || amount <= 0 || amount > al.remaining) {
        return { ok: false, code: 'ledger:allowance_exceeded' };
      }
      const toAcct = cur.accounts[input.toAccount];
      const fromAcct = cur.accounts[al.fromAccount];
      if (!toAcct || !fromAcct) return { ok: false, code: 'ledger:account_not_found' };
      if (fromAcct.currency !== toAcct.currency) return { ok: false, code: 'ledger:currency_mismatch' };
      cur.accounts[fromAcct.id] = { ...fromAcct, balance: fromAcct.balance - amount };
      cur.accounts[toAcct.id] = { ...toAcct, balance: toAcct.balance + amount };
      cur.allowances[al.allowanceId] = { ...al, remaining: al.remaining - amount };
      cur.entries = cur.entries.concat([{
        opId: tx.opId,
        author: tx.author,
        ts: nowMs,
        memo: typeof input.memo === 'string' ? input.memo : ('allowance:' + al.allowanceId),
        postings: [{ account: fromAcct.id, delta: -amount }, { account: toAcct.id, delta: amount }],
      }]).slice(-512);
      return { ok: true, state: cur, events: [{ topic: 'ledger.allowance_spent', payload: { allowanceId: al.allowanceId, amount, remaining: al.remaining - amount } }] };
    }

    if (action === 'reclaimAllowance') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const al = cur.allowances[input.allowanceId];
      if (!al || al.status !== 'active') return { ok: false, code: 'ledger:allowance_not_active' };
      cur.allowances[al.allowanceId] = { ...al, status: 'reclaimed', remaining: 0 };
      return { ok: true, state: cur, events: [{ topic: 'ledger.allowance_reclaimed', payload: { allowanceId: al.allowanceId } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },

  query(state, input) {
    const cur = normalizeState(state);
    const q = input && typeof input === 'object' ? input : {};
    const atMs = Number.isSafeInteger(q.atMs) ? q.atMs : 0;
    const kind = q.query || q.kind || 'balances';
    if (kind === 'account' && typeof q.id === 'string') {
      const a = cur.accounts[q.id];
      if (!a) return null;
      return { ...a, available: availableBalance(cur, a.id, atMs) };
    }
    if (kind === 'holds') return { holds: Object.values(cur.holds) };
    if (kind === 'allowances') {
      const list = Object.values(cur.allowances);
      return { allowances: typeof q.grantee === 'string' ? list.filter(a => a.grantee === q.grantee) : list };
    }
    if (kind === 'entries') return { entries: cur.entries };
    const balances = {};
    for (const id of Object.keys(cur.accounts).sort()) {
      const a = cur.accounts[id];
      balances[id] = { currency: a.currency, balance: a.balance, available: availableBalance(cur, id, atMs) };
    }
    return { balances };
  },

  describe() {
    const optInt = { anyOf: [{ type: 'integer' }, { type: 'null' }] };
    const postingItem = { type: 'object', properties: { account: { type: 'string' }, delta: { type: 'integer' } }, required: ['account', 'delta'] };
    return {
      commands: [
        { name: 'createAccount', description: 'Create a ledger account.', input: { type: 'object', properties: { id: { type: 'string' }, currency: { type: 'string' }, allowNegative: { type: 'boolean' } }, required: ['id'] } },
        { name: 'post', description: 'Submit balanced double-entry postings.', input: { type: 'object', properties: { postings: { type: 'array', items: postingItem }, memo: { type: 'string' } }, required: ['postings'] } },
        { name: 'hold', description: 'Reserve funds in an expiring hold/escrow.', input: { type: 'object', properties: { holdId: { type: 'string' }, from: { type: 'string' }, to: { type: 'string' }, amount: { type: 'integer' }, expiresAtMs: optInt }, required: ['from', 'to', 'amount'] } },
        { name: 'captureHold', description: 'Settle an active hold.', input: { type: 'object', properties: { holdId: { type: 'string' }, amount: { type: 'integer' } }, required: ['holdId'] } },
        { name: 'releaseHold', description: 'Release an active hold.', input: { type: 'object', properties: { holdId: { type: 'string' } }, required: ['holdId'] } },
        { name: 'grantAllowance', description: 'Reserve an offline Escrow CRDT spending allowance for a peer or agent.', input: { type: 'object', properties: { allowanceId: { type: 'string' }, fromAccount: { type: 'string' }, grantee: { type: 'string' }, amount: { type: 'integer' }, expiresAtMs: optInt }, required: ['fromAccount', 'grantee', 'amount'] } },
        { name: 'spendFromAllowance', description: 'Spend offline from a granted allowance without global consensus.', input: { type: 'object', properties: { allowanceId: { type: 'string' }, toAccount: { type: 'string' }, amount: { type: 'integer' }, memo: { type: 'string' } }, required: ['allowanceId', 'toAccount', 'amount'] } },
        { name: 'reclaimAllowance', description: 'Reclaim unused funds from an allowance.', input: { type: 'object', properties: { allowanceId: { type: 'string' } }, required: ['allowanceId'] } },
      ],
      queries: [
        { name: 'balances', description: 'Read posted and available balances.', input: { type: 'object', properties: { atMs: { type: 'integer' } } } },
        { name: 'allowances', description: 'List active offline spending allowances.', input: { type: 'object', properties: { grantee: { type: 'string' } } } },
        { name: 'holds', description: 'List holds and escrows.', input: { type: 'object', properties: {} } },
        { name: 'entries', description: 'Read ledger entry history.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/workflow.ts
var STD_WORKFLOW_SOURCE = `
function hasCap(ctx, cap, author) {
  const checked = ctx.query('$permissions', { check: cap, actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  const m = perms.members.find(x => x.publicKey === author);
  if (!m) return false;
  if (cap === 'administrator') return m.administrator === true;
  if (cap === 'writer') return m.writer === true || m.administrator === true;
  return false;
}

function normalizeWorkflow(state, config) {
  const cfg = config && typeof config === 'object' ? config : {};
  const s = state && typeof state === 'object' ? state : {};
  const def = s.definition && typeof s.definition === 'object'
    ? s.definition
    : (cfg.definition && typeof cfg.definition === 'object' ? cfg.definition : {
        initialState: 'proposed',
        states: ['proposed', 'approved', 'rejected', 'expired'],
        transitions: [
          { name: 'approve', from: 'proposed', to: 'approved', roles: ['administrator'], distinctFromCreator: false, requiredApprovals: 1 },
          { name: 'reject', from: 'proposed', to: 'rejected', roles: ['administrator'], distinctFromCreator: false, requiredApprovals: 1 },
        ],
      });
  return {
    definition: def,
    items: s.items && typeof s.items === 'object' ? { ...s.items } : {},
  };
}

/**
 * Deterministic Workflow / State-Machine & Approval Queue Reducer.
 * Supports role guards, separation of duties (reviewer !== creator), M-of-N item sign-offs,
 * SLA expiry, and AI-agent proposal review queues.
 */
export const stateMachine = {
  reduce(state, tx, ctx) {
    const cur = normalizeWorkflow(state, ctx.config);
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const isAdmin = hasCap(ctx, 'administrator', tx.author);
    const isWriter = isAdmin || hasCap(ctx, 'writer', tx.author);
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = typeof input.action === 'string' ? input.action : 'create';

    if (action === 'configure') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const def = input.definition;
      if (!def || typeof def !== 'object' || !Array.isArray(def.states) || !Array.isArray(def.transitions) || typeof def.initialState !== 'string') {
        return { ok: false, code: 'workflow:invalid_definition' };
      }
      return { ok: true, state: { ...cur, definition: def }, events: [{ topic: 'workflow.configured', payload: { states: def.states } }] };
    }

    if (action === 'create') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const id = typeof input.id === 'string' && input.id.length > 0 ? input.id : tx.opId;
      if (cur.items[id]) return { ok: false, code: 'workflow:item_exists' };
      const initialState = typeof input.initialState === 'string' ? input.initialState : cur.definition.initialState;
      if (!cur.definition.states.includes(initialState)) return { ok: false, code: 'workflow:invalid_state' };
      cur.items[id] = {
        id,
        title: typeof input.title === 'string' ? input.title : '',
        state: initialState,
        createdBy: tx.author,
        createdAtMs: nowMs,
        enteredAtMs: nowMs,
        payload: input.payload === undefined ? null : input.payload,
        approvals: {},
        history: [{ state: initialState, actor: tx.author, ts: nowMs, opId: tx.opId }],
      };
      return { ok: true, state: cur, events: [{ topic: 'workflow.created', payload: { id, state: initialState } }] };
    }

    if (action === 'transition') {
      const id = typeof input.id === 'string' ? input.id : '';
      const item = cur.items[id];
      if (!item) return { ok: false, code: 'workflow:item_not_found' };
      const tName = typeof input.transition === 'string' ? input.transition : '';
      const rule = cur.definition.transitions.find(r =>
        r.name === tName && (Array.isArray(r.from) ? r.from.includes(item.state) : r.from === item.state),
      );
      if (!rule) return { ok: false, code: 'workflow:transition_not_allowed' };
      if (rule.slaMs !== undefined && rule.slaMs !== null && nowMs > item.enteredAtMs + Number(rule.slaMs)) {
        return { ok: false, code: 'workflow:sla_expired' };
      }
      if (rule.distinctFromCreator === true && tx.author === item.createdBy) {
        return { ok: false, code: 'workflow:separation_of_duties' };
      }
      const roles = Array.isArray(rule.roles) && rule.roles.length > 0 ? rule.roles : ['writer'];
      const authorized = roles.some(role => {
        if (role === 'administrator' || role === 'admin') return isAdmin;
        if (role === 'writer') return isWriter;
        return Boolean(ctx.query('$permissions', { check: 'scope', actor: tx.author, scope: role, atMs: nowMs }));
      });
      if (!authorized) return { ok: false, code: 'workflow:role_required' };

      const required = Number.isSafeInteger(rule.requiredApprovals) && rule.requiredApprovals > 0 ? rule.requiredApprovals : 1;
      const nextApprovals = { ...(item.approvals || {}) };
      const currentSigners = Array.isArray(nextApprovals[tName]) ? nextApprovals[tName].slice() : [];
      if (!currentSigners.includes(tx.author)) currentSigners.push(tx.author);
      currentSigners.sort();
      nextApprovals[tName] = currentSigners;

      if (currentSigners.length < required) {
        cur.items[id] = { ...item, approvals: nextApprovals };
        return {
          ok: true,
          state: cur,
          events: [{ topic: 'workflow.approval_recorded', payload: { id, transition: tName, count: currentSigners.length, required } }],
        };
      }

      const nextHistory = item.history.concat([{
        transition: tName,
        from: item.state,
        state: rule.to,
        actor: tx.author,
        ts: nowMs,
        opId: tx.opId,
        ...(typeof input.note === 'string' && input.note.length > 0 ? { note: input.note } : {}),
      }]);
      cur.items[id] = {
        ...item,
        state: rule.to,
        enteredAtMs: nowMs,
        approvals: {},
        ...(input.payload !== undefined ? { payload: input.payload } : {}),
        history: nextHistory,
      };
      return {
        ok: true,
        state: cur,
        events: [{ topic: 'workflow.transitioned', payload: { id, transition: tName, from: item.state, to: rule.to } }],
      };
    }

    if (action === 'expire') {
      const id = typeof input.id === 'string' ? input.id : '';
      const item = cur.items[id];
      if (!item) return { ok: false, code: 'workflow:item_not_found' };
      const rule = cur.definition.transitions.find(r =>
        r.slaMs !== undefined && r.slaMs !== null && r.expiredTo &&
        (Array.isArray(r.from) ? r.from.includes(item.state) : r.from === item.state),
      );
      if (!rule) return { ok: false, code: 'workflow:no_sla_rule' };
      if (nowMs <= item.enteredAtMs + Number(rule.slaMs)) return { ok: false, code: 'workflow:not_yet_expired' };
      cur.items[id] = {
        ...item,
        state: rule.expiredTo,
        enteredAtMs: nowMs,
        approvals: {},
        history: item.history.concat([{ transition: 'expire', from: item.state, state: rule.expiredTo, actor: tx.author, ts: nowMs, opId: tx.opId }]),
      };
      return { ok: true, state: cur, events: [{ topic: 'workflow.expired', payload: { id, to: rule.expiredTo } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },

  query(state, input) {
    const cur = normalizeWorkflow(state, null);
    const q = input && typeof input === 'object' ? input : {};
    const kind = q.query || q.kind || 'list';
    if (kind === 'config') return cur.definition;
    if (kind === 'item' && typeof q.id === 'string') return cur.items[q.id] || null;
    const all = Object.values(cur.items);
    const filtered = typeof q.state === 'string' ? all.filter(i => i.state === q.state) : all;
    filtered.sort((a, b) => (a.createdAtMs !== b.createdAtMs ? a.createdAtMs - b.createdAtMs : (a.id < b.id ? -1 : 1)));
    return { items: filtered };
  },

  describe() {
    const anyPayload = { anyOf: [{ type: 'object', properties: {} }, { type: 'string' }, { type: 'number' }, { type: 'boolean' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'configure', description: 'Configure states, transitions, role guards, and SLA rules.', input: { type: 'object', properties: { definition: { type: 'object', properties: {} } }, required: ['definition'] } },
        { name: 'create', description: 'Create a workflow item or AI proposal.', input: { type: 'object', properties: { id: { type: 'string' }, title: { type: 'string' }, payload: anyPayload } } },
        { name: 'transition', description: 'Approve or execute a state transition.', input: { type: 'object', properties: { id: { type: 'string' }, transition: { type: 'string' }, note: { type: 'string' } }, required: ['id', 'transition'] } },
        { name: 'expire', description: 'Transition an item past its SLA deadline.', input: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
      ],
      queries: [
        { name: 'list', description: 'List workflow items (optionally filtered by state).', input: { type: 'object', properties: { state: { type: 'string' } } } },
        { name: 'item', description: 'Inspect one workflow item and its history.', input: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
        { name: 'config', description: 'Inspect active state machine definition.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/fs.ts
var STD_FS_SOURCE = `
function hasWriter(ctx, author) {
  const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
  if (cfg.allowPublicWrite === true) return true;
  const checked = ctx.query('$permissions', { check: 'writer', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  return perms.members.some(m => m.publicKey === author && (m.writer === true || m.administrator === true));
}

function normalizePath(raw) {
  if (typeof raw !== 'string') return null;
  const parts = raw.split('/').filter(Boolean);
  if (parts.length === 0) return '/';
  for (const p of parts) {
    if (p === '.' || p === '..' || p.length > 128) return null;
  }
  return '/' + parts.join('/');
}

function parentPath(p) {
  if (p === '/') return null;
  const idx = p.lastIndexOf('/');
  return idx <= 0 ? '/' : p.slice(0, idx);
}

function conflictPathFor(path, author, opId) {
  const slash = path.lastIndexOf('/');
  const dir = path.slice(0, slash + 1);
  const name = path.slice(slash + 1);
  const dot = name.lastIndexOf('.');
  const tag = ' (conflict-' + String(author).slice(0, 8) + '-' + String(opId).slice(0, 6) + ')';
  if (dot > 0) return dir + name.slice(0, dot) + tag + name.slice(dot);
  return dir + name + tag;
}

function normalizeFs(state) {
  const s = state && typeof state === 'object' && state.entries && typeof state.entries === 'object'
    ? { entries: { ...state.entries } }
    : { entries: { '/': { kind: 'dir', path: '/', createdAtMs: 0 } } };
  if (!s.entries['/']) s.entries['/'] = { kind: 'dir', path: '/', createdAtMs: 0 };
  return s;
}

function ensureParents(entries, path, nowMs, author) {
  let cur = parentPath(path);
  const toCreate = [];
  while (cur && !entries[cur]) {
    toCreate.push(cur);
    cur = parentPath(cur);
  }
  for (let i = toCreate.length - 1; i >= 0; i--) {
    const dirPath = toCreate[i];
    entries[dirPath] = { kind: 'dir', path: dirPath, createdBy: author, createdAtMs: nowMs };
  }
}

/**
 * Content-Addressed Virtual Filesystem Reducer.
 * Stores directory tree & metadata in the log while file bodies are lazy-pulled via session.content.
 * Concurrent edits to a file with a mismatched expectedOpId automatically create a non-destructive conflict fork.
 */
export const virtualFs = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = normalizeFs(state);
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = typeof input.action === 'string' ? input.action : 'writeFile';

    if (action === 'mkdir') {
      const path = normalizePath(input.path);
      if (!path || path === '/') return { ok: false, code: 'fs:invalid_path' };
      if (cur.entries[path] && cur.entries[path].kind !== 'dir') return { ok: false, code: 'fs:path_is_file' };
      ensureParents(cur.entries, path, nowMs, tx.author);
      if (!cur.entries[path]) {
        cur.entries[path] = { kind: 'dir', path, createdBy: tx.author, createdAtMs: nowMs };
      }
      return { ok: true, state: cur, events: [{ topic: 'fs.mkdir', payload: { path } }] };
    }

    if (action === 'writeFile') {
      const path = normalizePath(input.path);
      if (!path || path === '/') return { ok: false, code: 'fs:invalid_path' };
      const existing = cur.entries[path];
      if (existing && existing.kind === 'dir') return { ok: false, code: 'fs:path_is_dir' };
      ensureParents(cur.entries, path, nowMs, tx.author);

      const expectedOpId = input.expectedOpId;
      const isConflict = expectedOpId !== undefined &&
        ((existing && existing.opId !== expectedOpId) || (!existing && expectedOpId !== null));

      if (isConflict && input.onConflict === 'reject') {
        return { ok: false, code: 'fs:version_conflict', detail: path };
      }

      const targetPath = isConflict ? conflictPathFor(path, tx.author, tx.opId) : path;
      const prevVersion = existing && !isConflict ? (Number(existing.version) || 0) : 0;
      const prevHistory = existing && !isConflict && Array.isArray(existing.history) ? existing.history.slice(-15) : [];
      const meta = {
        kind: 'file',
        path: targetPath,
        ...(isConflict ? { conflictOf: path } : {}),
        ref: input.ref === undefined ? null : input.ref,
        sha256: typeof input.sha256 === 'string' ? input.sha256 : null,
        bytes: Number.isSafeInteger(input.bytes) ? input.bytes : 0,
        mediaType: typeof input.mediaType === 'string' ? input.mediaType : 'application/octet-stream',
        version: prevVersion + 1,
        opId: tx.opId,
        updatedBy: tx.author,
        updatedAtMs: nowMs,
        history: prevHistory.concat([{ version: prevVersion + 1, opId: tx.opId, ref: input.ref ?? null, updatedBy: tx.author, updatedAtMs: nowMs }]),
      };
      cur.entries[targetPath] = meta;
      return {
        ok: true,
        state: cur,
        events: [{ topic: isConflict ? 'fs.conflict_fork' : 'fs.write', payload: { path: targetPath, ...(isConflict ? { conflictOf: path } : {}), version: meta.version } }],
      };
    }

    if (action === 'move') {
      const from = normalizePath(input.from);
      const to = normalizePath(input.to);
      if (!from || !to || from === '/' || to === '/') return { ok: false, code: 'fs:invalid_path' };
      const entry = cur.entries[from];
      if (!entry) return { ok: false, code: 'fs:not_found' };
      if (cur.entries[to]) return { ok: false, code: 'fs:destination_exists' };
      ensureParents(cur.entries, to, nowMs, tx.author);
      if (entry.kind === 'file') {
        delete cur.entries[from];
        cur.entries[to] = { ...entry, path: to, updatedBy: tx.author, updatedAtMs: nowMs };
      } else {
        const prefix = from + '/';
        const moved = [];
        for (const p of Object.keys(cur.entries)) {
          if (p === from || p.startsWith(prefix)) moved.push(p);
        }
        for (const p of moved) {
          const nextP = p === from ? to : to + p.slice(from.length);
          cur.entries[nextP] = { ...cur.entries[p], path: nextP };
          delete cur.entries[p];
        }
      }
      return { ok: true, state: cur, events: [{ topic: 'fs.move', payload: { from, to } }] };
    }

    if (action === 'delete') {
      const path = normalizePath(input.path);
      if (!path || path === '/') return { ok: false, code: 'fs:invalid_path' };
      if (!cur.entries[path]) return { ok: false, code: 'fs:not_found' };
      const prefix = path + '/';
      for (const p of Object.keys(cur.entries)) {
        if (p === path || p.startsWith(prefix)) delete cur.entries[p];
      }
      return { ok: true, state: cur, events: [{ topic: 'fs.delete', payload: { path } }] };
    }

    if (action === 'resolveConflict') {
      const conflictPath = normalizePath(input.conflictPath);
      if (!conflictPath || !cur.entries[conflictPath] || !cur.entries[conflictPath].conflictOf) {
        return { ok: false, code: 'fs:conflict_not_found' };
      }
      const conflictEntry = cur.entries[conflictPath];
      const originalPath = conflictEntry.conflictOf;
      const strategy = input.strategy || 'keep_original';
      if (strategy === 'keep_original') {
        delete cur.entries[conflictPath];
      } else if (strategy === 'replace_original') {
        const prev = cur.entries[originalPath];
        const nextVersion = prev ? (Number(prev.version) || 0) + 1 : 1;
        delete cur.entries[conflictPath];
        const { conflictOf: _drop, ...clean } = conflictEntry;
        cur.entries[originalPath] = { ...clean, path: originalPath, version: nextVersion, opId: tx.opId, updatedBy: tx.author, updatedAtMs: nowMs };
      } else if (strategy === 'keep_both') {
        const { conflictOf: _drop, ...clean } = conflictEntry;
        cur.entries[conflictPath] = clean;
      } else {
        return { ok: false, code: 'fs:invalid_strategy' };
      }
      return { ok: true, state: cur, events: [{ topic: 'fs.conflict_resolved', payload: { conflictPath, originalPath, strategy } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },

  query(state, input) {
    const cur = normalizeFs(state);
    const q = input && typeof input === 'object' ? input : {};
    const kind = q.query || q.kind || 'list';
    if (kind === 'stat') {
      const p = normalizePath(q.path || '/');
      return p ? (cur.entries[p] || null) : null;
    }
    if (kind === 'conflicts') {
      const conflicts = Object.values(cur.entries).filter(e => e.kind === 'file' && e.conflictOf);
      conflicts.sort((a, b) => (a.path < b.path ? -1 : 1));
      return { conflicts };
    }
    if (kind === 'tree') {
      const entries = Object.values(cur.entries).sort((a, b) => (a.path < b.path ? -1 : 1));
      return { entries };
    }
    const dir = normalizePath(q.path || '/');
    if (!dir) return { entries: [] };
    const entries = Object.values(cur.entries)
      .filter(e => e.path !== '/' && parentPath(e.path) === dir)
      .sort((a, b) => (a.kind !== b.kind ? (a.kind === 'dir' ? -1 : 1) : (a.path < b.path ? -1 : 1)));
    return { path: dir, entries };
  },

  describe() {
    const optStr = { anyOf: [{ type: 'string' }, { type: 'null' }] };
    const optRef = { anyOf: [{ type: 'object', properties: {} }, { type: 'string' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'mkdir', description: 'Create a directory.', input: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } },
        { name: 'writeFile', description: 'Write file metadata and content ref (auto-forks on concurrent version mismatch).', input: { type: 'object', properties: { path: { type: 'string' }, ref: optRef, bytes: { type: 'integer' }, mediaType: { type: 'string' }, expectedOpId: optStr }, required: ['path'] } },
        { name: 'move', description: 'Move or rename a file or directory.', input: { type: 'object', properties: { from: { type: 'string' }, to: { type: 'string' } }, required: ['from', 'to'] } },
        { name: 'delete', description: 'Delete a file or directory recursively.', input: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } },
        { name: 'resolveConflict', description: 'Resolve an auto-forked conflict file.', input: { type: 'object', properties: { conflictPath: { type: 'string' }, strategy: { type: 'string', enum: ['keep_original', 'replace_original', 'keep_both'] } }, required: ['conflictPath'] } },
      ],
      queries: [
        { name: 'list', description: 'List entries in a directory.', input: { type: 'object', properties: { path: { type: 'string' } } } },
        { name: 'stat', description: 'Inspect metadata and history for a path.', input: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } },
        { name: 'conflicts', description: 'List unresolved conflict forks.', input: { type: 'object', properties: {} } },
        { name: 'tree', description: 'List the entire directory tree.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/mounts.ts
var STD_MOUNTS_SOURCE = `
import { verifyEd25519, canonicalJson } from 'chronolog:crypto';

const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;

function isAdmin(ctx, actor) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === actor && m.administrator === true));
}

export const verifiedMounts = {
  reduce(state, tx, ctx) {
    const cur = state && typeof state === 'object' && state.mounts && typeof state.mounts === 'object'
      ? { mounts: { ...state.mounts } }
      : { mounts: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_mount_input' };
    const action = input.action || 'update';
    const name = typeof input.name === 'string' ? input.name.trim() : '';
    if (!name || name.length > 128) return { ok: false, code: 'invalid_mount_name' };

    if (action === 'remove') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      delete cur.mounts[name];
      return { ok: true, state: cur, events: [{ topic: '$mounts.removed', payload: { name } }] };
    }

    if (action === 'configure') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      if (typeof input.logId !== 'string' || !HEX32.test(input.logId)) return { ok: false, code: 'invalid_log_id' };
      const signers = Array.isArray(input.trustedSigners)
        ? Array.from(new Set(input.trustedSigners.filter(k => typeof k === 'string' && HEX32.test(k)))).sort()
        : [];
      const prev = cur.mounts[name] || null;
      cur.mounts[name] = {
        logId: input.logId,
        stateRoot: prev ? prev.stateRoot : null,
        topics: prev ? prev.topics : {},
        casRoots: prev ? prev.casRoots : [],
        trustedSigners: signers,
        attestedBy: prev ? prev.attestedBy : null,
        updatedAtMs: tx.authorTimestampMs,
      };
      return { ok: true, state: cur, events: [{ topic: '$mounts.configured', payload: { name, logId: input.logId } }] };
    }

    if (action === 'update') {
      const prev = cur.mounts[name] || null;
      const logId = typeof input.logId === 'string' ? input.logId : (prev ? prev.logId : '');
      const stateRoot = typeof input.stateRoot === 'string' ? input.stateRoot : '';
      const topics = input.topics && typeof input.topics === 'object' && !Array.isArray(input.topics) ? input.topics : null;
      if (!HEX32.test(logId) || !HEX32.test(stateRoot) || !topics) {
        return { ok: false, code: 'invalid_mount_snapshot' };
      }
      if (prev && prev.logId !== logId) return { ok: false, code: 'mount_log_id_mismatch' };
      const trustedSigners = Array.isArray(input.trustedSigners) && isAdmin(ctx, tx.author)
        ? Array.from(new Set(input.trustedSigners.filter(k => typeof k === 'string' && HEX32.test(k)))).sort()
        : (prev && Array.isArray(prev.trustedSigners) ? prev.trustedSigners : []);

      let attestedBy = null;
      if (typeof input.signer === 'string' && typeof input.signature === 'string') {
        if (!HEX32.test(input.signer) || !HEX64.test(input.signature)) {
          return { ok: false, code: 'invalid_mount_signature' };
        }
        if (trustedSigners.length > 0 && !trustedSigners.includes(input.signer)) {
          return { ok: false, code: 'untrusted_mount_signer' };
        }
        const msg = 'chronolog/mount/v1:' + canonicalJson({ logId, stateRoot, topics });
        if (!verifyEd25519(input.signer, msg, input.signature)) {
          return { ok: false, code: 'mount_signature_failed' };
        }
        attestedBy = input.signer;
      } else if (!isAdmin(ctx, tx.author)) {
        return { ok: false, code: 'mount_authorization_required' };
      }

      const casRoots = Array.isArray(input.casRoots)
        ? Array.from(new Set(input.casRoots.filter(h => typeof h === 'string' && (HEX32.test(h) || /^cas:sha256-[0-9a-f]{64}$/.test(h))))).sort()
        : [];
      cur.mounts[name] = {
        logId,
        stateRoot,
        topics,
        casRoots,
        trustedSigners,
        attestedBy,
        updatedAtMs: tx.authorTimestampMs,
      };
      return {
        ok: true,
        state: cur,
        events: [{ topic: '$mounts.updated', payload: { name, logId, stateRoot, attestedBy } }],
      };
    }

    return { ok: false, code: 'unknown_mount_action' };
  },
  query(state, input) {
    const mounts = state && typeof state === 'object' && state.mounts && typeof state.mounts === 'object' ? state.mounts : {};
    if (input && typeof input === 'object' && typeof input.name === 'string') {
      return Object.prototype.hasOwnProperty.call(mounts, input.name) ? mounts[input.name] : null;
    }
    return { mounts };
  },
};
`.trimStart();

// packages/materializer/src/std/builders.ts
var STD_BUILDERS_SOURCE = `
import { verifyEd25519, canonicalJson } from 'chronolog:crypto';

const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;
const CAS_REF = /^cas:sha256-[0-9a-f]{64}$/;

function isAdmin(ctx, actor) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === actor && m.administrator === true));
}

function uniqueSortedHex(list) {
  return Array.from(new Set((Array.isArray(list) ? list : []).filter(k => typeof k === 'string' && HEX32.test(k)))).sort();
}

function verifyAttestation(att) {
  if (!att || typeof att !== 'object') return false;
  if (!att.payload || typeof att.payload !== 'object') return false;
  if (att.payload.format !== 'chronolog-attestation/v1') return false;
  if (typeof att.signer !== 'string' || !HEX32.test(att.signer)) return false;
  if (typeof att.signature !== 'string' || !HEX64.test(att.signature)) return false;
  const msg = 'chronolog/attestation/v1:' + canonicalJson(att.payload);
  return verifyEd25519(att.signer, msg, att.signature);
}

export const attestedBuilders = {
  reduce(state, tx, ctx) {
    if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
    const cur = state && typeof state === 'object'
      ? {
          builders: uniqueSortedHex(state.builders),
          auditors: uniqueSortedHex(state.auditors),
          threshold: typeof state.threshold === 'number' && state.threshold >= 1 ? Math.floor(state.threshold) : 1,
          requireAudit: Boolean(state.requireAudit),
          requireMountApproval: typeof state.requireMountApproval === 'string' ? state.requireMountApproval : null,
        }
      : { builders: [], auditors: [], threshold: 1, requireAudit: false, requireMountApproval: null };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_builders_input' };
    const next = { ...cur };
    if (Array.isArray(input.builders)) next.builders = uniqueSortedHex(input.builders);
    if (Array.isArray(input.auditors)) next.auditors = uniqueSortedHex(input.auditors);
    if (typeof input.threshold === 'number' && Number.isInteger(input.threshold) && input.threshold >= 1) {
      next.threshold = input.threshold;
    }
    if (typeof input.requireAudit === 'boolean') next.requireAudit = input.requireAudit;
    if (input.requireMountApproval === null || typeof input.requireMountApproval === 'string') {
      next.requireMountApproval = input.requireMountApproval;
    }
    return { ok: true, state: next, events: [{ topic: '$builders.updated', payload: { threshold: next.threshold } }] };
  },
  query(state) {
    return state || { builders: [], auditors: [], threshold: 1, requireAudit: false, requireMountApproval: null };
  },
};

/**
 * Governed $reducers policy that accepts upgrades either from an administrator
 * OR via M-of-N verified chronolog-attestation/v1 build/audit receipts from $builders
 * (and optional verification against a mounted Registry Chronolog via ctx.mountQuery).
 */
export const attestedReducers = {
  reduce(state, tx, ctx) {
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const admin = isAdmin(ctx, tx.author);
    const buildersCfg = ctx.topic('$builders');
    const builders = buildersCfg && Array.isArray(buildersCfg.builders) ? buildersCfg.builders : [];
    const auditors = buildersCfg && Array.isArray(buildersCfg.auditors) ? buildersCfg.auditors : [];
    const threshold = buildersCfg && typeof buildersCfg.threshold === 'number' && buildersCfg.threshold >= 1
      ? buildersCfg.threshold
      : 1;
    const requireAudit = Boolean(buildersCfg && buildersCfg.requireAudit);
    const requireMount = buildersCfg && typeof buildersCfg.requireMountApproval === 'string'
      ? buildersCfg.requireMountApproval
      : null;

    const newRefs = [];
    if (input.imports && typeof input.imports === 'object') {
      for (const [, v] of Object.entries(input.imports)) {
        if (typeof v === 'string' && CAS_REF.test(v)) newRefs.push(v);
      }
    }

    // If a mounted Registry approval policy is configured, verify every added/updated ref exists in the mount!
    if (requireMount && newRefs.length > 0) {
      for (const ref of newRefs) {
        const found = ctx.mountQuery(requireMount, 'packages', { query: 'resolveByHash', pkgRef: ref });
        if (!found || found.revoked) {
          return { ok: false, code: 'mount_approval_required', detail: 'Package not approved in mount ' + requireMount + ': ' + ref };
        }
      }
    }

    if (!admin) {
      if (builders.length === 0 || newRefs.length === 0) {
        return { ok: false, code: 'admin_or_attestation_required' };
      }
      const attestations = Array.isArray(input.attestations) ? input.attestations : [];
      for (const ref of newRefs) {
        const buildSigners = new Set();
        const auditSigners = new Set();
        for (const att of attestations) {
          if (!verifyAttestation(att)) continue;
          if (att.payload.kind === 'build' && att.payload.outputRef === ref && builders.includes(att.signer)) {
            buildSigners.add(att.signer);
          }
          if (att.payload.kind === 'audit' && att.payload.pkgRef === ref && att.payload.verdict === 'approved' && auditors.includes(att.signer)) {
            auditSigners.add(att.signer);
          }
        }
        if (buildSigners.size < threshold) {
          return { ok: false, code: 'build_attestation_threshold_unmet', detail: 'Need ' + threshold + ' builder attestations for ' + ref };
        }
        if (requireAudit && auditSigners.size < 1) {
          return { ok: false, code: 'audit_attestation_required', detail: 'Need approved auditor attestation for ' + ref };
        }
      }
    }

    const next = {
      runtime: state.runtime,
      imports: { ...(state.imports || {}) },
      topics: { ...(state.topics || {}) },
    };
    if (input.imports && typeof input.imports === 'object') {
      for (const [k, v] of Object.entries(input.imports)) {
        if (v === null) delete next.imports[k];
        else next.imports[k] = v;
      }
    }
    if (input.topics && typeof input.topics === 'object') {
      for (const [k, v] of Object.entries(input.topics)) {
        if (v === null) delete next.topics[k];
        else next.topics[k] = v;
      }
    }
    return {
      ok: true,
      state: next,
      events: [{ topic: '$reducers.updated', payload: { author: tx.author, attested: !admin } }],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/registry.ts
var STD_REGISTRY_SOURCE = `
import { openDb } from 'chronolog:sqlite';
import { verifyEd25519, canonicalJson, sha256 } from 'chronolog:crypto';

const CAS_REF = /^cas:sha256-[0-9a-f]{64}$/;
const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;

function isWriter(ctx, actor) {
  const checked = ctx.query('$permissions', { check: 'writer', actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === actor && m.writer === true));
}

function isAdmin(ctx, actor) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === actor && m.administrator === true));
}

function ensureSchema(db) {
  db.exec(\`
    CREATE TABLE IF NOT EXISTS packages (
      name TEXT PRIMARY KEY,
      description TEXT NOT NULL DEFAULT '',
      latest_version TEXT NOT NULL,
      publisher TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS versions (
      name TEXT NOT NULL,
      version TEXT NOT NULL,
      pkg_ref TEXT NOT NULL,
      drv_ref TEXT,
      runtime TEXT NOT NULL,
      builtins_json TEXT NOT NULL DEFAULT '[]',
      describe_json TEXT,
      publisher TEXT NOT NULL,
      published_at INTEGER NOT NULL,
      revoked INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (name, version)
    );
    CREATE INDEX IF NOT EXISTS idx_versions_pkg_ref ON versions(pkg_ref);
    CREATE TABLE IF NOT EXISTS attestations (
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL,
      target_ref TEXT NOT NULL,
      drv_ref TEXT,
      verdict TEXT,
      runtime TEXT,
      signer TEXT NOT NULL,
      signature TEXT NOT NULL,
      notes TEXT,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_attestations_target ON attestations(target_ref);
    CREATE VIRTUAL TABLE IF NOT EXISTS packages_fts USING fts5(name, description);
  \`, [], { mode: 'admin' });
}

function withDb(dbRoot, fn) {
  const db = openDb(dbRoot || null);
  try {
    return fn(db);
  } finally {
    db.close();
  }
}

export const packageRegistry = {
  reduce(state, tx, ctx) {
    if (!isWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_registry_input' };
    const curRoot = state && typeof state === 'object' && typeof state.dbRoot === 'string' ? state.dbRoot : null;

    return withDb(curRoot, db => {
      ensureSchema(db);
      const action = input.action;

      if (action === 'publish') {
        const name = typeof input.name === 'string' ? input.name.trim() : '';
        const version = typeof input.version === 'string' ? input.version.trim() : '';
        const pkgRef = typeof input.pkgRef === 'string' ? input.pkgRef : '';
        const drvRef = typeof input.drvRef === 'string' && CAS_REF.test(input.drvRef) ? input.drvRef : null;
        const runtime = typeof input.runtime === 'string' ? input.runtime : 'esm-quickjs';
        const description = typeof input.description === 'string' ? input.description : '';
        const builtins = Array.isArray(input.builtins) ? input.builtins.filter(b => typeof b === 'string').sort() : [];
        const describeJson = input.describeSchema !== undefined ? JSON.stringify(input.describeSchema) : null;
        if (!name || name.length > 256 || !version || version.length > 128 || !CAS_REF.test(pkgRef)) {
          return { ok: false, code: 'invalid_package_release' };
        }
        const existingPkg = db.query('SELECT publisher FROM packages WHERE name = ?', [name]);
        if (existingPkg.rows.length > 0 && existingPkg.rows[0][0] !== tx.author && !isAdmin(ctx, tx.author)) {
          return { ok: false, code: 'package_owner_mismatch' };
        }
        const existingVer = db.query('SELECT pkg_ref FROM versions WHERE name = ? AND version = ?', [name, version]);
        if (existingVer.rows.length > 0) {
          return { ok: false, code: 'version_already_exists' };
        }
        db.exec(
          'INSERT INTO versions(name, version, pkg_ref, drv_ref, runtime, builtins_json, describe_json, publisher, published_at, revoked) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, 0)',
          [name, version, pkgRef, drvRef, runtime, JSON.stringify(builtins), describeJson, tx.author, tx.authorTimestampMs],
          { mode: 'admin' },
        );
        db.exec(
          'INSERT INTO packages(name, description, latest_version, publisher, updated_at) VALUES(?, ?, ?, ?, ?) ON CONFLICT(name) DO UPDATE SET description = excluded.description, latest_version = excluded.latest_version, updated_at = excluded.updated_at',
          [name, description, version, tx.author, tx.authorTimestampMs],
          { mode: 'admin' },
        );
        db.exec('DELETE FROM packages_fts WHERE name = ?', [name], { mode: 'admin' });
        db.exec('INSERT INTO packages_fts(name, description) VALUES(?, ?)', [name, description], { mode: 'admin' });
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { dbRoot },
          events: [{ topic: 'registry.published', payload: { name, version, pkgRef, drvRef } }],
        };
      }

      if (action === 'attest') {
        const att = input.attestation;
        if (!att || typeof att !== 'object' || !att.payload || typeof att.payload !== 'object') {
          return { ok: false, code: 'invalid_attestation' };
        }
        if (att.payload.format !== 'chronolog-attestation/v1') return { ok: false, code: 'invalid_attestation_format' };
        if (typeof att.signer !== 'string' || !HEX32.test(att.signer) || typeof att.signature !== 'string' || !HEX64.test(att.signature)) {
          return { ok: false, code: 'invalid_attestation_signature' };
        }
        const msg = 'chronolog/attestation/v1:' + canonicalJson(att.payload);
        if (!verifyEd25519(att.signer, msg, att.signature)) {
          return { ok: false, code: 'attestation_signature_failed' };
        }
        const kind = att.payload.kind;
        let targetRef = '';
        let drvRef = null;
        let verdict = null;
        let runtime = null;
        let notes = null;
        if (kind === 'build') {
          targetRef = typeof att.payload.outputRef === 'string' ? att.payload.outputRef : '';
          drvRef = typeof att.payload.drvRef === 'string' ? att.payload.drvRef : null;
          runtime = typeof att.payload.runtime === 'string' ? att.payload.runtime : null;
        } else if (kind === 'audit') {
          targetRef = typeof att.payload.pkgRef === 'string' ? att.payload.pkgRef : '';
          verdict = typeof att.payload.verdict === 'string' ? att.payload.verdict : null;
          notes = typeof att.payload.notes === 'string' ? att.payload.notes : null;
        } else {
          return { ok: false, code: 'unknown_attestation_kind' };
        }
        if (!CAS_REF.test(targetRef)) return { ok: false, code: 'invalid_attestation_target' };
        const id = sha256(att.signer + ':' + msg);
        db.exec(
          'INSERT OR IGNORE INTO attestations(id, kind, target_ref, drv_ref, verdict, runtime, signer, signature, notes, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [id, kind, targetRef, drvRef, verdict, runtime, att.signer, att.signature, notes, tx.authorTimestampMs],
          { mode: 'admin' },
        );
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { dbRoot },
          events: [{ topic: 'registry.attested', payload: { kind, targetRef, signer: att.signer } }],
        };
      }

      if (action === 'revoke') {
        const name = typeof input.name === 'string' ? input.name.trim() : '';
        const version = typeof input.version === 'string' ? input.version.trim() : '';
        const existing = db.query('SELECT publisher FROM versions WHERE name = ? AND version = ?', [name, version]);
        if (existing.rows.length === 0) return { ok: false, code: 'version_not_found' };
        if (existing.rows[0][0] !== tx.author && !isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_or_owner_required' };
        db.exec('UPDATE versions SET revoked = 1 WHERE name = ? AND version = ?', [name, version], { mode: 'admin' });
        const dbRoot = db.commit();
        return { ok: true, state: { dbRoot }, events: [{ topic: 'registry.revoked', payload: { name, version } }] };
      }

      return { ok: false, code: 'unknown_registry_action' };
    });
  },
  query(state, input) {
    const curRoot = state && typeof state === 'object' && typeof state.dbRoot === 'string' ? state.dbRoot : null;
    if (!curRoot) return input && input.query === 'resolve' ? null : [];
    const req = input && typeof input === 'object' ? input : { query: 'list' };

    return withDb(curRoot, db => {
      const q = req.query || 'list';
      if (q === 'search') {
        const term = typeof req.q === 'string' ? req.q.trim() : '';
        const limit = typeof req.limit === 'number' && req.limit > 0 ? Math.min(100, Math.floor(req.limit)) : 25;
        if (!term) {
          const all = db.query('SELECT name, description, latest_version, publisher, updated_at FROM packages ORDER BY name LIMIT ?', [limit]);
          return all.rows.map(r => ({ name: r[0], description: r[1], latestVersion: r[2], publisher: r[3], updatedAt: r[4] }));
        }
        let rows = [];
        try {
          const fts = db.query(
            'SELECT p.name, p.description, p.latest_version, p.publisher, p.updated_at FROM packages_fts f JOIN packages p ON p.name = f.name WHERE packages_fts MATCH ? LIMIT ?',
            [term, limit],
          );
          rows = fts.rows;
        } catch {
          const like = '%' + term + '%';
          rows = db.query(
            'SELECT name, description, latest_version, publisher, updated_at FROM packages WHERE name LIKE ? OR description LIKE ? ORDER BY name LIMIT ?',
            [like, like, limit],
          ).rows;
        }
        return rows.map(r => ({ name: r[0], description: r[1], latestVersion: r[2], publisher: r[3], updatedAt: r[4] }));
      }

      if (q === 'resolve') {
        const name = typeof req.name === 'string' ? req.name : '';
        const version = typeof req.version === 'string' && req.version.length > 0 ? req.version : null;
        const sql = version
          ? 'SELECT name, version, pkg_ref, drv_ref, runtime, builtins_json, describe_json, publisher, published_at, revoked FROM versions WHERE name = ? AND version = ? LIMIT 1'
          : 'SELECT v.name, v.version, v.pkg_ref, v.drv_ref, v.runtime, v.builtins_json, v.describe_json, v.publisher, v.published_at, v.revoked FROM packages p JOIN versions v ON v.name = p.name AND v.version = p.latest_version WHERE p.name = ? LIMIT 1';
        const res = db.query(sql, version ? [name, version] : [name]);
        if (res.rows.length === 0) return null;
        const r = res.rows[0];
        const att = db.query('SELECT kind, verdict, signer, signature, drv_ref, runtime, notes FROM attestations WHERE target_ref = ? ORDER BY created_at ASC', [r[2]]);
        return {
          name: r[0],
          version: r[1],
          pkgRef: r[2],
          drvRef: r[3],
          runtime: r[4],
          builtins: JSON.parse(r[5]),
          describeSchema: r[6] ? JSON.parse(r[6]) : null,
          publisher: r[7],
          publishedAt: r[8],
          revoked: Boolean(r[9]),
          attestations: att.rows.map(a => ({ kind: a[0], verdict: a[1], signer: a[2], signature: a[3], drvRef: a[4], runtime: a[5], notes: a[6] })),
        };
      }

      if (q === 'resolveByHash') {
        const pkgRef = typeof req.pkgRef === 'string' ? req.pkgRef : '';
        const res = db.query(
          'SELECT name, version, pkg_ref, drv_ref, runtime, builtins_json, publisher, published_at, revoked FROM versions WHERE pkg_ref = ? LIMIT 1',
          [pkgRef],
        );
        if (res.rows.length === 0) return null;
        const r = res.rows[0];
        const att = db.query('SELECT kind, verdict, signer FROM attestations WHERE target_ref = ?', [pkgRef]);
        return {
          name: r[0],
          version: r[1],
          pkgRef: r[2],
          drvRef: r[3],
          runtime: r[4],
          builtins: JSON.parse(r[5]),
          publisher: r[6],
          publishedAt: r[7],
          revoked: Boolean(r[8]),
          buildAttestations: att.rows.filter(a => a[0] === 'build').length,
          approvedAudits: att.rows.filter(a => a[0] === 'audit' && a[1] === 'approved').length,
        };
      }

      if (q === 'attestations') {
        const targetRef = typeof req.targetRef === 'string' ? req.targetRef : '';
        const res = db.query('SELECT id, kind, target_ref, drv_ref, verdict, runtime, signer, signature, notes, created_at FROM attestations WHERE target_ref = ? ORDER BY created_at ASC', [targetRef]);
        return res.rows.map(a => ({ id: a[0], kind: a[1], targetRef: a[2], drvRef: a[3], verdict: a[4], runtime: a[5], signer: a[6], signature: a[7], notes: a[8], createdAt: a[9] }));
      }

      const limit = typeof req.limit === 'number' && req.limit > 0 ? Math.min(200, Math.floor(req.limit)) : 50;
      const all = db.query('SELECT name, description, latest_version, publisher, updated_at FROM packages ORDER BY name LIMIT ?', [limit]);
      return all.rows.map(r => ({ name: r[0], description: r[1], latestVersion: r[2], publisher: r[3], updatedAt: r[4] }));
    });
  },
  describe() {
    return {
      commands: [
        { name: 'publish', description: 'Publish a content-addressed package release (pkgRef + optional drvRef).' },
        { name: 'attest', description: 'Record a signed Ed25519 reproducible-build or security audit attestation.' },
        { name: 'revoke', description: 'Revoke a published package version.' },
      ],
      queries: [
        { name: 'search', description: 'Full-text search packages via SQLite FTS5.' },
        { name: 'resolve', description: 'Resolve package name/version to its CAS root and attestations.' },
        { name: 'resolveByHash', description: 'Look up package provenance and attestations by cas:sha256-... root.' },
        { name: 'attestations', description: 'List verified attestations for a package CAS root.' },
        { name: 'list', description: 'List published packages.' },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std-stdlib-extra.ts
var STD_FINALITY_PREDICATES_SOURCE = `
import { canonicalJson, sha256, verifyEd25519 } from 'chronolog:crypto';

const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;

function canonicalCheckpointMessage(payload) {
  return canonicalJson(['chronolog/finality-predicate/v1', payload]);
}

function verifySigEntry(entry, payload) {
  if (!entry || typeof entry !== 'object') return false;
  if (typeof entry.signer !== 'string' || !HEX32.test(entry.signer)) return false;
  if (typeof entry.signature !== 'string' || !HEX64.test(entry.signature)) return false;
  return verifyEd25519(entry.signer, canonicalCheckpointMessage(payload), entry.signature);
}

/** Single-signer programmable finality predicate (config: { signer: 64-hex }). */
export const signedFrontierPredicate = {
  query(state, input, ctx) {
    const cfg = (input && input.policy && input.policy.config) || ctx.config || {};
    const cp = input && input.checkpoint;
    if (!cp || !cp.payload || !cp.attestation || typeof cfg.signer !== 'string' || !HEX32.test(cfg.signer)) {
      return { admitted: false, reason: 'invalid_input' };
    }
    const data = cp.attestation.kind === 'evidence' ? cp.attestation.data : cp.attestation;
    const sigs = Array.isArray(data && data.signatures) ? data.signatures : (data && data.signer ? [data] : []);
    for (const s of sigs) {
      if (s && s.signer === cfg.signer && verifySigEntry(s, cp.payload)) {
        return { admitted: true, signer: cfg.signer };
      }
    }
    return { admitted: false, reason: 'signature_missing_or_invalid' };
  },
};

/**
 * Weighted or M-of-N validator quorum predicate.
 * config: { validators: string[] | Record<string, number>, threshold: number }
 */
export const thresholdQuorumPredicate = {
  query(state, input, ctx) {
    const cfg = (input && input.policy && input.policy.config) || ctx.config || {};
    const cp = input && input.checkpoint;
    if (!cp || !cp.payload || !cp.attestation) return { admitted: false, reason: 'invalid_input' };
    const threshold = Number(cfg.threshold || 1);
    if (!Number.isFinite(threshold) || threshold < 1) return { admitted: false, reason: 'invalid_threshold' };

    const weights = {};
    if (Array.isArray(cfg.validators)) {
      for (const v of cfg.validators) if (typeof v === 'string' && HEX32.test(v)) weights[v] = 1;
    } else if (cfg.validators && typeof cfg.validators === 'object') {
      for (const [k, w] of Object.entries(cfg.validators)) {
        if (HEX32.test(k) && typeof w === 'number' && Number.isFinite(w) && w > 0) weights[k] = w;
      }
    }

    const data = cp.attestation.kind === 'evidence' ? cp.attestation.data : cp.attestation;
    const sigs = Array.isArray(data && data.signatures) ? data.signatures : [];
    const seen = new Set();
    let total = 0;
    for (const s of sigs) {
      if (!s || typeof s.signer !== 'string' || !Object.prototype.hasOwnProperty.call(weights, s.signer)) continue;
      if (seen.has(s.signer)) continue;
      if (verifySigEntry(s, cp.payload)) {
        seen.add(s.signer);
        total += weights[s.signer];
      }
    }
    return { admitted: total >= threshold, weight: total, threshold };
  },
};

/**
 * Optimistic challenge-window predicate:
 * Admits a signed checkpoint once an attested observation timestamp >= closedThroughMs + challengeWindowMs,
 * UNLESS a valid signed fraud/challenge counter-proof is present in attestation.data.challenges.
 * config: { proposers: string[], challengers?: string[], challengeWindowMs: number }
 */
export const optimisticChallengePredicate = {
  query(state, input, ctx) {
    const cfg = (input && input.policy && input.policy.config) || ctx.config || {};
    const cp = input && input.checkpoint;
    if (!cp || !cp.payload || !cp.attestation || cp.attestation.kind !== 'evidence') {
      return { admitted: false, reason: 'evidence_required' };
    }
    const data = cp.attestation.data || {};
    const proposers = Array.isArray(cfg.proposers) ? cfg.proposers : [];
    const challengers = Array.isArray(cfg.challengers) ? cfg.challengers : proposers;
    const windowMs = Number(cfg.challengeWindowMs || 0);
    const closedMs = Number(cp.payload.closedThroughMs || 0);
    const observedMs = Number(data.observedAtMs || 0);
    if (!Number.isFinite(observedMs) || observedMs < closedMs + windowMs) {
      return { admitted: false, reason: 'challenge_window_open' };
    }
    const proposal = data.proposal;
    if (!proposal || !proposers.includes(proposal.signer) || !verifySigEntry(proposal, cp.payload)) {
      return { admitted: false, reason: 'invalid_proposal_signature' };
    }
    const challenges = Array.isArray(data.challenges) ? data.challenges : [];
    for (const ch of challenges) {
      if (!ch || !challengers.includes(ch.signer) || typeof ch.signature !== 'string' || !HEX64.test(ch.signature)) continue;
      const challengeMsg = canonicalJson(['chronolog/finality-challenge/v1', cp.payload.logId, cp.payload.policyScopeId, cp.payload.closedThroughMs, ch.reason || 'fraud']);
      if (verifyEd25519(ch.signer, challengeMsg, ch.signature)) {
        return { admitted: false, challenged: true, challenger: ch.signer, reason: ch.reason || 'fraud' };
      }
    }
    return { admitted: true, proposer: proposal.signer };
  },
};

/**
 * External Merkle-anchor predicate:
 * Verifies a SHA-256 Merkle inclusion proof tying sha256(canonicalJson(checkpoint.payload))
 * into a root signed by a trusted anchor oracle (or pinned in config.trustedRoots).
 * config: { anchorSigners?: string[], trustedRoots?: string[] }
 */
export const merkleAnchorPredicate = {
  query(state, input, ctx) {
    const cfg = (input && input.policy && input.policy.config) || ctx.config || {};
    const cp = input && input.checkpoint;
    if (!cp || !cp.payload || !cp.attestation || cp.attestation.kind !== 'evidence') {
      return { admitted: false, reason: 'evidence_required' };
    }
    const data = cp.attestation.data || {};
    const root = data.root;
    const proof = Array.isArray(data.proof) ? data.proof : null;
    if (typeof root !== 'string' || !HEX32.test(root) || !proof || proof.length > 64) {
      return { admitted: false, reason: 'invalid_merkle_proof' };
    }
    let cur = sha256(canonicalCheckpointMessage(cp.payload));
    for (const step of proof) {
      if (!step || typeof step.sibling !== 'string' || !HEX32.test(step.sibling)) {
        return { admitted: false, reason: 'invalid_merkle_step' };
      }
      cur = step.position === 'left'
        ? sha256(step.sibling + cur)
        : sha256(cur + step.sibling);
    }
    if (cur !== root) return { admitted: false, reason: 'merkle_root_mismatch' };
    const trustedRoots = Array.isArray(cfg.trustedRoots) ? cfg.trustedRoots : [];
    if (trustedRoots.includes(root)) return { admitted: true, root };
    const signers = Array.isArray(cfg.anchorSigners) ? cfg.anchorSigners : [];
    const anchorSig = data.anchorSignature;
    if (anchorSig && signers.includes(anchorSig.signer) && HEX64.test(anchorSig.signature || '')) {
      const msg = canonicalJson(['chronolog/merkle-anchor/v1', root]);
      if (verifyEd25519(anchorSig.signer, msg, anchorSig.signature)) {
        return { admitted: true, root, anchorSigner: anchorSig.signer };
      }
    }
    return { admitted: false, reason: 'untrusted_anchor_root' };
  },
};

export default thresholdQuorumPredicate;
`.trimStart();
var STD_GUARDS_SOURCE = `
/**
 * Composable pre/post condition standard library for JS & SQL reducers.
 */

export function requireAuthorChain(ctx, tx, expectedLastOpId) {
  const actual = typeof ctx.authorLastOpId === 'function' ? ctx.authorLastOpId(tx.author) : null;
  if (actual !== expectedLastOpId) {
    return {
      ok: false,
      code: 'guard:author_history_mismatch',
      detail: 'Author ' + tx.author + ' expected last op ' + String(expectedLastOpId) + ', got ' + String(actual),
    };
  }
  return { ok: true };
}

export function requireOpsAccepted(ctx, opIds) {
  if (!Array.isArray(opIds)) return { ok: true };
  for (const id of opIds) {
    const st = typeof ctx.opOutcome === 'function' ? ctx.opOutcome(id) : null;
    if (st === null) return { ok: false, code: 'guard:missing_op', detail: 'Required op ' + id + ' not present' };
    if (st !== 'accepted') return { ok: false, code: 'guard:op_rejected', detail: 'Required op ' + id + ' was rejected' };
  }
  return { ok: true };
}

export function requireTopicVersion(ctx, topic, expectedLastOpId) {
  const actual = typeof ctx.topicLastOpId === 'function' ? ctx.topicLastOpId(topic) : null;
  if (actual !== expectedLastOpId) {
    return {
      ok: false,
      code: 'guard:topic_modified',
      detail: 'Topic ' + topic + ' expected last op ' + String(expectedLastOpId) + ', got ' + String(actual),
    };
  }
  return { ok: true };
}

export function checkPostInvariant(predicate, nextState, tx, ctx, code = 'guard:postcondition_failed', detail = 'Postcondition failed') {
  const res = predicate(nextState, tx, ctx);
  if (res === true) return { ok: true };
  if (res && typeof res === 'object' && res.ok === true) return { ok: true };
  if (res && typeof res === 'object' && res.ok === false) {
    return { ok: false, code: res.code || code, detail: res.detail || detail };
  }
  return { ok: false, code, detail };
}

/**
 * Higher-order reducer wrapper enforcing declarative pre/post conditions around any reducer.
 */
export function guardReducer(reducer, options = {}) {
  const preList = Array.isArray(options.pre) ? options.pre : (options.pre ? [options.pre] : []);
  const postList = Array.isArray(options.post) ? options.post : (options.post ? [options.post] : []);
  return {
    ...reducer,
    reduce(state, tx, ctx) {
      for (const check of preList) {
        const res = check(state, tx, ctx);
        if (res && res.ok === false) return res;
        if (res === false) return { ok: false, code: 'guard:precondition_failed' };
      }
      const out = reducer.reduce(state, tx, ctx);
      if (!out || out.ok !== true) return out;
      for (const check of postList) {
        const res = check(out.state, tx, ctx, state);
        if (res && res.ok === false) return res;
        if (res === false) return { ok: false, code: 'guard:postcondition_failed' };
      }
      return out;
    },
  };
}

/** SQL precondition/postcondition builders compatible with chronolog/sql. */
export function sqlBasedOnRow(table, where, lastOpId, code) {
  return { kind: 'based_on_row', table, where, lastOpId, ...(code ? { code } : {}) };
}

export function sqlRowMatches(table, where, expect, code) {
  return { kind: 'row_matches', table, where, expect, ...(code ? { code } : {}) };
}

export function sqlRequireAuthorLastOp(expectedLastOpId, author, code = 'sql:author_history_mismatch') {
  if (expectedLastOpId === null) {
    return {
      sql: author ? 'SELECT chronolog_author_last_op(?) IS NULL' : 'SELECT chronolog_author_last_op() IS NULL',
      params: author ? [author] : [],
      expect: { firstValue: 1 },
      code,
    };
  }
  return {
    sql: author ? 'SELECT chronolog_author_last_op(?)' : 'SELECT chronolog_author_last_op()',
    params: author ? [author] : [],
    expect: { firstValue: expectedLastOpId },
    code,
  };
}

export function sqlPostInvariant(sql, params = [], expect = { firstValue: 1 }, code = 'sql:postcondition_failed') {
  return { sql, params, expect, code };
}

export default {
  requireAuthorChain,
  requireOpsAccepted,
  requireTopicVersion,
  checkPostInvariant,
  guardReducer,
  sqlBasedOnRow,
  sqlRowMatches,
  sqlRequireAuthorLastOp,
  sqlPostInvariant,
};
`.trimStart();
var STD_QUOTAS_SOURCE = `
/**
 * Deterministic per-author token-bucket rate limiter & quota tracker driven purely by tx.authorTimestampMs.
 * Usable both as a standalone topic reducer AND as a helper inside custom reducers.
 */

export function consumeTokenBucket(buckets, actor, nowMs, { capacity = 60, refillPerSec = 1, cost = 1 } = {}) {
  const cur = (buckets && buckets[actor]) || { tokens: capacity, lastMs: nowMs };
  const elapsedSec = Math.max(0, (nowMs - cur.lastMs) / 1000);
  const replenished = Math.min(capacity, cur.tokens + elapsedSec * refillPerSec);
  if (replenished < cost) {
    return {
      ok: false,
      code: 'quota:rate_limited',
      retryAfterMs: Math.ceil(((cost - replenished) / Math.max(refillPerSec, 0.0001)) * 1000),
      remaining: replenished,
    };
  }
  const nextTokens = replenished - cost;
  return {
    ok: true,
    remaining: nextTokens,
    buckets: { ...(buckets || {}), [actor]: { tokens: nextTokens, lastMs: nowMs } },
  };
}

export const tokenBucketQuotas = {
  reduce(state, tx, ctx) {
    const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
    const cur = state && typeof state === 'object' ? state : { buckets: {}, usage: {} };
    const input = tx.payload || {};
    const action = input.action || 'consume';
    const nowMs = Number(tx.authorTimestampMs || 0);
    if (action === 'consume') {
      const cost = Number(input.cost === undefined ? 1 : input.cost);
      if (!Number.isFinite(cost) || cost <= 0) return { ok: false, code: 'quota:invalid_cost' };
      const res = consumeTokenBucket(cur.buckets, tx.author, nowMs, {
        capacity: Number(cfg.capacity || 60),
        refillPerSec: Number(cfg.refillPerSec || 1),
        cost,
      });
      if (!res.ok) return { ok: false, code: res.code, detail: 'Retry after ' + res.retryAfterMs + 'ms' };
      const prevUsage = Number((cur.usage && cur.usage[tx.author]) || 0);
      return {
        ok: true,
        state: { buckets: res.buckets, usage: { ...(cur.usage || {}), [tx.author]: prevUsage + cost } },
        events: [{ topic: 'quota.consumed', payload: { actor: tx.author, cost, remaining: res.remaining } }],
      };
    }
    return { ok: false, code: 'quota:unknown_action' };
  },
  query(state, input) {
    const cur = state && typeof state === 'object' ? state : { buckets: {}, usage: {} };
    if (input && typeof input.actor === 'string') {
      return {
        bucket: (cur.buckets && cur.buckets[input.actor]) || null,
        usage: Number((cur.usage && cur.usage[input.actor]) || 0),
      };
    }
    return cur;
  },
};

export default tokenBucketQuotas;
`.trimStart();
var STD_QUEUE_SOURCE = `
/**
 * Deterministic CRDT job queue with time-based leases (tx.authorTimestampMs),
 * idempotent claims, retries, and dead-letter queue \u2014 ideal for multi-agent workspaces.
 */

export const jobQueue = {
  reduce(state, tx, ctx) {
    const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
    const defaultLeaseMs = Number(cfg.defaultLeaseMs || 30_000);
    const defaultMaxAttempts = Number(cfg.maxAttempts || 3);
    const cur = state && typeof state === 'object' ? state : { jobs: {} };
    const jobs = { ...(cur.jobs || {}) };
    const input = tx.payload || {};
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = input.action;

    if (action === 'enqueue') {
      const id = String(input.id || tx.operationId || tx.opId);
      if (jobs[id]) return { ok: false, code: 'queue:job_exists' };
      jobs[id] = {
        id,
        kind: String(input.kind || 'default'),
        payload: input.payload === undefined ? null : input.payload,
        status: 'pending',
        attempts: 0,
        maxAttempts: Number(input.maxAttempts || defaultMaxAttempts),
        createdAtMs: nowMs,
        createdBy: tx.author,
        claimedBy: null,
        leaseUntilMs: null,
        result: null,
        lastError: null,
      };
      return { ok: true, state: { jobs }, events: [{ topic: 'queue.enqueued', payload: { id, kind: jobs[id].kind } }] };
    }

    if (action === 'claim') {
      const id = String(input.id || '');
      const job = jobs[id];
      if (!job) return { ok: false, code: 'queue:not_found' };
      const leaseExpired = job.status === 'claimed' && job.leaseUntilMs !== null && nowMs >= job.leaseUntilMs;
      if (job.status !== 'pending' && !leaseExpired) return { ok: false, code: 'queue:already_claimed' };
      const nextAttempts = job.attempts + 1;
      if (nextAttempts > job.maxAttempts) {
        jobs[id] = { ...job, status: 'dead', claimedBy: null, leaseUntilMs: null, lastError: 'max_attempts_exceeded' };
        return { ok: true, state: { jobs }, events: [{ topic: 'queue.dead_letter', payload: { id } }] };
      }
      const leaseMs = Number(input.leaseMs || defaultLeaseMs);
      jobs[id] = { ...job, status: 'claimed', attempts: nextAttempts, claimedBy: tx.author, leaseUntilMs: nowMs + leaseMs };
      return { ok: true, state: { jobs }, events: [{ topic: 'queue.claimed', payload: { id, worker: tx.author, leaseUntilMs: nowMs + leaseMs } }] };
    }

    if (action === 'complete') {
      const id = String(input.id || '');
      const job = jobs[id];
      if (!job) return { ok: false, code: 'queue:not_found' };
      if (job.status !== 'claimed' || job.claimedBy !== tx.author) return { ok: false, code: 'queue:not_lease_holder' };
      jobs[id] = { ...job, status: 'completed', leaseUntilMs: null, completedAtMs: nowMs, result: input.result === undefined ? null : input.result };
      return { ok: true, state: { jobs }, events: [{ topic: 'queue.completed', payload: { id, worker: tx.author } }] };
    }

    if (action === 'fail') {
      const id = String(input.id || '');
      const job = jobs[id];
      if (!job) return { ok: false, code: 'queue:not_found' };
      if (job.status !== 'claimed' || job.claimedBy !== tx.author) return { ok: false, code: 'queue:not_lease_holder' };
      const dead = job.attempts >= job.maxAttempts;
      jobs[id] = {
        ...job,
        status: dead ? 'dead' : 'pending',
        claimedBy: null,
        leaseUntilMs: null,
        lastError: typeof input.error === 'string' ? input.error : 'failed',
      };
      return { ok: true, state: { jobs }, events: [{ topic: dead ? 'queue.dead_letter' : 'queue.requeued', payload: { id } }] };
    }

    return { ok: false, code: 'queue:unknown_action' };
  },
  query(state, input) {
    const jobs = (state && state.jobs) || {};
    const list = Object.values(jobs);
    if (!input || typeof input !== 'object') return list;
    if (typeof input.id === 'string') return jobs[input.id] || null;
    const nowMs = typeof input.nowMs === 'number' ? input.nowMs : null;
    return list.filter(j => {
      if (input.kind && j.kind !== input.kind) return false;
      if (input.status === 'claimable') {
        return j.status === 'pending' || (j.status === 'claimed' && nowMs !== null && j.leaseUntilMs !== null && nowMs >= j.leaseUntilMs);
      }
      if (input.status && j.status !== input.status) return false;
      return true;
    });
  },
};

export default jobQueue;
`.trimStart();
var STD_VOTES_SOURCE = `
/**
 * Deterministic weighted voting, quorum polls, and timelocked decision reducer.
 */

export const weightedVotes = {
  reduce(state, tx) {
    const cur = state && typeof state === 'object' ? state : { polls: {} };
    const polls = { ...(cur.polls || {}) };
    const input = tx.payload || {};
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = input.action;

    if (action === 'create') {
      const id = String(input.id || tx.operationId || tx.opId);
      if (polls[id]) return { ok: false, code: 'votes:poll_exists' };
      const options = Array.isArray(input.options) ? input.options.map(String) : [];
      if (options.length < 2) return { ok: false, code: 'votes:options_required' };
      polls[id] = {
        id,
        title: String(input.title || id),
        options,
        quorum: Number(input.quorum || 1),
        weights: input.weights && typeof input.weights === 'object' ? input.weights : null,
        closesAtMs: typeof input.closesAtMs === 'number' ? input.closesAtMs : null,
        status: 'open',
        createdBy: tx.author,
        createdAtMs: nowMs,
        ballots: {},
      };
      return { ok: true, state: { polls }, events: [{ topic: 'votes.created', payload: { id } }] };
    }

    if (action === 'cast') {
      const id = String(input.id || '');
      const poll = polls[id];
      if (!poll) return { ok: false, code: 'votes:not_found' };
      if (poll.status !== 'open') return { ok: false, code: 'votes:closed' };
      if (poll.closesAtMs !== null && nowMs > poll.closesAtMs) return { ok: false, code: 'votes:deadline_passed' };
      const choice = String(input.choice || '');
      if (!poll.options.includes(choice)) return { ok: false, code: 'votes:invalid_option' };
      const weight = poll.weights ? Number(poll.weights[tx.author] || 0) : 1;
      if (weight <= 0) return { ok: false, code: 'votes:not_eligible' };
      polls[id] = { ...poll, ballots: { ...poll.ballots, [tx.author]: { choice, weight, atMs: nowMs } } };
      return { ok: true, state: { polls }, events: [{ topic: 'votes.cast', payload: { id, voter: tx.author, choice, weight } }] };
    }

    if (action === 'close') {
      const id = String(input.id || '');
      const poll = polls[id];
      if (!poll) return { ok: false, code: 'votes:not_found' };
      if (poll.status !== 'open') return { ok: false, code: 'votes:already_closed' };
      if (poll.createdBy !== tx.author && (poll.closesAtMs === null || nowMs < poll.closesAtMs)) {
        return { ok: false, code: 'votes:cannot_close_yet' };
      }
      polls[id] = { ...poll, status: 'closed', closedAtMs: nowMs };
      return { ok: true, state: { polls }, events: [{ topic: 'votes.closed', payload: { id } }] };
    }

    return { ok: false, code: 'votes:unknown_action' };
  },
  query(state, input) {
    const polls = (state && state.polls) || {};
    const tally = poll => {
      const counts = Object.fromEntries(poll.options.map(o => [o, 0]));
      let totalWeight = 0;
      for (const b of Object.values(poll.ballots || {})) {
        counts[b.choice] = (counts[b.choice] || 0) + b.weight;
        totalWeight += b.weight;
      }
      let winner = null;
      let best = -1;
      let tied = false;
      for (const [opt, score] of Object.entries(counts)) {
        if (score > best) { best = score; winner = opt; tied = false; }
        else if (score === best) { tied = true; }
      }
      return { ...poll, counts, totalWeight, quorumMet: totalWeight >= poll.quorum, winner: totalWeight >= poll.quorum && !tied ? winner : null };
    };
    if (input && typeof input.id === 'string') {
      const poll = polls[input.id];
      return poll ? tally(poll) : null;
    }
    return Object.values(polls).map(tally);
  },
};

export default weightedVotes;
`.trimStart();
var STD_SCHEMA_SOURCE = `
/**
 * Lightweight deterministic JSON schema validator and state migration helper for JS reducers.
 */

export function validate(schema, value, path = '$') {
  if (!schema || typeof schema !== 'object') return { ok: true };
  if (schema.enum && !schema.enum.some(v => JSON.stringify(v) === JSON.stringify(value))) {
    return { ok: false, code: 'schema:enum', detail: path + ' must be one of enum values' };
  }
  if (schema.type) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    const actual = value === null ? 'null' : Array.isArray(value) ? 'array' : typeof value;
    const matched = types.some(t => t === actual || (t === 'integer' && typeof value === 'number' && Number.isInteger(value)));
    if (!matched) return { ok: false, code: 'schema:type', detail: path + ' expected ' + types.join('|') + ', got ' + actual };
  }
  if (typeof value === 'string') {
    if (typeof schema.minLength === 'number' && value.length < schema.minLength) return { ok: false, code: 'schema:min_length', detail: path + ' too short' };
    if (typeof schema.maxLength === 'number' && value.length > schema.maxLength) return { ok: false, code: 'schema:max_length', detail: path + ' too long' };
  }
  if (typeof value === 'number') {
    if (typeof schema.minimum === 'number' && value < schema.minimum) return { ok: false, code: 'schema:minimum', detail: path + ' below minimum' };
    if (typeof schema.maximum === 'number' && value > schema.maximum) return { ok: false, code: 'schema:maximum', detail: path + ' above maximum' };
  }
  if (Array.isArray(value)) {
    if (typeof schema.minItems === 'number' && value.length < schema.minItems) return { ok: false, code: 'schema:min_items', detail: path + ' too few items' };
    if (typeof schema.maxItems === 'number' && value.length > schema.maxItems) return { ok: false, code: 'schema:max_items', detail: path + ' too many items' };
    if (schema.items) {
      for (let i = 0; i < value.length; i++) {
        const res = validate(schema.items, value[i], path + '[' + i + ']');
        if (!res.ok) return res;
      }
    }
  }
  if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
    if (Array.isArray(schema.required)) {
      for (const req of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(value, req) || value[req] === undefined) {
          return { ok: false, code: 'schema:required', detail: path + '.' + req + ' is required' };
        }
      }
    }
    if (schema.properties && typeof schema.properties === 'object') {
      for (const [k, propSchema] of Object.entries(schema.properties)) {
        if (Object.prototype.hasOwnProperty.call(value, k)) {
          const res = validate(propSchema, value[k], path + '.' + k);
          if (!res.ok) return res;
        }
      }
    }
    if (schema.additionalProperties === false && schema.properties) {
      for (const k of Object.keys(value)) {
        if (!Object.prototype.hasOwnProperty.call(schema.properties, k)) {
          return { ok: false, code: 'schema:additional_property', detail: path + '.' + k + ' is not allowed' };
        }
      }
    }
  }
  return { ok: true };
}

export function migrateState(state, migrations, targetVersion) {
  let cur = state && typeof state === 'object' ? state : { schemaVersion: 0 };
  let v = Number(cur.schemaVersion || 0);
  while (v < targetVersion) {
    const fn = migrations[v + 1];
    if (typeof fn !== 'function') throw new Error('SCHEMA_MIGRATION_MISSING:' + (v + 1));
    cur = { ...fn(cur), schemaVersion: v + 1 };
    v += 1;
  }
  return cur;
}

export default { validate, migrateState };
`.trimStart();
var STD_AUDIT_SOURCE = `
import { canonicalJson, sha256 } from 'chronolog:crypto';

const GENESIS_CHAIN_HASH = '0'.repeat(64);

/**
 * Deterministic hash-chained tamper-evident audit log reducer.
 */
export const auditLog = {
  reduce(state, tx) {
    const cur = state && typeof state === 'object' ? state : { head: GENESIS_CHAIN_HASH, entries: [] };
    const input = tx.payload || {};
    if (input.action && input.action !== 'append') return { ok: false, code: 'audit:unknown_action' };
    const entryCore = {
      seq: cur.entries.length,
      prevHash: cur.head,
      opId: tx.opId,
      actor: tx.author,
      atMs: Number(tx.authorTimestampMs || 0),
      category: String(input.category || 'general'),
      subject: input.subject === undefined ? null : input.subject,
      detail: input.detail === undefined ? null : input.detail,
    };
    const hash = sha256(canonicalJson(entryCore));
    const entry = { ...entryCore, hash };
    return {
      ok: true,
      state: { head: hash, entries: cur.entries.concat([entry]) },
      events: [{ topic: 'audit.appended', payload: { seq: entry.seq, category: entry.category, hash } }],
    };
  },
  query(state, input) {
    const cur = state && typeof state === 'object' ? state : { head: GENESIS_CHAIN_HASH, entries: [] };
    if (input && input.verify === true) {
      let prev = GENESIS_CHAIN_HASH;
      for (const e of cur.entries) {
        const { hash, ...core } = e;
        if (core.prevHash !== prev || sha256(canonicalJson(core)) !== hash) {
          return { valid: false, brokenAt: e.seq };
        }
        prev = hash;
      }
      return { valid: prev === cur.head, count: cur.entries.length, head: cur.head };
    }
    let list = cur.entries;
    if (input && typeof input.actor === 'string') list = list.filter(e => e.actor === input.actor);
    if (input && typeof input.category === 'string') list = list.filter(e => e.category === input.category);
    if (input && typeof input.sinceMs === 'number') list = list.filter(e => e.atMs >= input.sinceMs);
    return { head: cur.head, count: list.length, entries: list };
  },
};

export default auditLog;
`.trimStart();

// packages/materializer/src/std-modules.ts
var STD_PERMISSIONS_SOURCE = `
import { verifyEd25519, canonicalJson } from 'chronolog:crypto';

const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;

function sortedKeys(list) {
  return Array.from(new Set(list)).sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
}

function isLegacyAdmin(perms, author) {
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.administrator === true));
}

function hasCapability(ctx, capability, actor) {
  const checked = ctx.query('$permissions', { check: capability, actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  const m = perms.members.find(x => x.publicKey === actor);
  if (!m) return false;
  if (capability === 'administrator') return m.administrator === true;
  if (capability === 'publisher') return m.publisher === true || m.administrator === true;
  if (capability === 'writer') return m.writer === true || m.administrator === true;
  if (capability === 'reader') return m.reader === true;
  if (capability === 'finalizer') return m.finalizer === true;
  return true;
}

function normalizeMember(m) {
  if (!m || typeof m !== 'object' || !HEX32.test(m.publicKey || '') || (m.wrapKey !== undefined && m.wrapKey !== null && !HEX32.test(m.wrapKey))) {
    throw new Error('INVALID_MEMBER');
  }
  const scopes = Array.isArray(m.scopes)
    ? sortedKeys(m.scopes.filter(s => typeof s === 'string' && s.length > 0 && s.length <= 128))
    : undefined;
  const expiresAtMs = m.expiresAtMs !== undefined && m.expiresAtMs !== null && Number.isSafeInteger(m.expiresAtMs)
    ? m.expiresAtMs
    : undefined;
  return {
    publicKey: m.publicKey,
    ...(m.wrapKey ? { wrapKey: m.wrapKey } : {}),
    ...(typeof m.label === 'string' && m.label.length > 0 ? { label: m.label } : {}),
    ...(typeof m.subject === 'string' && m.subject.length > 0 ? { subject: m.subject } : {}),
    ...(scopes && scopes.length > 0 ? { scopes } : {}),
    ...(expiresAtMs !== undefined ? { expiresAtMs } : {}),
    reader: Boolean(m.reader),
    writer: Boolean(m.writer),
    administrator: Boolean(m.administrator),
    publisher: Boolean(m.publisher),
    finalizer: Boolean(m.finalizer),
  };
}

function isMemberExpired(member, atMs) {
  if (!member || member.expiresAtMs === undefined || member.expiresAtMs === null) return false;
  if (!Number.isSafeInteger(atMs) || atMs <= 0) return false;
  return atMs > member.expiresAtMs;
}

function queryMembersList(members, role) {
  if (role === 'members') return members;
  if (role === 'readers') return sortedKeys(members.filter(m => m.reader === true).map(m => m.publicKey));
  if (role === 'writers') return sortedKeys(members.filter(m => m.writer === true || m.administrator === true).map(m => m.publicKey));
  if (role === 'administrators') return sortedKeys(members.filter(m => m.administrator === true).map(m => m.publicKey));
  if (role === 'publishers') return sortedKeys(members.filter(m => m.publisher === true || m.administrator === true).map(m => m.publicKey));
  if (role === 'finalizers') return sortedKeys(members.filter(m => m.finalizer === true).map(m => m.publicKey));
  return [];
}

function checkMembersCapability(members, capability, actor, options) {
  const m = members.find(x => x.publicKey === actor);
  if (!m) return false;
  const atMs = options && Number.isSafeInteger(options.atMs) ? options.atMs : 0;
  if (isMemberExpired(m, atMs)) return false;
  if (capability === 'scope') {
    if (m.administrator === true) return true;
    const scope = options && typeof options.scope === 'string' ? options.scope : '';
    if (!scope) return false;
    if (!Array.isArray(m.scopes)) return false;
    return m.scopes.includes('*') || m.scopes.includes(scope);
  }
  if (capability === 'reader') return m.reader === true;
  if (capability === 'writer') return m.writer === true || m.administrator === true;
  if (capability === 'administrator') return m.administrator === true;
  if (capability === 'publisher') return m.publisher === true || m.administrator === true;
  if (capability === 'finalizer') return m.finalizer === true;
  if (capability === 'member') return true;
  return false;
}

function isLegacyReader(perms, author) {
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.reader === true));
}

function attestedMatchesPolicy(cur, attPayload, member) {
  const adm = cur.admission;
  if (!adm || adm.mode === 'strict') return false;
  if (Array.isArray(adm.removed) && adm.removed.includes(member.publicKey)) return false;
  if (cur.members.some(m => m.publicKey === member.publicKey)) return false;
  const accounts = Array.isArray(adm.accounts) ? adm.accounts : [];
  const email = typeof attPayload.email === 'string' ? attPayload.email.toLowerCase() : null;
  const accountOk = accounts.includes(attPayload.accountId) || (email !== null && accounts.includes('email:' + email));
  if (accountOk) {
    if (attPayload.subject === 'agent') {
      return member.administrator !== true && member.finalizer !== true;
    }
    const grant = adm.grant || { reader: true, writer: true, administrator: true };
    return Boolean(member.reader) === Boolean(grant.reader) &&
      Boolean(member.writer) === Boolean(grant.writer) &&
      Boolean(member.administrator) === Boolean(grant.administrator);
  }
  if (attPayload.inviteId && Array.isArray(adm.invites)) {
    const inv = adm.invites.find(i => i.inviteId === attPayload.inviteId && !i.revoked);
    if (!inv) return false;
    if (inv.binding && inv.binding.kind === 'email' && email !== inv.binding.email) return false;
    const expected = inv.role === 'admin'
      ? { reader: true, writer: true, administrator: true }
      : inv.role === 'reader'
        ? { reader: true, writer: false, administrator: false }
        : { reader: true, writer: true, administrator: false };
    return Boolean(member.reader) === expected.reader &&
      Boolean(member.writer) === expected.writer &&
      Boolean(member.administrator) === expected.administrator;
  }
  return false;
}

export const attestedMembers = {
  reduce(state, tx) {
    const cur = state && typeof state === 'object' ? state : { members: [], admission: null };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const authorIsAdmin = isLegacyAdmin(cur, tx.author);

    if (input.action === 'setMember') {
      if (!authorIsAdmin) {
        if (!isLegacyReader(cur, tx.author) || !input.attestation) {
          return { ok: false, code: 'admin_required' };
        }
      }
      if (input.attestation) {
        const att = input.attestation;
        const hostKey = cur.admission && cur.admission.hostKey;
        if (!hostKey || !HEX32.test(hostKey) || !HEX64.test(att.signature || '')) {
          return { ok: false, code: 'attestation_invalid' };
        }
        const msg = canonicalJson(['chronolog/host-attestation/v1', att.payload]);
        if (!verifyEd25519(hostKey, msg, att.signature)) {
          return { ok: false, code: 'attestation_signature_invalid' };
        }
        if (att.payload.publicKey !== input.member.publicKey) {
          return { ok: false, code: 'attestation_subject_mismatch' };
        }
        if (!authorIsAdmin && !attestedMatchesPolicy(cur, att.payload, input.member)) {
          return { ok: false, code: 'admin_required' };
        }
      }
      const next = normalizeMember(input.member);
      const members = cur.members.filter(m => m.publicKey !== next.publicKey).concat([next]);
      members.sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));
      let admission = cur.admission;
      if (authorIsAdmin && admission && Array.isArray(admission.removed) && admission.removed.includes(next.publicKey)) {
        admission = { ...admission, removed: admission.removed.filter(k => k !== next.publicKey) };
      }
      return { ok: true, state: { ...cur, members, admission }, events: [{ topic: '$permissions.member', payload: { publicKey: next.publicKey } }] };
    }

    if (input.action === 'requestRecovery') {
      const guardians = cur.guardians;
      if (!guardians || !Array.isArray(guardians.members) || guardians.members.length === 0) {
        return { ok: false, code: 'guardians_not_configured' };
      }
      if (!HEX32.test(input.newPublicKey || '') || !HEX32.test(input.newWrapKey || '')) {
        return { ok: false, code: 'invalid_recovery_key' };
      }
      if (tx.author !== input.newPublicKey && !authorIsAdmin) {
        return { ok: false, code: 'recovery_author_mismatch' };
      }
      const requestId = typeof input.requestId === 'string' && input.requestId.length > 0 ? input.requestId : tx.opId;
      const requests = { ...(cur.recoveryRequests || {}) };
      requests[requestId] = {
        requestId,
        newPublicKey: input.newPublicKey,
        newWrapKey: input.newWrapKey,
        label: typeof input.label === 'string' ? input.label.slice(0, 80) : 'Recovered device',
        verificationCode: typeof input.verificationCode === 'string' ? input.verificationCode.slice(0, 32) : '',
        approvals: [],
        status: 'pending',
        createdAtMs: Number(tx.authorTimestampMs || 0),
      };
      return {
        ok: true,
        state: { ...cur, recoveryRequests: requests },
        events: [{ topic: '$permissions.recovery_requested', payload: { requestId, newPublicKey: input.newPublicKey } }],
      };
    }

    if (input.action === 'approveRecovery') {
      const guardians = cur.guardians;
      if (!guardians || !Array.isArray(guardians.members) || !guardians.members.some(g => g.publicKey === tx.author)) {
        return { ok: false, code: 'guardian_required' };
      }
      const requests = { ...(cur.recoveryRequests || {}) };
      const req = requests[input.requestId];
      if (!req || req.status !== 'pending') return { ok: false, code: 'recovery_request_not_found' };
      const approvals = sortedKeys((req.approvals || []).concat([tx.author]));
      const completed = approvals.length >= guardians.threshold;
      requests[input.requestId] = { ...req, approvals, status: completed ? 'completed' : 'pending' };
      let members = cur.members;
      if (completed) {
        const promoted = normalizeMember({
          publicKey: req.newPublicKey,
          wrapKey: req.newWrapKey,
          label: req.label,
          reader: true,
          writer: true,
          administrator: true,
          publisher: true,
          finalizer: false,
        });
        members = cur.members.filter(m => m.publicKey !== promoted.publicKey).concat([promoted]);
        members.sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));
      }
      return {
        ok: true,
        state: { ...cur, members, recoveryRequests: requests },
        events: [{ topic: completed ? '$permissions.recovery_completed' : '$permissions.recovery_approved', payload: { requestId: input.requestId, guardian: tx.author, approvals: approvals.length, threshold: guardians.threshold } }],
      };
    }

    if (!authorIsAdmin) return { ok: false, code: 'admin_required' };

    if (input.action === 'setGuardians') {
      if (input.guardians === null) {
        return { ok: true, state: { ...cur, guardians: null }, events: [{ topic: '$permissions.guardians_cleared', payload: {} }] };
      }
      const g = input.guardians;
      if (!g || typeof g !== 'object' || !Array.isArray(g.members) || g.members.length === 0) {
        return { ok: false, code: 'invalid_guardians' };
      }
      const cleaned = [];
      const seen = new Set();
      for (const item of g.members) {
        if (!item || !HEX32.test(item.publicKey || '') || !HEX32.test(item.wrapKey || '') || seen.has(item.publicKey)) {
          return { ok: false, code: 'invalid_guardian' };
        }
        seen.add(item.publicKey);
        cleaned.push({
          publicKey: item.publicKey,
          wrapKey: item.wrapKey,
          ...(typeof item.label === 'string' && item.label.length > 0 ? { label: item.label.slice(0, 80) } : {}),
        });
      }
      cleaned.sort((a, b) => (a.publicKey < b.publicKey ? -1 : 1));
      const threshold = Number(g.threshold);
      if (!Number.isSafeInteger(threshold) || threshold < 1 || threshold > cleaned.length) {
        return { ok: false, code: 'invalid_guardian_threshold' };
      }
      return {
        ok: true,
        state: { ...cur, guardians: { threshold, members: cleaned } },
        events: [{ topic: '$permissions.guardians_updated', payload: { threshold, count: cleaned.length } }],
      };
    }

    if (input.action === 'removeMember') {
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      const members = cur.members.filter(m => m.publicKey !== input.publicKey);
      if (!members.some(m => m.administrator)) return { ok: false, code: 'last_admin_required' };
      let admission = cur.admission;
      if (admission && typeof admission === 'object') {
        const prevRemoved = Array.isArray(admission.removed) ? admission.removed : [];
        const removed = sortedKeys(prevRemoved.concat([input.publicKey])).slice(-512);
        admission = { ...admission, removed };
      }
      return { ok: true, state: { ...cur, members, admission }, events: [{ topic: '$permissions.removed', payload: { publicKey: input.publicKey } }] };
    }

    if (input.action === 'createInvite') {
      const inv = input.invite;
      if (!inv || typeof inv !== 'object' || typeof inv.inviteId !== 'string' || inv.inviteId.length < 1 || inv.inviteId.length > 128) {
        return { ok: false, code: 'invalid_invite' };
      }
      const admission = cur.admission && typeof cur.admission === 'object' ? cur.admission : { mode: 'attested' };
      const invites = (Array.isArray(admission.invites) ? admission.invites : []).filter(i => i.inviteId !== inv.inviteId).concat([{ ...inv, revoked: false }]).slice(-128);
      return { ok: true, state: { ...cur, admission: { ...admission, invites } }, events: [{ topic: '$permissions.invite_created', payload: { inviteId: inv.inviteId } }] };
    }

    if (input.action === 'revokeInvite') {
      if (typeof input.inviteId !== 'string' || !input.inviteId) return { ok: false, code: 'invalid_invite' };
      const admission = cur.admission && typeof cur.admission === 'object' ? cur.admission : null;
      if (!admission || !Array.isArray(admission.invites)) return { ok: false, code: 'invite_not_found' };
      let found = false;
      const invites = admission.invites.map(i => {
        if (i.inviteId !== input.inviteId) return i;
        found = true;
        return { ...i, revoked: true };
      });
      if (!found) return { ok: false, code: 'invite_not_found' };
      return { ok: true, state: { ...cur, admission: { ...admission, invites } }, events: [{ topic: '$permissions.invite_revoked', payload: { inviteId: input.inviteId } }] };
    }

    if (input.action === 'setAdmission') {
      return { ok: true, state: { ...cur, admission: input.admission ?? null } };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const cur = state && typeof state === 'object' ? state : { members: [], admission: null };
    const members = Array.isArray(cur.members) ? cur.members : [];
    if (input && typeof input === 'object') {
      if (typeof input.check === 'string' && typeof input.actor === 'string') {
        if (input.check === 'guardian') {
          return Boolean(cur.guardians && Array.isArray(cur.guardians.members) && cur.guardians.members.some(g => g.publicKey === input.actor));
        }
        return checkMembersCapability(members, input.check, input.actor, input);
      }
      if (typeof input.list === 'string') {
        if (input.list === 'guardians') return cur.guardians && Array.isArray(cur.guardians.members) ? cur.guardians.members.map(g => g.publicKey) : [];
        return queryMembersList(members, input.list);
      }
      if (input.guardians === true) {
        return { guardians: cur.guardians ?? null, recoveryRequests: cur.recoveryRequests ?? {} };
      }
      if (input.admission === true) {
        return cur.admission ?? null;
      }
      if (input.summary === true) {
        return {
          mode: 'attested',
          members,
          readers: queryMembersList(members, 'readers'),
          writers: queryMembersList(members, 'writers'),
          administrators: queryMembersList(members, 'administrators'),
          publishers: queryMembersList(members, 'publishers'),
          openReaders: false,
          openWriters: false,
          blockedAuthors: [],
          admission: cur.admission ?? null,
          guardians: cur.guardians ?? null,
          recoveryRequests: cur.recoveryRequests ?? {},
          multisig: null,
        };
      }
      if (input.publicKey) {
        return members.find(m => m.publicKey === input.publicKey) || null;
      }
    }
    return cur;
  },
};

/**
 * Open public-write / open-read authority model:
 * Any valid Ed25519 key can write (and read when openRead !== false), while listed
 * administrators govern control topics ($reducers, $finality, $publications).
 */
export const openMembers = {
  reduce(state, tx) {
    const cur = state && typeof state === 'object'
      ? {
          admins: Array.isArray(state.admins) ? state.admins : [],
          members: Array.isArray(state.members) ? state.members : [],
          openRead: state.openRead !== false,
          openWrite: state.openWrite !== false,
          blockedAuthors: Array.isArray(state.blockedAuthors) ? state.blockedAuthors : [],
          vouchedAuthors: Array.isArray(state.vouchedAuthors) ? state.vouchedAuthors : [],
          antiSpam: state.antiSpam && typeof state.antiSpam === 'object' ? state.antiSpam : null,
          admission: state.admission ?? null,
        }
      : { admins: [], members: [], openRead: true, openWrite: true, blockedAuthors: [], vouchedAuthors: [], antiSpam: null, admission: null };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };

    if (input.action === 'vouchAuthor') {
      const canVouch = cur.admins.includes(tx.author) || cur.vouchedAuthors.includes(tx.author);
      if (!canVouch) return { ok: false, code: 'vouch_permission_required' };
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      if (cur.blockedAuthors.includes(input.publicKey)) return { ok: false, code: 'author_blocked' };
      const vouchedAuthors = sortedKeys(cur.vouchedAuthors.concat([input.publicKey])).slice(-4096);
      return { ok: true, state: { ...cur, vouchedAuthors }, events: [{ topic: '$permissions.author_vouched', payload: { publicKey: input.publicKey, by: tx.author } }] };
    }

    if (!cur.admins.includes(tx.author)) return { ok: false, code: 'admin_required' };

    if (input.action === 'setAntiSpam') {
      if (input.antiSpam === null) {
        return { ok: true, state: { ...cur, antiSpam: null } };
      }
      const cfg = input.antiSpam;
      if (!cfg || typeof cfg !== 'object') return { ok: false, code: 'invalid_antispam' };
      const next = {
        requireVouch: Boolean(cfg.requireVouch),
        ...(Number.isSafeInteger(cfg.maxOpsPerWindow) && cfg.maxOpsPerWindow > 0 ? { maxOpsPerWindow: cfg.maxOpsPerWindow } : {}),
        ...(Number.isSafeInteger(cfg.windowMs) && cfg.windowMs > 0 ? { windowMs: cfg.windowMs } : {}),
      };
      return { ok: true, state: { ...cur, antiSpam: next }, events: [{ topic: '$permissions.antispam_updated', payload: next }] };
    }

    if (input.action === 'setAdmin') {
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      const admins = input.enabled === false
        ? cur.admins.filter(k => k !== input.publicKey)
        : sortedKeys(cur.admins.concat([input.publicKey]));
      if (admins.length === 0) return { ok: false, code: 'last_admin_required' };
      const blockedAuthors = input.enabled === false
        ? cur.blockedAuthors
        : cur.blockedAuthors.filter(k => k !== input.publicKey);
      return { ok: true, state: { ...cur, admins, blockedAuthors }, events: [{ topic: '$permissions.admin', payload: { publicKey: input.publicKey, enabled: input.enabled !== false } }] };
    }

    if (input.action === 'setOpen') {
      return {
        ok: true,
        state: {
          ...cur,
          ...(input.openRead === undefined ? {} : { openRead: Boolean(input.openRead) }),
          ...(input.openWrite === undefined ? {} : { openWrite: Boolean(input.openWrite) }),
        },
      };
    }

    if (input.action === 'blockAuthor') {
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      if (cur.admins.includes(input.publicKey)) return { ok: false, code: 'cannot_block_admin' };
      const blockedAuthors = sortedKeys(cur.blockedAuthors.concat([input.publicKey])).slice(-2048);
      return {
        ok: true,
        state: { ...cur, blockedAuthors },
        events: [{ topic: '$permissions.author_blocked', payload: { publicKey: input.publicKey, ...(typeof input.reason === 'string' && input.reason ? { reason: input.reason.slice(0, 160) } : {}) } }],
      };
    }

    if (input.action === 'unblockAuthor') {
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      const blockedAuthors = cur.blockedAuthors.filter(k => k !== input.publicKey);
      return {
        ok: true,
        state: { ...cur, blockedAuthors },
        events: [{ topic: '$permissions.author_unblocked', payload: { publicKey: input.publicKey } }],
      };
    }

    if (input.action === 'setMember') {
      const next = normalizeMember(input.member);
      const members = cur.members.filter(m => m.publicKey !== next.publicKey).concat([next]);
      members.sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));
      const admins = next.administrator ? sortedKeys(cur.admins.concat([next.publicKey])) : cur.admins;
      const blockedAuthors = next.administrator ? cur.blockedAuthors.filter(k => k !== next.publicKey) : cur.blockedAuthors;
      return { ok: true, state: { ...cur, admins, members, blockedAuthors }, events: [{ topic: '$permissions.member', payload: { publicKey: next.publicKey } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const cur = state && typeof state === 'object'
      ? {
          admins: Array.isArray(state.admins) ? state.admins : [],
          members: Array.isArray(state.members) ? state.members : [],
          openRead: state.openRead !== false,
          openWrite: state.openWrite !== false,
          blockedAuthors: Array.isArray(state.blockedAuthors) ? sortedKeys(state.blockedAuthors.filter(k => HEX32.test(k || ''))) : [],
          vouchedAuthors: Array.isArray(state.vouchedAuthors) ? sortedKeys(state.vouchedAuthors.filter(k => HEX32.test(k || ''))) : [],
          antiSpam: state.antiSpam && typeof state.antiSpam === 'object' ? state.antiSpam : null,
          admission: state.admission ?? null,
        }
      : { admins: [], members: [], openRead: true, openWrite: true, blockedAuthors: [], vouchedAuthors: [], antiSpam: null, admission: null };

    const adminSet = new Set(cur.admins);
    const blockedSet = new Set(cur.blockedAuthors);
    const vouchedSet = new Set(cur.vouchedAuthors);
    const synthesizedMap = new Map();
    for (const m of cur.members) synthesizedMap.set(m.publicKey, m);
    for (const a of cur.admins) {
      const existing = synthesizedMap.get(a);
      synthesizedMap.set(a, {
        publicKey: a,
        ...(existing && existing.wrapKey ? { wrapKey: existing.wrapKey } : {}),
        reader: true,
        writer: true,
        administrator: true,
        publisher: true,
        finalizer: Boolean(existing && existing.finalizer),
      });
    }
    const members = Array.from(synthesizedMap.values()).sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));

    if (input && typeof input === 'object') {
      if (typeof input.check === 'string' && typeof input.actor === 'string') {
        if (!HEX32.test(input.actor)) return false;
        if (input.check === 'blocked') return blockedSet.has(input.actor);
        if (input.check === 'administrator') return adminSet.has(input.actor);
        if (input.check === 'publisher') return adminSet.has(input.actor) || checkMembersCapability(members, 'publisher', input.actor);
        if (input.check === 'writer') {
          if (blockedSet.has(input.actor)) return false;
          if (adminSet.has(input.actor)) return true;
          if (checkMembersCapability(members, 'writer', input.actor, input)) return true;
          if (!cur.openWrite) return false;
          if (cur.antiSpam && cur.antiSpam.requireVouch === true) {
            return vouchedSet.has(input.actor);
          }
          return true;
        }
        if (input.check === 'reader') return cur.openRead || adminSet.has(input.actor) || checkMembersCapability(members, 'reader', input.actor, input);
        if (input.check === 'member') return cur.openWrite || cur.openRead || adminSet.has(input.actor) || checkMembersCapability(members, 'member', input.actor, input);
        return checkMembersCapability(members, input.check, input.actor, input);
      }
      if (typeof input.list === 'string') {
        if (input.list === 'blockedAuthors') return cur.blockedAuthors;
        if (input.list === 'readers' && cur.openRead) return ['*'];
        if (input.list === 'writers' && cur.openWrite) return ['*'];
        return queryMembersList(members, input.list);
      }
      if (input.admission === true) return cur.admission;
      if (input.summary === true) {
        return {
          mode: 'open',
          members,
          readers: cur.openRead ? ['*'] : queryMembersList(members, 'readers'),
          writers: cur.openWrite ? ['*'] : queryMembersList(members, 'writers'),
          administrators: sortedKeys(cur.admins),
          publishers: queryMembersList(members, 'publishers'),
          openReaders: cur.openRead,
          openWriters: cur.openWrite,
          blockedAuthors: cur.blockedAuthors,
          admission: cur.admission,
          multisig: null,
        };
      }
      if (input.publicKey) {
        return members.find(m => m.publicKey === input.publicKey) || null;
      }
    }
    return cur;
  },
};

/**
 * M-of-N multisig authority model (zero host attestation, completely distinct state shape):
 * State: { threshold: number, signers: string[], members: Record<pubkey, { wrapKey?, reader, writer, publisher, finalizer }>, proposals: Record<id, ...> }
 * Signers submit proposals (action: 'propose' | 'approve'); once approvals >= threshold, the proposal executes atomically.
 */
function normalizeMultisigState(state) {
  const s = state && typeof state === 'object' ? state : {};
  const signers = sortedKeys(Array.isArray(s.signers) ? s.signers.filter(k => HEX32.test(k || '')) : []);
  const threshold = Number.isSafeInteger(s.threshold) && s.threshold >= 1 ? Math.min(s.threshold, Math.max(1, signers.length)) : 1;
  const members = s.members && typeof s.members === 'object' && !Array.isArray(s.members) ? { ...s.members } : {};
  const proposals = s.proposals && typeof s.proposals === 'object' && !Array.isArray(s.proposals) ? { ...s.proposals } : {};
  return { threshold, signers, members, proposals };
}

function multisigMemberRecords(cur) {
  const byKey = new Map();
  for (const [pk, entry] of Object.entries(cur.members)) {
    if (!HEX32.test(pk) || !entry || typeof entry !== 'object') continue;
    byKey.set(pk, {
      publicKey: pk,
      ...(entry.wrapKey ? { wrapKey: entry.wrapKey } : {}),
      reader: Boolean(entry.reader),
      writer: Boolean(entry.writer),
      administrator: cur.signers.includes(pk),
      publisher: Boolean(entry.publisher) || cur.signers.includes(pk),
      finalizer: Boolean(entry.finalizer),
    });
  }
  for (const pk of cur.signers) {
    if (!byKey.has(pk)) {
      byKey.set(pk, {
        publicKey: pk,
        reader: true,
        writer: true,
        administrator: true,
        publisher: true,
        finalizer: false,
      });
    }
  }
  return Array.from(byKey.values()).sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));
}

function applyMultisigProposal(cur, prop) {
  if (prop.kind === 'setMember') {
    const m = normalizeMember(prop.member);
    const nextMembers = {
      ...cur.members,
      [m.publicKey]: {
        ...(m.wrapKey ? { wrapKey: m.wrapKey } : {}),
        reader: m.reader,
        writer: m.writer,
        publisher: m.publisher,
        finalizer: m.finalizer,
      },
    };
    const nextSigners = m.administrator
      ? sortedKeys(cur.signers.concat([m.publicKey]))
      : cur.signers.filter(k => k !== m.publicKey);
    if (nextSigners.length === 0 || nextSigners.length < cur.threshold) {
      return { ok: false, code: 'threshold_unsatisfiable' };
    }
    return { ok: true, state: { ...cur, signers: nextSigners, members: nextMembers }, event: { topic: '$permissions.member', payload: { publicKey: m.publicKey } } };
  }
  if (prop.kind === 'removeMember') {
    if (!HEX32.test(prop.publicKey || '')) return { ok: false, code: 'invalid_member' };
    const nextMembers = { ...cur.members };
    delete nextMembers[prop.publicKey];
    const nextSigners = cur.signers.filter(k => k !== prop.publicKey);
    if (nextSigners.length === 0 || nextSigners.length < cur.threshold) return { ok: false, code: 'threshold_unsatisfiable' };
    return { ok: true, state: { ...cur, signers: nextSigners, members: nextMembers }, event: { topic: '$permissions.removed', payload: { publicKey: prop.publicKey } } };
  }
  if (prop.kind === 'setThreshold') {
    const t = prop.threshold;
    if (!Number.isSafeInteger(t) || t < 1 || t > cur.signers.length) return { ok: false, code: 'invalid_threshold' };
    return { ok: true, state: { ...cur, threshold: t }, event: { topic: '$permissions.threshold', payload: { threshold: t } } };
  }
  return { ok: false, code: 'unknown_proposal_kind' };
}

export const multisigMembers = {
  reduce(state, tx) {
    const cur = normalizeMultisigState(state);
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    if (!cur.signers.includes(tx.author)) return { ok: false, code: 'signer_required' };

    if (input.action === 'propose') {
      const id = typeof input.proposalId === 'string' && input.proposalId.length > 0 ? input.proposalId : tx.opId;
      if (cur.proposals[id]) return { ok: false, code: 'proposal_exists' };
      const prop = {
        kind: input.kind,
        ...(input.member !== undefined ? { member: input.member } : {}),
        ...(input.publicKey !== undefined ? { publicKey: input.publicKey } : {}),
        ...(input.threshold !== undefined ? { threshold: input.threshold } : {}),
        approvals: [tx.author],
      };
      if (prop.approvals.length >= cur.threshold) {
        const applied = applyMultisigProposal(cur, prop);
        if (!applied.ok) return applied;
        return { ok: true, state: applied.state, events: [applied.event] };
      }
      const nextProposals = { ...cur.proposals, [id]: prop };
      return {
        ok: true,
        state: { ...cur, proposals: nextProposals },
        events: [{ topic: '$permissions.proposed', payload: { proposalId: id, approvals: 1, threshold: cur.threshold } }],
      };
    }

    if (input.action === 'approve') {
      const id = input.proposalId;
      const existing = typeof id === 'string' ? cur.proposals[id] : null;
      if (!existing) return { ok: false, code: 'proposal_not_found' };
      const approvals = sortedKeys((existing.approvals || []).concat([tx.author]));
      const updated = { ...existing, approvals };
      if (approvals.length >= cur.threshold) {
        const nextProposals = { ...cur.proposals };
        delete nextProposals[id];
        const applied = applyMultisigProposal({ ...cur, proposals: nextProposals }, updated);
        if (!applied.ok) return applied;
        return { ok: true, state: applied.state, events: [applied.event] };
      }
      return {
        ok: true,
        state: { ...cur, proposals: { ...cur.proposals, [id]: updated } },
        events: [{ topic: '$permissions.approved', payload: { proposalId: id, approvals: approvals.length, threshold: cur.threshold } }],
      };
    }

    if (input.action === 'cancel') {
      const id = input.proposalId;
      if (typeof id !== 'string' || !cur.proposals[id]) return { ok: false, code: 'proposal_not_found' };
      const nextProposals = { ...cur.proposals };
      delete nextProposals[id];
      return {
        ok: true,
        state: { ...cur, proposals: nextProposals },
        events: [{ topic: '$permissions.cancelled', payload: { proposalId: id } }],
      };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const cur = normalizeMultisigState(state);
    const members = multisigMemberRecords(cur);
    if (input && typeof input === 'object') {
      if (typeof input.check === 'string' && typeof input.actor === 'string') {
        return checkMembersCapability(members, input.check, input.actor);
      }
      if (typeof input.list === 'string') {
        return queryMembersList(members, input.list);
      }
      if (input.admission === true) return null;
      if (input.summary === true) {
        return {
          mode: 'multisig',
          members,
          readers: queryMembersList(members, 'readers'),
          writers: queryMembersList(members, 'writers'),
          administrators: queryMembersList(members, 'administrators'),
          publishers: queryMembersList(members, 'publishers'),
          openReaders: false,
          openWriters: false,
          blockedAuthors: [],
          admission: null,
          multisig: {
            threshold: cur.threshold,
            signers: cur.signers,
            proposals: cur.proposals,
          },
        };
      }
      if (input.publicKey) {
        return members.find(m => m.publicKey === input.publicKey) || null;
      }
    }
    return cur;
  },
};

export const adminOnlyReducers = {
  reduce(state, tx, ctx) {
    if (!hasCapability(ctx, 'administrator', tx.author)) return { ok: false, code: 'admin_required' };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const next = {
      runtime: state.runtime,
      imports: { ...(state.imports || {}) },
      topics: { ...(state.topics || {}) },
    };
    if (input.imports && typeof input.imports === 'object') {
      for (const [k, v] of Object.entries(input.imports)) {
        if (v === null) delete next.imports[k];
        else next.imports[k] = v;
      }
    }
    if (input.topics && typeof input.topics === 'object') {
      for (const [k, v] of Object.entries(input.topics)) {
        if (v === null) delete next.topics[k];
        else next.topics[k] = v;
      }
    }
    return { ok: true, state: next, events: [{ topic: '$reducers.updated', payload: { author: tx.author } }] };
  },
};

export const defaultSignalPolicy = {
  reduce(state, tx, ctx) {
    if (!hasCapability(ctx, 'administrator', tx.author)) return { ok: false, code: 'admin_required' };
    if (!tx.payload || !Array.isArray(tx.payload.rules)) return { ok: false, code: 'invalid_signal_policy' };
    return { ok: true, state: { rules: tx.payload.rules } };
  },
  query(state, _input, ctx) {
    if (state && Array.isArray(state.rules)) return state;
    const queried = ctx.query('$permissions', { list: 'readers' });
    if (Array.isArray(queried)) {
      return {
        rules: [{ topicPattern: '*', allowedAuthors: queried, maxTtlMs: 30000, allowRelay: true }],
      };
    }
    const perms = ctx.topic('$permissions') || { members: [] };
    const readers = Array.isArray(perms.members) ? perms.members.filter(m => m.reader).map(m => m.publicKey) : [];
    return {
      rules: [{ topicPattern: '*', allowedAuthors: readers, maxTtlMs: 30000, allowRelay: true }],
    };
  },
};
`.trimStart();
var STD_KEYS_SOURCE = `
const HEX32 = /^[0-9a-f]{64}$/;

function isAdmin(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.administrator === true));
}

function isReader(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'reader', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.reader === true));
}

function isGuardian(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'guardian', actor: author });
  return checked === true;
}

const RING_RE = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/;

export const hpkeEpochs = {
  reduce(state, tx, ctx) {
    const cur = state && typeof state === 'object' ? state : { currentEpoch: -1, epochs: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };

    if (input.action === 'setRecoveryVault') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      const vault = input.vault;
      if (!vault || typeof vault.nonce !== 'string' || typeof vault.ciphertext !== 'string') {
        return { ok: false, code: 'recovery_vault_invalid' };
      }
      if (!input.guardianShares || typeof input.guardianShares !== 'object') {
        return { ok: false, code: 'guardian_shares_invalid' };
      }
      const guardianShares = {};
      for (const [pk, item] of Object.entries(input.guardianShares)) {
        if (!HEX32.test(pk) || !item || !Number.isSafeInteger(item.index) || item.index < 1 || item.index > 255 || !item.box || typeof item.box.encapsulatedKey !== 'string' || typeof item.box.ciphertext !== 'string') {
          return { ok: false, code: 'guardian_share_invalid' };
        }
        guardianShares[pk] = { index: item.index, box: { encapsulatedKey: item.box.encapsulatedKey, ciphertext: item.box.ciphertext } };
      }
      return {
        ok: true,
        state: {
          ...cur,
          recovery: {
            vault: { nonce: vault.nonce, ciphertext: vault.ciphertext },
            guardianShares,
          },
        },
        events: [{ topic: '$keys.recovery_vault_updated', payload: { guardians: Object.keys(guardianShares).length } }],
      };
    }

    if (input.action === 'submitRecoveryShare') {
      if (!isGuardian(ctx, tx.author)) return { ok: false, code: 'guardian_required' };
      if (!HEX32.test(input.member || '') || !Number.isSafeInteger(input.index) || input.index < 1 || input.index > 255 || !input.box || typeof input.box.encapsulatedKey !== 'string' || typeof input.box.ciphertext !== 'string') {
        return { ok: false, code: 'recovery_share_invalid' };
      }
      const recoveryGrants = { ...(cur.recoveryGrants || {}) };
      const forMember = { ...(recoveryGrants[input.member] || {}) };
      forMember[tx.author] = {
        index: input.index,
        box: { encapsulatedKey: input.box.encapsulatedKey, ciphertext: input.box.ciphertext },
      };
      recoveryGrants[input.member] = forMember;
      return {
        ok: true,
        state: { ...cur, recoveryGrants },
        events: [{ topic: '$keys.recovery_share_submitted', payload: { member: input.member, guardian: tx.author } }],
      };
    }

    if (input.action === 'rotateRingEpoch') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      const ringName = typeof input.ring === 'string' && RING_RE.test(input.ring) ? input.ring : null;
      if (!ringName || ringName === 'default') return { ok: false, code: 'ring_name_invalid' };
      const rings = { ...(cur.rings || {}) };
      const prevRing = rings[ringName] || { currentEpoch: -1, epochs: {} };
      const epoch = input.epoch;
      if (!Number.isSafeInteger(epoch) || epoch !== prevRing.currentEpoch + 1) return { ok: false, code: 'epoch_sequence_invalid' };
      if (!HEX32.test(input.keyCommitment || '')) return { ok: false, code: 'key_commitment_invalid' };
      if (!input.boxes || typeof input.boxes !== 'object') return { ok: false, code: 'boxes_invalid' };
      const boxes = {};
      for (const [pk, box] of Object.entries(input.boxes)) {
        if (!HEX32.test(pk) || !box || typeof box.encapsulatedKey !== 'string' || typeof box.ciphertext !== 'string') {
          return { ok: false, code: 'box_invalid' };
        }
        boxes[pk] = { encapsulatedKey: box.encapsulatedKey, ciphertext: box.ciphertext };
      }
      rings[ringName] = {
        currentEpoch: epoch,
        epochs: { ...prevRing.epochs, [String(epoch)]: { epoch, keyCommitment: input.keyCommitment, boxes } },
      };
      const topicRings = { ...(cur.topicRings || {}) };
      if (Array.isArray(input.topics)) {
        for (const t of input.topics) {
          if (typeof t === 'string' && t.length > 0 && !t.startsWith('$')) topicRings[t] = ringName;
        }
      }
      return {
        ok: true,
        state: { ...cur, rings, topicRings },
        events: [{ topic: '$keys.ring_rotated', payload: { ring: ringName, epoch } }],
      };
    }

    if (input.action === 'grantRingBoxes') {
      if (!isAdmin(ctx, tx.author) && !isReader(ctx, tx.author)) return { ok: false, code: 'reader_required' };
      const ringName = typeof input.ring === 'string' && RING_RE.test(input.ring) ? input.ring : null;
      const rings = { ...(cur.rings || {}) };
      if (!ringName || !rings[ringName]) return { ok: false, code: 'ring_not_found' };
      if (!HEX32.test(input.member || '') || !input.epochBoxes || typeof input.epochBoxes !== 'object') {
        return { ok: false, code: 'grant_boxes_invalid' };
      }
      const nextEpochs = { ...rings[ringName].epochs };
      for (const [epKey, box] of Object.entries(input.epochBoxes)) {
        const existing = nextEpochs[epKey];
        if (!existing) return { ok: false, code: 'epoch_missing' };
        if (!box || typeof box.encapsulatedKey !== 'string' || typeof box.ciphertext !== 'string') {
          return { ok: false, code: 'box_invalid' };
        }
        nextEpochs[epKey] = {
          ...existing,
          boxes: { ...existing.boxes, [input.member]: { encapsulatedKey: box.encapsulatedKey, ciphertext: box.ciphertext } },
        };
      }
      rings[ringName] = { ...rings[ringName], epochs: nextEpochs };
      return {
        ok: true,
        state: { ...cur, rings },
        events: [{ topic: '$keys.ring_granted', payload: { ring: ringName, member: input.member } }],
      };
    }

    if (input.action === 'rotateEpoch') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      const epoch = input.epoch;
      if (!Number.isSafeInteger(epoch) || epoch !== cur.currentEpoch + 1) return { ok: false, code: 'epoch_sequence_invalid' };
      if (!HEX32.test(input.keyCommitment || '')) return { ok: false, code: 'key_commitment_invalid' };
      if (!input.boxes || typeof input.boxes !== 'object') return { ok: false, code: 'boxes_invalid' };
      const boxes = {};
      for (const [pk, box] of Object.entries(input.boxes)) {
        if (!HEX32.test(pk) || !box || typeof box.encapsulatedKey !== 'string' || typeof box.ciphertext !== 'string') {
          return { ok: false, code: 'box_invalid' };
        }
        boxes[pk] = { encapsulatedKey: box.encapsulatedKey, ciphertext: box.ciphertext };
      }
      const nextEpochs = { ...cur.epochs, [String(epoch)]: { epoch, keyCommitment: input.keyCommitment, boxes } };
      return {
        ok: true,
        state: { ...cur, currentEpoch: epoch, epochs: nextEpochs },
        events: [{ topic: '$keys.rotated', payload: { epoch } }],
      };
    }

    // Grant a newly admitted fresh device lockboxes for one or more retained historical epochs (0..N or checkpointEpoch..N).
    // Any existing reader holding the epoch keys may seal lockboxes for an already-authorized reader in $permissions.
    if (input.action === 'grantBoxes') {
      if (!isAdmin(ctx, tx.author) && !isReader(ctx, tx.author)) return { ok: false, code: 'reader_required' };
      if (!HEX32.test(input.member || '') || !input.epochBoxes || typeof input.epochBoxes !== 'object') {
        return { ok: false, code: 'grant_boxes_invalid' };
      }
      if (!isAdmin(ctx, tx.author) && !isReader(ctx, input.member)) {
        return { ok: false, code: 'member_not_authorized' };
      }
      const nextEpochs = { ...cur.epochs };
      for (const [epKey, box] of Object.entries(input.epochBoxes)) {
        const existing = nextEpochs[epKey];
        if (!existing) return { ok: false, code: 'epoch_missing' };
        if (!box || typeof box.encapsulatedKey !== 'string' || typeof box.ciphertext !== 'string') {
          return { ok: false, code: 'box_invalid' };
        }
        nextEpochs[epKey] = {
          ...existing,
          boxes: { ...existing.boxes, [input.member]: { encapsulatedKey: box.encapsulatedKey, ciphertext: box.ciphertext } },
        };
      }
      return {
        ok: true,
        state: { ...cur, currentEpoch: cur.currentEpoch, epochs: nextEpochs },
        events: [{ topic: '$keys.granted', payload: { member: input.member } }],
      };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const cur = state || { currentEpoch: -1, epochs: {} };
    if (input && typeof input === 'object') {
      if (typeof input.recoveryFor === 'string') {
        const vault = cur.recovery ? cur.recovery.vault : null;
        const shares = cur.recoveryGrants && cur.recoveryGrants[input.recoveryFor] ? cur.recoveryGrants[input.recoveryFor] : {};
        return { vault, shares };
      }
      if (typeof input.guardianShareFor === 'string') {
        return cur.recovery && cur.recovery.guardianShares ? (cur.recovery.guardianShares[input.guardianShareFor] || null) : null;
      }
      if (typeof input.topicRing === 'string') {
        return cur.topicRings && cur.topicRings[input.topicRing] ? cur.topicRings[input.topicRing] : 'default';
      }
      if (typeof input.ring === 'string' && input.ring !== 'default') {
        const ring = cur.rings && cur.rings[input.ring] ? cur.rings[input.ring] : { currentEpoch: -1, epochs: {} };
        if (input.member) {
          const out = {};
          for (const [ep, entry] of Object.entries(ring.epochs || {})) {
            if (entry.boxes && entry.boxes[input.member]) {
              out[ep] = { epoch: entry.epoch, keyCommitment: entry.keyCommitment, box: entry.boxes[input.member] };
            }
          }
          return { ring: input.ring, currentEpoch: ring.currentEpoch, memberEpochs: out };
        }
        return ring;
      }
      if (input.member) {
        const out = {};
        for (const [ep, entry] of Object.entries(cur.epochs || {})) {
          if (entry.boxes && entry.boxes[input.member]) {
            out[ep] = { epoch: entry.epoch, keyCommitment: entry.keyCommitment, box: entry.boxes[input.member] };
          }
        }
        return { currentEpoch: cur.currentEpoch, memberEpochs: out };
      }
    }
    return cur;
  },
};
`.trimStart();
var STD_FINALITY_SOURCE = `
function isAdmin(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.administrator === true));
}

function validPolicy(policy) {
  if (!policy || typeof policy !== 'object') return false;
  if (policy.kind === 'none') return true;
  if (policy.kind === 'signed-frontier') return typeof policy.signer === 'string' && /^[0-9a-f]{64}$/.test(policy.signer);
  if (policy.kind === 'fixed-validator') {
    return Array.isArray(policy.validators) && policy.validators.length > 0 &&
      policy.validators.every(v => typeof v === 'string' && /^[0-9a-f]{64}$/.test(v)) &&
      Number.isSafeInteger(policy.threshold) && policy.threshold >= 1 && policy.threshold <= policy.validators.length;
  }
  if (policy.kind === 'blockchain-anchor') {
    return typeof policy.chain === 'string' && policy.chain.length > 0 && typeof policy.anchorId === 'string' && policy.anchorId.length > 0;
  }
  if (policy.kind === 'predicate') {
    return typeof policy.module === 'string' && policy.module.length > 0 &&
      (policy.export === undefined || (typeof policy.export === 'string' && policy.export.length > 0));
  }
  return false;
}

export const scheduledFinality = {
  reduce(state, tx, ctx) {
    if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
    const cur = state && Array.isArray(state.schedule) ? state : { schedule: [{ effectiveAfterMs: -1, policy: { kind: 'none' } }] };
    const input = tx.payload;
    if (!input || input.action !== 'schedulePolicy' || !validPolicy(input.policy)) return { ok: false, code: 'invalid_finality_policy' };
    const effectiveAfterMs = input.effectiveAfterMs;
    const last = cur.schedule[cur.schedule.length - 1];
    if (!Number.isSafeInteger(effectiveAfterMs) || effectiveAfterMs <= last.effectiveAfterMs) {
      return { ok: false, code: 'finality_activation_not_monotonic' };
    }
    if (effectiveAfterMs < tx.authorTimestampMs) {
      return { ok: false, code: 'finality_activation_in_past' };
    }
    const nextSchedule = cur.schedule.concat([{ effectiveAfterMs, policy: input.policy }]);
    return {
      ok: true,
      state: { schedule: nextSchedule },
      events: [{ topic: '$finality.scheduled', payload: { effectiveAfterMs, kind: input.policy.kind } }],
    };
  },
  query(state) {
    return state || { schedule: [{ effectiveAfterMs: -1, policy: { kind: 'none' } }] };
  },
};
`.trimStart();
var STD_PUBLICATIONS_SOURCE = `
const HEX32 = /^[0-9a-f]{64}$/;

function isPublisher(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'publisher', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && (m.publisher === true || m.administrator === true)));
}

function validPublicationPath(path) {
  if (typeof path !== 'string' || path.length === 0 || path.length > 512 || path.startsWith('/')) return false;
  for (let i = 0; i < path.length; i++) {
    const code = path.charCodeAt(i);
    if (code < 0x20 || code === 0x7f || code === 0x5c) return false;
  }
  const parts = path.split('/');
  return !parts.some(p => p.length === 0 || p === '.' || p === '..');
}

export const signedReleases = {
  reduce(state, tx, ctx) {
    if (!isPublisher(ctx, tx.author)) return { ok: false, code: 'publisher_required' };
    const cur = state && typeof state === 'object' ? state : { revision: 0, current: null, history: [] };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_publication' };

    if (input.action === 'rollback') {
      const hist = Array.isArray(cur.history) ? cur.history : [];
      const target = input.opId !== undefined
        ? hist.find(r => r.opId === input.opId)
        : Number.isSafeInteger(input.revision)
          ? hist.find(r => r.revision === input.revision)
          : null;
      if (!target || !Array.isArray(target.files)) return { ok: false, code: 'publication_not_found' };
      const revision = cur.revision + 1;
      const release = {
        revision,
        opId: tx.opId,
        author: tx.author,
        timestampMs: tx.authorTimestampMs,
        entry: target.entry,
        files: target.files,
        ...(typeof target.treeRoot === 'string' ? { treeRoot: target.treeRoot } : {}),
        rollbackOf: target.revision,
      };
      const history = hist.concat([release]).slice(-128);
      return {
        ok: true,
        state: { revision, current: release, history },
        events: [{ topic: '$publications.published', payload: { revision, opId: tx.opId, rollbackOf: target.revision } }],
      };
    }

    if (input.action !== 'publish' || typeof input.entry !== 'string' || !Array.isArray(input.files) || input.files.length === 0) {
      return { ok: false, code: 'invalid_publication' };
    }
    if (input.expectedRevision !== undefined && input.expectedRevision !== cur.revision) {
      return { ok: false, code: 'publication_revision_conflict' };
    }
    if (input.treeRoot !== undefined && (typeof input.treeRoot !== 'string' || !/^cas:sha256-[0-9a-f]{64}$/.test(input.treeRoot))) {
      return { ok: false, code: 'invalid_publication_tree_root' };
    }
    const files = [];
    const seenPaths = new Set();
    for (const f of input.files) {
      if (!f || !validPublicationPath(f.path) || seenPaths.has(f.path) || !HEX32.test(f.hash || '') || !Number.isSafeInteger(f.size) || f.size < 0 || typeof f.type !== 'string' || f.type.length === 0) {
        return { ok: false, code: 'invalid_publication_file' };
      }
      seenPaths.add(f.path);
      files.push({ path: f.path, hash: f.hash, size: f.size, type: f.type });
    }
    if (!files.some(f => f.path === input.entry)) return { ok: false, code: 'publication_entry_missing' };
    const revision = cur.revision + 1;
    const release = {
      revision,
      opId: tx.opId,
      author: tx.author,
      timestampMs: tx.authorTimestampMs,
      entry: input.entry,
      files,
      ...(typeof input.treeRoot === 'string' ? { treeRoot: input.treeRoot } : {}),
    };
    const history = (Array.isArray(cur.history) ? cur.history : []).concat([release]).slice(-128);
    return {
      ok: true,
      state: { revision, current: release, history },
      events: [{ topic: '$publications.published', payload: { revision, opId: tx.opId } }],
    };
  },
  query(state, input) {
    const cur = state && typeof state === 'object' ? state : { revision: 0, current: null, history: [] };
    if (input && typeof input === 'object') {
      const hist = Array.isArray(cur.history) ? cur.history : [];
      if (typeof input.opId === 'string') {
        if (cur.current && cur.current.opId === input.opId) return cur.current;
        return hist.find(r => r.opId === input.opId) || null;
      }
      if (Number.isSafeInteger(input.revision)) {
        if (cur.current && cur.current.revision === input.revision) return cur.current;
        return hist.find(r => r.revision === input.revision) || null;
      }
      if (input.history === true) return hist;
    }
    return cur;
  },
};
`.trimStart();
var STD_RLS_SOURCE = `
function quoteIdent(name) {
  if (typeof name !== 'string' || !/^[A-Za-z][A-Za-z0-9_]*$/.test(name) || name.startsWith('_rls_') || name.startsWith('sqlite_')) {
    throw new Error('RLS_INVALID_IDENTIFIER:' + String(name));
  }
  return '"' + name + '"';
}

/**
 * Install Postgres-style write RLS triggers on tables inside a chronolog:sqlite database.
 * Each predicate is validated via db.validateExpr() (SQLite mode:'readonly', zero trailing tokens)
 * before wrapping in a BEFORE INSERT/UPDATE/DELETE trigger with RAISE(ABORT, ...).
 */
export function applyRls(db, policies) {
  if (!policies || typeof policies !== 'object') throw new Error('RLS_POLICIES_INVALID');
  const ops = [
    ['insert', 'INSERT'],
    ['update', 'UPDATE'],
    ['delete', 'DELETE'],
  ];
  for (const [table, rule] of Object.entries(policies)) {
    const qTable = quoteIdent(table);
    for (const [key, sqlOp] of ops) {
      const trigName = '_rls_' + table + '_' + key;
      db.exec('DROP TRIGGER IF EXISTS ' + '"' + trigName + '"', [], { mode: 'admin' });
      const expr = rule && rule[key];
      if (expr === undefined || expr === null) continue;
      if (typeof expr !== 'string' || expr.trim().length === 0) throw new Error('RLS_EXPR_INVALID');
      // Validate pure single read-only SQL expression using SQLite's own parser in mode:'readonly'
      db.validateExpr(table, sqlOp, expr);
      const triggerSql =
        'CREATE TRIGGER "' + trigName + '" BEFORE ' + sqlOp + ' ON ' + qTable +
        " BEGIN SELECT CASE WHEN NOT (" + expr + ") THEN RAISE(ABORT, 'rls_denied:" + table + ":" + key + "') END; END";
      db.exec(triggerSql, [], { mode: 'admin' });
    }
  }
}

export function ensureTableOwners(db) {
  db.exec(
    'CREATE TABLE IF NOT EXISTS _rls_table_owners (name TEXT PRIMARY KEY NOT NULL, owner TEXT NOT NULL)',
    [],
    { mode: 'admin' },
  );
}

export function getOwnedTables(db, owner) {
  ensureTableOwners(db);
  const res = db.query('SELECT name FROM _rls_table_owners WHERE owner = ? ORDER BY name', [owner]);
  return res.rows.map(r => r[0]);
}

export function recordTableOwners(db, createdTables, droppedTables, owner) {
  ensureTableOwners(db);
  for (const name of createdTables || []) {
    db.exec('INSERT OR REPLACE INTO _rls_table_owners (name, owner) VALUES (?, ?)', [name, owner], { mode: 'admin' });
  }
  for (const name of droppedTables || []) {
    db.exec('DELETE FROM _rls_table_owners WHERE name = ?', [name], { mode: 'admin' });
  }
}

/**
 * Install automatic row-version stamping triggers on tables that have '_last_op_id TEXT'
 * (and optional '_updated_at INTEGER') columns. Powers 1-line 'based_on_row' optimistic concurrency.
 */
export function stampRowOp(db, tables, options = {}) {
  const list = Array.isArray(tables) ? tables : [tables];
  const withUpdatedAt = options && options.updatedAt === true;
  for (const table of list) {
    const qTable = quoteIdent(table);
    const insName = '_rls_stamp_' + table + '_ins';
    const updName = '_rls_stamp_' + table + '_upd';
    db.exec('DROP TRIGGER IF EXISTS "' + insName + '"', [], { mode: 'admin' });
    db.exec('DROP TRIGGER IF EXISTS "' + updName + '"', [], { mode: 'admin' });
    const setClause = withUpdatedAt
      ? '_last_op_id = op_id(), _updated_at = op_time()'
      : '_last_op_id = op_id()';
    db.exec(
      'CREATE TRIGGER "' + insName + '" AFTER INSERT ON ' + qTable +
      ' WHEN NEW._last_op_id IS NOT op_id() BEGIN UPDATE ' + qTable +
      ' SET ' + setClause + ' WHERE rowid = NEW.rowid; END',
      [],
      { mode: 'admin' },
    );
    db.exec(
      'CREATE TRIGGER "' + updName + '" AFTER UPDATE ON ' + qTable +
      ' WHEN NEW._last_op_id IS NOT op_id() BEGIN UPDATE ' + qTable +
      ' SET ' + setClause + ' WHERE rowid = NEW.rowid; END',
      [],
      { mode: 'admin' },
    );
    db.exec(
      'UPDATE ' + qTable + ' SET ' + setClause + ' WHERE _last_op_id IS NULL',
      [],
      { mode: 'admin' },
    );
  }
}

export function ensureConflictsTable(db) {
  db.exec(
    'CREATE TABLE IF NOT EXISTS _chronolog_conflicts (' +
    'op_id TEXT PRIMARY KEY NOT NULL, ' +
    'author TEXT NOT NULL, ' +
    'author_time INTEGER NOT NULL, ' +
    'code TEXT NOT NULL, ' +
    'detail TEXT, ' +
    'payload_json TEXT NOT NULL, ' +
    'resolved INTEGER NOT NULL DEFAULT 0, ' +
    'resolution TEXT' +
    ')',
    [],
    { mode: 'admin' },
  );
}

export function recordConflict(db, tx, failure) {
  ensureConflictsTable(db);
  db.exec(
    'INSERT OR REPLACE INTO _chronolog_conflicts (op_id, author, author_time, code, detail, payload_json, resolved, resolution) VALUES (?, ?, ?, ?, ?, ?, 0, NULL)',
    [
      String(tx.opId),
      String(tx.author),
      Number(tx.authorTimestampMs || 0),
      String((failure && failure.code) || 'assumption:failed'),
      failure && failure.detail ? String(failure.detail) : null,
      JSON.stringify(tx.payload === undefined ? null : tx.payload),
    ],
    { mode: 'admin' },
  );
}

export function ensureAuditTable(db) {
  db.exec(
    'CREATE TABLE IF NOT EXISTS _chronolog_audit (' +
    'seq INTEGER PRIMARY KEY AUTOINCREMENT, ' +
    'table_name TEXT NOT NULL, ' +
    'row_rowid INTEGER NOT NULL, ' +
    'action TEXT NOT NULL, ' +
    'actor TEXT NOT NULL, ' +
    'op_id TEXT NOT NULL, ' +
    'op_time INTEGER NOT NULL, ' +
    'before_json TEXT, ' +
    'after_json TEXT' +
    ')',
    [],
    { mode: 'admin' },
  );
}

/**
 * Install deterministic AFTER INSERT/UPDATE/DELETE audit triggers on tables, recording
 * actor(), op_id(), op_time(), and JSON row snapshots into _chronolog_audit.
 */
export function enableAuditLog(db, tables) {
  ensureAuditTable(db);
  const list = Array.isArray(tables) ? tables : [tables];
  for (const table of list) {
    const qTable = quoteIdent(table);
    const info = db.query('SELECT * FROM ' + qTable + ' LIMIT 0', []);
    const cols = Array.isArray(info.columns) ? info.columns : [];
    const quoteCol = c => {
      if (typeof c !== 'string' || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(c)) {
        throw new Error('RLS_INVALID_COLUMN:' + String(c));
      }
      return '"' + c + '"';
    };
    const buildJsonObj = prefix => {
      if (cols.length === 0) return "'{}'";
      const pairs = cols.map(c => "'" + String(c).replace(/'/g, "''") + "', " + prefix + '.' + quoteCol(c));
      return 'json_object(' + pairs.join(', ') + ')';
    };
    const insTrig = '_rls_audit_' + table + '_ins';
    const updTrig = '_rls_audit_' + table + '_upd';
    const delTrig = '_rls_audit_' + table + '_del';
    db.exec('DROP TRIGGER IF EXISTS "' + insTrig + '"', [], { mode: 'admin' });
    db.exec('DROP TRIGGER IF EXISTS "' + updTrig + '"', [], { mode: 'admin' });
    db.exec('DROP TRIGGER IF EXISTS "' + delTrig + '"', [], { mode: 'admin' });
    db.exec(
      'CREATE TRIGGER "' + insTrig + '" AFTER INSERT ON ' + qTable +
      " BEGIN INSERT INTO _chronolog_audit (table_name, row_rowid, action, actor, op_id, op_time, before_json, after_json) VALUES ('" +
      table + "', NEW.rowid, 'insert', actor(), op_id(), op_time(), NULL, " + buildJsonObj('NEW') + '); END',
      [],
      { mode: 'admin' },
    );
    db.exec(
      'CREATE TRIGGER "' + updTrig + '" AFTER UPDATE ON ' + qTable +
      " BEGIN INSERT INTO _chronolog_audit (table_name, row_rowid, action, actor, op_id, op_time, before_json, after_json) VALUES ('" +
      table + "', NEW.rowid, 'update', actor(), op_id(), op_time(), " + buildJsonObj('OLD') + ', ' + buildJsonObj('NEW') + '); END',
      [],
      { mode: 'admin' },
    );
    db.exec(
      'CREATE TRIGGER "' + delTrig + '" AFTER DELETE ON ' + qTable +
      " BEGIN INSERT INTO _chronolog_audit (table_name, row_rowid, action, actor, op_id, op_time, before_json, after_json) VALUES ('" +
      table + "', OLD.rowid, 'delete', actor(), op_id(), op_time(), " + buildJsonObj('OLD') + ', NULL); END',
      [],
      { mode: 'admin' },
    );
  }
}

export function queryAuditHistory(db, options = {}) {
  const hasTable = db.query("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = '_chronolog_audit'", []);
  if (hasTable.rows.length === 0) return [];
  const limit = Number.isSafeInteger(options.limit) && options.limit > 0 ? Math.min(options.limit, 500) : 100;
  const where = [];
  const params = [];
  if (typeof options.table === 'string' && options.table.length > 0) {
    where.push('table_name = ?');
    params.push(options.table);
  }
  if (typeof options.opId === 'string' && options.opId.length > 0) {
    where.push('op_id = ?');
    params.push(options.opId);
  }
  const whereSql = where.length > 0 ? ' WHERE ' + where.join(' AND ') : '';
  params.push(limit);
  const res = db.query(
    'SELECT seq, table_name, row_rowid, action, actor, op_id, op_time, before_json, after_json FROM _chronolog_audit' +
    whereSql + ' ORDER BY seq DESC LIMIT ?',
    params,
  );
  return res.rows.map(r => ({
    seq: r[0],
    table: r[1],
    rowid: r[2],
    action: r[3],
    actor: r[4],
    opId: r[5],
    opTimeMs: r[6],
    before: r[7] ? JSON.parse(String(r[7])) : null,
    after: r[8] ? JSON.parse(String(r[8])) : null,
  }));
}
`.trimStart();
var STD_SQL_SOURCE = `
import { openDb } from 'chronolog:sqlite';
import { applyRls, enableAuditLog, ensureConflictsTable, getOwnedTables, queryAuditHistory, recordConflict, recordTableOwners, stampRowOp } from 'chronolog/rls';

function extractTouchedTables(sql) {
  const out = [];
  const re = /(?:INSERT\\s+(?:OR\\s+\\w+\\s+)?INTO|UPDATE\\s+(?:OR\\s+\\w+\\s+)?|DELETE\\s+FROM|CREATE\\s+(?:VIRTUAL\\s+)?TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?|ALTER\\s+TABLE|DROP\\s+TABLE\\s+(?:IF\\s+EXISTS\\s+)?)\\s+["']?([A-Za-z_][A-Za-z0-9_]*)["']?/gi;
  let m;
  while ((m = re.exec(String(sql))) !== null) {
    if (m[1] && !out.includes(m[1])) out.push(m[1]);
  }
  return out;
}

function hasCapability(ctx, capability, actor, extra) {
  const queryInput = extra ? { check: capability, actor, ...extra } : { check: capability, actor };
  const checked = ctx.query('$permissions', queryInput);
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  const m = perms.members.find(x => x.publicKey === actor);
  if (!m) return false;
  if (capability === 'administrator') return m.administrator === true;
  if (capability === 'writer') return m.writer === true || m.administrator === true;
  if (capability === 'reader') return m.reader === true;
  return false;
}

function normalizeSqlState(state, config) {
  const cfg = config && typeof config === 'object' ? config : {};
  const s = state && typeof state === 'object' ? state : {};
  return {
    dbRoot: typeof s.dbRoot === 'string' ? s.dbRoot : null,
    schemaVersion: Number.isSafeInteger(s.schemaVersion) ? s.schemaVersion : 0,
    policies: s.policies && typeof s.policies === 'object' && !Array.isArray(s.policies) ? { ...s.policies } : {},
    allowUserDdl: s.allowUserDdl !== undefined ? Boolean(s.allowUserDdl) : cfg.allowUserDdl !== false,
  };
}

function normalizeStatement(stmt) {
  if (typeof stmt === 'string') return { sql: stmt, params: [] };
  if (stmt && typeof stmt === 'object' && typeof stmt.sql === 'string') {
    return { sql: stmt.sql, params: Array.isArray(stmt.params) ? stmt.params : [] };
  }
  return null;
}

function quoteSqlIdent(name) {
  if (typeof name !== 'string' || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(name)) {
    throw new Error('SQL_INVALID_IDENTIFIER:' + String(name));
  }
  return '"' + name + '"';
}

function buildWhereClause(whereObj) {
  if (!whereObj || typeof whereObj !== 'object' || Array.isArray(whereObj)) {
    throw new Error('PRECONDITION_WHERE_INVALID');
  }
  const keys = Object.keys(whereObj).sort();
  if (keys.length === 0) throw new Error('PRECONDITION_WHERE_EMPTY');
  const clauses = [];
  const params = [];
  for (const k of keys) {
    const val = whereObj[k];
    if (val === null) {
      clauses.push(quoteSqlIdent(k) + ' IS NULL');
    } else {
      clauses.push(quoteSqlIdent(k) + ' = ?');
      params.push(val);
    }
  }
  return { clause: clauses.join(' AND '), params };
}

function checkPreconditions(db, preconditions) {
  if (!Array.isArray(preconditions)) return { ok: true };
  for (let i = 0; i < preconditions.length; i++) {
    const pre = preconditions[i];
    if (!pre || typeof pre !== 'object') {
      return { ok: false, code: 'sql:invalid_precondition', detail: 'Precondition ' + i + ' invalid' };
    }
    const failCode = typeof pre.code === 'string' && pre.code.length > 0 ? pre.code : 'sql:precondition_failed';

    if (pre.kind === 'based_on_row') {
      try {
        const qTable = quoteSqlIdent(pre.table);
        const { clause, params } = buildWhereClause(pre.where);
        const res = db.query('SELECT _last_op_id FROM ' + qTable + ' WHERE ' + clause, params);
        if (pre.lastOpId === null) {
          if (res.rows.length > 0) {
            return { ok: false, code: failCode === 'sql:precondition_failed' ? 'sql:row_already_exists' : failCode, detail: 'Expected row to not exist in ' + pre.table };
          }
          continue;
        }
        if (res.rows.length !== 1) {
          return { ok: false, code: failCode === 'sql:precondition_failed' ? 'sql:row_missing' : failCode, detail: 'Expected 1 row in ' + pre.table + ', got ' + res.rows.length };
        }
        if (res.rows[0][0] !== pre.lastOpId) {
          return { ok: false, code: failCode === 'sql:precondition_failed' ? 'sql:row_modified' : failCode, detail: 'Row in ' + pre.table + ' modified (expected op ' + pre.lastOpId + ', got ' + String(res.rows[0][0]) + ')' };
        }
        continue;
      } catch (err) {
        return { ok: false, code: failCode, detail: String(err && err.message ? err.message : err) };
      }
    }

    if (pre.kind === 'row_matches') {
      try {
        const qTable = quoteSqlIdent(pre.table);
        const { clause, params } = buildWhereClause(pre.where);
        const expectObj = pre.expect && typeof pre.expect === 'object' && !Array.isArray(pre.expect) ? pre.expect : null;
        if (!expectObj) return { ok: false, code: 'sql:invalid_precondition', detail: 'row_matches requires expect object' };
        const cols = Object.keys(expectObj).sort();
        if (cols.length === 0) return { ok: false, code: 'sql:invalid_precondition', detail: 'row_matches expect empty' };
        const sel = cols.map(quoteSqlIdent).join(', ');
        const res = db.query('SELECT ' + sel + ' FROM ' + qTable + ' WHERE ' + clause, params);
        if (res.rows.length !== 1) {
          return { ok: false, code: failCode, detail: 'Expected 1 matching row in ' + pre.table + ', got ' + res.rows.length };
        }
        for (let c = 0; c < cols.length; c++) {
          const actual = res.rows[0][c];
          const expected = expectObj[cols[c]];
          if (JSON.stringify(actual) !== JSON.stringify(expected)) {
            return { ok: false, code: failCode, detail: 'Column ' + cols[c] + ' expected ' + JSON.stringify(expected) + ', got ' + JSON.stringify(actual) };
          }
        }
        continue;
      } catch (err) {
        return { ok: false, code: failCode, detail: String(err && err.message ? err.message : err) };
      }
    }

    if (typeof pre.sql !== 'string') {
      return { ok: false, code: 'sql:invalid_precondition', detail: 'Precondition ' + i + ' missing sql' };
    }
    let res;
    try {
      res = db.query(pre.sql, Array.isArray(pre.params) ? pre.params : []);
    } catch (err) {
      return { ok: false, code: failCode, detail: String(err && err.message ? err.message : err) };
    }
    const exp = pre.expect;
    if (exp === undefined || exp === null) {
      const ok = res.rows.length > 0 && Boolean(res.rows[0][0]);
      if (!ok) return { ok: false, code: failCode, detail: 'Precondition ' + i + ' evaluated falsy' };
      continue;
    }
    if (typeof exp !== 'object') {
      return { ok: false, code: 'sql:invalid_precondition', detail: 'Precondition ' + i + ' expect must be an object' };
    }
    if (exp.exists !== undefined) {
      const hasRows = res.rows.length > 0;
      if (hasRows !== Boolean(exp.exists)) {
        return { ok: false, code: failCode, detail: 'Expected exists=' + Boolean(exp.exists) + ', got ' + hasRows };
      }
    }
    if (exp.rowCount !== undefined && res.rows.length !== exp.rowCount) {
      return { ok: false, code: failCode, detail: 'Expected rowCount ' + exp.rowCount + ', got ' + res.rows.length };
    }
    if (exp.minRows !== undefined && res.rows.length < exp.minRows) {
      return { ok: false, code: failCode, detail: 'Expected minRows ' + exp.minRows + ', got ' + res.rows.length };
    }
    if (exp.maxRows !== undefined && res.rows.length > exp.maxRows) {
      return { ok: false, code: failCode, detail: 'Expected maxRows ' + exp.maxRows + ', got ' + res.rows.length };
    }
    if (exp.firstValue !== undefined) {
      const actual = res.rows.length > 0 ? res.rows[0][0] : undefined;
      if (JSON.stringify(actual) !== JSON.stringify(exp.firstValue)) {
        return { ok: false, code: failCode, detail: 'Expected firstValue ' + JSON.stringify(exp.firstValue) + ', got ' + JSON.stringify(actual) };
      }
    }
    if (exp.equals !== undefined) {
      if (JSON.stringify(res.rows) !== JSON.stringify(exp.equals)) {
        return { ok: false, code: failCode, detail: 'Precondition ' + i + ' rows mismatch' };
      }
    }
  }
  return { ok: true };
}

function extractSqlErrorCode(err) {
  const msg = String(err && err.message ? err.message : err);
  const rls = /rls_denied:[A-Za-z0-9_]+:(?:insert|update|delete)/.exec(msg);
  if (rls) return rls[0];
  if (/not authorized|AUTHORIZER/i.test(msg)) return 'sql:not_authorized';
  if (/UNIQUE constraint|PRIMARY KEY/i.test(msg)) return 'sql:constraint_unique';
  if (/FOREIGN KEY constraint/i.test(msg)) return 'sql:constraint_fk';
  if (/CHECK constraint/i.test(msg)) return 'sql:constraint_check';
  if (/NOT NULL constraint/i.test(msg)) return 'sql:constraint_not_null';
  return 'sql:error';
}

function normalizeEvents(events) {
  if (!Array.isArray(events)) return [];
  const out = [];
  for (const ev of events) {
    if (ev && typeof ev === 'object' && typeof ev.topic === 'string' && ev.topic.length > 0) {
      out.push({ topic: ev.topic, payload: ev.payload === undefined ? null : ev.payload });
    }
  }
  return out;
}

function rowsToObjects(res) {
  return res.rows.map(row => {
    const obj = {};
    for (let i = 0; i < res.columns.length; i++) obj[res.columns[i]] = row[i];
    return obj;
  });
}

function mergeRlsPolicies(existing, incoming) {
  const next = { ...existing };
  const toApply = {};
  for (const [table, rule] of Object.entries(incoming)) {
    if (rule === null) {
      delete next[table];
      toApply[table] = { insert: null, update: null, delete: null };
      continue;
    }
    if (!rule || typeof rule !== 'object' || Array.isArray(rule)) {
      throw new Error('RLS_POLICIES_INVALID');
    }
    const merged = { ...(existing[table] || {}), ...rule };
    const clean = {};
    for (const op of ['insert', 'update', 'delete']) {
      if (merged[op] !== undefined && merged[op] !== null) clean[op] = merged[op];
    }
    if (Object.keys(clean).length === 0) delete next[table];
    else next[table] = clean;
    toApply[table] = {
      insert: merged.insert ?? null,
      update: merged.update ?? null,
      delete: merged.delete ?? null,
    };
  }
  return { nextPolicies: next, toApply };
}

/**
 * First-class deterministic Merkle-paged SQLite topic reducer.
 * - Declarative SQL transactions with atomic preconditions, postconditions, and automatic rollback on failure
 * - Postgres-style write RLS policies (chronolog/rls) + host-bound actor()/op_id()/op_time()
 * - Admin DDL (mode:'admin') and non-admin user-owned dynamic table & view DDL (mode:'user')
 * - Multiple topics in one chain can each bind chronolog/sql for independent hash-addressed databases
 */
export const sqlDatabase = {
  reduce(state, tx, ctx) {
    const cur = normalizeSqlState(state, ctx.config);
    const input = tx.payload;
    if (!input || typeof input !== 'object' || Array.isArray(input)) {
      return { ok: false, code: 'invalid_input' };
    }

    const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
    const allowPublicWrite = cfg.allowPublicWrite === true;
    const atMs = Number(tx.authorTimestampMs || 0);
    const isAdmin = hasCapability(ctx, 'administrator', tx.author, { atMs });
    const isWriter = allowPublicWrite || isAdmin || hasCapability(ctx, 'writer', tx.author, { atMs });
    const action = typeof input.action === 'string' ? input.action : 'exec';

    if (action === 'setConfig') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const next = {
        ...cur,
        ...(input.allowUserDdl === undefined ? {} : { allowUserDdl: Boolean(input.allowUserDdl) }),
      };
      return { ok: true, state: next, events: normalizeEvents(input.events) };
    }

    if (action === 'setRls' || action === 'setPolicies') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      if (!input.policies || typeof input.policies !== 'object' || Array.isArray(input.policies)) {
        return { ok: false, code: 'rls:invalid_policies' };
      }
      const db = openDb(cur.dbRoot);
      try {
        const { nextPolicies, toApply } = mergeRlsPolicies(cur.policies, input.policies);
        applyRls(db, toApply);
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { ...cur, dbRoot, policies: nextPolicies },
          events: normalizeEvents(input.events).concat([{ topic: 'sql.rls_updated', payload: { tables: Object.keys(input.policies) } }]),
        };
      } catch (err) {
        return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
      } finally {
        db.close();
      }
    }

    if (action === 'migrate') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const statements = Array.isArray(input.statements) ? input.statements : [];
      const db = openDb(cur.dbRoot);
      try {
        const preCheck = checkPreconditions(db, input.preconditions);
        if (!preCheck.ok) {
          if (input.onPreconditionFailed === 'record_conflict') {
            recordConflict(db, tx, preCheck);
            const dbRoot = db.commit();
            return {
              ok: true,
              state: { ...cur, dbRoot },
              events: [{ topic: 'sql.conflict_recorded', payload: { opId: tx.opId, code: preCheck.code, detail: preCheck.detail || null } }],
            };
          }
          return preCheck;
        }
        for (const rawStmt of statements) {
          const stmt = normalizeStatement(rawStmt);
          if (!stmt) return { ok: false, code: 'sql:invalid_statement' };
          db.exec(stmt.sql, stmt.params, { mode: 'admin' });
        }
        let nextPolicies = cur.policies;
        if (input.policies && typeof input.policies === 'object' && !Array.isArray(input.policies)) {
          const merged = mergeRlsPolicies(cur.policies, input.policies);
          applyRls(db, merged.toApply);
          nextPolicies = merged.nextPolicies;
        }
        if (Array.isArray(input.stampTables) && input.stampTables.length > 0) {
          stampRowOp(db, input.stampTables, { updatedAt: input.stampUpdatedAt === true });
        }
        if (Array.isArray(input.auditTables) && input.auditTables.length > 0) {
          enableAuditLog(db, input.auditTables);
        }
        const postCheck = checkPreconditions(db, input.postconditions);
        if (!postCheck.ok) return postCheck;
        const dbRoot = db.commit();
        const schemaVersion = Number.isSafeInteger(input.schemaVersion) ? input.schemaVersion : cur.schemaVersion + 1;
        const allowUserDdl = input.allowUserDdl === undefined ? cur.allowUserDdl : Boolean(input.allowUserDdl);
        return {
          ok: true,
          state: { ...cur, dbRoot, schemaVersion, policies: nextPolicies, allowUserDdl },
          events: normalizeEvents(input.events).concat([{ topic: 'sql.migrated', payload: { schemaVersion } }]),
        };
      } catch (err) {
        return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
      } finally {
        db.close();
      }
    }

    if (action === 'exec') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      if (!isAdmin && typeof input.requiredScope === 'string' && input.requiredScope.length > 0) {
        if (!hasCapability(ctx, 'scope', tx.author, { scope: input.requiredScope, atMs })) {
          return { ok: false, code: 'scope_required', detail: input.requiredScope };
        }
      }
      const mode = input.mode === 'admin' ? 'admin' : 'user';
      if (mode === 'admin' && !isAdmin) return { ok: false, code: 'admin_required' };
      const statements = Array.isArray(input.statements)
        ? input.statements
        : typeof input.sql === 'string'
          ? [{ sql: input.sql, params: Array.isArray(input.params) ? input.params : [] }]
          : null;
      if (!statements || (statements.length === 0 && !Array.isArray(input.preconditions))) {
        return { ok: false, code: 'sql:statements_required' };
      }

      const db = openDb(cur.dbRoot);
      try {
        const preCheck = checkPreconditions(db, input.preconditions);
        if (!preCheck.ok) {
          if (input.onPreconditionFailed === 'record_conflict') {
            recordConflict(db, tx, preCheck);
            const dbRoot = db.commit();
            return {
              ok: true,
              state: { ...cur, dbRoot },
              events: [{ topic: 'sql.conflict_recorded', payload: { opId: tx.opId, code: preCheck.code, detail: preCheck.detail || null } }],
            };
          }
          return preCheck;
        }

        let owned = mode === 'user' && cur.allowUserDdl ? getOwnedTables(db, tx.author) : null;
        const touchedSet = new Set();
        for (const rawStmt of statements) {
          const stmt = normalizeStatement(rawStmt);
          if (!stmt) return { ok: false, code: 'sql:invalid_statement' };
          for (const tbl of extractTouchedTables(stmt.sql)) touchedSet.add(tbl);
          const execOpts = mode === 'admin'
            ? { mode: 'admin' }
            : cur.allowUserDdl
              ? {
                  mode: 'user',
                  ddl: {
                    createTable: true,
                    alterTable: owned,
                    dropTable: owned,
                    indexOn: owned,
                    createView: true,
                    dropView: owned,
                  },
                }
              : { mode: 'user' };
          const res = db.exec(stmt.sql, stmt.params, execOpts);
          const created = (res.createdTables || []).concat(res.createdViews || []);
          const dropped = (res.droppedTables || []).concat(res.droppedViews || []);
          for (const tbl of created) touchedSet.add(tbl);
          for (const tbl of dropped) touchedSet.add(tbl);
          if (mode === 'user' && cur.allowUserDdl && (created.length > 0 || dropped.length > 0)) {
            recordTableOwners(db, created, dropped, tx.author);
            owned = getOwnedTables(db, tx.author);
          }
        }

        const postCheck = checkPreconditions(db, input.postconditions);
        if (!postCheck.ok) return postCheck;

        const dbRoot = db.commit();
        const touchedTables = Array.from(touchedSet).sort();
        const baseEvents = normalizeEvents(input.events);
        const events = touchedTables.length > 0
          ? baseEvents.concat([{ topic: 'sql.tables_changed', payload: { tables: touchedTables, dbRoot } }])
          : baseEvents;
        return {
          ok: true,
          state: { ...cur, dbRoot },
          events,
        };
      } catch (err) {
        return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
      } finally {
        db.close();
      }
    }

    if (action === 'resolveConflict') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      if (typeof input.opId !== 'string' || input.opId.length === 0) return { ok: false, code: 'sql:invalid_conflict_id' };
      const db = openDb(cur.dbRoot);
      try {
        ensureConflictsTable(db);
        const existing = db.query('SELECT author FROM _chronolog_conflicts WHERE op_id = ?', [input.opId]);
        if (existing.rows.length === 0) return { ok: false, code: 'sql:conflict_not_found' };
        if (!isAdmin && existing.rows[0][0] !== tx.author) return { ok: false, code: 'conflict_owner_or_admin_required' };
        db.exec(
          'UPDATE _chronolog_conflicts SET resolved = 1, resolution = ? WHERE op_id = ?',
          [typeof input.resolution === 'string' ? input.resolution : 'resolved', input.opId],
          { mode: 'admin' },
        );
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { ...cur, dbRoot },
          events: normalizeEvents(input.events).concat([{ topic: 'sql.conflict_resolved', payload: { opId: input.opId } }]),
        };
      } catch (err) {
        return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
      } finally {
        db.close();
      }
    }

    return { ok: false, code: 'unknown_action' };
  },

  onConflict(state, tx, ctx, failure) {
    const cur = normalizeSqlState(state, ctx.config);
    const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
    const allowPublicWrite = cfg.allowPublicWrite === true;
    const isAdmin = hasCapability(ctx, 'administrator', tx.author);
    const isWriter = allowPublicWrite || isAdmin || hasCapability(ctx, 'writer', tx.author);
    if (!isWriter) return { ok: false, code: 'writer_required' };
    const db = openDb(cur.dbRoot);
    try {
      recordConflict(db, tx, failure);
      const dbRoot = db.commit();
      return {
        ok: true,
        state: { ...cur, dbRoot },
        events: [{ topic: 'sql.conflict_recorded', payload: { opId: tx.opId, code: (failure && failure.code) || 'assumption:failed', detail: (failure && failure.detail) || null } }],
      };
    } catch (err) {
      return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
    } finally {
      db.close();
    }
  },

  query(state, input, ctx) {
    const cur = normalizeSqlState(state, ctx.config);
    if (input === null || input === undefined) {
      return {
        dbRoot: cur.dbRoot,
        schemaVersion: cur.schemaVersion,
        policies: cur.policies,
        allowUserDdl: cur.allowUserDdl,
      };
    }
    const kind = typeof input === 'object' ? (input.query || input.kind || input.action) : null;
    if (typeof input === 'object' && typeof input.sql === 'string') {
      const db = openDb(cur.dbRoot);
      try {
        const res = db.query(input.sql, Array.isArray(input.params) ? input.params : []);
        return input.format === 'objects'
          ? { columns: res.columns, rows: rowsToObjects(res) }
          : res;
      } finally {
        db.close();
      }
    }
    if (kind === 'audit') {
      const db = openDb(cur.dbRoot);
      try {
        return { dbRoot: cur.dbRoot, audit: queryAuditHistory(db, input || {}) };
      } finally {
        db.close();
      }
    }
    if (kind === 'conflicts') {
      const db = openDb(cur.dbRoot);
      try {
        const hasTable = db.query("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = '_chronolog_conflicts'", []);
        if (hasTable.rows.length === 0) return { dbRoot: cur.dbRoot, conflicts: [] };
        const unresolvedOnly = input && input.unresolvedOnly !== false;
        const sql = unresolvedOnly
          ? 'SELECT op_id, author, author_time, code, detail, payload_json, resolved, resolution FROM _chronolog_conflicts WHERE resolved = 0 ORDER BY author_time DESC'
          : 'SELECT op_id, author, author_time, code, detail, payload_json, resolved, resolution FROM _chronolog_conflicts ORDER BY author_time DESC';
        const res = db.query(sql, []);
        return {
          dbRoot: cur.dbRoot,
          conflicts: res.rows.map(r => ({
            opId: r[0],
            author: r[1],
            authorTimeMs: r[2],
            code: r[3],
            detail: r[4],
            payload: JSON.parse(String(r[5] || 'null')),
            resolved: Boolean(r[6]),
            resolution: r[7],
          })),
        };
      } finally {
        db.close();
      }
    }
    if (kind === 'tables') {
      const db = openDb(cur.dbRoot);
      try {
        const res = db.query("SELECT name, type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_rls_%' ORDER BY name", []);
        return { dbRoot: cur.dbRoot, tables: res.rows.map(r => ({ name: r[0], type: r[1] })) };
      } finally {
        db.close();
      }
    }
    if (kind === 'schema') {
      const db = openDb(cur.dbRoot);
      try {
        const res = db.query("SELECT type, name, tbl_name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name", []);
        const objects = res.rows.map(r => ({ type: r[0], name: r[1], table: r[2], sql: r[3] }));
        const owners = {};
        const hasOwners = objects.some(o => o.type === 'table' && o.name === '_rls_table_owners');
        if (hasOwners) {
          const ownRes = db.query('SELECT name, owner FROM _rls_table_owners ORDER BY name', []);
          for (const row of ownRes.rows) owners[String(row[0])] = String(row[1]);
        }
        const tables = [];
        for (const obj of objects) {
          if ((obj.type !== 'table' && obj.type !== 'view') || String(obj.name).startsWith('_rls_')) continue;
          const quoted = '"' + String(obj.name).replace(/"/g, '""') + '"';
          let columns = [];
          try {
            const info = db.query('SELECT * FROM ' + quoted + ' LIMIT 0', []);
            columns = Array.isArray(info.columns) ? info.columns.slice() : [];
          } catch {}
          tables.push({
            name: obj.name,
            type: obj.type,
            owner: Object.prototype.hasOwnProperty.call(owners, obj.name) ? owners[obj.name] : null,
            columns,
            rls: Object.prototype.hasOwnProperty.call(cur.policies, obj.name) ? cur.policies[obj.name] : null,
          });
        }
        return {
          dbRoot: cur.dbRoot,
          schemaVersion: cur.schemaVersion,
          policies: cur.policies,
          allowUserDdl: cur.allowUserDdl,
          userOwnedObjects: owners,
          tables,
          objects,
        };
      } finally {
        db.close();
      }
    }
    return {
      dbRoot: cur.dbRoot,
      schemaVersion: cur.schemaVersion,
      policies: cur.policies,
      allowUserDdl: cur.allowUserDdl,
    };
  },

  describe() {
    const scalarParam = {
      anyOf: [{ type: 'string' }, { type: 'number' }, { type: 'boolean' }, { type: 'null' }],
    };
    const statementSchema = {
      anyOf: [
        { type: 'string' },
        {
          type: 'object',
          properties: {
            sql: { type: 'string' },
            params: { type: 'array', items: scalarParam },
          },
          required: ['sql'],
        },
      ],
    };
    return {
      commands: [
        {
          name: 'exec',
          description: 'Execute a deterministic SQL transaction with optional atomic preconditions under write RLS.',
          input: {
            type: 'object',
            properties: {
              mode: { type: 'string', enum: ['user', 'admin'] },
              preconditions: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    sql: { type: 'string' },
                    params: { type: 'array', items: scalarParam },
                    code: { type: 'string' },
                  },
                  required: ['sql'],
                },
              },
              postconditions: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    sql: { type: 'string' },
                    params: { type: 'array', items: scalarParam },
                    code: { type: 'string' },
                  },
                  required: ['sql'],
                },
              },
              statements: { type: 'array', items: statementSchema },
              events: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: { topic: { type: 'string' } },
                  required: ['topic'],
                },
              },
            },
          },
        },
        {
          name: 'migrate',
          description: 'Run administrator DDL migrations and optionally install write RLS policies atomically.',
          input: {
            type: 'object',
            properties: {
              statements: { type: 'array', items: statementSchema },
              schemaVersion: { type: 'integer' },
              allowUserDdl: { type: 'boolean' },
            },
          },
        },
        {
          name: 'setRls',
          description: 'Install or update Postgres-style write RLS policies (administrator only).',
          input: {
            type: 'object',
            properties: {
              policies: { type: 'object', properties: {} },
            },
            required: ['policies'],
          },
        },
        {
          name: 'setConfig',
          description: 'Update SQL topic configuration such as allowUserDdl (administrator only).',
          input: {
            type: 'object',
            properties: {
              allowUserDdl: { type: 'boolean' },
            },
          },
        },
      ],
      queries: [
        {
          name: 'sql',
          description: 'Execute a read-only SQL query against the deterministic SQLite-CAS state.',
          input: {
            type: 'object',
            properties: {
              sql: { type: 'string' },
              params: { type: 'array', items: scalarParam },
              format: { type: 'string', enum: ['rows', 'objects'] },
            },
            required: ['sql'],
          },
        },
        {
          name: 'tables',
          description: 'List user tables and views in this SQLite-CAS database.',
          input: { type: 'object', properties: {} },
        },
        {
          name: 'schema',
          description: 'Inspect schema objects, dbRoot, and active write RLS policies.',
          input: { type: 'object', properties: {} },
        },
      ],
    };
  },
};

export default sqlDatabase;
`.trimStart();
var STD_SQLITE_HELPERS_SOURCE = `
import { openDb } from 'chronolog:sqlite';
import { applyRls } from 'chronolog/rls';

export function rowsToObjects(res) {
  return (res.rows || []).map(row => {
    const obj = {};
    for (let i = 0; i < res.columns.length; i++) obj[res.columns[i]] = row[i];
    return obj;
  });
}

/**
 * Open a deterministic chronolog:sqlite database, invoke fn(db), auto-close in finally,
 * and optionally commit when mutate === true.
 */
export function withDb(dbRoot, fn, options) {
  const db = openDb(dbRoot ?? null);
  try {
    const value = fn(db);
    if (options && options.commit === true) {
      return { value, dbRoot: db.commit() };
    }
    return value;
  } finally {
    db.close();
  }
}

/**
 * Build a concise, self-describing chronolog:sqlite ES Module reducer with automatic
 * schema/tables/read-only SQL query introspection, permission checks, and write RLS.
 */
export function defineSqlReducer(spec) {
  const commands = (spec && spec.commands) || {};
  const queries = (spec && spec.queries) || {};
  const setup = typeof (spec && spec.setup) === 'function' ? spec.setup : null;
  const policies = (spec && spec.policies) || null;
  const allowPublicWrite = Boolean(spec && spec.allowPublicWrite);

  function checkCap(ctx, cap, actor) {
    const checked = ctx.query('$permissions', { check: cap, actor });
    if (typeof checked === 'boolean') return checked;
    const perms = ctx.topic('$permissions');
    if (!perms || !Array.isArray(perms.members)) return false;
    const m = perms.members.find(x => x.publicKey === actor);
    if (!m) return false;
    if (cap === 'administrator') return m.administrator === true;
    if (cap === 'writer') return m.writer === true || m.administrator === true;
    return m.reader === true;
  }

  return {
    reduce(state, tx, ctx) {
      const cur = state && typeof state === 'object' ? state : { dbRoot: null, initialized: false };
      const input = tx.payload;
      if (!input || typeof input !== 'object' || Array.isArray(input)) {
        return { ok: false, code: 'invalid_input' };
      }
      const action = typeof input.action === 'string' ? input.action : null;
      const handler = action && Object.prototype.hasOwnProperty.call(commands, action) ? commands[action] : null;
      if (!handler) return { ok: false, code: 'unknown_action' };
      const reqAdmin = Boolean(handler.adminOnly);
      if (reqAdmin) {
        if (!checkCap(ctx, 'administrator', tx.author)) return { ok: false, code: 'admin_required' };
      } else if (!allowPublicWrite && !checkCap(ctx, 'writer', tx.author)) {
        return { ok: false, code: 'writer_required' };
      }
      const db = openDb(cur.dbRoot ?? null);
      try {
        if (!cur.initialized) {
          if (setup) setup(db);
          if (policies) applyRls(db, policies);
        }
        const run = typeof handler === 'function' ? handler : handler.run;
        const out = run(db, input, tx, ctx);
        if (out && out.ok === false) return out;
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { ...cur, dbRoot, initialized: true },
          ...(out && Array.isArray(out.events) ? { events: out.events } : {}),
        };
      } catch (err) {
        const msg = String(err && err.message ? err.message : err);
        const rls = /rls_denied:[A-Za-z0-9_]+:(?:insert|update|delete)/.exec(msg);
        return { ok: false, code: rls ? rls[0] : 'sql:error', detail: msg };
      } finally {
        db.close();
      }
    },
    query(state, input, ctx) {
      const cur = state && typeof state === 'object' ? state : { dbRoot: null, initialized: false };
      const qObj = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
      const qName = typeof qObj.query === 'string' ? qObj.query : (typeof qObj.kind === 'string' ? qObj.kind : null);
      if (qName && Object.prototype.hasOwnProperty.call(queries, qName)) {
        const qHandler = queries[qName];
        const run = typeof qHandler === 'function' ? qHandler : qHandler.run;
        return withDb(cur.dbRoot, db => run(db, qObj, ctx));
      }
      if (typeof qObj.sql === 'string') {
        return withDb(cur.dbRoot, db => {
          const res = db.query(qObj.sql, Array.isArray(qObj.params) ? qObj.params : []);
          return qObj.format === 'objects' ? { columns: res.columns, rows: rowsToObjects(res) } : res;
        });
      }
      if (qName === 'tables') {
        return withDb(cur.dbRoot, db => {
          const res = db.query("SELECT name, type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_rls_%' ORDER BY name", []);
          return { dbRoot: cur.dbRoot, tables: res.rows.map(r => ({ name: r[0], type: r[1] })) };
        });
      }
      if (qName === 'schema') {
        return withDb(cur.dbRoot, db => {
          const res = db.query("SELECT type, name, tbl_name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name", []);
          const objects = res.rows.map(r => ({ type: r[0], name: r[1], table: r[2], sql: r[3] }));
          const tables = [];
          for (const obj of objects) {
            if ((obj.type !== 'table' && obj.type !== 'view') || String(obj.name).startsWith('_rls_')) continue;
            let columns = [];
            try {
              const info = db.query('SELECT * FROM "' + String(obj.name).replace(/"/g, '""') + '" LIMIT 0', []);
              columns = Array.isArray(info.columns) ? info.columns.slice() : [];
            } catch {}
            tables.push({ name: obj.name, type: obj.type, owner: null, columns, rls: policies && policies[obj.name] ? policies[obj.name] : null });
          }
          return { dbRoot: cur.dbRoot, schemaVersion: 1, policies: policies || {}, allowUserDdl: false, userOwnedObjects: {}, tables, objects };
        });
      }
      return { dbRoot: cur.dbRoot, initialized: Boolean(cur.initialized) };
    },
    describe() {
      return {
        commands: Object.entries(commands).map(([name, entry]) => ({
          name,
          description: (entry && entry.description) || '',
          input: (entry && entry.input) || { type: 'object', properties: {} },
        })),
        queries: [
          ...Object.entries(queries).map(([name, entry]) => ({
            name,
            description: (entry && entry.description) || '',
            input: (entry && entry.input) || { type: 'object', properties: {} },
          })),
          { name: 'schema', description: 'Inspect SQLite-CAS schema tables and RLS policies.', input: { type: 'object', properties: {} } },
          { name: 'tables', description: 'List user tables and views.', input: { type: 'object', properties: {} } },
        ],
      };
    },
  };
}
`.trimStart();
var STANDARD_MODULE_SOURCES = Object.freeze({
  "chronolog/permissions": STD_PERMISSIONS_SOURCE,
  "chronolog/keys": STD_KEYS_SOURCE,
  "chronolog/finality": STD_FINALITY_SOURCE,
  "chronolog/publications": STD_PUBLICATIONS_SOURCE,
  "chronolog/rls": STD_RLS_SOURCE,
  "chronolog/sql": STD_SQL_SOURCE,
  "chronolog/sqlite-helpers": STD_SQLITE_HELPERS_SOURCE,
  "chronolog/crdt": STD_CRDT_SOURCE,
  "chronolog/text": STD_TEXT_SOURCE,
  "chronolog/ledger": STD_LEDGER_SOURCE,
  "chronolog/workflow": STD_WORKFLOW_SOURCE,
  "chronolog/fs": STD_FS_SOURCE,
  "chronolog/mounts": STD_MOUNTS_SOURCE,
  "chronolog/builders": STD_BUILDERS_SOURCE,
  "chronolog/registry": STD_REGISTRY_SOURCE,
  "chronolog/finality-predicates": STD_FINALITY_PREDICATES_SOURCE,
  "chronolog/guards": STD_GUARDS_SOURCE,
  "chronolog/quotas": STD_QUOTAS_SOURCE,
  "chronolog/queue": STD_QUEUE_SOURCE,
  "chronolog/votes": STD_VOTES_SOURCE,
  "chronolog/schema": STD_SCHEMA_SOURCE,
  "chronolog/audit": STD_AUDIT_SOURCE
});
var STANDARD_MODULE_BUILTINS = Object.freeze({
  "chronolog/permissions": ["chronolog:crypto"],
  "chronolog/keys": ["chronolog:crypto"],
  "chronolog/finality": ["chronolog:crypto"],
  "chronolog/publications": ["chronolog:crypto"],
  "chronolog/rls": [],
  "chronolog/sql": ["chronolog:sqlite"],
  "chronolog/sqlite-helpers": ["chronolog:sqlite"],
  "chronolog/crdt": [],
  "chronolog/text": [],
  "chronolog/ledger": [],
  "chronolog/workflow": [],
  "chronolog/fs": ["chronolog:cas"],
  "chronolog/mounts": ["chronolog:crypto"],
  "chronolog/builders": ["chronolog:crypto"],
  "chronolog/registry": ["chronolog:sqlite", "chronolog:crypto"],
  "chronolog/finality-predicates": ["chronolog:crypto"],
  "chronolog/guards": [],
  "chronolog/quotas": [],
  "chronolog/queue": [],
  "chronolog/votes": [],
  "chronolog/schema": [],
  "chronolog/audit": ["chronolog:crypto"]
});
var STANDARD_MODULE_IMPORTS = Object.freeze(
  Object.fromEntries(
    Object.entries(STANDARD_MODULE_SOURCES).map(([spec, src]) => [spec, `cas:sha256-${computeCasHash(utf8(src))}`])
  )
);
async function seedStandardModules(cas) {
  const imports = {};
  for (const [spec, src] of Object.entries(STANDARD_MODULE_SOURCES)) {
    const hash = await cas.put(utf8(src), [], "public");
    imports[spec] = `cas:sha256-${hash}`;
  }
  return imports;
}
async function seedStandardPackages(cas) {
  const imports = {};
  for (const [spec, src] of Object.entries(STANDARD_MODULE_SOURCES)) {
    const pkg = await putPackageDag(cas, {
      name: spec,
      version: "1.0.0",
      runtime: "esm-quickjs",
      files: { "index.js": src },
      exports: { ".": "index.js" },
      builtins: STANDARD_MODULE_BUILTINS[spec] ?? []
    }, "public");
    imports[spec] = pkg.ref;
  }
  return imports;
}

export {
  STANDARD_MODULE_SOURCES,
  STANDARD_MODULE_IMPORTS,
  seedStandardModules,
  seedStandardPackages
};
