import {
  FactIdSet,
  createCasMirrorClient,
  reconcileRanges
} from "./chunk-JZVERRC5.mjs";
import {
  openSqlBranch
} from "./chunk-6QZAGTOJ.mjs";
import {
  TopicKernel,
  createBytesStoreDerivationMemo,
  decodeMaterializedCache,
  encodeMaterializedCache,
  evaluateDerivation
} from "./chunk-IHG3HSGG.mjs";
import {
  claimApplicationDevice,
  epochKeyCommitmentV2,
  hpkeOpenEpochKey,
  hpkeSealEpochKey
} from "./chunk-SJBUGLEN.mjs";
import {
  STANDARD_MODULE_SOURCES
} from "./chunk-XVIRXFJR.mjs";
import {
  HPKE_SUITE,
  combineShares,
  decryptEpochPayload,
  encryptEpochPayload,
  generateX25519KeyPair,
  hpkeReceiveExportBase,
  hpkeSendExportBase,
  splitSecret
} from "./chunk-RFZQY6CX.mjs";
import {
  CONTENT_CHUNK_BYTES,
  MAX_BLOB_BYTES,
  MAX_BLOB_CHUNKS,
  MAX_CONTENT_BYTES,
  describeApplication,
  isPrivateContentReference,
  isPublicBlobReference,
  putContentBytes,
  readContentBytes
} from "./chunk-O7NXWMZY.mjs";
import {
  check,
  checkedApplicationInputSchema,
  computeIncludedSetDigest,
  decodeRecord,
  encodeRecord,
  equalRecord,
  parseFinalitySchedule,
  policyScopeId,
  recordDigest,
  signFinalityCheckpoint,
  signRecord,
  validateApplicationDescription,
  verifyFinalityV2,
  verifyRecord
} from "./chunk-3YYBTMHD.mjs";
import {
  awaitOwnedTask
} from "./chunk-KSC4KBWO.mjs";
import {
  ContentAddressedStore,
  blobDagIndex,
  casRef,
  computeBlobDagHash,
  computeCasHash,
  encodeEncBlobManifest,
  encodeTreeNode,
  parseCasRef,
  putBlobDag,
  putPackageDag,
  readBlobDag,
  statBlobDag,
  tryDecodePackageNode,
  tryParseCasRef,
  verifyBlobDagIndex,
  writeBytesMany
} from "./chunk-OWL5GQ66.mjs";
import {
  DOMAINS,
  assertValidReducersConfig,
  bytesToHex as bytesToHex2,
  canonicalJson,
  compareOperationOrder,
  decodeEncryptedEnvelope,
  decodeLogGenesis,
  decodeSignedOperation,
  decodeTrustedEncryptedEnvelope,
  decodeTrustedOperationCore,
  decodeTrustedSignedOperation,
  encodeEncryptedEnvelope,
  encodeLogGenesis,
  encodeSignedOperation,
  encryptedEnvelopeDigest,
  envelopeAad,
  genesisLogId,
  hexToBytes as hexToBytes2,
  isControlTopic,
  normalizeAssumptionsConfig,
  normalizeJsonValue,
  operationIdDigest,
  signDomain,
  signOperationCore,
  utf8 as utf82,
  verifyDomain,
  verifySignedOperation
} from "./chunk-XIVHZVOM.mjs";
import {
  DEFAULT_DECODE_LIMITS,
  assertCanonicalCbor,
  bytesToHex,
  concatBytes,
  decodeCanonicalCbor,
  encodeCanonicalCbor,
  equalBytes,
  hexToBytes,
  perfCount,
  perfTimeAsync,
  sha256,
  utf8
} from "./chunk-VRR2HFJY.mjs";

// packages/signals/src/payload.ts
function assertSignalTopic(topic) {
  if (typeof topic !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._/-]*$/u.test(topic) || topic.length > 128) throw new Error("SIGNAL_TOPIC_INVALID");
}
function canonicalSignalPayload(payload) {
  let nodes = 0;
  const visit = (value, depth) => {
    if (depth > 32 || ++nodes > 4096) throw new Error("SIGNAL_PAYLOAD_TOO_COMPLEX");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw new Error("SIGNAL_PAYLOAD_INVALID");
      return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
      if (Reflect.ownKeys(value).length !== value.length + 1) throw new Error("SIGNAL_PAYLOAD_INVALID");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, i);
        if (descriptor === void 0 || !("value" in descriptor) || !descriptor.enumerable) throw new Error("SIGNAL_PAYLOAD_INVALID");
        entries.push(visit(descriptor.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    if (typeof value !== "object" || value === null || Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null || Reflect.ownKeys(value).length !== Object.keys(value).length) throw new Error("SIGNAL_PAYLOAD_INVALID");
    return `{${Object.keys(value).sort().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!("value" in descriptor)) throw new Error("SIGNAL_PAYLOAD_INVALID");
      return `${JSON.stringify(key)}:${visit(descriptor.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const result = visit(payload, 0);
  if (new TextEncoder().encode(result).length > 16384) throw new Error("SIGNAL_FRAME_TOO_LARGE");
  return result;
}

// packages/signals/src/index.ts
var SIGNAL_DOMAIN = "chronolog/signal/v1";
var SIGNAL_STREAM_DOMAIN = "chronolog/signal/v2";
var MAX_SIGNAL_BYTES = 16384;
var SignalError = class extends Error {
  constructor(code, message = code) {
    super(message);
    this.code = code;
    this.name = "SignalError";
  }
  code;
};
var SignalChannel = class {
  #options;
  #authorId;
  #session = crypto.getRandomValues(new Uint8Array(32));
  #sessions = /* @__PURE__ */ new Map();
  #subscriptions = /* @__PURE__ */ new Set();
  #routes = /* @__PURE__ */ new Set();
  /** Detached callbacks retain their quota until the actual operation settles. */
  #retiring = /* @__PURE__ */ new Set();
  #lifetime = new AbortController();
  #ttl;
  #skew;
  #maxSessions;
  #maxSequences;
  #maxRemembered;
  #maxSends;
  #maxReceives;
  #maxRoutes;
  #maxSubscriptions;
  #maxQueuedSignals;
  #maxQueuedBytes;
  #maxRetainedLatest;
  #sendTimeout;
  #verifyKeys = /* @__PURE__ */ new Map();
  #retainedLatest = /* @__PURE__ */ new Map();
  #sequence = 0;
  #sendTail = Promise.resolve();
  #pendingSends = 0;
  #pendingReceives = 0;
  #remembered = 0;
  #observedTime = 0;
  #lastPruneAt = 0;
  constructor(options) {
    if (typeof options.scope !== "string" || options.scope.length === 0 || new TextEncoder().encode(options.scope).length > 256 || !(options.identity.publicKeyBytes instanceof Uint8Array) || options.identity.publicKeyBytes.length !== 32 || typeof options.authorize !== "function") throw new SignalError("SIGNAL_CONFIGURATION_INVALID");
    const credential = typeof options.credential === "function" ? options.credential : credentialBytes(options.credential);
    this.#options = {
      ...options,
      identity: { ...options.identity, publicKeyBytes: options.identity.publicKeyBytes.slice() },
      ...credential === void 0 ? {} : { credential }
    };
    this.#authorId = bytesToHex(options.identity.publicKeyBytes);
    this.#ttl = bound(options.maxTtlMs ?? 3e4, 1, 6e4);
    this.#skew = bound(options.maxClockSkewMs ?? 2e3, 0, 1e4);
    this.#maxSessions = bound(options.maxSessions ?? 1024, 1, 65536);
    this.#maxSequences = bound(options.maxSequencesPerSession ?? 1024, 1, 65536);
    this.#maxRemembered = bound(options.maxRememberedSignals ?? 8192, 1, 1048576);
    this.#maxSends = bound(options.maxPendingSends ?? 32, 1, 1024);
    this.#maxReceives = bound(options.maxPendingReceives ?? 32, 1, 1024);
    this.#maxRoutes = bound(options.maxRoutes ?? 64, 1, 1024);
    this.#maxSubscriptions = bound(options.maxSubscriptions ?? 16, 1, 1024);
    this.#maxQueuedSignals = bound(options.maxQueuedSignals ?? 64, 1, 4096);
    this.#maxQueuedBytes = bound(options.maxQueuedBytes ?? 262144, 1, 16777216);
    this.#maxRetainedLatest = bound(options.maxRetainedLatest ?? 128, 0, 4096);
    this.#sendTimeout = bound(options.sendTimeoutMs ?? 1e4, 1, 12e4);
    if (options.trySend !== void 0) this.attachRoute({ trySend: options.trySend });
  }
  get delivery() {
    return this.#options.relay === true ? "application" : "neighbors";
  }
  attachRoute(transport) {
    this.#assertOpen();
    if (typeof transport.trySend !== "function") throw new SignalError("SIGNAL_TRANSPORT_INVALID");
    if (this.#routes.size + this.#retiring.size >= this.#maxRoutes) throw new SignalError("SIGNAL_ROUTE_QUOTA_EXCEEDED");
    const route = {
      trySend: transport.trySend.bind(transport),
      lifetime: new AbortController(),
      busy: false,
      retired: false,
      rejections: { total: 0, clockSkew: 0, expired: 0, unauthorized: 0, duplicate: 0, capacity: 0 },
      ...transport.close === void 0 ? {} : { close: transport.close.bind(transport) }
    };
    this.#routes.add(route);
    return {
      receive: (frame) => this.#enqueueReceive(frame, route),
      close: () => this.#detach(route),
      get diagnostics() {
        return { ...route.rejections };
      }
    };
  }
  send(topic, payload, options = {}) {
    try {
      if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
      this.#assertOpen();
      options.signal?.throwIfAborted();
      if (this.#routes.size === 0 && this.#options.localEcho !== true) throw new SignalError("SIGNAL_ROUTE_UNAVAILABLE");
      const routes = [...this.#routes];
      if (this.#pendingSends >= this.#maxSends) throw new SignalError("SIGNAL_BACKPRESSURE");
      assertSignalTopic(topic);
      const encodedPayload = canonicalSignalPayload(payload);
      const stream = options.stream === void 0 ? void 0 : checkedStream(options.stream);
      const ttlMs = bound(options.ttlMs ?? Math.min(5e3, this.#ttl), 1, this.#ttl, "SIGNAL_TTL_INVALID");
      const issuedAtMs = this.#now(), expiresAtMs = issuedAtMs + ttlMs;
      if (!Number.isSafeInteger(expiresAtMs)) throw new SignalError("SIGNAL_CLOCK_INVALID");
      const expiry = new AbortController();
      const timer = setTimeout(() => expiry.abort(new SignalError("SIGNAL_SEND_TIMEOUT")), Math.min(ttlMs, this.#sendTimeout));
      const signal = AbortSignal.any([this.#lifetime.signal, expiry.signal, ...options.signal === void 0 ? [] : [options.signal]]);
      this.#pendingSends += 1;
      let started = false;
      const task = this.#sendTail.then(() => {
        signal.throwIfAborted();
        started = true;
        const operation = (async () => {
          const configured = this.#options.credential;
          const credential = credentialBytes(typeof configured === "function" ? await configured(topic, { signal }) : configured);
          const authorization = { scope: this.#options.scope, authorId: this.#options.identity.publicKeyBytes.slice(), topic, credential: credential ?? null, ...stream === void 0 ? {} : { stream } };
          await this.#authorize(authorization, signal);
          if (this.#sequence >= Number.MAX_SAFE_INTEGER) throw new SignalError("SIGNAL_SEQUENCE_EXHAUSTED");
          const sequence = ++this.#sequence;
          const fields2 = [
            stream === void 0 ? 1n : 2n,
            stream === void 0 ? SIGNAL_DOMAIN : SIGNAL_STREAM_DOMAIN,
            this.#options.scope,
            this.#options.identity.publicKeyBytes,
            credential ?? null,
            this.#session,
            BigInt(sequence),
            BigInt(issuedAtMs),
            BigInt(expiresAtMs),
            topic,
            encodedPayload,
            ...stream === void 0 ? [] : [JSON.stringify(stream)]
          ];
          const signature = new Uint8Array(await crypto.subtle.sign(
            "Ed25519",
            this.#options.identity.privateKey,
            encodeCanonicalCbor(fields2).slice().buffer
          ));
          const frame = encodeCanonicalCbor([...fields2, signature]);
          if (frame.length > MAX_SIGNAL_BYTES) throw new SignalError("SIGNAL_FRAME_TOO_LARGE");
          const value = {
            scope: this.#options.scope,
            authorId: this.#authorId,
            sessionId: bytesToHex(this.#session),
            sequence,
            topic,
            payload: JSON.parse(encodedPayload),
            issuedAtMs,
            expiresAtMs,
            ...stream === void 0 ? {} : { stream }
          };
          await this.#authorize(authorization, signal);
          this.#assertFresh(value);
          if (!this.#remember(value)) throw new SignalError("SIGNAL_BACKPRESSURE");
          const local = this.#options.localEcho === true;
          if (local) {
            this.#deliver(value, frame.length);
            if (routes.length > 0) void this.#dispatch({ value, authorization, frame }, routes, signal, false).catch(() => void 0);
          }
          if (!local && !await this.#dispatch({ value, authorization, frame }, routes, signal, true)) {
            this.#forget(value);
            throw new SignalError("SIGNAL_BACKPRESSURE");
          }
          return structuredClone(value);
        })().finally(() => {
          clearTimeout(timer);
          this.#pendingSends -= 1;
        });
        return interrupted(operation, signal);
      }).finally(() => {
        if (!started) {
          clearTimeout(timer);
          this.#pendingSends -= 1;
        }
      });
      this.#sendTail = task.catch(() => void 0);
      return interrupted(task, signal);
    } catch (error) {
      return Promise.reject(error);
    }
  }
  /** Standalone receive validates and delivers without inferring a relay source. */
  receive(frame) {
    return this.#enqueueReceive(frame);
  }
  #enqueueReceive(input, route) {
    try {
      this.#assertOpen();
      if (!(input instanceof Uint8Array) || input.byteLength > MAX_SIGNAL_BYTES) throw new SignalError("SIGNAL_FRAME_TOO_LARGE");
      if (route?.lifetime.signal.aborted === true) throw new SignalError("SIGNAL_ROUTE_CLOSED");
      if (this.#pendingReceives >= this.#maxReceives) return Promise.resolve(this.#reject(route, "capacity"));
      const frame = input.slice();
      const routes = [...this.#routes].filter((attached) => attached !== route);
      this.#pendingReceives += 1;
      const expiry = new AbortController();
      const timer = setTimeout(() => expiry.abort(new SignalError("SIGNAL_RECEIVE_TIMEOUT")), this.#ttl);
      const signal = AbortSignal.any([this.#lifetime.signal, expiry.signal, ...route === void 0 ? [] : [route.lifetime.signal]]);
      const operation = (async () => {
        signal.throwIfAborted();
        const verified = await this.#verify(frame, signal, route);
        if (verified === null || !this.#remember(verified.value, route)) return null;
        this.#deliver(verified.value, frame.length);
        if (this.#options.relay === true) await this.#dispatch(verified, routes, signal, false);
        return structuredClone(verified.value);
      })().finally(() => {
        clearTimeout(timer);
        this.#pendingReceives -= 1;
      });
      return interrupted(operation, signal);
    } catch (error) {
      return Promise.reject(error);
    }
  }
  async #verify(bytes, signal, route) {
    const frame = assertCanonicalCbor(bytes, {
      maxBytes: MAX_SIGNAL_BYTES,
      maxDepth: 2,
      maxArrayItems: 13,
      maxMapItems: 0,
      maxTextBytes: MAX_SIGNAL_BYTES,
      maxBlobBytes: 1024
    });
    if (!Array.isArray(frame) || !(frame.length === 12 && frame[0] === 1n && frame[1] === SIGNAL_DOMAIN || frame.length === 13 && frame[0] === 2n && frame[1] === SIGNAL_STREAM_DOMAIN) || frame[2] !== this.#options.scope || !(frame[3] instanceof Uint8Array) || frame[3].length !== 32 || frame[4] !== null && (!(frame[4] instanceof Uint8Array) || frame[4].length > 1024) || !(frame[5] instanceof Uint8Array) || frame[5].length !== 32 || typeof frame[6] !== "bigint" || typeof frame[7] !== "bigint" || typeof frame[8] !== "bigint" || typeof frame[9] !== "string" || typeof frame[10] !== "string" || !(frame[frame.length - 1] instanceof Uint8Array) || frame[frame.length - 1].length !== 64) throw new SignalError("SIGNAL_FRAME_INVALID");
    assertSignalTopic(frame[9]);
    const stream = frame.length === 13 ? decodeStream(frame[11]) : void 0;
    const payload = JSON.parse(frame[10]);
    if (canonicalSignalPayload(payload) !== frame[10]) throw new SignalError("SIGNAL_PAYLOAD_INVALID");
    const value = {
      scope: this.#options.scope,
      authorId: bytesToHex(frame[3]),
      sessionId: bytesToHex(frame[5]),
      sequence: Number(frame[6]),
      issuedAtMs: Number(frame[7]),
      expiresAtMs: Number(frame[8]),
      topic: frame[9],
      payload,
      ...stream === void 0 ? {} : { stream }
    };
    this.#assertClockFields(value);
    let key = this.#verifyKeys.get(value.authorId);
    if (key === void 0) {
      key = await crypto.subtle.importKey("raw", frame[3].slice().buffer, "Ed25519", false, ["verify"]);
      if (this.#verifyKeys.size >= 256) {
        const oldest = this.#verifyKeys.keys().next().value;
        if (oldest !== void 0) this.#verifyKeys.delete(oldest);
      }
      this.#verifyKeys.set(value.authorId, key);
    }
    if (!await crypto.subtle.verify("Ed25519", key, frame[frame.length - 1].slice().buffer, encodeCanonicalCbor(frame.slice(0, -1)).slice().buffer)) {
      throw new SignalError("SIGNAL_SIGNATURE_INVALID");
    }
    const credential = frame[4];
    const authorization = { scope: value.scope, authorId: frame[3].slice(), topic: value.topic, credential: credential?.slice() ?? null, ...stream === void 0 ? {} : { stream } };
    if (!await this.#allowed(authorization, signal)) return this.#reject(route, "unauthorized");
    const now = this.#now();
    if (value.issuedAtMs > now + this.#skew) return this.#reject(route, "clockSkew");
    if (value.expiresAtMs <= now) return this.#reject(route, "expired");
    return { value, authorization, frame: bytes };
  }
  async #allowed(input, signal) {
    signal.throwIfAborted();
    const allowed = await this.#options.authorize(structuredClone(input), { signal });
    signal.throwIfAborted();
    return allowed;
  }
  async #authorize(input, signal) {
    if (!await this.#allowed(input, signal)) throw new SignalError("SIGNAL_UNAUTHORIZED");
  }
  async #dispatch(verified, eligible, signal, required) {
    const attached = eligible.filter((route) => !route.lifetime.signal.aborted);
    if (required && attached.length === 0) throw new SignalError("SIGNAL_ROUTE_UNAVAILABLE");
    const routes = attached.filter((route) => !route.busy);
    if (routes.length === 0) return false;
    const attempts = routes.map((route) => {
      route.busy = true;
      let handedOff = false, settled = false;
      const deadline = new AbortController();
      const timer = setTimeout(() => {
        const reason = new SignalError("SIGNAL_SEND_TIMEOUT");
        deadline.abort(reason);
        if (handedOff && !settled) this.#detach(route, true, reason);
      }, Math.max(1, Math.min(this.#sendTimeout, verified.value.expiresAtMs - this.#now())));
      const lifetime = AbortSignal.any([signal, route.lifetime.signal, deadline.signal]);
      const operation = (async () => {
        await this.#authorize(verified.authorization, lifetime);
        this.#assertFresh(verified.value);
        handedOff = true;
        const result = await route.trySend(verified.frame.slice(), { signal: lifetime });
        if (typeof result !== "boolean") {
          throw new SignalError("SIGNAL_TRANSPORT_RESULT_INVALID");
        }
        return result;
      })().catch((error) => {
        if (handedOff && (!lifetime.aborted || error !== lifetime.reason)) this.#detach(route, true, error);
        throw error;
      }).finally(() => {
        settled = true;
        route.busy = false;
        this.#retiring.delete(route);
        clearTimeout(timer);
      });
      return interrupted(operation, lifetime);
    });
    if (required) {
      const refused = new Error("Signal dispatch refused");
      try {
        return await Promise.any(attempts.map(async (attempt) => {
          if (!await attempt) throw refused;
          return true;
        }));
      } catch (error) {
        if (error instanceof AggregateError) {
          const failures = error.errors.filter((value) => value !== refused);
          if (failures.length === 0) return false;
          if (failures.length === 1) throw failures[0];
        }
        throw new SignalError("SIGNAL_SEND_FAILED");
      }
    }
    return (await Promise.allSettled(attempts)).some((result) => result.status === "fulfilled" && result.value);
  }
  #pruneRemembered(now) {
    this.#lastPruneAt = now;
    for (const [id, progress] of this.#sessions) {
      for (const [sequence, expiresAtMs] of progress.seen) if (expiresAtMs <= now) {
        progress.seen.delete(sequence);
        this.#remembered -= 1;
      }
      if (progress.seen.size === 0) this.#sessions.delete(id);
    }
  }
  #reject(route, reason) {
    if (route !== void 0) {
      route.rejections.total = Math.min(Number.MAX_SAFE_INTEGER, route.rejections.total + 1);
      route.rejections[reason] = Math.min(Number.MAX_SAFE_INTEGER, route.rejections[reason] + 1);
    }
    return null;
  }
  #remember(value, route) {
    const now = this.#now();
    const key = `${value.authorId}/${value.sessionId}`;
    let previous = this.#sessions.get(key);
    const existingExpiry = previous?.seen.get(value.sequence);
    if (existingExpiry !== void 0) {
      if (existingExpiry > now) {
        this.#reject(route, "duplicate");
        return false;
      }
      previous.seen.delete(value.sequence);
      this.#remembered -= 1;
      if (previous.seen.size === 0) {
        this.#sessions.delete(key);
        previous = void 0;
      }
    }
    if (now - this.#lastPruneAt >= 1e3 || previous === void 0 && this.#sessions.size >= this.#maxSessions || (previous?.seen.size ?? 0) >= this.#maxSequences || this.#remembered >= this.#maxRemembered) {
      this.#pruneRemembered(now);
      previous = this.#sessions.get(key);
    }
    if (previous === void 0 && this.#sessions.size >= this.#maxSessions || (previous?.seen.size ?? 0) >= this.#maxSequences || this.#remembered >= this.#maxRemembered) {
      this.#reject(route, "capacity");
      return false;
    }
    const progress = previous ?? { seen: /* @__PURE__ */ new Map() };
    progress.seen.set(value.sequence, value.expiresAtMs);
    this.#remembered += 1;
    this.#sessions.set(key, progress);
    return true;
  }
  #forget(value) {
    const key = `${value.authorId}/${value.sessionId}`, session = this.#sessions.get(key);
    if (session?.seen.delete(value.sequence) === true) this.#remembered -= 1;
    if (session?.seen.size === 0) this.#sessions.delete(key);
  }
  #deliver(value, bytes) {
    const now = this.#now();
    const streamKey = JSON.stringify([value.authorId, value.sessionId, value.topic, value.stream?.endpointId ?? null, value.stream?.endpointIncarnation ?? null, value.stream?.streamId ?? null, value.stream?.target ?? null]);
    if (this.#maxRetainedLatest > 0 && value.expiresAtMs > now) {
      const prior = this.#retainedLatest.get(streamKey);
      if (prior === void 0 || prior.value.sequence < value.sequence || prior.value.expiresAtMs <= now) {
        if (prior !== void 0) this.#retainedLatest.delete(streamKey);
        else if (this.#retainedLatest.size >= this.#maxRetainedLatest) {
          for (const [id, entry] of this.#retainedLatest) if (entry.value.expiresAtMs <= now) this.#retainedLatest.delete(id);
          if (this.#retainedLatest.size >= this.#maxRetainedLatest) {
            const oldest = this.#retainedLatest.keys().next().value;
            if (oldest !== void 0) this.#retainedLatest.delete(oldest);
          }
        }
        this.#retainedLatest.set(streamKey, { value: structuredClone(value), bytes });
      }
    }
    for (const subscriber of this.#subscriptions) {
      if (subscriber.topics !== null && !subscriber.topics.has(value.topic)) continue;
      if (subscriber.streams !== null && !subscriber.streams.some((selector) => matchesStream(value, selector))) continue;
      for (let index = subscriber.pending.length - 1; index >= 0; index -= 1) {
        if (subscriber.pending[index].value.expiresAtMs <= now) subscriber.bytes -= subscriber.pending.splice(index, 1)[0].bytes;
      }
      for (const [id, latest] of subscriber.latest) if (latest.retainThroughMs <= now) subscriber.latest.delete(id);
      const key = streamKey;
      if (subscriber.mode === "latest") {
        const previous = subscriber.latest.get(key);
        if (previous !== void 0 && previous.sequence >= value.sequence) continue;
        if (previous === void 0 && subscriber.latest.size >= this.#maxQueuedSignals) {
          this.#overflow(subscriber);
          continue;
        }
        subscriber.latest.set(key, { sequence: value.sequence, retainThroughMs: now + this.#ttl + this.#skew });
        const index = subscriber.pending.findIndex((item) => item.key === key);
        if (index !== -1) subscriber.bytes -= subscriber.pending.splice(index, 1)[0].bytes;
      }
      if (subscriber.pending.length >= this.#maxQueuedSignals || subscriber.bytes + bytes > this.#maxQueuedBytes) {
        this.#overflow(subscriber);
      } else {
        subscriber.pending.push({ value: structuredClone(value), bytes, key });
        subscriber.bytes += bytes;
      }
      subscriber.wake?.();
    }
  }
  #overflow(subscriber) {
    subscriber.error = new SignalError("SIGNAL_SUBSCRIPTION_OVERFLOW");
    subscriber.pending.length = 0;
    subscriber.bytes = 0;
    subscriber.latest.clear();
    subscriber.clean();
    this.#subscriptions.delete(subscriber);
    subscriber.wake?.();
  }
  subscribe(options = {}) {
    if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
    const self = this;
    return { [Symbol.asyncIterator]() {
      const controller = new AbortController();
      const signal = options.signal === void 0 ? controller.signal : AbortSignal.any([controller.signal, options.signal]);
      const iterator = self.#subscribe({ ...options, signal });
      return {
        next: () => iterator.next(),
        async return() {
          controller.abort();
          return iterator.return();
        },
        async throw(error) {
          controller.abort();
          return iterator.throw(error);
        }
      };
    } };
  }
  async *#subscribe(options) {
    this.#assertOpen();
    if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
    const mode = options.mode ?? "all";
    if (mode !== "all" && mode !== "latest") throw new SignalError("SIGNAL_SUBSCRIPTION_MODE_INVALID");
    if (options.topics !== void 0) {
      if (!Array.isArray(options.topics) || options.topics.length > 64) throw new SignalError("SIGNAL_TOPIC_FILTER_TOO_LARGE");
      for (const topic of options.topics) {
        if (typeof topic !== "string") throw new SignalError("SIGNAL_TOPIC_FILTER_INVALID");
        assertSignalTopic(topic);
      }
    }
    const streams = options.streams === void 0 ? null : checkedSelectors(options.streams);
    if (this.#subscriptions.size >= this.#maxSubscriptions) throw new SignalError("SIGNAL_SUBSCRIPTION_QUOTA_EXCEEDED");
    const subscriber = {
      topics: options.topics === void 0 ? null : new Set(options.topics),
      streams,
      mode,
      pending: [],
      latest: /* @__PURE__ */ new Map(),
      bytes: 0,
      error: null,
      wake: null,
      clean: () => void 0
    };
    if (options.includeLatest === true) {
      if (mode !== "latest") throw new SignalError("SIGNAL_SUBSCRIPTION_MODE_INVALID");
      const now = this.#now();
      for (const [key, entry] of this.#retainedLatest) {
        if (entry.value.expiresAtMs <= now) {
          this.#retainedLatest.delete(key);
          continue;
        }
        if (subscriber.topics !== null && !subscriber.topics.has(entry.value.topic)) continue;
        if (subscriber.streams !== null && !subscriber.streams.some((selector) => matchesStream(entry.value, selector))) continue;
        if (subscriber.pending.length >= this.#maxQueuedSignals || subscriber.bytes + entry.bytes > this.#maxQueuedBytes) break;
        subscriber.latest.set(key, { sequence: entry.value.sequence, retainThroughMs: now + this.#ttl + this.#skew });
        subscriber.pending.push({ value: structuredClone(entry.value), bytes: entry.bytes, key });
        subscriber.bytes += entry.bytes;
      }
    }
    this.#subscriptions.add(subscriber);
    const signal = options.signal;
    const abort = () => {
      subscriber.pending.length = 0;
      subscriber.bytes = 0;
      subscriber.latest.clear();
      subscriber.clean();
      this.#subscriptions.delete(subscriber);
      subscriber.wake?.();
    };
    subscriber.clean = () => signal?.removeEventListener("abort", abort);
    signal?.addEventListener("abort", abort, { once: true });
    try {
      while (!this.#lifetime.signal.aborted && signal?.aborted !== true) {
        if (subscriber.error !== null) throw subscriber.error;
        const item = subscriber.pending.shift();
        if (item !== void 0) {
          subscriber.bytes -= item.bytes;
          if (item.value.expiresAtMs > this.#now()) yield structuredClone(item.value);
        } else {
          await new Promise((resolve) => {
            subscriber.wake = resolve;
            if (this.#lifetime.signal.aborted || signal?.aborted === true || subscriber.pending.length > 0 || subscriber.error !== null) resolve();
          });
          subscriber.wake = null;
        }
      }
    } finally {
      subscriber.clean();
      this.#subscriptions.delete(subscriber);
    }
  }
  close() {
    if (this.#lifetime.signal.aborted) return;
    this.#lifetime.abort(new SignalError("SIGNAL_CHANNEL_CLOSED"));
    for (const route of this.#routes) this.#detach(route);
    for (const subscriber of this.#subscriptions) {
      subscriber.pending.length = 0;
      subscriber.latest.clear();
      subscriber.clean();
      subscriber.wake?.();
    }
    this.#subscriptions.clear();
    this.#sessions.clear();
    this.#retainedLatest.clear();
    this.#verifyKeys.clear();
    this.#remembered = 0;
  }
  #detach(route, retire = false, reason = new SignalError("SIGNAL_ROUTE_CLOSED")) {
    if (route.busy) this.#retiring.add(route);
    this.#routes.delete(route);
    route.lifetime.abort(reason);
    if (retire && !route.retired) {
      route.retired = true;
      try {
        void Promise.resolve(route.close?.(reason)).catch(() => void 0);
      } catch {
      }
    }
  }
  #assertOpen() {
    this.#lifetime.signal.throwIfAborted();
  }
  #assertFresh(value) {
    this.#assertClock(value);
    if (value.expiresAtMs <= this.#now()) throw new SignalError("SIGNAL_EXPIRED");
  }
  #assertClockFields(value) {
    if (!Number.isSafeInteger(value.sequence) || value.sequence < 1 || !Number.isSafeInteger(value.issuedAtMs) || value.issuedAtMs < 0 || !Number.isSafeInteger(value.expiresAtMs) || value.expiresAtMs <= value.issuedAtMs || value.expiresAtMs - value.issuedAtMs > this.#ttl) {
      throw new SignalError("SIGNAL_CLOCK_INVALID");
    }
  }
  #assertClock(value) {
    this.#assertClockFields(value);
    if (value.issuedAtMs > this.#now() + this.#skew) throw new SignalError("SIGNAL_CLOCK_INVALID");
  }
  #now() {
    const now = bound(this.#options.now?.() ?? Date.now(), 0, Number.MAX_SAFE_INTEGER, "SIGNAL_CLOCK_INVALID");
    this.#observedTime = Math.max(this.#observedTime, now);
    return this.#observedTime;
  }
};
function credentialBytes(value) {
  if (value === void 0) return void 0;
  if (!(value instanceof Uint8Array) || value.length > 1024) throw new SignalError("SIGNAL_CREDENTIAL_INVALID");
  return value.slice();
}
function bound(value, minimum, maximum, code = "SIGNAL_BOUNDS_INVALID") {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) throw new SignalError(code);
  return value;
}
function interrupted(operation, signal) {
  return new Promise((resolve, reject) => {
    const abort = () => {
      reject(signal.reason);
      signal.removeEventListener("abort", abort);
    };
    signal.addEventListener("abort", abort, { once: true });
    void operation.then(resolve, reject).finally(() => signal.removeEventListener("abort", abort));
    if (signal.aborted) abort();
  });
}
function checkedStream(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !["streamId", "endpointId", "endpointIncarnation", "target", "stateRoot", "supersedesStream"].includes(key)) || !boundedLabel(value.streamId) || value.endpointId === void 0 !== (value.endpointIncarnation === void 0) || value.endpointId !== void 0 && !boundedLabel(value.endpointId) || value.endpointIncarnation !== void 0 && !boundedLabel(value.endpointIncarnation) || value.target !== void 0 && !boundedLabel(value.target) || value.stateRoot !== void 0 && !/^[0-9a-f]{64}$/u.test(value.stateRoot) || value.supersedesStream !== void 0 && !boundedLabel(value.supersedesStream)) throw new SignalError("SIGNAL_STREAM_INVALID");
  return {
    streamId: value.streamId,
    ...value.endpointId === void 0 ? {} : { endpointId: value.endpointId, endpointIncarnation: value.endpointIncarnation },
    ...value.target === void 0 ? {} : { target: value.target },
    ...value.stateRoot === void 0 ? {} : { stateRoot: value.stateRoot },
    ...value.supersedesStream === void 0 ? {} : { supersedesStream: value.supersedesStream }
  };
}
function decodeStream(value) {
  if (typeof value !== "string" || value.length > 2048) throw new SignalError("SIGNAL_STREAM_INVALID");
  let parsed;
  try {
    parsed = JSON.parse(value);
  } catch {
    throw new SignalError("SIGNAL_STREAM_INVALID");
  }
  const stream = checkedStream(parsed);
  if (JSON.stringify(stream) !== value) throw new SignalError("SIGNAL_STREAM_INVALID");
  return stream;
}
function boundedLabel(value) {
  return typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._:/@-]{0,127}$/u.test(value);
}
function checkedSelectors(value) {
  const keys = ["authorId", "sessionId", "streamId", "endpointId", "endpointIncarnation", "target"];
  if (!Array.isArray(value) || value.length > 64 || value.some((selector) => selector === null || typeof selector !== "object" || Array.isArray(selector) || Object.entries(selector).some(([key, item]) => !keys.includes(key) || !boundedLabel(item)))) {
    throw new SignalError("SIGNAL_STREAM_FILTER_INVALID");
  }
  return structuredClone(value);
}
function matchesStream(value, selector) {
  return (selector.authorId === void 0 || selector.authorId === value.authorId) && (selector.sessionId === void 0 || selector.sessionId === value.sessionId) && (selector.streamId === void 0 || selector.streamId === value.stream?.streamId) && (selector.endpointId === void 0 || selector.endpointId === value.stream?.endpointId) && (selector.endpointIncarnation === void 0 || selector.endpointIncarnation === value.stream?.endpointIncarnation) && (selector.target === void 0 || selector.target === value.stream?.target);
}

// packages/peer-session/src/snapshot-codec.ts
var SNAPSHOT_LIMITS = Object.freeze({ ...DEFAULT_DECODE_LIMITS, maxBytes: 256 * 1024 * 1024, maxBlobBytes: 256 * 1024 * 1024, maxArrayItems: 4e6 });
var aad = (logId, epoch) => utf82(`chronolog-v3-snapshot:${logId}:${epoch}`);
async function encodeSnapshotBundle(input) {
  const logIdBytes = hexToBytes(input.logId);
  const body2 = encodeCanonicalCbor([
    logIdBytes,
    encodeMaterializedCache(input.cache),
    input.casNodes.map((node) => [hexToBytes(node.hash), node.partition === "public" ? 0n : 1n, node.bytes])
  ]);
  const signature = await signDomain(DOMAINS.materializedSnapshot, body2, input.identity.privateKey);
  const signer = hexToBytes(input.identity.publicKey);
  if (input.encryption === void 0) return encodeCanonicalCbor([3n, logIdBytes, 0n, signer, signature, body2]);
  const plain = encodeCanonicalCbor([signer, signature, body2]);
  const enc = await encryptEpochPayload(input.encryption.key, BigInt(input.encryption.epoch), plain, aad(input.logId, input.encryption.epoch));
  return encodeCanonicalCbor([3n, logIdBytes, 1n, BigInt(input.encryption.epoch), enc.nonce, enc.ciphertext]);
}
async function decodeSnapshotBundle(bytes, logId, epochKey) {
  try {
    const outer = decodeCanonicalCbor(bytes, SNAPSHOT_LIMITS);
    if (!Array.isArray(outer) || outer[0] !== 3n || !(outer[1] instanceof Uint8Array) || bytesToHex(outer[1]) !== logId) return null;
    let signer, signature, body2;
    if (outer[2] === 0n && outer.length === 6) {
      ;
      [, , , signer, signature, body2] = outer;
    } else if (outer[2] === 1n && outer.length === 6) {
      const [, , , epochRaw, nonce, ciphertext] = outer;
      if (typeof epochRaw !== "bigint" || !(nonce instanceof Uint8Array) || !(ciphertext instanceof Uint8Array)) return null;
      const epoch = Number(epochRaw);
      const key = epochKey(epoch);
      if (key === void 0) return null;
      const plain = await decryptEpochPayload(key, { epoch: epochRaw, nonce, ciphertext }, aad(logId, epoch));
      const inner = decodeCanonicalCbor(plain, SNAPSHOT_LIMITS);
      if (!Array.isArray(inner) || inner.length !== 3) return null;
      [signer, signature, body2] = inner;
    } else {
      return null;
    }
    if (!(signer instanceof Uint8Array) || signer.length !== 32 || !(signature instanceof Uint8Array) || !(body2 instanceof Uint8Array)) return null;
    if (!await verifyDomain(DOMAINS.materializedSnapshot, body2, signature, signer)) return null;
    const decodedBody = decodeCanonicalCbor(body2, SNAPSHOT_LIMITS);
    if (!Array.isArray(decodedBody) || decodedBody.length !== 3) return null;
    const [bodyLogId, cacheBytes, rawNodes] = decodedBody;
    if (!(bodyLogId instanceof Uint8Array) || bytesToHex(bodyLogId) !== logId || !(cacheBytes instanceof Uint8Array) || !Array.isArray(rawNodes)) return null;
    const cache = decodeMaterializedCache(cacheBytes);
    if (cache === null || cache.logId !== logId) return null;
    const casNodes = [];
    for (const item of rawNodes) {
      if (!Array.isArray(item) || item.length !== 3) return null;
      const [hash, partition, nodeBytes] = item;
      if (!(hash instanceof Uint8Array) || hash.length !== 32 || partition !== 0n && partition !== 1n || !(nodeBytes instanceof Uint8Array)) return null;
      casNodes.push({ hash: bytesToHex(hash), bytes: nodeBytes, partition: partition === 0n ? "public" : "private" });
    }
    return { signer: bytesToHex(signer), cache, casNodes };
  } catch {
    return null;
  }
}

// packages/peer-session/src/content-pull.ts
var CONTENT_PULL_DEFAULTS = Object.freeze({ windowChunks: 64, batchChunks: 8, perSource: 8 });
var BUSY = /* @__PURE__ */ new Set(["CONTENT_BUSY", "CONTENT_REQUEST_LIMIT"]);
var MAX_BUSY_RETRIES = 1e3;
function slot() {
  let resolve, reject;
  const promise = new Promise((yes, no) => {
    resolve = yes;
    reject = no;
  });
  void promise.catch(() => void 0);
  const value = {
    promise,
    settled: false,
    resolve: (bytes) => {
      if (!value.settled) {
        value.settled = true;
        resolve(bytes);
      }
    },
    reject: (error) => {
      if (!value.settled) {
        value.settled = true;
        reject(error);
      }
    }
  };
  return value;
}
var ChunkPuller = class {
  #options;
  #window;
  #batch;
  #perSource;
  #controller = new AbortController();
  #signal;
  #slots = /* @__PURE__ */ new Map();
  /** Indices waiting for a (re)fetch, with the sources that already failed them. */
  #queue = [];
  #inflight;
  /** Per-source concurrency, lowered to what the source accepted when it reports busy. */
  #cap;
  #used;
  #scanned = 0;
  #consumed = 0;
  /** Slow start: the window doubles with every take, so a consumer that stops early pulls ~what it read. */
  #open = 1;
  #failed = void 0;
  #retryTimer;
  constructor(options) {
    this.#options = options;
    this.#window = Math.max(1, options.windowChunks ?? CONTENT_PULL_DEFAULTS.windowChunks);
    this.#batch = Math.max(1, Math.min(this.#window, options.batchChunks ?? CONTENT_PULL_DEFAULTS.batchChunks));
    this.#perSource = Math.max(1, options.perSource ?? CONTENT_PULL_DEFAULTS.perSource);
    this.#inflight = options.sources.map(() => 0);
    this.#scanned = this.#consumed = options.start ?? 0;
    this.#open = Math.max(1, Math.min(this.#window, options.initialWindow ?? 1));
    this.#cap = options.sources.map(() => this.#perSource);
    this.#used = options.sources.map(() => 0);
    this.#signal = AbortSignal.any([options.signal, this.#controller.signal]);
    this.#signal.addEventListener("abort", this.#onAbort, { once: true });
  }
  #onAbort = () => this.close(this.#signal.reason);
  /** Resolve chunk `index` (taken in increasing order) and slide the window past it. */
  async take(index) {
    this.#signal.throwIfAborted();
    if (this.#failed !== void 0) throw this.#failed instanceof Error ? this.#failed : new Error(this.#options.missing, { cause: this.#failed });
    this.#consumed = Math.max(this.#consumed, index);
    this.#pump();
    this.#open = Math.min(this.#window, this.#open * 2);
    const target = this.#slotFor(index);
    try {
      return await target.promise;
    } finally {
      this.#slots.delete(index);
      this.#consumed = Math.max(this.#consumed, index + 1);
    }
  }
  close(reason = new Error("CONTENT_PULL_CLOSED")) {
    if (this.#retryTimer !== void 0) clearTimeout(this.#retryTimer);
    this.#signal.removeEventListener("abort", this.#onAbort);
    if (!this.#controller.signal.aborted) this.#controller.abort(reason);
    for (const value of this.#slots.values()) value.reject(reason);
  }
  #slotFor(index) {
    let value = this.#slots.get(index);
    if (value === void 0) {
      value = slot();
      this.#slots.set(index, value);
    }
    return value;
  }
  #fail(error) {
    if (this.#failed !== void 0) return;
    this.#failed = error;
    this.close(error);
  }
  /** Scan newly windowed indices (local first), then dispatch queued misses as range requests. */
  #pump() {
    if (this.#signal.aborted || this.#failed !== void 0) return;
    const limit2 = Math.min(this.#options.count, this.#consumed + this.#open);
    if (this.#scanned < limit2) {
      const start = this.#scanned, end = limit2;
      this.#scanned = limit2;
      void this.#scan(start, end).catch((error) => this.#fail(error));
    }
    this.#dispatch();
  }
  async #scan(start, end) {
    for (let index = start; index < end; index++) {
      const target = this.#slotFor(index);
      const local = await this.#options.local(index, this.#signal);
      this.#signal.throwIfAborted();
      if (local !== null) target.resolve(local);
      else this.#queue.push({ index, excluded: /* @__PURE__ */ new Set(), failure: void 0, busy: 0 });
      if (this.#queue.length >= this.#batch || index === end - 1) this.#dispatch();
    }
  }
  #pickSource(excluded) {
    let best = -1;
    for (let source2 = 0; source2 < this.#inflight.length; source2++) {
      if (excluded.has(source2) || this.#inflight[source2] >= this.#cap[source2]) continue;
      if (best < 0 || this.#inflight[source2] < this.#inflight[best] || this.#inflight[source2] === this.#inflight[best] && this.#used[source2] < this.#used[best]) best = source2;
    }
    return best;
  }
  #dispatch() {
    if (this.#signal.aborted || this.#failed !== void 0) return;
    this.#queue.sort((x, y) => x.index - y.index);
    let blocked = 0;
    while (this.#queue.length > blocked) {
      const head = this.#queue[blocked];
      if (head.excluded.size >= this.#options.sources.length) {
        this.#queue.splice(blocked, 1);
        const error = head.failure ?? new Error(this.#options.missing);
        this.#slotFor(head.index).reject(error);
        this.#fail(error);
        return;
      }
      const source2 = this.#pickSource(head.excluded);
      if (source2 < 0) {
        blocked++;
        continue;
      }
      let run = 1;
      while (run < this.#batch && blocked + run < this.#queue.length) {
        const item = this.#queue[blocked + run];
        if (item.index !== head.index + run || item.excluded.has(source2)) break;
        run++;
      }
      const items = this.#queue.splice(blocked, run);
      void this.#request(source2, items);
    }
  }
  async #request(source2, items) {
    this.#inflight[source2]++;
    this.#used[source2]++;
    const start = items[0].index, pending = new Map(items.map((item) => [item.index, item]));
    const accepted = [];
    let failure;
    try {
      await this.#options.sources[source2].fetch(start, items.length, (index, bytes) => {
        const item = pending.get(index);
        if (item === void 0 || this.#signal.aborted) return;
        pending.delete(index);
        if (bytes === null) {
          item.excluded.add(source2);
          this.#queue.push(item);
          return;
        }
        accepted.push(this.#options.accept(index, bytes, this.#signal).then(
          (value) => {
            this.#slotFor(index).resolve(value);
          },
          (error) => {
            if (!this.#signal.aborted) {
              item.excluded.add(source2);
              item.failure = error;
              this.#queue.push(item);
            }
          }
        ));
      }, this.#signal);
    } catch (error) {
      failure = error;
    }
    await Promise.all(accepted);
    this.#inflight[source2]--;
    if (this.#signal.aborted) return;
    const busy = failure instanceof Error && BUSY.has(failure.message);
    for (const item of pending.values()) {
      if (busy && ++item.busy <= MAX_BUSY_RETRIES) {
        this.#queue.push(item);
        continue;
      }
      item.excluded.add(source2);
      if (failure !== void 0) item.failure = failure;
      this.#queue.push(item);
    }
    if (!busy) this.#cap[source2] = Math.min(this.#perSource, this.#cap[source2] + 1);
    else if (pending.size > 0) {
      this.#cap[source2] = Math.max(1, this.#inflight[source2]);
      if (this.#inflight[source2] === 0) {
        if (this.#retryTimer === void 0) this.#retryTimer = setTimeout(() => {
          this.#retryTimer = void 0;
          this.#dispatch();
        }, 10);
        return;
      }
    }
    this.#dispatch();
  }
};

// packages/peer-session/src/content.ts
var MAX_CONTENT_CHUNKS = MAX_CONTENT_BYTES / CONTENT_CHUNK_BYTES;
var CONTENT_CHUNK_HEADER_BYTES = 21;
var CONTENT_CHUNK_FORMAT = 1;
var AES_GCM_TAG_BYTES = 16;
var MAX_CONTENT_ENCRYPTED_CHUNK_BYTES = CONTENT_CHUNK_BYTES + CONTENT_CHUNK_HEADER_BYTES + AES_GCM_TAG_BYTES;
var MAX_CONTENT_MANIFEST_BYTES = 256 * 1024;
var CONTENT_FETCH_WINDOW_BYTES = 4 * 1024 * 1024;
var digest = (value) => typeof value === "string" && /^[0-9a-f]{64}$/u.test(value);
var stageId = (value) => typeof value === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u.test(value);
function object(value, keys) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), "CONTENT_SHAPE_INVALID");
}
function assertReferenceBody(value) {
  object(value, ["profile", "applicationId", "epoch", "bytes", "mediaType"]);
  check(value.profile === "authored-content-v1" && digest(value.applicationId) && Number.isSafeInteger(value.epoch) && Number(value.epoch) >= 0 && Number.isSafeInteger(value.bytes) && Number(value.bytes) >= 0 && Number(value.bytes) <= MAX_CONTENT_BYTES && typeof value.mediaType === "string" && value.mediaType.length > 0 && value.mediaType.length <= 256 && /^[\x20-\x7e]+$/u.test(value.mediaType), "CONTENT_REFERENCE_INVALID");
}
function assertContentReference(value) {
  object(value, ["profile", "applicationId", "id", "epoch", "bytes", "mediaType"]);
  check(digest(value.id), "CONTENT_REFERENCE_INVALID");
  const { id: _id, ...body2 } = value;
  assertReferenceBody(body2);
}
function assertContentManifest(value) {
  object(value, ["stageId", "reference", "chunks"]);
  check(stageId(value.stageId), "CONTENT_MANIFEST_INVALID");
  assertReferenceBody(value.reference);
  check(Array.isArray(value.chunks) && value.chunks.length <= MAX_CONTENT_CHUNKS && value.chunks.length === Math.ceil(value.reference.bytes / CONTENT_CHUNK_BYTES), "CONTENT_MANIFEST_INVALID");
  for (const chunk of value.chunks) {
    object(chunk, ["hash", "bytes"]);
    check(digest(chunk.hash) && Number.isSafeInteger(chunk.bytes) && Number(chunk.bytes) > 0 && Number(chunk.bytes) <= MAX_CONTENT_ENCRYPTED_CHUNK_BYTES, "CONTENT_MANIFEST_INVALID");
  }
  check(encodeRecord(value).length <= MAX_CONTENT_MANIFEST_BYTES, "CONTENT_MANIFEST_INVALID");
}
function assertContentRetention(value) {
  object(value, ["payload", "signer", "signature"]);
  check(digest(value.signer) && typeof value.signature === "string" && /^[0-9a-f]{128}$/u.test(value.signature), "CONTENT_RETENTION_INVALID");
  object(value.payload, ["reference", "peer", "storageId"]);
  assertContentReference(value.payload.reference);
  check(value.payload.peer === value.signer && typeof value.payload.storageId === "string" && value.payload.storageId.length > 0 && value.payload.storageId.length <= 256, "CONTENT_RETENTION_INVALID");
}
function assertBlobInfo(value) {
  object(value, ["hash", "bytes"]);
  check(digest(value.hash) && Number.isSafeInteger(value.bytes) && Number(value.bytes) >= 0 && Number(value.bytes) <= MAX_BLOB_BYTES, "CONTENT_BLOB_INVALID");
}
function body(reference) {
  const { id: _id, ...rest } = reference;
  return rest;
}
function encodeChunk(payload) {
  const out = new Uint8Array(CONTENT_CHUNK_HEADER_BYTES + payload.ciphertext.length);
  out[0] = CONTENT_CHUNK_FORMAT;
  new DataView(out.buffer).setBigUint64(1, payload.epoch);
  out.set(payload.nonce, 9);
  out.set(payload.ciphertext, CONTENT_CHUNK_HEADER_BYTES);
  return out;
}
function envelope(bytes, epoch, plaintextBytes) {
  check(bytes instanceof Uint8Array && bytes.length === CONTENT_CHUNK_HEADER_BYTES + plaintextBytes + AES_GCM_TAG_BYTES && bytes[0] === CONTENT_CHUNK_FORMAT, "CONTENT_CHUNK_INVALID");
  const value = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getBigUint64(1);
  check(value === BigInt(epoch), "CONTENT_CHUNK_INVALID");
  return { epoch: value, nonce: bytes.subarray(9, CONTENT_CHUNK_HEADER_BYTES), ciphertext: bytes.subarray(CONTENT_CHUNK_HEADER_BYTES) };
}
var plainBytesAt = (reference, index) => Math.min(CONTENT_CHUNK_BYTES, reference.bytes - index * CONTENT_CHUNK_BYTES);
function rangeOf(ranged, single) {
  return {
    async fetch(start, count, onChunk, signal) {
      if (ranged !== void 0) {
        await awaitOwnedTask(signal, () => ranged(start, count, onChunk, signal));
        return;
      }
      for (let index = start; index < start + count; index++) await onChunk(index, await awaitOwnedTask(signal, () => single(index, signal)));
    }
  };
}
var ApplicationContent = class {
  #sources = /* @__PURE__ */ new Map();
  #reads = /* @__PURE__ */ new Map();
  #lifetime = new AbortController();
  #prefix;
  #cas;
  #options;
  #cacheIndex = null;
  /** Last validated manifest per id, keyed by its exact stored bytes so a changed record is revalidated. */
  #manifests = /* @__PURE__ */ new Map();
  #tail = Promise.resolve();
  constructor(options) {
    check(typeof options.storageId === "string" && options.storageId.length > 0 && options.storageId.length <= 256, "CONTENT_STORAGE_ID_INVALID");
    this.#options = options;
    this.#cas = options.cas ?? new ContentAddressedStore({ store: options.store });
    this.#prefix = `content/${options.authority.applicationId}`;
  }
  get cas() {
    return this.#cas;
  }
  #cacheEntryKey(kind, key) {
    return `${this.#prefix}/cache-entry/${kind}/${key}`;
  }
  async #loadCacheIndex() {
    if (this.#cacheIndex !== null) return this.#cacheIndex;
    const map = /* @__PURE__ */ new Map();
    const entryPrefix = `${this.#prefix}/cache-entry/`;
    const ingest = (entry) => {
      if (!entry.key.startsWith(entryPrefix) || entry.value.length === 0) return;
      try {
        const item = decodeRecord(entry.value);
        if (item && typeof item.key === "string" && (item.kind === "public" || item.kind === "private") && typeof item.bytes === "number") {
          map.set(`${item.kind}:${item.key}`, { ...item, pinned: Boolean(item.pinned) });
        }
      } catch {
      }
    };
    if (this.#options.store.iteratePrefix !== void 0) {
      for await (const entry of this.#options.store.iteratePrefix(entryPrefix)) ingest(entry);
    } else if (this.#options.store.iterateEntries !== void 0) {
      for await (const entry of this.#options.store.iterateEntries()) ingest(entry);
    } else if (this.#options.store.entries !== void 0) {
      for (const entry of await this.#options.store.entries()) ingest(entry);
    }
    this.#cacheIndex = map;
    return map;
  }
  async #saveCacheEntry(entry) {
    await this.#options.store.put(this.#cacheEntryKey(entry.kind, entry.key), encodeRecord(entry), { durability: "relaxed" });
  }
  async #touchCacheEntry(kind, key, bytes, reference) {
    const map = await this.#loadCacheIndex();
    const id = `${kind}:${key}`;
    const prev = map.get(id);
    const next = {
      kind,
      key,
      bytes,
      lastAccessMs: Date.now(),
      pinned: prev?.pinned ?? false,
      ...reference !== void 0 ? { reference } : prev?.reference !== void 0 ? { reference: prev.reference } : {}
    };
    map.set(id, next);
    await this.#saveCacheEntry(next);
  }
  async #dropCacheEntry(kind, key) {
    const map = await this.#loadCacheIndex();
    if (map.delete(`${kind}:${key}`)) {
      await this.#remove(this.#cacheEntryKey(kind, key));
    }
  }
  #cacheIdOf(target) {
    if (typeof target === "string") {
      check(digest(target), "CONTENT_BLOB_INVALID");
      return { kind: "public", key: target };
    }
    if (isPublicBlobReference(target)) {
      check(digest(target.hash), "CONTENT_BLOB_INVALID");
      return { kind: "public", key: target.hash };
    }
    if (isPrivateContentReference(target)) {
      const ref = this.#reference(target);
      return { kind: "private", key: ref.id };
    }
    throw new Error("CONTENT_REFERENCE_INVALID");
  }
  #reader() {
    this.#lifetime.signal.throwIfAborted();
    check(this.#options.authority.isReader(this.#options.identity.publicKey), "CONTENT_READER_REQUIRED");
  }
  #reference(input) {
    assertContentReference(input);
    check(input.applicationId === this.#options.authority.applicationId, "CONTENT_SCOPE_INVALID");
    return { ...input };
  }
  #serial(work) {
    const task = this.#tail.then(() => {
      this.#lifetime.signal.throwIfAborted();
      return work();
    });
    this.#tail = task.catch(() => void 0);
    return task;
  }
  #scopeKey(key, options) {
    this.#reader();
    options.signal?.throwIfAborted();
    const controller = new AbortController();
    let reads = this.#reads.get(key);
    if (reads === void 0) {
      reads = /* @__PURE__ */ new Set();
      this.#reads.set(key, reads);
    }
    reads.add(controller);
    const signal = AbortSignal.any([this.#lifetime.signal, controller.signal, ...options.signal === void 0 ? [] : [options.signal]]);
    signal.throwIfAborted();
    return { signal, release: () => {
      reads.delete(controller);
      if (reads.size === 0) this.#reads.delete(key);
    } };
  }
  #readScope(reference, options) {
    return this.#scopeKey(reference.id, options);
  }
  #blobScope(hash, options) {
    return this.#scopeKey(`blob:${hash}`, options);
  }
  attachSource(id, source2) {
    this.#lifetime.signal.throwIfAborted();
    check(typeof id === "string" && id.length > 0 && id.length <= 256 && this.#sources.size < 8 && !this.#sources.has(id), "CONTENT_SOURCE_LIMIT");
    this.#sources.set(id, source2);
    let detached = false;
    return () => {
      if (!detached) {
        detached = true;
        this.#sources.delete(id);
      }
    };
  }
  async stage(options) {
    this.#reader();
    const id = crypto.randomUUID(), epoch = this.#options.authority.currentEpoch();
    const reference = { profile: "authored-content-v1", applicationId: this.#options.authority.applicationId, epoch, bytes: options.bytes, mediaType: options.mediaType ?? "application/octet-stream" };
    assertReferenceBody(reference);
    check(this.#options.authority.epochKey(epoch) !== null, "CONTENT_KEY_MISSING");
    await this.#serial(() => this.#options.store.put(`${this.#prefix}/stage/${id}`, encodeRecord({ stageId: id, reference, committed: null, discarded: false })));
    return this.resumeUpload(id);
  }
  async resumeUpload(id) {
    this.#reader();
    check(stageId(id), "CONTENT_STAGE_INVALID");
    const key = `${this.#prefix}/stage/${id}`;
    const readStage = async () => {
      this.#reader();
      const raw = await this.#options.store.get(key);
      check(raw !== null, "CONTENT_STAGE_MISSING");
      const stage = decodeRecord(raw);
      object(stage, ["stageId", "reference", "committed", "discarded"]);
      assertReferenceBody(stage.reference);
      check(stage.stageId === id && stage.reference.applicationId === this.#options.authority.applicationId && typeof stage.discarded === "boolean", "CONTENT_STAGE_INVALID");
      if (stage.committed !== null) {
        assertContentReference(stage.committed);
        check(equalRecord(body(stage.committed), stage.reference), "CONTENT_STAGE_INVALID");
      }
      check(!stage.discarded, "CONTENT_STAGE_DISCARDED");
      return stage;
    };
    const first = await readStage(), count = Math.ceil(first.reference.bytes / CONTENT_CHUNK_BYTES);
    return {
      id,
      write: (index, input) => {
        check(input instanceof Uint8Array && input.length <= CONTENT_CHUNK_BYTES, "CONTENT_CHUNK_SIZE_INVALID");
        const bytes = input.slice();
        return this.#serial(async () => {
          const stage = await readStage();
          check(stage.committed === null && Number.isSafeInteger(index) && index >= 0 && index < count && bytes.length === Math.min(CONTENT_CHUNK_BYTES, stage.reference.bytes - index * CONTENT_CHUNK_BYTES), "CONTENT_CHUNK_SIZE_INVALID");
          const epochKey = this.#options.authority.epochKey(stage.reference.epoch);
          check(epochKey !== null, "CONTENT_KEY_MISSING");
          const aad2 = encodeRecord([this.#prefix, id, index]), existing = await this.#options.store.get(`${key}/chunk/${index}`);
          if (existing !== null) {
            const plaintext = await decryptEpochPayload(epochKey, envelope(existing, stage.reference.epoch, bytes.length), aad2);
            check(equalBytes(plaintext, bytes), "CONTENT_CHUNK_CONFLICT");
            return;
          }
          const encrypted = encodeChunk(await encryptEpochPayload(epochKey, BigInt(stage.reference.epoch), bytes, aad2));
          await this.#options.store.put(`${key}/chunk/${index}`, encrypted);
        });
      },
      progress: () => this.#serial(async () => {
        const stage = await readStage(), missingChunks = [];
        let storedBytes = 0;
        for (let index = 0; index < count; index++) {
          const chunk = await this.#options.store.get(`${key}/chunk/${index}`);
          if (chunk === null) missingChunks.push(index);
          else {
            envelope(chunk, stage.reference.epoch, Math.min(CONTENT_CHUNK_BYTES, stage.reference.bytes - index * CONTENT_CHUNK_BYTES));
            storedBytes += Math.min(CONTENT_CHUNK_BYTES, stage.reference.bytes - index * CONTENT_CHUNK_BYTES);
          }
        }
        return { bytes: stage.reference.bytes, storedBytes, missingChunks };
      }),
      commit: () => this.#serial(async () => {
        const stage = await readStage();
        if (stage.committed !== null) return structuredClone(stage.committed);
        const chunks = [];
        const encManifestChunks = [];
        const epochKey = this.#options.authority.epochKey(stage.reference.epoch);
        check(epochKey !== null, "CONTENT_KEY_MISSING");
        for (let index = 0; index < count; index++) {
          const bytes = await this.#options.store.get(`${key}/chunk/${index}`);
          check(bytes !== null, "CONTENT_INCOMPLETE");
          const plainBytes = Math.min(CONTENT_CHUNK_BYTES, stage.reference.bytes - index * CONTENT_CHUNK_BYTES);
          await decryptEpochPayload(epochKey, envelope(bytes, stage.reference.epoch, plainBytes), encodeRecord([this.#prefix, id, index]));
          const hash = await this.#cas.put(bytes, [], "public", { cache: false });
          chunks.push({ hash, bytes: bytes.length });
          encManifestChunks.push({ hash, bytes: bytes.length, plainBytes });
        }
        const manifest = { stageId: id, reference: stage.reference, chunks };
        const reference = { ...stage.reference, id: await recordDigest(manifest) };
        const encCas = encodeEncBlobManifest({
          format: "chronolog-enc-blob/v1",
          applicationId: stage.reference.applicationId,
          epoch: stage.reference.epoch,
          bytes: stage.reference.bytes,
          mediaType: stage.reference.mediaType,
          stageId: id,
          chunks: encManifestChunks
        });
        await this.#cas.put(encCas.bytes, encCas.links, "public");
        await this.#options.store.put(`${this.#prefix}/manifest/${reference.id}`, encodeRecord(manifest));
        await this.#options.store.put(key, encodeRecord({ ...stage, committed: reference }));
        await this.#touchCacheEntry("private", reference.id, reference.bytes, reference);
        return reference;
      }),
      discard: () => this.#serial(async () => {
        const raw = await this.#options.store.get(key);
        if (raw === null) return;
        const stage = decodeRecord(raw);
        await this.#options.store.put(key, encodeRecord({ ...stage, discarded: true }));
        for (let index = 0; index < count; index++) await this.#remove(`${key}/chunk/${index}`);
      })
    };
  }
  async #remove(key) {
    if (this.#options.store.delete !== void 0) await this.#options.store.delete(key);
    else await this.#options.store.put(key, new Uint8Array());
  }
  async #validateManifest(manifest, reference) {
    assertContentManifest(manifest);
    check(equalRecord(manifest.reference, body(reference)) && await recordDigest(manifest) === reference.id, "CONTENT_MANIFEST_INVALID");
  }
  #rememberManifest(id, raw, manifest) {
    this.#manifests.delete(id);
    this.#manifests.set(id, { raw, manifest });
    while (this.#manifests.size > 64) this.#manifests.delete(this.#manifests.keys().next().value);
  }
  async #manifest(reference, signal, localOnly = false) {
    signal.throwIfAborted();
    this.#reader();
    const raw = await awaitOwnedTask(signal, () => this.#options.store.get(`${this.#prefix}/manifest/${reference.id}`));
    if (raw !== null && raw.length > 0) {
      check(raw.length <= MAX_CONTENT_MANIFEST_BYTES, "CONTENT_MANIFEST_INVALID");
      const known = this.#manifests.get(reference.id);
      if (known !== void 0 && equalBytes(known.raw, raw)) {
        signal.throwIfAborted();
        return known.manifest;
      }
      const manifest = decodeRecord(raw);
      await this.#validateManifest(manifest, reference);
      signal.throwIfAborted();
      this.#rememberManifest(reference.id, raw, manifest);
      return manifest;
    }
    this.#manifests.delete(reference.id);
    if (localOnly) return null;
    let failure;
    for (const source2 of [...this.#sources.values()]) {
      try {
        const candidate = await awaitOwnedTask(signal, () => source2.manifest(reference, { signal }));
        if (candidate === null) continue;
        assertContentManifest(candidate);
        const manifest = structuredClone(candidate);
        await this.#validateManifest(manifest, reference);
        await this.#serial(async () => {
          signal.throwIfAborted();
          this.#reader();
          await this.#options.store.put(`${this.#prefix}/manifest/${reference.id}`, encodeRecord(manifest));
        });
        return manifest;
      } catch (error) {
        signal.throwIfAborted();
        failure = error;
      }
    }
    if (failure !== void 0) throw failure instanceof Error ? failure : new Error("CONTENT_SOURCE_FAILED", { cause: failure });
    throw new Error("CONTENT_MANIFEST_MISSING");
  }
  /** A locally stored chunk. CAS is keyed by hash and verifies bytes loaded from the store, so no rehash here. */
  async #localChunk(reference, manifest, index, signal) {
    signal.throwIfAborted();
    this.#reader();
    const descriptor = manifest.chunks[index];
    check(descriptor !== void 0, "CONTENT_CHUNK_INDEX_INVALID");
    const storedNode = await awaitOwnedTask(signal, () => this.#cas.get(descriptor.hash, "public", { cache: false }));
    if (storedNode === null || storedNode.bytes.length === 0) return null;
    check(storedNode.bytes.length === descriptor.bytes, "CONTENT_CHUNK_INVALID");
    envelope(storedNode.bytes, reference.epoch, plainBytesAt(reference, index));
    signal.throwIfAborted();
    return storedNode.bytes;
  }
  /** Verify a remote chunk exactly once (envelope shape, then one hash inside the CAS write) and persist it. */
  async #acceptChunk(reference, manifest, index, bytes, signal) {
    const descriptor = manifest.chunks[index];
    check(descriptor !== void 0, "CONTENT_CHUNK_INDEX_INVALID");
    check(bytes instanceof Uint8Array && bytes.length === descriptor.bytes, "CONTENT_CHUNK_INVALID");
    envelope(bytes, reference.epoch, plainBytesAt(reference, index));
    await this.#serial(async () => {
      signal.throwIfAborted();
      this.#reader();
      try {
        await this.#cas.putVerified(descriptor.hash, bytes, [], "public", { cache: false });
      } catch (error) {
        throw error instanceof Error && error.message === "CAS_HASH_MISMATCH" ? new Error("CONTENT_CHUNK_INVALID") : error;
      }
    });
    return bytes;
  }
  /** In-order chunk reader: local chunks directly, remote ones through one windowed multi-source puller. */
  #chunkReader(reference, manifest, signal, eager = false) {
    let puller;
    return {
      next: async (index) => {
        if (puller === void 0) {
          const local = await this.#localChunk(reference, manifest, index, signal);
          if (local !== null) return local;
          const sources = [...this.#sources.values()].map((source2) => rangeOf(
            source2.chunks === void 0 ? void 0 : (start, count, sink, s) => source2.chunks(reference, start, count, sink, { signal: s }),
            (i, s) => source2.chunk(reference, i, { signal: s })
          ));
          if (sources.length === 0) throw new Error("CONTENT_CHUNK_MISSING");
          puller = new ChunkPuller({
            count: manifest.chunks.length,
            start: index,
            sources,
            signal,
            missing: "CONTENT_CHUNK_MISSING",
            local: (i, s) => this.#localChunk(reference, manifest, i, s),
            accept: (i, bytes, s) => this.#acceptChunk(reference, manifest, i, bytes, s),
            windowChunks: CONTENT_FETCH_WINDOW_BYTES / CONTENT_CHUNK_BYTES,
            // Streaming reads slow-start so an early stop pulls about what was read; retention wants it all.
            ...eager ? { initialWindow: CONTENT_FETCH_WINDOW_BYTES / CONTENT_CHUNK_BYTES } : {}
          });
        }
        return puller.take(index);
      },
      close: () => puller?.close()
    };
  }
  async *read(input, options = {}) {
    const reference = this.#reference(input), scope = this.#readScope(reference, options);
    let chunks;
    try {
      const manifest = await this.#manifest(reference, scope.signal);
      check(manifest !== null, "CONTENT_MANIFEST_MISSING");
      const key = this.#options.authority.epochKey(reference.epoch);
      check(key !== null, "CONTENT_KEY_MISSING");
      chunks = this.#chunkReader(reference, manifest, scope.signal);
      for (let index = 0; index < manifest.chunks.length; index++) {
        const bytes = await chunks.next(index);
        const plaintext = await decryptEpochPayload(key, envelope(bytes, reference.epoch, plainBytesAt(reference, index)), encodeRecord([this.#prefix, manifest.stageId, index]));
        scope.signal.throwIfAborted();
        this.#reader();
        yield plaintext;
      }
    } finally {
      chunks?.close();
      scope.release();
    }
  }
  async #receipt(reference, signal) {
    const receipt = await signRecord("content-retention", { reference, peer: this.#options.identity.publicKey, storageId: this.#options.storageId }, this.#options.identity);
    signal.throwIfAborted();
    this.#reader();
    return receipt;
  }
  /** Transfer/check the entire encrypted object before claiming local retention. */
  async retain(input, options = {}) {
    const reference = this.#reference(input), scope = this.#readScope(reference, options);
    try {
      const manifest = await this.#manifest(reference, scope.signal);
      check(manifest !== null, "CONTENT_MANIFEST_MISSING");
      const chunks = this.#chunkReader(reference, manifest, scope.signal, true);
      try {
        for (let index = 0; index < manifest.chunks.length; index++) await chunks.next(index);
      } finally {
        chunks.close();
      }
      return await this.#receipt(reference, scope.signal);
    } finally {
      scope.release();
    }
  }
  async verifyRetention(input, receipt, expectedPeer) {
    const reference = this.#reference(input);
    assertContentRetention(receipt);
    check(equalRecord(receipt.payload.reference, reference) && (expectedPeer === void 0 || receipt.signer === expectedPeer) && this.#options.authority.isReader(receipt.signer), "CONTENT_RETENTION_INVALID");
    await verifyRecord("content-retention", receipt, expectedPeer);
  }
  /** Ask attached sources to retain the object; these signed availability facts are not finality. */
  async retention(input, options = {}) {
    const reference = this.#reference(input), scope = this.#readScope(reference, options);
    try {
      const receipts = new Map((await this.retained(reference)).map((receipt) => [receipt.signer, receipt]));
      for (const source2 of [...this.#sources.values()]) {
        if (source2.retained === void 0) continue;
        const receipt = await awaitOwnedTask(scope.signal, () => source2.retained(reference, { signal: scope.signal }));
        await this.verifyRetention(reference, receipt);
        if (receipt.signer === this.#options.identity.publicKey || receipt.payload.storageId === this.#options.storageId) continue;
        check(receipts.size < 8 || receipts.has(receipt.signer), "CONTENT_RETENTION_LIMIT");
        receipts.set(receipt.signer, structuredClone(receipt));
        await this.#serial(async () => {
          scope.signal.throwIfAborted();
          const stored = new Map((await this.retained(reference)).map((value) => [value.signer, value]));
          check(stored.size < 8 || stored.has(receipt.signer), "CONTENT_RETENTION_LIMIT");
          stored.set(receipt.signer, structuredClone(receipt));
          await this.#options.store.put(`${this.#prefix}/retentions/${reference.id}`, encodeRecord([...stored.values()]));
        });
      }
      scope.signal.throwIfAborted();
      return await this.retained(reference);
    } finally {
      scope.release();
    }
  }
  async retained(input) {
    this.#reader();
    const reference = this.#reference(input);
    const raw = await this.#options.store.get(`${this.#prefix}/retentions/${reference.id}`);
    if (raw === null || raw.length === 0) return [];
    check(raw.length <= 16 * 1024, "CONTENT_RETENTION_LIMIT");
    const receipts = decodeRecord(raw);
    check(Array.isArray(receipts) && receipts.length <= 8, "CONTENT_RETENTION_LIMIT");
    for (const receipt of receipts) await this.verifyRetention(reference, receipt);
    return receipts.filter((receipt) => receipt.signer !== this.#options.identity.publicKey && receipt.payload.storageId !== this.#options.storageId);
  }
  async discard(input) {
    this.#reader();
    const reference = this.#reference(input);
    for (const read of this.#reads.get(reference.id) ?? []) read.abort(new Error("CONTENT_DISCARDED"));
    await this.#serial(async () => {
      const manifest = await this.#manifest(reference, this.#lifetime.signal, true);
      await this.#remove(`${this.#prefix}/manifest/${reference.id}`);
      await this.#remove(`${this.#prefix}/retentions/${reference.id}`);
      const chunkHashes = (manifest?.chunks ?? []).map((c) => c.hash);
      for (const h of chunkHashes) this.#cas.unpin(h);
      if (chunkHashes.length > 0) await this.#cas.deleteNodes(chunkHashes, "public");
      await this.#dropCacheEntry("private", reference.id);
    });
  }
  async #localBlobInfo(hash, signal) {
    signal.throwIfAborted();
    this.#reader();
    const st = await awaitOwnedTask(signal, () => statBlobDag(this.#cas, hash, "public"));
    if (st === null) return null;
    signal.throwIfAborted();
    return { hash, bytes: st.bytes };
  }
  /** Verified leaf list of a local blob, or null when it is not (fully indexed) here. */
  async #localBlobIndex(hash, signal) {
    signal.throwIfAborted();
    this.#reader();
    try {
      return await awaitOwnedTask(signal, () => blobDagIndex(this.#cas, hash, "public"));
    } catch (error) {
      signal.throwIfAborted();
      if (error instanceof Error && error.message.startsWith("CAS_BLOB_")) return null;
      throw error;
    }
  }
  /** Pull every leaf of a verified blob index through the windowed puller; leaves are hashed once on arrival. */
  async #pullBlob(hash, bytes, leaves, interior, first, cache, signal) {
    const ordered = [first, ...[...this.#sources.values()].filter((source2) => source2 !== first)];
    const sources = ordered.filter((source2) => source2.blobChunks !== void 0 || source2.blobChunk !== void 0).map((source2) => rangeOf(
      source2.blobChunks === void 0 ? void 0 : (start, count, sink, s) => source2.blobChunks(hash, start, count, sink, { signal: s }),
      async (i, s) => source2.blobChunk === void 0 ? null : source2.blobChunk(hash, i, { signal: s })
    ));
    const assembled = new Uint8Array(bytes);
    const puller = new ChunkPuller({
      count: leaves.length,
      sources,
      signal,
      missing: "CONTENT_BLOB_MISSING",
      windowChunks: CONTENT_FETCH_WINDOW_BYTES / CONTENT_CHUNK_BYTES,
      initialWindow: CONTENT_FETCH_WINDOW_BYTES / CONTENT_CHUNK_BYTES,
      local: async (i, s) => {
        const node = await awaitOwnedTask(s, () => this.#cas.get(leaves[i].hash, "public", { cache: false }));
        return node !== null && node.links.length === 0 && node.bytes.length === leaves[i].bytes ? node.bytes : null;
      },
      accept: async (i, chunk, s) => {
        const leaf = leaves[i];
        check(chunk instanceof Uint8Array && chunk.byteLength === leaf.bytes, "CONTENT_BLOB_INVALID");
        if (!cache) {
          check(computeCasHash(chunk, []) === leaf.hash, "CONTENT_BLOB_INVALID");
          return chunk;
        }
        await this.#serial(async () => {
          s.throwIfAborted();
          this.#reader();
          try {
            await this.#cas.putVerified(leaf.hash, chunk, [], "public", { cache: false });
          } catch (error) {
            throw error instanceof Error && error.message === "CAS_HASH_MISMATCH" ? new Error("CONTENT_BLOB_INVALID") : error;
          }
        });
        return chunk;
      }
    });
    try {
      for (let index = 0; index < leaves.length; index++) assembled.set(await puller.take(index), index * CONTENT_CHUNK_BYTES);
    } finally {
      puller.close();
    }
    signal.throwIfAborted();
    if (cache) {
      await this.#serial(async () => {
        signal.throwIfAborted();
        this.#reader();
        for (let index = interior.length - 1; index >= 0; index--) await this.#cas.putVerified(interior[index].hash, interior[index].bytes, interior[index].links, "public");
        await this.#touchCacheEntry("public", hash, bytes);
      });
    }
    return assembled;
  }
  async #storeLocalBlob(bytes, signal) {
    let info;
    await this.#serial(async () => {
      signal.throwIfAborted();
      this.#reader();
      const stored = await putBlobDag(this.#cas, bytes, "public");
      info = { hash: stored.hash, bytes: stored.bytes };
      await this.#touchCacheEntry("public", info.hash, info.bytes);
    });
    return info;
  }
  /** Store bytes into unified Merkle-DAG CAS (chronolog-blob/v1) so peers and reducers share one hash space. */
  async putBlob(input, options = {}) {
    this.#reader();
    check(input instanceof Uint8Array && input.byteLength <= MAX_BLOB_BYTES, "CONTENT_RANGE_INVALID");
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    signal.throwIfAborted();
    const bytes = input.slice();
    return this.#storeLocalBlob(bytes, signal);
  }
  async hasBlob(hash) {
    this.#reader();
    check(digest(hash), "CONTENT_BLOB_INVALID");
    try {
      const data = await readBlobDag(this.#cas, hash, "public", { maxBytes: MAX_BLOB_BYTES });
      return data !== null;
    } catch {
      return false;
    }
  }
  /** Retrieve a CAS chronolog-blob/v1 locally, falling back to connected peers and verifying the CAS root hash. */
  async getBlob(hash, options = {}) {
    check(digest(hash), "CONTENT_BLOB_INVALID");
    const maxBytes = options.maxBytes ?? MAX_BLOB_BYTES;
    check(Number.isSafeInteger(maxBytes) && maxBytes >= 0 && maxBytes <= MAX_BLOB_BYTES, "CONTENT_READ_LIMIT_INVALID");
    if (options.expectedBytes !== void 0) {
      check(Number.isSafeInteger(options.expectedBytes) && options.expectedBytes >= 0 && options.expectedBytes <= MAX_BLOB_BYTES, "CONTENT_BLOB_INVALID");
      check(options.expectedBytes <= maxBytes, "CONTENT_READ_LIMIT_EXCEEDED");
    }
    const scope = this.#blobScope(hash, options);
    try {
      const localInfo = await this.#localBlobInfo(hash, scope.signal);
      if (localInfo !== null) {
        if (options.expectedBytes !== void 0) check(localInfo.bytes === options.expectedBytes, "CONTENT_BLOB_INVALID");
        check(localInfo.bytes <= maxBytes, "CONTENT_READ_LIMIT_EXCEEDED");
        const assembled = await awaitOwnedTask(scope.signal, () => readBlobDag(this.#cas, hash, "public", { maxBytes }));
        if (assembled !== null) {
          scope.signal.throwIfAborted();
          return assembled;
        }
      }
      if (options.localOnly === true) return null;
      let failure;
      for (const source2 of [...this.#sources.values()]) {
        try {
          if (source2.blobIndex !== void 0) {
            const index = await awaitOwnedTask(scope.signal, () => source2.blobIndex(hash, { signal: scope.signal }));
            if (index === null) continue;
            check(index !== null && typeof index === "object" && index.hash === hash && Array.isArray(index.nodes) && index.nodes.length <= 64, "CONTENT_BLOB_INVALID");
            assertBlobInfo({ hash: index.hash, bytes: index.bytes });
            if (options.expectedBytes !== void 0) check(index.bytes === options.expectedBytes, "CONTENT_BLOB_INVALID");
            check(index.bytes <= maxBytes, "CONTENT_READ_LIMIT_EXCEEDED");
            let verified;
            try {
              verified = verifyBlobDagIndex(hash, index.bytes, index.nodes);
            } catch {
              throw new Error("CONTENT_BLOB_INVALID");
            }
            return await this.#pullBlob(hash, index.bytes, verified.leaves, verified.interior, source2, options.cache !== false, scope.signal);
          }
          if (source2.blobInfo === void 0 || source2.blobChunk === void 0) continue;
          const info = await awaitOwnedTask(scope.signal, () => source2.blobInfo(hash, { signal: scope.signal }));
          if (info === null) continue;
          assertBlobInfo(info);
          check(info.hash === hash, "CONTENT_BLOB_INVALID");
          if (options.expectedBytes !== void 0) check(info.bytes === options.expectedBytes, "CONTENT_BLOB_INVALID");
          check(info.bytes <= maxBytes, "CONTENT_READ_LIMIT_EXCEEDED");
          const count = Math.ceil(info.bytes / CONTENT_CHUNK_BYTES);
          const assembled = new Uint8Array(info.bytes);
          for (let index = 0; index < count; index++) {
            const expectedLen = Math.min(CONTENT_CHUNK_BYTES, info.bytes - index * CONTENT_CHUNK_BYTES);
            const chunk = await awaitOwnedTask(scope.signal, () => source2.blobChunk(hash, index, { signal: scope.signal }));
            check(chunk instanceof Uint8Array && chunk.byteLength === expectedLen, "CONTENT_BLOB_INVALID");
            assembled.set(chunk, index * CONTENT_CHUNK_BYTES);
          }
          check(computeBlobDagHash(assembled) === hash, "CONTENT_BLOB_INVALID");
          scope.signal.throwIfAborted();
          if (options.cache !== false) await this.#storeLocalBlob(assembled, scope.signal);
          return assembled;
        } catch (error) {
          scope.signal.throwIfAborted();
          failure = error;
        }
      }
      if (failure !== void 0) throw failure instanceof Error ? failure : new Error("CONTENT_SOURCE_FAILED", { cause: failure });
      return null;
    } finally {
      scope.release();
    }
  }
  async deleteBlob(hash) {
    this.#reader();
    check(digest(hash), "CONTENT_BLOB_INVALID");
    for (const read of this.#reads.get(`blob:${hash}`) ?? []) read.abort(new Error("CONTENT_DISCARDED"));
    await this.#serial(async () => {
      this.#cas.unpin(hash);
      const nodes = await this.#cas.reachable([hash]);
      if (nodes.size > 0) await this.#cas.deleteNodes(nodes, "public");
      await this.#dropCacheEntry("public", hash);
    });
  }
  /** Serve only verified local bytes. Serving never recursively consults remote sources. */
  source() {
    const range = (count, start, length) => {
      check(Number.isSafeInteger(start) && Number.isSafeInteger(length) && start >= 0 && length > 0 && start + length <= count, "CONTENT_CHUNK_INDEX_INVALID");
    };
    const chunks = async (input, start, count, onChunk, options = {}) => {
      const reference = this.#reference(input), scope = this.#readScope(reference, options);
      try {
        range(Math.ceil(reference.bytes / CONTENT_CHUNK_BYTES), start, count);
        const manifest = await this.#manifest(reference, scope.signal, true);
        for (let index = start; index < start + count; index++) await onChunk(index, manifest === null ? null : await this.#localChunk(reference, manifest, index, scope.signal));
      } finally {
        scope.release();
      }
    };
    const blobChunks = async (hash, start, count, onChunk, options = {}) => {
      check(digest(hash), "CONTENT_BLOB_INVALID");
      const scope = this.#blobScope(hash, options);
      try {
        check(Number.isSafeInteger(start) && Number.isSafeInteger(count) && start >= 0 && count > 0 && start + count <= MAX_BLOB_BYTES / CONTENT_CHUNK_BYTES, "CONTENT_CHUNK_INDEX_INVALID");
        const index = await this.#localBlobIndex(hash, scope.signal);
        for (let i = start; i < start + count; i++) {
          const leaf = index?.leaves[i];
          const node = leaf === void 0 ? null : await awaitOwnedTask(scope.signal, () => this.#cas.get(leaf.hash, "public", { cache: false }));
          await onChunk(i, node === null || node.links.length !== 0 ? null : node.bytes);
        }
      } finally {
        scope.release();
      }
    };
    const one = async (run) => {
      let value = null;
      await run((_index, bytes) => {
        value = bytes;
      });
      return value;
    };
    return {
      manifest: async (input, options = {}) => {
        const reference = this.#reference(input), scope = this.#readScope(reference, options);
        try {
          return await this.#manifest(reference, scope.signal, true);
        } finally {
          scope.release();
        }
      },
      chunk: (input, index, options = {}) => one((sink) => chunks(input, index, 1, sink, options)),
      chunks,
      retained: async (input, options = {}) => {
        const reference = this.#reference(input), scope = this.#readScope(reference, options);
        try {
          const manifest = await this.#manifest(reference, scope.signal, true);
          check(manifest !== null, "CONTENT_MANIFEST_MISSING");
          for (let index = 0; index < manifest.chunks.length; index++) check(await this.#localChunk(reference, manifest, index, scope.signal) !== null, "CONTENT_INCOMPLETE");
          return await this.#receipt(reference, scope.signal);
        } finally {
          scope.release();
        }
      },
      blobInfo: async (hash, options = {}) => {
        check(digest(hash), "CONTENT_BLOB_INVALID");
        const scope = this.#blobScope(hash, options);
        try {
          return await this.#localBlobInfo(hash, scope.signal);
        } finally {
          scope.release();
        }
      },
      blobIndex: async (hash, options = {}) => {
        check(digest(hash), "CONTENT_BLOB_INVALID");
        const scope = this.#blobScope(hash, options);
        try {
          const index = await this.#localBlobIndex(hash, scope.signal);
          return index === null ? null : { hash, bytes: index.bytes, nodes: index.nodes };
        } finally {
          scope.release();
        }
      },
      blobChunk: (hash, index, options = {}) => one((sink) => blobChunks(hash, index, 1, sink, options)),
      blobChunks
    };
  }
  putBytes(bytes, options) {
    return putContentBytes(this, bytes, options);
  }
  readBytes(reference, options) {
    return readContentBytes(this, reference, options);
  }
  /**
   * Keyed-convergent deterministic encryption under the current epoch key:
   * identical plaintext uploaded by different readers in the same epoch produces
   * the exact same `ContentReference` and chunk hashes, while remaining opaque
   * to any party without the epoch key.
   */
  async #putPrivateConvergent(input, options = {}) {
    this.#reader();
    check(input instanceof Uint8Array && input.byteLength <= MAX_CONTENT_BYTES, "CONTENT_RANGE_INVALID");
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    signal.throwIfAborted();
    const bytes = input.slice();
    const epoch = this.#options.authority.currentEpoch();
    const mediaType = options.mediaType ?? "application/octet-stream";
    const refBody = {
      profile: "authored-content-v1",
      applicationId: this.#options.authority.applicationId,
      epoch,
      bytes: bytes.byteLength,
      mediaType
    };
    assertReferenceBody(refBody);
    const epochKey = this.#options.authority.epochKey(epoch);
    check(epochKey !== null, "CONTENT_KEY_MISSING");
    const plainDigest = await awaitOwnedTask(signal, () => sha256(bytes));
    const stageBytes = await awaitOwnedTask(
      signal,
      () => sha256(concatBytes(utf8("chronolog/convergent-stage/v2:"), epochKey, utf8(this.#prefix), utf8(mediaType), plainDigest))
    );
    const uuidHex = bytesToHex(stageBytes.subarray(0, 16));
    const id = `${uuidHex.slice(0, 8)}-${uuidHex.slice(8, 12)}-4${uuidHex.slice(13, 16)}-8${uuidHex.slice(17, 20)}-${uuidHex.slice(20, 32)}`;
    const count = Math.ceil(bytes.byteLength / CONTENT_CHUNK_BYTES);
    const encryptedChunks = [];
    for (let index = 0; index < count; index++) {
      signal.throwIfAborted();
      const plainChunk = bytes.subarray(index * CONTENT_CHUNK_BYTES, Math.min(bytes.byteLength, (index + 1) * CONTENT_CHUNK_BYTES));
      const nonceDigest = await awaitOwnedTask(
        signal,
        () => sha256(concatBytes(utf8("chronolog/convergent-nonce/v2:"), epochKey, utf8(this.#prefix), plainDigest, utf8(`:${index}`)))
      );
      const encrypted = encodeChunk(await awaitOwnedTask(
        signal,
        () => encryptEpochPayload(epochKey, BigInt(epoch), plainChunk, encodeRecord([this.#prefix, id, index]), nonceDigest.subarray(0, 12))
      ));
      const hash = computeCasHash(encrypted, []);
      encryptedChunks.push({ hash, bytes: encrypted });
    }
    const manifest = {
      stageId: id,
      reference: refBody,
      chunks: encryptedChunks.map((c) => ({ hash: c.hash, bytes: c.bytes.length }))
    };
    const reference = { ...refBody, id: await recordDigest(manifest) };
    await this.#serial(async () => {
      signal.throwIfAborted();
      this.#reader();
      const encManifestChunks = [];
      for (let index = 0; index < encryptedChunks.length; index++) {
        const chunk = encryptedChunks[index];
        await this.#cas.put(chunk.bytes, [], "public", { cache: false });
        encManifestChunks.push({
          hash: chunk.hash,
          bytes: chunk.bytes.length,
          plainBytes: Math.min(CONTENT_CHUNK_BYTES, bytes.byteLength - index * CONTENT_CHUNK_BYTES)
        });
      }
      const encCas = encodeEncBlobManifest({
        format: "chronolog-enc-blob/v1",
        applicationId: refBody.applicationId,
        epoch: refBody.epoch,
        bytes: refBody.bytes,
        mediaType: refBody.mediaType,
        stageId: id,
        chunks: encManifestChunks
      });
      await this.#cas.put(encCas.bytes, encCas.links, "public");
      await this.#options.store.put(`${this.#prefix}/manifest/${reference.id}`, encodeRecord(manifest));
      await this.#touchCacheEntry("private", reference.id, reference.bytes, reference);
    });
    return reference;
  }
  /** Stream an async iterable of Uint8Array chunks into private or public lazy-pull content without holding the entire file in memory. */
  async putStream(chunks, options = {}) {
    const visibility = options.visibility ?? "private";
    const mediaType = options.mediaType ?? "application/octet-stream";
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    signal.throwIfAborted();
    if (visibility === "private" && options.totalBytes !== void 0) {
      this.#reader();
      const total2 = options.totalBytes;
      check(Number.isSafeInteger(total2) && total2 >= 0 && total2 <= MAX_CONTENT_BYTES, "CONTENT_RANGE_INVALID");
      const upload = await this.stage({ bytes: total2, mediaType });
      let written = 0;
      let chunkIndex = 0;
      let buffer = new Uint8Array(0);
      try {
        for await (const part of chunks) {
          signal.throwIfAborted();
          check(part instanceof Uint8Array, "CONTENT_CHUNK_SIZE_INVALID");
          if (part.byteLength === 0) continue;
          buffer = buffer.byteLength === 0 ? part.slice() : concatBytes(buffer, part);
          while (buffer.byteLength >= CONTENT_CHUNK_BYTES) {
            const slice = buffer.subarray(0, CONTENT_CHUNK_BYTES);
            await upload.write(chunkIndex++, slice);
            written += slice.byteLength;
            buffer = buffer.subarray(CONTENT_CHUNK_BYTES);
          }
        }
        if (buffer.byteLength > 0) {
          await upload.write(chunkIndex++, buffer);
          written += buffer.byteLength;
        }
        check(written === total2, "CONTENT_INCOMPLETE");
        return await upload.commit();
      } catch (error) {
        await upload.discard().catch(() => void 0);
        throw error;
      }
    }
    const maxAllowed = visibility === "public" ? MAX_BLOB_BYTES : MAX_CONTENT_BYTES;
    const parts = [];
    let total = 0;
    for await (const part of chunks) {
      signal.throwIfAborted();
      check(part instanceof Uint8Array, "CONTENT_CHUNK_SIZE_INVALID");
      total += part.byteLength;
      check(total <= maxAllowed, "CONTENT_RANGE_INVALID");
      if (part.byteLength > 0) parts.push(part.slice());
    }
    const assembled = parts.length === 0 ? new Uint8Array(0) : concatBytes(...parts);
    return this.put(assembled, { visibility, mediaType, ...options.signal === void 0 ? {} : { signal: options.signal } });
  }
  /** Stream verified chunks for either a private ContentReference or a public PublicBlobReference / SHA-256 hash. */
  async *readStream(target, options = {}) {
    if (isPrivateContentReference(target)) {
      const ref = this.#reference(target);
      if (options.maxBytes !== void 0) check(ref.bytes <= options.maxBytes, "CONTENT_READ_LIMIT_EXCEEDED");
      for await (const chunk of this.read(ref, options.signal === void 0 ? {} : { signal: options.signal })) {
        yield chunk;
      }
      return;
    }
    const hash = typeof target === "string" ? target : isPublicBlobReference(target) ? target.hash : "";
    check(digest(hash), "CONTENT_REFERENCE_INVALID");
    const expectedBytes = options.expectedBytes ?? (isPublicBlobReference(target) ? target.bytes : void 0);
    const bytes = await this.getBlob(hash, { ...options, ...expectedBytes === void 0 ? {} : { expectedBytes } });
    if (bytes === null) throw new Error("CONTENT_BLOB_MISSING");
    for (let offset = 0; offset < bytes.byteLength; offset += CONTENT_CHUNK_BYTES) {
      yield bytes.subarray(offset, Math.min(bytes.byteLength, offset + CONTENT_CHUNK_BYTES));
    }
  }
  /** Pin a cached blob or private content item so `pruneCache()` will never evict it. */
  async pin(target) {
    this.#reader();
    const { kind, key } = this.#cacheIdOf(target);
    await this.#serial(async () => {
      const map = await this.#loadCacheIndex();
      const id = `${kind}:${key}`;
      const existing = map.get(id);
      if (existing !== void 0) {
        existing.pinned = true;
        existing.lastAccessMs = Date.now();
        await this.#saveCacheEntry(existing);
      } else {
        const created = {
          kind,
          key,
          bytes: typeof target === "string" ? 0 : target.bytes,
          lastAccessMs: Date.now(),
          pinned: true,
          ...isPrivateContentReference(target) ? { reference: this.#reference(target) } : {}
        };
        map.set(id, created);
        await this.#saveCacheEntry(created);
      }
      if (kind === "public") this.#cas.pin(key);
    });
  }
  async unpin(target) {
    this.#reader();
    const { kind, key } = this.#cacheIdOf(target);
    await this.#serial(async () => {
      const map = await this.#loadCacheIndex();
      const existing = map.get(`${kind}:${key}`);
      if (existing !== void 0) {
        existing.pinned = false;
        await this.#saveCacheEntry(existing);
      }
      if (kind === "public") this.#cas.unpin(key);
    });
  }
  async isPinned(target) {
    this.#reader();
    const { kind, key } = this.#cacheIdOf(target);
    const map = await this.#loadCacheIndex();
    return map.get(`${kind}:${key}`)?.pinned === true;
  }
  async stats() {
    this.#reader();
    const map = await this.#loadCacheIndex();
    let publicBlobs = 0;
    let privateItems = 0;
    let totalBytes = 0;
    let pinnedCount = 0;
    for (const entry of map.values()) {
      if (entry.kind === "public") publicBlobs++;
      else privateItems++;
      totalBytes += entry.bytes;
      if (entry.pinned) pinnedCount++;
    }
    return {
      publicBlobs,
      privateItems,
      totalBytes,
      pinnedCount,
      maxCacheBytes: this.#options.maxCacheBytes ?? null
    };
  }
  /** Evict oldest unpinned locally cached blobs/items down to `maxBytes` (LRU). */
  async pruneCache(options = {}) {
    this.#reader();
    const limit2 = options.maxBytes ?? this.#options.maxCacheBytes;
    check(limit2 !== void 0 && Number.isSafeInteger(limit2) && limit2 >= 0, "CONTENT_CACHE_LIMIT_INVALID");
    const map = await this.#loadCacheIndex();
    let totalBytes = 0;
    for (const entry of map.values()) totalBytes += entry.bytes;
    if (totalBytes <= limit2) {
      return { evictedCount: 0, evictedBytes: 0, remainingBytes: totalBytes };
    }
    const candidates = [...map.values()].filter((e) => !e.pinned).sort((a, b) => a.lastAccessMs - b.lastAccessMs || a.key.localeCompare(b.key));
    let evictedCount = 0;
    let evictedBytes = 0;
    for (const entry of candidates) {
      if (totalBytes - evictedBytes <= limit2) break;
      if (entry.kind === "public") {
        await this.deleteBlob(entry.key);
      } else if (entry.reference !== void 0) {
        await this.discard(entry.reference);
      } else {
        await this.#serial(() => this.#dropCacheEntry(entry.kind, entry.key));
      }
      evictedCount++;
      evictedBytes += entry.bytes;
    }
    return {
      evictedCount,
      evictedBytes,
      remainingBytes: Math.max(0, totalBytes - evictedBytes)
    };
  }
  /** Unified lazy-pull blob write: supports both public raw-SHA-256 blobs and private epoch-encrypted blobs. */
  async put(bytes, options = {}) {
    const visibility = options.visibility ?? "private";
    const mediaType = options.mediaType ?? "application/octet-stream";
    if (visibility === "public") {
      check(typeof mediaType === "string" && mediaType.length > 0 && mediaType.length <= 256 && /^[\x20-\x7e]+$/u.test(mediaType), "CONTENT_REFERENCE_INVALID");
      const info = await this.putBlob(bytes, options.signal === void 0 ? {} : { signal: options.signal });
      return { profile: "chronolog-blob-v2", visibility: "public", hash: info.hash, bytes: info.bytes, mediaType };
    }
    const putOpts = {
      mediaType,
      ...options.signal === void 0 ? {} : { signal: options.signal }
    };
    return options.deduplicate === true ? this.#putPrivateConvergent(bytes, putOpts) : this.putBytes(bytes, putOpts);
  }
  /** Unified lazy-pull blob read: accepts a raw SHA-256 hex hash, a PublicBlobReference, or a private ContentReference. */
  async get(target, options = {}) {
    if (typeof target === "string") {
      return this.getBlob(target, options);
    }
    if (isPublicBlobReference(target)) {
      return this.getBlob(target.hash, {
        ...options,
        expectedBytes: options.expectedBytes ?? target.bytes
      });
    }
    if (isPrivateContentReference(target)) {
      try {
        return await this.readBytes(target, {
          maxBytes: options.maxBytes ?? target.bytes,
          ...options.signal === void 0 ? {} : { signal: options.signal }
        });
      } catch (error) {
        if (error instanceof Error && (error.message === "CONTENT_MANIFEST_MISSING" || error.message === "CONTENT_CHUNK_MISSING")) {
          return null;
        }
        throw error;
      }
    }
    throw new Error("CONTENT_REFERENCE_INVALID");
  }
  async close() {
    this.#lifetime.abort(new Error("CONTENT_CLOSED"));
    this.#sources.clear();
    await this.#tail;
  }
};

// packages/peer-session/src/network-content.ts
var CONTENT_NETWORK_LIMITS = Object.freeze({
  pending: 16,
  active: 16,
  rangeChunks: 16,
  timeoutMs: 3e4,
  chunkBytes: MAX_CONTENT_ENCRYPTED_CHUNK_BYTES,
  blobNodes: 64,
  blobNodeBytes: 16 * 1024
});
var RESPONSE = {
  manifest: "manifest-response",
  chunks: "chunk-response",
  retain: "retain-response",
  "blob-info": "blob-info-response",
  "blob-chunks": "blob-chunk-response"
};
var digest2 = (value) => typeof value === "string" && /^[0-9a-f]{64}$/u.test(value);
function fields(value, keys) {
  check(Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), "CONTENT_WIRE_INVALID");
}
function rangeValid(start, count, total) {
  return Number.isSafeInteger(start) && Number.isSafeInteger(count) && Number(start) >= 0 && Number(count) > 0 && Number(count) <= CONTENT_NETWORK_LIMITS.rangeChunks && Number(start) + Number(count) <= total;
}
function chunkValid(index, bytes, maxIndex, maxBytes) {
  return Number.isSafeInteger(index) && Number(index) >= 0 && Number(index) < maxIndex && (bytes === null || bytes instanceof Uint8Array && bytes.length <= maxBytes);
}
function assertContentWireMessage(input) {
  check(input !== null && typeof input === "object" && !Array.isArray(input), "CONTENT_WIRE_INVALID");
  const value = input;
  check(typeof value.id === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u.test(value.id), "CONTENT_WIRE_INVALID");
  switch (value.type) {
    case "manifest-request":
    case "retain-request":
      fields(value, ["type", "id", "reference"]);
      assertContentReference(value.reference);
      break;
    case "chunks-request":
      fields(value, ["type", "id", "reference", "start", "count"]);
      assertContentReference(value.reference);
      check(rangeValid(value.start, value.count, Math.min(MAX_CONTENT_CHUNKS, Math.ceil(value.reference.bytes / CONTENT_CHUNK_BYTES))), "CONTENT_WIRE_CHUNK_INVALID");
      break;
    case "blob-info-request":
      fields(value, ["type", "id", "hash"]);
      check(digest2(value.hash), "CONTENT_WIRE_INVALID");
      break;
    case "blob-chunks-request":
      fields(value, ["type", "id", "hash", "start", "count"]);
      check(digest2(value.hash) && rangeValid(value.start, value.count, MAX_BLOB_CHUNKS), "CONTENT_WIRE_CHUNK_INVALID");
      break;
    case "manifest-response":
      fields(value, ["type", "id", "manifest"]);
      if (value.manifest !== null) assertContentManifest(value.manifest);
      break;
    case "chunk-response":
      fields(value, ["type", "id", "index", "bytes"]);
      check(chunkValid(value.index, value.bytes, MAX_CONTENT_CHUNKS, MAX_CONTENT_ENCRYPTED_CHUNK_BYTES), "CONTENT_WIRE_CHUNK_INVALID");
      break;
    case "blob-info-response":
      fields(value, ["type", "id", "bytes", "nodes"]);
      check(value.bytes === null || Number.isSafeInteger(value.bytes) && Number(value.bytes) >= 0 && Number(value.bytes) <= MAX_BLOB_BYTES, "CONTENT_WIRE_INVALID");
      check(Array.isArray(value.nodes) && value.nodes.length <= CONTENT_NETWORK_LIMITS.blobNodes && (value.bytes !== null || value.nodes.length === 0) && value.nodes.every((node) => node instanceof Uint8Array && node.length > 0 && node.length <= CONTENT_NETWORK_LIMITS.blobNodeBytes), "CONTENT_WIRE_INVALID");
      break;
    case "blob-chunk-response":
      fields(value, ["type", "id", "index", "bytes"]);
      check(chunkValid(value.index, value.bytes, MAX_BLOB_CHUNKS, CONTENT_CHUNK_BYTES), "CONTENT_WIRE_CHUNK_INVALID");
      break;
    case "retain-response":
      fields(value, ["type", "id", "receipt"]);
      assertContentRetention(value.receipt);
      break;
    case "error":
      fields(value, ["type", "id", "code"]);
      check(["CONTENT_UNAVAILABLE", "CONTENT_FORBIDDEN", "CONTENT_BUSY"].includes(String(value.code)), "CONTENT_WIRE_INVALID");
      break;
    case "cancel":
      fields(value, ["type", "id"]);
      break;
    default:
      throw new Error("CONTENT_WIRE_INVALID");
  }
}
function createNetworkContent(options) {
  options.signal.throwIfAborted();
  check(/^[0-9a-f]{64}$/u.test(options.peerId), "CONTENT_PEER_INVALID");
  const lifetime = new AbortController(), signal = AbortSignal.any([options.signal, lifetime.signal]);
  const pending = /* @__PURE__ */ new Map(), active = /* @__PURE__ */ new Map();
  const local = options.content.source();
  const allowed = () => {
    signal.throwIfAborted();
    check(options.authorize() === true, "CONTENT_FORBIDDEN");
  };
  const close = () => {
    if (lifetime.signal.aborted) return;
    lifetime.abort(new Error("CONTENT_NETWORK_CLOSED"));
    options.signal.removeEventListener("abort", close);
    detach();
    for (const waiter of pending.values()) {
      waiter.cleanup();
      waiter.reject(signal.reason);
    }
    pending.clear();
    for (const controller of active.values()) controller.abort(signal.reason);
    active.clear();
  };
  const send = async (message) => {
    allowed();
    try {
      await awaitOwnedTask(signal, () => options.send(message));
      allowed();
    } catch (error) {
      close();
      throw error;
    }
  };
  const cancel = (id) => {
    if (!signal.aborted && options.authorize()) void send({ type: "cancel", id }).catch(() => void 0);
  };
  const sendRequest = (action, build, input, stream) => {
    allowed();
    input.signal?.throwIfAborted();
    check(pending.size < CONTENT_NETWORK_LIMITS.pending, "CONTENT_REQUEST_LIMIT");
    const id = crypto.randomUUID(), requestSignal = input.signal;
    const message = build(id);
    assertContentWireMessage(message);
    return new Promise((resolve, reject) => {
      const finish = (error) => {
        const waiter = pending.get(id);
        if (waiter === void 0) return;
        pending.delete(id);
        waiter.cleanup();
        reject(error);
        cancel(id);
      };
      const abort = () => finish(requestSignal?.reason instanceof Error ? requestSignal.reason : new Error("CONTENT_REQUEST_ABORTED"));
      let timer = setTimeout(() => finish(new Error("CONTENT_REQUEST_TIMEOUT")), CONTENT_NETWORK_LIMITS.timeoutMs);
      const touch = () => {
        clearTimeout(timer);
        timer = setTimeout(() => finish(new Error("CONTENT_REQUEST_TIMEOUT")), CONTENT_NETWORK_LIMITS.timeoutMs);
      };
      const cleanup = () => {
        clearTimeout(timer);
        requestSignal?.removeEventListener("abort", abort);
      };
      pending.set(id, { action, ...stream === void 0 ? {} : { stream }, resolve, reject, touch, cleanup });
      requestSignal?.addEventListener("abort", abort, { once: true });
      void send(message).catch((error) => {
        const waiter = pending.get(id);
        if (waiter !== void 0) {
          pending.delete(id);
          cleanup();
          reject(error);
        }
      });
    });
  };
  const collectOne = async (run) => {
    let value = null;
    await run((_index, bytes) => {
      value = bytes;
    });
    return value;
  };
  const chunks = async (reference, start, count, onChunk, input = {}) => {
    assertContentReference(reference);
    await sendRequest("chunks", (id) => ({ type: "chunks-request", id, reference: { ...reference }, start, count }), input, { next: start, end: start + count, onChunk });
    allowed();
    input.signal?.throwIfAborted();
  };
  const blobChunks = async (hash, start, count, onChunk, input = {}) => {
    check(digest2(hash), "CONTENT_BLOB_INVALID");
    await sendRequest("blob-chunks", (id) => ({ type: "blob-chunks-request", id, hash, start, count }), input, { next: start, end: start + count, onChunk });
    allowed();
    input.signal?.throwIfAborted();
  };
  const blobIndex = async (hash, input = {}) => {
    check(digest2(hash), "CONTENT_BLOB_INVALID");
    const response = await sendRequest("blob-info", (id) => ({ type: "blob-info-request", id, hash }), input);
    check(response.type === "blob-info-response", "CONTENT_RESPONSE_INVALID");
    allowed();
    input.signal?.throwIfAborted();
    return response.bytes === null ? null : { hash, bytes: response.bytes, nodes: response.nodes };
  };
  const detach = options.content.attachSource(`network:${options.peerId}:${crypto.randomUUID()}`, {
    async manifest(reference, input = {}) {
      assertContentReference(reference);
      const response = await sendRequest("manifest", (id) => ({ type: "manifest-request", id, reference: { ...reference } }), input);
      check(response.type === "manifest-response", "CONTENT_RESPONSE_INVALID");
      return response.manifest;
    },
    chunk: (reference, index, input = {}) => collectOne((sink) => chunks(reference, index, 1, sink, input)),
    chunks,
    async retained(reference, input = {}) {
      assertContentReference(reference);
      const response = await sendRequest("retain", (id) => ({ type: "retain-request", id, reference: { ...reference } }), input);
      check(response.type === "retain-response", "CONTENT_RESPONSE_INVALID");
      await options.content.verifyRetention(reference, response.receipt, options.peerId);
      allowed();
      input.signal?.throwIfAborted();
      return response.receipt;
    },
    async blobInfo(hash, input = {}) {
      const index = await blobIndex(hash, input);
      return index === null ? null : { hash, bytes: index.bytes };
    },
    blobIndex,
    blobChunk: (hash, index, input = {}) => collectOne((sink) => blobChunks(hash, index, 1, sink, input)),
    blobChunks
  });
  options.signal.addEventListener("abort", close, { once: true });
  if (options.signal.aborted) close();
  const serve = async (message, controller) => {
    let timer = setTimeout(() => controller.abort(new Error("CONTENT_REQUEST_TIMEOUT")), CONTENT_NETWORK_LIMITS.timeoutMs);
    const touch = () => {
      clearTimeout(timer);
      timer = setTimeout(() => controller.abort(new Error("CONTENT_REQUEST_TIMEOUT")), CONTENT_NETWORK_LIMITS.timeoutMs);
    };
    const requestSignal = AbortSignal.any([signal, controller.signal]);
    const stream = (type) => async (index, bytes) => {
      requestSignal.throwIfAborted();
      allowed();
      await send({ type, id: message.id, index, bytes });
      touch();
    };
    try {
      allowed();
      requestSignal.throwIfAborted();
      let response;
      if (message.type === "manifest-request") response = { type: "manifest-response", id: message.id, manifest: await awaitOwnedTask(requestSignal, () => local.manifest(message.reference, { signal: requestSignal })) };
      else if (message.type === "chunks-request") await awaitOwnedTask(requestSignal, () => local.chunks(message.reference, message.start, message.count, stream("chunk-response"), { signal: requestSignal }));
      else if (message.type === "blob-info-request") {
        const index = await awaitOwnedTask(requestSignal, () => local.blobIndex(message.hash, { signal: requestSignal }));
        response = { type: "blob-info-response", id: message.id, bytes: index === null ? null : index.bytes, nodes: index === null ? [] : index.nodes };
      } else if (message.type === "blob-chunks-request") await awaitOwnedTask(requestSignal, () => local.blobChunks(message.hash, message.start, message.count, stream("blob-chunk-response"), { signal: requestSignal }));
      else response = { type: "retain-response", id: message.id, receipt: await awaitOwnedTask(requestSignal, () => options.content.retain(message.reference, { signal: requestSignal })) };
      if (response !== void 0) {
        requestSignal.throwIfAborted();
        allowed();
        await send(response);
      }
    } catch {
      if (!requestSignal.aborted && !signal.aborted) await send({ type: "error", id: message.id, code: options.authorize() ? "CONTENT_UNAVAILABLE" : "CONTENT_FORBIDDEN" }).catch(() => void 0);
    } finally {
      clearTimeout(timer);
      if (active.get(message.id) === controller) active.delete(message.id);
    }
  };
  return { close, async handle(message) {
    allowed();
    assertContentWireMessage(message);
    if (message.type === "cancel") {
      active.get(message.id)?.abort(new Error("CONTENT_REQUEST_CANCELLED"));
      return;
    }
    if (message.type === "manifest-request" || message.type === "chunks-request" || message.type === "retain-request" || message.type === "blob-info-request" || message.type === "blob-chunks-request") {
      check(!active.has(message.id), "CONTENT_REQUEST_DUPLICATE");
      if (active.size >= CONTENT_NETWORK_LIMITS.active) {
        await send({ type: "error", id: message.id, code: "CONTENT_BUSY" });
        return;
      }
      const controller = new AbortController();
      active.set(message.id, controller);
      void serve(message, controller).catch(() => close());
      return;
    }
    const waiter = pending.get(message.id);
    if (waiter === void 0) return;
    check(message.type === "error" || message.type === RESPONSE[waiter.action], "CONTENT_RESPONSE_INVALID");
    if (message.type === "error") {
      pending.delete(message.id);
      waiter.cleanup();
      waiter.reject(new Error(message.code));
      return;
    }
    const stream = waiter.stream;
    if (stream === void 0) {
      pending.delete(message.id);
      waiter.cleanup();
      waiter.resolve(message);
      return;
    }
    check((message.type === "chunk-response" || message.type === "blob-chunk-response") && message.index === stream.next, "CONTENT_RESPONSE_INVALID");
    stream.next++;
    waiter.touch();
    try {
      const handed = stream.onChunk(message.index, message.bytes);
      if (handed instanceof Promise) handed.catch(() => void 0);
    } catch {
    }
    if (stream.next === stream.end) {
      pending.delete(message.id);
      waiter.cleanup();
      waiter.resolve(message);
    }
  } };
}

// packages/peer-session/src/wire-codec.ts
var BIGINT_TAG = 48;
var textEncoder = new TextEncoder();
var textDecoder = new TextDecoder("utf-8", { fatal: true });
var DEFAULT_LIMITS = { maxDepth: 32, maxItems: 1e6 };
var Writer = class {
  #buf = new Uint8Array(1024);
  #view = new DataView(this.#buf.buffer);
  #len = 0;
  #ensure(extra) {
    if (this.#len + extra <= this.#buf.length) return;
    let size = this.#buf.length * 2;
    while (size < this.#len + extra) size *= 2;
    const next = new Uint8Array(size);
    next.set(this.#buf.subarray(0, this.#len));
    this.#buf = next;
    this.#view = new DataView(next.buffer);
  }
  head(major, value) {
    this.#ensure(9);
    const m = major << 5;
    if (value < 24) this.#buf[this.#len++] = m | value;
    else if (value < 256) {
      this.#buf[this.#len++] = m | 24;
      this.#buf[this.#len++] = value;
    } else if (value < 65536) {
      this.#buf[this.#len++] = m | 25;
      this.#view.setUint16(this.#len, value);
      this.#len += 2;
    } else if (value < 4294967296) {
      this.#buf[this.#len++] = m | 26;
      this.#view.setUint32(this.#len, value);
      this.#len += 4;
    } else {
      this.#buf[this.#len++] = m | 27;
      this.#view.setBigUint64(this.#len, BigInt(value));
      this.#len += 8;
    }
  }
  bytes(bytes) {
    this.#ensure(bytes.length);
    this.#buf.set(bytes, this.#len);
    this.#len += bytes.length;
  }
  float(value) {
    this.#ensure(9);
    this.#buf[this.#len++] = 251;
    this.#view.setFloat64(this.#len, value);
    this.#len += 8;
  }
  byte(value) {
    this.#ensure(1);
    this.#buf[this.#len++] = value;
  }
  result() {
    return this.#buf.slice(0, this.#len);
  }
};
function write(w, value, depth) {
  if (depth > 64) throw new Error("WIRE_ENCODE_DEPTH");
  if (value === null || value === void 0) {
    w.byte(246);
    return;
  }
  if (value === false) {
    w.byte(244);
    return;
  }
  if (value === true) {
    w.byte(245);
    return;
  }
  if (typeof value === "number") {
    if (Number.isSafeInteger(value)) {
      if (value >= 0) w.head(0, value);
      else w.head(1, -1 - value);
      return;
    }
    if (!Number.isFinite(value)) throw new Error("WIRE_ENCODE_NUMBER");
    w.float(value);
    return;
  }
  if (typeof value === "bigint") {
    w.head(6, BIGINT_TAG);
    const text = textEncoder.encode(value.toString());
    w.head(3, text.length);
    w.bytes(text);
    return;
  }
  if (typeof value === "string") {
    const text = textEncoder.encode(value);
    w.head(3, text.length);
    w.bytes(text);
    return;
  }
  if (value instanceof Uint8Array) {
    w.head(2, value.length);
    w.bytes(value);
    return;
  }
  if (Array.isArray(value)) {
    w.head(4, value.length);
    for (const item of value) write(w, item, depth + 1);
    return;
  }
  if (typeof value === "object") {
    const entries = Object.entries(value).filter(([, v]) => v !== void 0);
    w.head(5, entries.length);
    for (const [key, item] of entries) {
      const text = textEncoder.encode(key);
      w.head(3, text.length);
      w.bytes(text);
      write(w, item, depth + 1);
    }
    return;
  }
  throw new Error("WIRE_ENCODE_UNSUPPORTED");
}
function encodeWireValue(value) {
  const w = new Writer();
  write(w, value, 0);
  return w.result();
}
var Reader = class {
  constructor(input, limits) {
    this.input = input;
    this.limits = limits;
    this.#view = new DataView(input.buffer, input.byteOffset, input.byteLength);
  }
  input;
  limits;
  #pos = 0;
  #items = 0;
  #view;
  get done() {
    return this.#pos === this.input.length;
  }
  #need(n) {
    if (this.#pos + n > this.input.length) throw new Error("WIRE_DECODE_TRUNCATED");
  }
  #arg(additional) {
    if (additional < 24) return additional;
    if (additional === 24) {
      this.#need(1);
      return this.input[this.#pos++];
    }
    if (additional === 25) {
      this.#need(2);
      const v = this.#view.getUint16(this.#pos);
      this.#pos += 2;
      return v;
    }
    if (additional === 26) {
      this.#need(4);
      const v = this.#view.getUint32(this.#pos);
      this.#pos += 4;
      return v;
    }
    if (additional === 27) {
      this.#need(8);
      const v = this.#view.getBigUint64(this.#pos);
      this.#pos += 8;
      if (v > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("WIRE_DECODE_RANGE");
      return Number(v);
    }
    throw new Error("WIRE_DECODE_INVALID");
  }
  #text(length) {
    this.#need(length);
    const value = textDecoder.decode(this.input.subarray(this.#pos, this.#pos + length));
    this.#pos += length;
    return value;
  }
  value(depth) {
    if (depth > this.limits.maxDepth) throw new Error("WIRE_DECODE_DEPTH");
    if (++this.#items > this.limits.maxItems) throw new Error("WIRE_DECODE_ITEMS");
    this.#need(1);
    const initial = this.input[this.#pos++], major = initial >> 5, additional = initial & 31;
    if (major === 7) {
      if (additional === 20) return false;
      if (additional === 21) return true;
      if (additional === 22) return null;
      if (additional === 27) {
        this.#need(8);
        const v = this.#view.getFloat64(this.#pos);
        this.#pos += 8;
        return v;
      }
      throw new Error("WIRE_DECODE_INVALID");
    }
    const arg = this.#arg(additional);
    switch (major) {
      case 0:
        return arg;
      case 1:
        return -1 - arg;
      case 2: {
        this.#need(arg);
        const out = this.input.slice(this.#pos, this.#pos + arg);
        this.#pos += arg;
        return out;
      }
      case 3:
        return this.#text(arg);
      case 4: {
        if (arg > this.input.length - this.#pos) throw new Error("WIRE_DECODE_TRUNCATED");
        const out = new Array(arg);
        for (let i = 0; i < arg; i++) out[i] = this.value(depth + 1);
        return out;
      }
      case 5: {
        if (arg > this.input.length - this.#pos) throw new Error("WIRE_DECODE_TRUNCATED");
        const out = /* @__PURE__ */ Object.create(null);
        for (let i = 0; i < arg; i++) {
          this.#need(1);
          const keyHead = this.input[this.#pos++];
          if (keyHead >> 5 !== 3) throw new Error("WIRE_DECODE_KEY");
          const key = this.#text(this.#arg(keyHead & 31));
          if (key === "__proto__") throw new Error("WIRE_DECODE_KEY");
          out[key] = this.value(depth + 1);
        }
        return Object.assign({}, out);
      }
      case 6: {
        if (arg !== BIGINT_TAG) throw new Error("WIRE_DECODE_TAG");
        const inner = this.value(depth + 1);
        if (typeof inner !== "string" || !/^-?\d{1,80}$/u.test(inner)) throw new Error("WIRE_DECODE_BIGINT");
        return BigInt(inner);
      }
      default:
        throw new Error("WIRE_DECODE_INVALID");
    }
  }
};
function decodeWireValue(input, limits = DEFAULT_LIMITS) {
  const reader = new Reader(input, limits);
  const value = reader.value(0);
  if (!reader.done) throw new Error("WIRE_DECODE_TRAILING");
  return value;
}

// packages/peer-session/src/network-wire.ts
var APPLICATION_NETWORK_LIMITS = Object.freeze({
  messageBytes: 32 * 1024 * 1024,
  fragmentBytes: 48 * 1024,
  queuedMessages: 8,
  queuedBytes: 32 * 1024 * 1024,
  pendingRequests: 4,
  incomingRequests: 4,
  rangeCommands: 32,
  rangeBytes: 4 * 1024 * 1024,
  peers: 16
});
function networkError(code) {
  return new Error(code);
}
function requireNetwork(value, code) {
  if (!value) throw networkError(code);
}
function interruptible(promise, signal) {
  signal.throwIfAborted();
  return new Promise((resolve, reject) => {
    const abort = () => reject(signal.reason);
    signal.addEventListener("abort", abort, { once: true });
    void promise.then(resolve, reject).finally(() => signal.removeEventListener("abort", abort));
  });
}
function timeout(milliseconds, message) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(networkError(message)), milliseconds);
  return { signal: controller.signal, cancel: () => clearTimeout(timer) };
}
var FRAGMENT_VERSION = 2;
var FRAGMENT_HEADER = 13;
function encodeFragment(id, offset, total, fragment) {
  const frame = new Uint8Array(FRAGMENT_HEADER + fragment.length), view = new DataView(frame.buffer);
  frame[0] = FRAGMENT_VERSION;
  view.setUint32(1, id);
  view.setUint32(5, offset);
  view.setUint32(9, total);
  frame.set(fragment, FRAGMENT_HEADER);
  return frame;
}
function decodeFragment(frame) {
  requireNetwork(frame.length > FRAGMENT_HEADER && frame[0] === FRAGMENT_VERSION, "APPLICATION_NETWORK_FRAME_INVALID");
  const view = new DataView(frame.buffer, frame.byteOffset, frame.byteLength);
  return { id: view.getUint32(1), position: view.getUint32(5), total: view.getUint32(9), chunk: frame.subarray(FRAGMENT_HEADER) };
}
var ApplicationMessageWire = class {
  #connection;
  #signal;
  #timeoutMs;
  #authorize;
  #outgoing = 0;
  #incoming = 0;
  #pending = 0;
  #pendingBytes = 0;
  #sentBytes = 0;
  #receivedBytes = 0;
  #tail = Promise.resolve();
  constructor(connection, signal, timeoutMs, authorize = () => {
  }) {
    this.#connection = connection;
    this.#signal = signal;
    this.#timeoutMs = timeoutMs;
    this.#authorize = authorize;
  }
  get stats() {
    return { sentBytes: this.#sentBytes, receivedBytes: this.#receivedBytes };
  }
  send(value, authorize) {
    this.#signal.throwIfAborted();
    requireNetwork(this.#pending < APPLICATION_NETWORK_LIMITS.queuedMessages, "APPLICATION_NETWORK_BACKPRESSURE");
    const bytes = encodeWireValue(value);
    const kind = typeof value?.kind === "string" ? value.kind : "unknown";
    perfCount(`wire.send.${kind}`);
    perfCount(`wire.send.${kind}.bytes`, bytes.length);
    requireNetwork(bytes.length > 0 && bytes.length <= APPLICATION_NETWORK_LIMITS.messageBytes && this.#pendingBytes + bytes.length <= APPLICATION_NETWORK_LIMITS.queuedBytes, "APPLICATION_NETWORK_BACKPRESSURE");
    this.#pending++;
    this.#pendingBytes += bytes.length;
    const queued = timeout(this.#timeoutMs, "APPLICATION_NETWORK_WRITE_TIMEOUT");
    const signal = AbortSignal.any([this.#signal, queued.signal]);
    const task = this.#tail.then(async () => {
      signal.throwIfAborted();
      authorize?.();
      requireNetwork(this.#outgoing < 4294967295, "APPLICATION_NETWORK_SEQUENCE_EXHAUSTED");
      const id = ++this.#outgoing;
      for (let offset = 0; offset < bytes.length; offset += APPLICATION_NETWORK_LIMITS.fragmentBytes) {
        signal.throwIfAborted();
        this.#authorize();
        authorize?.();
        const fragment = bytes.subarray(offset, offset + APPLICATION_NETWORK_LIMITS.fragmentBytes);
        const frame = encodeFragment(id, offset, bytes.length, fragment);
        await interruptible(this.#connection.send(frame, { signal }), signal);
        this.#sentBytes += frame.length;
      }
    }).finally(() => {
      queued.cancel();
      this.#pending--;
      this.#pendingBytes -= bytes.length;
    });
    this.#tail = task.catch(() => void 0);
    return task;
  }
  async *messages() {
    let body2 = null, offset = 0;
    let assembly;
    const iterator = this.#connection.frames(this.#signal)[Symbol.asyncIterator]();
    try {
      while (!this.#signal.aborted) {
        const signal = assembly === void 0 ? this.#signal : AbortSignal.any([this.#signal, assembly.signal]);
        const next = await interruptible(iterator.next(), signal);
        if (next.done) {
          requireNetwork(body2 === null, "APPLICATION_NETWORK_TRUNCATED");
          return;
        }
        const bytes = next.value;
        requireNetwork(
          bytes instanceof Uint8Array && bytes.length > 0 && bytes.length <= APPLICATION_NETWORK_LIMITS.fragmentBytes + 128,
          "APPLICATION_NETWORK_FRAME_LIMIT"
        );
        this.#receivedBytes += bytes.length;
        const { id, position, total, chunk } = decodeFragment(bytes);
        requireNetwork(
          Number.isSafeInteger(id) && id === this.#incoming + 1 && Number.isSafeInteger(position) && position === offset && Number.isSafeInteger(total) && total > 0 && total <= APPLICATION_NETWORK_LIMITS.messageBytes && chunk.length > 0 && chunk.length <= APPLICATION_NETWORK_LIMITS.fragmentBytes && offset + chunk.length <= total,
          "APPLICATION_NETWORK_FRAME_INVALID"
        );
        if (body2 === null) {
          body2 = new Uint8Array(total);
          assembly = timeout(this.#timeoutMs, "APPLICATION_NETWORK_READ_TIMEOUT");
        }
        requireNetwork(body2.length === total, "APPLICATION_NETWORK_FRAME_INVALID");
        body2.set(chunk, offset);
        offset += chunk.length;
        if (offset === total) {
          const complete = body2;
          body2 = null;
          offset = 0;
          this.#incoming++;
          assembly?.cancel();
          assembly = void 0;
          let message;
          try {
            message = decodeWireValue(complete);
          } catch {
            throw networkError("APPLICATION_NETWORK_MESSAGE_INVALID");
          }
          perfCount("wire.recv");
          perfCount("wire.recv.bytes", complete.length);
          yield message;
        }
      }
    } finally {
      assembly?.cancel();
      void iterator.return?.().catch(() => void 0);
    }
  }
};

// packages/peer-session/src/secure-channel.ts
var APPLICATION_CHANNEL_SUITE = `${HPKE_SUITE}/peer-record-v1`;
var APPLICATION_CHANNEL_LIMITS = Object.freeze({ overheadBytes: 22, records: 2 ** 24, plaintextBytes: 2 ** 32 });
var DOMAIN = "chronolog/peer-channel/v1";
var EXPORT_CONTEXT = encodeRecord({ domain: DOMAIN, layout: ["reliable-key:32", "reliable-nonce:12", "live-key:32", "live-nonce:12"] });
var HEADER = 6;
var TAG = 16;
var limit = (live) => live ? MAX_SIGNAL_BYTES : APPLICATION_NETWORK_LIMITS.fragmentBytes + 128;
var source = (bytes) => Uint8Array.from(bytes).buffer;
var context = (sender, receiver) => encodeRecord({ domain: DOMAIN, suite: APPLICATION_CHANNEL_SUITE, sender, receiver });
var RecordCipher = class {
  #key;
  #baseNonce;
  #live;
  #sequence = 0;
  #bytes = 0;
  constructor(key, nonce, live) {
    this.#key = key;
    this.#baseNonce = nonce;
    this.#live = live;
  }
  #nonce(sequence) {
    const nonce = this.#baseNonce.slice(), view = new DataView(nonce.buffer);
    view.setUint32(8, view.getUint32(8) ^ sequence);
    return nonce;
  }
  #budget(length) {
    requireNetwork(this.#key !== void 0, "APPLICATION_CHANNEL_CLOSED");
    requireNetwork(
      this.#sequence < APPLICATION_CHANNEL_LIMITS.records && this.#bytes + length <= APPLICATION_CHANNEL_LIMITS.plaintextBytes,
      "APPLICATION_CHANNEL_KEY_EXHAUSTED"
    );
  }
  async seal(input) {
    requireNetwork(input instanceof Uint8Array && input.length > 0 && input.length <= limit(this.#live), "APPLICATION_CHANNEL_FRAME_LIMIT");
    this.#budget(input.length);
    const sequence = ++this.#sequence, header = Uint8Array.of(1, this.#live ? 2 : 1, 0, 0, 0, 0);
    new DataView(header.buffer).setUint32(2, sequence);
    this.#bytes += input.length;
    const encrypted = new Uint8Array(await crypto.subtle.encrypt({
      name: "AES-GCM",
      iv: source(this.#nonce(sequence)),
      additionalData: source(header),
      tagLength: 128
    }, this.#key, source(input)));
    const result = new Uint8Array(header.length + encrypted.length);
    result.set(header);
    result.set(encrypted, HEADER);
    return result;
  }
  async open(input) {
    requireNetwork(
      input instanceof Uint8Array && input.length > HEADER + TAG && input.length <= limit(this.#live) + HEADER + TAG,
      "APPLICATION_CHANNEL_FRAME_LIMIT"
    );
    requireNetwork(input[0] === 1 && input[1] === (this.#live ? 2 : 1), "APPLICATION_CHANNEL_FRAME_INVALID");
    const sequence = new DataView(input.buffer, input.byteOffset, HEADER).getUint32(2);
    requireNetwork(sequence > 0 && sequence <= APPLICATION_CHANNEL_LIMITS.records, "APPLICATION_CHANNEL_SEQUENCE_INVALID");
    if (this.#live && sequence <= this.#sequence) return null;
    requireNetwork(this.#live || sequence === this.#sequence + 1, "APPLICATION_CHANNEL_SEQUENCE_INVALID");
    this.#budget(input.length - HEADER - TAG);
    let plaintext;
    try {
      plaintext = new Uint8Array(await crypto.subtle.decrypt({
        name: "AES-GCM",
        iv: source(this.#nonce(sequence)),
        additionalData: source(input.subarray(0, HEADER)),
        tagLength: 128
      }, this.#key, source(input.subarray(HEADER))));
    } catch {
      throw new Error("APPLICATION_CHANNEL_AUTHENTICATION_FAILED");
    }
    this.#sequence = sequence;
    this.#bytes += plaintext.length;
    return plaintext;
  }
  clear() {
    this.#key = void 0;
    this.#baseNonce.fill(0);
  }
};
async function direction(secret, usage) {
  requireNetwork(secret.length === 88, "APPLICATION_CHANNEL_KEY_INVALID");
  try {
    const reliable = await crypto.subtle.importKey("raw", source(secret.subarray(0, 32)), "AES-GCM", false, [usage]);
    const live = await crypto.subtle.importKey("raw", source(secret.subarray(44, 76)), "AES-GCM", false, [usage]);
    return { reliable: new RecordCipher(reliable, secret.slice(32, 44), false), live: new RecordCipher(live, secret.slice(76, 88), true) };
  } finally {
    secret.fill(0);
  }
}
function clear(value) {
  value?.reliable.clear();
  value?.live.clear();
}
var ApplicationSecureChannel = class {
  connection;
  #signal;
  #receiver;
  #outbound;
  #inbound;
  #hello = false;
  #preparing = false;
  #sending = false;
  #closed = false;
  #reliableBusy = false;
  #liveBusy = false;
  #onAbort = () => this.clear();
  constructor(raw, signal) {
    this.#signal = AbortSignal.any([signal, raw.signal]);
    const lifetime = this.#signal, channel = this;
    const live = raw.live === void 0 ? void 0 : {
      signal: AbortSignal.any([lifetime, raw.live.signal]),
      async trySend(frame, options = {}) {
        const signal2 = options.signal === void 0 ? lifetime : AbortSignal.any([lifetime, options.signal]);
        channel.#open();
        signal2.throwIfAborted();
        requireNetwork(channel.#sending && channel.#outbound !== void 0, "APPLICATION_PEER_AUTHENTICATION_REQUIRED");
        if (channel.#liveBusy) return false;
        channel.#liveBusy = true;
        try {
          const encrypted = await channel.#outbound.live.seal(frame);
          channel.#open();
          signal2.throwIfAborted();
          return await raw.live.trySend(encrypted, { signal: signal2 });
        } finally {
          channel.#liveBusy = false;
        }
      },
      async *frames(signal2) {
        const lifetime2 = signal2 === void 0 ? channel.#signal : AbortSignal.any([channel.#signal, signal2]);
        for await (const frame of raw.live.frames(lifetime2)) {
          channel.#open();
          lifetime2.throwIfAborted();
          requireNetwork(channel.#inbound !== void 0, "APPLICATION_PEER_AUTHENTICATION_REQUIRED");
          const plaintext = await channel.#inbound.live.open(frame);
          channel.#open();
          lifetime2.throwIfAborted();
          if (plaintext !== null) yield plaintext;
        }
      },
      close: () => raw.live.close()
    };
    this.connection = {
      signal: lifetime,
      ...live === void 0 ? {} : { live },
      async send(frame, options = {}) {
        const signal2 = options.signal === void 0 ? lifetime : AbortSignal.any([lifetime, options.signal]);
        channel.#open();
        signal2.throwIfAborted();
        requireNetwork(!channel.#reliableBusy, "APPLICATION_NETWORK_BACKPRESSURE");
        channel.#reliableBusy = true;
        try {
          const bytes = channel.#sending ? await channel.#outbound.reliable.seal(frame) : frame;
          channel.#open();
          signal2.throwIfAborted();
          await raw.send(bytes, { signal: signal2 });
        } catch (error) {
          if (channel.#sending) {
            channel.clear();
            void raw.close().catch(() => void 0);
          }
          throw error;
        } finally {
          channel.#reliableBusy = false;
        }
      },
      async *frames(signal2) {
        const lifetime2 = signal2 === void 0 ? channel.#signal : AbortSignal.any([channel.#signal, signal2]);
        for await (const frame of raw.frames(lifetime2)) {
          channel.#open();
          lifetime2.throwIfAborted();
          const plaintext = channel.#inbound === void 0 ? frame : await channel.#inbound.reliable.open(frame);
          channel.#open();
          lifetime2.throwIfAborted();
          yield plaintext;
        }
      },
      close: async () => {
        channel.clear();
        await raw.close();
      }
    };
    lifetime.addEventListener("abort", this.#onAbort, { once: true });
    if (lifetime.aborted) this.clear();
  }
  #open() {
    this.#signal.throwIfAborted();
    requireNetwork(!this.#closed, "APPLICATION_CHANNEL_CLOSED");
  }
  async hello() {
    this.#open();
    requireNetwork(!this.#hello, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    this.#hello = true;
    const receiver = await generateX25519KeyPair(false);
    this.#open();
    this.#receiver = receiver;
    return { suite: APPLICATION_CHANNEL_SUITE, receiverKey: bytesToHex2(receiver.publicKeyBytes) };
  }
  async prepare(peerReceiverKey, sender, receiver) {
    this.#open();
    requireNetwork(!this.#preparing, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    this.#preparing = true;
    const exported = await hpkeSendExportBase(hexToBytes2(peerReceiverKey), context(sender, receiver), EXPORT_CONTEXT, 88);
    try {
      this.#open();
      const outbound = await direction(exported.exportedSecret, "encrypt");
      if (this.#closed || this.#signal.aborted) {
        clear(outbound);
        this.#open();
      }
      this.#outbound = outbound;
      return bytesToHex2(exported.encapsulatedKey);
    } finally {
      exported.exportedSecret.fill(0);
    }
  }
  /** Called only when every public proof fragment has been dispatched. */
  enableSending() {
    this.#open();
    requireNetwork(this.#outbound !== void 0 && !this.#sending, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    this.#sending = true;
  }
  async accept(encapsulatedKey, sender, receiver) {
    this.#open();
    requireNetwork(this.#receiver !== void 0 && this.#inbound === void 0, "APPLICATION_NETWORK_HANDSHAKE_ORDER");
    const key = this.#receiver;
    this.#receiver = void 0;
    const secret = await hpkeReceiveExportBase(key.privateKey, key.publicKeyBytes, hexToBytes2(encapsulatedKey), context(sender, receiver), EXPORT_CONTEXT, 88);
    try {
      this.#open();
      const inbound = await direction(secret, "decrypt");
      if (this.#closed || this.#signal.aborted) {
        clear(inbound);
        this.#open();
      }
      this.#inbound = inbound;
    } finally {
      secret.fill(0);
    }
  }
  clear() {
    if (this.#closed) return;
    this.#closed = true;
    this.#receiver = void 0;
    this.#signal.removeEventListener("abort", this.#onAbort);
    clear(this.#outbound);
    clear(this.#inbound);
    this.#outbound = void 0;
    this.#inbound = void 0;
  }
};

// packages/peer-session/src/network.ts
var tracked = /* @__PURE__ */ new WeakMap();
var activeLinks = /* @__PURE__ */ new WeakMap();
var linkListeners = /* @__PURE__ */ new WeakMap();
function applicationPeerDiagnostics(session) {
  return [...tracked.get(session)?.values() ?? []].map((snapshot) => snapshot());
}
function applicationPeerLinks(session) {
  return [...activeLinks.get(session)?.values() ?? []];
}
function onApplicationPeerLink(session, listener) {
  let set = linkListeners.get(session);
  if (!set) linkListeners.set(session, set = /* @__PURE__ */ new Set());
  set.add(listener);
  for (const link of applicationPeerLinks(session)) {
    try {
      listener({ type: "connected", link });
    } catch {
    }
  }
  return () => {
    set.delete(listener);
  };
}
var unavailableMedia = Object.freeze({
  available: false,
  unavailableReason: "relay",
  addTrack() {
    throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
  },
  removeTrack() {
    throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
  },
  addTransceiver() {
    throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
  },
  getTransceivers() {
    return [];
  },
  onTrack() {
    return () => {
    };
  },
  async restartIce() {
    throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
  }
});
var unavailableStreams = Object.freeze({
  available: false,
  unavailableReason: "relay",
  open() {
    throw new Error("WEBRTC_STREAMS_UNAVAILABLE");
  },
  onStream() {
    return () => {
    };
  }
});
async function connectApplicationPeer(session, options) {
  check(session.status.connectedPeers < APPLICATION_NETWORK_LIMITS.peers, "SESSION_PEER_LIMIT");
  const lifetime = new AbortController();
  const signal = AbortSignal.any([lifetime.signal, session.signal, options.connection.signal, ...options.signal === void 0 ? [] : [options.signal]]);
  const secure = new ApplicationSecureChannel(options.connection, signal);
  const wire = new ApplicationMessageWire(secure.connection, signal, options.handshakeTimeoutMs ?? 3e4);
  const iterator = wire.messages()[Symbol.asyncIterator]();
  const localNonce = crypto.randomUUID(), connectionId = crypto.randomUUID();
  const timeout2 = setTimeout(() => lifetime.abort(new Error("PEER_HANDSHAKE_TIMEOUT")), options.handshakeTimeoutMs ?? 3e4);
  let authenticated = false;
  let stopping;
  let stopFacts;
  let signalRoute;
  let contentLink;
  let inBandRtc;
  let createdLink;
  let sentLiveBytes = 0, receivedLiveBytes = 0;
  const liveDiagnostics = () => signalRoute === void 0 ? {} : { sentLiveBytes, receivedLiveBytes, signalRejections: signalRoute.diagnostics };
  const close = () => stopping ??= (async () => {
    lifetime.abort(new Error("PEER_CLOSED"));
    stopFacts?.();
    signalRoute?.close();
    contentLink?.close();
    inBandRtc?.close();
    secure.clear();
    if (authenticated) {
      authenticated = false;
      tracked.get(session)?.delete(connectionId);
      if (createdLink) {
        const links = activeLinks.get(session);
        if (links?.get(connectionId) === createdLink) links.delete(connectionId);
        for (const listener of linkListeners.get(session) ?? []) {
          try {
            listener({ type: "disconnected", link: createdLink });
          } catch {
          }
        }
      }
      session.setConnectedPeers(tracked.get(session)?.size ?? 0);
    }
    await options.connection.close();
    void iterator.return?.();
  })();
  signal.addEventListener("abort", () => {
    void close().catch(() => void 0);
  }, { once: true });
  try {
    await wire.send({
      kind: "hello",
      value: await signRecord("peer-hello", {
        applicationId: session.applicationId,
        nonce: localNonce,
        channel: await secure.hello()
      }, session.device.identity)
    });
    const next = await iterator.next();
    check(!next.done, "PEER_HELLO_MISSING");
    const hello = next.value;
    check(hello.kind === "hello", "PEER_HELLO_INVALID");
    await verifyRecord("peer-hello", hello.value);
    check(
      hello.value.payload.applicationId === session.applicationId && typeof hello.value.payload.nonce === "string" && hello.value.payload.nonce.length <= 128 && (options.peerIdentity === void 0 || options.peerIdentity === hello.value.signer),
      "PEER_SCOPE_MISMATCH"
    );
    const localContext = { applicationId: session.applicationId, identity: session.device.identity.publicKey, nonce: localNonce };
    const peerContext = { applicationId: session.applicationId, identity: hello.value.signer, nonce: hello.value.payload.nonce };
    const encapsulatedKey = await secure.prepare(hello.value.payload.channel.receiverKey, localContext, peerContext);
    await wire.send({
      kind: "proof",
      value: await signRecord("peer-proof", {
        applicationId: session.applicationId,
        localNonce,
        peerNonce: hello.value.payload.nonce,
        encapsulatedKey
      }, session.device.identity)
    });
    secure.enableSending();
    const proofNext = await iterator.next();
    check(!proofNext.done, "PEER_PROOF_MISSING");
    const proof = proofNext.value;
    check(proof.kind === "proof", "PEER_PROOF_INVALID");
    await verifyRecord("peer-proof", proof.value, hello.value.signer);
    check(
      proof.value.payload.applicationId === session.applicationId && proof.value.payload.localNonce === hello.value.payload.nonce && proof.value.payload.peerNonce === localNonce,
      "PEER_PROOF_CONTEXT_INVALID"
    );
    await secure.accept(proof.value.payload.encapsulatedKey, peerContext, localContext);
    clearTimeout(timeout2);
    const peerId = hello.value.signer;
    const connections = tracked.get(session) ?? /* @__PURE__ */ new Map();
    check(connections.size < APPLICATION_NETWORK_LIMITS.peers, "SESSION_PEER_LIMIT");
    tracked.set(session, connections);
    authenticated = true;
    connections.set(connectionId, () => ({
      connectionId,
      peerId,
      kind: "unknown",
      sentReliableBytes: wire.stats.sentBytes,
      receivedReliableBytes: wire.stats.receivedBytes,
      ...liveDiagnostics()
    }));
    session.setConnectedPeers(connections.size);
    const authorizeReader = () => {
      check(session.isReader(peerId) && session.isReader(session.device.identity.publicKey), "RTC_FORBIDDEN");
    };
    const sendRtc = (rtcMessage) => wire.send({ kind: "rtc", message: rtcMessage }, authorizeReader);
    const polite = session.device.identity.publicKey < peerId;
    const rtcSession = options.connection.session;
    if (rtcSession !== void 0) {
      inBandRtc = rtcSession.attachInBandSignaling({ polite, send: sendRtc });
    } else if (typeof options.connection.attachInBandSignaling === "function") {
      inBandRtc = options.connection.attachInBandSignaling({ peerId, polite, send: sendRtc });
    }
    const transportKind = rtcSession !== void 0 || typeof options.connection.attachInBandSignaling === "function" ? "direct" : "relay";
    if (secure.connection.live !== void 0 && session.isReader(peerId)) {
      const live = secure.connection.live;
      signalRoute = session.signals.attachRoute({
        async trySend(frame, input) {
          const accepted = await live.trySend(frame, input);
          if (accepted) sentLiveBytes = Math.min(Number.MAX_SAFE_INTEGER, sentLiveBytes + frame.length);
          return accepted;
        }
      });
      void (async () => {
        try {
          for await (const frame of live.frames(signal)) {
            if (!session.isReader(peerId)) break;
            receivedLiveBytes = Math.min(Number.MAX_SAFE_INTEGER, receivedLiveBytes + frame.length);
            await signalRoute?.receive(frame);
          }
        } catch {
        }
      })();
    }
    let contentOut = Promise.resolve();
    contentLink = createNetworkContent({
      content: session.content,
      peerId,
      signal,
      authorize: () => session.isReader(peerId) && session.isReader(session.device.identity.publicKey),
      send: (message) => {
        const task = contentOut.then(() => wire.send(
          { kind: "content", message },
          () => check(session.isReader(peerId) && session.isReader(session.device.identity.publicKey), "CONTENT_FORBIDDEN")
        ));
        contentOut = task.catch(() => void 0);
        return task;
      }
    });
    const self = session.device.identity.publicKey;
    const initiator = self < peerId;
    let outTail = Promise.resolve();
    const post = (message) => {
      const task = outTail.then(() => wire.send(message));
      outTail = task.catch(() => void 0);
      task.catch(() => {
        void close();
      });
      return task;
    };
    let memberVerified = false;
    let markMember;
    const memberReady = new Promise((resolve) => {
      markMember = resolve;
    });
    const privateAllowed = () => memberVerified && session.isReader(peerId) && session.isReader(self);
    const verifyMember = () => {
      if (memberVerified) return;
      check(session.isMember(peerId), "PEER_MEMBER_REQUIRED");
      memberVerified = true;
      markMember();
    };
    const FACT_BATCH_BYTES = 512 * 1024;
    const sendFactBatches = async (facts, requestId = "") => {
      const batches = [];
      let current = { publicOps: [], encryptedEnvelopes: [], checkpoints: [] }, size = 0;
      const roll = (bytes) => {
        if (size + bytes > FACT_BATCH_BYTES && size > 0) {
          batches.push(current);
          current = { publicOps: [], encryptedEnvelopes: [], checkpoints: [] };
          size = 0;
        }
        size += bytes;
      };
      for (const raw of facts.publicOps) {
        roll(raw.length);
        current.publicOps.push(raw);
      }
      for (const raw of facts.encryptedEnvelopes) {
        if (!privateAllowed()) break;
        roll(raw.length);
        current.encryptedEnvelopes.push(raw);
      }
      for (const cp of facts.checkpoints) {
        roll(4096);
        current.checkpoints.push(cp);
      }
      batches.push(current);
      let sent = Promise.resolve();
      for (let i = 0; i < batches.length; i++) {
        const batch = batches[i], last = i === batches.length - 1;
        if (!last && batch.publicOps.length + batch.encryptedEnvelopes.length + batch.checkpoints.length === 0) continue;
        if (last && requestId === "" && batch.publicOps.length + batch.encryptedEnvelopes.length + batch.checkpoints.length === 0) continue;
        sent = post({ kind: "facts", requestId: last ? requestId : "", facts: batch });
      }
      await sent;
    };
    const pushIds = (scope, ids) => {
      if (ids.length === 0 || scope === "private" && !privateAllowed()) return Promise.resolve();
      return sendFactBatches(session.exportFactsById(scope, ids));
    };
    const livePending = [];
    let liveFlush;
    const flushLive = () => liveFlush ??= (async () => {
      try {
        while (livePending.length > 0 && !signal.aborted) {
          const items = livePending.splice(0);
          await pushIds("public", items.filter((item) => item.scope === "public").map((item) => item.id));
          await pushIds("private", items.filter((item) => item.scope === "private").map((item) => item.id));
        }
      } finally {
        liveFlush = void 0;
      }
    })();
    stopFacts = session.onFacts((delta) => {
      let hasOutOfBand = false;
      for (const item of delta.items) {
        if (item.source === connectionId) continue;
        if (item.source === void 0) hasOutOfBand = true;
        if (item.scope === "private" && !privateAllowed()) continue;
        livePending.push({ scope: item.scope, id: item.id });
      }
      if (livePending.length > 0) void flushLive().catch(() => close());
      if (hasOutOfBand && memberVerified) queueOutOfBandReceipts();
    });
    let receiptItems = [];
    let receiptTimer;
    const flushReceipts = async () => {
      receiptTimer = void 0;
      const items = receiptItems;
      receiptItems = [];
      if (items.length === 0 || signal.aborted) return;
      for (let i = 0; i < items.length; i += 1024) {
        const chunk = items.slice(i, i + 1024);
        const evidence = await session.retainMany(chunk);
        const own = evidence.find((ev) => ev.signer === self);
        if (own !== void 0) void post({ kind: "receipt", evidence: own });
      }
    };
    const scheduleReceipts = () => {
      if (receiptItems.length > 0 && receiptTimer === void 0) {
        receiptTimer = setTimeout(() => {
          void flushReceipts().catch(() => void 0);
        }, 25);
      }
    };
    const queueOutOfBandReceipts = () => {
      if (signal.aborted) return;
      for (const proposalId of session.unreceiptedProposalIdsByAuthor(peerId, privateAllowed())) {
        receiptItems.push({ proposalId });
      }
      scheduleReceipts();
    };
    const queueReceipts = (facts) => {
      for (const raw of facts.publicOps) {
        try {
          receiptItems.push({ proposalId: bytesToHex(operationIdDigest(decodeSignedOperation(raw).coreBytes)) });
        } catch {
        }
      }
      for (const raw of facts.encryptedEnvelopes) {
        try {
          receiptItems.push({ proposalId: bytesToHex(decodeEncryptedEnvelope(raw).opId) });
        } catch {
        }
      }
      scheduleReceipts();
    };
    const casRequests = /* @__PURE__ */ new Map();
    const requestedCas = /* @__PURE__ */ new Set();
    const pullMissingCas = async () => {
      for (let attempt = 0; attempt < 8 && !signal.aborted; attempt++) {
        const missing = session.missingCasDependencies().filter((hash) => !requestedCas.has(hash));
        if (missing.length === 0) return;
        for (const hash of missing) requestedCas.add(hash);
        const requestId = crypto.randomUUID();
        const done = new Promise((resolve, reject) => casRequests.set(requestId, { resolve, reject }));
        void post({ kind: "cas-want", requestId, hashes: missing.slice(0, 1024), subgraph: true });
        await done;
      }
    };
    const SNAPSHOT_MAX_BYTES = 24 * 1024 * 1024;
    const snapshotWaiters = /* @__PURE__ */ new Map();
    let snapshotRequested = false;
    const snapshotScopeAllowed = () => !session.genesis.privateLog || privateAllowed();
    const requestSnapshot = () => {
      if (snapshotRequested || !snapshotScopeAllowed() || !session.wantsSnapshotBootstrap()) return Promise.resolve();
      snapshotRequested = true;
      const requestId = crypto.randomUUID();
      return new Promise((resolve) => {
        const timer = setTimeout(() => {
          snapshotWaiters.delete(requestId);
          resolve();
        }, 3e4);
        snapshotWaiters.set(requestId, () => {
          clearTimeout(timer);
          snapshotWaiters.delete(requestId);
          resolve();
        });
        void post({ kind: "snapshot-want", requestId });
      });
    };
    const rounds = /* @__PURE__ */ new Map();
    const wantRequests = /* @__PURE__ */ new Map();
    const maybeFinishRound = async (id) => {
      const round = rounds.get(id);
      if (round === void 0 || round.ended || round.outstanding > 0 || round.wants.size > 0) return;
      round.ended = true;
      await pullMissingCas();
      void post({ kind: "recon-end", round: id, scope: round.scope });
    };
    const applyStep = async (roundId, scope, ranges, owner) => {
      const allowed = scope === "public" || privateAllowed();
      const local = allowed ? session.factIds(scope) : void 0;
      const step = local === void 0 ? { reply: ranges.filter((r) => !("ids" in r)).map((r) => ({ prefix: r.prefix, ids: [] })), push: [], want: [] } : reconcileRanges(local, ranges);
      if (allowed) void pushIds(scope, step.push);
      if (allowed && step.want.length > 0) {
        const requestId = crypto.randomUUID();
        if (owner) {
          wantRequests.set(requestId, roundId);
          for (const want of step.want) rounds.get(roundId)?.wants.add(want);
        }
        void post({ kind: "want", requestId, scope, ids: step.want });
      }
      if (owner) {
        const round = rounds.get(roundId);
        if (round === void 0) return;
        if (step.reply.length > 0) {
          round.outstanding++;
          void post({ kind: "recon", round: roundId, scope, owner: true, ranges: step.reply });
        }
        await maybeFinishRound(roundId);
      } else {
        void post({ kind: "recon", round: roundId, scope, owner: false, ranges: step.reply });
      }
    };
    const runRound = (scope) => {
      check(!signal.aborted && rounds.size < 8, "PEER_REQUEST_LIMIT");
      const id = crypto.randomUUID();
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          rounds.delete(id);
          reject(new Error("PEER_SYNC_TIMEOUT"));
          void close();
        }, 6e4);
        rounds.set(id, {
          scope,
          outstanding: 1,
          wants: /* @__PURE__ */ new Set(),
          ended: false,
          resolve: () => {
            clearTimeout(timer);
            rounds.delete(id);
            resolve();
          },
          reject: (error) => {
            clearTimeout(timer);
            rounds.delete(id);
            reject(error);
          }
        });
        const local = scope === "private" && !privateAllowed() ? void 0 : session.factIds(scope);
        const root = local === void 0 ? { prefix: "", count: 0, fp: new Uint8Array(16) } : local.summary("");
        void wire.send({ kind: "recon", round: id, scope, owner: false, ranges: [root] }).catch((error) => {
          rounds.get(id)?.reject(error);
        });
      });
    };
    let markReady;
    const initialSync = new Promise((resolve) => {
      markReady = resolve;
    });
    void initialSync.catch(() => void 0);
    const runInitialSync = async () => {
      if (!session.genesis.privateLog) await requestSnapshot();
      await runRound("public");
      verifyMember();
      if (session.genesis.privateLog) await requestSnapshot();
      await runRound("private");
      queueOutOfBandReceipts();
      void post({ kind: "ready" });
      markReady();
    };
    let contentTail = Promise.resolve();
    void (async () => {
      try {
        while (!signal.aborted) {
          const incoming = await iterator.next();
          if (incoming.done) break;
          const message = incoming.value;
          if (memberVerified) check(session.isMember(peerId), "PEER_REVOKED");
          switch (message.kind) {
            case "recon": {
              check(typeof message.round === "string" && message.round.length <= 64 && Array.isArray(message.ranges) && message.ranges.length <= 4096, "PEER_REQUEST_INVALID");
              check(message.scope === "public" || message.scope === "private", "PEER_REQUEST_INVALID");
              const round = rounds.get(message.round);
              if (round !== void 0 && !message.owner) {
                round.outstanding--;
                await applyStep(message.round, message.scope, message.ranges, true);
              } else {
                await applyStep(message.round, message.scope, message.ranges, false);
              }
              break;
            }
            case "recon-end": {
              if (message.scope === "public") {
                verifyMember();
                if (session.genesis.privateLog) void requestSnapshot();
              } else if (message.scope === "private") {
                queueOutOfBandReceipts();
              }
              void post({ kind: "ack", requestId: message.round });
              break;
            }
            case "ready":
              markReady();
              break;
            case "want": {
              check(Array.isArray(message.ids) && message.ids.length <= 1e5, "PEER_REQUEST_INVALID");
              const allowed = message.scope === "public" || privateAllowed();
              void sendFactBatches(allowed ? session.exportFactsById(message.scope, message.ids) : { publicOps: [], encryptedEnvelopes: [], checkpoints: [] }, message.requestId);
              break;
            }
            case "facts": {
              check(typeof message.requestId === "string" && message.requestId.length <= 128, "PEER_REQUEST_INVALID");
              const facts = message.facts;
              const encryptedEnvelopes = privateAllowed() ? facts.encryptedEnvelopes : [];
              await session.mergeFacts({ publicOps: facts.publicOps, encryptedEnvelopes, casNodes: [], retentions: [], checkpoints: facts.checkpoints }, { source: connectionId });
              queueReceipts({ publicOps: facts.publicOps, encryptedEnvelopes, checkpoints: [] });
              if (message.requestId !== "") {
                const roundId = wantRequests.get(message.requestId);
                wantRequests.delete(message.requestId);
                const round = roundId === void 0 ? void 0 : rounds.get(roundId);
                if (round !== void 0) {
                  round.wants.clear();
                  await maybeFinishRound(roundId);
                }
              }
              if (session.missingCasDependencies().length > 0) void pullMissingCas().catch(() => void 0);
              break;
            }
            case "cas-want": {
              check(Array.isArray(message.hashes) && message.hashes.length <= 1024, "PEER_REQUEST_INVALID");
              const nodes = await session.exportCasNodes(
                message.hashes.filter((h) => typeof h === "string" && /^[0-9a-f]{64}$/u.test(h)),
                privateAllowed(),
                { subgraph: message.subgraph !== false }
              );
              void post({ kind: "cas", requestId: message.requestId, nodes });
              break;
            }
            case "cas": {
              const nodes = message.nodes.filter((node) => node.partition === "public" || privateAllowed());
              if (nodes.length > 0) await session.mergeFacts({ publicOps: [], encryptedEnvelopes: [], casNodes: nodes, retentions: [], checkpoints: [] }, { source: connectionId });
              const waiter = casRequests.get(message.requestId);
              casRequests.delete(message.requestId);
              waiter?.resolve();
              break;
            }
            case "receipt": {
              await session.mergeFacts({ publicOps: [], encryptedEnvelopes: [], casNodes: [], retentions: [message.evidence], checkpoints: [] }, { source: connectionId });
              break;
            }
            case "content": {
              const content = message.message;
              if (memberVerified) await contentLink.handle(content);
              else contentTail = contentTail.then(() => memberReady).then(() => contentLink.handle(content)).catch(() => void 0);
              break;
            }
            case "rtc":
              if (memberVerified && inBandRtc !== void 0 && session.isReader(peerId)) {
                void inBandRtc.receive(message.message).catch(() => void 0);
              }
              break;
            case "snapshot-want": {
              check(typeof message.requestId === "string" && message.requestId.length <= 64, "PEER_REQUEST_INVALID");
              let bytes = null;
              if (session.genesis.privateLog) verifyMember();
              if (snapshotScopeAllowed()) {
                try {
                  bytes = await session.exportMaterializedSnapshot({ minOps: 16 });
                } catch {
                  bytes = null;
                }
                if (bytes !== null && bytes.length > SNAPSHOT_MAX_BYTES) bytes = null;
              }
              void post({ kind: "snapshot", requestId: message.requestId, bytes });
              break;
            }
            case "snapshot": {
              const waiter = snapshotWaiters.get(message.requestId);
              if (waiter === void 0) break;
              if (message.bytes instanceof Uint8Array && snapshotScopeAllowed()) {
                try {
                  await session.importMaterializedSnapshot(message.bytes);
                } catch {
                }
              }
              waiter();
              break;
            }
            case "ack": {
              const round = rounds.get(message.requestId);
              if (round !== void 0) round.resolve();
              break;
            }
            default:
              throw new Error("PEER_MESSAGE_INVALID");
          }
        }
      } catch (error) {
        lifetime.abort(error);
      } finally {
        for (const round of rounds.values()) round.reject(signal.reason ?? new Error("PEER_CLOSED"));
        for (const waiter of casRequests.values()) waiter.reject(signal.reason ?? new Error("PEER_CLOSED"));
        for (const waiter of snapshotWaiters.values()) waiter();
        if (receiptTimer !== void 0) clearTimeout(receiptTimer);
        await close();
      }
    })();
    if (initiator) void runInitialSync().catch((error) => {
      lifetime.abort(error);
    });
    else if (!session.genesis.privateLog) void requestSnapshot();
    const completion = signal.aborted ? Promise.resolve() : new Promise((resolve) => signal.addEventListener("abort", () => resolve(), { once: true }));
    const link = {
      peerIdentity: peerId,
      transportKind,
      media: rtcSession?.media ?? unavailableMedia,
      streams: rtcSession?.streams ?? unavailableStreams,
      signal,
      completion,
      get stats() {
        return { ...wire.stats, ...liveDiagnostics() };
      },
      close,
      async synchronize() {
        check(!signal.aborted, "PEER_REQUEST_LIMIT");
        await interruptible(initialSync, signal);
        await runRound("public");
        await runRound("private");
      }
    };
    createdLink = link;
    let sessionLinks = activeLinks.get(session);
    if (!sessionLinks) {
      sessionLinks = /* @__PURE__ */ new Map();
      activeLinks.set(session, sessionLinks);
    }
    sessionLinks.set(connectionId, link);
    for (const listener of linkListeners.get(session) ?? []) {
      try {
        listener({ type: "connected", link });
      } catch {
      }
    }
    return link;
  } catch (error) {
    await close();
    throw error;
  } finally {
    clearTimeout(timeout2);
  }
}

// packages/peer-session/src/operation.ts
var ApplicationOperation = class {
  constructor(id, operationId, owner) {
    this.id = id;
    this.operationId = operationId;
    this.owner = owner;
  }
  id;
  operationId;
  owner;
  stored = true;
  inspect() {
    return this.owner.inspectOperation(this.id);
  }
  async materialized(options) {
    return (await this.owner.waitOperation(this.id, "materialized", options)).materialized;
  }
  async retained(options) {
    return (await this.owner.waitOperation(this.id, "retained", options)).retained;
  }
  async finalized(options) {
    return (await this.owner.waitOperation(this.id, "finalized", options)).materialized;
  }
};

// packages/peer-session/src/session-types.ts
var APPLICATION_EVENT_CURSOR_LIMIT = 128 * 1024;

// packages/peer-session/src/session.ts
var FactMap = class extends Map {
  constructor(ids, onAdd) {
    super();
    this.ids = ids;
    this.onAdd = onAdd;
  }
  ids;
  onAdd;
  #source;
  set(key, value) {
    if (this.ids !== void 0 && !super.has(key)) {
      this.ids.add(key);
      this.onAdd(key, this.#source);
    }
    return super.set(key, value);
  }
  /** Insert a fact delivered by peer link `source` (synchronous, so concurrent local writes are never mis-tagged). */
  setFrom(key, value, source2) {
    this.#source = source2;
    try {
      return this.set(key, value);
    } finally {
      this.#source = void 0;
    }
  }
  delete(key) {
    this.ids.delete(key);
    return super.delete(key);
  }
  clear() {
    this.ids.clear();
    super.clear();
  }
};
var standardHashes;
function standardModuleHashes() {
  return standardHashes ??= new Set(Object.values(STANDARD_MODULE_SOURCES).map((src) => computeCasHash(utf8(src), [])));
}
function sameBytes(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}
function globMatches(pattern, topic) {
  if (pattern === "*" || pattern === topic) return true;
  if (pattern.endsWith("*")) return topic.startsWith(pattern.slice(0, -1));
  return false;
}
function toMaterializedRevision(rev) {
  return Object.freeze({
    digest: rev.digest,
    stateRoot: rev.stateRoot,
    historyDigest: rev.historyDigest,
    view: rev.view,
    orderLength: rev.orderLength
  });
}
function toApplicationEvent(ev) {
  return Object.freeze({
    id: `${ev.opId}:${ev.eventOrdinal}`,
    proposalId: ev.opId,
    operationId: ev.operationId,
    author: ev.author,
    authorTimestampMs: ev.authorTimestampMs.toString(),
    topic: ev.topic,
    payload: structuredClone(ev.payload)
  });
}
var ApplicationSession = class _ApplicationSession {
  applicationId;
  logId;
  genesis;
  genesisBytes;
  device;
  identity;
  definition;
  cas;
  content;
  signals;
  #store;
  #prefix;
  #lifetime = new AbortController();
  #release;
  #blindHostMode;
  #blockchainVerifier;
  #sandboxOptions;
  #sqliteWasmModule;
  #sqliteWasmLoader;
  #maxOperations;
  #casMirrors;
  #mirrorAttempted = /* @__PURE__ */ new Set();
  #sqliteDriver;
  #sqliteLoadPromise;
  #kernel;
  #kernelHasSqlite = false;
  #controlKernel = null;
  #finalKernel = null;
  #publicFactIds = new FactIdSet();
  #privateFactIds = new FactIdSet();
  #pendingDelta = [];
  #recordDelta(scope, id, source2) {
    this.#pendingDelta.push(source2 === void 0 ? { scope, id } : { scope, id, source: source2 });
  }
  #publicOps = new FactMap(this.#publicFactIds, (id, source2) => this.#recordDelta("public", id, source2));
  #encryptedEnvelopes = new FactMap(this.#privateFactIds, (id, source2) => this.#recordDelta("private", id, source2));
  #undecryptedEnvelopes = /* @__PURE__ */ new Set();
  #localPending = /* @__PURE__ */ new Map();
  #retentions = /* @__PURE__ */ new Map();
  #checkpoints = new FactMap(this.#publicFactIds, (id, source2) => this.#recordDelta("public", id, source2));
  #epochKeys = /* @__PURE__ */ new Map();
  #ringKeys = /* @__PURE__ */ new Map();
  #statusListeners = /* @__PURE__ */ new Set();
  #changeListeners = /* @__PURE__ */ new Set();
  #factListeners = /* @__PURE__ */ new Set();
  #connectedPeers = 0;
  #connectionRevision = 0;
  #materializationError = null;
  #lastLocalRevision;
  #lastFinalRevision = null;
  #verifiedFinality = {
    closedThroughMs: null,
    includedOpIds: /* @__PURE__ */ new Set(),
    excludedOpIds: /* @__PURE__ */ new Set(),
    latestCheckpoint: null,
    verifiedCheckpoints: [],
    equivocationProofs: []
  };
  #cachedSignalPolicy = null;
  #cachedDescription = null;
  #validationDescription = null;
  #evaluatedPermissions = null;
  #lastPermsStateJson = "";
  #pendingMaterializedCache = null;
  #pendingSnapshotBundle = null;
  /**
   * Op ids this replica already verified (signature + id) before folding them into a persisted
   * materialized cache, plus ops it authored. Trust shortcut on cold open: an envelope re-read
   * from the device's own store whose decrypted op id is in this set skips Ed25519 re-verification.
   */
  #trustedOpIds = /* @__PURE__ */ new Set();
  #snapshotBootstrap;
  #visibilityCleanup;
  #pendingEncryptedSnapshot = null;
  #lastPersistedCacheDigest = "";
  #cachePersistTimer;
  #materializedCacheHits = 0;
  #lastSyncSeq = 0;
  #closed = false;
  #closing;
  #tail = Promise.resolve();
  #writeTail = Promise.resolve();
  #materializeDirty = false;
  #materializePromise = null;
  constructor(options, genesisBytes, cas) {
    this.genesisBytes = genesisBytes.slice();
    this.genesis = decodeLogGenesis(this.genesisBytes);
    this.logId = bytesToHex(genesisLogId(this.genesisBytes));
    this.applicationId = options.applicationId ?? this.logId;
    this.device = options.device;
    this.identity = Object.freeze({ publicKey: options.device.identity.publicKey });
    if (options.definition !== void 0) this.definition = options.definition;
    this.cas = cas;
    this.#store = options.store;
    this.#prefix = `v2/${this.logId}`;
    this.#release = options.release;
    this.#blindHostMode = options.blindHostMode ?? false;
    if (options.blockchainVerifier !== void 0) this.#blockchainVerifier = options.blockchainVerifier;
    if (options.sqliteWasmModule !== void 0) this.#sqliteWasmModule = options.sqliteWasmModule;
    if (options.sqliteWasmLoader !== void 0) this.#sqliteWasmLoader = options.sqliteWasmLoader;
    if (options.materializedSnapshot !== void 0) this.#pendingEncryptedSnapshot = options.materializedSnapshot.slice();
    this.#snapshotBootstrap = options.snapshotBootstrap ?? true;
    this.#installVisibilityFlush();
    this.#maxOperations = options.maxOperations ?? 5e4;
    this.#casMirrors = (options.casMirrors ?? []).map((u) => u.replace(/\/+$/u, ""));
    this.#sandboxOptions = {
      ...options.wasmModule === void 0 ? {} : { wasmModule: options.wasmModule },
      ...options.sqliteDriver === void 0 ? {} : { sqliteDriver: options.sqliteDriver }
    };
    if (options.sqliteDriver !== void 0) {
      this.#sqliteDriver = options.sqliteDriver;
      this.#kernelHasSqlite = true;
    }
    this.#kernel = new TopicKernel({
      genesis: this.genesisBytes,
      cas: this.cas,
      blindHostMode: this.#blindHostMode,
      ...this.#sandboxOptions
    });
    if (this.genesis.privateLog && !this.#blindHostMode) {
      this.#controlKernel = new TopicKernel({
        genesis: this.genesisBytes,
        cas: this.cas,
        blindHostMode: true,
        ...this.#sandboxOptions
      });
    }
    this.#lastLocalRevision = toMaterializedRevision(this.#kernel.revision("local"));
    this.content = new ApplicationContent({
      store: this.#store,
      cas: this.cas,
      identity: this.device.identity,
      storageId: this.device.storageId,
      authority: {
        applicationId: this.applicationId,
        isReader: (pk) => this.isReader(pk),
        currentEpoch: () => Math.max(0, this.currentEpoch()),
        epochKey: (epoch) => this.#epochKeys.get(epoch) ?? null
      }
    });
    this.signals = new SignalChannel({
      scope: this.applicationId,
      identity: {
        publicKeyBytes: hexToBytes(this.device.identity.publicKey),
        privateKey: this.device.identity.privateKey
      },
      localEcho: true,
      authorize: async (auth) => {
        if (auth.scope !== this.applicationId) return false;
        const authorHex = bytesToHex(auth.authorId);
        const policy = await this.#resolveSignalPolicy();
        for (const rule of policy.rules) {
          if (!globMatches(rule.topicPattern, auth.topic)) continue;
          if (!rule.allowedAuthors.includes("*") && !rule.allowedAuthors.includes(authorHex)) continue;
          return true;
        }
        return false;
      }
    });
  }
  static async open(options) {
    const cas = new ContentAddressedStore({ store: options.store });
    const initialSeq = await options.store.latestChangeSeq?.() ?? 0;
    const allEntries = await readAllStoreEntries(options.store);
    let discoveredGenesis = null;
    const nonCasEntries = [];
    for (const entry of allEntries) {
      if (cas.indexPersistedEntry(entry, { verifyHash: false })) continue;
      nonCasEntries.push(entry);
      if (discoveredGenesis === null && entry.key.startsWith("v2/") && entry.key.endsWith("/genesis")) {
        discoveredGenesis = entry.value;
      }
    }
    if (options.casNodes !== void 0 && options.casNodes.length > 0) {
      await cas.putManyVerified(options.casNodes);
    }
    const missingStandard = Object.values(STANDARD_MODULE_SOURCES).map((src) => utf8(src)).filter((bytes) => !cas.hasSync(computeCasHash(bytes, []), "public"));
    for (const bytes of missingStandard) await cas.put(bytes, [], "public");
    let genesisBytes;
    if (options.genesis !== void 0) {
      genesisBytes = options.genesis instanceof Uint8Array ? options.genesis.slice() : encodeLogGenesis(options.genesis);
      const logId = bytesToHex(genesisLogId(genesisBytes));
      if (options.logId !== void 0 && options.logId !== logId) {
        throw new Error("SESSION_CHAIN_ID_MISMATCH");
      }
      const existingEntry = nonCasEntries.find((e) => e.key === `v2/${logId}/genesis`);
      const existing = existingEntry?.value ?? null;
      if (existing !== null && !sameBytes(existing, genesisBytes)) {
        throw new Error("SESSION_GENESIS_MISMATCH");
      }
      if (existing === null) await options.store.put(`v2/${logId}/genesis`, genesisBytes, { durability: "strict" });
    } else if (options.logId !== void 0) {
      const found = nonCasEntries.find((e) => e.key === `v2/${options.logId}/genesis`);
      genesisBytes = found?.value ?? null;
    } else {
      genesisBytes = discoveredGenesis;
    }
    if (genesisBytes === null) throw new Error("SESSION_GENESIS_NOT_FOUND");
    const session = new _ApplicationSession(options, genesisBytes, cas);
    session.#lastSyncSeq = initialSeq;
    if (options.epochKeys !== void 0) {
      for (const [epoch, key] of options.epochKeys) {
        await session.installEpochKey(epoch, key);
      }
    }
    await session.#hydrateFromEntries(nonCasEntries);
    session.#pendingDelta = [];
    await session.#rematerialize();
    return session;
  }
  get signal() {
    return this.#lifetime.signal;
  }
  #computeKeyState() {
    if (!this.genesis.privateLog || this.#blindHostMode) return "public";
    const epoch = this.currentEpoch();
    if (epoch < 0) return "ready";
    if (this.#epochKeys.has(epoch)) return "ready";
    const hasBox = this.keysState().epochs?.[String(epoch)]?.boxes?.[this.identity.publicKey] !== void 0;
    return hasBox ? "pending-unseal" : "missing-lockbox";
  }
  get status() {
    const pendingOps = this.#countPendingOps();
    const keyState = this.#computeKeyState();
    const pk = this.identity.publicKey;
    const isAdmin = this.isAdministrator(pk);
    const isPub = this.#evaluatedPermissions !== null ? this.#evaluatedPermissions.publishers.has(pk) : this.member(pk)?.publisher === true;
    const canAuthorControl = !this.#closed && !this.#blindHostMode && (isAdmin || isPub);
    const canAuthorData = !this.#closed && !this.#blindHostMode && this.isWriter(pk) && (keyState === "public" || keyState === "ready");
    const canAuthor = canAuthorData || canAuthorControl;
    const awaitingKeys = this.genesis.privateLog && !this.#blindHostMode && this.isReader(pk) && this.currentEpoch() >= 0 && !this.#epochKeys.has(this.currentEpoch());
    return Object.freeze({
      ...this.#kernel.pendingDependencies.length > 0 ? { pendingDependencies: this.#kernel.pendingDependencies } : {},
      canAuthor,
      canAuthorData,
      canAuthorControl,
      keyState,
      phase: this.#closed ? "closed" : awaitingKeys ? "awaiting-keys" : "ready",
      database: this.#closed ? "closed" : this.#materializationError !== null ? "failed" : "ready",
      connectedPeers: this.#connectedPeers,
      connectionRevision: this.#connectionRevision,
      pendingOperations: pendingOps,
      materializationError: this.#materializationError
    });
  }
  permissions() {
    if (this.#evaluatedPermissions !== null) {
      const p = this.#evaluatedPermissions;
      return {
        mode: p.mode,
        members: p.members,
        readers: p.openReaders ? ["*"] : [...p.readers].sort(),
        writers: p.openWriters ? ["*"] : [...p.writers].sort(),
        administrators: [...p.administrators].sort(),
        publishers: [...p.publishers].sort(),
        openReaders: p.openReaders,
        openWriters: p.openWriters,
        blockedAuthors: [...p.blockedAuthors].sort(),
        admission: p.admission,
        multisig: p.multisig
      };
    }
    const raw = this.#kernel.topic("$permissions");
    if (raw === null || typeof raw !== "object" || !Array.isArray(raw.members)) {
      return { members: [], openReaders: false, openWriters: false, blockedAuthors: [], admission: null, multisig: null };
    }
    return raw;
  }
  member(publicKey) {
    return this.permissions().members.find((m) => m.publicKey === publicKey) ?? null;
  }
  isBlockedAuthor(publicKey) {
    return this.#evaluatedPermissions !== null && this.#evaluatedPermissions.blockedAuthors.has(publicKey);
  }
  isMember(publicKey) {
    if (this.#evaluatedPermissions !== null) {
      if (this.#evaluatedPermissions.openWriters || this.#evaluatedPermissions.openReaders) return /^[0-9a-f]{64}$/u.test(publicKey);
      return this.#evaluatedPermissions.members.some((m) => m.publicKey === publicKey) || this.#evaluatedPermissions.readers.has(publicKey) || this.#evaluatedPermissions.writers.has(publicKey) || this.#evaluatedPermissions.administrators.has(publicKey);
    }
    return this.member(publicKey) !== null;
  }
  isReader(publicKey) {
    if (!this.genesis.privateLog) return true;
    if (this.#evaluatedPermissions !== null) {
      if (this.#evaluatedPermissions.openReaders) return /^[0-9a-f]{64}$/u.test(publicKey);
      return this.#evaluatedPermissions.readers.has(publicKey);
    }
    return this.member(publicKey)?.reader === true;
  }
  isWriter(publicKey) {
    if (this.#evaluatedPermissions !== null) {
      if (this.#evaluatedPermissions.blockedAuthors.has(publicKey)) return false;
      if (this.#evaluatedPermissions.openWriters) return /^[0-9a-f]{64}$/u.test(publicKey);
      return this.#evaluatedPermissions.writers.has(publicKey) || this.#evaluatedPermissions.administrators.has(publicKey);
    }
    return this.member(publicKey)?.writer === true || this.member(publicKey)?.administrator === true;
  }
  isAdministrator(publicKey) {
    if (this.#evaluatedPermissions !== null) {
      return this.#evaluatedPermissions.administrators.has(publicKey);
    }
    return this.member(publicKey)?.administrator === true;
  }
  /** Query an arbitrary capability (standard or custom) against the chain's `$permissions` reducer. */
  async checkPermission(capability, actor = this.identity.publicKey) {
    const res = await this.#kernel.query("$permissions", { check: capability, actor }).catch(() => null);
    if (typeof res === "boolean") return res;
    if (capability === "reader") return this.isReader(actor);
    if (capability === "writer") return this.isWriter(actor);
    if (capability === "administrator") return this.isAdministrator(actor);
    if (capability === "publisher") {
      return this.#evaluatedPermissions !== null ? this.#evaluatedPermissions.publishers.has(actor) || this.#evaluatedPermissions.administrators.has(actor) : this.member(actor)?.publisher === true || this.member(actor)?.administrator === true;
    }
    if (capability === "member") return this.isMember(actor);
    return false;
  }
  keysState() {
    const raw = this.#kernel.topic("$keys");
    if (raw === null || typeof raw !== "object") return { currentEpoch: -1, epochs: {} };
    return raw;
  }
  currentEpoch() {
    const state = this.keysState();
    if (state.currentEpoch >= 0) return state.currentEpoch;
    if (this.#epochKeys.size > 0) return Math.max(...this.#epochKeys.keys());
    return -1;
  }
  epochKey(epoch) {
    return this.#epochKeys.get(epoch)?.slice() ?? null;
  }
  hasEpochKey(epoch) {
    return this.#epochKeys.has(epoch);
  }
  exportEpochKeys() {
    const out = /* @__PURE__ */ new Map();
    for (const [ep, key] of this.#epochKeys) out.set(ep, key.slice());
    return out;
  }
  async installEpochKey(epoch, key) {
    check(Number.isSafeInteger(epoch) && epoch >= 0 && key instanceof Uint8Array && key.length === 32, "EPOCH_KEY_INVALID");
    this.#epochKeys.set(epoch, key.slice());
    await this.#store.put(`${this.#prefix}/epoch-key/${epoch}`, key.slice());
  }
  async installRingKey(ring, epoch, key) {
    check(typeof ring === "string" && ring.length > 0 && ring !== "default", "RING_NAME_INVALID");
    check(Number.isSafeInteger(epoch) && epoch >= 0 && key instanceof Uint8Array && key.length === 32, "EPOCH_KEY_INVALID");
    let map = this.#ringKeys.get(ring);
    if (map === void 0) {
      map = /* @__PURE__ */ new Map();
      this.#ringKeys.set(ring, map);
    }
    map.set(epoch, key.slice());
    await this.#store.put(`${this.#prefix}/ring-key/${ring}/${epoch}`, key.slice());
  }
  ringKey(ring, epoch) {
    if (ring === "default") return this.epochKey(epoch);
    return this.#ringKeys.get(ring)?.get(epoch)?.slice() ?? null;
  }
  /**
   * Heal any admitted reader missing HPKE lockboxes in `$keys` for epochs we hold
   * (e.g. concurrent admission + epoch rotation, multisig approvals, or late wrapKey addition).
   */
  async backfillMissingEpochBoxes(options = {}) {
    if (!this.genesis.privateLog || this.#blindHostMode) return 0;
    await this.#flushPendingMaterialization();
    const keysState = this.keysState();
    if (keysState.currentEpoch < 0) return 0;
    const minEp = Math.max(0, options.minEpoch ?? 0);
    const members = this.permissions().members;
    let sealedMembers = 0;
    for (const member of members) {
      if (!member.reader || !member.wrapKey) continue;
      const epochBoxes = {};
      for (let ep = minEp; ep <= keysState.currentEpoch; ep++) {
        const epKey = this.#epochKeys.get(ep);
        if (epKey === void 0) continue;
        if (keysState.epochs?.[String(ep)]?.boxes?.[member.publicKey] !== void 0) continue;
        epochBoxes[String(ep)] = await hpkeSealEpochKey(member.wrapKey, epKey, this.logId, ep);
      }
      if (Object.keys(epochBoxes).length === 0) continue;
      await this.submit({
        visibility: "public",
        awaitMaterialized: true,
        updates: [{
          topic: "$keys",
          input: {
            action: "grantBoxes",
            member: member.publicKey,
            epochBoxes
          }
        }]
      });
      sealedMembers++;
    }
    return sealedMembers;
  }
  /** Incrementally pull facts written by a sibling tab/PWA into the shared multi-tab BytesStore. */
  async syncFromStore() {
    if (this.#closed || this.#store.readChangesSince === void 0) return false;
    return this.#serial(async () => {
      const { latestSeq, changes } = await this.#store.readChangesSince(this.#lastSyncSeq);
      if (latestSeq <= this.#lastSyncSeq || changes.length === 0) {
        this.#lastSyncSeq = Math.max(this.#lastSyncSeq, latestSeq);
        return false;
      }
      this.#lastSyncSeq = latestSeq;
      const uniqueKeys = /* @__PURE__ */ new Set();
      const prefix = `${this.#prefix}/`;
      for (const ch of changes) {
        if (ch.deleted) continue;
        if (ch.key.startsWith("cas/") || ch.key.startsWith(prefix) && ch.key !== `${prefix}materialized-cache`) {
          uniqueKeys.add(ch.key);
        }
      }
      if (uniqueKeys.size === 0) return false;
      let changed = false;
      for (const key of uniqueKeys) {
        const val = await this.#store.get(key);
        if (val === null) continue;
        if (this.cas.indexPersistedEntry({ key, value: val }, { verifyHash: false })) {
          changed = true;
          continue;
        }
        if (await this.#ingestSingleStoreEntry({ key, value: val })) {
          changed = true;
        }
      }
      if (changed) {
        await this.#rematerialize();
        this.#emitFacts();
      }
      return changed;
    });
  }
  topic(name) {
    return this.#kernel.topic(name);
  }
  revision(view = "local") {
    if (view === "final") {
      return this.#lastFinalRevision ?? toMaterializedRevision(this.#kernel.revision("final"));
    }
    return this.#lastLocalRevision;
  }
  async retryMaterialization() {
    await this.#serial(() => this.#rematerialize());
  }
  #countPendingOps() {
    let count = this.#kernel.pendingDependencies.length + this.#undecryptedEnvelopes.size;
    if (this.#materializeDirty) count++;
    return count;
  }
  #serial(work) {
    const task = this.#tail.then(() => {
      if (this.#closed) throw new Error("SESSION_CLOSED");
      return work();
    });
    this.#tail = task.catch(() => void 0);
    return task;
  }
  #writeLane(work) {
    const task = this.#writeTail.then(() => {
      if (this.#closed) throw new Error("SESSION_CLOSED");
      return work();
    });
    this.#writeTail = task.catch(() => void 0);
    return task;
  }
  #scheduleMaterialize() {
    this.#materializeDirty = true;
    if (this.#materializePromise !== null) return this.#materializePromise;
    this.#materializePromise = this.#serial(async () => {
      try {
        while (this.#materializeDirty && !this.#closed) {
          this.#materializeDirty = false;
          await this.#rematerialize();
        }
      } finally {
        this.#materializePromise = null;
        if (this.#materializeDirty && !this.#closed) {
          void this.#scheduleMaterialize().catch(() => void 0);
        }
      }
    });
    return this.#materializePromise;
  }
  async #flushPendingMaterialization() {
    if (this.#closed) return;
    if (this.#materializePromise !== null) {
      await this.#materializePromise;
    } else if (this.#materializeDirty) {
      await this.#scheduleMaterialize();
    }
  }
  /**
   * Persist the materialized cache soon: immediately (next task) when no cache has been written for
   * this replica yet, so a reload right after the first materialization already opens warm;
   * otherwise debounced. Also flushed on close and when the page is hidden.
   */
  #scheduleCachePersist() {
    if (this.#closed || this.#cachePersistTimer !== void 0) return;
    const delay = this.#lastPersistedCacheDigest === "" ? 0 : 1500;
    this.#cachePersistTimer = setTimeout(() => {
      this.#cachePersistTimer = void 0;
      void this.#serial(() => this.#persistMaterializedCacheNow()).catch(() => void 0);
    }, delay);
    this.#cachePersistTimer.unref?.();
  }
  /** Write the materialized cache now (hosts call this on visibility change / before unload). */
  flushMaterializedCache() {
    if (this.#closed) return Promise.resolve();
    if (this.#cachePersistTimer !== void 0) {
      clearTimeout(this.#cachePersistTimer);
      this.#cachePersistTimer = void 0;
    }
    return this.#serial(() => this.#persistMaterializedCacheNow());
  }
  #installVisibilityFlush() {
    const doc = globalThis.document;
    const win = globalThis;
    if (doc?.addEventListener === void 0 || typeof win.addEventListener !== "function") return;
    const onHidden = () => {
      if (doc.visibilityState !== "visible") void this.flushMaterializedCache().catch(() => void 0);
    };
    doc.addEventListener("visibilitychange", onHidden);
    win.addEventListener("pagehide", onHidden);
    this.#visibilityCleanup = () => {
      doc.removeEventListener?.("visibilitychange", onHidden);
      win.removeEventListener?.("pagehide", onHidden);
    };
  }
  async #persistMaterializedCacheNow() {
    if (this.#closed) return;
    const rev = this.#lastLocalRevision.digest;
    if (this.#kernel.pendingDependencies.length > 0 || this.#kernel.materializedOutcomes.length === 0 && this.#kernel.frontierOrderLength === 0 || rev === this.#lastPersistedCacheDigest) {
      return;
    }
    try {
      await this.#kernel.commitSeenOpsRoot();
      const cache = this.#kernel.exportMaterializedCache();
      await this.#store.put(`${this.#prefix}/materialized-cache`, encodeMaterializedCache(cache), { durability: "relaxed" });
      for (const id of cache.orderOpIds) this.#trustedOpIds.add(id);
      this.#lastPersistedCacheDigest = rev;
    } catch {
    }
  }
  #emitStatus() {
    const snap = this.status;
    for (const listener of this.#statusListeners) {
      try {
        listener(snap);
      } catch {
      }
    }
  }
  #emitChange(change) {
    for (const listener of this.#changeListeners) {
      try {
        listener(change);
      } catch {
      }
    }
  }
  #emitFacts() {
    const delta = { items: this.#pendingDelta };
    this.#pendingDelta = [];
    for (const listener of this.#factListeners) {
      try {
        listener(delta);
      } catch {
      }
    }
  }
  onStatus(listener) {
    this.#statusListeners.add(listener);
    try {
      listener(this.status);
    } catch {
    }
    return () => {
      this.#statusListeners.delete(listener);
    };
  }
  onChange(listener) {
    this.#changeListeners.add(listener);
    return () => {
      this.#changeListeners.delete(listener);
    };
  }
  onFacts(listener) {
    this.#factListeners.add(listener);
    return () => {
      this.#factListeners.delete(listener);
    };
  }
  async *changes(options = {}) {
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    const queue = [];
    let wake;
    const stop = this.onChange((value) => {
      queue.splice(0, queue.length, value);
      wake?.();
    });
    const abort = () => {
      wake?.();
    };
    signal.addEventListener("abort", abort);
    try {
      while (!signal.aborted) {
        if (queue.length === 0) await new Promise((resolve) => {
          wake = resolve;
        });
        while (queue.length > 0 && !signal.aborted) yield queue.shift();
      }
    } finally {
      stop();
      signal.removeEventListener("abort", abort);
    }
  }
  setConnectedPeers(count) {
    this.#connectedPeers = count;
    this.#connectionRevision++;
    this.#emitStatus();
  }
  async #ensureSqliteIfNeeded(reducersOverride, mountsOverride) {
    if (this.#sqliteDriver !== void 0) return !this.#kernelHasSqlite;
    const memoKey = `${reducersOverride !== void 0 ? JSON.stringify(reducersOverride) : `hash:${this.#kernel.topicHash("$reducers") ?? ""}`}\0${mountsOverride !== void 0 ? JSON.stringify(mountsOverride) : `mhash:${this.#kernel.topicHash("$mounts") ?? ""}`}`;
    if (this.#sqliteScanNegative.has(memoKey)) return false;
    const reducersRaw = reducersOverride !== void 0 ? reducersOverride : this.#kernel.topic("$reducers");
    if (reducersRaw === null) return false;
    let needsSqlite = false, incomplete = false;
    try {
      const queue = [];
      const visited = /* @__PURE__ */ new Set();
      const checkReducersCfg = (cfgRaw) => {
        const c = assertValidReducersConfig(cfgRaw);
        for (const [topicName, binding] of Object.entries(c.topics)) {
          if (this.#blindHostMode && this.genesis.privateLog && !isControlTopic(topicName)) continue;
          const ref = tryParseCasRef(binding.module) !== null ? binding.module : c.imports[binding.module];
          if (binding.module === "chronolog:sqlite" || binding.module === "chronolog/sql" || binding.module === "chronolog/sqlite-helpers" || binding.module === "chronolog/registry") {
            needsSqlite = true;
            return;
          }
          if (ref !== void 0) queue.push(ref);
          queue.push(binding.module);
        }
      };
      const cfg = assertValidReducersConfig(reducersRaw);
      checkReducersCfg(reducersRaw);
      const mountsRaw = mountsOverride !== void 0 ? mountsOverride : this.#kernel.topic("$mounts");
      if (!needsSqlite && mountsRaw !== null && typeof mountsRaw === "object" && !Array.isArray(mountsRaw)) {
        const mountsMap = mountsRaw.mounts;
        if (mountsMap !== null && typeof mountsMap === "object" && !Array.isArray(mountsMap)) {
          for (const mountEntry of Object.values(mountsMap)) {
            if (mountEntry !== null && typeof mountEntry === "object" && !Array.isArray(mountEntry)) {
              const mt = mountEntry.topics;
              if (mt !== null && typeof mt === "object" && !Array.isArray(mt)) {
                const mtRec = mt;
                if (mtRec.$reducers !== void 0) {
                  try {
                    checkReducersCfg(mtRec.$reducers);
                  } catch {
                  }
                }
              }
            }
          }
        }
      }
      const importSpecRe = /\bfrom\s*['"]([^'"]+)['"]|\bimport\s*\(\s*['"]([^'"]+)['"]\s*\)/gu;
      while (!needsSqlite && queue.length > 0) {
        const item = queue.shift();
        if (visited.has(item)) continue;
        visited.add(item);
        if (item === "chronolog:sqlite" || item === "chronolog/sql" || item === "chronolog/sqlite-helpers" || item === "chronolog/registry") {
          needsSqlite = true;
          break;
        }
        const directHash = tryParseCasRef(item);
        const ref = directHash !== null ? item : cfg.imports[item];
        if (ref === void 0 || !ref.startsWith("cas:sha256-")) continue;
        const hash = ref.slice(11);
        const node = await this.cas.get(hash, "any");
        if (node === null) {
          incomplete = true;
          continue;
        }
        const pkg = tryDecodePackageNode(node.bytes);
        if (pkg !== null) {
          if (pkg.builtins.includes("chronolog:sqlite")) {
            needsSqlite = true;
            break;
          }
          for (const depRef of Object.values(pkg.dependencies)) {
            if (!visited.has(depRef)) queue.push(depRef);
          }
          continue;
        }
        const text = new TextDecoder().decode(node.bytes);
        if (text.includes("chronolog:sqlite") || text.includes("chronolog/sql") || text.includes("chronolog/sqlite-helpers") || text.includes("chronolog/registry")) {
          needsSqlite = true;
          break;
        }
        importSpecRe.lastIndex = 0;
        let match;
        while ((match = importSpecRe.exec(text)) !== null) {
          const dep = match[1] ?? match[2];
          if (dep !== void 0 && !visited.has(dep) && Object.hasOwn(cfg.imports, dep)) {
            queue.push(dep);
          }
        }
      }
    } catch {
      return false;
    }
    if (!needsSqlite) {
      if (!incomplete) {
        if (this.#sqliteScanNegative.size > 64) this.#sqliteScanNegative.clear();
        this.#sqliteScanNegative.add(memoKey);
      }
      return false;
    }
    this.#sqliteLoadPromise ??= (async () => {
      const wasmModule = this.#sqliteWasmModule ?? (this.#sqliteWasmLoader !== void 0 ? await this.#sqliteWasmLoader() : void 0);
      const mod = await import("./src-B2RZ3WJY.mjs");
      const driver = await mod.createSqliteCasDriver({
        ...wasmModule === void 0 ? {} : { wasmModule }
      });
      this.#sqliteDriver = driver;
      return driver;
    })();
    await this.#sqliteLoadPromise;
    return !this.#kernelHasSqlite;
  }
  async #refreshPermissionsCache(kernel = this.#kernel) {
    const rawPerms = kernel.topic("$permissions");
    const rawJson = JSON.stringify(rawPerms);
    if (this.#evaluatedPermissions !== null && rawJson === this.#lastPermsStateJson) {
      return;
    }
    const parseStringList = (val) => {
      const keys = /* @__PURE__ */ new Set();
      let open = false;
      if (Array.isArray(val)) {
        for (const item of val) {
          if (item === "*") open = true;
          else if (typeof item === "string") keys.add(item);
        }
      }
      return { keys, open };
    };
    const parseMembers = (val) => {
      if (!Array.isArray(val)) return [];
      return val.filter((m) => m !== null && typeof m === "object" && typeof m.publicKey === "string");
    };
    try {
      const summary = await kernel.query("$permissions", { summary: true });
      if (summary !== null && typeof summary === "object" && !Array.isArray(summary) && Array.isArray(summary.administrators) && Array.isArray(summary.readers)) {
        const s = summary;
        const readers = parseStringList(s.readers);
        const writers = parseStringList(s.writers);
        const admins = parseStringList(s.administrators);
        const pubs = parseStringList(s.publishers);
        const blocked = parseStringList(s.blockedAuthors);
        const admission = s.admission !== null && typeof s.admission === "object" && !Array.isArray(s.admission) ? s.admission : null;
        const msRaw = s.multisig;
        const multisig = msRaw !== null && typeof msRaw === "object" && !Array.isArray(msRaw) && typeof msRaw.threshold === "number" && Array.isArray(msRaw.signers) ? {
          threshold: msRaw.threshold,
          signers: msRaw.signers.filter((k) => typeof k === "string"),
          proposals: msRaw.proposals ?? {}
        } : null;
        const openReaders = s.openReaders === true || readers.open;
        const openWriters = s.openWriters === true || writers.open;
        const mode = s.mode === "attested" || s.mode === "open" || s.mode === "multisig" ? s.mode : multisig !== null ? "multisig" : openReaders || openWriters ? "open" : admission !== null ? "attested" : "custom";
        this.#evaluatedPermissions = {
          mode,
          members: parseMembers(s.members),
          readers: readers.keys,
          writers: writers.keys,
          administrators: admins.keys,
          publishers: pubs.keys,
          openReaders,
          openWriters,
          blockedAuthors: blocked.keys,
          admission,
          multisig
        };
        return;
      }
      const [rRaw, wRaw, aRaw, pRaw, mRaw, admRaw, blkRaw] = await Promise.all([
        kernel.query("$permissions", { list: "readers" }).catch(() => null),
        kernel.query("$permissions", { list: "writers" }).catch(() => null),
        kernel.query("$permissions", { list: "administrators" }).catch(() => null),
        kernel.query("$permissions", { list: "publishers" }).catch(() => null),
        kernel.query("$permissions", { list: "members" }).catch(() => null),
        kernel.query("$permissions", { admission: true }).catch(() => null),
        kernel.query("$permissions", { list: "blockedAuthors" }).catch(() => null)
      ]);
      if (Array.isArray(rRaw) || Array.isArray(wRaw) || Array.isArray(aRaw)) {
        const readers = parseStringList(rRaw);
        const writers = parseStringList(wRaw);
        const admins = parseStringList(aRaw);
        const pubs = parseStringList(pRaw);
        const blocked = parseStringList(blkRaw);
        const admission = admRaw !== null && typeof admRaw === "object" && !Array.isArray(admRaw) ? admRaw : null;
        this.#evaluatedPermissions = {
          mode: readers.open || writers.open ? "open" : admission !== null ? "attested" : "custom",
          members: parseMembers(mRaw),
          readers: readers.keys,
          writers: writers.keys,
          administrators: admins.keys,
          publishers: pubs.keys,
          openReaders: readers.open,
          openWriters: writers.open,
          blockedAuthors: blocked.keys,
          admission,
          multisig: null
        };
        return;
      }
    } catch {
    }
    const raw = kernel.topic("$permissions");
    if (raw !== null && typeof raw === "object" && Array.isArray(raw.members)) {
      const members = parseMembers(raw.members);
      this.#evaluatedPermissions = {
        mode: raw.admission ? "attested" : "custom",
        members,
        readers: new Set(members.filter((m) => m.reader).map((m) => m.publicKey)),
        writers: new Set(members.filter((m) => m.writer || m.administrator).map((m) => m.publicKey)),
        administrators: new Set(members.filter((m) => m.administrator).map((m) => m.publicKey)),
        publishers: new Set(members.filter((m) => m.publisher || m.administrator).map((m) => m.publicKey)),
        openReaders: false,
        openWriters: false,
        blockedAuthors: /* @__PURE__ */ new Set(),
        admission: raw.admission ?? null,
        multisig: null
      };
    } else {
      this.#evaluatedPermissions = null;
    }
    this.#lastPermsStateJson = JSON.stringify(kernel.topic("$permissions"));
  }
  async #ingestSingleStoreEntry(entry) {
    const prefix = `${this.#prefix}/`;
    if (!entry.key.startsWith(prefix)) return false;
    const rest = entry.key.slice(prefix.length);
    if (rest.startsWith("epoch-key/")) {
      const ep = Number(rest.slice("epoch-key/".length));
      if (Number.isSafeInteger(ep) && ep >= 0 && entry.value.length === 32 && !this.#epochKeys.has(ep)) {
        this.#epochKeys.set(ep, entry.value.slice());
        return true;
      }
    } else if (rest.startsWith("ring-key/")) {
      const parts = rest.slice("ring-key/".length).split("/");
      const ring = parts[0];
      const ep = Number(parts[1]);
      if (ring && ring !== "default" && Number.isSafeInteger(ep) && ep >= 0 && entry.value.length === 32) {
        let map = this.#ringKeys.get(ring);
        if (map === void 0) {
          map = /* @__PURE__ */ new Map();
          this.#ringKeys.set(ring, map);
        }
        if (!map.has(ep)) {
          map.set(ep, entry.value.slice());
          return true;
        }
      }
    } else if (rest.startsWith("public-op/")) {
      const keyOpId = rest.slice("public-op/".length);
      if (this.#publicOps.has(keyOpId)) return false;
      try {
        if (!/^[0-9a-f]{64}$/u.test(keyOpId)) return false;
        const signed = decodeTrustedSignedOperation(entry.value);
        const core = decodeTrustedOperationCore(signed.coreBytes);
        const opId = keyOpId;
        if (bytesToHex(core.logId) === this.logId && core.visibility === "public" && !this.#publicOps.has(opId)) {
          this.#publicOps.set(opId, { raw: entry.value.slice(), signed, core });
          return true;
        }
      } catch {
      }
    } else if (rest.startsWith("enc-env/")) {
      const keyDigest = rest.slice("enc-env/".length);
      if (this.#encryptedEnvelopes.has(keyDigest)) return false;
      try {
        if (!/^[0-9a-f]{64}$/u.test(keyDigest)) return false;
        const envelope2 = decodeTrustedEncryptedEnvelope(entry.value);
        if (bytesToHex(envelope2.logId) === this.logId) {
          const digest3 = keyDigest;
          if (!this.#encryptedEnvelopes.has(digest3)) {
            this.#encryptedEnvelopes.set(digest3, { digest: digest3, raw: entry.value, envelope: envelope2, fromStore: true });
            this.#undecryptedEnvelopes.add(digest3);
            return true;
          }
        }
      } catch {
      }
    } else if (rest.startsWith("local-pending/")) {
      try {
        const rec = decodeLocalPending(entry.value);
        const signed = decodeTrustedSignedOperation(rec.raw);
        const core = decodeTrustedOperationCore(signed.coreBytes);
        const opId = rest.slice("local-pending/".length);
        if (/^[0-9a-f]{64}$/u.test(opId) && !this.#localPending.has(opId)) {
          this.#trustedOpIds.add(opId);
          this.#localPending.set(opId, {
            raw: rec.raw,
            signed,
            core,
            currentEnvelopeDigest: rec.envelopeDigest,
            currentEpoch: rec.epoch
          });
          return true;
        }
      } catch {
      }
    } else if (rest.startsWith("retention/")) {
      try {
        const ev = decodeRecord(entry.value);
        if (Array.isArray(ev.payload.items) && this.#indexRetention(ev)) return true;
      } catch {
      }
    } else if (rest.startsWith("checkpoint/")) {
      const key = rest.slice("checkpoint/".length);
      if (this.#checkpoints.has(key)) return false;
      try {
        const cp = decodeRecord(entry.value);
        const computedKey = await recordDigest(cp);
        if (!this.#checkpoints.has(computedKey)) {
          this.#checkpoints.set(computedKey, cp);
          return true;
        }
      } catch {
      }
    } else if (rest === "materialized-cache") {
      const cached = decodeMaterializedCache(entry.value);
      if (cached !== null && cached.logId === this.logId && cached.blindHostMode === this.#blindHostMode) {
        this.#pendingMaterializedCache = cached;
        for (const id of cached.orderOpIds) this.#trustedOpIds.add(id);
        for (const id of cached.frontierOpIds) this.#trustedOpIds.add(id);
      }
    }
    return false;
  }
  async #hydrateFromEntries(entries) {
    for (const entry of entries) {
      await this.#ingestSingleStoreEntry(entry);
    }
  }
  /**
   * Decode + verify a v3 snapshot bundle (see snapshot-codec.ts): decrypts private-log bundles
   * with the epoch key, checks the Ed25519 signature, and rejects signers that are not members
   * under the permissions this replica currently knows.
   */
  async #decodeMaterializedSnapshot(bytes) {
    if (this.genesis.privateLog && this.#blindHostMode) return null;
    const decoded = await decodeSnapshotBundle(bytes, this.logId, (epoch) => this.#epochKeys.get(epoch));
    if (decoded === null) return null;
    if (decoded.cache.blindHostMode !== this.#blindHostMode) return null;
    if (!this.isMember(decoded.signer)) return null;
    return { cache: decoded.cache, casNodes: decoded.casNodes };
  }
  #keysStateFrom(kernel) {
    const raw = kernel.topic("$keys");
    if (raw === null || typeof raw !== "object") return { currentEpoch: -1, epochs: {} };
    return raw;
  }
  #currentEpochFrom(kernel) {
    const state = this.#keysStateFrom(kernel);
    if (state.currentEpoch >= 0) return state.currentEpoch;
    if (this.#epochKeys.size > 0) return Math.max(...this.#epochKeys.keys());
    return -1;
  }
  async #unsealAvailableEpochKeys(kernel = this.#kernel) {
    if (!this.genesis.privateLog || this.#blindHostMode) return false;
    const keys = this.#keysStateFrom(kernel);
    let unlockedAny = false;
    for (const entry of Object.values(keys.epochs ?? {})) {
      if (this.#epochKeys.has(entry.epoch)) continue;
      const box = entry.boxes?.[this.identity.publicKey];
      if (box === void 0) continue;
      try {
        const plainKey = await hpkeOpenEpochKey(
          this.device.wrapKey.privateKey,
          this.device.wrapKey.publicKey,
          box,
          this.logId,
          entry.epoch
        );
        if (epochKeyCommitmentV2(plainKey) !== entry.keyCommitment) continue;
        await this.installEpochKey(entry.epoch, plainKey);
        unlockedAny = true;
      } catch {
      }
    }
    for (const [ringName, ringState] of Object.entries(keys.rings ?? {})) {
      const existingMap = this.#ringKeys.get(ringName);
      for (const entry of Object.values(ringState.epochs ?? {})) {
        if (existingMap?.has(entry.epoch)) continue;
        const box = entry.boxes?.[this.identity.publicKey];
        if (box === void 0) continue;
        try {
          const plainKey = await hpkeOpenEpochKey(
            this.device.wrapKey.privateKey,
            this.device.wrapKey.publicKey,
            box,
            `${this.logId}:${ringName}`,
            entry.epoch
          );
          if (epochKeyCommitmentV2(plainKey) !== entry.keyCommitment) continue;
          await this.installRingKey(ringName, entry.epoch, plainKey);
          unlockedAny = true;
        } catch {
        }
      }
    }
    return unlockedAny;
  }
  async #decryptPendingEnvelopes() {
    if (!this.genesis.privateLog || this.#blindHostMode || this.#undecryptedEnvelopes.size === 0) return;
    const work = [];
    for (const digest3 of [...this.#undecryptedEnvelopes]) {
      const entry = this.#encryptedEnvelopes.get(digest3);
      if (entry === void 0 || entry.decrypted !== void 0) {
        this.#undecryptedEnvelopes.delete(digest3);
        continue;
      }
      const ring = entry.envelope.ring ?? "default";
      const epochKey = ring === "default" ? this.#epochKeys.get(entry.envelope.epoch) : this.#ringKeys.get(ring)?.get(entry.envelope.epoch);
      const pending = this.#localPending.get(bytesToHex(entry.envelope.opId));
      if (pending !== void 0 && pending.currentEnvelopeDigest === digest3) {
        entry.decrypted = { opId: bytesToHex(entry.envelope.opId), signed: pending.signed, core: pending.core };
        this.#undecryptedEnvelopes.delete(digest3);
        continue;
      }
      if (epochKey === void 0) continue;
      work.push((async () => {
        try {
          const aad2 = envelopeAad(entry.envelope.logId, entry.envelope.opId, entry.envelope.author);
          const plaintext = await decryptEpochPayload(epochKey, {
            epoch: BigInt(entry.envelope.epoch),
            nonce: entry.envelope.nonce,
            ciphertext: entry.envelope.ciphertext
          }, aad2);
          let verified;
          let signed;
          const trustedId = entry.fromStore === true ? bytesToHex(entry.envelope.opId) : null;
          if (trustedId !== null && this.#trustedOpIds.has(trustedId)) {
            signed = decodeTrustedSignedOperation(plaintext);
            const opId = operationIdDigest(signed.coreBytes);
            if (bytesToHex(opId) !== trustedId) return;
            verified = { core: decodeTrustedOperationCore(signed.coreBytes), opId };
          } else {
            signed = decodeSignedOperation(plaintext);
            verified = await verifySignedOperation(signed);
          }
          if (bytesToHex(verified.core.logId) !== this.logId) return;
          if (verified.core.visibility !== "encrypted") return;
          if (!sameBytes(verified.opId, entry.envelope.opId) || !sameBytes(verified.core.author, entry.envelope.author)) return;
          entry.decrypted = { opId: bytesToHex(verified.opId), signed, core: verified.core };
          this.#undecryptedEnvelopes.delete(digest3);
        } catch {
        }
      })());
      if (work.length >= 64) await Promise.all(work.splice(0));
    }
    await Promise.all(work);
  }
  /**
   * Reconnect rewrapping: if this device authored offline encrypted ops under an older epoch
   * and $keys has since rotated to a newer epoch that we hold (and we are still a writer),
   * re-encrypt the EXACT original SignedOperation bytes under the newest epoch so peers can
   * decrypt them without changing opId, authorTimestampMs, or signature!
   */
  async #rewrapPendingLocalOps(kernel = this.#kernel) {
    if (!this.genesis.privateLog || this.#blindHostMode) return false;
    const newestEpoch = this.#currentEpochFrom(kernel);
    if (newestEpoch < 0) return false;
    const newestKey = this.#epochKeys.get(newestEpoch);
    if (newestKey === void 0 || !this.isWriter(this.identity.publicKey)) return false;
    let rewrapped = false;
    for (const [opId, pending] of this.#localPending) {
      if (pending.currentEpoch >= newestEpoch) continue;
      const logIdBytes = hexToBytes(this.logId);
      const opIdBytes = hexToBytes(opId);
      const aad2 = envelopeAad(logIdBytes, opIdBytes, pending.core.author);
      const enc = await encryptEpochPayload(newestKey, BigInt(newestEpoch), pending.raw, aad2);
      const env = {
        version: 1,
        logId: logIdBytes,
        opId: opIdBytes,
        author: pending.core.author,
        epoch: newestEpoch,
        nonce: enc.nonce,
        ciphertext: enc.ciphertext
      };
      const envBytes = encodeEncryptedEnvelope(env);
      const envDigest = bytesToHex(encryptedEnvelopeDigest(envBytes));
      const oldRetentions = this.#retentions.get(opId);
      const oldRetainedRemotely = oldRetentions !== void 0 && [...oldRetentions.values()].some((r) => r.signer !== this.identity.publicKey);
      if (!oldRetainedRemotely && this.#encryptedEnvelopes.has(pending.currentEnvelopeDigest)) {
        this.#encryptedEnvelopes.delete(pending.currentEnvelopeDigest);
        await this.#store.delete?.(`${this.#prefix}/enc-env/${pending.currentEnvelopeDigest}`);
      }
      await this.#store.put(`${this.#prefix}/enc-env/${envDigest}`, envBytes);
      this.#encryptedEnvelopes.set(envDigest, {
        digest: envDigest,
        raw: envBytes,
        envelope: env,
        decrypted: { opId, signed: pending.signed, core: pending.core }
      });
      pending.currentEpoch = newestEpoch;
      pending.currentEnvelopeDigest = envDigest;
      await this.#store.put(`${this.#prefix}/local-pending/${opId}`, encodeLocalPending(pending.raw, envDigest, newestEpoch));
      rewrapped = true;
    }
    return rewrapped;
  }
  /** Stable kernel input objects per op (lets the kernel memoize id/validation work by identity). */
  #kernelInputs = /* @__PURE__ */ new Map();
  /** $reducers configurations already scanned and found not to need SQLite. */
  #sqliteScanNegative = /* @__PURE__ */ new Set();
  /** operationId -> opId for ops authored by this identity (O(1) inspect by caller-chosen id). */
  #ownOperationIds = /* @__PURE__ */ new Map();
  #kernelInput(opId, core) {
    let input = this.#kernelInputs.get(opId);
    if (input === void 0 || input.core !== core) {
      input = { opId: hexToBytes(opId), core, verified: true };
      this.#kernelInputs.set(opId, input);
      if (bytesToHex(core.author) === this.identity.publicKey) this.#ownOperationIds.set(core.operationId, opId);
    }
    return input;
  }
  #collectDecryptedKernelInputs() {
    const byOpId = /* @__PURE__ */ new Map();
    for (const [opId, entry] of this.#publicOps) {
      byOpId.set(opId, this.#kernelInput(opId, entry.core));
    }
    if (!this.#blindHostMode) {
      for (const entry of this.#encryptedEnvelopes.values()) {
        if (entry.decrypted === void 0) continue;
        if (!byOpId.has(entry.decrypted.opId)) {
          byOpId.set(entry.decrypted.opId, this.#kernelInput(entry.decrypted.opId, entry.decrypted.core));
        }
      }
    }
    return byOpId;
  }
  /** Swap in a SQLite-capable kernel before restoring state whose reducers need chronolog:sqlite. */
  async #upgradeKernelForSqlite(reducers) {
    if (this.#kernelHasSqlite || !await this.#ensureSqliteIfNeeded(reducers) || this.#sqliteDriver === void 0) return;
    this.#kernel.dispose();
    this.#kernel = new TopicKernel({
      genesis: this.genesisBytes,
      cas: this.cas,
      blindHostMode: this.#blindHostMode,
      ...this.#sandboxOptions,
      sqliteDriver: this.#sqliteDriver
    });
    this.#kernelHasSqlite = true;
    this.#finalKernel?.dispose();
    this.#finalKernel = null;
  }
  async #rematerialize() {
    return perfTimeAsync("session.rematerialize", () => this.#rematerialize__impl());
  }
  async #rematerialize__impl() {
    const prevDigest = this.#lastLocalRevision.digest;
    const prevFinalDigest = this.#lastFinalRevision?.digest ?? null;
    const prevKernel = this.#kernel;
    const prevOutcomeList = this.#kernel.materializedOutcomes;
    const prevRestores = this.#kernel.cacheRestores;
    try {
      const publicInputs = [];
      for (const [opId, entry] of this.#publicOps) {
        publicInputs.push(this.#kernelInput(opId, entry.core));
      }
      let controlKernel;
      let rewrapped = false;
      let ephemeralControl = null;
      let allByOpId;
      if (this.#controlKernel !== null) {
        controlKernel = this.#controlKernel;
        await controlKernel.materialize(publicInputs);
        await this.#refreshPermissionsCache(controlKernel);
        await this.#unsealAvailableEpochKeys(controlKernel);
        await this.#decryptPendingEnvelopes();
        rewrapped = await this.#rewrapPendingLocalOps(controlKernel);
        allByOpId = this.#collectDecryptedKernelInputs();
      } else {
        allByOpId = this.#collectDecryptedKernelInputs();
        if (this.#checkpoints.size > 0) {
          await this.#ensureSqliteIfNeeded();
          controlKernel = new TopicKernel({
            genesis: this.genesisBytes,
            cas: this.cas,
            blindHostMode: this.#blindHostMode,
            ...this.#sandboxOptions,
            ...this.#sqliteDriver === void 0 ? {} : { sqliteDriver: this.#sqliteDriver }
          });
          ephemeralControl = controlKernel;
          await controlKernel.materialize(publicInputs);
        } else {
          controlKernel = this.#kernel;
        }
      }
      const schedule = parseFinalitySchedule(controlKernel.topic("$finality"));
      this.#verifiedFinality = await verifyFinalityV2({
        logId: this.logId,
        schedule,
        checkpoints: [...this.#checkpoints.values()],
        knownOps: [...allByOpId.entries()].map(([opId, input]) => ({
          opId,
          authorTimestampMs: input.core.authorTimestampMs
        })),
        predicateVerifier: controlKernel.createFinalityPredicateVerifier(),
        ...this.#blockchainVerifier === void 0 ? {} : { blockchainVerifier: this.#blockchainVerifier }
      });
      const eligibleLocal = [];
      for (const [opId, input] of allByOpId) {
        if (this.#verifiedFinality.excludedOpIds.has(opId)) continue;
        eligibleLocal.push(input);
      }
      const needsKernelUpgrade = await this.#ensureSqliteIfNeeded(controlKernel.topic("$reducers"), controlKernel.topic("$mounts"));
      ephemeralControl?.dispose();
      if (needsKernelUpgrade && this.#sqliteDriver !== void 0) {
        this.#kernel.dispose();
        const nextKernel = new TopicKernel({
          genesis: this.genesisBytes,
          cas: this.cas,
          blindHostMode: this.#blindHostMode,
          ...this.#sandboxOptions,
          sqliteDriver: this.#sqliteDriver
        });
        this.#kernel = nextKernel;
        this.#kernelHasSqlite = true;
        this.#finalKernel?.dispose();
        this.#finalKernel = null;
      }
      if (this.#pendingEncryptedSnapshot !== null) {
        const decoded = await this.#decodeMaterializedSnapshot(this.#pendingEncryptedSnapshot);
        if (decoded !== null) {
          if (decoded.casNodes.length > 0) {
            await this.cas.putManyVerified(decoded.casNodes);
          }
          this.#pendingSnapshotBundle = decoded;
          this.#pendingEncryptedSnapshot = null;
        } else if (this.#epochKeys.size > 0 || !this.genesis.privateLog) {
          this.#pendingEncryptedSnapshot = null;
        }
      }
      if (this.#pendingSnapshotBundle !== null) {
        const bundle = this.#pendingSnapshotBundle;
        this.#pendingSnapshotBundle = null;
        const covered = bundle.cache.frontierOpIds.length + bundle.cache.orderOpIds.length;
        if (covered > this.#kernel.revision("local").orderLength) {
          await this.#upgradeKernelForSqlite(bundle.cache.topics.$reducers);
          if (await this.#kernel.restoreSnapshotFrontier(bundle.cache)) this.#materializedCacheHits++;
        }
      }
      if (this.#pendingMaterializedCache !== null && (eligibleLocal.length > 0 || this.#pendingMaterializedCache.frontierOpIds.length > 0)) {
        const cached = this.#pendingMaterializedCache;
        this.#pendingMaterializedCache = null;
        await this.#upgradeKernelForSqlite(cached.topics.$reducers);
        if (await this.#kernel.restoreMaterializedCache(cached, eligibleLocal)) {
          this.#materializedCacheHits++;
          this.#lastPersistedCacheDigest = this.#kernel.revision("local").digest;
        }
      }
      let localResult;
      try {
        localResult = await this.#kernel.materialize(eligibleLocal);
      } catch (error) {
        if (!(error instanceof Error) || error.message !== "KERNEL_FRONTIER_REWIND") throw error;
        this.#kernel.dispose();
        this.#kernel = new TopicKernel({
          genesis: this.genesisBytes,
          cas: this.cas,
          blindHostMode: this.#blindHostMode,
          ...this.#sandboxOptions,
          ...this.#sqliteDriver === void 0 ? {} : { sqliteDriver: this.#sqliteDriver }
        });
        this.#finalKernel?.dispose();
        this.#finalKernel = null;
        localResult = await this.#kernel.materialize(eligibleLocal);
      }
      if (localResult.pendingDependencies.length > 0 && this.#casMirrors.length > 0) {
        const fetched = await this.#pullMissingFromMirrors();
        if (fetched > 0) {
          localResult = await this.#kernel.materialize(eligibleLocal);
        }
      }
      if (!this.#kernelHasSqlite && await this.#ensureSqliteIfNeeded(this.#kernel.topic("$reducers")) && this.#sqliteDriver !== void 0) {
        const nextKernel = new TopicKernel({
          genesis: this.genesisBytes,
          cas: this.cas,
          blindHostMode: this.#blindHostMode,
          ...this.#sandboxOptions,
          sqliteDriver: this.#sqliteDriver
        });
        localResult = await nextKernel.materialize(eligibleLocal);
        this.#kernel.dispose();
        this.#kernel = nextKernel;
        this.#kernelHasSqlite = true;
        this.#finalKernel?.dispose();
        this.#finalKernel = null;
      }
      await this.#refreshPermissionsCache(this.#kernel);
      this.#lastLocalRevision = toMaterializedRevision(localResult.revision);
      if (localResult.pendingDependencies.length === 0 && (eligibleLocal.length > 0 || this.#kernel.frontierOrderLength > 0) && localResult.revision.digest !== this.#lastPersistedCacheDigest) {
        this.#scheduleCachePersist();
      }
      if (this.#verifiedFinality.closedThroughMs !== null) {
        this.#finalKernel ??= new TopicKernel({
          genesis: this.genesisBytes,
          cas: this.cas,
          blindHostMode: this.#blindHostMode,
          ...this.#sandboxOptions,
          ...this.#sqliteDriver === void 0 ? {} : { sqliteDriver: this.#sqliteDriver }
        });
        const finalInputs = [];
        for (const [opId, input] of allByOpId) {
          if (this.#verifiedFinality.includedOpIds.has(opId)) finalInputs.push(input);
        }
        await this.#finalKernel.materialize(finalInputs);
        this.#lastFinalRevision = toMaterializedRevision(this.#finalKernel.revision("final"));
      } else {
        this.#lastFinalRevision = null;
      }
      if (this.#cachedSignalPolicy !== null && this.#cachedSignalPolicy.stateRoot !== this.#lastLocalRevision.stateRoot) {
        this.#cachedSignalPolicy = null;
      }
      this.#materializationError = null;
      const revised = [];
      const changedTopicsSet = /* @__PURE__ */ new Set();
      const changedTablesSet = /* @__PURE__ */ new Set();
      let hasHistoryRevision = false;
      let allNewSqlWithTables = true;
      let sawNewSql = false;
      const replayedFrom = this.#kernel === prevKernel && this.#kernel.cacheRestores === prevRestores ? localResult.replayedFrom ?? 0 : 0;
      const prevOutcomes = /* @__PURE__ */ new Map();
      for (let i = replayedFrom; i < prevOutcomeList.length; i++) {
        const o = prevOutcomeList[i];
        prevOutcomes.set(o.opId, `${o.outcome}:${o.rejectionCode ?? ""}`);
      }
      for (let i = replayedFrom; i < localResult.outcomes.length; i++) {
        const o = localResult.outcomes[i];
        const key = `${o.outcome}:${o.rejectionCode ?? ""}`;
        const prevKey = prevOutcomes.get(o.opId);
        if (prevKey !== key) {
          revised.push(o.opId);
          if (prevKey !== void 0) {
            hasHistoryRevision = true;
          } else if (o.outcome === "accepted") {
            const input = allByOpId.get(o.opId);
            if (input !== void 0) {
              for (const u of input.core.updates) changedTopicsSet.add(u.topic);
            }
            let opHadTableEvent = false;
            for (const ev of o.events) {
              if (ev.topic === "sql.tables_changed" && ev.payload && typeof ev.payload === "object" && !Array.isArray(ev.payload)) {
                const tbls = ev.payload.tables;
                if (Array.isArray(tbls)) {
                  opHadTableEvent = true;
                  sawNewSql = true;
                  for (const t of tbls) {
                    if (typeof t === "string") changedTablesSet.add(t);
                  }
                }
              }
            }
            if (!opHadTableEvent && o.events.some((ev) => ev.topic === "sql.migrated" || ev.topic === "sql.rls_updated")) {
              allNewSqlWithTables = false;
            }
          }
        }
      }
      const changedTopics = !hasHistoryRevision && changedTopicsSet.size > 0 ? [...changedTopicsSet].sort() : void 0;
      const changedTables = !hasHistoryRevision && sawNewSql && allNewSqlWithTables && changedTablesSet.size > 0 ? [...changedTablesSet].sort() : void 0;
      if (this.#lastLocalRevision.digest !== prevDigest) {
        this.#emitChange({
          kind: localResult.pendingDependencies.length > 0 ? "dependency" : "materialized",
          revision: this.#lastLocalRevision,
          revisedProposalIds: revised,
          ...changedTopics === void 0 ? {} : { changedTopics },
          ...changedTables === void 0 ? {} : { changedTables }
        });
      }
      if (this.#lastFinalRevision !== null && this.#lastFinalRevision.digest !== prevFinalDigest) {
        this.#emitChange({
          kind: "finalized",
          revision: this.#lastFinalRevision,
          revisedProposalIds: []
        });
      }
      this.#emitStatus();
      if (rewrapped) this.#emitFacts();
    } catch (error) {
      this.#materializationError = error instanceof Error ? error.message : String(error);
      this.#emitStatus();
      throw error;
    }
  }
  async #resolveSignalPolicy() {
    const stateRoot = this.#lastLocalRevision.stateRoot;
    if (this.#cachedSignalPolicy !== null && this.#cachedSignalPolicy.stateRoot === stateRoot) {
      return this.#cachedSignalPolicy;
    }
    const policy = await this.#kernel.signalPolicy();
    this.#cachedSignalPolicy = { stateRoot, rules: policy.rules };
    return this.#cachedSignalPolicy;
  }
  /** Author locally and durably before network delivery (fast local-append lane; materializes in background unless awaitMaterialized is true). */
  async submit(input) {
    const op = await this.#writeLane(async () => {
      check(!this.#blindHostMode, "SESSION_BLIND_HOST_CANNOT_AUTHOR");
      check(Array.isArray(input.updates) && input.updates.length > 0, "OPERATION_UPDATES_REQUIRED");
      const updatesList = input.updates;
      const allControl = updatesList.every((u) => isControlTopic(u.topic));
      const anyControl = updatesList.some((u) => isControlTopic(u.topic));
      check(!anyControl || allControl, "OPERATION_CROSS_PARTITION_FORBIDDEN");
      const visibility = input.visibility ?? (this.genesis.privateLog ? allControl ? "public" : "encrypted" : "public");
      if (this.genesis.privateLog) {
        if (allControl) check(visibility === "public", "CONTROL_OP_MUST_BE_PUBLIC");
        else check(visibility === "encrypted", "PRIVATE_OP_MUST_BE_ENCRYPTED");
      }
      const operationId = input.operationId ?? crypto.randomUUID();
      for (const [opId, entry] of this.#publicOps) {
        if (entry.core.visibility === visibility && bytesToHex(entry.core.author) === this.identity.publicKey && entry.core.operationId === operationId) {
          return new ApplicationOperation(opId, operationId, this);
        }
      }
      for (const [opId, pending] of this.#localPending) {
        if (pending.core.visibility === visibility && pending.core.operationId === operationId) {
          return new ApplicationOperation(opId, operationId, this);
        }
      }
      const combinedChecks = [
        ...input.assumptions?.checks ?? [],
        ...(input.afterOps ?? []).map((opId) => ({ kind: "op_accepted", opId })),
        ...(input.requiresRejected ?? []).map((opId) => ({ kind: "op_rejected", opId }))
      ];
      const onFailed = input.assumptions?.onFailed ?? input.onAssumptionFailed;
      const assumptions = combinedChecks.length > 0 ? normalizeAssumptionsConfig({
        checks: combinedChecks,
        ...onFailed === void 0 ? {} : { onFailed }
      }) : void 0;
      let causalFloorMs = 0n;
      if (assumptions !== void 0) {
        const referencedOpIds = /* @__PURE__ */ new Set();
        for (const chk of assumptions.checks) {
          if (chk.kind === "op_accepted" || chk.kind === "op_rejected" || chk.kind === "op_present") referencedOpIds.add(chk.opId);
          else if ((chk.kind === "topic_revision" || chk.kind === "author_last_op") && chk.lastOpId !== null) referencedOpIds.add(chk.lastOpId);
        }
        for (const refId of referencedOpIds) {
          const pub = this.#publicOps.get(refId);
          if (pub !== void 0 && pub.core.authorTimestampMs + 1n > causalFloorMs) {
            causalFloorMs = pub.core.authorTimestampMs + 1n;
          }
          for (const enc of this.#encryptedEnvelopes.values()) {
            const dec = enc.decrypted;
            if (dec !== null && dec !== void 0 && dec.opId === refId && dec.core.authorTimestampMs + 1n > causalFloorMs) {
              causalFloorMs = dec.core.authorTimestampMs + 1n;
            }
          }
        }
      }
      const nowMs = BigInt(Date.now());
      const authorTimestampMs = input.authorTimestampMs ?? (nowMs >= causalFloorMs ? nowMs : causalFloorMs);
      const logIdBytes = hexToBytes(this.logId);
      const authorBytes = hexToBytes(this.identity.publicKey);
      const core = {
        version: 1,
        logId: logIdBytes,
        author: authorBytes,
        operationId,
        authorTimestampMs,
        nonce: crypto.getRandomValues(new Uint8Array(16)),
        visibility,
        updates: updatesList.map((u) => ({ topic: u.topic, input: normalizeJsonValue(u.input) })),
        ...assumptions === void 0 ? {} : { assumptions }
      };
      const signed = await signOperationCore(core, this.device.identity.privateKey);
      const opBytes = encodeSignedOperation(signed);
      const opIdBytes = operationIdDigest(signed.coreBytes);
      const opIdHex = bytesToHex(opIdBytes);
      if (visibility === "public") {
        await this.#store.put(`${this.#prefix}/public-op/${opIdHex}`, opBytes, { durability: "strict" });
        this.#publicOps.set(opIdHex, { raw: opBytes, signed, core });
      } else {
        const keysState = this.keysState();
        const ringNames = new Set(updatesList.map((u) => keysState.topicRings?.[u.topic] ?? "default"));
        check(ringNames.size === 1, "OPERATION_CROSS_RING_FORBIDDEN");
        const ring = [...ringNames][0];
        const epoch = ring === "default" ? this.currentEpoch() : keysState.rings?.[ring]?.currentEpoch ?? -1;
        check(epoch >= 0, "EPOCH_KEY_REQUIRED");
        const epochKey = ring === "default" ? this.#epochKeys.get(epoch) : this.#ringKeys.get(ring)?.get(epoch);
        check(epochKey !== void 0, "EPOCH_KEY_MISSING");
        const aad2 = envelopeAad(logIdBytes, opIdBytes, authorBytes);
        const enc = await encryptEpochPayload(epochKey, BigInt(epoch), opBytes, aad2);
        const env = {
          version: 1,
          logId: logIdBytes,
          opId: opIdBytes,
          author: authorBytes,
          epoch,
          nonce: enc.nonce,
          ciphertext: enc.ciphertext,
          ...ring === "default" ? {} : { ring }
        };
        const envBytes = encodeEncryptedEnvelope(env);
        const envDigest = bytesToHex(encryptedEnvelopeDigest(envBytes));
        await writeBytesMany(this.#store, [
          { key: `${this.#prefix}/enc-env/${envDigest}`, value: envBytes },
          {
            key: `${this.#prefix}/local-pending/${opIdHex}`,
            value: encodeLocalPending(opBytes, envDigest, epoch)
          }
        ], { durability: "strict" });
        this.#encryptedEnvelopes.set(envDigest, {
          digest: envDigest,
          raw: envBytes,
          envelope: env,
          decrypted: { opId: opIdHex, signed, core }
        });
        this.#localPending.set(opIdHex, {
          raw: opBytes,
          signed,
          core,
          currentEnvelopeDigest: envDigest,
          currentEpoch: epoch
        });
      }
      if (this.#store.latestChangeSeq !== void 0) {
        this.#lastSyncSeq = Math.max(this.#lastSyncSeq, await this.#store.latestChangeSeq());
      }
      this.#emitFacts();
      void this.#scheduleMaterialize().catch(() => void 0);
      return new ApplicationOperation(opIdHex, operationId, this);
    });
    if (input.awaitMaterialized === true) {
      await this.#flushPendingMaterialization();
    }
    return op;
  }
  /** Execute a named command (via local ApplicationDefinition if present, else direct topic dispatch). */
  async command(name, input = {}, options = {}) {
    if (this.definition !== void 0 && Object.hasOwn(this.definition.commands, name)) {
      const cmd = this.definition.commands[name];
      const updates = cmd.prepare(input);
      return this.submit({ ...options, updates });
    }
    const reducers = this.#kernel.topic("$reducers");
    const topics = reducers?.topics ?? {};
    if (Object.hasOwn(topics, name)) {
      return this.submit({ ...options, updates: [{ topic: name, input: normalizeJsonValue(input) }] });
    }
    const sep = name.includes(".") ? name.indexOf(".") : name.indexOf(":");
    if (sep > 0) {
      const topic = name.slice(0, sep);
      const action = name.slice(sep + 1);
      if (Object.hasOwn(topics, topic)) {
        const body2 = input !== null && typeof input === "object" && !Array.isArray(input) ? { action, ...input } : { action, input: normalizeJsonValue(input) };
        return this.submit({ ...options, updates: [{ topic, input: body2 }] });
      }
    }
    const appTopics = Object.keys(topics).filter((t) => !isControlTopic(t));
    if (appTopics.length === 1) {
      const topic = appTopics[0];
      const described = await this.#describeForValidation();
      const matchesDescribed = (cName) => cName === name || cName === `${topic}.${name}` || cName === `${topic}:${name}`;
      if (described && described.commands.length > 0 && !described.commands.some((c) => matchesDescribed(c.name))) {
        throw new Error(`APPLICATION_COMMAND_UNKNOWN:${name}`);
      }
      const body2 = input !== null && typeof input === "object" && !Array.isArray(input) ? { action: name, ...input } : { action: name, input: normalizeJsonValue(input) };
      return this.submit({ ...options, updates: [{ topic, input: body2 }] });
    }
    throw new Error(`APPLICATION_COMMAND_UNKNOWN:${name}`);
  }
  /** Execute a named query (via local ApplicationDefinition if present, else reducer query()). */
  async query(name, input = null, _options) {
    await this.#flushPendingMaterialization();
    if (this.definition !== void 0 && Object.hasOwn(this.definition.queries, name)) {
      const view = await this.readView();
      try {
        const value = await this.definition.queries[name].read(view, input);
        return { applicationId: this.applicationId, revision: view.revision, value };
      } finally {
        view.release();
      }
    }
    const reducers = this.#kernel.topic("$reducers");
    const topics = reducers?.topics ?? {};
    if (Object.hasOwn(topics, name)) {
      const value = await this.#kernel.query(name, normalizeJsonValue(input));
      return { applicationId: this.applicationId, revision: this.#lastLocalRevision, value };
    }
    const sep = name.includes(".") ? name.indexOf(".") : name.indexOf(":");
    if (sep > 0) {
      const topic = name.slice(0, sep);
      const queryName = name.slice(sep + 1);
      if (Object.hasOwn(topics, topic)) {
        const body2 = input !== null && typeof input === "object" && !Array.isArray(input) ? { query: queryName, ...input } : { query: queryName, input: normalizeJsonValue(input) };
        const value = await this.#kernel.query(topic, body2);
        return { applicationId: this.applicationId, revision: this.#lastLocalRevision, value };
      }
    }
    const appTopics = Object.keys(topics).filter((t) => !isControlTopic(t));
    if (appTopics.length === 1) {
      const topic = appTopics[0];
      const described = await this.#describeForValidation();
      const matchesDescribed = (qName) => qName === name || qName === `${topic}.${name}` || qName === `${topic}:${name}`;
      if (described && described.queries.length > 0 && !described.queries.some((q) => matchesDescribed(q.name))) {
        throw new Error(`APPLICATION_QUERY_UNKNOWN:${name}`);
      }
      const body2 = input !== null && typeof input === "object" && !Array.isArray(input) ? { query: name, ...input } : { query: name, input: normalizeJsonValue(input) };
      const value = await this.#kernel.query(topic, body2);
      return { applicationId: this.applicationId, revision: this.#lastLocalRevision, value };
    }
    throw new Error(`APPLICATION_QUERY_UNKNOWN:${name}`);
  }
  /**
   * Command/query name validation only needs the reducer surface, which changes with `$reducers`,
   * not with every application write; cache it per `$reducers` content hash.
   */
  async #describeForValidation() {
    const key = this.#kernel.topicHash("$reducers") ?? "";
    if (this.#validationDescription !== null && this.#validationDescription.key === key) return this.#validationDescription.value;
    const value = await this.describe().catch(() => null);
    this.#validationDescription = { key, value };
    return value;
  }
  /** Describe available commands and queries (from local definition or in-chain reducer describe() exports). */
  async describe() {
    await this.#flushPendingMaterialization();
    if (this.definition !== void 0) return describeApplication(this.definition);
    const stateRoot = this.#lastLocalRevision.stateRoot;
    if (this.#cachedDescription !== null && this.#cachedDescription.stateRoot === stateRoot) {
      return structuredClone(this.#cachedDescription.value);
    }
    const raw = await this.#kernel.describe();
    const commands = [];
    const queries = [];
    const multiTopic = Object.keys(raw).filter((t) => !isControlTopic(t)).length > 1;
    for (const [topic, entry] of Object.entries(raw)) {
      if (entry === null || typeof entry !== "object" || Array.isArray(entry)) continue;
      const obj = entry;
      const prefix = multiTopic ? `${topic}.` : "";
      if (Array.isArray(obj.commands)) {
        for (const c of obj.commands) {
          if (c && typeof c === "object" && typeof c.name === "string") {
            const cmd = c;
            commands.push({
              name: `${prefix}${cmd.name}`,
              description: cmd.description ?? "",
              input: checkedApplicationInputSchema(cmd.input ?? { type: "object", properties: {} })
            });
          }
        }
      }
      if (Array.isArray(obj.queries)) {
        for (const q of obj.queries) {
          if (q && typeof q === "object" && typeof q.name === "string") {
            const qry = q;
            queries.push({
              name: `${prefix}${qry.name}`,
              description: qry.description ?? "",
              input: checkedApplicationInputSchema(qry.input ?? { type: "object", properties: {} })
            });
          }
        }
      }
    }
    commands.sort((a, b) => a.name.localeCompare(b.name));
    queries.sort((a, b) => a.name.localeCompare(b.name));
    const description = validateApplicationDescription({
      id: `chain-${this.logId.slice(0, 16)}`,
      version: "2.0.0",
      commands,
      queries
    });
    this.#cachedDescription = { stateRoot, value: structuredClone(description) };
    return description;
  }
  #hasActiveFinalityPolicy() {
    const schedule = parseFinalitySchedule(this.#kernel.topic("$finality"));
    return schedule.some((entry) => entry.policy.kind !== "none");
  }
  opOutcome(opId) {
    return this.#kernel.opOutcome(opId);
  }
  topicLastOpId(topic) {
    return this.#kernel.topicLastOpId(topic);
  }
  authorLastOpId(author) {
    return this.#kernel.authorLastOpId(author ?? this.identity.publicKey);
  }
  /**
   * Plain-language finality lifecycle status for UI badges (Pending -> Confirmed -> Needs attention):
   * - 'equivocated': notary/witness equivocation detected (fraud proof available via equivocationProofs())
   * - 'finalized': op is included in a verified $finality checkpoint
   * - 'excluded': closed-time frontier passed op's timestamp without including it
   * - 'synced': op has retention evidence from at least one peer/host
   * - 'local': authored/stored locally, awaiting sync or finality
   */
  finalityStatus(opId) {
    if (this.#verifiedFinality.equivocationProofs.length > 0) return "equivocated";
    if (this.#verifiedFinality.includedOpIds.has(opId)) return "finalized";
    if (this.#verifiedFinality.excludedOpIds.has(opId)) return "excluded";
    const ret = this.#retentions.get(opId);
    if (ret !== void 0 && ret.size > 0) return "synced";
    return "local";
  }
  equivocationProofs() {
    return this.#verifiedFinality.equivocationProofs;
  }
  /**
   * Time-travel query: run any topic query against a historical opId or timestamp
   * without mutating live session state.
   */
  async queryAsOf(topic, input = null, target) {
    await this.#flushPendingMaterialization();
    const res = await this.#kernel.queryAt(topic, input, target);
    return {
      applicationId: this.applicationId,
      revision: toMaterializedRevision(res.revision),
      targetOpId: res.targetOpId,
      value: res.value
    };
  }
  /**
   * Open a zero-copy O(1) SQLite branch over the current dbRoot of a chronolog/sql topic.
   * Run speculative queries/mutations, compute exact row-level diffs, and optionally export a guarded proposal.
   */
  async forkSql(topic) {
    await this.#flushPendingMaterialization();
    const topicState = this.#kernel.topic(topic);
    const baseRoot = topicState !== null && typeof topicState === "object" && typeof topicState.dbRoot === "string" ? topicState.dbRoot : null;
    let driver = this.#sqliteDriver;
    if (driver === void 0) {
      const { createSqliteCasDriver } = await import("./src-B2RZ3WJY.mjs");
      driver = await createSqliteCasDriver();
      this.#sqliteDriver = driver;
    }
    const partition = this.genesis.privateLog && isControlTopic(topic) ? "public" : "private";
    return openSqlBranch({
      topic,
      baseRoot,
      cas: this.cas,
      partition,
      driver,
      actor: this.identity.publicKey
    });
  }
  /** Capture a coherent read snapshot for reactive views, queries, and event pagination. */
  async readView(options = {}) {
    await this.#flushPendingMaterialization();
    const viewKind = options.view ?? "local";
    if (viewKind === "final" && !this.#hasActiveFinalityPolicy()) {
      throw Object.assign(new Error("FINALITY_UNSUPPORTED"), { code: "FINALITY_UNSUPPORTED" });
    }
    const kernel = viewKind === "final" ? this.#finalKernel : this.#kernel;
    const revision = kernel === null ? this.revision(viewKind) : toMaterializedRevision(kernel.revision(viewKind));
    const topicsSnap = kernel === null ? {} : kernel.topics;
    const outcomesSnap = kernel === null ? [] : kernel.outcomes;
    const opOutcomeSnap = /* @__PURE__ */ new Map();
    for (const o of outcomesSnap) opOutcomeSnap.set(o.opId, o.outcome);
    const events = [];
    for (const outcome of outcomesSnap) {
      if (outcome.outcome !== "accepted") continue;
      for (const ev of outcome.events) events.push(toApplicationEvent(ev));
    }
    let released = false;
    const checkLive = () => {
      if (released) throw new Error("READ_VIEW_RELEASED");
    };
    return {
      applicationId: this.applicationId,
      revision,
      topic(name) {
        checkLive();
        return Object.hasOwn(topicsSnap, name) ? structuredClone(topicsSnap[name]) : null;
      },
      async query(topic, input) {
        checkLive();
        if (kernel === null) return Object.hasOwn(topicsSnap, topic) ? structuredClone(topicsSnap[topic]) : null;
        return kernel.query(topic, input ?? null, topicsSnap);
      },
      opOutcome(opId) {
        checkLive();
        return opOutcomeSnap.get(opId) ?? null;
      },
      topicLastOpId(topic) {
        checkLive();
        return kernel === null ? null : kernel.topicLastOpId(topic);
      },
      readEvents(eventOptions = {}) {
        checkLive();
        return sliceEvents(events, revision, eventOptions);
      },
      release() {
        released = true;
      }
    };
  }
  readEvents(options = {}) {
    const viewKind = options.view ?? "local";
    if (viewKind === "final" && !this.#hasActiveFinalityPolicy()) {
      throw Object.assign(new Error("FINALITY_UNSUPPORTED"), { code: "FINALITY_UNSUPPORTED" });
    }
    const kernel = viewKind === "final" ? this.#finalKernel : this.#kernel;
    const revision = kernel === null ? this.revision(viewKind) : toMaterializedRevision(kernel.revision(viewKind));
    const events = [];
    if (kernel !== null) {
      for (const outcome of kernel.outcomes) {
        if (outcome.outcome !== "accepted") continue;
        for (const ev of outcome.events) events.push(toApplicationEvent(ev));
      }
    }
    return sliceEvents(events, revision, options);
  }
  // ---- High-level v2 control helpers ----
  async admitMember(options) {
    const memberPayload = {
      publicKey: options.publicKey,
      ...options.wrapKey ? { wrapKey: options.wrapKey } : {},
      ...options.label ? { label: options.label } : {},
      ...options.subject ? { subject: options.subject } : {},
      ...options.scopes && options.scopes.length > 0 ? { scopes: [...options.scopes] } : {},
      ...options.expiresAtMs !== void 0 ? { expiresAtMs: options.expiresAtMs } : {},
      reader: options.reader ?? true,
      writer: options.writer ?? true,
      administrator: options.administrator ?? false,
      publisher: options.publisher ?? false,
      finalizer: options.finalizer ?? false
    };
    const updates = [
      {
        topic: "$permissions",
        input: {
          action: "setMember",
          member: memberPayload,
          ...options.attestation ? { attestation: options.attestation } : {}
        }
      }
    ];
    if (this.genesis.privateLog && (options.reader ?? true) && options.wrapKey) {
      const keysState = this.keysState();
      if (keysState.currentEpoch < 0) {
        const epoch0 = this.#epochKeys.get(0) ?? crypto.getRandomValues(new Uint8Array(32));
        await this.installEpochKey(0, epoch0);
        const boxes = {};
        const allReaders = /* @__PURE__ */ new Map();
        for (const m of this.permissions().members) {
          if (m.reader && m.wrapKey) allReaders.set(m.publicKey, m.wrapKey);
        }
        allReaders.set(options.publicKey, options.wrapKey);
        for (const [pk, wk] of allReaders) {
          boxes[pk] = await hpkeSealEpochKey(wk, epoch0, this.logId, 0);
        }
        updates.push({
          topic: "$keys",
          input: {
            action: "rotateEpoch",
            epoch: 0,
            keyCommitment: epochKeyCommitmentV2(epoch0),
            boxes
          }
        });
      } else {
        const minEp = options.minEpoch ?? 0;
        const epochBoxes = {};
        for (let ep = minEp; ep <= keysState.currentEpoch; ep++) {
          const epKey = this.#epochKeys.get(ep);
          if (epKey === void 0) continue;
          epochBoxes[String(ep)] = await hpkeSealEpochKey(options.wrapKey, epKey, this.logId, ep);
        }
        if (Object.keys(epochBoxes).length > 0) {
          updates.push({
            topic: "$keys",
            input: {
              action: "grantBoxes",
              member: options.publicKey,
              epochBoxes
            }
          });
        }
      }
    }
    return this.submit({
      visibility: "public",
      awaitMaterialized: true,
      updates,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs }
    });
  }
  async rotateEpoch(options = {}) {
    check(this.genesis.privateLog, "EPOCH_ROTATION_PRIVATE_LOG_ONLY");
    await this.#flushPendingMaterialization();
    const keysState = this.keysState();
    const nextEpoch = keysState.currentEpoch + 1;
    const key = options.newEpochKey ?? crypto.getRandomValues(new Uint8Array(32));
    await this.installEpochKey(nextEpoch, key);
    const exclude = new Set(options.excludeMembers ?? []);
    const boxes = {};
    for (const m of this.permissions().members) {
      if (!m.reader || !m.wrapKey || exclude.has(m.publicKey)) continue;
      boxes[m.publicKey] = await hpkeSealEpochKey(m.wrapKey, key, this.logId, nextEpoch);
    }
    const operation = await this.submit({
      visibility: "public",
      awaitMaterialized: true,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$keys",
        input: {
          action: "rotateEpoch",
          epoch: nextEpoch,
          keyCommitment: epochKeyCommitmentV2(key),
          boxes
        }
      }]
    });
    return { epoch: nextEpoch, operation };
  }
  /**
   * Create or rotate a named compartment key ring in $keys (e.g. 'admins' or 'personal:<pk>'),
   * sealing its epoch key strictly to the chosen members and binding the specified topics to it.
   */
  async createCompartment(ringName, options) {
    check(this.genesis.privateLog, "COMPARTMENT_PRIVATE_LOG_ONLY");
    check(typeof ringName === "string" && ringName.length > 0 && ringName !== "default", "RING_NAME_INVALID");
    await this.#flushPendingMaterialization();
    const keysState = this.keysState();
    const prevRing = keysState.rings?.[ringName];
    const nextEpoch = (prevRing?.currentEpoch ?? -1) + 1;
    const key = crypto.getRandomValues(new Uint8Array(32));
    await this.installRingKey(ringName, nextEpoch, key);
    const boxes = {};
    for (const m of options.members) {
      boxes[m.publicKey] = await hpkeSealEpochKey(m.wrapKey, key, `${this.logId}:${ringName}`, nextEpoch);
    }
    const operation = await this.submit({
      visibility: "public",
      awaitMaterialized: true,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$keys",
        input: {
          action: "rotateRingEpoch",
          ring: ringName,
          epoch: nextEpoch,
          keyCommitment: epochKeyCommitmentV2(key),
          boxes,
          topics: [...options.topics]
        }
      }]
    });
    return { ring: ringName, epoch: nextEpoch, operation };
  }
  /**
   * Configure threshold Social Recovery ("Trusted Backup Contacts"):
   * - Splits a fresh 32-byte recoveryKey into N Shamir shares (threshold M).
   * - Encrypts all retained epoch + compartment keys inside a recovery vault under recoveryKey.
   * - HPKE-seals each Shamir share strictly to its guardian's wrapKey (guardians cannot read app data).
   * - Atomically updates $permissions.guardians and $keys.recovery.
   */
  async setupSocialRecovery(options) {
    check(options.guardians.length > 0, "GUARDIANS_REQUIRED");
    check(Number.isSafeInteger(options.threshold) && options.threshold >= 1 && options.threshold <= options.guardians.length, "INVALID_GUARDIAN_THRESHOLD");
    const updates = [{
      topic: "$permissions",
      input: {
        action: "setGuardians",
        guardians: {
          threshold: options.threshold,
          members: options.guardians.map((g) => ({
            publicKey: g.publicKey,
            wrapKey: g.wrapKey,
            ...g.label ? { label: g.label } : {}
          }))
        }
      }
    }];
    if (this.genesis.privateLog) {
      const recoveryKey = crypto.getRandomValues(new Uint8Array(32));
      const vaultPayload = { epochs: {}, rings: {} };
      for (const [ep, key] of this.#epochKeys) {
        vaultPayload.epochs[String(ep)] = bytesToHex(key);
      }
      for (const [ring, map] of this.#ringKeys) {
        const ringObj = {};
        for (const [ep, key] of map) ringObj[String(ep)] = bytesToHex(key);
        vaultPayload.rings[ring] = ringObj;
      }
      const aad2 = utf8(`chronolog-recovery-vault:${this.logId}`);
      const encVault = await encryptEpochPayload(recoveryKey, 0n, utf8(JSON.stringify(vaultPayload)), aad2);
      const shares = splitSecret(recoveryKey, options.threshold, options.guardians.length);
      const guardianShares = {};
      for (let i = 0; i < options.guardians.length; i++) {
        const g = options.guardians[i];
        const share = shares[i];
        const box = await hpkeSealEpochKey(g.wrapKey, share.bytes, `${this.logId}:recovery-share`, share.index);
        guardianShares[g.publicKey] = { index: share.index, box };
      }
      updates.push({
        topic: "$keys",
        input: {
          action: "setRecoveryVault",
          vault: {
            nonce: bytesToHex(encVault.nonce),
            ciphertext: bytesToHex(encVault.ciphertext)
          },
          guardianShares
        }
      });
    }
    return this.submit({
      visibility: "public",
      awaitMaterialized: true,
      updates,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs }
    });
  }
  /** Fresh device requests recovery from configured guardians with a short human-readable match code. */
  async requestSocialRecovery(options = {}) {
    const requestId = options.requestId ?? crypto.randomUUID();
    const codeBytes = crypto.getRandomValues(new Uint8Array(3));
    const codeNum = (codeBytes[0] << 16 | codeBytes[1] << 8 | codeBytes[2]) % 1e6;
    const verificationCode = options.verificationCode ?? String(codeNum).padStart(6, "0");
    const operation = await this.submit({
      visibility: "public",
      awaitMaterialized: true,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$permissions",
        input: {
          action: "requestRecovery",
          requestId,
          newPublicKey: this.identity.publicKey,
          newWrapKey: this.device.wrapKey.publicKey,
          label: options.label ?? "Recovered device",
          verificationCode
        }
      }]
    });
    return { requestId, verificationCode, operation };
  }
  /** Guardian approves a pending recovery request and re-seals their Shamir share to the recovering device. */
  async approveSocialRecovery(requestId, options = {}) {
    const permInfo = await this.#kernel.query("$permissions", { guardians: true });
    const req = permInfo?.recoveryRequests?.[requestId];
    check(req !== void 0 && req.status === "pending", "RECOVERY_REQUEST_NOT_FOUND");
    const updates = [{
      topic: "$permissions",
      input: { action: "approveRecovery", requestId }
    }];
    if (this.genesis.privateLog) {
      const myShare = await this.#kernel.query("$keys", { guardianShareFor: this.identity.publicKey });
      check(myShare !== null, "GUARDIAN_SHARE_MISSING");
      const shareBytes = await hpkeOpenEpochKey(
        this.device.wrapKey.privateKey,
        this.device.wrapKey.publicKey,
        myShare.box,
        `${this.logId}:recovery-share`,
        myShare.index
      );
      const resealedBox = await hpkeSealEpochKey(
        req.newWrapKey,
        shareBytes,
        `${this.logId}:recovery-grant`,
        myShare.index
      );
      updates.push({
        topic: "$keys",
        input: {
          action: "submitRecoveryShare",
          member: req.newPublicKey,
          index: myShare.index,
          box: resealedBox
        }
      });
    }
    return this.submit({
      visibility: "public",
      awaitMaterialized: true,
      updates,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs }
    });
  }
  /**
   * Called by the recovering device once threshold guardians have approved:
   * unseals guardian shares, reconstructs recoveryKey via Shamir interpolation,
   * decrypts the recovery vault, installs all epoch + compartment keys, and rematerializes.
   */
  async completeSocialRecovery() {
    return this.#serial(async () => {
      if (!this.genesis.privateLog) return { restoredEpochs: 0, restoredRings: 0 };
      const permInfo = await this.#kernel.query("$permissions", { guardians: true });
      const threshold = permInfo?.guardians?.threshold ?? 1;
      const rec = await this.#kernel.query("$keys", { recoveryFor: this.identity.publicKey });
      check(rec?.vault !== null && rec?.vault !== void 0, "RECOVERY_VAULT_MISSING");
      const shareEntries = Object.values(rec.shares ?? {});
      check(shareEntries.length >= threshold, "INSUFFICIENT_RECOVERY_SHARES");
      const decodedShares = [];
      for (const entry of shareEntries.slice(0, threshold)) {
        const bytes = await hpkeOpenEpochKey(
          this.device.wrapKey.privateKey,
          this.device.wrapKey.publicKey,
          entry.box,
          `${this.logId}:recovery-grant`,
          entry.index
        );
        decodedShares.push({ index: entry.index, bytes });
      }
      const recoveryKey = combineShares(decodedShares);
      const aad2 = utf8(`chronolog-recovery-vault:${this.logId}`);
      const plainBytes = await decryptEpochPayload(recoveryKey, {
        epoch: 0n,
        nonce: hexToBytes(rec.vault.nonce),
        ciphertext: hexToBytes(rec.vault.ciphertext)
      }, aad2);
      const parsed = JSON.parse(new TextDecoder().decode(plainBytes));
      let restoredEpochs = 0;
      for (const [epStr, hexKey] of Object.entries(parsed.epochs ?? {})) {
        await this.installEpochKey(Number(epStr), hexToBytes(hexKey));
        restoredEpochs++;
      }
      let restoredRings = 0;
      for (const [ring, eps] of Object.entries(parsed.rings ?? {})) {
        for (const [epStr, hexKey] of Object.entries(eps)) {
          await this.installRingKey(ring, Number(epStr), hexToBytes(hexKey));
        }
        restoredRings++;
      }
      await this.#rematerialize();
      return { restoredEpochs, restoredRings };
    });
  }
  async removeMember(publicKey, options = {}) {
    const updates = [
      { topic: "$permissions", input: { action: "removeMember", publicKey } }
    ];
    if (this.genesis.privateLog && options.rotateEpoch !== false) {
      const nextEpoch = this.keysState().currentEpoch + 1;
      const key = crypto.getRandomValues(new Uint8Array(32));
      await this.installEpochKey(nextEpoch, key);
      const boxes = {};
      for (const m of this.permissions().members) {
        if (!m.reader || !m.wrapKey || m.publicKey === publicKey) continue;
        boxes[m.publicKey] = await hpkeSealEpochKey(m.wrapKey, key, this.logId, nextEpoch);
      }
      updates.push({
        topic: "$keys",
        input: {
          action: "rotateEpoch",
          epoch: nextEpoch,
          keyCommitment: epochKeyCommitmentV2(key),
          boxes
        }
      });
    }
    return this.submit({
      visibility: "public",
      awaitMaterialized: true,
      updates,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs }
    });
  }
  async publishRelease(options) {
    const descriptors = [];
    const treeEntries = {};
    for (const f of options.files) {
      let hash = f.hash;
      let size = f.size;
      if (f.bytes !== void 0) {
        const computedHash = computeBlobDagHash(f.bytes);
        if (hash !== void 0) check(hash === computedHash, "PUBLICATION_FILE_HASH_MISMATCH");
        hash = computedHash;
        size = f.bytes.length;
        if (this.isReader(this.identity.publicKey)) {
          await this.content.putBlob(f.bytes);
        }
      }
      check(hash !== void 0 && size !== void 0, "PUBLICATION_FILE_INVALID");
      descriptors.push({ path: f.path, hash, size, type: f.type });
      treeEntries[f.path] = casRef(hash);
    }
    let treeRoot;
    if (options.includeTreeRoot !== false && descriptors.length > 0) {
      const encodedTree = encodeTreeNode({ format: "chronolog-tree/v1", entries: treeEntries });
      const treeHash = await this.cas.put(encodedTree.bytes, encodedTree.links, "public");
      treeRoot = casRef(treeHash);
    }
    return this.submit({
      visibility: "public",
      awaitMaterialized: true,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$publications",
        input: {
          action: "publish",
          entry: options.entry,
          files: descriptors,
          ...treeRoot === void 0 ? {} : { treeRoot },
          ...options.expectedRevision === void 0 ? {} : { expectedRevision: options.expectedRevision }
        }
      }]
    });
  }
  async rollbackRelease(options) {
    check(options.revision !== void 0 || options.opId !== void 0, "PUBLICATION_ROLLBACK_TARGET_REQUIRED");
    return this.submit({
      visibility: "public",
      awaitMaterialized: true,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$publications",
        input: {
          action: "rollback",
          ...options.revision === void 0 ? {} : { revision: options.revision },
          ...options.opId === void 0 ? {} : { opId: options.opId }
        }
      }]
    });
  }
  async scheduleFinality(options) {
    return this.submit({
      visibility: "public",
      awaitMaterialized: true,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$finality",
        input: {
          action: "schedulePolicy",
          effectiveAfterMs: Number(options.effectiveAfterMs),
          policy: options.policy
        }
      }]
    });
  }
  async updateReducers(options) {
    const pinnedImports = {};
    if (options.imports !== void 0) {
      for (const [spec, val] of Object.entries(options.imports)) {
        if (val === null || val.startsWith("cas:sha256-")) {
          pinnedImports[spec] = val;
        } else {
          const hash = await this.cas.put(utf8(val), [], "public");
          pinnedImports[spec] = `cas:sha256-${hash}`;
        }
      }
    }
    return this.submit({
      visibility: "public",
      awaitMaterialized: true,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{
        topic: "$reducers",
        input: {
          ...Object.keys(pinnedImports).length > 0 ? { imports: pinnedImports } : {},
          ...options.topics !== void 0 ? { topics: options.topics } : {}
        }
      }]
    });
  }
  // ---- Finality operations ----
  finality = {
    status: () => ({
      ...this.#verifiedFinality,
      schedule: parseFinalitySchedule(this.#kernel.topic("$finality"))
    }),
    createCheckpoint: async (options) => {
      return this.#serial(async () => {
        const schedule = parseFinalitySchedule(this.#kernel.topic("$finality"));
        const scopeEntries = await Promise.all(schedule.map(async (entry) => ({
          entry,
          scopeId: await policyScopeId(this.logId, entry)
        })));
        const closedByScope = /* @__PURE__ */ new Map();
        for (const cp of this.#verifiedFinality.verifiedCheckpoints) {
          const prev = closedByScope.get(cp.payload.policyScopeId);
          if (prev === void 0 || cp.payload.closedThroughMs > prev) {
            closedByScope.set(cp.payload.policyScopeId, cp.payload.closedThroughMs);
          }
        }
        let activeIdx = 0;
        for (let i = 0; i < scopeEntries.length; i++) {
          const cur = scopeEntries[i];
          if (cur.entry.effectiveAfterMs > options.throughMs) break;
          if (i > 0) {
            const prev = scopeEntries[i - 1];
            if (prev.entry.policy.kind !== "none") {
              const prevClosed = closedByScope.get(prev.scopeId);
              if (prevClosed === void 0 || prevClosed < cur.entry.effectiveAfterMs) break;
            }
          }
          activeIdx = i;
        }
        const active = scopeEntries[activeIdx].entry;
        check(active.policy.kind !== "none", "FINALITY_NOT_ACTIVE");
        const scopeId = scopeEntries[activeIdx].scopeId;
        const all = this.#collectDecryptedKernelInputs();
        const included = [];
        for (const [opId, input] of all) {
          if (this.#verifiedFinality.excludedOpIds.has(opId)) continue;
          if (input.core.authorTimestampMs <= options.throughMs) included.push(input);
        }
        included.sort((a, b) => compareOperationOrder(
          { authorTimestampMs: a.core.authorTimestampMs, author: a.core.author, opId: a.opId },
          { authorTimestampMs: b.core.authorTimestampMs, author: b.core.author, opId: b.opId }
        ));
        const tempKernel = new TopicKernel({
          genesis: this.genesisBytes,
          cas: this.cas,
          blindHostMode: this.#blindHostMode,
          ...this.#sandboxOptions,
          ...this.#sqliteDriver === void 0 ? {} : { sqliteDriver: this.#sqliteDriver }
        });
        let snap;
        try {
          await tempKernel.materialize(included);
          await tempKernel.commitSeenOpsRoot();
          snap = tempKernel.snapshot();
        } finally {
          tempKernel.dispose();
        }
        const inclusions = included.map((i) => ({
          opId: bytesToHex(i.opId),
          authorTimestampMs: i.core.authorTimestampMs,
          author: bytesToHex(i.core.author)
        }));
        const payload = {
          logId: this.logId,
          policyScopeId: scopeId,
          closedThroughMs: options.throughMs,
          includedSetDigest: computeIncludedSetDigest(inclusions.map((i) => i.opId)),
          historyDigest: snap.historyDigest,
          stateRoot: snap.stateRoot,
          inclusions
        };
        const attestation = options.attestation === void 0 ? { kind: "signatures", signatures: [await signFinalityCheckpoint(payload, this.device.identity)] } : typeof options.attestation === "function" ? await options.attestation(payload) : options.attestation;
        const checkpoint = {
          payload,
          attestation
        };
        const key = await recordDigest(checkpoint);
        this.#checkpoints.set(key, checkpoint);
        await this.#store.put(`${this.#prefix}/checkpoint/${key}`, encodeRecord(checkpoint));
        await this.#rematerialize();
        this.#emitFacts();
        return { checkpoint, snapshot: snap };
      });
    },
    submitCheckpoints: async (checkpoints) => {
      await this.mergeFacts({
        publicOps: [],
        encryptedEnvelopes: [],
        casNodes: [],
        retentions: [],
        checkpoints
      });
    },
    bootstrapFromCheckpoint: async (checkpoint, snapshot) => {
      await this.#serial(async () => {
        check(checkpoint.payload.logId === this.logId, "CHECKPOINT_CHAIN_MISMATCH");
        check(checkpoint.payload.stateRoot === snapshot.stateRoot && checkpoint.payload.historyDigest === snapshot.historyDigest, "CHECKPOINT_SNAPSHOT_MISMATCH");
        const key = await recordDigest(checkpoint);
        this.#checkpoints.set(key, checkpoint);
        await this.#store.put(`${this.#prefix}/checkpoint/${key}`, encodeRecord(checkpoint));
        await this.#kernel.bootstrapFromCheckpoint(snapshot);
        if (this.#controlKernel !== null) {
          await this.#controlKernel.bootstrapFromCheckpoint(snapshot);
        }
        this.#lastLocalRevision = toMaterializedRevision(this.#kernel.revision("local"));
        this.#emitChange({ kind: "finalized", revision: this.#lastLocalRevision, revisedProposalIds: [] });
        this.#emitStatus();
      });
    }
  };
  // ---- Operation inspection & waiting ----
  inspectOperation(idOrOperationId) {
    let opIdHex = idOrOperationId;
    let core = null;
    let pending = null;
    const pub = this.#publicOps.get(idOrOperationId);
    const known = pub === void 0 ? this.#kernelInputs.get(idOrOperationId) ?? this.#kernelInputs.get(this.#ownOperationIds.get(idOrOperationId) ?? "") : void 0;
    if (pub !== void 0) {
      core = pub.core;
    } else if (known !== void 0) {
      opIdHex = bytesToHex(known.opId);
      core = known.core;
    } else {
      for (const [k, v] of this.#publicOps) {
        if (v.core.operationId === idOrOperationId && bytesToHex(v.core.author) === this.identity.publicKey) {
          opIdHex = k;
          core = v.core;
          break;
        }
      }
    }
    if (core === null) {
      const byDigest = this.#encryptedEnvelopes.get(idOrOperationId);
      if (byDigest?.decrypted !== void 0) {
        opIdHex = byDigest.decrypted.opId;
        core = byDigest.decrypted.core;
      }
    }
    if (core === null) {
      for (const entry of this.#encryptedEnvelopes.values()) {
        if (entry.decrypted?.opId === idOrOperationId) {
          opIdHex = entry.decrypted.opId;
          core = entry.decrypted.core;
          break;
        }
        if (entry.decrypted?.core.operationId === idOrOperationId && bytesToHex(entry.decrypted.core.author) === this.identity.publicKey) {
          opIdHex = entry.decrypted.opId;
          core = entry.decrypted.core;
          break;
        }
      }
    }
    if (core === null) {
      const pend = this.#localPending.get(idOrOperationId);
      if (pend !== void 0) core = pend.core;
      else {
        for (const [k, v] of this.#localPending) {
          if (v.core.operationId === idOrOperationId) {
            opIdHex = k;
            core = v.core;
            break;
          }
        }
      }
    }
    const outcome = this.#kernel.outcomeOf(opIdHex);
    const materialized = outcome === void 0 ? null : {
      proposalId: opIdHex,
      revision: this.#lastLocalRevision,
      outcome: outcome.outcome,
      rejectionCode: outcome.rejectionCode,
      ...outcome.rejectionDetail === void 0 ? {} : { rejectionDetail: outcome.rejectionDetail }
    };
    if (materialized === null) {
      if (this.#kernel.pendingDependencies.length > 0) pending = "dependency";
      else if (core === null) pending = "key";
    }
    const retained = [...this.#retentions.get(opIdHex)?.values() ?? []].filter((r) => r.signer !== this.identity.publicKey && r.payload.storageId !== this.device.storageId);
    return {
      applicationId: this.applicationId,
      author: core === null ? "" : bytesToHex(core.author),
      authorTimestampMs: core === null ? null : core.authorTimestampMs.toString(),
      proposalId: opIdHex,
      operationId: core === null ? idOrOperationId : core.operationId,
      visibility: core === null ? "encrypted" : core.visibility,
      stored: core !== null,
      pending,
      materialized,
      retained,
      finalized: this.#verifiedFinality.includedOpIds.has(opIdHex),
      excluded: this.#verifiedFinality.excludedOpIds.has(opIdHex)
    };
  }
  async waitOperation(id, fact, options = {}) {
    if (fact === "finalized" && !this.#hasActiveFinalityPolicy()) {
      throw Object.assign(new Error("FINALITY_UNSUPPORTED"), { code: "FINALITY_UNSUPPORTED" });
    }
    const checkDone = () => {
      const info = this.inspectOperation(id);
      if (fact === "materialized" && info.materialized !== null) return info;
      if (fact === "retained" && info.retained.length > 0) return info;
      if (fact === "finalized" && info.finalized && info.materialized !== null) return info;
      return null;
    };
    const immediate = checkDone();
    if (immediate !== null) return immediate;
    const timeoutMs = options.timeoutMs ?? 3e4;
    const signal = options.signal === void 0 ? this.#lifetime.signal : AbortSignal.any([this.#lifetime.signal, options.signal]);
    signal.throwIfAborted();
    return new Promise((resolve, reject) => {
      let settled = false;
      const done = (fn) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        stopChange();
        stopStatus();
        stopFacts();
        signal.removeEventListener("abort", onAbort);
        fn();
      };
      const evaluate = () => {
        const ready = checkDone();
        if (ready !== null) done(() => resolve(ready));
      };
      const onAbort = () => done(() => reject(signal.reason));
      const timer = setTimeout(() => done(() => reject(new Error(`OPERATION_WAIT_TIMEOUT:${fact}`))), timeoutMs);
      const stopChange = this.onChange(evaluate);
      const stopStatus = this.onStatus(evaluate);
      const stopFacts = this.onFacts(evaluate);
      signal.addEventListener("abort", onAbort, { once: true });
      evaluate();
    });
  }
  operations = {
    get: (idOrOperationId) => {
      const info = this.inspectOperation(idOrOperationId);
      return info.stored ? new ApplicationOperation(info.proposalId, info.operationId, this) : null;
    },
    retry: async (idOrOperationId) => {
      const existing = this.operations.get(idOrOperationId);
      check(existing !== null, "OPERATION_UNKNOWN");
      this.#emitFacts();
      return existing;
    }
  };
  // ---- Retention ----
  async retain(proposalId, subject) {
    const [evidence] = await this.retainMany([{ proposalId, author: subject.author, envelopeDigest: subject.envelopeDigest }]);
    return evidence;
  }
  /** Sign and persist a batch of retention receipts in ONE batched store write + ONE fact emission. */
  /** Index a (batch) retention receipt under every proposal it covers; true if anything was new. */
  #indexRetention(ev) {
    let added = false;
    for (const proposalId of ev.payload.items) {
      if (typeof proposalId !== "string") continue;
      let byPeer = this.#retentions.get(proposalId);
      if (byPeer === void 0) {
        byPeer = /* @__PURE__ */ new Map();
        this.#retentions.set(proposalId, byPeer);
      }
      if (!byPeer.has(ev.signer)) {
        byPeer.set(ev.signer, ev);
        added = true;
      }
    }
    return added;
  }
  /**
   * Sign ONE retention receipt covering every newly retained item (sync v3), instead of one
   * signature, store write and gossip fact per operation.
   */
  async retainMany(items) {
    if (items.length === 0) return [];
    const fresh = [...new Set(items.map((item) => item.proposalId))].filter((proposalId) => this.#retentions.get(proposalId)?.get(this.identity.publicKey) === void 0);
    if (fresh.length === 0) return items.map((item) => this.#retentions.get(item.proposalId).get(this.identity.publicKey));
    const evidence = await signRecord("operation-retention", {
      applicationId: this.applicationId,
      peer: this.identity.publicKey,
      storageId: this.device.storageId,
      items: fresh
    }, this.device.identity);
    for (const proposalId of fresh) {
      let byPeer = this.#retentions.get(proposalId);
      if (byPeer === void 0) {
        byPeer = /* @__PURE__ */ new Map();
        this.#retentions.set(proposalId, byPeer);
      }
      byPeer.set(this.identity.publicKey, evidence);
    }
    await this.#store.put(`${this.#prefix}/retention/${await recordDigest(evidence.payload)}`, encodeRecord(evidence), { durability: "relaxed" });
    this.#emitFacts();
    return items.map((item) => this.#retentions.get(item.proposalId).get(this.identity.publicKey));
  }
  /**
   * Return `proposalId`s authored by `authorPublicKey` that this replica holds durably
   * (public ops and/or encrypted envelopes) and has not yet signed its own retention receipt for.
   * Used after P2P sync reconciliation to attest operations received out-of-band (e.g. host mailbox)
   * without re-signing or resending receipts on unchanged reconnects.
   */
  unreceiptedProposalIdsByAuthor(authorPublicKey, includePrivate) {
    const self = this.identity.publicKey;
    const ids = [];
    for (const [opId, op] of this.#publicOps) {
      if (bytesToHex(op.core.author) === authorPublicKey && this.#retentions.get(opId)?.get(self) === void 0) {
        ids.push(opId);
      }
    }
    if (includePrivate) {
      for (const env of this.#encryptedEnvelopes.values()) {
        if (bytesToHex(env.envelope.author) === authorPublicKey) {
          const opId = bytesToHex(env.envelope.opId);
          if (this.#retentions.get(opId)?.get(self) === void 0) ids.push(opId);
        }
      }
    }
    return ids;
  }
  // ---- Facts export & merge (P2P + blind host sync) ----
  /** Number of times this session skipped full replay by restoring a verified materialized cache/snapshot. */
  get materializedCacheHits() {
    return this.#materializedCacheHits;
  }
  /**
   * Export a member-signed Snapshot Bundle (v3, see snapshot-codec.ts): the current state as a
   * frontier (topics, idempotency set, digests and the covered op ids — no outcomes or events)
   * plus the CAS nodes reachable from it (SQLite pages, seen set; standard modules excluded).
   * On private logs it is AEAD-encrypted under the current epoch key, so blind hosts can cache it
   * and peers can serve it without exposing plaintext.
   */
  async exportMaterializedSnapshot(options = {}) {
    await this.#flushPendingMaterialization();
    return this.#serial(() => this.#exportSnapshotNow(options));
  }
  async #exportSnapshotNow(options) {
    const totalOps = this.#kernel.materializedOutcomes.length + this.#kernel.frontierOrderLength;
    const minOps = options.minOps ?? 1;
    if (totalOps < minOps || this.#kernel.pendingDependencies.length > 0) {
      return null;
    }
    let encryption;
    if (this.genesis.privateLog) {
      if (this.#blindHostMode) return null;
      const epoch = this.#currentEpochFrom(this.#kernel);
      const key = epoch >= 0 ? this.#epochKeys.get(epoch) : void 0;
      if (key === void 0) return null;
      encryption = { epoch, key };
    }
    await this.#kernel.commitSeenOpsRoot();
    const cache = this.#kernel.exportMaterializedCache({ suffix: false });
    const casNodes = [];
    const roots = /* @__PURE__ */ new Set([cache.seenOpsRoot]);
    if (options.includeReachableCas !== false) {
      const stdHashes = standardModuleHashes();
      for (const hash of this.#kernel.gcRoots()) roots.add(hash);
      for (const hash of await this.cas.reachable(roots)) {
        if (stdHashes.has(hash)) continue;
        const pubRaw = await this.cas.getRaw(hash, "public");
        if (pubRaw !== null) {
          casNodes.push({ hash, bytes: pubRaw, partition: "public" });
          continue;
        }
        const privRaw = await this.cas.getRaw(hash, "private");
        if (privRaw !== null) casNodes.push({ hash, bytes: privRaw, partition: "private" });
      }
    }
    return encodeSnapshotBundle({
      logId: this.logId,
      cache,
      casNodes,
      identity: this.device.identity,
      ...encryption === void 0 ? {} : { encryption }
    });
  }
  /**
   * True when this replica has no materialized history yet (no ops and no snapshot frontier) and
   * would benefit from adopting a peer's snapshot instead of replaying everything.
   */
  wantsSnapshotBootstrap() {
    if (!this.#snapshotBootstrap || this.#closed || this.#blindHostMode) return false;
    if (this.#kernel.frontierOrderLength > 0 || this.#localPending.size > 0) return false;
    if (this.genesis.privateLog) return this.#encryptedEnvelopes.size === 0;
    return this.#publicOps.size === 0;
  }
  /**
   * Stage and apply an exported materialized snapshot bundle (AEAD-decrypted on private logs).
   * Works on cold replicas with zero historical ops downloaded (frontier bootstrap).
   */
  importMaterializedSnapshot(bytes) {
    return this.#serial(async () => {
      const decoded = await this.#decodeMaterializedSnapshot(bytes);
      if (decoded === null) return false;
      if (decoded.casNodes.length > 0) {
        await this.cas.putManyVerified(decoded.casNodes);
      }
      this.#pendingSnapshotBundle = decoded;
      await this.#rematerialize();
      return true;
    });
  }
  async readCasPayload(hash, partition = "any") {
    const node = await this.cas.get(hash, partition);
    if (node === null) return null;
    return { hash, payload: node.bytes.slice(), links: [...node.links] };
  }
  async exportFacts(options = {}) {
    const includePrivate = options.includePrivateCas ?? (!this.#blindHostMode && this.isReader(this.identity.publicKey));
    const casNodes = [];
    const partitions = includePrivate ? ["public", "private"] : ["public"];
    for (const partition of partitions) {
      for (const hash of this.cas.listKnownHashes(partition)) {
        const raw = await this.cas.getRaw(hash, partition);
        if (raw !== null) casNodes.push({ hash, bytes: raw, partition });
      }
    }
    const retentions = [];
    for (const byPeer of this.#retentions.values()) {
      for (const ev of byPeer.values()) retentions.push(ev);
    }
    return {
      ...options.includeGenesis ? { genesisBytes: this.genesisBytes.slice() } : {},
      publicOps: [...this.#publicOps.values()].map((v) => v.raw.slice()),
      encryptedEnvelopes: [...this.#encryptedEnvelopes.values()].map((v) => v.raw.slice()),
      casNodes,
      retentions,
      checkpoints: [...this.#checkpoints.values()]
    };
  }
  /** Reconciliation id set for a sync-v3 scope (live view; do not mutate). */
  factIds(scope) {
    return scope === "public" ? this.#publicFactIds : this.#privateFactIds;
  }
  /** Raw facts for the given ids of one scope (unknown ids are skipped). */
  exportFactsById(scope, ids) {
    const ops = [], checkpoints = [];
    const LAST = 1n << 62n;
    for (const id of ids) {
      if (scope === "private") {
        const env = this.#encryptedEnvelopes.get(id);
        if (env !== void 0) ops.push({ ts: env.decrypted?.core.authorTimestampMs ?? LAST, raw: env.raw });
        continue;
      }
      const op = this.#publicOps.get(id);
      if (op !== void 0) {
        ops.push({ ts: op.core.authorTimestampMs, raw: op.raw });
        continue;
      }
      const cp = this.#checkpoints.get(id);
      if (cp !== void 0) checkpoints.push(cp);
    }
    ops.sort((a, b) => a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : 0);
    const raws = ops.map((op) => op.raw);
    return { publicOps: scope === "public" ? raws : [], encryptedEnvelopes: scope === "private" ? raws : [], casNodes: [], retentions: [], checkpoints };
  }
  /** CAS nodes by hash for an on-demand peer pull; walks explicit CasNode.links when subgraph=true. */
  async exportCasNodes(hashes, includePrivate, options = {}) {
    if (options.subgraph === true) {
      const sub = await this.cas.collectSubgraph(hashes, {
        allowedPartition: includePrivate ? "any" : "public",
        ...options.maxNodes === void 0 ? {} : { maxNodes: options.maxNodes },
        ...options.maxBytes === void 0 ? {} : { maxBytes: options.maxBytes }
      });
      return [...sub];
    }
    const out = [];
    for (const hash of hashes) {
      for (const partition of includePrivate ? ["public", "private"] : ["public"]) {
        const raw = await this.cas.getRaw(hash, partition);
        if (raw !== null) {
          out.push({ hash, bytes: raw, partition });
          break;
        }
      }
    }
    return out;
  }
  /** Fetch missing public CAS subgraphs from configured untrusted HTTP CAS mirrors. */
  async #pullMissingFromMirrors() {
    if (this.#casMirrors.length === 0) return 0;
    let addedTotal = 0;
    const missing = this.missingCasDependencies().filter((h) => !this.#mirrorAttempted.has(h));
    for (const hash of missing) {
      if (this.cas.hasSync(hash, "public")) continue;
      this.#mirrorAttempted.add(hash);
      for (const mirror of this.#casMirrors) {
        try {
          const client = createCasMirrorClient(mirror);
          const nodes = await client.fetchSubgraph(hash, { maxNodes: 256, maxBytes: 8 * 1024 * 1024 });
          if (nodes.length === 0) continue;
          const added = await this.cas.putManyVerified(
            nodes.map((n) => ({ hash: n.hash, bytes: n.bytes, partition: "public" }))
          );
          addedTotal += added;
          if (this.cas.hasSync(hash, "public")) break;
        } catch {
        }
      }
    }
    return addedTotal;
  }
  /**
   * Install a content-addressed `chronolog-pkg/v1` package (or pre-packed bundle / existing CAS ref)
   * into this log's `$reducers` topic in one ergonomic call.
   */
  async installPackage(pkg, options) {
    let pkgRef;
    if (typeof pkg === "string") {
      pkgRef = casRef(tryParseCasRef(pkg) ?? pkg);
    } else if ("casNodes" in pkg && "ref" in pkg) {
      if (pkg.casNodes.length > 0) {
        await this.cas.putManyVerified(pkg.casNodes);
      }
      pkgRef = casRef(parseCasRef(pkg.ref));
    } else {
      const pkgInput = pkg;
      const partition = (options.partition ?? pkgInput.partition) === "private" && this.genesis.privateLog ? "private" : "public";
      const placed = await putPackageDag(this.cas, pkgInput, partition);
      pkgRef = placed.ref;
    }
    const topicUpdates = {};
    if (options.topics !== void 0) {
      for (const [topicName, binding] of Object.entries(options.topics)) {
        topicUpdates[topicName] = {
          module: options.alias,
          ...binding.export === void 0 ? {} : { export: binding.export },
          ...binding.config === void 0 ? {} : { config: binding.config }
        };
      }
    }
    const payload = {
      imports: { [options.alias]: pkgRef },
      ...Object.keys(topicUpdates).length > 0 ? { topics: topicUpdates } : {},
      ...options.attestations !== void 0 ? { attestations: options.attestations } : {}
    };
    const operation = await this.submit({
      visibility: "public",
      awaitMaterialized: true,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{ topic: "$reducers", input: payload }]
    });
    return { pkgRef, operation };
  }
  /**
   * Pin a verified snapshot of an external Chronolog log into `$mounts` so reducers can query it
   * deterministically via `ctx.mount(name)` and `ctx.mountQuery(name, topic, input)`.
   */
  async mountLog(name, source2, options = {}) {
    let logId;
    let stateRoot;
    let topics;
    let casNodes;
    let signer;
    let signature;
    if (source2 instanceof _ApplicationSession) {
      const snap = source2.#kernel.snapshot();
      logId = source2.logId;
      stateRoot = snap.stateRoot;
      topics = snap.topics;
      const exported = await source2.exportFacts({ includePrivateCas: !source2.genesis.privateLog });
      casNodes = exported.casNodes.map((n) => ({ hash: n.hash, bytes: n.bytes, partition: "public" }));
      const msg = utf8(`chronolog/mount/v1:${canonicalJson({ logId, stateRoot, topics })}`);
      signer = source2.device.identity.publicKey;
      signature = bytesToHex(new Uint8Array(await crypto.subtle.sign("Ed25519", source2.device.identity.privateKey, new Uint8Array(msg))));
    } else {
      logId = source2.logId;
      stateRoot = source2.stateRoot;
      topics = source2.topics;
      casNodes = source2.casNodes ?? [];
      signer = source2.signer;
      signature = source2.signature;
    }
    if (casNodes.length > 0) {
      await this.cas.putManyVerified(casNodes);
    }
    const casRoots = [...new Set(casNodes.map((n) => n.hash))].sort();
    const payload = {
      action: "update",
      name,
      logId,
      stateRoot,
      topics,
      casRoots,
      ...options.trustedSigners !== void 0 ? { trustedSigners: [...options.trustedSigners] } : {},
      ...signer !== void 0 && signature !== void 0 ? { signer, signature } : {}
    };
    return this.submit({
      visibility: "public",
      awaitMaterialized: true,
      ...options.operationId === void 0 ? {} : { operationId: options.operationId },
      ...options.authorTimestampMs === void 0 ? {} : { authorTimestampMs: options.authorTimestampMs },
      updates: [{ topic: "$mounts", input: payload }]
    });
  }
  /**
   * Evaluate (or retrieve from local memo cache or trusted `$builders` derivation mirror)
   * a content-addressed `chronolog-drv/v1` derivation.
   */
  async evaluateDerivation(drvRefOrHash, options = {}) {
    const memo = createBytesStoreDerivationMemo(this.#store, `${this.#prefix}/drv-memo/`);
    const drvHash = tryParseCasRef(drvRefOrHash) ?? drvRefOrHash;
    const partition = options.partition ?? "public";
    if (!options.skipMirror && partition === "public") {
      const buildersTopic = this.topic("$builders");
      const trustedBuilders = options.trustedBuilders ?? buildersTopic?.builders ?? [];
      const threshold = options.threshold ?? buildersTopic?.threshold ?? 1;
      const mirrorUrls = options.mirrors ?? this.#casMirrors;
      if (trustedBuilders.length > 0 && mirrorUrls.length > 0 && /^[0-9a-f]{64}$/u.test(drvHash)) {
        for (const mirror of mirrorUrls) {
          try {
            const client = createCasMirrorClient(mirror);
            const { trusted } = await client.fetchDerivationAttestations(drvHash, { trustedBuilders, threshold });
            if (trusted === null) continue;
            const nodes = await client.fetchSubgraph(trusted.outputHash, { maxNodes: 512, maxBytes: 16 * 1024 * 1024 });
            if (nodes.length === 0) continue;
            await this.cas.putManyVerified(
              nodes.map((n) => ({ hash: n.hash, bytes: n.bytes, partition: "public" }))
            );
            if (this.cas.hasSync(trusted.outputHash, "public")) {
              await memo.set(drvHash, trusted.outputHash);
              return {
                drvHash,
                drvRef: casRef(drvHash),
                outputHash: trusted.outputHash,
                outputRef: trusted.outputRef,
                fromCache: true,
                attestedBy: trusted.signers
              };
            }
          } catch {
          }
        }
      }
    }
    return evaluateDerivation({
      drvRefOrHash,
      cas: this.cas,
      sandbox: this.#kernel.sandbox,
      memo,
      ...options.partition === void 0 ? {} : { partition: options.partition },
      ...options.skipMemo === void 0 ? {} : { skipMemo: options.skipMemo },
      ...options.wasiRunners === void 0 ? {} : { wasiRunners: options.wasiRunners }
    });
  }
  /** CAS hashes replay is blocked on (modules, reducer-read nodes, SQLite pages). */
  missingCasDependencies() {
    const out = /* @__PURE__ */ new Set();
    for (const kernel of [this.#kernel, this.#controlKernel, this.#finalKernel]) {
      for (const dep of kernel?.pendingDependencies ?? []) {
        const hash = dep.slice(dep.indexOf("/") + 1);
        if (/^[0-9a-f]{64}$/u.test(hash)) out.add(hash);
      }
    }
    return [...out];
  }
  async exportPublicControlFacts() {
    const casNodes = [];
    const standard = standardModuleHashes();
    for (const hash of this.cas.listKnownHashes("public")) {
      if (standard.has(hash)) continue;
      const raw = await this.cas.getRaw(hash, "public");
      if (raw !== null) casNodes.push({ hash, bytes: raw, partition: "public" });
    }
    return {
      publicOps: [...this.#publicOps.values()].map((v) => v.raw.slice()),
      casNodes,
      checkpoints: [...this.#checkpoints.values()]
    };
  }
  mergeFacts(facts, options = {}) {
    return this.#serial(async () => {
      await this.#mergeFactsNow(facts, options.source);
    });
  }
  async #mergeFactsNow(facts, source2) {
    {
      if (facts.genesisBytes !== void 0) {
        check(sameBytes(facts.genesisBytes, this.genesisBytes), "FACTS_GENESIS_MISMATCH");
      }
      let materializedChanged = false;
      let factsChanged = false;
      if (facts.casNodes !== void 0 && facts.casNodes.length > 0) {
        const addedCas = await this.cas.putManyVerified(facts.casNodes);
        if (addedCas > 0) {
          materializedChanged = true;
          factsChanged = true;
        }
      }
      const storeBatch = [];
      for (const raw of facts.publicOps ?? []) {
        const signed = decodeSignedOperation(raw);
        if (this.#publicOps.has(bytesToHex(operationIdDigest(signed.coreBytes)))) continue;
        const verified = await verifySignedOperation(signed);
        if (bytesToHex(verified.core.logId) !== this.logId) continue;
        if (verified.core.visibility !== "public") continue;
        const opId = bytesToHex(verified.opId);
        if (this.#publicOps.has(opId)) continue;
        check(this.#publicOps.size + this.#encryptedEnvelopes.size < this.#maxOperations, "SESSION_OPERATION_LIMIT");
        const copy = raw.slice();
        storeBatch.push({ key: `${this.#prefix}/public-op/${opId}`, value: copy });
        this.#publicOps.setFrom(opId, { raw: copy, signed, core: verified.core }, source2);
        materializedChanged = true;
        factsChanged = true;
      }
      for (const raw of facts.encryptedEnvelopes ?? []) {
        const digest3 = bytesToHex(encryptedEnvelopeDigest(raw));
        if (this.#encryptedEnvelopes.has(digest3)) continue;
        const envelope2 = decodeEncryptedEnvelope(raw);
        if (bytesToHex(envelope2.logId) !== this.logId) continue;
        check(this.#publicOps.size + this.#encryptedEnvelopes.size < this.#maxOperations, "SESSION_OPERATION_LIMIT");
        const copy = raw.slice();
        storeBatch.push({ key: `${this.#prefix}/enc-env/${digest3}`, value: copy });
        this.#encryptedEnvelopes.setFrom(digest3, { digest: digest3, raw: copy, envelope: envelope2 }, source2);
        this.#undecryptedEnvelopes.add(digest3);
        materializedChanged = true;
        factsChanged = true;
      }
      for (const ev of facts.retentions ?? []) {
        if (ev.payload.applicationId !== this.applicationId || !Array.isArray(ev.payload.items)) continue;
        if (ev.payload.items.every((proposalId) => this.#retentions.get(proposalId)?.has(ev.signer) === true)) continue;
        await verifyRecord("operation-retention", ev, ev.signer);
        if (this.#indexRetention(ev)) {
          storeBatch.push({ key: `${this.#prefix}/retention/${await recordDigest(ev.payload)}`, value: encodeRecord(ev) });
          factsChanged = true;
        }
      }
      for (const cp of facts.checkpoints ?? []) {
        if (cp.payload.logId !== this.logId) continue;
        const key = await recordDigest(cp);
        if (!this.#checkpoints.has(key)) {
          this.#checkpoints.setFrom(key, cp, source2);
          storeBatch.push({ key: `${this.#prefix}/checkpoint/${key}`, value: encodeRecord(cp) });
          materializedChanged = true;
          factsChanged = true;
        }
      }
      if (storeBatch.length > 0) {
        for (let i = 0; i < storeBatch.length; i += 128) {
          await writeBytesMany(this.#store, storeBatch.slice(i, i + 128), { durability: "relaxed" });
        }
        if (this.#store.latestChangeSeq !== void 0) {
          this.#lastSyncSeq = Math.max(this.#lastSyncSeq, await this.#store.latestChangeSeq());
        }
      }
      if (materializedChanged) {
        await this.#rematerialize();
      } else if (factsChanged) {
        this.#emitStatus();
      }
      if (factsChanged) {
        this.#emitFacts();
      }
    }
  }
  async collectGarbage() {
    return this.#serial(async () => {
      await this.#flushPendingMaterialization();
      const roots = this.#kernel.gcRoots();
      if (this.#controlKernel !== null) {
        for (const r of this.#controlKernel.gcRoots()) roots.add(r);
      }
      if (this.#finalKernel !== null) {
        for (const r of this.#finalKernel.gcRoots()) roots.add(r);
      }
      for (const src of Object.values(STANDARD_MODULE_SOURCES)) {
        roots.add(computeCasHash(utf8(src), []));
      }
      return this.cas.collectGarbage(roots);
    });
  }
  connectPeer(options) {
    return connectApplicationPeer(this, options);
  }
  diagnostics() {
    return applicationPeerDiagnostics(this);
  }
  peerLinks() {
    return applicationPeerLinks(this);
  }
  onPeerLink(listener) {
    return onApplicationPeerLink(this, listener);
  }
  close() {
    return this.#closing ??= (async () => {
      if (this.#cachePersistTimer !== void 0) {
        clearTimeout(this.#cachePersistTimer);
        this.#cachePersistTimer = void 0;
      }
      try {
        await this.#flushPendingMaterialization();
      } catch {
      }
      try {
        await this.#persistMaterializedCacheNow();
      } catch {
      }
      this.#visibilityCleanup?.();
      this.#closed = true;
      this.#lifetime.abort(new Error("SESSION_CLOSED"));
      this.#emitStatus();
      this.#kernel.dispose();
      this.#controlKernel?.dispose();
      this.#finalKernel?.dispose();
      await this.content.close();
      await this.#release();
    })();
  }
};
function encodeLocalPending(raw, envelopeDigest, epoch) {
  return encodeCanonicalCbor([1n, raw, hexToBytes(envelopeDigest), BigInt(epoch)]);
}
function decodeLocalPending(bytes) {
  const value = decodeCanonicalCbor(bytes, DEFAULT_DECODE_LIMITS);
  check(Array.isArray(value) && value.length === 4 && value[0] === 1n && value[1] instanceof Uint8Array && value[2] instanceof Uint8Array && value[2].length === 32 && typeof value[3] === "bigint", "LOCAL_PENDING_INVALID");
  const [, raw, digest3, epoch] = value;
  return { raw, envelopeDigest: bytesToHex(digest3), epoch: Number(epoch) };
}
async function readAllStoreEntries(store) {
  if (store.iterateEntries !== void 0) {
    const entries = [];
    for await (const entry of store.iterateEntries()) entries.push(entry);
    return entries;
  }
  if (store.entries !== void 0) {
    return store.entries();
  }
  return [];
}
function sliceEvents(events, revision, options) {
  const limit2 = options.limit ?? 64;
  check(Number.isSafeInteger(limit2) && limit2 >= 1 && limit2 <= 512, "EVENT_LIMIT_INVALID");
  const normalizedTopics = options.topics === void 0 ? null : [...new Set(options.topics)].sort();
  const topicFilter = normalizedTopics === null ? null : new Set(normalizedTopics);
  const filtered = topicFilter === null ? events : events.filter((ev) => topicFilter.has(ev.topic));
  let start = 0;
  if (options.cursor !== void 0 && options.cursor !== "") {
    check(options.cursor.length <= APPLICATION_EVENT_CURSOR_LIMIT, "EVENT_CURSOR_INVALID");
    let parsed;
    try {
      parsed = JSON.parse(options.cursor);
    } catch {
      throw Object.assign(new Error("EVENT_CURSOR_INVALID"), { code: "EVENT_CURSOR_INVALID" });
    }
    if (parsed === null || typeof parsed !== "object" || typeof parsed.after !== "number" || !Number.isSafeInteger(parsed.after) || parsed.after < 0) {
      throw Object.assign(new Error("EVENT_CURSOR_INVALID"), { code: "EVENT_CURSOR_INVALID" });
    }
    if (parsed.revision !== revision.digest || parsed.view !== revision.view || JSON.stringify(parsed.topics ?? null) !== JSON.stringify(normalizedTopics)) {
      throw Object.assign(new Error("EVENT_CURSOR_STALE"), { code: "EVENT_CURSOR_STALE" });
    }
    start = parsed.after;
  }
  const page = filtered.slice(start, start + limit2);
  const nextAfter = start + page.length;
  const hasMore = nextAfter < filtered.length;
  const cursor = JSON.stringify({
    revision: revision.digest,
    view: revision.view,
    topics: normalizedTopics,
    after: nextAfter
  });
  return { revision, events: page, cursor, hasMore };
}

// packages/peer-session/src/runtime.ts
async function createApplicationSession(options) {
  const release = claimApplicationDevice(options.device);
  try {
    const storage = await options.device.openStorage();
    return await ApplicationSession.open({
      ...options,
      store: storage.store,
      async release() {
        release();
        await options.device.close();
      }
    });
  } catch (error) {
    release();
    await options.device.close();
    throw error;
  }
}

export {
  createApplicationSession
};
