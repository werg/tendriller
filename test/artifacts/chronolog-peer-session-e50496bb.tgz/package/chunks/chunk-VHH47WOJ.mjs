import {
  computeCasHash,
  decodeCasNode,
  encodeCasNode,
  hashCasNode,
  tryParseCasRef
} from "./chunk-OWL5GQ66.mjs";
import {
  isControlTopic
} from "./chunk-XIVHZVOM.mjs";

// packages/peer-session/src/utilities.ts
var HEX32 = /^[0-9a-f]{64}$/u;
function collectCasRefsFromValue(value, options = {}) {
  const maxDepth = options.maxDepth ?? 8;
  const maxRefs = options.maxRefs ?? 256;
  const casHashes = /* @__PURE__ */ new Set();
  const contentIds = /* @__PURE__ */ new Set();
  const walk = (v, depth) => {
    if (depth > maxDepth || casHashes.size + contentIds.size >= maxRefs || v === null || v === void 0) return;
    if (typeof v === "string") {
      const h = tryParseCasRef(v);
      if (h !== null) casHashes.add(h);
      return;
    }
    if (Array.isArray(v)) {
      for (const item of v) walk(item, depth + 1);
      return;
    }
    if (typeof v === "object") {
      const rec = v;
      if (rec.profile === "chronolog-blob-v2" && typeof rec.hash === "string" && HEX32.test(rec.hash)) {
        casHashes.add(rec.hash);
      }
      if (rec.profile === "authored-content-v1" && typeof rec.id === "string" && rec.id.length > 0) {
        contentIds.add(rec.id);
      }
      for (const child of Object.values(rec)) walk(child, depth + 1);
    }
  };
  walk(value, 0);
  return { casHashes: [...casHashes].sort(), contentIds: [...contentIds].sort() };
}
function bytesToBase64(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}
function base64ToBytes(b64) {
  const binary = atob(b64);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}
async function exportLogBlueprint(session) {
  const reducers = session.topic("$reducers");
  const rawTopics = reducers?.topics ?? {};
  const rawImports = reducers?.imports ?? {};
  const topics = {};
  const imports = {};
  const rootHashes = [];
  for (const [topicName, binding] of Object.entries(rawTopics)) {
    if (isControlTopic(topicName)) continue;
    topics[topicName] = binding;
    if (binding.module.startsWith("cas:sha256-")) {
      const h = tryParseCasRef(binding.module);
      if (h !== null) rootHashes.push(h);
    } else if (!binding.module.startsWith("chronolog/") && typeof rawImports[binding.module] === "string") {
      const ref = rawImports[binding.module];
      imports[binding.module] = ref;
      const h = tryParseCasRef(ref);
      if (h !== null) rootHashes.push(h);
    }
  }
  for (const [spec, ref] of Object.entries(rawImports)) {
    if (spec.startsWith("chronolog/")) continue;
    if (imports[spec] === void 0 && typeof ref === "string") {
      imports[spec] = ref;
      const h = tryParseCasRef(ref);
      if (h !== null) rootHashes.push(h);
    }
  }
  const casNodes = {};
  if (rootHashes.length > 0) {
    const exported = await session.exportCasNodes([...new Set(rootHashes)], false, {
      subgraph: true,
      maxNodes: 1024,
      maxBytes: 16 * 1024 * 1024
    });
    for (const node of exported) {
      casNodes[node.hash] = bytesToBase64(node.bytes);
    }
  }
  const sqlSchemas = {};
  for (const [topicName, binding] of Object.entries(topics)) {
    if (binding.module !== "chronolog/sql") continue;
    try {
      const res = await session.query(topicName, { query: "schema" });
      if (res.value === null || res.value === void 0 || typeof res.value !== "object" || Array.isArray(res.value)) continue;
      const schemaVal = res.value;
      const userOwned = new Set(Array.isArray(schemaVal.userOwnedObjects) ? schemaVal.userOwnedObjects.filter((s) => typeof s === "string") : []);
      const statements = [];
      const objects = Array.isArray(schemaVal.objects) ? schemaVal.objects : [];
      for (const obj of objects) {
        if (obj === null || typeof obj !== "object") continue;
        const o = obj;
        const name = typeof o.name === "string" ? o.name : "";
        const sql = typeof o.sql === "string" ? o.sql.trim() : "";
        if (!name || !sql || name.startsWith("sqlite_") || name.startsWith("_rls_") || userOwned.has(name)) continue;
        statements.push(sql);
      }
      const policies = schemaVal.policies !== null && typeof schemaVal.policies === "object" && !Array.isArray(schemaVal.policies) ? schemaVal.policies : {};
      sqlSchemas[topicName] = { statements, policies };
    } catch {
    }
  }
  const pubTopic = session.topic("$publications");
  return {
    format: "chronolog-blueprint/v1",
    privateLog: session.genesis.privateLog,
    topics,
    imports,
    casNodes,
    sqlSchemas,
    ...pubTopic?.current !== void 0 && pubTopic.current !== null ? { publication: pubTopic.current } : {}
  };
}
function validateLogBlueprint(blueprint) {
  if (blueprint === null || typeof blueprint !== "object" || Array.isArray(blueprint)) {
    throw new Error("BLUEPRINT_INVALID");
  }
  const b = blueprint;
  if (b.format !== "chronolog-blueprint/v1") throw new Error("BLUEPRINT_FORMAT_INVALID");
  if (b.topics === null || typeof b.topics !== "object" || Array.isArray(b.topics)) {
    throw new Error("BLUEPRINT_TOPICS_INVALID");
  }
  for (const topicName of Object.keys(b.topics)) {
    if (isControlTopic(topicName)) throw new Error(`BLUEPRINT_FORBIDS_CONTROL_TOPIC:${topicName}`);
  }
  if (b.casNodes === null || typeof b.casNodes !== "object" || Array.isArray(b.casNodes)) {
    throw new Error("BLUEPRINT_CAS_INVALID");
  }
  const verifiedNodes = [];
  for (const [hash, b64] of Object.entries(b.casNodes)) {
    if (!HEX32.test(hash) || typeof b64 !== "string") throw new Error(`BLUEPRINT_CAS_ENTRY_INVALID:${hash}`);
    const raw = base64ToBytes(b64);
    if (hashCasNode(raw) === hash) {
      decodeCasNode(raw);
      verifiedNodes.push({ hash, bytes: raw, partition: "public" });
    } else if (computeCasHash(raw, []) === hash) {
      verifiedNodes.push({ hash, bytes: encodeCasNode(raw, []), partition: "public" });
    } else {
      throw new Error(`BLUEPRINT_CAS_HASH_MISMATCH:${hash}`);
    }
  }
  return { blueprint: b, casNodes: verifiedNodes };
}
function attachCasPinner(session, options = {}) {
  const maxBytes = options.maxBytes ?? 128 * 1024 * 1024;
  const maxRefsPerScan = options.maxRefsPerScan ?? 32;
  const maxDepth = options.maxDepth ?? 8;
  const attempted = /* @__PURE__ */ new Set();
  let running = false;
  let rerun = false;
  const scan = async () => {
    if (running) {
      rerun = true;
      return;
    }
    running = true;
    try {
      const reducers = session.topic("$reducers");
      const topicNames = options.topics ?? Object.keys(reducers?.topics ?? {}).filter((t) => !isControlTopic(t));
      const refs = [];
      for (const name of topicNames) {
        const state = session.topic(name);
        if (state === void 0) continue;
        const found = collectCasRefsFromValue(state, { maxDepth, maxRefs: maxRefsPerScan });
        for (const h of found.casHashes) refs.push(h);
        for (const id of found.contentIds) refs.push(id);
      }
      let fetched = 0;
      for (const ref of refs) {
        if (fetched >= maxRefsPerScan) break;
        if (attempted.has(ref)) continue;
        attempted.add(ref);
        fetched += 1;
        try {
          const data = await session.content.get(ref, { cache: true });
          if (data !== null && session.content.pin !== void 0) {
            await session.content.pin(ref);
          }
        } catch {
          attempted.delete(ref);
        }
      }
      if (fetched > 0 && session.content.pruneCache !== void 0) {
        await session.content.pruneCache({ maxBytes }).catch(() => {
        });
      }
    } finally {
      running = false;
      if (rerun) {
        rerun = false;
        void scan();
      }
    }
  };
  const offChange = session.onChange(() => {
    void scan();
  });
  const offPeer = session.onPeerLink?.(() => {
    attempted.clear();
    void scan();
  });
  void scan();
  return () => {
    offChange();
    offPeer?.();
  };
}

export {
  collectCasRefsFromValue,
  exportLogBlueprint,
  validateLogBlueprint,
  attachCasPinner
};
