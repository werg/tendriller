import {
  ProtocolError,
  integerMap,
  protocolInvariant,
  utf8
} from "./chunk-XIVHZVOM.mjs";
import {
  concatBytes,
  encodeCanonicalCbor,
  sha512
} from "./chunk-VRR2HFJY.mjs";

// packages/crypto/src/shamir.ts
function gfMul(a, b) {
  let x = a & 255;
  let y = b & 255;
  let out = 0;
  for (let i = 0; i < 8; i++) {
    if ((y & 1) !== 0) out ^= x;
    const hi = x & 128;
    x = x << 1 & 255;
    if (hi !== 0) x ^= 27;
    y >>>= 1;
  }
  return out;
}
function gfPow(base, exp) {
  let result = 1;
  let b = base & 255;
  let e = exp;
  while (e > 0) {
    if ((e & 1) !== 0) result = gfMul(result, b);
    b = gfMul(b, b);
    e >>>= 1;
  }
  return result;
}
function gfInv(a) {
  if ((a & 255) === 0) throw new Error("SHAMIR_ZERO_INVERSE");
  return gfPow(a, 254);
}
function splitSecret(secret, threshold, totalShares) {
  if (!(secret instanceof Uint8Array) || secret.length === 0) {
    throw new Error("SHAMIR_SECRET_EMPTY");
  }
  if (!Number.isSafeInteger(threshold) || !Number.isSafeInteger(totalShares) || threshold < 1 || totalShares < threshold || totalShares > 255) {
    throw new Error("SHAMIR_INVALID_THRESHOLD");
  }
  const len = secret.length;
  const coeffs = new Uint8Array((threshold - 1) * len);
  if (coeffs.length > 0) crypto.getRandomValues(coeffs);
  const shares = [];
  for (let i = 1; i <= totalShares; i++) {
    const out = new Uint8Array(len);
    for (let pos = 0; pos < len; pos++) {
      let acc = 0;
      for (let d = threshold - 1; d >= 1; d--) {
        acc = gfMul(acc, i) ^ coeffs[(d - 1) * len + pos];
      }
      acc = gfMul(acc, i) ^ secret[pos];
      out[pos] = acc;
    }
    shares.push({ index: i, bytes: out });
  }
  return shares;
}
function combineShares(shares) {
  if (shares.length === 0) {
    throw new Error("SHAMIR_SHARES_EMPTY");
  }
  const len = shares[0].bytes.length;
  if (len === 0) throw new Error("SHAMIR_SHARE_EMPTY");
  const seen = /* @__PURE__ */ new Set();
  for (const s of shares) {
    if (!Number.isSafeInteger(s.index) || s.index < 1 || s.index > 255) {
      throw new Error("SHAMIR_INVALID_INDEX");
    }
    if (seen.has(s.index)) throw new Error("SHAMIR_DUPLICATE_INDEX");
    seen.add(s.index);
    if (!(s.bytes instanceof Uint8Array) || s.bytes.length !== len) {
      throw new Error("SHAMIR_SHARE_LENGTH_MISMATCH");
    }
  }
  const lambdas = new Uint8Array(shares.length);
  for (let j = 0; j < shares.length; j++) {
    const xj = shares[j].index;
    let num = 1;
    let den = 1;
    for (let m = 0; m < shares.length; m++) {
      if (m === j) continue;
      const xm = shares[m].index;
      num = gfMul(num, xm);
      den = gfMul(den, xm ^ xj);
    }
    lambdas[j] = gfMul(num, gfInv(den));
  }
  const secret = new Uint8Array(len);
  for (let pos = 0; pos < len; pos++) {
    let val = 0;
    for (let j = 0; j < shares.length; j++) {
      val ^= gfMul(shares[j].bytes[pos], lambdas[j]);
    }
    secret[pos] = val;
  }
  return secret;
}

// packages/crypto/src/epoch.ts
function source(value) {
  return Uint8Array.from(value).buffer;
}
var aesKeys = /* @__PURE__ */ new Map();
function aesKey(contentKey) {
  let id = "";
  for (const byte of contentKey) id += byte.toString(16).padStart(2, "0");
  let key = aesKeys.get(id);
  if (key === void 0) {
    if (aesKeys.size >= 256) aesKeys.clear();
    key = globalThis.crypto.subtle.importKey("raw", source(contentKey), "AES-GCM", false, ["encrypt", "decrypt"]);
    aesKeys.set(id, key);
    key.catch(() => aesKeys.delete(id));
  }
  return key;
}
function payloadAad(epoch, associatedData) {
  return encodeCanonicalCbor(integerMap([[0, 1n], [1, epoch], [2, associatedData]]));
}
async function encryptEpochPayload(contentKey, epoch, plaintext, associatedData, explicitNonce) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  const key = await aesKey(contentKey);
  let nonce;
  if (explicitNonce !== void 0) {
    protocolInvariant(explicitNonce.length === 12, "SCHEMA_INVALID", "Epoch payload nonce must contain 12 bytes");
    nonce = explicitNonce.slice();
  } else {
    nonce = globalThis.crypto.getRandomValues(new Uint8Array(12));
  }
  const ciphertext = new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source(nonce), additionalData: source(payloadAad(epoch, associatedData)), tagLength: 128 },
    key,
    source(plaintext)
  ));
  return { epoch, nonce, ciphertext };
}
async function decryptEpochPayload(contentKey, payload, associatedData) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  protocolInvariant(payload.nonce.length === 12, "SCHEMA_INVALID", "Epoch payload nonce must contain 12 bytes");
  try {
    const key = await aesKey(contentKey);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source(payload.nonce), additionalData: source(payloadAad(payload.epoch, associatedData)), tagLength: 128 },
      key,
      source(payload.ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "Epoch payload authentication failed");
  }
}

// packages/crypto/src/hpke.ts
var HPKE_SUITE = "DHKEM(X25519,HKDF-SHA256)/HKDF-SHA256/AES-256-GCM";
var KEM_ID = Uint8Array.of(0, 32);
var KDF_ID = Uint8Array.of(0, 1);
var AEAD_ID = Uint8Array.of(0, 2);
var KEM_SUITE_ID = concatBytes(utf8("KEM"), KEM_ID);
var HPKE_SUITE_ID = concatBytes(utf8("HPKE"), KEM_ID, KDF_ID, AEAD_ID);
var HPKE_VERSION = utf8("HPKE-v1");
var HASH_SIZE = 32;
var X25519 = { name: "X25519" };
function source2(value) {
  return Uint8Array.from(value).buffer;
}
function i2osp(value, length) {
  protocolInvariant(Number.isSafeInteger(value) && value >= 0 && value < 2 ** (8 * length), "INTEGER_OUT_OF_RANGE", "Integer does not fit HPKE field");
  const result = new Uint8Array(length);
  let remainder = value;
  for (let index = length - 1; index >= 0; index -= 1) {
    result[index] = remainder & 255;
    remainder = Math.floor(remainder / 256);
  }
  return result;
}
async function hmac(keyBytes, data) {
  const key = await globalThis.crypto.subtle.importKey(
    "raw",
    source2(keyBytes),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return new Uint8Array(await globalThis.crypto.subtle.sign("HMAC", key, source2(data)));
}
async function hkdfExtract(salt, ikm) {
  return hmac(salt.length === 0 ? new Uint8Array(HASH_SIZE) : salt, ikm);
}
async function hkdfExpand(prk, info, length) {
  protocolInvariant(length <= 255 * HASH_SIZE, "INTEGER_OUT_OF_RANGE", "HKDF output is too long");
  let previous = new Uint8Array();
  const blocks = [];
  for (let counter = 1; blocks.reduce((sum, block) => sum + block.length, 0) < length; counter += 1) {
    previous = await hmac(prk, concatBytes(previous, info, Uint8Array.of(counter)));
    blocks.push(previous);
  }
  return concatBytes(...blocks).slice(0, length);
}
async function labeledExtract(suiteId, salt, label, ikm) {
  return hkdfExtract(salt, concatBytes(HPKE_VERSION, suiteId, utf8(label), ikm));
}
async function labeledExpand(suiteId, prk, label, info, length) {
  return hkdfExpand(prk, concatBytes(i2osp(length, 2), HPKE_VERSION, suiteId, utf8(label), info), length);
}
async function generateX25519KeyPair(extractable = true) {
  const pair = await globalThis.crypto.subtle.generateKey(X25519, extractable, ["deriveBits"]);
  return {
    publicKey: pair.publicKey,
    privateKey: pair.privateKey,
    publicKeyBytes: new Uint8Array(await globalThis.crypto.subtle.exportKey("raw", pair.publicKey))
  };
}
async function importX25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "X25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", source2(raw), X25519, true, []);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import X25519 public key");
  }
}
async function importX25519PrivateKey(pkcs8, extractable = true) {
  try {
    return await globalThis.crypto.subtle.importKey("pkcs8", source2(pkcs8), X25519, extractable, ["deriveBits"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import X25519 private key");
  }
}
async function exportX25519PrivateKey(privateKey) {
  try {
    return new Uint8Array(await globalThis.crypto.subtle.exportKey("pkcs8", privateKey));
  } catch {
    throw new ProtocolError("INVALID_KEY", "X25519 private key is not extractable");
  }
}
async function dh(privateKey, publicKey) {
  try {
    const bits = await globalThis.crypto.subtle.deriveBits({ name: "X25519", public: publicKey }, privateKey, 256);
    const result = new Uint8Array(bits);
    protocolInvariant(result.some((byte) => byte !== 0), "INVALID_KEY", "X25519 produced the prohibited all-zero shared secret");
    return result;
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    throw new ProtocolError("INVALID_KEY", "X25519 key agreement failed");
  }
}
async function extractAndExpand(dhValue, kemContext) {
  const eaePrk = await labeledExtract(KEM_SUITE_ID, new Uint8Array(), "eae_prk", dhValue);
  return labeledExpand(KEM_SUITE_ID, eaePrk, "shared_secret", kemContext, HASH_SIZE);
}
async function keySchedule(sharedSecret, info) {
  const pskIdHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "psk_id_hash", new Uint8Array());
  const infoHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "info_hash", info);
  const keyScheduleContext = concatBytes(Uint8Array.of(0), pskIdHash, infoHash);
  const secret = await labeledExtract(HPKE_SUITE_ID, sharedSecret, "secret", new Uint8Array());
  return {
    key: await labeledExpand(HPKE_SUITE_ID, secret, "key", keyScheduleContext, 32),
    nonce: await labeledExpand(HPKE_SUITE_ID, secret, "base_nonce", keyScheduleContext, 12),
    exporterSecret: await labeledExpand(HPKE_SUITE_ID, secret, "exp", keyScheduleContext, HASH_SIZE)
  };
}
async function aesGcmSeal(keyBytes, nonce, plaintext, aad) {
  const key = await globalThis.crypto.subtle.importKey("raw", source2(keyBytes), "AES-GCM", false, ["encrypt"]);
  return new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source2(nonce), additionalData: source2(aad), tagLength: 128 },
    key,
    source2(plaintext)
  ));
}
async function aesGcmOpen(keyBytes, nonce, ciphertext, aad) {
  try {
    const key = await globalThis.crypto.subtle.importKey("raw", source2(keyBytes), "AES-GCM", false, ["decrypt"]);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source2(nonce), additionalData: source2(aad), tagLength: 128 },
      key,
      source2(ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "HPKE ciphertext authentication failed");
  }
}
async function senderContext(recipientPublicKeyBytes, info) {
  const recipientPublicKey = await importX25519PublicKey(recipientPublicKeyBytes);
  const ephemeral = await generateX25519KeyPair(false);
  const sharedSecret = await extractAndExpand(
    await dh(ephemeral.privateKey, recipientPublicKey),
    concatBytes(ephemeral.publicKeyBytes, recipientPublicKeyBytes)
  );
  try {
    return { encapsulatedKey: ephemeral.publicKeyBytes, context: await keySchedule(sharedSecret, info) };
  } finally {
    sharedSecret.fill(0);
  }
}
async function recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info) {
  protocolInvariant(recipientPublicKeyBytes.length === 32 && encapsulatedKey.length === 32, "INVALID_KEY", "HPKE X25519 keys must contain 32 bytes");
  const ephemeralPublicKey = await importX25519PublicKey(encapsulatedKey);
  const sharedSecret = await extractAndExpand(
    await dh(recipientPrivateKey, ephemeralPublicKey),
    concatBytes(encapsulatedKey, recipientPublicKeyBytes)
  );
  try {
    return await keySchedule(sharedSecret, info);
  } finally {
    sharedSecret.fill(0);
  }
}
function clearContext(context) {
  context.key.fill(0);
  context.nonce.fill(0);
  context.exporterSecret.fill(0);
}
async function hpkeSealBase(recipientPublicKeyBytes, plaintext, info, aad) {
  const { encapsulatedKey, context } = await senderContext(recipientPublicKeyBytes, info);
  try {
    return { encapsulatedKey, ciphertext: await aesGcmSeal(context.key, context.nonce, plaintext, aad) };
  } finally {
    clearContext(context);
  }
}
async function hpkeOpenBase(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, ciphertext, info, aad) {
  const context = await recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info);
  try {
    return await aesGcmOpen(context.key, context.nonce, ciphertext, aad);
  } finally {
    clearContext(context);
  }
}
async function hpkeSendExportBase(recipientPublicKeyBytes, info, exporterContext, length) {
  const { encapsulatedKey, context } = await senderContext(recipientPublicKeyBytes, info);
  try {
    return { encapsulatedKey, exportedSecret: await labeledExpand(HPKE_SUITE_ID, context.exporterSecret, "sec", exporterContext, length) };
  } finally {
    clearContext(context);
  }
}
async function hpkeReceiveExportBase(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info, exporterContext, length) {
  const context = await recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info);
  try {
    return await labeledExpand(HPKE_SUITE_ID, context.exporterSecret, "sec", exporterContext, length);
  } finally {
    clearContext(context);
  }
}

// node_modules/.pnpm/@noble+ed25519@3.2.0/node_modules/@noble/ed25519/index.js
var freeze = Object.freeze;
var P = 0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffedn;
var N = 0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3edn;
var _d = 0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3n;
var Gx = 0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51an;
var Gy = 0x6666666666666666666666666666666666666666666666666666666666666658n;
var _a = P - 1n;
var ed25519_CURVE = freeze({
  p: P,
  n: N,
  h: 8n,
  a: _a,
  d: _d,
  Gx,
  Gy
});
var LEN = 32;
var isBytes = (a) => {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && a.BYTES_PER_ELEMENT === 1;
};
var abytes = (value, length, title = "") => {
  if (isBytes(value) && (length === void 0 || value.length === length))
    return value;
  const bytes = isBytes(value);
  const ofLen = length !== void 0 ? ` of length ${length}` : "";
  const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
  const message = (title ? `"${title}" ` : "") + "expected Uint8Array" + ofLen + ", got " + got;
  if (!bytes)
    throw new TypeError(message);
  throw new RangeError(message);
};
var snapshotBytes = (value, title = "", length) => Uint8Array.from(abytes(value, length, title));
var padh = (n, pad) => n.toString(16).padStart(pad, "0");
var bytesToHex = (bytes) => {
  let hex = "";
  for (const byte of abytes(bytes))
    hex += padh(byte, 2);
  return hex;
};
var hexToBytes = (hex) => {
  const e = "hex invalid";
  if (typeof hex !== "string")
    throw new TypeError(e);
  if (hex.length % 2 || !/^[\da-f]*$/i.test(hex))
    throw new RangeError(e);
  const array = new Uint8Array(hex.length / 2);
  for (let ai = 0, hi = 0; ai < array.length; ai++, hi += 2) {
    const n1 = hex.charCodeAt(hi);
    const n2 = hex.charCodeAt(hi + 1);
    array[ai] = ((n1 & 15) + (n1 >> 6) * 9) * 16 + (n2 & 15) + (n2 >> 6) * 9;
  }
  return array;
};
var concatBytes2 = (...arrays) => {
  let sum = 0;
  for (const a of arrays)
    sum += abytes(a).length;
  const res = new Uint8Array(sum);
  let pad = 0;
  for (const a of arrays) {
    res.set(a, pad);
    pad += a.length;
  }
  return res;
};
var arange = (n, min, max, msg = "bad number: out of range") => {
  if (typeof n !== "bigint")
    throw new TypeError(msg);
  if (min <= n && n < max)
    return n;
  throw new RangeError(msg);
};
var mod = (a, b = P) => (a %= b) >= 0n ? a : b + a;
var P_MASK = (1n << 255n) - 1n;
var modP = (num) => {
  if (num < 0n)
    throw new RangeError("negative coordinate");
  let r = (num >> 255n) * 19n + (num & P_MASK);
  r = (r >> 255n) * 19n + (r & P_MASK);
  return r % P;
};
var modN = (a) => mod(a, N);
var invert = (number, modulo) => {
  if (number === 0n)
    throw new Error("invert: expected non-zero number");
  if (modulo <= 1n)
    throw new Error("invert: expected modulus > 1, got " + modulo);
  let a = mod(number, modulo);
  let b = modulo;
  let x = 0n, u = 1n;
  while (a !== 0n) {
    const q = b / a;
    const r = b - a * q;
    const m = x - u * q;
    b = a, a = r, x = u, u = m;
  }
  const gcd = b;
  if (gcd !== 1n)
    throw new Error("invert: does not exist");
  return mod(x, modulo);
};
var _hash = (name) => {
  const fn = hashes[name];
  if (typeof fn !== "function")
    throw new Error("hashes." + name + " not set");
  return fn;
};
var callHash = (name, ...m) => abytes(_hash(name)(concatBytes2(...m)), 64, "digest");
var apoint = (p) => {
  if (p instanceof Point)
    return p;
  throw new TypeError("Point expected");
};
var B256 = 2n ** 256n;
var Point = class _Point {
  static BASE;
  static ZERO;
  X;
  Y;
  Z;
  T;
  // Constructor only bounds-checks and freezes XYZT coordinates; it does not prove the point is
  // on-curve or that T matches X*Y/Z.
  constructor(X, Y, Z, T) {
    const max = B256;
    this.X = arange(X, 0n, max);
    this.Y = arange(Y, 0n, max);
    this.Z = arange(Z, 1n, max);
    this.T = arange(T, 0n, max);
    freeze(this);
  }
  static CURVE() {
    return ed25519_CURVE;
  }
  static fromAffine(p) {
    return new _Point(p.x, p.y, 1n, modP(p.x * p.y));
  }
  /** RFC8032 5.1.3: Uint8Array to Point. */
  static fromBytes(bytes, zip215 = false) {
    const normed = snapshotBytes(bytes, "point", LEN);
    const lastByte = normed[31];
    normed[31] = lastByte & ~128;
    const y = bytesToNumberLE(normed);
    if (!zip215)
      arange(y, 0n, P);
    const y2 = modP(y * y);
    const u = mod(y2 - 1n);
    const v = modP(_d * y2 + 1n);
    let { isValid, value: x } = uvRatio(u, v);
    if (!isValid)
      throw new Error("bad point: y not sqrt");
    const isLastByteOdd = !!(lastByte & 128);
    if (!zip215 && x === 0n && isLastByteOdd)
      throw new Error("bad point: x==0, isLastByteOdd");
    if (isLastByteOdd !== !!(x & 1n))
      x = mod(-x);
    return new _Point(x, y, 1n, modP(x * y));
  }
  static fromHex(hex, zip215) {
    return _Point.fromBytes(hexToBytes(hex), zip215);
  }
  get x() {
    return this.toAffine().x;
  }
  get y() {
    return this.toAffine().y;
  }
  /** Checks if the point is valid and on-curve. */
  assertValidity() {
    const a = _a;
    const d = _d;
    const p = this;
    if (p.is0())
      throw new Error("bad point: ZERO");
    const { X, Y, Z, T } = p;
    const X2 = modP(X * X);
    const Y2 = modP(Y * Y);
    const Z2 = modP(Z * Z);
    const Z4 = modP(Z2 * Z2);
    const aX2 = modP(X2 * a);
    const left = modP(Z2 * (aX2 + Y2));
    const right = mod(Z4 + modP(d * modP(X2 * Y2)));
    if (left !== right)
      throw new Error("bad point: equation left != right (1)");
    const XY = modP(X * Y);
    const ZT = modP(Z * T);
    if (XY !== ZT)
      throw new Error("bad point: equation left != right (2)");
    return this;
  }
  /** Equality check: compare points P&Q. */
  equals(other) {
    const { X: X1, Y: Y1, Z: Z1 } = this;
    const { X: X2, Y: Y2, Z: Z2 } = apoint(other);
    return modP(X1 * Z2) === modP(X2 * Z1) && modP(Y1 * Z2) === modP(Y2 * Z1);
  }
  is0() {
    return this.equals(I);
  }
  /** Flip point over y coordinate. */
  negate() {
    return new _Point(mod(-this.X), this.Y, this.Z, mod(-this.T));
  }
  /** Point doubling. Complete formula. Cost: `4M + 4S + 1*a + 6add + 1*2`. */
  double() {
    const { X: X1, Y: Y1, Z: Z1 } = this;
    const a = _a;
    const A = modP(X1 * X1);
    const B = modP(Y1 * Y1);
    const C = modP(2n * Z1 * Z1);
    const D = modP(a * A);
    const x1y1 = mod(X1 + Y1);
    const E = mod(modP(x1y1 * x1y1) - A - B);
    const G2 = mod(D + B);
    const F = mod(G2 - C);
    const H = mod(D - B);
    const X3 = modP(E * F);
    const Y3 = modP(G2 * H);
    const T3 = modP(E * H);
    const Z3 = modP(F * G2);
    return new _Point(X3, Y3, Z3, T3);
  }
  /** Point addition. Complete formula. Cost: `9M + 1*a + 1*d + 7add`. */
  add(other) {
    const { X: X1, Y: Y1, Z: Z1, T: T1 } = this;
    const { X: X2, Y: Y2, Z: Z2, T: T2 } = apoint(other);
    const a = _a;
    const d = _d;
    const A = modP(X1 * X2);
    const B = modP(Y1 * Y2);
    const C = modP(modP(T1 * d) * T2);
    const D = modP(Z1 * Z2);
    const E = mod(modP(mod(X1 + Y1) * mod(X2 + Y2)) - A - B);
    const F = mod(D - C);
    const G2 = mod(D + C);
    const H = mod(B - modP(a * A));
    const X3 = modP(E * F);
    const Y3 = modP(G2 * H);
    const T3 = modP(E * H);
    const Z3 = modP(F * G2);
    return new _Point(X3, Y3, Z3, T3);
  }
  subtract(other) {
    return this.add(apoint(other).negate());
  }
  /**
   * Point-by-scalar multiplication. Safe mode requires `1 <= n < CURVE.n`.
   * Unsafe mode additionally permits `n = 0` and returns the identity point for that case.
   * Uses {@link wNAF} for base point.
   * Uses fake point to mitigate side-channel leakage.
   * @param n - scalar by which point is multiplied
   * @param safe - safe mode guards against timing attacks; unsafe mode is faster
   */
  multiply(n, safe = true) {
    if (!safe && n === 0n)
      return I;
    arange(n, 1n, N);
    if (!safe && this.is0())
      return I;
    if (n === 1n)
      return this;
    if (this.equals(G))
      return wNAF(n).p;
    let p = I;
    let f = G;
    let d = this;
    for (let i = 0; safe ? i < 256 : n > 0n; i++) {
      if (n & 1n)
        p = p.add(d);
      else if (safe)
        f = f.add(d);
      d = d.double();
      n >>= 1n;
    }
    return p;
  }
  multiplyUnsafe(scalar) {
    return this.multiply(scalar, false);
  }
  /** Convert point to 2d xy affine point. (X, Y, Z) ∋ (x=X/Z, y=Y/Z) */
  toAffine() {
    const { X, Y, Z } = this;
    if (this.equals(I))
      return { x: 0n, y: 1n };
    const iz = invert(Z, P);
    if (modP(Z * iz) !== 1n)
      throw new Error("invalid inverse");
    return { x: modP(X * iz), y: modP(Y * iz) };
  }
  toBytes() {
    const { x, y } = this.toAffine();
    const b = numTo32bLE(y);
    b[31] |= x & 1n ? 128 : 0;
    return b;
  }
  toHex() {
    return bytesToHex(this.toBytes());
  }
  clearCofactor() {
    return this.multiply(8n, false);
  }
  isSmallOrder() {
    return this.clearCofactor().is0();
  }
  isTorsionFree() {
    return this.multiply(N / 2n, false).double().add(this).is0();
  }
};
var G = new Point(Gx, Gy, 1n, mod(Gx * Gy));
var I = new Point(0n, 1n, 1n, 0n);
Point.BASE = G;
Point.ZERO = I;
var numTo32bLE = (num) => hexToBytes(padh(arange(num, 0n, B256), 64)).reverse();
var bytesToNumberLE = (b) => BigInt("0x" + bytesToHex(Uint8Array.from(abytes(b)).reverse()));
var pow2 = (x, power) => {
  let r = x;
  while (power-- > 0) {
    r = modP(r * r);
  }
  return r;
};
var pow_2_252_3 = (x) => {
  const x2 = modP(x * x);
  const b2 = modP(x2 * x);
  const b4 = modP(pow2(b2, 2) * b2);
  const b5 = modP(pow2(b4, 1) * x);
  const b10 = modP(pow2(b5, 5) * b5);
  const b20 = modP(pow2(b10, 10) * b10);
  const b40 = modP(pow2(b20, 20) * b20);
  const b80 = modP(pow2(b40, 40) * b40);
  const b160 = modP(pow2(b80, 80) * b80);
  const b240 = modP(pow2(b160, 80) * b80);
  const b250 = modP(pow2(b240, 10) * b10);
  return modP(pow2(b250, 2) * x);
};
var RM1 = 0x2b8324804fc1df0b2b4d00993dfbd7a72f431806ad2fe478c4ee1b274a0ea0b0n;
var uvRatio = (u, v) => {
  const v3 = modP(v * modP(v * v));
  const v7 = modP(modP(v3 * v3) * v);
  const pow = pow_2_252_3(modP(u * v7));
  let x = modP(u * modP(v3 * pow));
  const vx2 = modP(v * modP(x * x));
  const root1 = x;
  const root2 = modP(x * RM1);
  const useRoot1 = vx2 === u;
  const useRoot2 = vx2 === mod(-u);
  const noRoot = vx2 === mod(-u * RM1);
  if (useRoot1)
    x = root1;
  if (useRoot2 || noRoot)
    x = root2;
  if ((mod(x) & 1n) === 1n)
    x = mod(-x);
  return { isValid: useRoot1 || useRoot2, value: x };
};
var modL_LE = (hash) => modN(bytesToNumberLE(hash));
var hashFinishSync = (res) => res[1](callHash("sha512", res[0]));
var getZip215 = (options) => {
  if (options === null || typeof options !== "object")
    throw new TypeError("expected valid options object");
  return options.zip215 ?? true;
};
var _verify = (sig, msg, publicKey, options) => {
  sig = abytes(sig, 64, "signature");
  msg = abytes(msg, void 0, "message");
  publicKey = abytes(publicKey, LEN, "publicKey");
  const zip215 = getZip215(options);
  const r = sig.subarray(0, LEN);
  const s = bytesToNumberLE(sig.subarray(LEN, 64));
  let A, R, SB;
  let hashable = Uint8Array.of();
  let finished = false;
  try {
    A = Point.fromBytes(publicKey, zip215);
    R = Point.fromBytes(r, zip215);
    SB = G.multiply(s, false);
    hashable = concatBytes2(r, publicKey, msg);
    finished = true;
  } catch (error) {
  }
  const finish = (hashed) => {
    if (!finished)
      return false;
    if (!zip215 && A.isSmallOrder())
      return false;
    const k = modL_LE(hashed);
    const RkA = R.add(A.multiply(k, false));
    return RkA.subtract(SB).clearCofactor().is0();
  };
  return [hashable, finish];
};
var verify = (signature, message, publicKey, opts = {}) => hashFinishSync(_verify(signature, message, publicKey, opts));
var hashes = {
  sha512Async: async (message) => {
    const s = globalThis?.crypto?.subtle;
    if (!s)
      throw new Error("crypto.subtle must be defined, consider polyfill");
    return new Uint8Array(await s.digest("SHA-512", concatBytes2(message)));
  },
  sha512: void 0
};
var precompute = () => {
  const points = [];
  let p = G;
  let b;
  for (let w = 0; w < 33; w++) {
    b = p;
    points.push(b);
    for (let i = 1; i < 128; i++) {
      b = b.add(p);
      points.push(b);
    }
    p = b.double();
  }
  return points;
};
var Gpows = void 0;
var ctneg = (cnd, p) => {
  const n = p.negate();
  return cnd ? n : p;
};
var wNAF = (n) => {
  const comp = Gpows || (Gpows = precompute());
  let p = I;
  let f = G;
  for (let w = 0; w < 33; w++) {
    let wbits = Number(n & 255n);
    n >>= 8n;
    if (wbits > 128) {
      wbits -= 256;
      n += 1n;
    }
    const off = w * 128;
    const offP = off + Math.abs(wbits) - 1;
    const isOddW = w % 2 !== 0;
    const isNeg = wbits < 0;
    if (wbits === 0) {
      f = f.add(ctneg(isOddW, comp[off]));
    } else {
      p = p.add(ctneg(isNeg, comp[offP]));
    }
  }
  if (n !== 0n)
    throw new Error("invalid wnaf");
  return { p, f };
};

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha512.js
var sha5122 = sha512;

// packages/crypto/src/ed25519-sync.ts
hashes.sha512 = (message) => sha5122(message);
function verifyEd25519Sync(publicKey, message, signature) {
  if (publicKey.length !== 32 || signature.length !== 64) return false;
  try {
    return verify(signature, message, publicKey);
  } catch {
    return false;
  }
}

export {
  encryptEpochPayload,
  decryptEpochPayload,
  HPKE_SUITE,
  generateX25519KeyPair,
  importX25519PrivateKey,
  exportX25519PrivateKey,
  hpkeSealBase,
  hpkeOpenBase,
  hpkeSendExportBase,
  hpkeReceiveExportBase,
  verifyEd25519Sync,
  splitSecret,
  combineShares
};
/*! Bundled license information:

@noble/ed25519/index.js:
  (*! noble-ed25519 - MIT License (c) 2019 Paul Miller (paulmillr.com) *)
*/
