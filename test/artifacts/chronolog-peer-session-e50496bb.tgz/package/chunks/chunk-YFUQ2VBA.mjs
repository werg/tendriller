import {
  APPLICATION_OWNER_PROTOCOL,
  SessionError
} from "./chunk-WUJDLR5N.mjs";
import {
  CONTENT_CHUNK_BYTES,
  MAX_BLOB_BYTES,
  isPrivateContentReference,
  isPublicBlobReference,
  putContentBytes,
  readContentBytes
} from "./chunk-O7NXWMZY.mjs";

// packages/peer-session/src/worker-application.ts
var WorkerApplicationOperation = class {
  constructor(id, operationId, session) {
    this.id = id;
    this.operationId = operationId;
    this.session = session;
  }
  id;
  operationId;
  session;
  stored = true;
  inspect() {
    return this.session.request("operation.inspect", [this.id]);
  }
  materialized(options) {
    return this.session.wait(this.id, "materialized", options);
  }
  retained(options) {
    return this.session.wait(this.id, "retained", options);
  }
  finalized(options) {
    return this.session.wait(this.id, "finalized", options);
  }
};
var WorkerApplicationSession = class {
  #endpoint;
  #attachment = crypto.randomUUID();
  #lifetime = new AbortController();
  #pending = /* @__PURE__ */ new Map();
  #statuses = /* @__PURE__ */ new Set();
  #changes = /* @__PURE__ */ new Set();
  #extensions = /* @__PURE__ */ new Set();
  #ownedViews = /* @__PURE__ */ new Set();
  #next = 0;
  #binding;
  #attachmentState = "active";
  #heartbeat;
  #pinging = false;
  #description;
  #status = { canAuthor: false, phase: "ready", database: "idle", connectedPeers: 0, pendingOperations: 0, materializationError: null };
  applicationId = "";
  identity = { publicKey: "" };
  constructor(endpoint) {
    this.#endpoint = endpoint;
    endpoint.addEventListener("message", this.#receive);
    const physical = endpoint;
    physical.addEventListener("close", this.#physicalClose);
    physical.addEventListener("messageerror", this.#physicalClose);
    physical.on?.("close", this.#physicalClose);
    physical.on?.("messageerror", this.#physicalClose);
  }
  #physicalClose = () => {
    this.#detach(Object.assign(new Error("OWNER_UNREACHABLE"), { code: "OWNER_UNREACHABLE" }));
  };
  get signal() {
    return this.#lifetime.signal;
  }
  get status() {
    return { ...this.#status, canAuthor: this.#status.canAuthor && this.#attachmentState === "active" && this.#binding?.capabilities.includes("commands") === true };
  }
  get endpoint() {
    return this.#binding === void 0 ? void 0 : structuredClone(this.#binding);
  }
  get attachmentState() {
    return this.#attachmentState;
  }
  describe() {
    if (this.#description === void 0) throw new Error("ENDPOINT_HANDSHAKE_REQUIRED");
    return structuredClone(this.#description);
  }
  get boundedRequest() {
    const requests = [...this.#pending.values()].filter((request2) => request2.method !== "operation.wait" && request2.method !== "signals.next").sort((a, b) => a.startedAt - b.startedAt);
    const request = requests[0];
    return request === void 0 ? null : { startedAt: request.startedAt, deadline: request.deadline };
  }
  #receive = (event) => {
    const message = event.data;
    if (message?.protocol !== APPLICATION_OWNER_PROTOCOL || message.attachment !== this.#attachment) return;
    if (message.kind === "response") {
      const response = message, pending = this.#pending.get(response.id);
      if (pending === void 0) return;
      this.#pending.delete(response.id);
      clearTimeout(pending.timer);
      pending.cleanup();
      if (response.error !== void 0) pending.reject(Object.assign(new Error(response.error), { code: response.error }));
      else pending.resolve(response.value);
    } else if (message.kind === "notice") {
      const notice = message;
      if (notice.topic === "closed") {
        this.#detach(new Error(String(notice.value)));
        return;
      }
      if (notice.topic === "status") {
        this.#status = notice.value;
        for (const listener of this.#statuses) {
          try {
            listener(this.status);
          } catch {
          }
        }
      }
      if (notice.topic === "extension") for (const listener of this.#extensions) {
        try {
          listener(notice.value);
        } catch {
        }
      }
      if (notice.topic === "change") for (const listener of this.#changes) {
        try {
          listener(notice.value);
        } catch {
        }
      }
    }
  };
  request(method, args, options = {}) {
    if (this.signal.aborted) return Promise.reject(this.signal.reason);
    if (options.signal?.aborted) return Promise.reject(options.signal.reason);
    const control = ["close", "attachment.ping", "attachment.suspend", "attachment.resume", "view.release", "sqlBranch.close", "content.cancel", "content.blobAbortWrite", "content.blobCloseRead", "signals.close", "upload.discard"].includes(method);
    if ([...this.#pending.values()].filter((request) => ["close", "attachment.ping", "attachment.suspend", "attachment.resume", "view.release", "sqlBranch.close", "content.cancel", "content.blobAbortWrite", "content.blobCloseRead", "signals.close", "upload.discard"].includes(request.method) === control).length >= (control ? 8 : 32)) return Promise.reject(new Error("ENDPOINT_REQUEST_LIMIT"));
    const timeoutMs = options.timeoutMs ?? 3e4;
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 12e4) return Promise.reject(new Error("ENDPOINT_TIMEOUT_LIMIT"));
    const id = ++this.#next, startedAt = performance.now();
    return new Promise((resolve, reject) => {
      const cancel = () => {
        try {
          this.#endpoint.postMessage({ protocol: APPLICATION_OWNER_PROTOCOL, attachment: this.#attachment, kind: "cancel", id });
        } catch {
        }
      };
      const abort = () => {
        const pending = this.#pending.get(id);
        if (pending === void 0) return;
        this.#pending.delete(id);
        clearTimeout(pending.timer);
        pending.cleanup();
        cancel();
        reject(options.signal?.reason);
      };
      const cleanup = () => options.signal?.removeEventListener("abort", abort);
      const timer = setTimeout(() => {
        this.#pending.delete(id);
        cleanup();
        cancel();
        reject(Object.assign(new Error("ENDPOINT_REQUEST_TIMEOUT"), { code: "ENDPOINT_REQUEST_TIMEOUT" }));
      }, timeoutMs);
      this.#pending.set(id, { method, startedAt, deadline: startedAt + timeoutMs, resolve: (value) => resolve(value), reject, timer, cleanup });
      options.signal?.addEventListener("abort", abort, { once: true });
      try {
        this.#endpoint.postMessage({ protocol: APPLICATION_OWNER_PROTOCOL, attachment: this.#attachment, kind: "request", id, method, args });
      } catch (error) {
        this.#pending.delete(id);
        clearTimeout(timer);
        cleanup();
        reject(error);
      }
    });
  }
  async initialize(options) {
    const value = await this.request("hello", [options]);
    this.applicationId = value.applicationId;
    this.identity = value.identity;
    this.#status = value.status;
    this.#binding = value.binding;
    this.#description = value.definition;
    if (options.heartbeat === true) {
      this.#heartbeat = setInterval(() => {
        if (this.#pinging || this.signal.aborted || this.#attachmentState === "suspended") return;
        this.#pinging = true;
        void this.request("attachment.ping", [], { timeoutMs: 2e4 }).catch((error) => this.#detach(error)).finally(() => {
          this.#pinging = false;
        });
      }, 5e3);
      this.#heartbeat.unref?.();
    }
  }
  async suspendAttachment() {
    await this.request("attachment.suspend", []);
    this.#attachmentState = "suspended";
    this.#ownedViews.clear();
  }
  suspend() {
    return this.suspendAttachment();
  }
  async resumeAttachment() {
    this.#status = await this.request("attachment.resume", []);
    this.#attachmentState = "active";
    return this.endpoint ?? null;
  }
  detach() {
    return this.close();
  }
  async submit(input) {
    const value = await this.request("submit", [input]);
    return new WorkerApplicationOperation(value.id, value.operationId, this);
  }
  async command(name, input, options = {}) {
    const value = await this.request("command", [name, input, options]);
    return new WorkerApplicationOperation(value.id, value.operationId, this);
  }
  query(name, input = null) {
    return this.request("query", [name, input]);
  }
  topic(name) {
    return this.request("topic", [name]);
  }
  queryAsOf(topic, input = null, target) {
    return this.request("queryAsOf", [topic, input, target]);
  }
  opOutcome(opId) {
    return this.request("opOutcome", [opId]);
  }
  topicLastOpId(topic) {
    return this.request("topicLastOpId", [topic]);
  }
  permissions() {
    return this.request("permissions.summary", []);
  }
  finalityStatus(opId) {
    return this.request("finality.opStatus", [opId]);
  }
  equivocationProofs() {
    return this.request("finality.equivocationProofs", []);
  }
  async forkSql(topic) {
    const opened = await this.request("sqlBranch.open", [topic]);
    let closed = false;
    const checkOpen = () => {
      if (closed) throw new Error("SQL_BRANCH_CLOSED");
    };
    return {
      topic: opened.topic,
      baseRoot: opened.baseRoot,
      exec: (sql, params = [], options = { mode: "user" }) => {
        checkOpen();
        return this.request("sqlBranch.exec", [opened.id, sql, params, options]);
      },
      query: (sql, params = []) => {
        checkOpen();
        return this.request("sqlBranch.query", [opened.id, sql, params]);
      },
      commitBranch: () => {
        checkOpen();
        return this.request("sqlBranch.commit", [opened.id]);
      },
      diff: () => {
        checkOpen();
        return this.request("sqlBranch.diff", [opened.id]);
      },
      toProposal: (options = {}) => {
        checkOpen();
        return this.request("sqlBranch.toProposal", [opened.id, options]);
      },
      close: async () => {
        if (closed) return;
        closed = true;
        await this.request("sqlBranch.close", [opened.id]);
      }
    };
  }
  async createCompartment(ringName, options) {
    const res = await this.request("compartment.create", [ringName, options]);
    return { ring: res.ring, epoch: res.epoch, operation: new WorkerApplicationOperation(res.operation.id, res.operation.operationId, this) };
  }
  async setupSocialRecovery(options) {
    const res = await this.request("recovery.setup", [options]);
    return new WorkerApplicationOperation(res.id, res.operationId, this);
  }
  async requestSocialRecovery(options = {}) {
    const res = await this.request("recovery.request", [options]);
    return { requestId: res.requestId, verificationCode: res.verificationCode, operation: new WorkerApplicationOperation(res.operation.id, res.operation.operationId, this) };
  }
  async approveSocialRecovery(requestId, options = {}) {
    const res = await this.request("recovery.approve", [requestId, options]);
    return new WorkerApplicationOperation(res.id, res.operationId, this);
  }
  completeSocialRecovery() {
    return this.request("recovery.complete", []);
  }
  readEvents(options = {}) {
    return this.request("readEvents", [options]);
  }
  wait(id, fact, options = {}) {
    const timeoutMs = options.timeoutMs ?? 3e4;
    return this.request("operation.wait", [id, fact, timeoutMs], { ...options, timeoutMs: Math.min(12e4, timeoutMs + 1e3) });
  }
  async readView(options = {}) {
    const captured = await this.request("readView", [options]);
    this.#ownedViews.add(captured.id);
    let released = false, releasing;
    return {
      applicationId: this.applicationId,
      revision: captured.revision,
      topic: (name) => {
        if (released) return Promise.reject(new Error("READ_VIEW_RELEASED"));
        return this.request("view.topic", [captured.id, name]);
      },
      query: (topic, input = null) => {
        if (released) return Promise.reject(new Error("READ_VIEW_RELEASED"));
        return this.request("view.query", [captured.id, topic, input]);
      },
      readEvents: (evOptions) => {
        if (released) return Promise.reject(new Error("READ_VIEW_RELEASED"));
        return this.request("view.events", [captured.id, evOptions ?? {}]);
      },
      release: () => {
        if (releasing !== void 0) return releasing;
        released = true;
        this.#ownedViews.delete(captured.id);
        return releasing = this.request("view.release", [captured.id]);
      }
    };
  }
  get operations() {
    const session = this;
    return {
      async retry(id) {
        const value = await session.request("operation.retry", [id]);
        return new WorkerApplicationOperation(value.id, value.operationId, session);
      },
      async get(id) {
        const value = await session.request("operation.get", [id]);
        return value === null ? null : new WorkerApplicationOperation(value.id, value.operationId, session);
      },
      async *subscribe(options) {
        const signal = options.signal === void 0 ? session.signal : AbortSignal.any([session.signal, options.signal]);
        let dirty = true, wake;
        const invalidate = () => {
          dirty = true;
          wake?.();
        };
        const stop = session.onChange(invalidate), stopStatus = session.onStatus(invalidate);
        signal.addEventListener("abort", invalidate);
        try {
          while (!signal.aborted) {
            if (!dirty) await new Promise((resolve) => {
              wake = resolve;
            });
            if (signal.aborted) break;
            dirty = false;
            const operation = await session.operations.get(options.operationId);
            if (operation !== null) yield await operation.inspect();
          }
        } finally {
          stop();
          stopStatus();
          signal.removeEventListener("abort", invalidate);
        }
      }
    };
  }
  onStatus(listener) {
    this.#statuses.add(listener);
    listener(this.status);
    return () => {
      this.#statuses.delete(listener);
    };
  }
  onChange(listener) {
    this.#changes.add(listener);
    return () => {
      this.#changes.delete(listener);
    };
  }
  async *changes(options = {}) {
    const signal = options.signal === void 0 ? this.signal : AbortSignal.any([this.signal, options.signal]), queue = [];
    let wake;
    const stop = this.onChange((value) => {
      queue.splice(0, queue.length, value);
      wake?.();
    }), abort = () => {
      wake?.();
    };
    signal.addEventListener("abort", abort);
    try {
      while (!signal.aborted) {
        if (queue.length === 0) await new Promise((resolve) => {
          wake = resolve;
        });
        while (queue.length > 0 && !signal.aborted) yield queue.shift();
      }
    } finally {
      stop();
      signal.removeEventListener("abort", abort);
    }
  }
  diagnostics() {
    return this.request("diagnostics.peers", []);
  }
  endpoints() {
    return this.request("endpoints.list", []);
  }
  exportFacts(options) {
    return this.request("facts.export", options === void 0 ? [] : [options]);
  }
  mergeFacts(facts) {
    return this.request("facts.merge", [facts]);
  }
  finality = {
    status: () => this.request("finality.status", []),
    createCheckpoint: (options) => this.request("finality.createCheckpoint", [options]),
    submitCheckpoints: (checkpoints) => this.request("finality.submitCheckpoints", [checkpoints])
  };
  extensions = {
    call: (name, args = [], options = {}) => this.request("extension.call", [name, args], options),
    subscribe: (listener) => {
      this.#extensions.add(listener);
      return () => {
        this.#extensions.delete(listener);
      };
    }
  };
  signals = {
    delivery: "application",
    send: (topic, payload, options = {}) => {
      const { signal, ...rest } = options;
      return this.request("signals.send", [topic, payload, rest], signal === void 0 ? {} : { signal });
    },
    subscribe: (options = {}) => {
      const session = this;
      return {
        async *[Symbol.asyncIterator]() {
          const { signal, ...rest } = options;
          const id = await session.request("signals.open", [rest], signal === void 0 ? {} : { signal });
          try {
            while (true) {
              const next = await session.request("signals.next", [id], signal === void 0 ? { timeoutMs: 12e4 } : { signal, timeoutMs: 12e4 });
              if (next === null) return;
              yield next;
            }
          } finally {
            void session.request("signals.close", [id]).catch(() => void 0);
          }
        }
      };
    }
  };
  content = {
    stage: async (options) => {
      const id = await this.request("content.stage", [options]);
      return {
        id,
        write: (index, bytes) => this.request("upload.write", [id, index, bytes]),
        progress: () => this.request("upload.progress", [id]),
        commit: () => this.request("upload.commit", [id]),
        discard: () => this.request("upload.discard", [id])
      };
    },
    read: (reference, options = {}) => {
      const session = this;
      return {
        async *[Symbol.asyncIterator]() {
          const id = await session.request("content.openRead", [reference], options);
          try {
            while (true) {
              const chunk = await session.request("content.next", [id], options);
              if (chunk === null) return;
              yield chunk;
            }
          } finally {
            void session.request("content.cancel", [id]).catch(() => void 0);
          }
        }
      };
    },
    putBytes: (bytes, options) => putContentBytes(this.content, bytes, options),
    readBytes: (reference, options) => readContentBytes(this.content, reference, options),
    retain: (reference, options = {}) => this.request("content.retain", [reference], options),
    retention: (reference, options = {}) => this.request("content.retention", [reference], options),
    retained: (reference) => this.request("content.retained", [reference]),
    discard: (reference) => this.request("content.discard", [reference]),
    putBlob: async (bytes, options = {}) => {
      if (!(bytes instanceof Uint8Array) || bytes.byteLength > MAX_BLOB_BYTES) throw new Error("CONTENT_RANGE_INVALID");
      const reqOptions = options.signal === void 0 ? {} : { signal: options.signal };
      const id = await this.request("content.blobOpenWrite", [bytes.byteLength], reqOptions);
      try {
        for (let offset = 0; offset < bytes.byteLength; offset += CONTENT_CHUNK_BYTES) {
          const chunk = Uint8Array.from(bytes.subarray(offset, Math.min(bytes.byteLength, offset + CONTENT_CHUNK_BYTES)));
          await this.request("content.blobWriteChunk", [id, offset / CONTENT_CHUNK_BYTES, chunk], reqOptions);
        }
        return await this.request("content.blobCommitWrite", [id], reqOptions);
      } catch (error) {
        void this.request("content.blobAbortWrite", [id]).catch(() => void 0);
        throw error;
      }
    },
    getBlob: async (hash, options = {}) => {
      const { signal, ...rest } = options;
      const reqOptions = signal === void 0 ? {} : { signal };
      const opened = await this.request("content.blobOpenRead", [hash, rest], reqOptions);
      if (opened === null) return null;
      const result = new Uint8Array(opened.bytes);
      let offset = 0;
      try {
        while (offset < opened.bytes) {
          const chunk = await this.request("content.blobNextChunk", [opened.id], reqOptions);
          if (chunk === null) break;
          if (!(chunk instanceof Uint8Array) || chunk.byteLength === 0 || offset + chunk.byteLength > opened.bytes) throw new Error("CONTENT_CHUNK_SIZE_INVALID");
          result.set(chunk, offset);
          offset += chunk.byteLength;
        }
        if (offset !== opened.bytes) throw new Error("CONTENT_INCOMPLETE");
        return result;
      } finally {
        void this.request("content.blobCloseRead", [opened.id]).catch(() => void 0);
      }
    },
    hasBlob: (hash) => this.request("content.hasBlob", [hash]),
    deleteBlob: (hash) => this.request("content.deleteBlob", [hash]),
    put: async (bytes, options = {}) => {
      const visibility = options.visibility ?? "private";
      const mediaType = options.mediaType ?? "application/octet-stream";
      if (visibility === "public") {
        const info = await this.content.putBlob(bytes, options.signal === void 0 ? {} : { signal: options.signal });
        return { profile: "chronolog-blob-v2", visibility: "public", hash: info.hash, bytes: info.bytes, mediaType };
      }
      if (options.deduplicate === true) {
        if (!(bytes instanceof Uint8Array) || bytes.byteLength > MAX_BLOB_BYTES) throw new Error("CONTENT_RANGE_INVALID");
        const reqOptions = options.signal === void 0 ? {} : { signal: options.signal };
        const id = await this.request("content.blobOpenWrite", [bytes.byteLength], reqOptions);
        try {
          for (let offset = 0; offset < bytes.byteLength; offset += CONTENT_CHUNK_BYTES) {
            const chunk = Uint8Array.from(bytes.subarray(offset, Math.min(bytes.byteLength, offset + CONTENT_CHUNK_BYTES)));
            await this.request("content.blobWriteChunk", [id, offset / CONTENT_CHUNK_BYTES, chunk], reqOptions);
          }
          return await this.request("content.blobCommitPrivate", [id, mediaType], reqOptions);
        } catch (error) {
          void this.request("content.blobAbortWrite", [id]).catch(() => void 0);
          throw error;
        }
      }
      return this.content.putBytes(bytes, { mediaType, ...options.signal === void 0 ? {} : { signal: options.signal } });
    },
    get: async (target, options = {}) => {
      if (typeof target === "string") return this.content.getBlob(target, options);
      if (isPublicBlobReference(target)) {
        return this.content.getBlob(target.hash, { ...options, expectedBytes: options.expectedBytes ?? target.bytes });
      }
      if (isPrivateContentReference(target)) {
        try {
          return await this.content.readBytes(target, {
            maxBytes: options.maxBytes ?? target.bytes,
            ...options.signal === void 0 ? {} : { signal: options.signal }
          });
        } catch (error) {
          if (error instanceof Error && (error.message === "CONTENT_MANIFEST_MISSING" || error.message === "CONTENT_CHUNK_MISSING")) {
            return null;
          }
          throw error;
        }
      }
      throw new Error("CONTENT_REFERENCE_INVALID");
    }
  };
  #detach(error) {
    if (this.#attachmentState === "detached") return;
    this.#attachmentState = "detached";
    clearInterval(this.#heartbeat);
    this.#lifetime.abort(error);
    for (const pending of this.#pending.values()) {
      clearTimeout(pending.timer);
      pending.cleanup();
      pending.reject(error);
    }
    this.#pending.clear();
    this.#endpoint.removeEventListener("message", this.#receive);
    const physical = this.#endpoint;
    physical.removeEventListener("close", this.#physicalClose);
    physical.removeEventListener("messageerror", this.#physicalClose);
    physical.off?.("close", this.#physicalClose);
    physical.off?.("messageerror", this.#physicalClose);
    this.#status = { ...this.#status, canAuthor: false, phase: "closed", database: "closed" };
    for (const listener of this.#statuses) {
      try {
        listener(this.status);
      } catch {
      }
    }
  }
  async close() {
    if (this.#attachmentState === "detached") return;
    try {
      await this.request("close", [], { timeoutMs: 2e3 });
    } catch {
    }
    this.#detach(new Error("ENDPOINT_CLOSED"));
    this.#endpoint.close?.();
  }
};
async function connectApplicationOwner(endpoint, options) {
  endpoint.start?.();
  const session = new WorkerApplicationSession(endpoint);
  try {
    await session.initialize(options);
    return session;
  } catch (error) {
    await session.close();
    throw error;
  }
}

// packages/peer-session/src/browser-tab-owner.ts
var TAB_OWNER_PROTOCOL = "chronolog/tab-owner/v1";
function requestPersistentStorage() {
  const nav = globalThis.navigator;
  const storage = nav?.storage;
  if (typeof storage?.persist !== "function") return Promise.resolve(null);
  return (async () => {
    try {
      if (typeof storage.persisted === "function" && await storage.persisted()) return true;
      return await storage.persist();
    } catch {
      return false;
    }
  })();
}
function coordinateNetworkLeader(profileId, options) {
  const ns = options.namespace ?? "chronolog";
  const tabId = options.tabId ?? (typeof crypto.randomUUID === "function" ? crypto.randomUUID() : String(Math.random()));
  const hiddenGraceMs = options.hiddenGraceMs ?? 1e4;
  const pingTimeoutMs = options.pingTimeoutMs ?? 500;
  const nav = globalThis.navigator;
  const locks = nav?.locks;
  const doc = globalThis.document;
  if (typeof locks?.request !== "function") {
    options.onRole(true);
    return () => {
    };
  }
  const lockName = `${ns}:net:${profileId}`;
  const channel = typeof globalThis.BroadcastChannel === "function" ? new BroadcastChannel(`${ns}:net:${profileId}`) : null;
  let stopped = false;
  let holding = false;
  let releaseHeld = null;
  let hiddenTimer;
  let trying = false;
  const isVisible = () => doc === void 0 || doc.visibilityState !== "hidden";
  const setHolding = (next) => {
    if (holding === next) return;
    holding = next;
    try {
      options.onRole(next);
    } catch {
    }
  };
  const dropLeadership = () => {
    if (hiddenTimer !== void 0) {
      clearTimeout(hiddenTimer);
      hiddenTimer = void 0;
    }
    if (releaseHeld === null) return;
    const rel = releaseHeld;
    releaseHeld = null;
    setHolding(false);
    rel();
    try {
      channel?.postMessage({ type: "net-released", from: tabId });
    } catch {
    }
  };
  const pingHolder = () => new Promise((resolve) => {
    if (channel === null) {
      resolve(null);
      return;
    }
    const id = typeof crypto.randomUUID === "function" ? crypto.randomUUID() : String(Math.random());
    const timer = setTimeout(() => {
      channel.removeEventListener("message", onPong);
      resolve(null);
    }, pingTimeoutMs);
    const onPong = (event) => {
      const data = event.data;
      if (data?.type !== "net-pong" || data.id !== id) return;
      clearTimeout(timer);
      channel.removeEventListener("message", onPong);
      resolve({ visible: Boolean(data.visible) });
    };
    channel.addEventListener("message", onPong);
    try {
      channel.postMessage({ type: "net-ping", id, from: tabId });
    } catch {
      clearTimeout(timer);
      channel.removeEventListener("message", onPong);
      resolve(null);
    }
  });
  const holdLock = (lockOpts) => new Promise((resolve) => {
    let resolved = false;
    const finish = (acquired) => {
      if (!resolved) {
        resolved = true;
        resolve(acquired);
      }
    };
    void locks.request(lockName, lockOpts, (lock) => {
      if (!lock || stopped || options.signal?.aborted) {
        finish(false);
        return Promise.resolve();
      }
      return new Promise((release) => {
        releaseHeld = release;
        setHolding(true);
        finish(true);
      });
    }).catch(() => {
      if (releaseHeld !== null) {
        releaseHeld = null;
        setHolding(false);
      }
      finish(false);
    });
  });
  const tryAcquire = async () => {
    if (stopped || options.signal?.aborted || holding || trying) return;
    trying = true;
    try {
      if (await holdLock({ ifAvailable: true })) return;
      if (!isVisible() || stopped || options.signal?.aborted) return;
      const holder = await pingHolder();
      if (stopped || options.signal?.aborted || holding) return;
      if (holder === null || !holder.visible) {
        await holdLock({ steal: true });
      }
    } finally {
      trying = false;
    }
  };
  const onChannel = (event) => {
    const data = event.data;
    if (stopped || data === null || data.from === tabId) return;
    if (data.type === "net-ping" && holding) {
      try {
        channel?.postMessage({ type: "net-pong", id: data.id, from: tabId, visible: isVisible() });
      } catch {
      }
    } else if (data.type === "net-released" && !holding && isVisible()) {
      void tryAcquire();
    }
  };
  channel?.addEventListener("message", onChannel);
  const onVisibility = () => {
    if (stopped) return;
    if (isVisible()) {
      if (hiddenTimer !== void 0) {
        clearTimeout(hiddenTimer);
        hiddenTimer = void 0;
      }
      if (!holding) void tryAcquire();
    } else if (holding) {
      if (hiddenTimer !== void 0) clearTimeout(hiddenTimer);
      hiddenTimer = setTimeout(() => {
        hiddenTimer = void 0;
        if (!isVisible()) dropLeadership();
      }, hiddenGraceMs);
    }
  };
  const onFreeze = () => dropLeadership();
  const onFocus = () => {
    if (!stopped && !holding && isVisible()) void tryAcquire();
  };
  doc?.addEventListener?.("visibilitychange", onVisibility);
  doc?.addEventListener?.("freeze", onFreeze);
  doc?.addEventListener?.("resume", onFocus);
  globalThis.addEventListener?.("focus", onFocus);
  globalThis.addEventListener?.("pagehide", onFreeze);
  void tryAcquire();
  const stop = () => {
    if (stopped) return;
    stopped = true;
    if (hiddenTimer !== void 0) {
      clearTimeout(hiddenTimer);
      hiddenTimer = void 0;
    }
    doc?.removeEventListener?.("visibilitychange", onVisibility);
    doc?.removeEventListener?.("freeze", onFreeze);
    doc?.removeEventListener?.("resume", onFocus);
    globalThis.removeEventListener?.("focus", onFocus);
    globalThis.removeEventListener?.("pagehide", onFreeze);
    channel?.removeEventListener("message", onChannel);
    dropLeadership();
    channel?.close();
  };
  options.signal?.addEventListener("abort", stop, { once: true });
  return stop;
}
async function connectTabWorkerOwner(options) {
  if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/u.test(options.profileId)) {
    throw new SessionError("INVALID_PROFILE", "Invalid browser owner profileId");
  }
  if (typeof globalThis.Worker !== "function") {
    throw new SessionError("OWNER_CAPABILITY_UNAVAILABLE", "Dedicated Workers are required for browser session ownership");
  }
  const protocol = options.protocol ?? TAB_OWNER_PROTOCOL;
  const timeoutMs = options.timeoutMs ?? 3e4;
  const url = new URL(String(options.workerUrl), globalThis.location?.href);
  if (globalThis.location?.origin && url.origin !== globalThis.location.origin) {
    throw new SessionError("OWNER_ORIGIN_MISMATCH", "Session worker URL must share origin with page");
  }
  void requestPersistentStorage();
  const worker = new Worker(url, { type: "module", name: `chronolog-owner:${options.profileId}` });
  const channel = new MessageChannel();
  const bootId = typeof crypto.randomUUID === "function" ? crypto.randomUUID() : String(Math.random());
  const waitForReply = (predicate) => new Promise((resolve, reject) => {
    const finish = (err, val) => {
      clearTimeout(timer);
      worker.removeEventListener("message", onMsg);
      worker.removeEventListener("error", onErr);
      options.signal?.removeEventListener("abort", onAbort);
      if (err !== null && err !== void 0) reject(err instanceof Error ? err : new Error(typeof err === "string" ? err : "WORKER_ERROR"));
      else resolve(val);
    };
    const onMsg = (ev) => {
      const data = ev.data;
      if (data?.protocol !== protocol) return;
      if (data.type === "failure") {
        const code = typeof data.code === "string" ? data.code : "OWNER_UNREACHABLE";
        const message = typeof data.message === "string" ? data.message : "Worker failed";
        finish(new SessionError(code, message));
      } else if (predicate(data)) {
        finish(null, data);
      }
    };
    const onErr = (ev) => finish(new SessionError("WORKER_LOAD_FAILED", ev.message || "Worker failed to load"));
    const onAbort = () => finish(options.signal?.reason ?? new Error("ABORTED"));
    const timer = setTimeout(() => finish(new SessionError("BOOT_TIMEOUT", "Session worker timed out")), timeoutMs);
    worker.addEventListener("message", onMsg);
    worker.addEventListener("error", onErr);
    options.signal?.addEventListener("abort", onAbort, { once: true });
  });
  try {
    const readyPromise = waitForReply((d) => d.type === "ready" && d.id === bootId);
    worker.postMessage(
      { protocol, type: "boot", id: bootId, profileId: options.profileId, configuration: options.configuration },
      [channel.port2]
    );
    const ready = await readyPromise;
    channel.port1.start();
    const session = await connectApplicationOwner(channel.port1, {
      applicationId: options.applicationId,
      ...options.context === void 0 ? {} : { context: options.context }
    });
    const stopLeader = coordinateNetworkLeader(options.profileId, {
      ...options.namespace === void 0 ? {} : { namespace: options.namespace },
      ...options.signal === void 0 ? {} : { signal: options.signal },
      onRole: (active) => {
        try {
          worker.postMessage({ protocol, type: "network-role", active });
        } catch {
        }
      }
    });
    let closed = false;
    return {
      session,
      worker,
      ownerInstanceId: ready.ownerInstanceId,
      async close() {
        if (closed) return;
        closed = true;
        stopLeader();
        try {
          await session.detach();
        } catch {
        }
        try {
          channel.port1.close();
        } catch {
        }
        try {
          const retireId = typeof crypto.randomUUID === "function" ? crypto.randomUUID() : String(Math.random());
          const retired = waitForReply((d) => d.type === "retired" && d.id === retireId).catch(() => {
          });
          worker.postMessage({ protocol, type: "retire", id: retireId, profileId: options.profileId });
          await Promise.race([retired, new Promise((r) => setTimeout(r, 1e3))]);
        } catch {
        }
        worker.terminate();
      }
    };
  } catch (err) {
    channel.port1.close();
    worker.terminate();
    throw err;
  }
}

export {
  WorkerApplicationOperation,
  WorkerApplicationSession,
  connectApplicationOwner,
  TAB_OWNER_PROTOCOL,
  requestPersistentStorage,
  coordinateNetworkLeader,
  connectTabWorkerOwner
};
