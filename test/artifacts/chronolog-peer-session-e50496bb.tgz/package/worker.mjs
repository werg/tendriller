import {
  createApplicationOwner,
  createApplicationSession
} from "./chunks/chunk-DE2YGMLI.mjs";
import {
  TAB_OWNER_PROTOCOL
} from "./chunks/chunk-YFUQ2VBA.mjs";
import "./chunks/chunk-WUJDLR5N.mjs";
import {
  openWorkerWebRtcConnection
} from "./chunks/chunk-VCWFJEFI.mjs";
import "./chunks/chunk-VUH2GHIC.mjs";
import "./chunks/chunk-VHH47WOJ.mjs";
import {
  openApplicationDevice
} from "./chunks/chunk-SJBUGLEN.mjs";
import "./chunks/chunk-XVIRXFJR.mjs";
import "./chunks/chunk-RFZQY6CX.mjs";
import "./chunks/chunk-O7NXWMZY.mjs";
import "./chunks/chunk-3YYBTMHD.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-OWL5GQ66.mjs";
import "./chunks/chunk-XIVHZVOM.mjs";
import "./chunks/chunk-VRR2HFJY.mjs";

// packages/peer-session/src/browser-metadata.ts
var TABLE = "metadata";
var MAX_BYTES = 16 * 1024 * 1024;
var BrowserMetadataStore = class _BrowserMetadataStore {
  #database;
  #closed = false;
  constructor(database) {
    this.#database = database;
    database.onversionchange = () => {
      this.close();
    };
  }
  static open(name) {
    if (typeof indexedDB === "undefined") return Promise.reject(new Error("BROWSER_IDENTITY_STORAGE_UNAVAILABLE"));
    return new Promise((resolve, reject) => {
      let failed = false;
      const request = indexedDB.open(`chronolog-metadata:${name}`, 1);
      request.onupgradeneeded = () => {
        request.result.createObjectStore(TABLE);
      };
      request.onerror = () => {
        reject(request.error ?? new Error("BROWSER_IDENTITY_STORAGE_UNAVAILABLE"));
      };
      request.onblocked = () => {
        failed = true;
        reject(new Error("BROWSER_IDENTITY_STORAGE_BLOCKED"));
      };
      request.onsuccess = () => {
        if (failed) request.result.close();
        else resolve(new _BrowserMetadataStore(request.result));
      };
    });
  }
  get(key) {
    return this.#transaction("readonly", (table) => {
      const request = table.get(key);
      return () => {
        if (request.result === void 0) return null;
        if (!(request.result instanceof Uint8Array) || request.result.length > MAX_BYTES) throw new Error("BROWSER_METADATA_INVALID");
        return request.result.slice();
      };
    });
  }
  put(key, value) {
    this.#validate(key, value);
    const captured = value.slice();
    return this.#transaction("readwrite", (table) => {
      table.put(captured, key);
      return () => void 0;
    });
  }
  initialize(input) {
    const entries = input.map(({ key, value }) => {
      this.#validate(key, value);
      return { key, value: value.slice() };
    });
    if (entries.length === 0 || entries.length > 8 || new Set(entries.map((entry) => entry.key)).size !== entries.length) {
      return Promise.reject(new Error("BROWSER_METADATA_INITIALIZATION_INVALID"));
    }
    return this.#transaction("readwrite", (table) => {
      let remaining = entries.length, present = false;
      for (const entry of entries) {
        const request = table.get(entry.key);
        request.onsuccess = () => {
          present ||= request.result !== void 0;
          if (--remaining === 0 && !present) for (const candidate of entries) table.add(candidate.value, candidate.key);
        };
      }
      return () => void 0;
    });
  }
  compareAndSwap(key, expected, value) {
    this.#validate(key, value);
    const before = expected?.slice() ?? null, after = value.slice();
    return this.#transaction("readwrite", (table) => {
      let written = false;
      const request = table.get(key);
      request.onsuccess = () => {
        const current = request.result;
        if (before === null ? current === void 0 : current instanceof Uint8Array && before.length === current.length && before.every((byte, index) => byte === current[index])) {
          table.put(after, key);
          written = true;
        }
      };
      return () => written;
    });
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#database.close();
    }
  }
  #validate(key, value) {
    if (!key || key.length > 4096 || value.length > MAX_BYTES) throw new Error("BROWSER_METADATA_LIMIT");
  }
  #transaction(mode, enqueue) {
    if (this.#closed) return Promise.reject(new Error("BROWSER_METADATA_CLOSED"));
    return new Promise((resolve, reject) => {
      const transaction = mode === "readonly" ? this.#database.transaction(TABLE, mode) : this.#database.transaction(TABLE, mode, { durability: "strict" });
      const value = enqueue(transaction.objectStore(TABLE));
      transaction.oncomplete = () => {
        try {
          resolve(value());
        } catch (error) {
          reject(error);
        }
      };
      transaction.onabort = () => {
        reject(transaction.error ?? new Error("BROWSER_METADATA_ABORTED"));
      };
      transaction.onerror = () => {
      };
    });
  }
};

// packages/peer-session/src/browser-device.ts
async function openBrowserDevice(options) {
  if (typeof document !== "undefined") throw new Error("BROWSER_PEER_WORKER_REQUIRED");
  if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/u.test(options.name)) throw new Error("BROWSER_STORAGE_NAME_INVALID");
  const metadata = await BrowserMetadataStore.open(options.name);
  try {
    return await openApplicationDevice({
      store: metadata,
      ...options.create === void 0 ? {} : { create: options.create },
      async openStorage() {
        const { IndexedDbBytesStore } = await import("./chunks/indexeddb-bytes-store-VG6JV3XA.mjs");
        const store = await IndexedDbBytesStore.open(options.name, { create: true });
        return {
          store,
          close: () => store.close()
        };
      },
      close: () => {
        metadata.close();
      }
    });
  } catch (error) {
    metadata.close();
    throw error;
  }
}

// packages/peer-session/src/worker-tab-owner.ts
function serveTabWorkerOwner(options) {
  const scope = options.scope ?? globalThis;
  const protocol = options.protocol ?? TAB_OWNER_PROTOCOL;
  const ns = options.namespace ?? "chronolog";
  const lifetime = new AbortController();
  const workerId = typeof crypto.randomUUID === "function" ? crypto.randomUUID() : String(Math.random());
  let profileId = options.profileId;
  let openSession = options.openSession;
  let ownerOptions = options.ownerOptions ?? {};
  let owner;
  let owned;
  let opening;
  let appPort;
  let syncChannel;
  let stopFacts = () => {
  };
  let closing;
  let closed = false;
  let syncingFromStore = false;
  let latestNetworkActive = null;
  const post = (value) => {
    try {
      scope.postMessage(value);
    } catch {
    }
  };
  let configPromise;
  const resolveConfig = (configuration) => {
    if (configPromise !== void 0) return configPromise;
    configPromise = Promise.resolve().then(async () => {
      if (options.load !== void 0) {
        const loaded = await options.load({ signal: lifetime.signal, configuration });
        profileId = loaded.profileId;
        openSession = loaded.openSession;
        ownerOptions = loaded.ownerOptions ?? {};
      }
      if (profileId === void 0 || !/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/u.test(profileId) || openSession === void 0) {
        throw new Error("OWNER_CONFIGURATION_INVALID");
      }
    });
    void configPromise.catch(() => {
    });
    return configPromise;
  };
  if (options.load === void 0) void resolveConfig(void 0);
  const ensureOpen = (configuration, transferredPort) => {
    if (opening !== void 0) return opening;
    opening = (async () => {
      await resolveConfig(configuration);
      lifetime.signal.throwIfAborted();
      try {
        owned = await openSession({
          signal: lifetime.signal,
          initialNetworkActive: latestNetworkActive !== false
        });
        lifetime.signal.throwIfAborted();
        owner = createApplicationOwner(
          owned.session,
          owned.extensions !== void 0 ? { ...ownerOptions, extensions: owned.extensions } : ownerOptions
        );
        if (transferredPort !== null) {
          appPort = transferredPort;
          appPort.start();
          owner.attach(appPort);
        }
        if (typeof globalThis.BroadcastChannel === "function" && profileId !== void 0) {
          syncChannel = new BroadcastChannel(`${ns}:sync:${profileId}`);
          syncChannel.addEventListener("message", (event) => {
            const data = event.data;
            if (closed || data === null || data.sender === workerId || data.type !== "facts-updated") return;
            syncingFromStore = true;
            void owned?.session.syncFromStore().catch(() => {
            }).finally(() => {
              syncingFromStore = false;
            });
          });
          stopFacts = owned.session.onFacts(() => {
            if (closed || syncingFromStore) return;
            try {
              syncChannel?.postMessage({ type: "facts-updated", sender: workerId });
            } catch {
            }
          });
        }
        if (latestNetworkActive !== null) {
          try {
            owned.setNetworkActive?.(latestNetworkActive);
          } catch {
          }
        }
        owned.session.signal.addEventListener("abort", () => {
          void close().catch(() => {
          });
        }, { once: true });
        if (owned.session.signal.aborted) void close().catch(() => {
        });
        return owner;
      } catch (err) {
        try {
          await owned?.session.close();
        } finally {
          await owned?.close?.();
        }
        throw err;
      }
    })().catch((err) => {
      opening = void 0;
      owned = void 0;
      owner = void 0;
      throw err;
    });
    return opening;
  };
  const handleControl = async (data, ports) => {
    if (data.type === "boot") {
      try {
        await resolveConfig(data.configuration);
        if (data.profileId !== profileId) throw new Error("INVALID_PROFILE");
        const activeOwner = await ensureOpen(data.configuration, ports[0] ?? null);
        post({ protocol, type: "ready", id: data.id, profileId, ownerInstanceId: activeOwner.ownerInstanceId });
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        post({ protocol, type: "failure", id: data.id, code: msg, message: msg });
      }
      return;
    }
    if (data.type === "network-role") {
      latestNetworkActive = Boolean(data.active);
      try {
        owned?.setNetworkActive?.(latestNetworkActive);
      } catch {
      }
      return;
    }
    if (data.type === "retire") {
      try {
        await close();
      } finally {
        post({ protocol, type: "retired", id: data.id, profileId });
      }
    }
  };
  const onMessage = (event) => {
    const me = event;
    const data = me.data;
    if (closed || data === null || data.protocol !== protocol) return;
    void handleControl(data, me.ports ?? []);
  };
  scope.addEventListener("message", onMessage);
  const close = () => {
    if (closing !== void 0) return closing;
    closed = true;
    lifetime.abort(new Error("OWNER_CLOSED"));
    scope.removeEventListener("message", onMessage);
    closing = (async () => {
      try {
        stopFacts();
      } catch {
      }
      try {
        syncChannel?.close();
      } catch {
      }
      try {
        appPort?.close();
      } catch {
      }
      try {
        await owner?.close();
      } catch {
      }
      try {
        await owned?.close?.();
      } catch {
      }
      try {
        await owned?.session.close();
      } catch {
      }
      owner = void 0;
      owned = void 0;
      syncChannel = void 0;
      appPort = void 0;
    })();
    return closing;
  };
  return Object.freeze({
    get owner() {
      return owner;
    },
    close
  });
}

// packages/peer-session/src/worker.ts
async function probeBrowserCapabilities(...args) {
  return (await import("./chunks/browser-capabilities-DITUGEI7.mjs")).probeBrowserCapabilities(...args);
}
export {
  createApplicationOwner,
  createApplicationSession,
  openBrowserDevice,
  openWorkerWebRtcConnection,
  probeBrowserCapabilities,
  serveTabWorkerOwner
};
