import type { JsonValue, OperationAssumptionsConfig, TopicUpdate } from '../../protocol/src/index.js';
import type { ApplicationOperation } from './operation.js';
import type { ApplicationSession } from './session.js';
export interface GuardedSqlPrecondition {
    readonly kind?: 'based_on_row' | 'row_matches';
    readonly table?: string;
    readonly where?: Readonly<Record<string, JsonValue>>;
    readonly lastOpId?: string | null;
    readonly expect?: JsonValue;
    readonly sql?: string;
    readonly params?: readonly JsonValue[];
    readonly code?: string;
}
export interface GuardedTxOptions {
    readonly defaultSqlTopic?: string;
    readonly onFailed?: 'reject' | 'record_conflict';
}
export interface GuardedTx {
    /**
     * Read a single SQL row and automatically capture an optimistic concurrency precondition:
     * - If the table has a `_last_op_id` column (via `stampRowOp`), records `{ kind: 'based_on_row', table, where, lastOpId }`.
     * - Otherwise records `{ kind: 'row_matches', table, where, expect }` for the read columns (or `{ kind: 'based_on_row', lastOpId: null }` when absent).
     */
    readRow(table: string, where: Readonly<Record<string, JsonValue>>, options?: {
        readonly topic?: string;
        readonly columns?: readonly string[];
        readonly code?: string;
    }): Promise<Record<string, JsonValue> | null>;
    /**
     * Execute a read-only SQL query and capture an exact precondition on its result (`rows`, `count`, or `exists`).
     */
    readSql(sql: string, params?: readonly JsonValue[], options?: {
        readonly topic?: string;
        readonly mode?: 'rows' | 'count' | 'exists';
        readonly code?: string;
    }): Promise<{
        readonly columns: readonly string[];
        readonly rows: readonly (readonly JsonValue[])[];
    }>;
    /**
     * Execute `session.query(topic, query)` and capture a kernel-level `query_match` assumption.
     */
    readQuery(topic: string, query?: JsonValue): Promise<JsonValue>;
    /**
     * Capture a kernel-level `topic_revision` assumption asserting `topic` has not been modified since now.
     */
    requireTopicUnchanged(topic: string): this;
    /**
     * Capture a kernel-level `author_last_op` assumption asserting this author's causal history chain
     * matches their latest accepted/local op (100% offline-friendly; chains across sequential local writes).
     */
    requireOwnHistory(author?: string): this;
    /**
     * Capture a kernel-level `op_accepted` / `op_rejected` / `op_present` assumption.
     */
    requireOp(opId: string, kind?: 'op_accepted' | 'op_rejected' | 'op_present'): this;
    /** Add an explicit SQL precondition (evaluated before DML on `topic`). */
    addSqlPrecondition(precondition: GuardedSqlPrecondition, topic?: string): this;
    /** Add an explicit SQL postcondition (evaluated after DML, before `db.commit()`). */
    addSqlPostcondition(postcondition: GuardedSqlPrecondition, topic?: string): this;
    /** Inspect captured kernel-level assumptions. */
    assumptions(options?: {
        readonly onFailed?: 'reject' | 'record_conflict';
    }): OperationAssumptionsConfig | undefined;
    /** Inspect captured SQL preconditions for `topic`. */
    sqlPreconditions(topic?: string): readonly GuardedSqlPrecondition[];
    /** Inspect captured SQL postconditions for `topic`. */
    sqlPostconditions(topic?: string): readonly GuardedSqlPrecondition[];
    /**
     * Submit a guarded operation combining all captured kernel assumptions and SQL pre/post conditions.
     * Any `updates` targeting a SQL topic automatically receive the captured `preconditions` and `postconditions`.
     */
    submit(input: {
        readonly updates: readonly TopicUpdate[];
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
        readonly visibility?: 'public' | 'encrypted';
        readonly onFailed?: 'reject' | 'record_conflict';
        readonly awaitMaterialized?: boolean;
    }): Promise<ApplicationOperation>;
}
/**
 * Create an explicit, scoped Optimistic Concurrency Control (OCC) transaction builder over an
 * `ApplicationSession`. Unlike implicit global query tracking, only reads performed through this
 * `GuardedTx` instance are added to the operation's signed read-set (`OperationAssumptions` +
 * `chronolog/sql` preconditions/postconditions), avoiding phantom conflicts with UI views.
 */
export declare function createGuardedTx(session: ApplicationSession, options?: GuardedTxOptions): GuardedTx;
