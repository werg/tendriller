import type { SqliteBuiltinDriver } from '../../materializer/src/index.js';
export declare const SQLITE_CAS_BUILTIN_ID = "sqlite-cas@1#sha256-4b2ef04a5c2f285d7df273e3187665d17ade145075f9f5b4816ec1bab0a0b241";
export interface CreateSqliteCasDriverOptions {
    /** Optional static pre-compiled WebAssembly.Module (for Cloudflare Workers / strict CSP). */
    readonly wasmModule?: WebAssembly.Module;
}
export declare function createSqliteCasDriver(options?: CreateSqliteCasDriverOptions): Promise<SqliteBuiltinDriver>;
