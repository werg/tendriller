/**
 * Extended audited standard library modules seeded into CAS as `chronolog/*`:
 * - `chronolog/finality-predicates`: programmable state-defined finality / admission predicates
 * - `chronolog/guards`: composable pre/post condition helpers + OCC/causal-chain guards
 * - `chronolog/quotas`: deterministic per-author rate limits and quotas driven by tx.authorTimestampMs
 * - `chronolog/queue`: deterministic job queue with time-based leases and dead-letter handling
 * - `chronolog/votes`: weighted voting, quorum polls, ranked/approval tallies, timelocked close
 * - `chronolog/schema`: deterministic JSON schema validator and versioned state migrations
 * - `chronolog/audit`: hash-chained tamper-evident audit trail reducer
 */
export declare const STD_FINALITY_PREDICATES_SOURCE: string;
export declare const STD_GUARDS_SOURCE: string;
export declare const STD_QUOTAS_SOURCE: string;
export declare const STD_QUEUE_SOURCE: string;
export declare const STD_VOTES_SOURCE: string;
export declare const STD_SCHEMA_SOURCE: string;
export declare const STD_AUDIT_SOURCE: string;
