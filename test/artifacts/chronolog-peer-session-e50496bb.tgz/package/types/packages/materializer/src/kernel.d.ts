import { type LogGenesis, type JsonValue, type OperationCore } from '../../protocol/src/index.js';
import type { ContentAddressedStore } from '../../records/src/index.js';
import type { KernelMaterializedCache, KernelOperationOutcome } from './materialized-cache.js';
export type { EmittedKernelEvent, KernelMaterializedCache, KernelOperationOutcome } from './materialized-cache.js';
import { QuickJsSandbox, type QuickJsSandboxOptions } from './quickjs-sandbox.js';
export interface KernelOperationInput {
    readonly opId: Uint8Array;
    readonly core: OperationCore;
    /** Caller already verified opId === operationIdDigest(core); skips O(N) CBOR+SHA-256 re-verification on every materialize(). */
    readonly verified?: boolean;
}
export interface KernelRevision {
    readonly stateRoot: string;
    readonly historyDigest: string;
    readonly digest: string;
    readonly view: 'local' | 'final';
    readonly orderLength: number;
}
/**
 * Cheap positional snapshot. Topic values are immutable (never mutated in place), so a snapshot
 * is a shallow copy of the topic record plus the lengths of the append-only seen/outcome logs.
 */
export interface KernelSnapshot {
    readonly topics: Readonly<Record<string, JsonValue>>;
    readonly topicHashes: ReadonlyMap<string, string>;
    readonly topicLastOpIds: ReadonlyMap<string, string>;
    readonly authorLastOpIds: ReadonlyMap<string, string>;
    readonly publicAuthorLastOpIds: ReadonlyMap<string, string>;
    readonly seenLength: number;
    readonly historyDigest: string;
    readonly stateRoot: string;
    readonly orderLength: number;
}
export interface KernelMaterializeResult {
    readonly revision: KernelRevision;
    readonly outcomes: readonly KernelOperationOutcome[];
    /** Outcomes before this index are unchanged (same objects) since the previous materialize. */
    readonly replayedFrom?: number;
    readonly pendingDependencies: readonly string[];
    readonly skippedOpIds: readonly string[];
}
export interface TopicKernelOptions extends QuickJsSandboxOptions {
    readonly genesis: LogGenesis | Uint8Array;
    readonly cas: ContentAddressedStore;
    /** When true (e.g. blind Cloudflare Worker), only public-control operations are replayed. */
    readonly blindHostMode?: boolean;
    readonly snapshotInterval?: number;
    readonly policyContextDigest?: string;
}
/**
 * Chronolog v2 Topic Kernel & Suffix-Replay Engine.
 * - Flat timestamp-ordered operation set: (authorTimestampMs, author, opId)
 * - Strict two-way public/encrypted control partition (blind-host equivalent)
 * - Scoped idempotency (visibility, author, operationId) in authenticated seenOpsRoot
 * - Rolling historyDigest + stateRoot + revision.digest
 * - Fresh QuickJSContext per call + uncatchable MissingDependency suspension
 */
export declare class TopicKernel {
    #private;
    readonly genesis: LogGenesis;
    readonly genesisBytes: Uint8Array;
    readonly logId: Uint8Array;
    readonly logIdHex: string;
    readonly cas: ContentAddressedStore;
    readonly sandbox: QuickJsSandbox;
    readonly blindHostMode: boolean;
    constructor(options: TopicKernelOptions);
    get topics(): Readonly<Record<string, JsonValue>>;
    /** CAS root of the committed idempotency set; computed lazily (O(N log N)) and cached per commit. */
    get seenOpsRoot(): string;
    get disposed(): boolean;
    /**
     * Release this kernel's VM runtimes, snapshots, logs and caches. Idempotent. Committed revision
     * fields stay readable; materialize/query/describe throw SANDBOX_DISPOSED afterwards.
     */
    dispose(): void;
    /** Durably persist the committed idempotency set node and return its root (call before exporting state). */
    commitSeenOpsRoot(): Promise<string>;
    /** Content hash of a committed topic state (or undefined when absent). */
    topicHash(name: string): string | undefined;
    snapshot(): {
        readonly topics: Readonly<Record<string, JsonValue>>;
        readonly seenOpsRoot: string;
        readonly historyDigest: string;
        readonly stateRoot: string;
    };
    topic(name: string): JsonValue | null;
    opOutcome(opId: string): 'accepted' | 'rejected' | null;
    topicLastOpId(topic: string): string | null;
    authorLastOpId(author: string, options?: {
        readonly publicOnly?: boolean;
    }): string | null;
    get outcomes(): readonly KernelOperationOutcome[];
    /** Committed outcome for one op in O(1) (falls back to a scan mid-replay). */
    outcomeOf(opId: string): KernelOperationOutcome | undefined;
    /** Committed outcome list without copying (replaced, never mutated, on each commit). */
    get materializedOutcomes(): readonly KernelOperationOutcome[];
    get pendingDependencies(): readonly string[];
    revision(view?: 'local' | 'final', policyContextDigest?: string): KernelRevision;
    get frontierOrderLength(): number;
    get frontierMaxTimestampMs(): bigint;
    hasFrontierOp(opId: string): boolean;
    /** Collect all CAS root hashes reachable from current state + retained suffix snapshots + historical $reducers (for local GC). */
    gcRoots(): Set<string>;
    get cacheRestores(): number;
    /**
     * Export the committed state for instant cold open (local cache) or snapshot bootstrap.
     * `suffix: false` omits the replayable suffix (order ids, outcomes and events) and folds it
     * into the frontier, giving a bundle whose size is O(state + op count x 32 bytes).
     * Outcome/event objects are immutable and shared, not cloned.
     */
    exportMaterializedCache(options?: {
        readonly suffix?: boolean;
    }): KernelMaterializedCache;
    /**
     * Restore materialized state directly from a previously exported cache if:
     * - logId, blindHostMode, and recomputed stateRoot match exactly,
     * - seenOpsRoot and every CAS node hash referenced by topics exist locally, and
     * - every suffix op id in cache.orderOpIds is present in `inputs` (in canonical order).
     * O(N) id lookups; no re-sort. Inputs not in the cache are applied by the next materialize().
     * Returns true on cache hit, false on miss.
     */
    restoreMaterializedCache(cache: KernelMaterializedCache, inputs: readonly KernelOperationInput[]): Promise<boolean>;
    /**
     * Bootstrap kernel state directly from a verified FinalityCheckpoint snapshot.
     * Restores both topicsMap, seenOpsRoot (consumed handles), and rolling historyDigest
     * so subsequent suffix replay produces identical stateRoot AND revision.digest.
     */
    bootstrapFromCheckpoint(checkpoint: {
        readonly topics: Readonly<Record<string, JsonValue>>;
        readonly seenOpsRoot: string;
        readonly historyDigest: string;
        readonly stateRoot: string;
    }): Promise<void>;
    /**
     * Bootstrap kernel state from a verified snapshot WITHOUT the historical operations: every op in
     * the cache (frontier and suffix) becomes frontier, so materialize(inputs) skips those ops and
     * applies only operations that are new. Trust: the caller has verified the snapshot's signer.
     */
    restoreSnapshotFrontier(cache: KernelMaterializedCache): Promise<boolean>;
    /**
     * Deterministically materialize an eligible operation set (arbitrary input order; sorted internally).
     * Rewinds only to the earliest snapshot before the first changed position (suffix replay).
     */
    materialize(inputs: readonly KernelOperationInput[]): Promise<KernelMaterializeResult>;
    materialize__impl(inputs: readonly KernelOperationInput[]): Promise<KernelMaterializeResult>;
    /** Execute a pure read-only query against a topic's query() export (or return raw topic state if no query export). */
    query(topic: string, input?: JsonValue, topicsOverride?: Readonly<Record<string, JsonValue>>): Promise<JsonValue>;
    /**
     * Time-travel materialization: reconstructs the exact coherent state at a specific opId
     * or at/before a timestamp without mutating live kernel state.
     */
    materializeAt(target: {
        readonly opId: string;
    } | {
        readonly atTimestampMs: bigint;
    }): Promise<{
        readonly revision: KernelRevision;
        readonly topics: Readonly<Record<string, JsonValue>>;
        readonly orderLength: number;
        readonly targetOpId: string | null;
    }>;
    /** Execute a read-only query against a historical revision (by opId or timestamp). */
    queryAt(topic: string, input: JsonValue, target: {
        readonly opId: string;
    } | {
        readonly atTimestampMs: bigint;
    }): Promise<{
        readonly revision: KernelRevision;
        readonly targetOpId: string | null;
        readonly value: JsonValue;
    }>;
    /** Collect exported command/query descriptions across all bound topics (for MCP & scoped tools). */
    describe(): Promise<Readonly<Record<string, JsonValue>>>;
    /**
     * Create a deterministic `FinalityPredicateVerifier` that evaluates `$finality` policies
     * with `kind: 'predicate'` by running the hash-pinned ES Module / `chronolog-pkg/v1` /
     * pure-WASM module declared in `$reducers` against the public control state and checkpoint
     * evidence. Runs identically on browsers, Node agents, and blind Cloudflare Worker hosts.
     */
    createFinalityPredicateVerifier(): (policy: {
        readonly kind: 'predicate';
        readonly module: string;
        readonly export?: string;
        readonly config?: JsonValue;
    }, checkpoint: unknown) => Promise<boolean>;
    /** Evaluate signal authorization policy for the current stateRoot (cached by caller per stateRoot). */
    signalPolicy(): Promise<{
        readonly rules: readonly {
            readonly topicPattern: string;
            readonly allowedAuthors: readonly string[];
            readonly maxTtlMs: number;
            readonly allowRelay: boolean;
        }[];
    }>;
}
