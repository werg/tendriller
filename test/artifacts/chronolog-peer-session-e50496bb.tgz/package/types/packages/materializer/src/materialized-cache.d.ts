import type { JsonValue, OperationVisibility } from '../../protocol/src/index.js';
/** One committed operation outcome as kept by the kernel (and its materialized cache). */
export interface EmittedKernelEvent {
    readonly opId: string;
    readonly eventOrdinal: number;
    readonly topic: string;
    readonly payload: JsonValue;
    readonly author: string;
    readonly operationId: string;
    readonly authorTimestampMs: bigint;
}
export interface KernelOperationOutcome {
    readonly opId: string;
    readonly author: string;
    readonly operationId: string;
    readonly authorTimestampMs: bigint;
    readonly visibility: OperationVisibility;
    readonly outcome: 'accepted' | 'rejected';
    readonly rejectionCode: string | null;
    readonly rejectionDetail?: string;
    readonly conflictRecorded?: boolean;
    readonly events: readonly EmittedKernelEvent[];
}
/**
 * Exported kernel state: enough to resume materialization without replaying history.
 *
 * `frontierOpIds` are ops already folded into `topics` whose inputs are NOT needed (snapshot
 * bootstrap); `orderOpIds`/`outcomes` are the replayable suffix whose inputs must be present
 * locally for an exact restore. A wire snapshot carries an empty suffix (frontier only).
 */
export interface KernelMaterializedCache {
    readonly v: 2;
    readonly logId: string;
    readonly blindHostMode: boolean;
    readonly topics: Readonly<Record<string, JsonValue>>;
    readonly seenOpsRoot: string;
    readonly historyDigest: string;
    readonly stateRoot: string;
    readonly frontierOpIds: readonly string[];
    readonly frontierMaxTimestampMs: bigint;
    readonly orderOpIds: readonly string[];
    readonly outcomes: readonly KernelOperationOutcome[];
    /** Last accepted op per topic (lets restore skip re-reading every op's updates). */
    readonly topicLastOpIds: Readonly<Record<string, string>>;
    /** Last accepted op per author (and public-only per author on private logs) for causal-chain checks. */
    readonly authorLastOpIds?: Readonly<Record<string, string>>;
    readonly publicAuthorLastOpIds?: Readonly<Record<string, string>>;
}
/**
 * Compact binary encoding of a KernelMaterializedCache:
 *   u32 magic | u8 format | u32 headerLen | header JSON | u32 frontierCount | 32B ids |
 *   u32 orderCount | 32B ids | u32 outcomesLen | outcomes JSON
 * Op ids are raw 32-byte values; outcomes are positional tuples with an author table, so the
 * encoding is O(N) bytes with no per-op hex or keys, and decoding is one native JSON.parse.
 */
export declare function encodeMaterializedCache(cache: KernelMaterializedCache): Uint8Array;
/** Decode encodeMaterializedCache output; returns null for any other or malformed input. */
export declare function decodeMaterializedCache(bytes: Uint8Array): KernelMaterializedCache | null;
