import {
  createApplicationSession
} from "./chunks/chunk-3P7G5R7H.mjs";
import "./chunks/chunk-JZVERRC5.mjs";
import "./chunks/chunk-6QZAGTOJ.mjs";
import "./chunks/chunk-PTJK7MFF.mjs";
import {
  collectControlReferencedCasHashes,
  dryRunReducerUpgrade,
  extractControlPermissions,
  replayBlindHostControl
} from "./chunks/chunk-3XPJXUQC.mjs";
import {
  MissingDependencyError,
  OperationalTimeoutError,
  QuickJsSandbox,
  TopicKernel,
  WasmSandbox,
  createBytesStoreDerivationMemo,
  createWasiCasRunner,
  evaluateDerivation,
  signAuditAttestation,
  signBuildAttestation,
  verifyAuditAttestation,
  verifyBuildAttestation,
  verifyDerivationOutput
} from "./chunks/chunk-IHG3HSGG.mjs";
import {
  attachCasPinner,
  collectCasRefsFromValue,
  exportLogBlueprint,
  validateLogBlueprint
} from "./chunks/chunk-VHH47WOJ.mjs";
import {
  openApplicationDevice
} from "./chunks/chunk-SJBUGLEN.mjs";
import {
  STANDARD_MODULE_IMPORTS,
  STANDARD_MODULE_SOURCES,
  seedStandardModules,
  seedStandardPackages
} from "./chunks/chunk-XVIRXFJR.mjs";
import "./chunks/chunk-RFZQY6CX.mjs";
import "./chunks/chunk-O7NXWMZY.mjs";
import "./chunks/chunk-3YYBTMHD.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import {
  ContentAddressedStore,
  MemoryBytesStore,
  casRef,
  computeBlobDagHash,
  computeCasHash,
  decodeCasNode,
  decodeDerivationNode,
  decodePackageNode,
  decodeTreeNode,
  encodeCasNode,
  encodeDerivationNode,
  encodePackageNode,
  encodeTreeNode,
  hashCasNode,
  parseCasRef,
  putBlobDag,
  putDerivationNode,
  putPackageDag,
  putTreeDag,
  readBlobDag,
  tryParseCasRef
} from "./chunks/chunk-OWL5GQ66.mjs";
import {
  decodeEncryptedEnvelope,
  decodeLogGenesis,
  decodeOperationCore,
  decodeSignedOperation,
  encodeEncryptedEnvelope,
  encodeLogGenesis,
  encodeSignedOperation,
  encryptedEnvelopeDigest,
  genesisLogId,
  isControlTopic,
  operationIdDigest,
  signOperationCore,
  verifySignedOperation
} from "./chunks/chunk-XIVHZVOM.mjs";
import {
  bytesToHex
} from "./chunks/chunk-VRR2HFJY.mjs";

// packages/peer-session/src/hosted-runner.ts
async function runEphemeralHostedSession(options, work) {
  const epochKeys = /* @__PURE__ */ new Map();
  for (const [epoch, key] of options.epochKeys) epochKeys.set(epoch, key.slice());
  const memStore = new MemoryBytesStore();
  const device = await openApplicationDevice({
    store: memStore,
    managedSigner: options.signer,
    create: true
  });
  const casNodes = options.publicCasNodes.map((n) => ({
    hash: n.hash,
    bytes: n.bytes,
    partition: "public"
  }));
  const hydratedPrivHashes = /* @__PURE__ */ new Set();
  if (options.sealedPrivateCas !== void 0 && options.unsealPrivateCas !== void 0) {
    for (const item of options.sealedPrivateCas) {
      const opened = await options.unsealPrivateCas(item.hash, item.sealed);
      if (opened !== null) {
        casNodes.push({ hash: item.hash, bytes: opened, partition: "private" });
        hydratedPrivHashes.add(item.hash);
      }
    }
  }
  const hydratedEnvDigests = /* @__PURE__ */ new Set();
  for (const raw of options.encryptedEnvelopes) {
    hydratedEnvDigests.add(bytesToHex(encryptedEnvelopeDigest(raw)));
  }
  const existingPublicOpIds = /* @__PURE__ */ new Set();
  for (const raw of options.publicOps) {
    try {
      const signed = decodeSignedOperation(raw);
      existingPublicOpIds.add(bytesToHex(operationIdDigest(signed.coreBytes)));
    } catch {
    }
  }
  const session = await createApplicationSession({
    device,
    genesis: options.genesisBytes,
    casNodes,
    epochKeys,
    ...options.materializedSnapshot === void 0 ? {} : { materializedSnapshot: options.materializedSnapshot },
    ...options.casMirrors === void 0 ? {} : { casMirrors: options.casMirrors },
    ...options.wasmModule === void 0 ? {} : { wasmModule: options.wasmModule },
    ...options.sqliteWasmModule === void 0 ? {} : { sqliteWasmModule: options.sqliteWasmModule }
  });
  const maxSnapshotBytes = options.maxSnapshotBytes ?? 1024 * 1024;
  let value;
  const newEnvelopes = [];
  const newPublicOps = [];
  const newSealedPrivateCas = [];
  const prunedPrivateCasHashes = [];
  let snapshot = null;
  try {
    if (options.publicOps.length > 0 || options.encryptedEnvelopes.length > 0 || (options.checkpoints?.length ?? 0) > 0) {
      await session.mergeFacts({
        publicOps: [...options.publicOps],
        encryptedEnvelopes: [...options.encryptedEnvelopes],
        casNodes,
        retentions: [],
        checkpoints: [...options.checkpoints ?? []]
      });
    }
    value = await work(session);
    const exported = await session.exportFacts();
    for (const rawEnv of exported.encryptedEnvelopes) {
      const digest = bytesToHex(encryptedEnvelopeDigest(rawEnv));
      if (!hydratedEnvDigests.has(digest)) {
        const decoded = decodeEncryptedEnvelope(rawEnv);
        newEnvelopes.push({
          digest,
          epoch: decoded.epoch,
          author: bytesToHex(decoded.author),
          raw: rawEnv
        });
        hydratedEnvDigests.add(digest);
      }
    }
    for (const rawOp of exported.publicOps) {
      try {
        const signed = decodeSignedOperation(rawOp);
        const opId = bytesToHex(operationIdDigest(signed.coreBytes));
        if (!existingPublicOpIds.has(opId)) {
          newPublicOps.push(rawOp);
          existingPublicOpIds.add(opId);
        }
      } catch {
      }
    }
    const activePrivHashes = /* @__PURE__ */ new Set();
    for (const node of exported.casNodes) {
      if (node.partition !== "private") continue;
      activePrivHashes.add(node.hash);
      if (!hydratedPrivHashes.has(node.hash) && options.sealPrivateCas !== void 0) {
        const sealed = await options.sealPrivateCas(node.hash, node.bytes);
        newSealedPrivateCas.push({ hash: node.hash, sealed });
        hydratedPrivHashes.add(node.hash);
      }
    }
    for (const oldHash of hydratedPrivHashes) {
      if (!activePrivHashes.has(oldHash)) prunedPrivateCasHashes.push(oldHash);
    }
    const exportedSnap = await session.exportMaterializedSnapshot();
    if (exportedSnap !== null && exportedSnap.byteLength <= maxSnapshotBytes) {
      snapshot = exportedSnap;
    }
  } finally {
    try {
      await session.close();
    } catch {
    }
    for (const key of epochKeys.values()) key.fill(0);
    epochKeys.clear();
  }
  return {
    value,
    delta: {
      newEnvelopes,
      newPublicOps,
      newSealedPrivateCas,
      prunedPrivateCasHashes,
      snapshot
    }
  };
}
export {
  ContentAddressedStore,
  MemoryBytesStore,
  MissingDependencyError,
  OperationalTimeoutError,
  QuickJsSandbox,
  STANDARD_MODULE_IMPORTS,
  STANDARD_MODULE_SOURCES,
  TopicKernel,
  WasmSandbox,
  attachCasPinner,
  casRef,
  collectCasRefsFromValue,
  collectControlReferencedCasHashes,
  computeBlobDagHash,
  computeCasHash,
  createBytesStoreDerivationMemo,
  createWasiCasRunner,
  decodeCasNode,
  decodeDerivationNode,
  decodeEncryptedEnvelope,
  decodeLogGenesis,
  decodeOperationCore,
  decodePackageNode,
  decodeSignedOperation,
  decodeTreeNode,
  dryRunReducerUpgrade,
  encodeCasNode,
  encodeDerivationNode,
  encodeEncryptedEnvelope,
  encodeLogGenesis,
  encodePackageNode,
  encodeSignedOperation,
  encodeTreeNode,
  encryptedEnvelopeDigest,
  evaluateDerivation,
  exportLogBlueprint,
  extractControlPermissions,
  genesisLogId,
  hashCasNode,
  isControlTopic,
  operationIdDigest,
  parseCasRef,
  putBlobDag,
  putDerivationNode,
  putPackageDag,
  putTreeDag,
  readBlobDag,
  replayBlindHostControl,
  runEphemeralHostedSession,
  seedStandardModules,
  seedStandardPackages,
  signAuditAttestation,
  signBuildAttestation,
  signOperationCore,
  tryParseCasRef,
  validateLogBlueprint,
  verifyAuditAttestation,
  verifyBuildAttestation,
  verifyDerivationOutput,
  verifySignedOperation
};
