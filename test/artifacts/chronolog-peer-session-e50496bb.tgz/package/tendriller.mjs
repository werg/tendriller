import {
  createApplicationBackend
} from "./chunks/chunk-VUH2GHIC.mjs";
import "./chunks/chunk-XIVHZVOM.mjs";
import "./chunks/chunk-VRR2HFJY.mjs";
export {
  createApplicationBackend
};
