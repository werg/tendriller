import {
  connectApplicationWebRtc
} from "./chunks/chunk-EKTTGGMR.mjs";
import {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
} from "./chunks/chunk-YLVANYHX.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-MCU2YKH4.mjs";
export {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
