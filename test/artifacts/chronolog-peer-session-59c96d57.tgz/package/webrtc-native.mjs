import {
  connectApplicationWebRtc
} from "./chunks/chunk-EKTTGGMR.mjs";
import {
  WEBRTC_LIMITS
} from "./chunks/chunk-YLVANYHX.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-MCU2YKH4.mjs";

// packages/transport-webrtc/src/native.ts
import { MediaStreamTrack, RTCPeerConnection, RTCRtpCodecParameters } from "werift";
function createNativeAudioTrack() {
  const track = new MediaStreamTrack({ kind: "audio" });
  return {
    kind: "audio",
    raw: track,
    writeRtp(packet) {
      track.writeRtp(packet);
    },
    onRtp(listener) {
      const sub = track.onReceiveRtp.subscribe((packet) => {
        listener({
          payload: new Uint8Array(packet.payload),
          sequenceNumber: packet.header.sequenceNumber,
          timestamp: packet.header.timestamp,
          payloadType: packet.header.payloadType,
          ssrc: packet.header.ssrc
        });
      });
      return () => {
        sub.unSubscribe();
      };
    },
    stop() {
      track.stop();
    }
  };
}
function createNativePeerConnection(configuration = {}, native = {}) {
  if (configuration.certificates !== void 0) throw new Error("WEBRTC_NATIVE_CERTIFICATES_UNSUPPORTED");
  const peer = new RTCPeerConnection({
    ...native,
    iceStunGatherTimeout: native.iceStunGatherTimeout ?? WEBRTC_LIMITS.gatheringMs / 1e3,
    iceUseDefaultStunServer: false,
    certificateScope: "peerConnection",
    codecs: {
      audio: [
        new RTCRtpCodecParameters({ mimeType: "audio/opus", clockRate: 48e3, channels: 2 })
      ],
      video: [
        new RTCRtpCodecParameters({ mimeType: "video/VP8", clockRate: 9e4 }),
        new RTCRtpCodecParameters({ mimeType: "video/H264", clockRate: 9e4 })
      ]
    },
    iceServers: configuration.iceServers?.map((server) => ({
      urls: server.urls,
      ...server.username === void 0 ? {} : { username: server.username },
      ...server.credential === void 0 ? {} : { credential: server.credential }
    })) ?? [],
    ...configuration.iceTransportPolicy === void 0 ? {} : { iceTransportPolicy: configuration.iceTransportPolicy },
    ...configuration.bundlePolicy === void 0 ? {} : { bundlePolicy: configuration.bundlePolicy },
    ...configuration.iceCandidatePoolSize === void 0 ? {} : { iceCandidatePoolSize: configuration.iceCandidatePoolSize }
  });
  const events = new EventTarget(), channels = /* @__PURE__ */ new Set();
  const wrap = (channel) => {
    const value = new NativeDataChannel(channel);
    channels.add(value);
    return value;
  };
  const subscriptions = [
    peer.onDataChannel.subscribe((channel) => events.dispatchEvent(Object.assign(new Event("datachannel"), { channel: wrap(channel) }))),
    peer.connectionStateChange.subscribe(() => events.dispatchEvent(new Event("connectionstatechange"))),
    peer.iceConnectionStateChange.subscribe(() => events.dispatchEvent(new Event("iceconnectionstatechange"))),
    peer.iceGatheringStateChange.subscribe(() => events.dispatchEvent(new Event("icegatheringstatechange"))),
    peer.signalingStateChange.subscribe(() => events.dispatchEvent(new Event("signalingstatechange"))),
    peer.onNegotiationneeded.subscribe(() => events.dispatchEvent(new Event("negotiationneeded"))),
    peer.onIceCandidate.subscribe((candidate) => {
      events.dispatchEvent(Object.assign(new Event("icecandidate"), {
        candidate: candidate ? candidate.toJSON() : null
      }));
    }),
    peer.onTrack.subscribe((track) => {
      const transceiver = peer.getTransceivers().find((item) => item.receiver?.track === track);
      events.dispatchEvent(Object.assign(new Event("track"), { track, streams: [], transceiver }));
    })
  ];
  return {
    get localDescription() {
      return peer.localDescription;
    },
    get iceGatheringState() {
      return peer.iceGatheringState;
    },
    get connectionState() {
      return peer.connectionState;
    },
    get signalingState() {
      return peer.signalingState;
    },
    get iceConnectionState() {
      return peer.iceConnectionState;
    },
    getStats: () => peer.getStats(),
    createDataChannel: (label, options) => wrap(peer.createDataChannel(label, options)),
    createOffer: (options) => peer.createOffer(options),
    createAnswer: () => peer.createAnswer(),
    async setLocalDescription(description) {
      if (description === void 0) {
        await peer.setLocalDescription();
        return;
      }
      if (description.type === "rollback") {
        await peer.setLocalDescription({ type: "rollback" });
        return;
      }
      if (description.type !== "offer" && description.type !== "answer" || description.sdp === void 0) {
        throw new Error("WEBRTC_DESCRIPTION_INVALID");
      }
      await peer.setLocalDescription({ type: description.type, sdp: description.sdp });
    },
    async setRemoteDescription(description) {
      if (description.type !== "offer" && description.type !== "answer" || description.sdp === void 0) {
        throw new Error("WEBRTC_DESCRIPTION_INVALID");
      }
      await peer.setRemoteDescription({ type: description.type, sdp: description.sdp });
    },
    async addIceCandidate(candidate) {
      await peer.addIceCandidate(candidate ?? null);
    },
    restartIce: () => peer.restartIce(),
    addTrack: (track, ...streams) => peer.addTrack(track, ...streams),
    removeTrack: (sender) => peer.removeTrack(sender),
    addTransceiver: (kindOrTrack, init) => peer.addTransceiver(kindOrTrack, init),
    getTransceivers: () => peer.getTransceivers(),
    getSenders: () => peer.getSenders(),
    getReceivers: () => peer.getReceivers(),
    addEventListener: (type, listener) => events.addEventListener(type, listener),
    removeEventListener: (type, listener) => events.removeEventListener(type, listener),
    async close() {
      for (const subscription of subscriptions) subscription.unSubscribe();
      for (const channel of channels) channel.close();
      await peer.close();
    }
  };
}
var NativeDataChannel = class extends EventTarget {
  binaryType = "arraybuffer";
  #closed = false;
  #channel;
  #subscriptions;
  constructor(channel) {
    super();
    this.#channel = channel;
    this.#subscriptions = [
      channel.onMessage.subscribe((data) => {
        const value = typeof data === "string" ? data : new Uint8Array(data).buffer;
        this.dispatchEvent(new MessageEvent("message", { data: value }));
      }),
      channel.stateChanged.subscribe((state) => {
        if (state === "open") this.dispatchEvent(new Event("open"));
        else if (state === "closed") this.close();
      }),
      channel.bufferedAmountLow.subscribe(() => this.dispatchEvent(new Event("bufferedamountlow"))),
      channel.error.subscribe(() => this.dispatchEvent(new Event("error")))
    ];
  }
  get label() {
    return this.#channel.label;
  }
  get ordered() {
    return this.#channel.ordered;
  }
  get maxPacketLifeTime() {
    return this.#channel.maxPacketLifeTime;
  }
  get maxRetransmits() {
    return this.#channel.maxRetransmits;
  }
  get readyState() {
    return this.#channel.readyState;
  }
  get bufferedAmount() {
    return this.#channel.bufferedAmount;
  }
  get bufferedAmountLowThreshold() {
    return this.#channel.bufferedAmountLowThreshold;
  }
  set bufferedAmountLowThreshold(value) {
    this.#channel.bufferedAmountLowThreshold = value;
  }
  send(data) {
    this.#channel.send(typeof data === "string" ? data : Buffer.from(data));
  }
  close() {
    if (this.#closed) return;
    this.#closed = true;
    this.dispatchEvent(new Event("close"));
    for (const subscription of this.#subscriptions) subscription.unSubscribe();
    this.#channel.close();
  }
};

// packages/peer-session/src/webrtc-native.ts
function connectNativeApplicationWebRtc(session, options) {
  return connectApplicationWebRtc(session, { ...options, createPeerConnection: (configuration) => createNativePeerConnection(configuration, options.native) });
}
export {
  connectNativeApplicationWebRtc,
  createNativeAudioTrack,
  createNativePeerConnection
};
