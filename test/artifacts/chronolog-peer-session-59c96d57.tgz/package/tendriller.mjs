import {
  createApplicationBackend
} from "./chunks/chunk-F4ZVOCDK.mjs";
import "./chunks/chunk-RIBYWTWK.mjs";
import "./chunks/chunk-PDJLSHX7.mjs";
export {
  createApplicationBackend
};
