import type { InBandSignalingHandle, InBandSignalingOptions, PeerDescription, PeerIceCandidate, PeerMediaController, PeerStreamsController, RtcDataChannel, RtcPeerConnection, RtcSignalMessage } from './types.js';
export declare const APP_STREAM_PREFIX = "app:";
export declare const MAX_APP_STREAMS = 16;
export declare const MAX_APP_STREAM_LABEL = 128;
export declare const MAX_APP_STREAM_MESSAGE_BYTES: number;
export declare const MAX_APP_STREAM_QUEUE = 256;
export declare const MAX_ICE_CANDIDATE_BYTES = 2048;
export declare const RENEGOTIATION_TIMEOUT_MS = 5000;
export declare const ICE_RESTART_DEBOUNCE_MS = 2000;
export declare function validatePeerDescription(value: unknown, expectedType?: PeerDescription['type']): PeerDescription;
export declare function validatePeerIceCandidate(value: unknown): PeerIceCandidate | null;
export declare function validateRtcSignalMessage(value: unknown): RtcSignalMessage;
export declare function serializeIceCandidate(candidate: unknown): PeerIceCandidate | null;
export interface PeerMediaAndStreamsRuntime {
    readonly media: PeerMediaController;
    readonly streams: PeerStreamsController;
    attachInBandSignaling(options: InBandSignalingOptions): InBandSignalingHandle;
    close(): void;
}
/**
 * Manages W3C Perfect Negotiation, ICE restart, RTP tracks, and dynamic `app:*`
 * DataChannels on an authenticated Chronolog WebRTC connection without disrupting
 * the pre-negotiated `chronolog.reliable` (id:0) and `chronolog.live` (id:1) lanes.
 */
export declare function createPeerMediaAndStreams(connection: RtcPeerConnection, sessionSignal: AbortSignal, options: {
    readonly onUnexpectedPreAuthChannel: (channel: RtcDataChannel) => void;
}): PeerMediaAndStreamsRuntime;
