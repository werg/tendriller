import { MediaStreamTrack, RTCRtpCodecParameters } from 'werift';
import type { PeerConfig } from 'werift';
import type { RtcPeerConnection } from './types.js';
export { MediaStreamTrack, RTCRtpCodecParameters };
export interface NativeAudioTrack {
    readonly kind: 'audio';
    readonly raw: unknown;
    writeRtp(packet: Uint8Array | {
        readonly header: unknown;
        readonly payload: Uint8Array;
    }): void;
    onRtp(listener: (packet: {
        readonly payload: Uint8Array;
        readonly sequenceNumber: number;
        readonly timestamp: number;
        readonly payloadType: number;
        readonly ssrc: number;
    }) => void): () => void;
    stop(): void;
}
/** Create a native Werift audio track for sending or wrapping RTP Opus frames in Node. */
export declare function createNativeAudioTrack(): NativeAudioTrack;
export type NativeRtcOptions = Partial<Pick<PeerConfig, 'icePortRange' | 'iceInterfaceAddresses' | 'iceAdditionalHostAddresses' | 'iceUseIpv4' | 'iceUseIpv6' | 'iceUseTcp' | 'iceTcpPassive' | 'iceStunGatherTimeout' | 'iceTurnConnectTimeout' | 'turnUdpFamily'>>;
/** Explicit native entrypoint: no Node or Werift bytes enter browser bundles. */
export declare function createNativePeerConnection(configuration?: RTCConfiguration, native?: NativeRtcOptions): RtcPeerConnection;
