export declare const DOMAINS: {
    readonly transaction: "chronolog/transaction-core/v1";
    readonly materializedLog: "chronolog/materialized-log/v1";
    readonly celldApplicationInvitation: "chronolog/celld/application-invitation/v1";
    readonly celldWorkspacePublication: "chronolog/celld/workspace-publication/v1";
    readonly publication: "chronolog/publication/v1";
};
export type ProtocolDomain = (typeof DOMAINS)[keyof typeof DOMAINS];
export declare function domainSeparatedBytes(domain: ProtocolDomain, payload: Uint8Array): Uint8Array;
export declare function hashDomain(domain: ProtocolDomain, payload: Uint8Array): Promise<Uint8Array>;
export interface Ed25519KeyPair {
    readonly publicKey: CryptoKey;
    readonly privateKey: CryptoKey;
    readonly publicKeyBytes: Uint8Array;
}
export declare function generateEd25519KeyPair(extractable?: boolean): Promise<Ed25519KeyPair>;
export declare function importEd25519PublicKey(raw: Uint8Array): Promise<CryptoKey>;
export declare function importEd25519PrivateKey(pkcs8: Uint8Array, extractable?: boolean): Promise<CryptoKey>;
export declare function exportEd25519PrivateKey(privateKey: CryptoKey): Promise<Uint8Array>;
export declare function signDomain(domain: ProtocolDomain, payload: Uint8Array, privateKey: CryptoKey): Promise<Uint8Array>;
export declare function verifyDomain(domain: ProtocolDomain, payload: Uint8Array, signature: Uint8Array, publicKey: CryptoKey | Uint8Array): Promise<boolean>;
