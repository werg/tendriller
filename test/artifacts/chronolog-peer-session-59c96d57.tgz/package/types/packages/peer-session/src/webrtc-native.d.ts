import { type NativeRtcOptions } from '../../transport-webrtc/src/native.js';
import type { ApplicationPeerLink } from './network.js';
import type { ApplicationSession } from './session.js';
import { type WebRtcOptions, type WebRtcSession } from './webrtc.js';
export { createNativePeerConnection, createNativeAudioTrack, type NativeRtcOptions, type NativeAudioTrack } from '../../transport-webrtc/src/native.js';
/** Node RTC adapter included in the standard archive with its exact Werift dependency. */
export declare function connectNativeApplicationWebRtc(session: ApplicationSession, options: Omit<WebRtcOptions, 'createPeerConnection'> & {
    readonly peerIdentity?: string;
    readonly native?: NativeRtcOptions;
}): Promise<ApplicationPeerLink & {
    readonly rtc: WebRtcSession;
}>;
