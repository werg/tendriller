import { type InBandSignalingHandle, type InBandSignalingOptions, type PeerMediaController, type PeerStreamsController, type RtcPeerConnection, type WebRtcOptions, type WebRtcRoute } from '../../transport-webrtc/src/index.js';
import type { FramedPeerConnection } from '../../records/src/index.js';
/** Ordered, authenticated endpoint: Worker, dedicated port, or a virtual endpoint. */
export interface ApplicationWorkerEndpoint {
    postMessage(message: unknown, transfer?: Transferable[]): void;
    addEventListener(type: 'message', listener: (event: MessageEvent) => void): void;
    removeEventListener(type: 'message', listener: (event: MessageEvent) => void): void;
    /** Owned MessagePort endpoints may release their physical handle on detach. */
    close?(): void;
}
export interface WorkerWebRtcConnection extends FramedPeerConnection {
    getRoute(): Promise<WebRtcRoute>;
    attachInBandSignaling(options: InBandSignalingOptions & {
        readonly peerId: string;
    }): InBandSignalingHandle;
}
export interface PagePeerHandle {
    readonly peerId: string;
    readonly connectionId: string;
    readonly transportKind: 'direct';
    readonly media: PeerMediaController;
    readonly streams: PeerStreamsController;
    readonly signal: AbortSignal;
}
export interface WorkerWebRtcServer {
    getPeer(peerId: string): PagePeerHandle | undefined;
    peers(): readonly PagePeerHandle[];
    onPeer(listener: (event: {
        readonly type: 'connected' | 'disconnected';
        readonly peer: PagePeerHandle;
    }) => void): () => void;
    close(): Promise<void>;
}
/** Page-side RTC and raw framing. Media tracks and `app:*` DataChannels stay directly in the page. */
export declare function serveWorkerWebRtcConnections(endpoint: ApplicationWorkerEndpoint, options?: {
    readonly createPeerConnection?: (configuration: RTCConfiguration) => RtcPeerConnection;
    readonly signal?: AbortSignal;
}): WorkerWebRtcServer;
/** Owner-side framed connection. Only bounded signaling and opaque peer frames cross the endpoint. */
export declare function openWorkerWebRtcConnection(endpoint: ApplicationWorkerEndpoint, options: Omit<WebRtcOptions, 'createPeerConnection'>): Promise<WorkerWebRtcConnection>;
