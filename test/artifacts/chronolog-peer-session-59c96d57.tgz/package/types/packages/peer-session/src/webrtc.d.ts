import { type WebRtcOptions, type WebRtcSession } from '../../transport-webrtc/src/index.js';
import type { ApplicationPeerLink } from './network.js';
import type { ApplicationSession } from './session.js';
export type { WebRtcOptions, PeerSignaling, PeerSignalingMessage, PeerDescription, PeerIceCandidate, RtcSignalMessage, RtcPeerConnection, PeerDataStream, PeerDataStreamOptions, PeerMediaController, PeerStreamsController, PeerTrackEvent, WebRtcSession, WebRtcRoute, } from '../../transport-webrtc/src/index.js';
export { openWebRtcConnection, WEBRTC_LIMITS, APP_STREAM_PREFIX, MAX_APP_STREAMS } from '../../transport-webrtc/src/index.js';
export { serveWorkerWebRtcConnections, openWorkerWebRtcConnection, type ApplicationWorkerEndpoint, type WorkerWebRtcConnection, type PagePeerHandle, type WorkerWebRtcServer, } from './worker-transport.js';
/** The maintained browser/native composition owns both RTC lanes and peer authentication. */
export declare function connectApplicationWebRtc(session: ApplicationSession, options: WebRtcOptions & {
    readonly peerIdentity?: string;
}): Promise<ApplicationPeerLink & {
    readonly rtc: WebRtcSession;
}>;
