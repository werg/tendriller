import { type CelldBytesStorage, type CelldBytesStoreOptions } from '../../records/src/celld.js';
import type { SigningIdentity } from '../../authority/src/index.js';
import { type ApplicationDevice } from './device.js';
export { CelldBytesStore, CelldPrivateBytesStore, type CelldBytesStorage, type CelldBytesStoreOptions, type CelldPrivateBytesStorage } from '../../records/src/celld.js';
export { createApplicationSession } from './index.js';
/** Import a per-class secret against the public key admitted by the host. */
export declare function importCelldSigningIdentity(publicKey: string, pkcs8Hex: string | undefined): Promise<SigningIdentity>;
/** Open one device under its celld object, optionally using a SQLite facet for application data. */
export declare function openCelldDevice(options: {
    readonly storage: CelldBytesStorage;
    readonly create?: true;
    readonly managedSigner?: SigningIdentity;
    readonly metadataLimits?: CelldBytesStoreOptions;
    readonly dataLimits?: CelldBytesStoreOptions;
    readonly openDataStorage?: () => CelldBytesStorage;
}): Promise<ApplicationDevice>;
