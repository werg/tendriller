import type { ApplicationSubmission } from './operation.js';
import type { ApplicationOperation } from './operation.js';
import type { CommandOptions } from './session-types.js';
export interface LocalAuthoringSession {
    submit(input: ApplicationSubmission): Promise<ApplicationOperation>;
    command(name: string, input: unknown, options?: CommandOptions): Promise<ApplicationOperation>;
}
export declare function submitBatch(session: LocalAuthoringSession, submissions: readonly ApplicationSubmission[]): Promise<readonly ApplicationOperation[]>;
export declare function createAppClient(session: LocalAuthoringSession): {
    command: (name: string, input: unknown, options?: CommandOptions) => Promise<ApplicationOperation>;
    submit: (input: ApplicationSubmission) => Promise<ApplicationOperation>;
    batch: (input: readonly ApplicationSubmission[]) => Promise<readonly ApplicationOperation[]>;
};
