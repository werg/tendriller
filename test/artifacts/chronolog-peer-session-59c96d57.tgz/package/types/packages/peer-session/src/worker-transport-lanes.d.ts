export type Lane = 'reliable' | 'live';
type Wire = Record<string, unknown>;
/** Bounded opaque-frame bridge. It never interprets a peer record or owns its keys. */
export declare function workerRtcLanes(post: (value: Wire) => void, lifetime: AbortSignal, fail: (error: unknown) => void, timeoutMs: number, consume?: (lane: Lane, bytes: Uint8Array) => Promise<boolean>): {
    reliable: {
        lane: "live" | "reliable";
        send: (bytes: Uint8Array, signal?: AbortSignal) => Promise<boolean>;
        frames: (signal?: AbortSignal) => AsyncIterable<Uint8Array>;
        receive(value: Wire): void;
    };
    live: {
        lane: "live" | "reliable";
        send: (bytes: Uint8Array, signal?: AbortSignal) => Promise<boolean>;
        frames: (signal?: AbortSignal) => AsyncIterable<Uint8Array>;
        receive(value: Wire): void;
    };
    receive(value: Wire): void;
};
export {};
