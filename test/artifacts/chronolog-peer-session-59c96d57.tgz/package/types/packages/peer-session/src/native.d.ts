import type { SigningIdentity } from '../../authority/src/index.js';
import { type ApplicationDevice } from './device.js';
export { createApplicationSession } from './index.js';
export type { CreateApplicationSessionOptions } from './runtime.js';
export { NativeBytesStore } from '../../records/src/native.js';
export interface DisposableNativeDevice extends ApplicationDevice {
    readonly ephemeral: true;
    readonly resumable: false;
    readonly storageMode: 'disposable-events' | 'disposable-sql';
    /** Managed temp directory allocated for disposable SQL, or null for in-memory events. */
    readonly temporaryDirectory: string | null;
    /** Path for a disposable SQL database file inside temporaryDirectory, or null for events. */
    readonly databasePath: string | null;
}
/**
 * The SQLite file is the exclusive history owner; a second owner receives a busy error.
 * Without `managedSigner` the file holds its own device-local Ed25519 key. With
 * `managedSigner` (the agent path) the file records only that identity's public key,
 * so one agent signer can own many application devices in one process; every
 * resume must supply the same signer.
 */
export declare function openNativeDevice(options: {
    readonly path: string;
    readonly create?: true;
    readonly managedSigner?: SigningIdentity;
    readonly quotaBytes?: number;
    readonly maxValueBytes?: number;
}): Promise<ApplicationDevice>;
/**
 * Explicit disposable native device replacing ad-hoc `:memory:` SQL workarounds.
 * - Events mode uses in-memory MemoryBytesStore.
 * - SQL mode allocates a managed temp directory under os.tmpdir() and cleans it up on close/exit.
 */
export declare function openDisposableNativeDevice(options?: {
    readonly sql?: boolean;
    readonly managedSigner?: SigningIdentity;
    readonly quotaBytes?: number;
    readonly maxValueBytes?: number;
}): Promise<DisposableNativeDevice>;
