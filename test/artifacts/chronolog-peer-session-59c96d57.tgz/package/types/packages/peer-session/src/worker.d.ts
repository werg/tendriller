export { createApplicationSession, type CreateApplicationSessionOptions } from './index.js';
export { openBrowserDevice } from './browser-device.js';
export { acquireApplicationOwnerLock } from './owner-lock.js';
export { createApplicationOwner } from './session-owner.js';
export type * from './owner-types.js';
export { openWorkerWebRtcConnection } from './worker-transport.js';
import type { probeBrowserCapabilities as ProbeBrowserCapabilities } from './browser-capabilities.js';
export declare function probeBrowserCapabilities(...args: Parameters<typeof ProbeBrowserCapabilities>): Promise<import("./browser-capabilities.js").BrowserCapabilityReport>;
