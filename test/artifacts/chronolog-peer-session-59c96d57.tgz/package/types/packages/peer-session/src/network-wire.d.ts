import type { FramedPeerConnection } from '../../records/src/index.js';
export type { FramedPeerConnection, PeerLiveLane } from '../../records/src/index.js';
export declare const APPLICATION_NETWORK_LIMITS: Readonly<{
    messageBytes: number;
    fragmentBytes: number;
    queuedMessages: 8;
    queuedBytes: number;
    pendingRequests: 4;
    incomingRequests: 4;
    rangeCommands: 32;
    rangeBytes: number;
    peers: 16;
}>;
export declare function networkError(code: string): Error;
export declare function requireNetwork(value: unknown, code: string): asserts value;
export declare function record(value: unknown, keys: readonly string[]): Record<string, unknown>;
export declare function interruptible<T>(promise: Promise<T>, signal: AbortSignal): Promise<T>;
export declare function timeout(milliseconds: number, message: string): {
    signal: AbortSignal;
    cancel(): void;
};
/** One bounded assembly and one serialized writer; no JSON-sized RTC frame. */
export declare class ApplicationMessageWire {
    #private;
    constructor(connection: FramedPeerConnection, signal: AbortSignal, timeoutMs: number, authorize?: () => void);
    get stats(): {
        readonly sentBytes: number;
        readonly receivedBytes: number;
    };
    send(value: unknown, authorize?: () => void): Promise<void>;
    messages(): AsyncIterable<unknown>;
}
/** Test/embedded transport only; sessions still execute the actual authenticated wire. */
export declare function createFramedPeerConnectionPair(): readonly [FramedPeerConnection, FramedPeerConnection];
