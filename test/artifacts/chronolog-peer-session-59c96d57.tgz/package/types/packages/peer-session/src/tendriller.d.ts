import type { CommandOptions as InlineCommandOptions } from './session-types.js';
import type { ApplicationSession } from './session.js';
/** Host adapter is structurally typed, portable and carries no host ordering authority. */
export declare function createApplicationBackend(session: ApplicationSession): {
    applicationId: string;
    identity: {
        readonly publicKey: string;
    };
    readonly status: import("./session-types.js").SessionStatus;
    signal: AbortSignal;
    onStatus: (listener: (value: import("./session-types.js").SessionStatus) => void) => () => void;
    submit: (input: import("./operation.js").ApplicationSubmission) => Promise<import("./operation.js").ApplicationOperation>;
    changes: (options?: {
        readonly signal?: AbortSignal;
    }) => AsyncIterable<import("./session-types.js").ApplicationChange>;
    readView: (options?: {
        readonly view?: "local" | "final";
    }) => Promise<import("./session-types.js").ApplicationReadView>;
    operations: {
        get: (id: string) => import("./operation.js").ApplicationOperation | null;
        retry(id: string): Promise<import("./operation.js").ApplicationOperation>;
        subscribe(options: {
            readonly operationId: string;
            readonly signal?: AbortSignal;
        }): AsyncIterable<import("./operation.js").OperationInspection>;
    };
    events: {
        publish: (topic: string, payload: unknown, options?: InlineCommandOptions) => Promise<import("./operation.js").ApplicationOperation>;
        read: (options?: import("./session-types.js").ApplicationEventOptions) => Promise<import("./session-types.js").ApplicationEventBatch>;
    };
};
