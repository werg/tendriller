import { type AuthorityProvider, type Signed, type SigningIdentity } from '../../authority/src/index.js';
import { type EncryptedEpochPayload } from '../../crypto/src/index.js';
import { type TransactionCore } from '../../protocol/src/index.js';
export interface SignedOperationBody {
    readonly proposalId: string;
    readonly canonicalCore: Uint8Array;
}
export type SignedOperation = Signed<SignedOperationBody>;
export interface OperationEnvelope {
    readonly applicationId: string;
    readonly proposalId: string;
    readonly author: string;
    readonly authorTimestampMs: bigint;
    readonly membershipId: string;
    readonly executionManifestDigest: string;
    readonly encrypted: EncryptedEpochPayload;
}
export type SignedOperationEnvelope = Signed<OperationEnvelope>;
export declare function signOperation(core: TransactionCore, identity: SigningIdentity): Promise<SignedOperation>;
export declare function verifyOperation(body: SignedOperation): Promise<TransactionCore>;
export declare function membershipAt(authority: AuthorityProvider, id: string, timestamp: bigint, author: string): 'valid' | 'pending' | 'invalid';
export declare function wrapOperation(body: SignedOperation, identity: SigningIdentity, epoch: number, key: Uint8Array): Promise<SignedOperationEnvelope>;
export declare function verifyEnvelope(envelope: SignedOperationEnvelope, authority: AuthorityProvider): Promise<'valid' | 'pending' | 'excluded'>;
export declare function unwrapOperation(envelope: SignedOperationEnvelope, authority: AuthorityProvider): Promise<{
    readonly body: SignedOperation;
    readonly core: TransactionCore;
    readonly admission: 'valid' | 'excluded';
} | 'authority' | 'key'>;
