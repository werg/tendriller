import type { ApplicationReadView } from './session-types.js';
import { type LiveView, type ReactiveSession } from './live-view.js';
export interface ApplicationProjectionDefinition<Value> {
    readonly name: string;
    readonly version: string;
    derive(view: ApplicationReadView): Value | Promise<Value>;
}
export declare function defineProjection<Value>(definition: ApplicationProjectionDefinition<Value>): ApplicationProjectionDefinition<Value>;
export declare function createProjection<Value>(session: ReactiveSession, definition: ApplicationProjectionDefinition<Value>): LiveView<Value>;
