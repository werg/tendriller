import type { AuthorityBundle as InlineAuthorityBundle } from '../../authority/src/index.js';
import type { ApplicationPeerConnectOptions as InlineApplicationPeerConnectOptions } from './network.js';
import type { ApplicationPeerDiagnostics as InlineApplicationPeerDiagnostics } from './network.js';
import type { ApplicationPeerLink as InlineApplicationPeerLink } from './network.js';
import { type FinalityStatement, type Signed, type AuthorityProvider, type FinalityProof } from '../../authority/src/index.js';
import { type ApplicationProvisioning } from './provisioning.js';
import { ApplicationContent } from './content.js';
import { SignalChannel } from '../../signals/src/index.js';
import type { BytesStore } from '../../records/src/index.js';
import type { ApplicationDefinition } from './definition.js';
import type { CreateApplicationSessionOptions } from './runtime.js';
import { ApplicationOperation, type ApplicationSubmission, type OperationInspection, type RetentionEvidence } from './operation.js';
import { type SignedOperationEnvelope } from './operation-codec.js';
import type { ApplicationChange, ApplicationEventBatch, ApplicationEventOptions, ApplicationReadView, CommandOptions, MaterializedRevision, SessionStatus, WaitOptions } from './session-types.js';
export interface SessionFacts {
    readonly authority?: InlineAuthorityBundle;
    readonly envelopes: readonly SignedOperationEnvelope[];
    readonly retentions: readonly RetentionEvidence[];
    readonly finality: readonly FinalityProof[];
}
type SessionOptions<D extends ApplicationDefinition> = CreateApplicationSessionOptions<D> & {
    readonly authority: AuthorityProvider;
    readonly store: BytesStore;
    readonly release: () => Promise<void>;
};
/** The signed operation set owns facts; execution is a replaceable deterministic projection. */
export declare class ApplicationSession<D extends ApplicationDefinition = ApplicationDefinition> {
    #private;
    readonly authority: AuthorityProvider;
    readonly definition: D;
    readonly device: CreateApplicationSessionOptions<D>['device'];
    readonly content: ApplicationContent;
    readonly provisioning: ApplicationProvisioning;
    readonly signals: SignalChannel;
    private constructor();
    static open<D extends ApplicationDefinition>(options: SessionOptions<D>): Promise<ApplicationSession<D>>;
    get signal(): AbortSignal;
    connectPeer(options: InlineApplicationPeerConnectOptions): Promise<InlineApplicationPeerLink>;
    diagnostics(): Promise<readonly InlineApplicationPeerDiagnostics[]>;
    peerLinks(): Promise<readonly InlineApplicationPeerLink[]>;
    onPeerLink(listener: (event: {
        readonly type: 'connected' | 'disconnected';
        readonly link: InlineApplicationPeerLink;
    }) => void): Promise<() => void>;
    get applicationId(): string;
    get identity(): {
        readonly publicKey: string;
    };
    get revision(): MaterializedRevision;
    get status(): SessionStatus;
    /** Completion is local durable signed storage, not network dispatch or engine warm-up. */
    submit(input: ApplicationSubmission): Promise<ApplicationOperation>;
    command(name: string, input: unknown, options?: CommandOptions): Promise<ApplicationOperation>;
    get operations(): {
        get: (id: string) => ApplicationOperation | null;
        retry(id: string): Promise<ApplicationOperation>;
        subscribe(options: {
            readonly operationId: string;
            readonly signal?: AbortSignal;
        }): AsyncIterable<OperationInspection>;
    };
    inspectOperation(id: string): OperationInspection;
    waitOperation(id: string, fact: 'materialized' | 'retained' | 'finalized', options?: WaitOptions): Promise<OperationInspection>;
    exportFacts(): SessionFacts;
    mergeFacts(input: SessionFacts): Promise<void>;
    retain(proposalId: string, subject?: {
        readonly author: string;
        readonly envelopeDigest: string;
    }): Promise<RetentionEvidence>;
    mergeAuthority(bundle: InlineAuthorityBundle): Promise<void>;
    get finality(): {
        voteAuthorTime: (options: {
            readonly throughMs: bigint;
        }) => Promise<readonly Signed<FinalityStatement>[]>;
        closeAuthorTime(options: {
            readonly throughMs: bigint;
        }): Promise<{
            readonly closedThroughMs: bigint | null;
            readonly proofs: readonly FinalityProof[];
        }>;
        submitProofs(proofs: readonly FinalityProof[]): Promise<void>;
    };
    onFacts(listener: () => void): () => void;
    onStatus(listener: (value: SessionStatus) => void): () => void;
    onChange(listener: (value: ApplicationChange) => void): () => void;
    setConnectedPeers(count: number): void;
    retryMaterialization(): Promise<void>;
    readView(options?: {
        readonly view?: 'local' | 'final';
    }): Promise<ApplicationReadView>;
    query(name: string, input: unknown, options?: {
        readonly signal?: AbortSignal;
    }): Promise<{
        readonly applicationId: string;
        readonly revision: MaterializedRevision;
        readonly value: unknown;
    }>;
    readEvents(options?: ApplicationEventOptions): Promise<ApplicationEventBatch>;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
    close(): Promise<void>;
}
export type { MaterializedRevision, SessionStatus, ApplicationReadView, QueryRows, QueryParameter, ApplicationEvent, ApplicationEventOptions, ApplicationEventBatch, CommandOptions, ApplicationChange } from './session-types.js';
export { ApplicationOperation } from './operation.js';
export type { ApplicationSubmission, OperationInspection, MaterializedOperation, RetentionEvidence } from './operation.js';
