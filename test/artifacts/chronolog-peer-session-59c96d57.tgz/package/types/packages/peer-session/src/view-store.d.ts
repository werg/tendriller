export declare class SessionError extends Error {
    readonly code: string;
    constructor(code: string, message?: string);
}
export declare function canonicalJson(value: unknown, maxBytes?: number): string;
export interface OperationReference {
    readonly applicationId: string;
    readonly author: string;
    readonly operationId: string;
    readonly proposalId: string;
}
export interface RetainedOperation {
    readonly reference: OperationReference;
    readonly viewId: string;
    readonly context: Readonly<Record<string, unknown>>;
}
export interface ViewStorage {
    readonly length: number;
    key(index: number): string | null;
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
export interface ViewStore<Draft = unknown> {
    readonly viewId: string;
    readDraft(draftId?: string): Draft | null;
    writeDraft(value: Draft, draftId?: string): void;
    removeDraft(draftId?: string): void;
    retainOperation(reference: OperationReference, context?: Record<string, unknown>): RetainedOperation;
    inspectOperation(reference: OperationReference): RetainedOperation | null;
    removeOperation(reference: OperationReference): void;
    pending(options?: {
        readonly allViews?: boolean;
    }): readonly RetainedOperation[];
}
export declare function createViewStore<Draft = unknown>(options: {
    readonly storage: ViewStorage;
    readonly applicationId: string;
    readonly profileId: string;
    readonly viewId: string;
}): ViewStore<Draft>;
