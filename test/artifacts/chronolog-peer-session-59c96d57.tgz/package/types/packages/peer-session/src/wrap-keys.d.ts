export interface WrapKeyPair {
    readonly publicKey: string;
    readonly privateKey: Uint8Array;
}
/** A long-lived X25519 key-wrap key pair. Keep the PKCS#8 private bytes with the device or agent signer, never in authored assets. */
export declare function createWrapKeyPair(): Promise<WrapKeyPair>;
export declare function importWrapPrivateKey(pkcs8: Uint8Array): Promise<CryptoKey>;
