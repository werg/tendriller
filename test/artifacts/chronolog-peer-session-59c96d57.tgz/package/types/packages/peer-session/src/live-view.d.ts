import type { ApplicationChange as InlineApplicationChange } from './session-types.js';
import type { ApplicationReadView, MaterializedRevision, SessionStatus } from './session-types.js';
export interface LiveViewSnapshot<Value> {
    readonly revision: MaterializedRevision;
    readonly value: Value;
}
export interface LiveView<Value> {
    readonly snapshot: LiveViewSnapshot<Value> | null;
    readonly status: SessionStatus | null;
    readonly error: unknown;
    ready(options?: {
        readonly signal?: AbortSignal;
        readonly timeoutMs?: number;
    }): Promise<LiveViewSnapshot<Value>>;
    refresh(): Promise<LiveViewSnapshot<Value>>;
    subscribe(listener: (value: LiveViewSnapshot<Value>) => void): () => void;
    close(): void;
}
export interface ReactiveReadView {
    readonly revision: MaterializedRevision;
    release(): void | Promise<void>;
}
export interface ReactiveSession<View extends ReactiveReadView = ApplicationReadView> {
    readView(): Promise<View>;
    onChange(listener: (change: InlineApplicationChange) => void): () => void;
    onStatus(listener: (value: SessionStatus) => void): () => void;
}
/** Invalidation rederives a coherent captured snapshot. It never incrementally mirrors arrival events. */
export declare function createLiveView<Value, View extends ReactiveReadView = ApplicationReadView>(session: ReactiveSession<View>, derive: (view: View) => Value | Promise<Value>, options?: {
    readonly signal?: AbortSignal;
    readonly onError?: (error: unknown) => void;
    readonly onStatus?: (status: SessionStatus) => void;
}): LiveView<Value>;
