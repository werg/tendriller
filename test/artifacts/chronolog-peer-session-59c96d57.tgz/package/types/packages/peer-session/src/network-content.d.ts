import { type ApplicationContent, type ContentManifest, type ContentReference, type ContentRetention } from './content.js';
export declare const CONTENT_NETWORK_LIMITS: Readonly<{
    pending: 4;
    active: 4;
    timeoutMs: 30000;
    chunkBytes: number;
    chunkBase64Characters: number;
    messageBytes: number;
}>;
export type ContentWireMessage = {
    readonly type: 'manifest-request';
    readonly id: string;
    readonly reference: ContentReference;
} | {
    readonly type: 'chunk-request';
    readonly id: string;
    readonly reference: ContentReference;
    readonly index: number;
} | {
    readonly type: 'retain-request';
    readonly id: string;
    readonly reference: ContentReference;
} | {
    readonly type: 'manifest-response';
    readonly id: string;
    readonly manifest: ContentManifest | null;
} | {
    readonly type: 'chunk-response';
    readonly id: string;
    readonly bytes: string | null;
} | {
    readonly type: 'retain-response';
    readonly id: string;
    readonly receipt: ContentRetention;
} | {
    readonly type: 'error';
    readonly id: string;
    readonly code: 'CONTENT_UNAVAILABLE' | 'CONTENT_FORBIDDEN' | 'CONTENT_BUSY';
} | {
    readonly type: 'cancel';
    readonly id: string;
};
/** Validate bounds before encoding, base64 decoding, hashing or allocating an object-sized buffer. */
export declare function assertContentWireMessage(input: unknown): asserts input is ContentWireMessage;
/** Content RPC on an already authenticated/encrypted channel. Owns no transport or writer queue. */
export declare function createNetworkContent(options: {
    readonly content: ApplicationContent;
    readonly send: (message: ContentWireMessage) => Promise<void>;
    readonly signal: AbortSignal;
    readonly authorize: () => boolean;
    readonly peerId: string;
}): {
    handle(message: ContentWireMessage): Promise<void>;
    close(): void;
};
