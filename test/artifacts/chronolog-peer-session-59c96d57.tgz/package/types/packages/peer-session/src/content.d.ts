import type { BytesStore } from '../../records/src/index.js';
import { type AuthorityProvider, type Signed, type SigningIdentity } from '../../authority/src/index.js';
import { type ContentPutBytesOptions, type ContentReadBytesOptions } from './content-bytes.js';
export { CONTENT_CHUNK_BYTES } from './content-bytes.js';
export type { ContentPutBytesOptions, ContentReadBytesOptions } from './content-bytes.js';
export declare const MAX_CONTENT_CHUNKS: number;
/** Canonical encrypted-envelope bytes: 64 KiB plaintext, AES tag, hex encoding and bounded metadata. */
export declare const MAX_CONTENT_ENCRYPTED_CHUNK_BYTES: number;
export declare const MAX_CONTENT_MANIFEST_BYTES: number;
export interface ContentReference {
    readonly profile: 'authored-content-v1';
    readonly applicationId: string;
    readonly id: string;
    readonly epoch: number;
    readonly bytes: number;
    readonly mediaType: string;
}
export interface ContentManifest {
    readonly stageId: string;
    readonly reference: Omit<ContentReference, 'id'>;
    readonly chunks: readonly {
        readonly hash: string;
        readonly bytes: number;
    }[];
}
export type ContentRetention = Signed<{
    readonly reference: ContentReference;
    readonly peer: string;
    readonly storageId: string;
}>;
export interface ContentOptions {
    readonly signal?: AbortSignal;
}
export interface ContentSource {
    manifest(reference: ContentReference, options?: ContentOptions): Promise<ContentManifest | null>;
    chunk(reference: ContentReference, index: number, options?: ContentOptions): Promise<Uint8Array | null>;
    retained?(reference: ContentReference, options?: ContentOptions): Promise<ContentRetention>;
}
export interface ContentUpload {
    readonly id: string;
    write(index: number, bytes: Uint8Array): Promise<void>;
    progress(): Promise<{
        readonly bytes: number;
        readonly storedBytes: number;
        readonly missingChunks: readonly number[];
    }>;
    commit(): Promise<ContentReference>;
    /** Release this upload's staging records; an already committed object remains independently retained. */
    discard(): Promise<void>;
}
export declare function assertContentReference(value: unknown): asserts value is ContentReference;
export declare function assertContentManifest(value: unknown): asserts value is ContentManifest;
export declare function assertContentRetention(value: unknown): asserts value is ContentRetention;
/** Durable encrypted content is independent of operation execution, peer delivery and finality. */
export declare class ApplicationContent {
    #private;
    constructor(options: {
        readonly store: BytesStore;
        readonly authority: AuthorityProvider;
        readonly identity: SigningIdentity;
        readonly storageId: string;
    });
    attachSource(id: string, source: ContentSource): () => void;
    stage(options: {
        readonly bytes: number;
        readonly mediaType?: string;
    }): Promise<ContentUpload>;
    resumeUpload(id: string): Promise<ContentUpload>;
    read(input: ContentReference, options?: ContentOptions): AsyncIterable<Uint8Array>;
    /** Transfer/check the entire encrypted object before claiming local retention. */
    retain(input: ContentReference, options?: ContentOptions): Promise<ContentRetention>;
    verifyRetention(input: ContentReference, receipt: ContentRetention, expectedPeer?: string): Promise<void>;
    /** Ask attached sources to retain the object; these signed availability facts are not finality. */
    retention(input: ContentReference, options?: ContentOptions): Promise<readonly ContentRetention[]>;
    retained(input: ContentReference): Promise<readonly ContentRetention[]>;
    discard(input: ContentReference): Promise<void>;
    /** Serve only verified local bytes. Serving never recursively consults remote sources. */
    source(): ContentSource;
    putBytes(bytes: Uint8Array, options?: ContentPutBytesOptions): Promise<ContentReference>;
    readBytes(reference: ContentReference, options: ContentReadBytesOptions): Promise<Uint8Array>;
    close(): Promise<void>;
}
