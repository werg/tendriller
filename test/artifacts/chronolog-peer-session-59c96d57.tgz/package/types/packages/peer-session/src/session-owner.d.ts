import type { ApplicationSession } from './session.js';
import { type ApplicationOwnerOptions, type ApplicationSessionOwner } from './owner-types.js';
/** One fenced signer/storage owner, with independent bounded and cancellable client attachments. */
export declare function createApplicationOwner(session: ApplicationSession, options?: ApplicationOwnerOptions): ApplicationSessionOwner;
