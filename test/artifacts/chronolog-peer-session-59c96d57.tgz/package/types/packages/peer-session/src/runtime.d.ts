import type { BytesStore } from '../../records/src/index.js';
import type { ChronologMaterializationRuntime } from '../../materializer/src/index.js';
import type { AuthorityProvider, AuthorityBundle } from '../../authority/src/index.js';
import { type ApplicationDevice } from './device.js';
import type { ApplicationDefinition } from './definition.js';
import { ApplicationSession } from './session.js';
export interface CreateApplicationSessionOptions<D extends ApplicationDefinition = ApplicationDefinition> {
    readonly device: ApplicationDevice;
    readonly definition: D;
    readonly authority?: AuthorityProvider | AuthorityBundle;
    readonly applicationId?: string;
    readonly epochKeys?: ReadonlyMap<number, Uint8Array>;
    readonly createMaterializer?: (options: {
        readonly signal: AbortSignal;
        readonly rootPrincipal: Uint8Array;
        readonly store: BytesStore;
    }) => ChronologMaterializationRuntime | Promise<ChronologMaterializationRuntime>;
    readonly maxOperations?: number;
    readonly maxHistoryBytes?: number;
}
/** Opens cached authority/identity first, without host discovery or transport. */
export declare function createApplicationSession<const D extends ApplicationDefinition>(options: CreateApplicationSessionOptions<D>): Promise<ApplicationSession<D>>;
