import { type ChangeProgram } from '../../protocol/src/index.js';
import { type ApplicationDescription, type ApplicationInput, type ApplicationInputSchema } from '../../authority/src/index.js';
export { parseApplicationInput, type ApplicationDescription, type ApplicationInput, type ApplicationInputSchema } from '../../authority/src/index.js';
export interface ApplicationCommand<Input = never> {
    readonly description: string;
    readonly input: ApplicationInputSchema;
    prepare(input: Input): ChangeProgram;
}
export interface ApplicationQuery<Input = never, Result = unknown, View = unknown> {
    readonly description: string;
    readonly input: ApplicationInputSchema;
    read(view: View, input: Input): Result | Promise<Result>;
}
export interface ApplicationDefinition<Commands extends Readonly<Record<string, ApplicationCommand>> = Readonly<Record<string, ApplicationCommand>>, Queries extends Readonly<Record<string, ApplicationQuery<never, unknown, never>>> = Readonly<Record<string, ApplicationQuery<never, unknown, never>>>> {
    readonly id: string;
    /** Changes to command preparation or query semantics require a new version. */
    readonly version: string;
    readonly commands: Commands;
    readonly queries: Queries;
}
export declare function defineCommand<const S extends ApplicationInputSchema>(options: {
    readonly description: string;
    readonly input: S;
    readonly prepare: (input: ApplicationInput<S>) => ChangeProgram;
}): ApplicationCommand<ApplicationInput<S>>;
export declare function defineQuery<const S extends ApplicationInputSchema, Result, View>(options: {
    readonly description: string;
    readonly input: S;
    readonly read: (view: View, input: ApplicationInput<S>) => Result | Promise<Result>;
}): ApplicationQuery<ApplicationInput<S>, Result, View>;
export declare function defineApplication<const Commands extends Readonly<Record<string, ApplicationCommand>>, const Queries extends Readonly<Record<string, ApplicationQuery<never, unknown, never>>>>(definition: ApplicationDefinition<Commands, Queries>): ApplicationDefinition<Commands, Queries>;
/** Descriptions and tool schemas come from the same definition that executes commands. */
export declare function describeApplication(definition: ApplicationDefinition): ApplicationDescription;
/** Authenticates the same public description used by bootstrap and local tools. */
export declare function applicationDefinitionDigest(definition: ApplicationDefinition): Promise<string>;
