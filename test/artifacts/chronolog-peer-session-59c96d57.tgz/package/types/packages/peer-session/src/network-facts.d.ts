import type { SessionFacts } from './session.js';
/** Knowledge is scoped to one reliable, authenticated connection, never to a peer
 * identity across reconnects. Digests identify complete signed facts, not proposal
 * IDs: alternate envelopes, retention signatures and finality updates all matter. */
export declare class PeerFactKnowledge {
    #private;
    /** Bounded by durable envelopes, retentions, statements, and one authority slot. */
    get size(): number;
    /** Call only after successful authenticated merge, or successful reliable send. */
    remember(facts: SessionFacts): Promise<void>;
    missing(facts: SessionFacts): Promise<SessionFacts>;
}
