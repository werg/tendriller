import { type HpkeCiphertext } from '../../crypto/src/index.js';
export { createWrapKeyPair, importWrapPrivateKey, type WrapKeyPair } from './wrap-keys.js';
import { type SigningIdentity, type Signed, type AuthorityProvider, type AuthorityBundle } from '../../authority/src/index.js';
/**
 * Every epoch key of an application, sealed to one member's signed key-wrap key.
 * The recipient and its wrap key come from authenticated membership, never from
 * the transport that carries the package.
 */
export interface KeyWrap {
    readonly applicationId: string;
    readonly descriptorId: string;
    readonly membershipId: string;
    readonly recipient: string;
    readonly wrapKey: string;
    readonly epochs: readonly number[];
    readonly authority: AuthorityBundle;
    readonly encrypted: HpkeCiphertext;
}
export type SignedKeyWrap = Signed<KeyWrap>;
export interface ApplicationProvisioning {
    /** Seal every epoch key this member holds to a current reader member's signed wrap key. */
    wrapKeys(recipient: string): Promise<SignedKeyWrap>;
    /** Verify a package addressed to this device, merge its authority and install its committed epoch keys. */
    unwrapKeys(value: SignedKeyWrap, wrapPrivateKey: CryptoKey): Promise<readonly number[]>;
}
export declare function createApplicationProvisioning(options: {
    readonly authority: AuthorityProvider;
    readonly identity: SigningIdentity;
}): ApplicationProvisioning;
