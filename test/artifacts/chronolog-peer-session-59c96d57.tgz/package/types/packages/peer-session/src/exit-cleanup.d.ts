export declare function registerExitCleanup(cleanup: () => void): () => void;
/** Registered cleanup count, for leak diagnostics in tests. */
export declare function exitCleanupCount(): number;
