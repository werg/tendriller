import type { BytesStore, BytesStoreEntry } from './bytes-store.js';
export interface NativeBytesStoreOptions {
    readonly quotaBytes?: number;
    readonly maxValueBytes?: number;
}
/** Diagnostic view of the process-wide store pool. */
export interface NativeBytesStorePoolStatus {
    /** Worker thread serving every open store, or null when no store is open. */
    readonly threadId: number | null;
    readonly stores: number;
}
/**
 * Stable SQLite file served by the process-wide store pool worker.
 * Await open() for acquisition and close() for release; each store keeps its own file and exclusive lock.
 */
export declare class NativeBytesStore implements BytesStore {
    #private;
    constructor(path: string, options?: NativeBytesStoreOptions);
    static open(path: string, options?: NativeBytesStoreOptions): Promise<NativeBytesStore>;
    /** The shared worker and how many stores it currently serves. */
    static poolStatus(): NativeBytesStorePoolStatus;
    get(key: string): Promise<Uint8Array | null>;
    getMany(keys: readonly string[]): Promise<readonly (Uint8Array | null)[]>;
    put(key: string, value: Uint8Array): Promise<void>;
    putMany(entries: readonly BytesStoreEntry[]): Promise<void>;
    delete(key: string): Promise<void>;
    iterateEntries(): AsyncIterable<BytesStoreEntry>;
    entries(): Promise<readonly BytesStoreEntry[]>;
    putAllIfEmpty(entries: readonly BytesStoreEntry[]): Promise<boolean>;
    putStreamIfEmpty(entries: AsyncIterable<BytesStoreEntry>): Promise<boolean>;
    checkpointWal(): Promise<void>;
    usageBytes(): number;
    close(): Promise<void>;
}
