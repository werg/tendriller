import { type Signed, type SigningIdentity } from './codec.js';
import { type AppDescriptor, type FinalityPolicy, type AuthorityProvider, type AdmissionScope } from './control.js';
export interface Inclusion {
    readonly proposalId: string;
    readonly authorTimestampMs: bigint;
    readonly membershipId: string;
    readonly author: string;
}
export interface FinalityStatement {
    readonly applicationId: string;
    readonly policyDigest: string;
    /** Complete authenticated membership head known to this closure signer. */
    readonly authorityHead: string;
    readonly scope: string;
    readonly sequence: number;
    readonly previous: string | null;
    /** Newly first-included proposals. All historical first inclusions remain effective. */
    readonly inclusions: readonly Inclusion[];
    readonly closedThroughMs: bigint;
    readonly blockers: readonly Inclusion[];
}
export interface FinalityProof {
    readonly statement: FinalityStatement;
    readonly signatures: readonly Signed<FinalityStatement>[];
}
export interface VerifiedFinality {
    readonly closedThroughMs: bigint | null;
    /** First inclusion is valid in EVERY applicable policy and historical membership scope. */
    readonly included: ReadonlyMap<string, Inclusion>;
    readonly excludedProposalIds: ReadonlySet<string>;
    readonly proofs: readonly FinalityProof[];
    readonly pendingDependencies?: readonly string[];
    readonly certifiedProofs?: readonly FinalityProof[];
}
export declare function finalityPolicyDigest(policy: FinalityPolicy): Promise<string>;
export declare function signFinalityStatement(statement: FinalityStatement, signer: SigningIdentity): Promise<Signed<FinalityStatement>>;
export declare function finalityAdmissionScopes(authority: AuthorityProvider): Promise<readonly AdmissionScope[]>;
/** Certificates are evidence sets keyed by statement identity, not by signature array/envelope bytes. */
export declare function mergeFinalityProofs(...histories: readonly (readonly FinalityProof[])[]): Promise<readonly FinalityProof[]>;
/** Proofs certify historical first inclusion/closure; neither this verifier nor its provider assigns operation order.
 * knownProposals contains already authenticated authored facts, not claims supplied by an untrusted UI.
 */
export declare function verifyFinalityProofs(descriptor: AppDescriptor, input: readonly FinalityProof[], authority?: AuthorityProvider, knownProposals?: readonly Inclusion[]): Promise<VerifiedFinality>;
export interface FinalityProvider {
    read(): Promise<readonly FinalityProof[]>;
    publish(proof: FinalityProof): Promise<void>;
}
