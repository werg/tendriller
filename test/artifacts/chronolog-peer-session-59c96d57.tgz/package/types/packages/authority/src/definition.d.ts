import { type EventPayload } from '../../protocol/src/index.js';
/** The deliberately small JSON Schema subset accepted by application tools. */
export type ApplicationInputSchema = ({
    readonly type: 'string';
    readonly minLength?: number;
    readonly maxLength?: number;
    readonly enum?: readonly string[];
} | {
    readonly type: 'number' | 'integer';
    readonly minimum?: number;
    readonly maximum?: number;
} | {
    readonly type: 'boolean' | 'null';
} | {
    readonly type: 'array';
    readonly items: ApplicationInputSchema;
    readonly minItems?: number;
    readonly maxItems?: number;
} | {
    readonly type: 'object';
    readonly properties: Readonly<Record<string, ApplicationInputSchema>>;
    readonly required?: readonly string[];
    readonly additionalProperties?: false;
} | {
    readonly anyOf: readonly ApplicationInputSchema[];
}) & {
    readonly description?: string;
};
export type ApplicationInput<S extends ApplicationInputSchema> = ApplicationInputSchema extends S ? EventPayload : S extends {
    readonly anyOf: readonly (infer T extends ApplicationInputSchema)[];
} ? ApplicationInput<T> : S extends {
    readonly type: 'string';
    readonly enum: readonly (infer T extends string)[];
} ? T : S extends {
    readonly type: 'string';
} ? string : S extends {
    readonly type: 'number' | 'integer';
} ? number : S extends {
    readonly type: 'boolean';
} ? boolean : S extends {
    readonly type: 'null';
} ? null : S extends {
    readonly type: 'array';
    readonly items: infer T extends ApplicationInputSchema;
} ? readonly ApplicationInput<T>[] : S extends {
    readonly type: 'object';
    readonly properties: infer P extends Readonly<Record<string, ApplicationInputSchema>>;
} ? {
    readonly [K in keyof P as K extends RequiredInputKeys<S> ? K : never]: ApplicationInput<P[K]>;
} & {
    readonly [K in keyof P as K extends RequiredInputKeys<S> ? never : K]?: ApplicationInput<P[K]>;
} : never;
type RequiredInputKeys<S> = S extends {
    readonly required: readonly (infer K extends string)[];
} ? K : never;
/** Validate, copy and freeze JSON. Accessors, prototypes, undefined, NaN and sparse arrays fail. */
export declare function parseApplicationInput(schema: ApplicationInputSchema, value: unknown): EventPayload;
export declare function checkedApplicationInputSchema(value: ApplicationInputSchema): ApplicationInputSchema;
export interface ApplicationDescription {
    readonly id: string;
    readonly version: string;
    readonly commands: readonly ApplicationEntryDescription[];
    readonly queries: readonly ApplicationEntryDescription[];
}
export interface ApplicationEntryDescription {
    readonly name: string;
    readonly description: string;
    readonly input: ApplicationInputSchema;
}
/** One bounded, executable schema contract is used by peers, host metadata, and tools. */
export declare function validateApplicationDescription(value: ApplicationDescription): ApplicationDescription;
/** Authenticates published schemas and semantic version without executable application code. */
export declare function applicationDescriptionDigest(value: ApplicationDescription): Promise<string>;
export {};
