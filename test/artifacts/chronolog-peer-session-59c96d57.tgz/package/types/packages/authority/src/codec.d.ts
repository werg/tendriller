import { bytesToHex, hexToBytes } from '../../canonical/src/index.js';
export { bytesToHex, hexToBytes };
export interface SigningIdentity {
    readonly publicKey: string;
    readonly privateKey: CryptoKey;
}
export interface Signed<T> {
    readonly payload: T;
    readonly signer: string;
    readonly signature: string;
}
export declare function check(condition: unknown, code: string): asserts condition;
export declare function hex(value: unknown, length?: number): asserts value is string;
export declare function encodeRecord(value: unknown): Uint8Array;
export declare function decodeRecord<T>(bytes: Uint8Array): T;
export declare function equalRecord(a: unknown, b: unknown): boolean;
export declare function recordDigest(value: unknown): Promise<string>;
export declare function signRecord<T>(domain: string, payload: T, identity: SigningIdentity): Promise<Signed<T>>;
export declare function verifyRecord<T>(domain: string, signed: Signed<T>, expectedSigner?: string): Promise<void>;
export declare function createSigningIdentity(): Promise<SigningIdentity>;
export declare function exportSigningIdentity(identity: SigningIdentity): Promise<{
    publicKey: string;
    privateKey: string;
}>;
export declare function importSigningIdentity(value: {
    readonly publicKey: string;
    readonly privateKey: string;
}): Promise<SigningIdentity>;
