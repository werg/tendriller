import type { BytesStore } from '../../records/src/index.js';
import type { AuthorityProvider } from './control.js';
import { type Signed, type SigningIdentity } from './codec.js';
export declare const PUBLICATION_LIMITS: Readonly<{
    files: 128;
    bytes: number;
    manifestBytes: number;
    revisions: 4096;
}>;
export interface PublicationFile {
    readonly path: string;
    readonly hash: string;
    readonly size: number;
    readonly type: string;
}
export interface PublicationManifest {
    readonly applicationId: string;
    readonly membershipId: string;
    readonly author: string;
    readonly operationId: string;
    readonly revision: number;
    readonly previous: string | null;
    readonly executionManifestDigest: string;
    /** Optional API label, never a database schema/admission lock. */
    readonly definitionLabel?: string;
    readonly entry: string;
    readonly files: readonly PublicationFile[];
}
export interface SignedPublication extends Signed<PublicationManifest> {
    readonly id: string;
}
export declare function validatePublicationManifest(value: PublicationManifest): PublicationManifest;
export declare function signPublicationManifest(value: PublicationManifest, identity: SigningIdentity): Promise<SignedPublication>;
export interface PublicationAuthority {
    readonly applicationId: string;
    readonly executionManifestDigest: string;
    /** Independent host-verified publisher grant revision. No data reader/writer/root key is required. */
    readonly grantId: string;
    readonly publisherKeys: readonly string[];
}
export declare function verifyPublicationManifest(value: SignedPublication, authority: AuthorityProvider | PublicationAuthority): Promise<void>;
export declare function authorizePublication(value: SignedPublication, authority: AuthorityProvider | PublicationAuthority, previous: SignedPublication | null): Promise<void>;
export declare function verifyPublicationAsset(file: PublicationFile, bytes: Uint8Array): Promise<void>;
export interface PublicationRegistry {
    read(): Promise<readonly SignedPublication[]>;
    publish(value: SignedPublication): Promise<SignedPublication>;
}
export declare function createPublicationRegistry(options: {
    readonly store: BytesStore;
    readonly authority: AuthorityProvider;
}): Promise<PublicationRegistry>;
