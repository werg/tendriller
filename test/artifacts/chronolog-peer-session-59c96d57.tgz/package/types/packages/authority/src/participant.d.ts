import type { AuthorityProvider, AuthorityBundle } from './control.js';
import type { FinalityProof } from './finality.js';
import type { PublicationRegistry, SignedPublication } from './publication.js';
import { type Signed, type SigningIdentity } from './codec.js';
export interface ParticipantRequest {
    readonly applicationId: string;
    readonly requestId: string;
    readonly action: 'authority.read' | 'publication.read' | 'publication.publish' | 'finality.read' | 'finality.publish';
    readonly publication?: SignedPublication;
    readonly proof?: FinalityProof;
}
export type SignedParticipantRequest = Signed<ParticipantRequest>;
export interface ParticipantResponse {
    readonly requestId: string;
    readonly authority?: AuthorityBundle;
    readonly publications?: readonly SignedPublication[];
    readonly proofs?: readonly FinalityProof[];
}
export declare function signParticipantRequest(value: ParticipantRequest, identity: SigningIdentity): Promise<SignedParticipantRequest>;
/** Portable thin control participant. It receives no epoch keys and never supplies application order. */
export declare function createAuthorityParticipant(options: {
    readonly authority: AuthorityProvider;
    readonly publications: PublicationRegistry;
    readonly finality?: {
        read(): Promise<readonly FinalityProof[]>;
        publish(proof: FinalityProof): Promise<void>;
    };
}): {
    handle(request: SignedParticipantRequest): Promise<ParticipantResponse>;
};
