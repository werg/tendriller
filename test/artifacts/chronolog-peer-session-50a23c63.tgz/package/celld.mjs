import {
  createApplicationSession
} from "./chunks/chunk-4DPGBHXI.mjs";
import {
  openApplicationDevice,
  verifyDeviceSigner
} from "./chunks/chunk-B5XDIITM.mjs";
import "./chunks/chunk-L3SH4E3G.mjs";
import "./chunks/chunk-JP3L3YUV.mjs";
import "./chunks/chunk-HHSRWTA7.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-F4ZVOCDK.mjs";
import {
  hexToBytes,
  importEd25519PrivateKey
} from "./chunks/chunk-RIBYWTWK.mjs";
import "./chunks/chunk-PDJLSHX7.mjs";

// packages/records/src/sqlite-byte-limits.ts
function sqliteByteLimits(options) {
  const quotaBytes = options.quotaBytes ?? 256 * 1024 * 1024;
  const maxValueBytes = options.maxValueBytes ?? 128 * 1024 * 1024;
  for (const value of [quotaBytes, maxValueBytes]) {
    if (!Number.isSafeInteger(value) || value < 1) throw new Error("BYTES_STORE_QUOTA_INVALID");
  }
  return { quotaBytes, maxValueBytes };
}
function validateSqliteByteKey(key) {
  if (key.length === 0 || key.length > 2048 || [...key].some((character) => character.charCodeAt(0) < 32)) {
    throw new Error("BYTES_STORE_KEY_INVALID");
  }
}

// packages/records/src/celld.ts
var CelldBytesStore = class {
  constructor(storage, options = {}) {
    this.storage = storage;
    this.#limits = sqliteByteLimits(options);
    this.storage.transactionSync(() => {
      this.storage.sql.exec(`CREATE TABLE IF NOT EXISTS chronolog_records (
        key TEXT PRIMARY KEY, value BLOB NOT NULL
      ) STRICT`).toArray();
      this.storage.sql.exec(`CREATE TABLE IF NOT EXISTS chronolog_record_usage (
        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
        used_bytes INTEGER NOT NULL CHECK (used_bytes >= 0)
      ) STRICT`).toArray();
      this.storage.sql.exec(`
        INSERT INTO chronolog_record_usage
        SELECT 1, (SELECT coalesce(sum(length(value)), 0) FROM chronolog_records)
        WHERE NOT EXISTS (SELECT 1 FROM chronolog_record_usage WHERE singleton = 1)
      `).toArray();
    });
  }
  storage;
  #limits;
  #closed = false;
  async get(key) {
    this.#assertOpen();
    validateSqliteByteKey(key);
    return this.#read(key);
  }
  async put(key, value) {
    this.#validate(key, value);
    this.storage.transactionSync(() => this.#write([{ key, value }]));
  }
  /** Persist a device signer and its immutable binding together. */
  async initialize(entries) {
    this.#assertOpen();
    validateInitialEntries(entries);
    for (const { key, value } of entries) this.#validate(key, value);
    this.storage.transactionSync(() => {
      if (entries.every(({ key }) => this.#size(key) === null)) this.#write(entries);
    });
  }
  async compareAndSwap(key, expected, value) {
    this.#validate(key, value);
    return this.storage.transactionSync(() => {
      const current = this.#read(key);
      const matches = expected === null ? current === null : current !== null && expected.byteLength === current.byteLength && expected.every((byte, index) => byte === current[index]);
      if (matches) this.#write([{ key, value }]);
      return matches;
    });
  }
  usageBytes() {
    this.#assertOpen();
    const value = this.storage.sql.exec("SELECT used_bytes FROM chronolog_record_usage WHERE singleton = 1").toArray()[0]?.used_bytes;
    return readNonnegativeBytes(value);
  }
  close() {
    this.#closed = true;
  }
  #assertOpen() {
    if (this.#closed) throw new Error("BYTES_STORE_CLOSED");
  }
  #validate(key, value) {
    this.#assertOpen();
    validateSqliteByteKey(key);
    if (!(value instanceof Uint8Array) || value.byteLength > this.#limits.maxValueBytes) {
      throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    }
  }
  #read(key) {
    const row = this.storage.sql.exec("SELECT value FROM chronolog_records WHERE key = ?", key).toArray()[0];
    if (!row) return null;
    if (row.value instanceof Uint8Array) return Uint8Array.from(row.value);
    if (row.value instanceof ArrayBuffer) return new Uint8Array(row.value.slice(0));
    throw new Error("BYTES_STORE_VALUE_CORRUPT");
  }
  #size(key) {
    const row = this.storage.sql.exec("SELECT length(value) AS size FROM chronolog_records WHERE key = ?", key).toArray()[0];
    return row ? readNonnegativeBytes(row.size) : null;
  }
  #write(entries) {
    const used = entries.reduce((bytes, { key, value }) => bytes - (this.#size(key) ?? 0) + value.byteLength, this.usageBytes());
    if (used > this.#limits.quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    for (const { key, value } of entries) {
      this.storage.sql.exec(
        "INSERT INTO chronolog_records VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        key,
        value
      ).toArray();
    }
    this.storage.sql.exec("UPDATE chronolog_record_usage SET used_bytes = ? WHERE singleton = 1", used).toArray();
  }
};
var CelldPrivateBytesStore = class {
  constructor(storage, options = {}) {
    this.storage = storage;
    const namespace = options.namespace ?? "device";
    if (!/^[a-zA-Z0-9_.-]{1,64}$/u.test(namespace)) throw new Error("BYTES_STORE_NAMESPACE_INVALID");
    this.#prefix = `chronolog:records:v1:${namespace}:`;
    this.#limits = sqliteByteLimits(options);
  }
  storage;
  #limits;
  #prefix;
  #closed = false;
  async get(key) {
    this.#assertOpen();
    validateSqliteByteKey(key);
    return this.#read(key)?.slice() ?? null;
  }
  async put(key, value) {
    this.#validate(key, value);
    this.storage.transactionSync(() => this.#write([{ key, value }]));
  }
  async initialize(entries) {
    this.#assertOpen();
    validateInitialEntries(entries);
    for (const { key, value } of entries) this.#validate(key, value);
    this.storage.transactionSync(() => {
      if (entries.every(({ key }) => this.#read(key) === null)) this.#write(entries);
    });
  }
  async compareAndSwap(key, expected, value) {
    this.#validate(key, value);
    return this.storage.transactionSync(() => {
      const current = this.#read(key);
      const matches = expected === null ? current === null : current !== null && expected.byteLength === current.byteLength && expected.every((byte, index) => byte === current[index]);
      if (matches) this.#write([{ key, value }]);
      return matches;
    });
  }
  usageBytes() {
    this.#assertOpen();
    const value = this.storage.kv.get(this.#prefix + "usage");
    return value === void 0 ? 0 : readNonnegativeBytes(value);
  }
  close() {
    this.#closed = true;
  }
  #assertOpen() {
    if (this.#closed) throw new Error("BYTES_STORE_CLOSED");
  }
  #validate(key, value) {
    this.#assertOpen();
    validateSqliteByteKey(key);
    if (!(value instanceof Uint8Array) || value.byteLength > this.#limits.maxValueBytes) {
      throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    }
  }
  #read(key) {
    const value = this.storage.kv.get(this.#prefix + "bytes:" + key);
    if (value === void 0) return null;
    if (!(value instanceof Uint8Array)) throw new Error("BYTES_STORE_VALUE_CORRUPT");
    return value;
  }
  #write(entries) {
    const used = entries.reduce((bytes, { key, value }) => bytes - (this.#read(key)?.byteLength ?? 0) + value.byteLength, this.usageBytes());
    if (!Number.isSafeInteger(used) || used < 0) throw new Error("BYTES_STORE_USAGE_CORRUPT");
    if (used > this.#limits.quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    for (const { key, value } of entries) this.storage.kv.put(this.#prefix + "bytes:" + key, value.slice());
    this.storage.kv.put(this.#prefix + "usage", used);
  }
};
function validateInitialEntries(entries) {
  if (entries.length === 0 || entries.length > 8 || new Set(entries.map(({ key }) => key)).size !== entries.length) {
    throw new Error("BYTES_STORE_INITIALIZATION_INVALID");
  }
}
function readNonnegativeBytes(value) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0)
    throw new Error("BYTES_STORE_USAGE_CORRUPT");
  return value;
}

// packages/peer-session/src/celld.ts
async function importCelldSigningIdentity(publicKey, pkcs8Hex) {
  if (pkcs8Hex === void 0) throw new Error("CELLD_SIGNING_SECRET_MISSING");
  if (pkcs8Hex.length < 2 || pkcs8Hex.length > 512 || !/^(?:[0-9a-f]{2})+$/u.test(pkcs8Hex)) {
    throw new Error("CELLD_SIGNING_SECRET_INVALID");
  }
  const bytes = hexToBytes(pkcs8Hex);
  try {
    const privateKey = await importEd25519PrivateKey(bytes, false);
    const identity = { publicKey, privateKey };
    await verifyDeviceSigner(identity);
    return Object.freeze(identity);
  } catch {
    throw new Error("CELLD_SIGNING_SECRET_INVALID");
  } finally {
    bytes.fill(0);
  }
}
async function openCelldDevice(options) {
  const store = new CelldBytesStore(options.storage, options.metadataLimits);
  const openDataStorage = options.openDataStorage;
  try {
    return await openApplicationDevice({
      store,
      ...options.create === void 0 ? {} : { create: options.create },
      ...options.managedSigner === void 0 ? {} : { managedSigner: options.managedSigner },
      ...openDataStorage === void 0 ? {} : {
        openStorage: () => {
          const data = new CelldBytesStore(openDataStorage(), options.dataLimits);
          return { store: data, close: () => data.close() };
        }
      },
      close: () => store.close()
    });
  } catch (error) {
    store.close();
    throw error;
  }
}
export {
  CelldBytesStore,
  CelldPrivateBytesStore,
  createApplicationSession,
  importCelldSigningIdentity,
  openCelldDevice
};
