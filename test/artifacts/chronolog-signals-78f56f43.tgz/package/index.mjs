// packages/canonical/src/errors.ts
var CanonicalError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.details = details;
    this.name = "CanonicalError";
  }
  code;
  details;
};
function canonicalInvariant(condition, code, message, details) {
  if (!condition) throw new CanonicalError(code, message, details);
}

// packages/canonical/src/bytes.ts
var textEncoder = new TextEncoder();
var fatalTextDecoder = new TextDecoder("utf-8", { fatal: true });
function utf8(value) {
  const encoded = textEncoder.encode(value);
  try {
    if (fatalTextDecoder.decode(encoded) !== value) throw new CanonicalError("INVALID_UTF8", "Text contains an unpaired UTF-16 surrogate");
  } catch (error) {
    if (error instanceof CanonicalError) throw error;
    throw new CanonicalError("INVALID_UTF8", "Text cannot be represented as canonical UTF-8");
  }
  return encoded;
}
function decodeUtf8(value) {
  try {
    return fatalTextDecoder.decode(value);
  } catch {
    throw new CanonicalError("INVALID_UTF8", "Bytes are not valid UTF-8");
  }
}
function concatBytes(...parts) {
  const size = parts.reduce((sum, part) => sum + part.length, 0);
  const result = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}
function compareBytes(left, right) {
  const size = Math.min(left.length, right.length);
  for (let index = 0; index < size; index += 1) {
    const difference = left[index] - right[index];
    if (difference !== 0) return difference < 0 ? -1 : 1;
  }
  return left.length === right.length ? 0 : left.length < right.length ? -1 : 1;
}
function equalBytes(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}
var hexPairs = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, "0"));
function bytesToHex(value) {
  let result = "";
  for (const byte of value) result += hexPairs[byte];
  return result;
}

// packages/canonical/src/cbor.ts
var DEFAULT_DECODE_LIMITS = Object.freeze({
  maxBytes: 16 * 1024 * 1024,
  maxDepth: 64,
  maxArrayItems: 1e6,
  maxMapItems: 1e5,
  maxTextBytes: 4 * 1024 * 1024,
  maxBlobBytes: 16 * 1024 * 1024
});
var MAX_UINT64 = (1n << 64n) - 1n;
var POSITIVE_BIGNUM_TAG = 2n;
var NEGATIVE_BIGNUM_TAG = 3n;
function encodeHead(major, value) {
  canonicalInvariant(value >= 0n && value <= MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR integer is outside uint64 range");
  if (value < 24n) return Uint8Array.of(major << 5 | Number(value));
  if (value <= 0xffn) return Uint8Array.of(major << 5 | 24, Number(value));
  if (value <= 0xffffn) return Uint8Array.of(major << 5 | 25, Number(value >> 8n), Number(value & 0xffn));
  if (value <= 0xffffffffn) {
    const bytes2 = new Uint8Array(5);
    bytes2[0] = major << 5 | 26;
    new DataView(bytes2.buffer).setUint32(1, Number(value), false);
    return bytes2;
  }
  const bytes = new Uint8Array(9);
  bytes[0] = major << 5 | 27;
  new DataView(bytes.buffer).setBigUint64(1, value, false);
  return bytes;
}
function magnitudeBytes(value) {
  canonicalInvariant(value > MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR bignum must exceed uint64 range");
  const octets = [];
  for (let remaining = value; remaining > 0n; remaining >>= 8n) octets.push(Number(remaining & 0xffn));
  octets.reverse();
  return Uint8Array.from(octets);
}
function encodeBigint(value) {
  const negative = value < 0n;
  const magnitude = negative ? -1n - value : value;
  if (magnitude <= MAX_UINT64) return encodeHead(negative ? 1 : 0, magnitude);
  const bytes = magnitudeBytes(magnitude);
  return concatBytes(
    encodeHead(6, negative ? NEGATIVE_BIGNUM_TAG : POSITIVE_BIGNUM_TAG),
    encodeHead(2, BigInt(bytes.length)),
    bytes
  );
}
function isMap(value) {
  return value instanceof Map;
}
function encodeCanonicalCbor(value) {
  if (value === null) return Uint8Array.of(246);
  if (value === false) return Uint8Array.of(244);
  if (value === true) return Uint8Array.of(245);
  if (typeof value === "bigint") return encodeBigint(value);
  if (typeof value === "string") {
    const bytes = utf8(value);
    return concatBytes(encodeHead(3, BigInt(bytes.length)), bytes);
  }
  if (value instanceof Uint8Array) return concatBytes(encodeHead(2, BigInt(value.length)), value);
  if (Array.isArray(value)) return concatBytes(encodeHead(4, BigInt(value.length)), ...value.map(encodeCanonicalCbor));
  if (isMap(value)) {
    const entries = [...value].map(([key, item]) => ({ key: encodeCanonicalCbor(key), value: encodeCanonicalCbor(item) })).sort((a, b) => a.key.length === b.key.length ? compareBytes(a.key, b.key) : a.key.length - b.key.length);
    for (let index = 1; index < entries.length; index += 1) canonicalInvariant(!equalBytes(entries[index - 1].key, entries[index].key), "CBOR_NON_CANONICAL", "Duplicate canonical CBOR map key");
    return concatBytes(encodeHead(5, BigInt(entries.length)), ...entries.flatMap((entry) => [entry.key, entry.value]));
  }
  throw new CanonicalError("SCHEMA_INVALID", "Value is not supported by the deterministic CBOR profile");
}
var Decoder = class {
  constructor(input, limits) {
    this.input = input;
    this.limits = limits;
    canonicalInvariant(input.length <= limits.maxBytes, "CBOR_LIMIT_EXCEEDED", "CBOR input exceeds byte limit");
  }
  input;
  limits;
  offset = 0;
  decode() {
    const value = this.value(0);
    canonicalInvariant(this.offset === this.input.length, "CBOR_INVALID", "Trailing bytes after CBOR value");
    return value;
  }
  byte() {
    canonicalInvariant(this.offset < this.input.length, "CBOR_INVALID", "Unexpected end of CBOR input");
    return this.input[this.offset++];
  }
  bytes(size) {
    canonicalInvariant(Number.isSafeInteger(size) && size >= 0 && this.offset + size <= this.input.length, "CBOR_INVALID", "Invalid or truncated CBOR byte range");
    const value = this.input.slice(this.offset, this.offset + size);
    this.offset += size;
    return value;
  }
  argument(additional) {
    if (additional < 24) return BigInt(additional);
    const read = (size) => {
      const bytes = this.bytes(size);
      const view = new DataView(bytes.buffer, bytes.byteOffset, size);
      return size === 1 ? BigInt(bytes[0]) : size === 2 ? BigInt(view.getUint16(0, false)) : size === 4 ? BigInt(view.getUint32(0, false)) : view.getBigUint64(0, false);
    };
    if (additional === 24) {
      const v = read(1);
      canonicalInvariant(v >= 24n, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 25) {
      const v = read(2);
      canonicalInvariant(v > 0xffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 26) {
      const v = read(4);
      canonicalInvariant(v > 0xffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 27) {
      const v = read(8);
      canonicalInvariant(v > 0xffffffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 31) throw new CanonicalError("CBOR_NON_CANONICAL", "Indefinite-length CBOR is prohibited");
    throw new CanonicalError("CBOR_INVALID", "Reserved CBOR additional information");
  }
  bignum(tag, depth) {
    canonicalInvariant(tag === POSITIVE_BIGNUM_TAG || tag === NEGATIVE_BIGNUM_TAG, "CBOR_INVALID", "Unsupported CBOR tag");
    canonicalInvariant(depth < this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    canonicalInvariant(major === 2, "CBOR_INVALID", "CBOR bignum payload must be a byte string");
    const argument = this.argument(additional);
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR bignum is too large");
    const size = Number(argument);
    canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR bignum exceeds blob limit");
    const bytes = this.bytes(size);
    canonicalInvariant(bytes.length > 8 && bytes[0] !== 0, "CBOR_NON_CANONICAL", "CBOR bignum is not minimally encoded");
    let magnitude = 0n;
    for (const byte of bytes) magnitude = magnitude << 8n | BigInt(byte);
    canonicalInvariant(magnitude > MAX_UINT64, "CBOR_NON_CANONICAL", "CBOR bignum must use the ordinary integer representation");
    return tag === POSITIVE_BIGNUM_TAG ? magnitude : -1n - magnitude;
  }
  value(depth) {
    canonicalInvariant(depth <= this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    if (major === 7) {
      if (additional === 20) return false;
      if (additional === 21) return true;
      if (additional === 22) return null;
      throw new CanonicalError("CBOR_INVALID", "Floating point and unsupported simple CBOR values are prohibited");
    }
    const argument = this.argument(additional);
    if (major === 6) return this.bignum(argument, depth + 1);
    if (major === 0) return argument;
    if (major === 1) return -1n - argument;
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR collection is too large");
    const size = Number(argument);
    if (major === 2) {
      canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR blob exceeds limit");
      return this.bytes(size);
    }
    if (major === 3) {
      canonicalInvariant(size <= this.limits.maxTextBytes, "CBOR_LIMIT_EXCEEDED", "CBOR text exceeds limit");
      return decodeUtf8(this.bytes(size));
    }
    if (major === 4) {
      canonicalInvariant(size <= this.limits.maxArrayItems, "CBOR_LIMIT_EXCEEDED", "CBOR array exceeds item limit");
      return Array.from({ length: size }, () => this.value(depth + 1));
    }
    if (major === 5) {
      canonicalInvariant(size <= this.limits.maxMapItems, "CBOR_LIMIT_EXCEEDED", "CBOR map exceeds item limit");
      const map = /* @__PURE__ */ new Map();
      let previous;
      for (let index = 0; index < size; index += 1) {
        const start = this.offset, key = this.value(depth + 1);
        canonicalInvariant(typeof key === "bigint" || typeof key === "string" || key instanceof Uint8Array, "CBOR_INVALID", "Unsupported CBOR map key");
        const encoded = this.input.slice(start, this.offset);
        if (previous !== void 0) canonicalInvariant(previous.length === encoded.length ? compareBytes(previous, encoded) < 0 : previous.length < encoded.length, "CBOR_NON_CANONICAL", "CBOR map keys are duplicate or incorrectly ordered");
        previous = encoded;
        map.set(key, this.value(depth + 1));
      }
      return map;
    }
    throw new CanonicalError("CBOR_INVALID", `Unsupported CBOR major type ${major}`);
  }
};
function decodeCanonicalCbor(input, limits) {
  return new Decoder(input, limits).decode();
}
function assertCanonicalCbor(input, limits) {
  const value = decodeCanonicalCbor(input, limits);
  canonicalInvariant(equalBytes(encodeCanonicalCbor(value), input), "CBOR_NON_CANONICAL", "CBOR bytes are not canonical");
  return value;
}

// packages/canonical/src/hash.ts
var HASH_DOMAINS = Object.freeze({
  transaction: "chronolog/transaction",
  schema: "chronolog/schema",
  executionManifest: "chronolog/execution-manifest",
  queryResult: "chronolog/query-result",
  expectation: "chronolog/expectation",
  module: "chronolog/module",
  entropy: "chronolog/entropy",
  platformObject: "chronolog/platform-object",
  genesis: "chronolog/genesis/v1",
  op: "chronolog/op/v1",
  envelope: "chronolog/envelope/v1",
  state: "chronolog/state/v1",
  cas: "chronolog/cas/v1",
  history: "chronolog/history/v1",
  revision: "chronolog/revision/v1"
});

// packages/signals/src/payload.ts
function assertSignalTopic(topic) {
  if (typeof topic !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._/-]*$/u.test(topic) || topic.length > 128) throw new Error("SIGNAL_TOPIC_INVALID");
}
function canonicalSignalPayload(payload) {
  let nodes = 0;
  const visit = (value, depth) => {
    if (depth > 32 || ++nodes > 4096) throw new Error("SIGNAL_PAYLOAD_TOO_COMPLEX");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw new Error("SIGNAL_PAYLOAD_INVALID");
      return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
      if (Reflect.ownKeys(value).length !== value.length + 1) throw new Error("SIGNAL_PAYLOAD_INVALID");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, i);
        if (descriptor === void 0 || !("value" in descriptor) || !descriptor.enumerable) throw new Error("SIGNAL_PAYLOAD_INVALID");
        entries.push(visit(descriptor.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    if (typeof value !== "object" || value === null || Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null || Reflect.ownKeys(value).length !== Object.keys(value).length) throw new Error("SIGNAL_PAYLOAD_INVALID");
    return `{${Object.keys(value).sort().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!("value" in descriptor)) throw new Error("SIGNAL_PAYLOAD_INVALID");
      return `${JSON.stringify(key)}:${visit(descriptor.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const result = visit(payload, 0);
  if (new TextEncoder().encode(result).length > 16384) throw new Error("SIGNAL_FRAME_TOO_LARGE");
  return result;
}

// packages/signals/src/index.ts
var SIGNAL_DOMAIN = "chronolog/signal/v1";
var SIGNAL_STREAM_DOMAIN = "chronolog/signal/v2";
var MAX_SIGNAL_BYTES = 16384;
async function generateSignalIdentity() {
  const keys = await crypto.subtle.generateKey("Ed25519", true, ["sign", "verify"]);
  return { publicKeyBytes: new Uint8Array(await crypto.subtle.exportKey("raw", keys.publicKey)), privateKey: keys.privateKey };
}
var SignalError = class extends Error {
  constructor(code, message = code) {
    super(message);
    this.code = code;
    this.name = "SignalError";
  }
  code;
};
var SignalChannel = class {
  #options;
  #authorId;
  #session = crypto.getRandomValues(new Uint8Array(32));
  #sessions = /* @__PURE__ */ new Map();
  #subscriptions = /* @__PURE__ */ new Set();
  #routes = /* @__PURE__ */ new Set();
  /** Detached callbacks retain their quota until the actual operation settles. */
  #retiring = /* @__PURE__ */ new Set();
  #lifetime = new AbortController();
  #ttl;
  #skew;
  #maxSessions;
  #maxSequences;
  #maxRemembered;
  #maxSends;
  #maxReceives;
  #maxRoutes;
  #maxSubscriptions;
  #maxQueuedSignals;
  #maxQueuedBytes;
  #maxRetainedLatest;
  #sendTimeout;
  #verifyKeys = /* @__PURE__ */ new Map();
  #retainedLatest = /* @__PURE__ */ new Map();
  #sequence = 0;
  #sendTail = Promise.resolve();
  #pendingSends = 0;
  #pendingReceives = 0;
  #remembered = 0;
  #observedTime = 0;
  #lastPruneAt = 0;
  constructor(options) {
    if (typeof options.scope !== "string" || options.scope.length === 0 || new TextEncoder().encode(options.scope).length > 256 || !(options.identity.publicKeyBytes instanceof Uint8Array) || options.identity.publicKeyBytes.length !== 32 || typeof options.authorize !== "function") throw new SignalError("SIGNAL_CONFIGURATION_INVALID");
    const credential = typeof options.credential === "function" ? options.credential : credentialBytes(options.credential);
    this.#options = {
      ...options,
      identity: { ...options.identity, publicKeyBytes: options.identity.publicKeyBytes.slice() },
      ...credential === void 0 ? {} : { credential }
    };
    this.#authorId = bytesToHex(options.identity.publicKeyBytes);
    this.#ttl = bound(options.maxTtlMs ?? 3e4, 1, 6e4);
    this.#skew = bound(options.maxClockSkewMs ?? 2e3, 0, 1e4);
    this.#maxSessions = bound(options.maxSessions ?? 1024, 1, 65536);
    this.#maxSequences = bound(options.maxSequencesPerSession ?? 1024, 1, 65536);
    this.#maxRemembered = bound(options.maxRememberedSignals ?? 8192, 1, 1048576);
    this.#maxSends = bound(options.maxPendingSends ?? 32, 1, 1024);
    this.#maxReceives = bound(options.maxPendingReceives ?? 32, 1, 1024);
    this.#maxRoutes = bound(options.maxRoutes ?? 64, 1, 1024);
    this.#maxSubscriptions = bound(options.maxSubscriptions ?? 16, 1, 1024);
    this.#maxQueuedSignals = bound(options.maxQueuedSignals ?? 64, 1, 4096);
    this.#maxQueuedBytes = bound(options.maxQueuedBytes ?? 262144, 1, 16777216);
    this.#maxRetainedLatest = bound(options.maxRetainedLatest ?? 128, 0, 4096);
    this.#sendTimeout = bound(options.sendTimeoutMs ?? 1e4, 1, 12e4);
    if (options.trySend !== void 0) this.attachRoute({ trySend: options.trySend });
  }
  get delivery() {
    return this.#options.relay === true ? "application" : "neighbors";
  }
  attachRoute(transport) {
    this.#assertOpen();
    if (typeof transport.trySend !== "function") throw new SignalError("SIGNAL_TRANSPORT_INVALID");
    if (this.#routes.size + this.#retiring.size >= this.#maxRoutes) throw new SignalError("SIGNAL_ROUTE_QUOTA_EXCEEDED");
    const route = {
      trySend: transport.trySend.bind(transport),
      lifetime: new AbortController(),
      busy: false,
      retired: false,
      rejections: { total: 0, clockSkew: 0, expired: 0, unauthorized: 0, duplicate: 0, capacity: 0 },
      ...transport.close === void 0 ? {} : { close: transport.close.bind(transport) }
    };
    this.#routes.add(route);
    return {
      receive: (frame) => this.#enqueueReceive(frame, route),
      close: () => this.#detach(route),
      get diagnostics() {
        return { ...route.rejections };
      }
    };
  }
  send(topic, payload, options = {}) {
    try {
      if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
      this.#assertOpen();
      options.signal?.throwIfAborted();
      if (this.#routes.size === 0 && this.#options.localEcho !== true) throw new SignalError("SIGNAL_ROUTE_UNAVAILABLE");
      const routes = [...this.#routes];
      if (this.#pendingSends >= this.#maxSends) throw new SignalError("SIGNAL_BACKPRESSURE");
      assertSignalTopic(topic);
      const encodedPayload = canonicalSignalPayload(payload);
      const stream = options.stream === void 0 ? void 0 : checkedStream(options.stream);
      const ttlMs = bound(options.ttlMs ?? Math.min(5e3, this.#ttl), 1, this.#ttl, "SIGNAL_TTL_INVALID");
      const issuedAtMs = this.#now(), expiresAtMs = issuedAtMs + ttlMs;
      if (!Number.isSafeInteger(expiresAtMs)) throw new SignalError("SIGNAL_CLOCK_INVALID");
      const expiry = new AbortController();
      const timer = setTimeout(() => expiry.abort(new SignalError("SIGNAL_SEND_TIMEOUT")), Math.min(ttlMs, this.#sendTimeout));
      const signal = AbortSignal.any([this.#lifetime.signal, expiry.signal, ...options.signal === void 0 ? [] : [options.signal]]);
      this.#pendingSends += 1;
      let started = false;
      const task = this.#sendTail.then(() => {
        signal.throwIfAborted();
        started = true;
        const operation = (async () => {
          const configured = this.#options.credential;
          const credential = credentialBytes(typeof configured === "function" ? await configured(topic, { signal }) : configured);
          const authorization = { scope: this.#options.scope, authorId: this.#options.identity.publicKeyBytes.slice(), topic, credential: credential ?? null, ...stream === void 0 ? {} : { stream } };
          await this.#authorize(authorization, signal);
          if (this.#sequence >= Number.MAX_SAFE_INTEGER) throw new SignalError("SIGNAL_SEQUENCE_EXHAUSTED");
          const sequence = ++this.#sequence;
          const fields = [
            stream === void 0 ? 1n : 2n,
            stream === void 0 ? SIGNAL_DOMAIN : SIGNAL_STREAM_DOMAIN,
            this.#options.scope,
            this.#options.identity.publicKeyBytes,
            credential ?? null,
            this.#session,
            BigInt(sequence),
            BigInt(issuedAtMs),
            BigInt(expiresAtMs),
            topic,
            encodedPayload,
            ...stream === void 0 ? [] : [JSON.stringify(stream)]
          ];
          const signature = new Uint8Array(await crypto.subtle.sign(
            "Ed25519",
            this.#options.identity.privateKey,
            encodeCanonicalCbor(fields).slice().buffer
          ));
          const frame = encodeCanonicalCbor([...fields, signature]);
          if (frame.length > MAX_SIGNAL_BYTES) throw new SignalError("SIGNAL_FRAME_TOO_LARGE");
          const value = {
            scope: this.#options.scope,
            authorId: this.#authorId,
            sessionId: bytesToHex(this.#session),
            sequence,
            topic,
            payload: JSON.parse(encodedPayload),
            issuedAtMs,
            expiresAtMs,
            ...stream === void 0 ? {} : { stream }
          };
          await this.#authorize(authorization, signal);
          this.#assertFresh(value);
          if (!this.#remember(value)) throw new SignalError("SIGNAL_BACKPRESSURE");
          const local = this.#options.localEcho === true;
          if (local) {
            this.#deliver(value, frame.length);
            if (routes.length > 0) void this.#dispatch({ value, authorization, frame }, routes, signal, false).catch(() => void 0);
          }
          if (!local && !await this.#dispatch({ value, authorization, frame }, routes, signal, true)) {
            this.#forget(value);
            throw new SignalError("SIGNAL_BACKPRESSURE");
          }
          return structuredClone(value);
        })().finally(() => {
          clearTimeout(timer);
          this.#pendingSends -= 1;
        });
        return interrupted(operation, signal);
      }).finally(() => {
        if (!started) {
          clearTimeout(timer);
          this.#pendingSends -= 1;
        }
      });
      this.#sendTail = task.catch(() => void 0);
      return interrupted(task, signal);
    } catch (error) {
      return Promise.reject(error);
    }
  }
  /** Standalone receive validates and delivers without inferring a relay source. */
  receive(frame) {
    return this.#enqueueReceive(frame);
  }
  #enqueueReceive(input, route) {
    try {
      this.#assertOpen();
      if (!(input instanceof Uint8Array) || input.byteLength > MAX_SIGNAL_BYTES) throw new SignalError("SIGNAL_FRAME_TOO_LARGE");
      if (route?.lifetime.signal.aborted === true) throw new SignalError("SIGNAL_ROUTE_CLOSED");
      if (this.#pendingReceives >= this.#maxReceives) return Promise.resolve(this.#reject(route, "capacity"));
      const frame = input.slice();
      const routes = [...this.#routes].filter((attached) => attached !== route);
      this.#pendingReceives += 1;
      const expiry = new AbortController();
      const timer = setTimeout(() => expiry.abort(new SignalError("SIGNAL_RECEIVE_TIMEOUT")), this.#ttl);
      const signal = AbortSignal.any([this.#lifetime.signal, expiry.signal, ...route === void 0 ? [] : [route.lifetime.signal]]);
      const operation = (async () => {
        signal.throwIfAborted();
        const verified = await this.#verify(frame, signal, route);
        if (verified === null || !this.#remember(verified.value, route)) return null;
        this.#deliver(verified.value, frame.length);
        if (this.#options.relay === true) await this.#dispatch(verified, routes, signal, false);
        return structuredClone(verified.value);
      })().finally(() => {
        clearTimeout(timer);
        this.#pendingReceives -= 1;
      });
      return interrupted(operation, signal);
    } catch (error) {
      return Promise.reject(error);
    }
  }
  async #verify(bytes, signal, route) {
    const frame = assertCanonicalCbor(bytes, {
      maxBytes: MAX_SIGNAL_BYTES,
      maxDepth: 2,
      maxArrayItems: 13,
      maxMapItems: 0,
      maxTextBytes: MAX_SIGNAL_BYTES,
      maxBlobBytes: 1024
    });
    if (!Array.isArray(frame) || !(frame.length === 12 && frame[0] === 1n && frame[1] === SIGNAL_DOMAIN || frame.length === 13 && frame[0] === 2n && frame[1] === SIGNAL_STREAM_DOMAIN) || frame[2] !== this.#options.scope || !(frame[3] instanceof Uint8Array) || frame[3].length !== 32 || frame[4] !== null && (!(frame[4] instanceof Uint8Array) || frame[4].length > 1024) || !(frame[5] instanceof Uint8Array) || frame[5].length !== 32 || typeof frame[6] !== "bigint" || typeof frame[7] !== "bigint" || typeof frame[8] !== "bigint" || typeof frame[9] !== "string" || typeof frame[10] !== "string" || !(frame[frame.length - 1] instanceof Uint8Array) || frame[frame.length - 1].length !== 64) throw new SignalError("SIGNAL_FRAME_INVALID");
    assertSignalTopic(frame[9]);
    const stream = frame.length === 13 ? decodeStream(frame[11]) : void 0;
    const payload = JSON.parse(frame[10]);
    if (canonicalSignalPayload(payload) !== frame[10]) throw new SignalError("SIGNAL_PAYLOAD_INVALID");
    const value = {
      scope: this.#options.scope,
      authorId: bytesToHex(frame[3]),
      sessionId: bytesToHex(frame[5]),
      sequence: Number(frame[6]),
      issuedAtMs: Number(frame[7]),
      expiresAtMs: Number(frame[8]),
      topic: frame[9],
      payload,
      ...stream === void 0 ? {} : { stream }
    };
    this.#assertClockFields(value);
    let key = this.#verifyKeys.get(value.authorId);
    if (key === void 0) {
      key = await crypto.subtle.importKey("raw", frame[3].slice().buffer, "Ed25519", false, ["verify"]);
      if (this.#verifyKeys.size >= 256) {
        const oldest = this.#verifyKeys.keys().next().value;
        if (oldest !== void 0) this.#verifyKeys.delete(oldest);
      }
      this.#verifyKeys.set(value.authorId, key);
    }
    if (!await crypto.subtle.verify("Ed25519", key, frame[frame.length - 1].slice().buffer, encodeCanonicalCbor(frame.slice(0, -1)).slice().buffer)) {
      throw new SignalError("SIGNAL_SIGNATURE_INVALID");
    }
    const credential = frame[4];
    const authorization = { scope: value.scope, authorId: frame[3].slice(), topic: value.topic, credential: credential?.slice() ?? null, ...stream === void 0 ? {} : { stream } };
    if (!await this.#allowed(authorization, signal)) return this.#reject(route, "unauthorized");
    const now = this.#now();
    if (value.issuedAtMs > now + this.#skew) return this.#reject(route, "clockSkew");
    if (value.expiresAtMs <= now) return this.#reject(route, "expired");
    return { value, authorization, frame: bytes };
  }
  async #allowed(input, signal) {
    signal.throwIfAborted();
    const allowed = await this.#options.authorize(structuredClone(input), { signal });
    signal.throwIfAborted();
    return allowed;
  }
  async #authorize(input, signal) {
    if (!await this.#allowed(input, signal)) throw new SignalError("SIGNAL_UNAUTHORIZED");
  }
  async #dispatch(verified, eligible, signal, required) {
    const attached = eligible.filter((route) => !route.lifetime.signal.aborted);
    if (required && attached.length === 0) throw new SignalError("SIGNAL_ROUTE_UNAVAILABLE");
    const routes = attached.filter((route) => !route.busy);
    if (routes.length === 0) return false;
    const attempts = routes.map((route) => {
      route.busy = true;
      let handedOff = false, settled = false;
      const deadline = new AbortController();
      const timer = setTimeout(() => {
        const reason = new SignalError("SIGNAL_SEND_TIMEOUT");
        deadline.abort(reason);
        if (handedOff && !settled) this.#detach(route, true, reason);
      }, Math.max(1, Math.min(this.#sendTimeout, verified.value.expiresAtMs - this.#now())));
      const lifetime = AbortSignal.any([signal, route.lifetime.signal, deadline.signal]);
      const operation = (async () => {
        await this.#authorize(verified.authorization, lifetime);
        this.#assertFresh(verified.value);
        handedOff = true;
        const result = await route.trySend(verified.frame.slice(), { signal: lifetime });
        if (typeof result !== "boolean") {
          throw new SignalError("SIGNAL_TRANSPORT_RESULT_INVALID");
        }
        return result;
      })().catch((error) => {
        if (handedOff && (!lifetime.aborted || error !== lifetime.reason)) this.#detach(route, true, error);
        throw error;
      }).finally(() => {
        settled = true;
        route.busy = false;
        this.#retiring.delete(route);
        clearTimeout(timer);
      });
      return interrupted(operation, lifetime);
    });
    if (required) {
      const refused = new Error("Signal dispatch refused");
      try {
        return await Promise.any(attempts.map(async (attempt) => {
          if (!await attempt) throw refused;
          return true;
        }));
      } catch (error) {
        if (error instanceof AggregateError) {
          const failures = error.errors.filter((value) => value !== refused);
          if (failures.length === 0) return false;
          if (failures.length === 1) throw failures[0];
        }
        throw new SignalError("SIGNAL_SEND_FAILED");
      }
    }
    return (await Promise.allSettled(attempts)).some((result) => result.status === "fulfilled" && result.value);
  }
  #pruneRemembered(now) {
    this.#lastPruneAt = now;
    for (const [id, progress] of this.#sessions) {
      for (const [sequence, expiresAtMs] of progress.seen) if (expiresAtMs <= now) {
        progress.seen.delete(sequence);
        this.#remembered -= 1;
      }
      if (progress.seen.size === 0) this.#sessions.delete(id);
    }
  }
  #reject(route, reason) {
    if (route !== void 0) {
      route.rejections.total = Math.min(Number.MAX_SAFE_INTEGER, route.rejections.total + 1);
      route.rejections[reason] = Math.min(Number.MAX_SAFE_INTEGER, route.rejections[reason] + 1);
    }
    return null;
  }
  #remember(value, route) {
    const now = this.#now();
    const key = `${value.authorId}/${value.sessionId}`;
    let previous = this.#sessions.get(key);
    const existingExpiry = previous?.seen.get(value.sequence);
    if (existingExpiry !== void 0) {
      if (existingExpiry > now) {
        this.#reject(route, "duplicate");
        return false;
      }
      previous.seen.delete(value.sequence);
      this.#remembered -= 1;
      if (previous.seen.size === 0) {
        this.#sessions.delete(key);
        previous = void 0;
      }
    }
    if (now - this.#lastPruneAt >= 1e3 || previous === void 0 && this.#sessions.size >= this.#maxSessions || (previous?.seen.size ?? 0) >= this.#maxSequences || this.#remembered >= this.#maxRemembered) {
      this.#pruneRemembered(now);
      previous = this.#sessions.get(key);
    }
    if (previous === void 0 && this.#sessions.size >= this.#maxSessions || (previous?.seen.size ?? 0) >= this.#maxSequences || this.#remembered >= this.#maxRemembered) {
      this.#reject(route, "capacity");
      return false;
    }
    const progress = previous ?? { seen: /* @__PURE__ */ new Map() };
    progress.seen.set(value.sequence, value.expiresAtMs);
    this.#remembered += 1;
    this.#sessions.set(key, progress);
    return true;
  }
  #forget(value) {
    const key = `${value.authorId}/${value.sessionId}`, session = this.#sessions.get(key);
    if (session?.seen.delete(value.sequence) === true) this.#remembered -= 1;
    if (session?.seen.size === 0) this.#sessions.delete(key);
  }
  #deliver(value, bytes) {
    const now = this.#now();
    const streamKey = JSON.stringify([value.authorId, value.sessionId, value.topic, value.stream?.endpointId ?? null, value.stream?.endpointIncarnation ?? null, value.stream?.streamId ?? null, value.stream?.target ?? null]);
    if (this.#maxRetainedLatest > 0 && value.expiresAtMs > now) {
      const prior = this.#retainedLatest.get(streamKey);
      if (prior === void 0 || prior.value.sequence < value.sequence || prior.value.expiresAtMs <= now) {
        if (prior !== void 0) this.#retainedLatest.delete(streamKey);
        else if (this.#retainedLatest.size >= this.#maxRetainedLatest) {
          for (const [id, entry] of this.#retainedLatest) if (entry.value.expiresAtMs <= now) this.#retainedLatest.delete(id);
          if (this.#retainedLatest.size >= this.#maxRetainedLatest) {
            const oldest = this.#retainedLatest.keys().next().value;
            if (oldest !== void 0) this.#retainedLatest.delete(oldest);
          }
        }
        this.#retainedLatest.set(streamKey, { value: structuredClone(value), bytes });
      }
    }
    for (const subscriber of this.#subscriptions) {
      if (subscriber.topics !== null && !subscriber.topics.has(value.topic)) continue;
      if (subscriber.streams !== null && !subscriber.streams.some((selector) => matchesStream(value, selector))) continue;
      for (let index = subscriber.pending.length - 1; index >= 0; index -= 1) {
        if (subscriber.pending[index].value.expiresAtMs <= now) subscriber.bytes -= subscriber.pending.splice(index, 1)[0].bytes;
      }
      for (const [id, latest] of subscriber.latest) if (latest.retainThroughMs <= now) subscriber.latest.delete(id);
      const key = streamKey;
      if (subscriber.mode === "latest") {
        const previous = subscriber.latest.get(key);
        if (previous !== void 0 && previous.sequence >= value.sequence) continue;
        if (previous === void 0 && subscriber.latest.size >= this.#maxQueuedSignals) {
          this.#overflow(subscriber);
          continue;
        }
        subscriber.latest.set(key, { sequence: value.sequence, retainThroughMs: now + this.#ttl + this.#skew });
        const index = subscriber.pending.findIndex((item) => item.key === key);
        if (index !== -1) subscriber.bytes -= subscriber.pending.splice(index, 1)[0].bytes;
      }
      if (subscriber.pending.length >= this.#maxQueuedSignals || subscriber.bytes + bytes > this.#maxQueuedBytes) {
        this.#overflow(subscriber);
      } else {
        subscriber.pending.push({ value: structuredClone(value), bytes, key });
        subscriber.bytes += bytes;
      }
      subscriber.wake?.();
    }
  }
  #overflow(subscriber) {
    subscriber.error = new SignalError("SIGNAL_SUBSCRIPTION_OVERFLOW");
    subscriber.pending.length = 0;
    subscriber.bytes = 0;
    subscriber.latest.clear();
    subscriber.clean();
    this.#subscriptions.delete(subscriber);
    subscriber.wake?.();
  }
  subscribe(options = {}) {
    if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
    const self = this;
    return { [Symbol.asyncIterator]() {
      const controller = new AbortController();
      const signal = options.signal === void 0 ? controller.signal : AbortSignal.any([controller.signal, options.signal]);
      const iterator = self.#subscribe({ ...options, signal });
      return {
        next: () => iterator.next(),
        async return() {
          controller.abort();
          return iterator.return();
        },
        async throw(error) {
          controller.abort();
          return iterator.throw(error);
        }
      };
    } };
  }
  async *#subscribe(options) {
    this.#assertOpen();
    if (typeof options !== "object" || options === null) throw new SignalError("SIGNAL_OPTIONS_INVALID");
    const mode = options.mode ?? "all";
    if (mode !== "all" && mode !== "latest") throw new SignalError("SIGNAL_SUBSCRIPTION_MODE_INVALID");
    if (options.topics !== void 0) {
      if (!Array.isArray(options.topics) || options.topics.length > 64) throw new SignalError("SIGNAL_TOPIC_FILTER_TOO_LARGE");
      for (const topic of options.topics) {
        if (typeof topic !== "string") throw new SignalError("SIGNAL_TOPIC_FILTER_INVALID");
        assertSignalTopic(topic);
      }
    }
    const streams = options.streams === void 0 ? null : checkedSelectors(options.streams);
    if (this.#subscriptions.size >= this.#maxSubscriptions) throw new SignalError("SIGNAL_SUBSCRIPTION_QUOTA_EXCEEDED");
    const subscriber = {
      topics: options.topics === void 0 ? null : new Set(options.topics),
      streams,
      mode,
      pending: [],
      latest: /* @__PURE__ */ new Map(),
      bytes: 0,
      error: null,
      wake: null,
      clean: () => void 0
    };
    if (options.includeLatest === true) {
      if (mode !== "latest") throw new SignalError("SIGNAL_SUBSCRIPTION_MODE_INVALID");
      const now = this.#now();
      for (const [key, entry] of this.#retainedLatest) {
        if (entry.value.expiresAtMs <= now) {
          this.#retainedLatest.delete(key);
          continue;
        }
        if (subscriber.topics !== null && !subscriber.topics.has(entry.value.topic)) continue;
        if (subscriber.streams !== null && !subscriber.streams.some((selector) => matchesStream(entry.value, selector))) continue;
        if (subscriber.pending.length >= this.#maxQueuedSignals || subscriber.bytes + entry.bytes > this.#maxQueuedBytes) break;
        subscriber.latest.set(key, { sequence: entry.value.sequence, retainThroughMs: now + this.#ttl + this.#skew });
        subscriber.pending.push({ value: structuredClone(entry.value), bytes: entry.bytes, key });
        subscriber.bytes += entry.bytes;
      }
    }
    this.#subscriptions.add(subscriber);
    const signal = options.signal;
    const abort = () => {
      subscriber.pending.length = 0;
      subscriber.bytes = 0;
      subscriber.latest.clear();
      subscriber.clean();
      this.#subscriptions.delete(subscriber);
      subscriber.wake?.();
    };
    subscriber.clean = () => signal?.removeEventListener("abort", abort);
    signal?.addEventListener("abort", abort, { once: true });
    try {
      while (!this.#lifetime.signal.aborted && signal?.aborted !== true) {
        if (subscriber.error !== null) throw subscriber.error;
        const item = subscriber.pending.shift();
        if (item !== void 0) {
          subscriber.bytes -= item.bytes;
          if (item.value.expiresAtMs > this.#now()) yield structuredClone(item.value);
        } else {
          await new Promise((resolve) => {
            subscriber.wake = resolve;
            if (this.#lifetime.signal.aborted || signal?.aborted === true || subscriber.pending.length > 0 || subscriber.error !== null) resolve();
          });
          subscriber.wake = null;
        }
      }
    } finally {
      subscriber.clean();
      this.#subscriptions.delete(subscriber);
    }
  }
  close() {
    if (this.#lifetime.signal.aborted) return;
    this.#lifetime.abort(new SignalError("SIGNAL_CHANNEL_CLOSED"));
    for (const route of this.#routes) this.#detach(route);
    for (const subscriber of this.#subscriptions) {
      subscriber.pending.length = 0;
      subscriber.latest.clear();
      subscriber.clean();
      subscriber.wake?.();
    }
    this.#subscriptions.clear();
    this.#sessions.clear();
    this.#retainedLatest.clear();
    this.#verifyKeys.clear();
    this.#remembered = 0;
  }
  #detach(route, retire = false, reason = new SignalError("SIGNAL_ROUTE_CLOSED")) {
    if (route.busy) this.#retiring.add(route);
    this.#routes.delete(route);
    route.lifetime.abort(reason);
    if (retire && !route.retired) {
      route.retired = true;
      try {
        void Promise.resolve(route.close?.(reason)).catch(() => void 0);
      } catch {
      }
    }
  }
  #assertOpen() {
    this.#lifetime.signal.throwIfAborted();
  }
  #assertFresh(value) {
    this.#assertClock(value);
    if (value.expiresAtMs <= this.#now()) throw new SignalError("SIGNAL_EXPIRED");
  }
  #assertClockFields(value) {
    if (!Number.isSafeInteger(value.sequence) || value.sequence < 1 || !Number.isSafeInteger(value.issuedAtMs) || value.issuedAtMs < 0 || !Number.isSafeInteger(value.expiresAtMs) || value.expiresAtMs <= value.issuedAtMs || value.expiresAtMs - value.issuedAtMs > this.#ttl) {
      throw new SignalError("SIGNAL_CLOCK_INVALID");
    }
  }
  #assertClock(value) {
    this.#assertClockFields(value);
    if (value.issuedAtMs > this.#now() + this.#skew) throw new SignalError("SIGNAL_CLOCK_INVALID");
  }
  #now() {
    const now = bound(this.#options.now?.() ?? Date.now(), 0, Number.MAX_SAFE_INTEGER, "SIGNAL_CLOCK_INVALID");
    this.#observedTime = Math.max(this.#observedTime, now);
    return this.#observedTime;
  }
};
function credentialBytes(value) {
  if (value === void 0) return void 0;
  if (!(value instanceof Uint8Array) || value.length > 1024) throw new SignalError("SIGNAL_CREDENTIAL_INVALID");
  return value.slice();
}
function bound(value, minimum, maximum, code = "SIGNAL_BOUNDS_INVALID") {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) throw new SignalError(code);
  return value;
}
function interrupted(operation, signal) {
  return new Promise((resolve, reject) => {
    const abort = () => {
      reject(signal.reason);
      signal.removeEventListener("abort", abort);
    };
    signal.addEventListener("abort", abort, { once: true });
    void operation.then(resolve, reject).finally(() => signal.removeEventListener("abort", abort));
    if (signal.aborted) abort();
  });
}
function checkedStream(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !["streamId", "endpointId", "endpointIncarnation", "target", "stateRoot", "supersedesStream"].includes(key)) || !boundedLabel(value.streamId) || value.endpointId === void 0 !== (value.endpointIncarnation === void 0) || value.endpointId !== void 0 && !boundedLabel(value.endpointId) || value.endpointIncarnation !== void 0 && !boundedLabel(value.endpointIncarnation) || value.target !== void 0 && !boundedLabel(value.target) || value.stateRoot !== void 0 && !/^[0-9a-f]{64}$/u.test(value.stateRoot) || value.supersedesStream !== void 0 && !boundedLabel(value.supersedesStream)) throw new SignalError("SIGNAL_STREAM_INVALID");
  return {
    streamId: value.streamId,
    ...value.endpointId === void 0 ? {} : { endpointId: value.endpointId, endpointIncarnation: value.endpointIncarnation },
    ...value.target === void 0 ? {} : { target: value.target },
    ...value.stateRoot === void 0 ? {} : { stateRoot: value.stateRoot },
    ...value.supersedesStream === void 0 ? {} : { supersedesStream: value.supersedesStream }
  };
}
function decodeStream(value) {
  if (typeof value !== "string" || value.length > 2048) throw new SignalError("SIGNAL_STREAM_INVALID");
  let parsed;
  try {
    parsed = JSON.parse(value);
  } catch {
    throw new SignalError("SIGNAL_STREAM_INVALID");
  }
  const stream = checkedStream(parsed);
  if (JSON.stringify(stream) !== value) throw new SignalError("SIGNAL_STREAM_INVALID");
  return stream;
}
function boundedLabel(value) {
  return typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._:/@-]{0,127}$/u.test(value);
}
function checkedSelectors(value) {
  const keys = ["authorId", "sessionId", "streamId", "endpointId", "endpointIncarnation", "target"];
  if (!Array.isArray(value) || value.length > 64 || value.some((selector) => selector === null || typeof selector !== "object" || Array.isArray(selector) || Object.entries(selector).some(([key, item]) => !keys.includes(key) || !boundedLabel(item)))) {
    throw new SignalError("SIGNAL_STREAM_FILTER_INVALID");
  }
  return structuredClone(value);
}
function matchesStream(value, selector) {
  return (selector.authorId === void 0 || selector.authorId === value.authorId) && (selector.sessionId === void 0 || selector.sessionId === value.sessionId) && (selector.streamId === void 0 || selector.streamId === value.stream?.streamId) && (selector.endpointId === void 0 || selector.endpointId === value.stream?.endpointId) && (selector.endpointIncarnation === void 0 || selector.endpointIncarnation === value.stream?.endpointIncarnation) && (selector.target === void 0 || selector.target === value.stream?.target);
}
export {
  MAX_SIGNAL_BYTES,
  SIGNAL_DOMAIN,
  SIGNAL_STREAM_DOMAIN,
  SignalChannel,
  SignalError,
  assertSignalTopic,
  canonicalSignalPayload,
  generateSignalIdentity
};
