import {
  connectApplicationWebRtc
} from "./chunks/chunk-CQ3ASKJS.mjs";
import {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
} from "./chunks/chunk-VCWFJEFI.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-OWL5GQ66.mjs";
import "./chunks/chunk-VRR2HFJY.mjs";
export {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
