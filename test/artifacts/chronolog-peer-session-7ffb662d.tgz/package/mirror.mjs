import {
  CAS_NODE_MEDIA_TYPE,
  CAS_SUBGRAPH_MEDIA_TYPE,
  FactIdSet,
  createBytesStoreCasMirrorStore,
  createCasAdapterMirrorStore,
  createCasMirrorClient,
  createCasMirrorHandler,
  decodeCasSubgraphBundle,
  encodeCasSubgraphBundle,
  normalizeVerifiedCasNode,
  rangesNeedReply,
  reconcileRanges,
  resolveTrustedBuildOutput,
  verifyMirrorAuditAttestation,
  verifyMirrorBuildAttestation
} from "./chunks/chunk-ESNE3YIR.mjs";
import "./chunks/chunk-X5EWPYTE.mjs";
import "./chunks/chunk-OWL5GQ66.mjs";
import "./chunks/chunk-XIJQU6SK.mjs";
import {
  DEFAULT_DECODE_LIMITS,
  assertCanonicalCbor,
  encodeCanonicalCbor
} from "./chunks/chunk-VRR2HFJY.mjs";

// packages/peer-session/src/http-sync.ts
var HEX32 = /^[0-9a-f]{64}$/u;
var HTTP_SYNC_V3_MEDIA_TYPE = "application/vnd.chronolog.sync-v3+cbor";
function encodeRanges(ranges) {
  return ranges.map((r) => {
    if ("ids" in r) {
      return /* @__PURE__ */ new Map([
        ["ids", [...r.ids]],
        ["prefix", r.prefix]
      ]);
    }
    return /* @__PURE__ */ new Map([
      ["count", BigInt(r.count)],
      ["fp", r.fp],
      ["prefix", r.prefix]
    ]);
  });
}
function decodeRanges(raw) {
  if (!Array.isArray(raw)) throw new Error("HTTP_SYNC_RANGES_INVALID");
  if (raw.length > 256) throw new Error("HTTP_SYNC_TOO_MANY_RANGES");
  const out = [];
  for (const item of raw) {
    if (!(item instanceof Map)) throw new Error("HTTP_SYNC_RANGE_INVALID");
    const map = item;
    const prefix = map.get("prefix");
    if (typeof prefix !== "string") throw new Error("HTTP_SYNC_RANGE_INVALID");
    const ids = map.get("ids");
    if (ids !== void 0) {
      if (!Array.isArray(ids) || ids.length > 512) throw new Error("HTTP_SYNC_RANGE_IDS_INVALID");
      const clean = [];
      for (const id of ids) {
        if (typeof id !== "string" || !HEX32.test(id)) throw new Error("HTTP_SYNC_RANGE_ID_INVALID");
        clean.push(id);
      }
      out.push({ prefix, ids: clean });
    } else {
      const count = map.get("count");
      const fp = map.get("fp");
      if (typeof count !== "bigint" || count < 0n || !(fp instanceof Uint8Array) || fp.byteLength !== 16) {
        throw new Error("HTTP_SYNC_RANGE_SUMMARY_INVALID");
      }
      out.push({ prefix, count: Number(count), fp: fp.slice() });
    }
  }
  return out;
}
function encodePairs(items) {
  return items.map((item) => [item.id ?? item.hash ?? "", item.bytes]);
}
function decodePairs(raw, maxItems) {
  if (raw === void 0) return [];
  if (!Array.isArray(raw) || raw.length > maxItems) throw new Error("HTTP_SYNC_ITEMS_INVALID");
  const out = [];
  for (const item of raw) {
    if (!Array.isArray(item) || item.length !== 2 || typeof item[0] !== "string" || !HEX32.test(item[0]) || !(item[1] instanceof Uint8Array)) {
      throw new Error("HTTP_SYNC_ITEM_INVALID");
    }
    out.push({ id: item[0], bytes: item[1].slice() });
  }
  return out;
}
function decodeStringList(raw, maxItems) {
  if (raw === void 0) return [];
  if (!Array.isArray(raw) || raw.length > maxItems) throw new Error("HTTP_SYNC_LIST_INVALID");
  const out = [];
  for (const item of raw) {
    if (typeof item !== "string" || !HEX32.test(item)) throw new Error("HTTP_SYNC_ID_INVALID");
    out.push(item);
  }
  return out;
}
function unknownToCbor(value, depth = 0) {
  if (depth > 8 || value === null || value === void 0) return null;
  if (typeof value === "boolean" || typeof value === "string") return value;
  if (typeof value === "number") return Number.isSafeInteger(value) ? BigInt(value) : String(value);
  if (typeof value === "bigint") return value;
  if (value instanceof Uint8Array) return value;
  if (Array.isArray(value)) return value.map((v) => unknownToCbor(v, depth + 1));
  if (typeof value === "object") {
    const map = /* @__PURE__ */ new Map();
    for (const [k, v] of Object.entries(value).sort(([a], [b]) => a.localeCompare(b))) {
      if (v !== void 0) map.set(k, unknownToCbor(v, depth + 1));
    }
    return map;
  }
  return null;
}
function cborToMeta(value) {
  if (!(value instanceof Map)) return void 0;
  const out = {};
  for (const [k, v] of value) {
    if (typeof k !== "string") continue;
    if (typeof v === "bigint") out[k] = Number(v);
    else if (v instanceof Map) out[k] = cborToMeta(v);
    else out[k] = v;
  }
  return out;
}
function encodeHttpSyncPayload(payload) {
  const map = /* @__PURE__ */ new Map([
    ["format", "chronolog-http-sync/v3"],
    ["push", encodePairs(payload.push)],
    ["ranges", encodeRanges(payload.ranges)],
    ["want", [...payload.want]]
  ]);
  if (payload.casPush !== void 0 && payload.casPush.length > 0) {
    map.set("casPush", encodePairs(payload.casPush));
  }
  if (payload.casWant !== void 0 && payload.casWant.length > 0) {
    map.set("casWant", [...payload.casWant]);
  }
  if (payload.meta !== void 0) {
    map.set("meta", unknownToCbor(payload.meta));
  }
  return encodeCanonicalCbor(map);
}
function decodeHttpSyncPayload(bytes, maxBytes = 16 * 1024 * 1024) {
  const decoded = assertCanonicalCbor(bytes, { ...DEFAULT_DECODE_LIMITS, maxBytes });
  if (!(decoded instanceof Map)) throw new Error("HTTP_SYNC_PAYLOAD_INVALID");
  const map = decoded;
  if (map.get("format") !== "chronolog-http-sync/v3") throw new Error("HTTP_SYNC_FORMAT_INVALID");
  const ranges = decodeRanges(map.get("ranges"));
  const push = decodePairs(map.get("push"), 512);
  const want = decodeStringList(map.get("want"), 512);
  const casPushRaw = decodePairs(map.get("casPush"), 256);
  const casPush = casPushRaw.map((item) => ({ hash: item.id, bytes: item.bytes }));
  const casWant = decodeStringList(map.get("casWant"), 256);
  const meta = cborToMeta(map.get("meta"));
  return {
    format: "chronolog-http-sync/v3",
    ranges,
    push,
    want,
    ...casPush.length > 0 ? { casPush } : {},
    ...casWant.length > 0 ? { casWant } : {},
    ...meta !== void 0 ? { meta } : {}
  };
}
function toFactIdSet(ids) {
  if (ids instanceof FactIdSet) return ids;
  const set = new FactIdSet();
  for (const id of ids) set.add(id);
  return set;
}
function createHttpSyncHandler(options) {
  const basePath = (options.basePath ?? "").replace(/\/+$/u, "");
  const maxRequestBytes = options.maxRequestBytes ?? 8 * 1024 * 1024;
  const maxPushPerReply = options.maxPushPerReply ?? 256;
  const maxPushBytesPerReply = options.maxPushBytesPerReply ?? 4 * 1024 * 1024;
  return async (request) => {
    const extraHeaders = options.headers ?? {};
    const url = new URL(request.url);
    let path = url.pathname;
    if (basePath.length > 0) {
      if (!path.startsWith(`${basePath}/`)) return new Response("Not found", { status: 404, headers: extraHeaders });
      path = path.slice(basePath.length);
    }
    const match = /^\/sync\/(control|mailbox)$/u.exec(path);
    if (match === null) return new Response("Not found", { status: 404, headers: extraHeaders });
    if (request.method !== "POST") return new Response("Method not allowed", { status: 405, headers: extraHeaders });
    const scope = match[1];
    const rawBody = new Uint8Array(await request.arrayBuffer());
    if (rawBody.byteLength > maxRequestBytes) {
      return new Response("Payload too large", { status: 413, headers: extraHeaders });
    }
    let incoming;
    try {
      incoming = decodeHttpSyncPayload(rawBody, maxRequestBytes);
    } catch (err) {
      return new Response(JSON.stringify({ error: err instanceof Error ? err.message : "invalid_sync_payload" }), {
        status: 400,
        headers: { ...options.headers, "Content-Type": "application/json" }
      });
    }
    const verifiedCas = [];
    for (const node of incoming.casPush ?? []) {
      const norm = normalizeVerifiedCasNode(node.hash, node.bytes);
      if (norm === null) {
        return new Response(JSON.stringify({ error: "cas_hash_mismatch", hash: node.hash }), {
          status: 400,
          headers: { ...options.headers, "Content-Type": "application/json" }
        });
      }
      verifiedCas.push({ hash: node.hash, bytes: norm });
    }
    let putMeta;
    if (incoming.push.length > 0 || verifiedCas.length > 0) {
      const putRes = await options.store.putFacts(scope, incoming.push, verifiedCas);
      putMeta = putRes.meta;
    }
    const localIds = toFactIdSet(await options.store.listIds(scope));
    const step = reconcileRanges(localIds, incoming.ranges);
    const toSendIds = [.../* @__PURE__ */ new Set([...incoming.want, ...step.push])].slice(0, maxPushPerReply);
    const rawItems = toSendIds.length > 0 ? await options.store.getFacts(scope, toSendIds) : [];
    const boundedPush = [];
    let pushBytes = 0;
    for (const item of rawItems) {
      if (pushBytes + item.bytes.byteLength > maxPushBytesPerReply && boundedPush.length > 0) break;
      boundedPush.push(item);
      pushBytes += item.bytes.byteLength;
    }
    const casNodes = incoming.casWant !== void 0 && incoming.casWant.length > 0 && options.store.getCasNodes !== void 0 ? await options.store.getCasNodes(scope, incoming.casWant) : [];
    const meta = putMeta ?? (options.store.getMeta !== void 0 ? await options.store.getMeta(scope) : void 0);
    const reply = encodeHttpSyncPayload({
      format: "chronolog-http-sync/v3",
      ranges: step.reply,
      push: boundedPush,
      want: step.want,
      ...casNodes.length > 0 ? { casPush: casNodes } : {},
      ...meta !== void 0 ? { meta } : {}
    });
    const headers = new Headers(options.headers);
    headers.set("Content-Type", HTTP_SYNC_V3_MEDIA_TYPE);
    headers.set("Cache-Control", "no-store");
    headers.set("X-Content-Type-Options", "nosniff");
    return new Response(reply.slice(), { status: 200, headers });
  };
}
function createHttpSyncClient(baseUrl, options = {}) {
  const base = baseUrl.replace(/\/+$/u, "");
  const doFetch = options.fetch ?? fetch;
  const baseHeaders = options.headers ?? {};
  const maxRounds = options.maxRounds ?? 8;
  return {
    baseUrl: base,
    async reconcile(scope, local) {
      let rounds = 0;
      let pushed = 0;
      let pulled = 0;
      let lastMeta;
      let nextRanges = [local.ids.summary("")];
      let nextPushIds = [];
      let nextWantIds = [];
      let pendingCasPush = local.casPush ?? [];
      let pendingCasWant = local.casWant ?? [];
      while (rounds < maxRounds) {
        rounds += 1;
        const pushItems = nextPushIds.length > 0 ? await local.getFacts(nextPushIds) : [];
        pushed += pushItems.length;
        const body = encodeHttpSyncPayload({
          format: "chronolog-http-sync/v3",
          ranges: nextRanges,
          push: pushItems,
          want: nextWantIds,
          ...pendingCasPush.length > 0 ? { casPush: pendingCasPush } : {},
          ...pendingCasWant.length > 0 ? { casWant: pendingCasWant } : {}
        });
        pendingCasPush = [];
        pendingCasWant = [];
        const resp = await doFetch(`${base}/sync/${scope}`, {
          method: "POST",
          headers: { ...baseHeaders, "Content-Type": HTTP_SYNC_V3_MEDIA_TYPE },
          body: body.slice()
        });
        if (!resp.ok) throw new Error(`HTTP_SYNC_FAILED:${resp.status}`);
        const reply = decodeHttpSyncPayload(new Uint8Array(await resp.arrayBuffer()));
        if (reply.meta !== void 0) lastMeta = reply.meta;
        if (reply.push.length > 0 || (reply.casPush?.length ?? 0) > 0) {
          pulled += reply.push.length;
          await local.onReceive(reply.push, reply.casPush ?? []);
          for (const item of reply.push) local.ids.add(item.id);
        }
        const step = reconcileRanges(local.ids, reply.ranges);
        nextRanges = step.reply;
        nextPushIds = [.../* @__PURE__ */ new Set([...reply.want, ...step.push])];
        nextWantIds = step.want;
        if (!rangesNeedReply(nextRanges) && nextRanges.length === 0 && nextPushIds.length === 0 && nextWantIds.length === 0) {
          break;
        }
      }
      return { rounds, pushed, pulled, ...lastMeta === void 0 ? {} : { meta: lastMeta } };
    }
  };
}
export {
  CAS_NODE_MEDIA_TYPE,
  CAS_SUBGRAPH_MEDIA_TYPE,
  FactIdSet,
  HTTP_SYNC_V3_MEDIA_TYPE,
  createBytesStoreCasMirrorStore,
  createCasAdapterMirrorStore,
  createCasMirrorClient,
  createCasMirrorHandler,
  createHttpSyncClient,
  createHttpSyncHandler,
  decodeCasSubgraphBundle,
  decodeHttpSyncPayload,
  encodeCasSubgraphBundle,
  encodeHttpSyncPayload,
  normalizeVerifiedCasNode,
  resolveTrustedBuildOutput,
  verifyMirrorAuditAttestation,
  verifyMirrorBuildAttestation
};
