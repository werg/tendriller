import {
  createApplicationBackend
} from "./chunks/chunk-AAOS5GF6.mjs";
import "./chunks/chunk-XIJQU6SK.mjs";
import "./chunks/chunk-VRR2HFJY.mjs";
export {
  createApplicationBackend
};
