/** Increment `name` by `n` (default 1). */
export declare function perfCount(name: string, n?: number): void;
/** Accumulate elapsed milliseconds of `fn` under `<name>.ms` and calls under `<name>`. */
export declare function perfTime<T>(name: string, fn: () => T): T;
/** Async variant of `perfTime`. */
export declare function perfTimeAsync<T>(name: string, fn: () => Promise<T>): Promise<T>;
/** Snapshot of all counters, sorted by name; `.ms` values are rounded to 0.01. */
export declare function perfCounters(): Record<string, number>;
export declare function resetPerfCounters(): void;
