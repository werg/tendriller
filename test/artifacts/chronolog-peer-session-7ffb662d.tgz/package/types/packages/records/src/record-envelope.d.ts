export declare const MAX_RECORD_VALUE_BYTES: number;
export declare const MAX_RECORD_ENVELOPE_BYTES: number;
export declare function assertRecordKey(key: string): void;
export declare function recordFilenameSync(key: string): string;
export declare function recordFilename(key: string): Promise<string>;
/** CRC-32 (IEEE) — integrity check against storage corruption (not an adversarial MAC). */
export declare function crc32(bytes: Uint8Array): number;
/**
 * Logical record envelope for raw browser stores (IndexedDB):
 *   u8 format (2) | u16 keyLen | key UTF-8 | u32 CRC-32(value) | value
 * The key binding catches misplaced values and the CRC catches torn/corrupt writes. Values in
 * this device's own store were authenticated at ingress (signed ops, hashed CAS nodes), so the
 * envelope does not re-hash them with SHA-256 on every read (trust shortcut, cold open).
 */
export declare function encodeRecordValueSync(key: string, bytes: Uint8Array): Uint8Array;
export declare function encodeRecordValue(key: string, bytes: Uint8Array): Promise<Uint8Array>;
export declare function decodeRecordEntrySync(raw: Uint8Array, corruptionCode: string): {
    key: string;
    value: Uint8Array;
};
export declare function decodeRecordValueSync(key: string, raw: Uint8Array, corruptionCode: string): Uint8Array;
export declare function decodeRecordValue(key: string, raw: Uint8Array, corruptionCode: string): Promise<Uint8Array>;
export declare function decodeRecordEntry(raw: Uint8Array, corruptionCode: string): Promise<{
    key: string;
    value: Uint8Array;
}>;
