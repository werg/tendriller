/**
 * The single local byte-storage contract for identity, controls, journals and projections.
 * One owner serializes mutations. Each put atomically replaces one key and resolves only
 * after durable persistence. get and put must not expose mutable internal byte buffers.
 */
export interface BytesStoreEntry {
    readonly key: string;
    readonly value: Uint8Array;
}
export interface BytesStoreWriteOptions {
    readonly durability?: 'strict' | 'relaxed';
}
export interface BytesStoreChange {
    readonly seq: number;
    readonly key: string;
    readonly deleted: boolean;
}
export interface BytesStore {
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, bytes: Uint8Array, options?: BytesStoreWriteOptions): Promise<void>;
    /** Optional durable, idempotent local eviction. */
    delete?(key: string, options?: BytesStoreWriteOptions): Promise<void>;
    /** Optional batched eviction. */
    deleteMany?(keys: readonly string[], options?: BytesStoreWriteOptions): Promise<void>;
    /** Optional bounded atomic multi-key write, committing all entries together. */
    putMany?(entries: readonly BytesStoreEntry[], options?: BytesStoreWriteOptions): Promise<void>;
    /** Optional bounded-key batch, preserving input order. */
    getMany?(keys: readonly string[]): Promise<readonly (Uint8Array | null)[]>;
    /** Optional deterministic snapshot enumeration for atomic encrypted device checkpoints. */
    entries?(): Promise<readonly BytesStoreEntry[]>;
    /** Bounded-memory, deterministic snapshot. Release the iterator when abandoning a read. */
    iterateEntries?(): AsyncIterable<BytesStoreEntry>;
    /** Optional prefix-scoped scan (uses IDBKeyRange in IndexedDB). */
    iteratePrefix?(prefix: string): AsyncIterable<BytesStoreEntry>;
    /** Optional multi-tab delta changelog cursor. */
    latestChangeSeq?(): Promise<number>;
    readChangesSince?(afterSeq: number): Promise<{
        readonly latestSeq: number;
        readonly changes: readonly BytesStoreChange[];
    }>;
    /** Stage a stream and atomically publish only after it completes; false leaves an existing store untouched. */
    putStreamIfEmpty?(entries: AsyncIterable<BytesStoreEntry>): Promise<boolean>;
    /** Atomically initialize an empty store; false leaves an existing store untouched. */
    putAllIfEmpty?(entries: readonly BytesStoreEntry[]): Promise<boolean>;
}
/** Independent ephemeral storage for disposable peers and tests; not a durability claim. */
export declare class MemoryBytesStore implements BytesStore {
    #private;
    constructor(options?: {
        readonly quotaBytes?: number;
        readonly maxValueBytes?: number;
    });
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, bytes: Uint8Array): Promise<void>;
    putMany(entries: readonly BytesStoreEntry[]): Promise<void>;
    delete(key: string): Promise<void>;
    deleteMany(keys: readonly string[]): Promise<void>;
    putAllIfEmpty(entries: readonly BytesStoreEntry[]): Promise<boolean>;
    iterateEntries(): AsyncIterable<BytesStoreEntry>;
    iteratePrefix(prefix: string): AsyncIterable<BytesStoreEntry>;
    latestChangeSeq(): Promise<number>;
    readChangesSince(afterSeq: number): Promise<{
        readonly latestSeq: number;
        readonly changes: readonly BytesStoreChange[];
    }>;
    putStreamIfEmpty(entries: AsyncIterable<BytesStoreEntry>): Promise<boolean>;
    entries(): Promise<readonly BytesStoreEntry[]>;
}
/** Bounded prefetch for owners reopening an authenticated journal. */
export declare function readBytesMany(store: BytesStore, keys: readonly string[]): Promise<readonly (Uint8Array | null)[]>;
/** Coalesced atomic write when supported by the store, otherwise sequential durable puts in order. */
export declare function writeBytesMany(store: BytesStore, entries: readonly BytesStoreEntry[], options?: BytesStoreWriteOptions): Promise<void>;
/** Coalesced batched eviction when supported by the store, otherwise sequential deletes. */
export declare function deleteBytesMany(store: BytesStore, keys: readonly string[], options?: BytesStoreWriteOptions): Promise<void>;
