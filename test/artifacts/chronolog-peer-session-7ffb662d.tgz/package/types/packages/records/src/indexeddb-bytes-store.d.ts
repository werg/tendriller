import type { BytesStore, BytesStoreChange, BytesStoreEntry, BytesStoreWriteOptions } from './bytes-store.js';
/** Multi-tab ACID IndexedDB BytesStore with atomic delta changelog and configurable durability. */
export declare class IndexedDbBytesStore implements BytesStore {
    #private;
    private constructor();
    static open(name: string, { create }?: {
        create?: boolean | undefined;
    }): Promise<IndexedDbBytesStore>;
    get(key: string): Promise<Uint8Array | null>;
    getMany(keys: readonly string[]): Promise<readonly (Uint8Array | null)[]>;
    put(key: string, input: Uint8Array, options?: BytesStoreWriteOptions): Promise<void>;
    putMany(entries: readonly BytesStoreEntry[], options?: BytesStoreWriteOptions): Promise<void>;
    delete(key: string, options?: BytesStoreWriteOptions): Promise<void>;
    deleteMany(keys: readonly string[], options?: BytesStoreWriteOptions): Promise<void>;
    putAllIfEmpty(entries: readonly {
        readonly key: string;
        readonly value: Uint8Array;
    }[]): Promise<boolean>;
    iteratePrefix(prefix: string): AsyncIterable<BytesStoreEntry>;
    iterateEntries(): AsyncIterable<BytesStoreEntry>;
    latestChangeSeq(): Promise<number>;
    readChangesSince(afterSeq: number): Promise<{
        readonly latestSeq: number;
        readonly changes: readonly BytesStoreChange[];
    }>;
    entries(): Promise<readonly BytesStoreEntry[]>;
    putStreamIfEmpty(entries: AsyncIterable<BytesStoreEntry>): Promise<boolean>;
    close(): Promise<void>;
}
/** Scratch-only conformance probe; never opens the device's actual database. */
export declare function probeIndexedDbBytesStore(): Promise<boolean>;
/**
 * Read-only existence inspection for a data database whose metadata/pin may
 * have been erased. Abort the version-0 upgrade rather than creating a
 * replacement; callers must fail closed when an orphaned data DB exists.
 */
export declare function inspectExistingIndexedDbRecords(name: string): Promise<boolean>;
