import { type CasPartition, type ContentAddressedStore } from './cas.js';
export declare const CAS_BLOB_CHUNK_BYTES = 65536;
export declare const CAS_BLOB_FANOUT = 64;
export type ChronologBuiltinName = 'chronolog:crypto' | 'chronolog:cas' | 'chronolog:sqlite' | 'chronolog:wasm';
export type ChronologPackageRuntime = 'esm-quickjs' | 'wasm-pure' | 'hybrid';
export interface ChronologPackageNode {
    readonly format: 'chronolog-pkg/v1';
    readonly name?: string;
    readonly version?: string;
    readonly runtime: ChronologPackageRuntime;
    /** Normalized POSIX relative paths (e.g. "index.js", "lib/util.js") -> cas:sha256-<64-hex> */
    readonly files: Readonly<Record<string, string>>;
    /** Subpath exports (e.g. "." -> "index.js", "./rls" -> "rls.js") */
    readonly exports: Readonly<Record<string, string>>;
    /** Scoped bare dependencies -> cas:sha256-<64-hex> */
    readonly dependencies: Readonly<Record<string, string>>;
    /** Capability allowlist for THIS package only */
    readonly builtins: readonly ChronologBuiltinName[];
    /** Optional WASM module entry (required when runtime === 'wasm-pure') */
    readonly wasm?: {
        readonly entry: string;
        readonly abi: 'chronolog-wasm/v1';
    };
    /** Optional provenance back-link to chronolog-drv/v1 (deliberately omitted from CasNode.links) */
    readonly derivation?: string;
}
export type DerivationProfile = 'quickjs-inline' | 'wasi-cas-v1';
export interface ChronologDerivationNode {
    readonly format: 'chronolog-drv/v1';
    readonly profile: DerivationProfile;
    /** Pinned deterministic builder package (cas:sha256-<64-hex>) */
    readonly builder: string;
    /** Named input CAS roots (cas:sha256-<64-hex>) */
    readonly inputs: Readonly<Record<string, string>>;
    /** Canonical deterministic JSON-compatible builder arguments */
    readonly args: Readonly<Record<string, unknown>>;
    readonly limits: {
        readonly maxMemoryBytes: number;
        readonly maxFuel: number;
    };
}
export interface ChronologTreeNode {
    readonly format: 'chronolog-tree/v1';
    /** Sorted normalized POSIX paths -> cas:sha256-<64-hex> */
    readonly entries: Readonly<Record<string, string>>;
}
export interface CasEncryptedBlobChunkRef {
    readonly hash: string;
    readonly bytes: number;
    readonly plainBytes: number;
}
export interface CasEncryptedBlobManifest {
    readonly format: 'chronolog-enc-blob/v1';
    readonly applicationId: string;
    readonly epoch: number;
    readonly bytes: number;
    readonly mediaType: string;
    readonly stageId?: string;
    readonly chunks: readonly CasEncryptedBlobChunkRef[];
}
export declare function casRef(hash: string): string;
export declare function parseCasRef(ref: string): string;
export declare function tryParseCasRef(ref: string): string | null;
export declare function normalizePosixPath(input: string): string;
/** Resolve a relative specifier (./foo.js, ../bar.js) against a POSIX file path inside a package. */
export declare function resolvePackageRelativePath(baseFilePath: string, relativeSpecifier: string): string;
/** Compute the exact chronolog-blob/v1 CAS root hash for bytes without writing to a store. */
export declare function computeBlobDagHash(bytes: Uint8Array): string;
/** Store arbitrary bytes into CAS as a leaf (<=64 KiB) or 64-way chunked chronolog-blob/v1 Merkle tree. */
export declare function putBlobDag(cas: ContentAddressedStore, bytes: Uint8Array, partition?: CasPartition): Promise<{
    readonly hash: string;
    readonly bytes: number;
}>;
/** Return the exact byte length of a leaf or chunked chronolog-blob/v1 root in O(1). */
export declare function statBlobDag(cas: ContentAddressedStore, rootHash: string, partition?: CasPartition | 'any'): Promise<{
    readonly hash: string;
    readonly bytes: number;
    readonly chunked: boolean;
} | null>;
/** Read the full bytes of a leaf or chunked chronolog-blob/v1 DAG from CAS. */
export declare function readBlobDag(cas: ContentAddressedStore, rootHash: string, partition?: CasPartition | 'any', options?: {
    readonly maxBytes?: number;
}): Promise<Uint8Array | null>;
/** Stream chunks of a leaf or chunked chronolog-blob/v1 DAG from CAS. */
export declare function streamBlobDag(cas: ContentAddressedStore, rootHash: string, partition?: CasPartition | 'any'): AsyncIterable<Uint8Array>;
export interface BlobDagLeaf {
    readonly hash: string;
    readonly bytes: number;
}
/** Interior structure of a chronolog-blob/v1 DAG: everything a peer needs to verify leaves one by one. */
export interface BlobDagIndex {
    readonly hash: string;
    readonly bytes: number;
    /** Interior tree-node payloads in breadth-first order (root first); empty for a single-leaf blob. */
    readonly nodes: readonly Uint8Array[];
    readonly leaves: readonly BlobDagLeaf[];
}
/** Read the interior nodes and ordered leaf list of a local blob DAG without touching leaf bytes. */
export declare function blobDagIndex(cas: ContentAddressedStore, rootHash: string, partition?: CasPartition | 'any'): Promise<BlobDagIndex | null>;
/**
 * Authenticate peer-supplied interior nodes against `rootHash` (each node hashed once) and return the
 * canonical leaf list, so each leaf can be verified by its own hash as it arrives. Rejects any shape
 * `putBlobDag` would not produce for `bytes`.
 */
export declare function verifyBlobDagIndex(rootHash: string, bytes: number, nodes: readonly Uint8Array[]): {
    readonly leaves: readonly BlobDagLeaf[];
    readonly interior: readonly {
        readonly hash: string;
        readonly bytes: Uint8Array;
        readonly links: readonly string[];
    }[];
};
/** Synchronous full read of a leaf or chunked chronolog-blob/v1 (for QuickJS/WASM sync loading). */
export declare function readBlobDagSync(cas: ContentAddressedStore, rootHash: string, partition: CasPartition | 'any', onMissing: (hash: string) => never): Uint8Array;
export declare function encodeEncBlobManifest(manifest: CasEncryptedBlobManifest): {
    readonly bytes: Uint8Array;
    readonly links: readonly string[];
};
export declare function decodeEncBlobManifest(rawBytes: Uint8Array): CasEncryptedBlobManifest;
export declare function assertValidPackageNode(pkg: ChronologPackageNode): ChronologPackageNode;
export declare function encodePackageNode(pkg: ChronologPackageNode): {
    readonly bytes: Uint8Array;
    readonly links: readonly string[];
};
export declare function tryDecodePackageNode(rawBytes: Uint8Array): ChronologPackageNode | null;
export declare function decodePackageNode(rawBytes: Uint8Array): ChronologPackageNode;
export interface PutPackageInput {
    readonly name?: string;
    readonly version?: string;
    readonly runtime?: ChronologPackageRuntime;
    /** POSIX path -> raw UTF-8 string or Uint8Array bytes */
    readonly files: Readonly<Record<string, string | Uint8Array>>;
    readonly exports?: Readonly<Record<string, string>>;
    readonly dependencies?: Readonly<Record<string, string>>;
    readonly builtins?: readonly ChronologBuiltinName[];
    readonly wasm?: {
        readonly entry: string;
        readonly abi: 'chronolog-wasm/v1';
    };
    readonly derivation?: string;
}
/** Store all package files (as chronolog-blob/v1) and its chronolog-pkg/v1 manifest into CAS. */
export declare function putPackageDag(cas: ContentAddressedStore, input: PutPackageInput, partition?: CasPartition): Promise<{
    readonly hash: string;
    readonly ref: string;
    readonly manifest: ChronologPackageNode;
}>;
/** Compute the exact deterministic hash of a package manifest without storing it. */
export declare function computePackageHash(pkg: ChronologPackageNode): string;
export declare function encodeTreeNode(tree: ChronologTreeNode): {
    readonly bytes: Uint8Array;
    readonly links: readonly string[];
};
export declare function decodeTreeNode(rawBytes: Uint8Array): ChronologTreeNode;
export declare function putTreeDag(cas: ContentAddressedStore, files: Readonly<Record<string, string | Uint8Array>>, partition?: CasPartition): Promise<{
    readonly hash: string;
    readonly ref: string;
    readonly tree: ChronologTreeNode;
}>;
export declare function assertValidDerivationNode(drv: ChronologDerivationNode): ChronologDerivationNode;
export declare function encodeDerivationNode(drv: ChronologDerivationNode): {
    readonly bytes: Uint8Array;
    readonly links: readonly string[];
};
export declare function decodeDerivationNode(rawBytes: Uint8Array): ChronologDerivationNode;
export declare function putDerivationNode(cas: ContentAddressedStore, drv: ChronologDerivationNode, partition?: CasPartition): Promise<{
    readonly hash: string;
    readonly ref: string;
    readonly derivation: ChronologDerivationNode;
}>;
