export declare const STD_MOUNTS_SOURCE: string;
