export declare const STD_REGISTRY_SOURCE: string;
