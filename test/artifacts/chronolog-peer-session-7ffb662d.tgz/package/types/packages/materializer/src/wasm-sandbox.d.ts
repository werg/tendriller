import { type JsonValue } from '../../protocol/src/index.js';
import { type CasPartition, type ContentAddressedStore } from '../../records/src/index.js';
export declare const WASM_BUILTIN_ID = "wasm@1";
export interface WasmCallHostContext {
    readonly cas: ContentAddressedStore;
    readonly readPartition: CasPartition | 'any';
    readonly writePartition: CasPartition;
    readonly readOnly: boolean;
    readonly maxMemoryBytes: number;
    readonly maxFuel: number;
    readonly onMissingCas: (hash: string) => never;
}
export interface WasmReducerInvocationInput {
    readonly wasmHash: string;
    readonly method: 'reduce' | 'query' | 'describe' | 'onConflict';
    readonly state: JsonValue;
    readonly payload: JsonValue;
    readonly tx?: {
        readonly opId: string;
        readonly author: string;
        readonly authorTimestampMs: number;
        readonly operationId: string;
    };
    readonly conflict?: {
        readonly code: string;
        readonly detail?: string;
        readonly checkIndex?: number;
    };
    readonly topics: Readonly<Record<string, JsonValue>>;
    readonly config?: JsonValue;
    readonly host: WasmCallHostContext;
}
export type WasmReducerInvocationResult = {
    readonly ok: true;
    readonly value: JsonValue;
} | {
    readonly ok: false;
    readonly code: string;
    readonly detail?: string;
};
/**
 * Pure deterministic WebAssembly execution engine for Chronolog reducers and libraries.
 * - Compiles each cas:sha256-<hash> WASM binary ONCE and caches the WebAssembly.Module in memory.
 * - Strictly rejects any non-'chronolog' host imports (zero WASI, clock, network, or host FS).
 * - Instantiates fresh linear memory per invocation (~10-50us) with memory & fuel enforcement.
 */
export declare class WasmSandbox {
    #private;
    constructor(options?: {
        readonly maxCachedModules?: number;
    });
    get cachedModuleCount(): number;
    clearCache(): void;
    /** Invoke a numeric export on a cached pure WASM module (for JS reducers using chronolog:wasm). */
    invokeNumeric(wasmHash: string, exportName: string, args: readonly number[], host: WasmCallHostContext): number;
    /** Invoke a JSON-ABI export (alloc + ptr/len -> packed i64 or i32 + result_len) on a pure WASM module. */
    invokeJson(wasmHash: string, exportName: string, input: JsonValue, host: WasmCallHostContext): JsonValue;
    /** Execute a standalone pure WASM topic reducer (chronolog-wasm/v1 ABI). */
    invokeReducer(input: WasmReducerInvocationInput): WasmReducerInvocationResult;
}
