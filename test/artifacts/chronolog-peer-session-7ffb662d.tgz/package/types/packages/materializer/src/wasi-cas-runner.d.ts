import type { WasiDerivationRunner } from './derivation.js';
/**
 * Reference pure, deterministic `wasi-cas-v1` runner (`wasi_snapshot_preview1` over CAS VFS).
 *
 * Works identically in Node.js, Browsers, and Cloudflare Workers (zero `node:wasi` required):
 * - Mounts every named `drv.inputs` (`chronolog-tree/v1` or `chronolog-blob/v1`) read-only at `/inputs/<name>/...`
 * - Provides a deterministic writable `/out/` directory; on clean `proc_exit(0)`, packs `/out/...`
 *   into a canonical `chronolog-tree/v1` CAS node (or single `chronolog-blob/v1` if only `/out/output` exists).
 * - Strips ALL ambient non-determinism: `clock_time_get` returns 0, `random_get` traps,
 *   `environ_get` exposes ONLY canonical `CHRONOLOG_ARGS=<canonicalJson(drv.args)>`, zero host fs/network.
 */
export declare function createWasiCasRunner(): WasiDerivationRunner;
