import { type BytesStore, type CasPartition, type ChronologDerivationNode, type ContentAddressedStore } from '../../records/src/index.js';
import { type QuickJsSandbox } from './quickjs-sandbox.js';
export interface BuildAttestationPayload {
    readonly format: 'chronolog-attestation/v1';
    readonly kind: 'build';
    readonly drvRef: string;
    readonly outputRef: string;
    readonly runtime: string;
}
export interface AuditAttestationPayload {
    readonly format: 'chronolog-attestation/v1';
    readonly kind: 'audit';
    readonly pkgRef: string;
    readonly verdict: 'approved' | 'revoked';
    readonly notes?: string;
}
export interface SignedBuildAttestation {
    readonly payload: BuildAttestationPayload;
    readonly signer: string;
    readonly signature: string;
}
export interface SignedAuditAttestation {
    readonly payload: AuditAttestationPayload;
    readonly signer: string;
    readonly signature: string;
}
export declare function canonicalAttestationMessage(payload: BuildAttestationPayload | AuditAttestationPayload): string;
export declare function signBuildAttestation(payload: Omit<BuildAttestationPayload, 'format' | 'kind'>, signerPublicKeyHex: string, privateKey: CryptoKey): Promise<SignedBuildAttestation>;
export declare function verifyBuildAttestation(attestation: SignedBuildAttestation): boolean;
export declare function signAuditAttestation(payload: Omit<AuditAttestationPayload, 'format' | 'kind'>, signerPublicKeyHex: string, privateKey: CryptoKey): Promise<SignedAuditAttestation>;
export declare function verifyAuditAttestation(attestation: SignedAuditAttestation): boolean;
export type WasiDerivationRunner = (drv: ChronologDerivationNode, cas: ContentAddressedStore, partition: CasPartition) => Promise<string>;
export interface DerivationMemoCache {
    get(drvHash: string): Promise<string | null>;
    set(drvHash: string, outputHash: string): Promise<void>;
}
export declare function createBytesStoreDerivationMemo(store: BytesStore, prefix?: string): DerivationMemoCache;
export interface EvaluateDerivationOptions {
    readonly drvRefOrHash: string;
    readonly cas: ContentAddressedStore;
    readonly sandbox: QuickJsSandbox;
    readonly partition?: CasPartition;
    readonly memo?: DerivationMemoCache;
    readonly skipMemo?: boolean;
    readonly wasiRunners?: Readonly<Record<string, WasiDerivationRunner>>;
    readonly imports?: Readonly<Record<string, string>>;
}
export interface DerivationEvalResult {
    readonly drvHash: string;
    readonly drvRef: string;
    readonly outputHash: string;
    readonly outputRef: string;
    readonly fromCache: boolean;
}
/**
 * Evaluate a content-addressed chronolog-drv/v1 derivation deterministically (CAS -> CAS).
 * - 'quickjs-inline' derivations execute directly in QuickJsSandbox (zero external authority).
 * - 'wasi-cas-v1' derivations execute via a registered deterministic CAS-backed runner.
 * Results are permanently memoizable by drvHash because execution is pure and deterministic.
 */
export declare function evaluateDerivation(options: EvaluateDerivationOptions): Promise<DerivationEvalResult>;
/** Permissionlessly recompute a derivation and verify that it matches an attested output hash. */
export declare function verifyDerivationOutput(options: EvaluateDerivationOptions & {
    readonly expectedOutputRef: string;
}): Promise<{
    readonly valid: boolean;
    readonly expectedOutputRef: string;
    readonly actualOutputRef: string;
}>;
