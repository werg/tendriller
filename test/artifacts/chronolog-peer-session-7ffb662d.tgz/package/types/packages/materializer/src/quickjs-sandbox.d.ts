import { type QuickJSWASMModule } from 'quickjs-emscripten-core';
import { type JsonValue } from '../../protocol/src/index.js';
import { type CasPartition, type ContentAddressedStore } from '../../records/src/index.js';
import { WASM_BUILTIN_ID, WasmSandbox } from './wasm-sandbox.js';
export declare const QUICKJS_RUNTIME_ID = "quickjs-ng@0.32.0";
export declare const CRYPTO_BUILTIN_ID = "crypto@1";
export declare const CAS_BUILTIN_ID = "cas@1";
export declare const DEFAULT_MAX_FUEL = 200000;
export { WASM_BUILTIN_ID };
/** Uncatchable host-level signal that a required CAS chunk/module is missing locally. */
export declare class MissingDependencyError extends Error {
    readonly hash: string;
    readonly kind: 'cas' | 'module' | 'sqlite';
    readonly code: "MISSING_DEPENDENCY";
    constructor(hash: string, kind?: 'cas' | 'module' | 'sqlite');
}
export declare class OperationalTimeoutError extends Error {
    readonly code: "OPERATIONAL_TIMEOUT";
    constructor(message?: string);
}
export interface SqliteDdlAllowlist {
    readonly createTable?: boolean;
    readonly alterTable?: readonly string[];
    readonly dropTable?: readonly string[];
    readonly indexOn?: readonly string[];
    readonly createView?: boolean;
    readonly dropView?: readonly string[];
}
export interface SqliteExecOptions {
    readonly mode?: 'admin' | 'user' | 'readonly';
    readonly ddl?: SqliteDdlAllowlist;
}
export interface SqliteExecResult {
    readonly changes: number;
    readonly lastInsertRowid: number;
    readonly createdTables: readonly string[];
    readonly droppedTables: readonly string[];
    readonly createdViews?: readonly string[];
    readonly droppedViews?: readonly string[];
}
export interface SqliteQueryResult {
    readonly columns: readonly string[];
    readonly rows: readonly (readonly JsonValue[])[];
}
export interface SqliteDbHandle {
    exec(sql: string, params?: readonly JsonValue[], options?: SqliteExecOptions): SqliteExecResult;
    query(sql: string, params?: readonly JsonValue[]): SqliteQueryResult;
    validateExpr(table: string, sqlOp: 'INSERT' | 'UPDATE' | 'DELETE', expr: string): void;
    commit(): string;
    close(): void;
}
export interface SqliteBuiltinDriver {
    readonly builtinId: string;
    openDb(options: {
        readonly dbRoot: string | null;
        readonly cas: ContentAddressedStore;
        readonly partition: CasPartition;
        readonly actor: string;
        readonly opId: string;
        readonly opTimeMs: bigint;
        readonly readOnly: boolean;
        readonly onMissingCas: (hash: string) => never;
    }): SqliteDbHandle;
}
export interface QuickJsSandboxOptions {
    /** Optional static pre-compiled WebAssembly.Module (required on Cloudflare Workers). */
    readonly wasmModule?: WebAssembly.Module;
    readonly sqliteDriver?: SqliteBuiltinDriver;
    readonly watchdogMs?: number;
}
export interface AssumptionFailureInfo {
    readonly code: string;
    readonly detail?: string;
    readonly checkIndex?: number;
}
export interface ReducerInvocationInput {
    readonly imports: Readonly<Record<string, string>>;
    readonly builtins: Readonly<Record<string, string>>;
    readonly topicBindings?: Readonly<Record<string, {
        readonly module: string;
        readonly export?: string;
        readonly config?: JsonValue;
    }>>;
    readonly moduleSpecifier: string;
    readonly exportName: string;
    readonly method: 'reduce' | 'query' | 'describe' | 'onConflict' | 'derive';
    readonly state: JsonValue;
    readonly payload: JsonValue;
    readonly tx?: {
        readonly opId: string;
        readonly author: string;
        readonly authorTimestampMs: number;
        readonly operationId: string;
    };
    readonly conflict?: AssumptionFailureInfo;
    /** Lazy outcome lookup for ops visible to this invocation (never serialized wholesale into the VM). */
    readonly opOutcome?: (opId: string) => 'accepted' | 'rejected' | null;
    readonly opOutcomes?: Readonly<Record<string, 'accepted' | 'rejected'>>;
    readonly topicLastOpIds?: Readonly<Record<string, string>>;
    /** Visible topic states; read lazily by `ctx.topic()` / `ctx.query()` through host calls. */
    readonly topics: Readonly<Record<string, JsonValue>>;
    /** Optional precomputed content hash of a visible topic state (memoization key for nested queries). */
    readonly topicHash?: (topic: string) => string | undefined;
    readonly config?: JsonValue;
    readonly cas: ContentAddressedStore;
    readonly casPartition: CasPartition;
    readonly readOnly: boolean;
    readonly maxMemoryBytes: number;
    readonly maxFuel?: number;
}
export type ReducerInvocationResult = {
    readonly ok: true;
    readonly value: JsonValue;
} | {
    readonly ok: false;
    readonly code: string;
    readonly detail?: string;
};
export declare function loadQuickJsModule(wasmModule?: WebAssembly.Module): Promise<QuickJSWASMModule>;
export declare class QuickJsSandbox {
    #private;
    constructor(options?: QuickJsSandboxOptions);
    get sqliteBuiltinId(): string | null;
    get wasmSandbox(): WasmSandbox;
    get disposed(): boolean;
    /** Release pooled runtimes and caches. Idempotent; later invocations throw SANDBOX_DISPOSED. */
    dispose(): void;
    /**
     * Execute one deterministic reduce/query/describe/onConflict/derive call.
     * Automatically dispatches runtime === 'wasm-pure' packages to WasmSandbox and
     * JS/hybrid packages to a fresh isolated QuickJSContext with 2-arg scoped resolution.
     */
    invoke(input: ReducerInvocationInput): Promise<ReducerInvocationResult>;
}
