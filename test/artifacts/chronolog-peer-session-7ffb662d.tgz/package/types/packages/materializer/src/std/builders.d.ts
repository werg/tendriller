export declare const STD_BUILDERS_SOURCE: string;
