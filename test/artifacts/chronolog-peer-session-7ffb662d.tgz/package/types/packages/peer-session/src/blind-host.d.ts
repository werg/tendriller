import { type BlockchainAnchorVerifier, type FinalityCheckpoint, type VerifiedFinalityV2 } from '../../authority/src/index.js';
import { TopicKernel, type KernelOperationInput, type KernelOperationOutcome, type QuickJsSandboxOptions } from '../../materializer/src/index.js';
import { ContentAddressedStore, type CasPartition, type PutPackageInput } from '../../records/src/index.js';
import { type JsonValue, type LogGenesis, type OperationCore } from '../../protocol/src/index.js';
export interface BlindHostCasNode {
    readonly hash: string;
    readonly bytes: Uint8Array;
}
/**
 * Compute the exact set of public CAS node hashes reachable from a log's genesis,
 * materialized `$*` control topics (`$reducers`, `$mounts`, `$builders`, `$publications`),
 * public operation payloads, and transitive `CasNode.links` (including `chronolog-pkg/v1`,
 * `chronolog-tree/v1`, `chronolog-drv/v1`, and mounted subgraphs).
 */
export declare function collectControlReferencedCasHashes(options: {
    readonly genesis?: LogGenesis;
    readonly topics?: Readonly<Record<string, JsonValue>>;
    readonly publicOps?: readonly OperationCore[];
    readonly cas?: ContentAddressedStore;
    readonly casNodes?: ReadonlyMap<string, Uint8Array>;
}): Promise<Set<string>>;
export interface ControlPermissionsSummary {
    readonly mode: 'attested' | 'multisig' | 'open' | 'custom';
    readonly openRead: boolean;
    readonly openWrite: boolean;
    readonly members: readonly Record<string, JsonValue>[];
    readonly readers: readonly string[];
    readonly writers: readonly string[];
    readonly administrators: readonly string[];
    readonly publishers: readonly string[];
    readonly finalizers: readonly string[];
    readonly blockedAuthors: readonly string[];
    readonly removedMembers: readonly string[];
    readonly admission: JsonValue | null;
}
/**
 * Extract normalized permissions capabilities from a blind-host `TopicKernel`,
 * supporting `attestedMembers`, `multisigMembers`, `openMembers`, and custom `$permissions` reducers.
 */
export declare function extractControlPermissions(kernel: TopicKernel, rawPermsTopic: JsonValue | undefined): Promise<ControlPermissionsSummary>;
export interface ReplayBlindHostOptions {
    readonly genesis: LogGenesis;
    readonly publicOps: readonly KernelOperationInput[];
    readonly publicCasNodes: readonly BlindHostCasNode[];
    readonly checkpoints?: readonly FinalityCheckpoint[];
    readonly anchorVerifier?: BlockchainAnchorVerifier;
    readonly wasmModule?: QuickJsSandboxOptions['wasmModule'];
    /** When true (default), replays finalized control topics if checkpoints close a non-empty frontier. */
    readonly includeFinalized?: boolean;
}
export interface BlindHostControlResult {
    readonly stateRoot: string;
    readonly historyDigest: string;
    readonly topics: Readonly<Record<string, JsonValue>>;
    readonly outcomes: readonly KernelOperationOutcome[];
    readonly pendingDependencies: readonly string[];
    readonly permissions: ControlPermissionsSummary;
    readonly initialPermissions: ControlPermissionsSummary;
    readonly finality: VerifiedFinalityV2;
    readonly finalizedTopics: Readonly<Record<string, JsonValue>> | null;
    readonly referencedCasHashes: ReadonlySet<string>;
}
/**
 * Reusable blind-host control engine: replays public control operations (`$reducers`,
 * `$permissions`, `$keys`, `$finality`, `$publications`, `$signal_policy`, `$mounts`, `$builders`)
 * with `blindHostMode: true` and zero decryption keys, derives generic `$permissions` capabilities,
 * verifies `$finality` checkpoints, and computes exact reachable public CAS hashes for GC.
 */
export declare function replayBlindHostControl(options: ReplayBlindHostOptions): Promise<BlindHostControlResult>;
export interface DryRunReducerUpgradeOptions {
    readonly specifier: string;
    /** Either a raw UTF-8 ES module source string or a `chronolog-pkg/v1` package input. */
    readonly source?: string;
    readonly pkg?: PutPackageInput;
    readonly exportName?: string;
    /** Optional sample topic name & payloads to dry-run against `reduce()` and `query()`. */
    readonly topic?: string;
    readonly initialState?: JsonValue;
    readonly sampleInputs?: readonly {
        readonly payload: JsonValue;
        readonly author?: string;
        readonly timestampMs?: bigint;
    }[];
    readonly sampleQuery?: JsonValue;
    readonly wasmModule?: QuickJsSandboxOptions['wasmModule'];
}
export interface DryRunReducerUpgradeResult {
    readonly ok: boolean;
    readonly ref: string;
    readonly hash: string;
    readonly casNodes: readonly {
        readonly hash: string;
        readonly bytes: Uint8Array;
        readonly partition: CasPartition;
    }[];
    readonly description?: JsonValue;
    readonly sampleOutcomes: readonly {
        readonly ok: boolean;
        readonly code?: string;
        readonly state?: JsonValue;
    }[];
    readonly sampleQueryResult?: JsonValue;
    readonly error?: string;
}
/**
 * Validate a candidate ES module or `chronolog-pkg/v1` reducer in an isolated ephemeral
 * `MemoryBytesStore` QuickJS-NG sandbox before submitting a `$reducers` upgrade operation.
 */
export declare function dryRunReducerUpgrade(options: DryRunReducerUpgradeOptions): Promise<DryRunReducerUpgradeResult>;
