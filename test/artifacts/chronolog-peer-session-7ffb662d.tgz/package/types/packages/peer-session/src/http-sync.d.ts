import { FactIdSet, type ReconcileRange } from './reconcile.js';
export { FactIdSet } from './reconcile.js';
import { type MirrorCasNode } from './cas-mirror.js';
export declare const HTTP_SYNC_V3_MEDIA_TYPE = "application/vnd.chronolog.sync-v3+cbor";
export type HttpSyncScope = 'control' | 'mailbox';
export interface HttpSyncFactItem {
    readonly id: string;
    readonly bytes: Uint8Array;
}
export interface HttpSyncPayload {
    readonly format: 'chronolog-http-sync/v3';
    readonly ranges: readonly ReconcileRange[];
    readonly push: readonly HttpSyncFactItem[];
    readonly want: readonly string[];
    readonly casPush?: readonly MirrorCasNode[];
    readonly casWant?: readonly string[];
    readonly meta?: Readonly<Record<string, unknown>>;
}
export declare function encodeHttpSyncPayload(payload: HttpSyncPayload): Uint8Array;
export declare function decodeHttpSyncPayload(bytes: Uint8Array, maxBytes?: number): HttpSyncPayload;
/**
 * Backend store contract for WinterCG binary CBOR sync-v3 HTTP reconciliation.
 * Implementations verify incoming signatures / permissions / CAS reachability inside `putFacts`.
 */
export interface BlindSyncStore {
    listIds(scope: HttpSyncScope): Promise<FactIdSet | readonly string[]>;
    getFacts(scope: HttpSyncScope, ids: readonly string[]): Promise<readonly HttpSyncFactItem[]>;
    putFacts(scope: HttpSyncScope, items: readonly HttpSyncFactItem[], casPush: readonly MirrorCasNode[]): Promise<{
        readonly accepted: number;
        readonly meta?: Readonly<Record<string, unknown>>;
    }>;
    getCasNodes?(scope: HttpSyncScope, hashes: readonly string[]): Promise<readonly MirrorCasNode[]>;
    getMeta?(scope: HttpSyncScope): Promise<Readonly<Record<string, unknown>> | undefined>;
}
export interface HttpSyncHandlerOptions {
    readonly store: BlindSyncStore;
    readonly basePath?: string;
    readonly maxRequestBytes?: number;
    readonly maxPushPerReply?: number;
    readonly maxPushBytesPerReply?: number;
    readonly headers?: Readonly<Record<string, string>>;
}
/**
 * WinterCG-native binary CBOR sync-v3 HTTP reconciliation handler (`POST /sync/control` & `POST /sync/mailbox`).
 * Replaces O(N) hex-JSON `knownOpIds`/`knownEnvelopeDigests` lists with O(d · log16(N)) range-fingerprint
 * reconciliation over compact binary CBOR.
 */
export declare function createHttpSyncHandler(options: HttpSyncHandlerOptions): (request: Request) => Promise<Response>;
export interface HttpSyncClientOptions {
    readonly fetch?: typeof fetch;
    readonly headers?: Readonly<Record<string, string>>;
    readonly maxRounds?: number;
}
export interface HttpSyncClient {
    readonly baseUrl: string;
    reconcile(scope: HttpSyncScope, local: {
        readonly ids: FactIdSet;
        readonly getFacts: (ids: readonly string[]) => Promise<readonly HttpSyncFactItem[]>;
        readonly onReceive: (items: readonly HttpSyncFactItem[], casNodes: readonly MirrorCasNode[]) => Promise<void>;
        readonly casPush?: readonly MirrorCasNode[];
        readonly casWant?: readonly string[];
    }): Promise<{
        readonly rounds: number;
        readonly pushed: number;
        readonly pulled: number;
        readonly meta?: Readonly<Record<string, unknown>>;
    }>;
}
/**
 * Binary CBOR sync-v3 HTTP client implementing O(d · log16(N)) range-fingerprint reconciliation.
 */
export declare function createHttpSyncClient(baseUrl: string, options?: HttpSyncClientOptions): HttpSyncClient;
