/**
 * Compact binary codec for peer wire messages (Chronolog sync v3).
 *
 * A CBOR subset over plain JS values: null, booleans, safe integers, finite floats, bigint
 * (tag 48), strings, byte strings, arrays and string-keyed objects (undefined properties are
 * dropped). Messages are authenticated by the secure channel and individual facts carry their own
 * signatures, so this codec is not canonical; it is a single allocation-light pass each way.
 */
export interface WireDecodeLimits {
    readonly maxDepth: number;
    readonly maxItems: number;
}
export declare function encodeWireValue(value: unknown): Uint8Array;
export declare function decodeWireValue(input: Uint8Array, limits?: WireDecodeLimits): unknown;
