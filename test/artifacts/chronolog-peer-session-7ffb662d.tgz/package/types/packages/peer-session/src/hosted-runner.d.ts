import type { FinalityCheckpoint, SigningIdentity } from '../../authority/src/index.js';
import type { QuickJsSandboxOptions } from '../../materializer/src/index.js';
import type { ApplicationSession } from './session.js';
export interface HostedEncryptedEnvelopeExport {
    readonly digest: string;
    readonly epoch: number;
    readonly author: string;
    readonly raw: Uint8Array;
}
export interface HostedSealedCasItem {
    readonly hash: string;
    readonly sealed: Uint8Array;
}
export interface RunEphemeralHostedSessionOptions {
    readonly genesisBytes: Uint8Array;
    readonly signer: SigningIdentity;
    readonly epochKeys: ReadonlyMap<number, Uint8Array>;
    readonly publicOps: readonly Uint8Array[];
    readonly encryptedEnvelopes: readonly Uint8Array[];
    readonly publicCasNodes: readonly {
        readonly hash: string;
        readonly bytes: Uint8Array;
    }[];
    readonly sealedPrivateCas?: readonly HostedSealedCasItem[];
    readonly checkpoints?: readonly FinalityCheckpoint[];
    readonly materializedSnapshot?: Uint8Array;
    readonly casMirrors?: readonly string[];
    readonly wasmModule?: QuickJsSandboxOptions['wasmModule'];
    readonly sqliteWasmModule?: WebAssembly.Module;
    readonly maxSnapshotBytes?: number;
    readonly unsealPrivateCas?: (hash: string, sealed: Uint8Array) => Promise<Uint8Array | null>;
    readonly sealPrivateCas?: (hash: string, plain: Uint8Array) => Promise<Uint8Array>;
}
export interface EphemeralHostedSessionDelta {
    readonly newEnvelopes: readonly HostedEncryptedEnvelopeExport[];
    readonly newPublicOps: readonly Uint8Array[];
    readonly newSealedPrivateCas: readonly HostedSealedCasItem[];
    readonly prunedPrivateCasHashes: readonly string[];
    readonly snapshot: Uint8Array | null;
}
/**
 * Stateless, zero-plaintext-at-rest Chronolog session runner for Cloudflare Workers,
 * hosted MCP gateways, and serverless webhooks.
 *
 * Hydrates an ephemeral `MemoryBytesStore` `ApplicationSession` using caller-supplied
 * RAM-only `signer` and `epochKeys`, executes `work(session)`, exports only encrypted
 * delta envelopes, newly sealed private CAS nodes, pruned private CAS hashes, and an
 * opaque epoch-AEAD materialized snapshot, and zeroes/discards RAM keys in `finally`.
 */
export declare function runEphemeralHostedSession<T>(options: RunEphemeralHostedSessionOptions, work: (session: ApplicationSession) => Promise<T>): Promise<{
    readonly value: T;
    readonly delta: EphemeralHostedSessionDelta;
}>;
