import type { OperationAssumptionsConfig, OperationVisibility, TopicUpdate } from '../../protocol/src/index.js';
import type { Signed } from '../../authority/src/index.js';
import type { MaterializedRevision, WaitOptions } from './session-types.js';
export interface MaterializedOperation {
    readonly proposalId: string;
    readonly revision: MaterializedRevision;
    readonly outcome: 'accepted' | 'rejected';
    readonly rejectionCode: string | null;
    readonly rejectionDetail?: string;
}
/** One signed receipt covers a batch of retained operations (sync v3). */
export interface RetentionStatement {
    readonly applicationId: string;
    readonly peer: string;
    readonly storageId: string;
    /** Proposal ids retained (any envelope version of an op carries the same signed operation). */
    readonly items: readonly string[];
}
export type RetentionEvidence = Signed<RetentionStatement>;
export interface OperationInspection {
    readonly applicationId: string;
    readonly author: string;
    readonly authorTimestampMs: string | null;
    readonly proposalId: string;
    readonly operationId: string;
    readonly visibility: OperationVisibility;
    readonly stored: boolean;
    readonly pending: 'dependency' | 'key' | null;
    readonly materialized: MaterializedOperation | null;
    readonly retained: readonly RetentionEvidence[];
    readonly finalized: boolean;
    readonly excluded: boolean;
}
export interface OperationOwner {
    inspectOperation(id: string): OperationInspection;
    waitOperation(id: string, fact: 'materialized' | 'retained' | 'finalized', options?: WaitOptions): Promise<OperationInspection>;
}
export declare class ApplicationOperation {
    readonly id: string;
    readonly operationId: string;
    private readonly owner;
    readonly stored = true;
    constructor(id: string, operationId: string, owner: OperationOwner);
    inspect(): OperationInspection;
    materialized(options?: WaitOptions): Promise<MaterializedOperation>;
    retained(options?: WaitOptions): Promise<readonly RetentionEvidence[]>;
    finalized(options?: WaitOptions): Promise<MaterializedOperation>;
}
export interface ApplicationSubmission {
    readonly operationId?: string;
    readonly authorTimestampMs?: bigint;
    readonly visibility?: OperationVisibility;
    /** Wait for background materialization before resolving submit (defaults to false for instant local append). */
    readonly awaitMaterialized?: boolean;
    readonly updates: readonly TopicUpdate[];
    readonly assumptions?: OperationAssumptionsConfig;
    readonly afterOps?: readonly string[];
    readonly requiresRejected?: readonly string[];
    readonly onAssumptionFailed?: 'reject' | 'record_conflict';
}
