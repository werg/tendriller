import type { CasPartition } from '../../records/src/index.js';
import { type KernelMaterializedCache } from '../../materializer/src/index.js';
export interface SnapshotCasNode {
    readonly hash: string;
    readonly bytes: Uint8Array;
    readonly partition: CasPartition;
}
export interface DecodedSnapshot {
    readonly signer: string;
    readonly cache: KernelMaterializedCache;
    readonly casNodes: readonly SnapshotCasNode[];
}
export declare function encodeSnapshotBundle(input: {
    readonly logId: string;
    readonly cache: KernelMaterializedCache;
    readonly casNodes: readonly SnapshotCasNode[];
    readonly identity: {
        readonly publicKey: string;
        readonly privateKey: CryptoKey;
    };
    readonly encryption?: {
        readonly epoch: number;
        readonly key: Uint8Array;
    };
}): Promise<Uint8Array>;
/** Peek at the outer envelope without decrypting (null when not a v3 bundle for `logId`). */
export declare function snapshotEnvelope(bytes: Uint8Array, logId: string): {
    readonly private: boolean;
    readonly epoch: number;
} | null;
/**
 * Decode, decrypt (private logs) and verify the signature of a v3 bundle. Returns null for
 * anything malformed, for the wrong log, or when the epoch key is unavailable.
 */
export declare function decodeSnapshotBundle(bytes: Uint8Array, logId: string, epochKey: (epoch: number) => Uint8Array | undefined): Promise<DecodedSnapshot | null>;
