export interface BrowserCapabilityReport {
    readonly secureContext: boolean;
    readonly dedicatedWorker: boolean;
    readonly sharedWorker: boolean;
    readonly indexedDb: {
        readonly supported: boolean;
        readonly writable: boolean;
    };
    readonly webLocks: boolean;
    readonly crypto: {
        readonly ed25519: boolean;
        readonly x25519: boolean;
    };
    readonly wasm: boolean;
    readonly events: {
        readonly supported: boolean;
        readonly backend: 'indexeddb' | null;
        readonly reason?: string;
    };
    readonly sql: {
        readonly apiEligible: boolean;
        readonly qualified: boolean;
        readonly reason: string;
    };
}
/**
 * Explicit scratch-only probe for an owning dedicated Worker.
 * Chronolog v2 uses multi-tab IndexedDB + WASM sqlite-cas (no OPFS sync handles or exclusive storage locks).
 */
export declare function probeBrowserCapabilities(): Promise<BrowserCapabilityReport>;
