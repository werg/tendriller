import { ContentAddressedStore, type BytesStore } from '../../records/src/index.js';
import { type Signed, type SigningIdentity } from '../../authority/src/index.js';
import { type BlobGetOptions, type BlobInfo, type BlobPutOptions, type BlobReference, type ContentCacheStats, type ContentGetOptions, type ContentPruneResult, type ContentPutBytesOptions, type ContentPutOptions, type ContentReadBytesOptions, type ContentStreamPutOptions } from './content-bytes.js';
import { type ChunkSink } from './content-pull.js';
export { CONTENT_CHUNK_BYTES, MAX_BLOB_BYTES, MAX_BLOB_CHUNKS, isPublicBlobReference, isPrivateContentReference } from './content-bytes.js';
export type { BlobGetOptions, BlobInfo, BlobPutOptions, BlobReference, ContentCacheStats, ContentGetOptions, ContentPruneResult, ContentPutBytesOptions, ContentPutOptions, ContentReadBytesOptions, ContentStreamPutOptions, PublicBlobReference, } from './content-bytes.js';
export interface ContentAuthority {
    readonly applicationId: string;
    isReader(publicKey: string): boolean;
    currentEpoch(): number;
    epochKey(epoch: number): Uint8Array | null;
}
export declare const MAX_CONTENT_CHUNKS: number;
/**
 * Binary encrypted chunk (stored and sent as-is): [format u8 = 1][epoch u64 BE][nonce 12][AES-GCM ciphertext+tag].
 * Exactly `CONTENT_CHUNK_HEADER_BYTES + plaintext + 16` bytes; no hex, JSON or base64 anywhere.
 */
export declare const CONTENT_CHUNK_HEADER_BYTES = 21;
export declare const MAX_CONTENT_ENCRYPTED_CHUNK_BYTES: number;
export declare const MAX_CONTENT_MANIFEST_BYTES: number;
/** Bytes a single lazy pull keeps in flight ahead of its consumer (sliding window over all sources). */
export declare const CONTENT_FETCH_WINDOW_BYTES: number;
export interface ContentReference {
    readonly profile: 'authored-content-v1';
    readonly applicationId: string;
    readonly id: string;
    readonly epoch: number;
    readonly bytes: number;
    readonly mediaType: string;
}
export interface ContentManifest {
    readonly stageId: string;
    readonly reference: Omit<ContentReference, 'id'>;
    readonly chunks: readonly {
        readonly hash: string;
        readonly bytes: number;
    }[];
}
export type ContentRetention = Signed<{
    readonly reference: ContentReference;
    readonly peer: string;
    readonly storageId: string;
}>;
export interface ContentOptions {
    readonly signal?: AbortSignal;
}
/** Interior nodes of a public blob DAG; enough to verify every leaf by its own hash. */
export interface BlobIndex {
    readonly hash: string;
    readonly bytes: number;
    readonly nodes: readonly Uint8Array[];
}
export type { ChunkSink } from './content-pull.js';
export interface ContentSource {
    manifest(reference: ContentReference, options?: ContentOptions): Promise<ContentManifest | null>;
    chunk(reference: ContentReference, index: number, options?: ContentOptions): Promise<Uint8Array | null>;
    /** Stream chunks `start..start+count-1` in order to `onChunk` (null = not available here). */
    chunks?(reference: ContentReference, start: number, count: number, onChunk: ChunkSink, options?: ContentOptions): Promise<void>;
    retained?(reference: ContentReference, options?: ContentOptions): Promise<ContentRetention>;
    blobInfo?(hash: string, options?: ContentOptions): Promise<BlobInfo | null>;
    blobChunk?(hash: string, index: number, options?: ContentOptions): Promise<Uint8Array | null>;
    blobIndex?(hash: string, options?: ContentOptions): Promise<BlobIndex | null>;
    /** Stream blob leaves `start..start+count-1` in order to `onChunk` (null = not available here). */
    blobChunks?(hash: string, start: number, count: number, onChunk: ChunkSink, options?: ContentOptions): Promise<void>;
}
export interface ContentUpload {
    readonly id: string;
    write(index: number, bytes: Uint8Array): Promise<void>;
    progress(): Promise<{
        readonly bytes: number;
        readonly storedBytes: number;
        readonly missingChunks: readonly number[];
    }>;
    commit(): Promise<ContentReference>;
    /** Release this upload's staging records; an already committed object remains independently retained. */
    discard(): Promise<void>;
}
export declare function assertContentReference(value: unknown): asserts value is ContentReference;
export declare function assertContentManifest(value: unknown): asserts value is ContentManifest;
export declare function assertContentRetention(value: unknown): asserts value is ContentRetention;
export declare function assertBlobInfo(value: unknown): asserts value is BlobInfo;
/** Durable unified CAS-backed content (public chronolog-blob/v1 + epoch-encrypted chronolog-enc-blob/v1). */
export declare class ApplicationContent {
    #private;
    constructor(options: {
        readonly store: BytesStore;
        readonly cas?: ContentAddressedStore;
        readonly authority: ContentAuthority;
        readonly identity: SigningIdentity;
        readonly storageId: string;
        readonly maxCacheBytes?: number;
    });
    get cas(): ContentAddressedStore;
    attachSource(id: string, source: ContentSource): () => void;
    stage(options: {
        readonly bytes: number;
        readonly mediaType?: string;
    }): Promise<ContentUpload>;
    resumeUpload(id: string): Promise<ContentUpload>;
    read(input: ContentReference, options?: ContentOptions): AsyncIterable<Uint8Array>;
    /** Transfer/check the entire encrypted object before claiming local retention. */
    retain(input: ContentReference, options?: ContentOptions): Promise<ContentRetention>;
    verifyRetention(input: ContentReference, receipt: ContentRetention, expectedPeer?: string): Promise<void>;
    /** Ask attached sources to retain the object; these signed availability facts are not finality. */
    retention(input: ContentReference, options?: ContentOptions): Promise<readonly ContentRetention[]>;
    retained(input: ContentReference): Promise<readonly ContentRetention[]>;
    discard(input: ContentReference): Promise<void>;
    /** Store bytes into unified Merkle-DAG CAS (chronolog-blob/v1) so peers and reducers share one hash space. */
    putBlob(input: Uint8Array, options?: BlobPutOptions): Promise<BlobInfo>;
    hasBlob(hash: string): Promise<boolean>;
    /** Retrieve a CAS chronolog-blob/v1 locally, falling back to connected peers and verifying the CAS root hash. */
    getBlob(hash: string, options?: BlobGetOptions): Promise<Uint8Array | null>;
    deleteBlob(hash: string): Promise<void>;
    /** Serve only verified local bytes. Serving never recursively consults remote sources. */
    source(): ContentSource;
    putBytes(bytes: Uint8Array, options?: ContentPutBytesOptions): Promise<ContentReference>;
    readBytes(reference: ContentReference, options: ContentReadBytesOptions): Promise<Uint8Array>;
    /** Stream an async iterable of Uint8Array chunks into private or public lazy-pull content without holding the entire file in memory. */
    putStream(chunks: AsyncIterable<Uint8Array> | Iterable<Uint8Array>, options?: ContentStreamPutOptions): Promise<BlobReference>;
    /** Stream verified chunks for either a private ContentReference or a public PublicBlobReference / SHA-256 hash. */
    readStream(target: BlobReference | string, options?: ContentGetOptions): AsyncIterable<Uint8Array>;
    /** Pin a cached blob or private content item so `pruneCache()` will never evict it. */
    pin(target: BlobReference | string): Promise<void>;
    unpin(target: BlobReference | string): Promise<void>;
    isPinned(target: BlobReference | string): Promise<boolean>;
    stats(): Promise<ContentCacheStats>;
    /** Evict oldest unpinned locally cached blobs/items down to `maxBytes` (LRU). */
    pruneCache(options?: {
        readonly maxBytes?: number;
    }): Promise<ContentPruneResult>;
    /** Unified lazy-pull blob write: supports both public raw-SHA-256 blobs and private epoch-encrypted blobs. */
    put(bytes: Uint8Array, options?: ContentPutOptions): Promise<BlobReference>;
    /** Unified lazy-pull blob read: accepts a raw SHA-256 hex hash, a PublicBlobReference, or a private ContentReference. */
    get(target: BlobReference | string, options?: ContentGetOptions): Promise<Uint8Array | null>;
    close(): Promise<void>;
}
