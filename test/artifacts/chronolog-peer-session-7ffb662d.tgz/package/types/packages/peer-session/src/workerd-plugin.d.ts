export interface WorkerdWasmPluginOptions {
    /** Directory where `.wasm` assets will be copied alongside the Worker bundle. */
    readonly outDir: string;
    /** Optional workspace root (defaults to `process.cwd()`). */
    readonly rootDir?: string;
    /** Optional callback notified whenever a `.wasm` asset is copied. */
    readonly onAsset?: (fileName: string, sourcePath: string) => void;
}
interface EsbuildPluginBuildLike {
    onResolve(options: {
        readonly filter: RegExp;
    }, callback: (args: {
        readonly path: string;
        readonly resolveDir: string;
    }) => {
        readonly path: string;
        readonly external?: boolean;
        readonly namespace?: string;
    }): void;
    onLoad(options: {
        readonly filter: RegExp;
        readonly namespace?: string;
    }, callback: () => {
        readonly contents: string;
        readonly loader: 'js';
    }): void;
}
/**
 * Reusable esbuild plugin for bundling Chronolog applications into Cloudflare Workers (`workerd`):
 * - Copies `@jitl/quickjs-ng-wasmfile-release-sync/wasm`, `@chronolog/peer-session/sqlite-cas.wasm`,
 *   and relative `*.wasm` imports beside the Worker bundle as static external `./<name>` imports
 *   (so Wrangler compiles them via `CompiledWasm`).
 * - Stubs `node:module` (`createRequire`) cleanly for workerd compatibility.
 */
export declare function createWorkerdWasmPlugin(options: WorkerdWasmPluginOptions): {
    readonly name: string;
    setup(builder: EsbuildPluginBuildLike): void;
};
export {};
