/** Create a private directory (0700 on POSIX). */
export declare function ensurePrivateDirectory(dir: string): void;
export interface AtomicLockHandle {
    readonly path: string;
    release(): void;
}
/**
 * Acquire an exclusive atomic lockfile inside `dir` (with stale dead-PID recovery).
 * Throws `OWNER_BUSY` if another live process holds the lock.
 */
export declare function acquireAtomicLock(dir: string, filename?: string): AtomicLockHandle;
export interface ExclusiveSqliteFence {
    readonly path: string;
    close(): void;
}
/**
 * Acquire an OS-level exclusive SQLite fence (`PRAGMA locking_mode=EXCLUSIVE; BEGIN EXCLUSIVE`)
 * using Node's built-in `node:sqlite` (`DatabaseSync`) so two processes can never sign concurrently.
 */
export declare function openExclusiveSqliteFence(dbPath: string): ExclusiveSqliteFence;
export interface NativeIpcConnection {
    send(frame: Uint8Array): void;
    onFrame(listener: (frame: Uint8Array) => void): () => void;
    onClose(listener: () => void): () => void;
    close(): void;
}
/** Start a length-prefixed local IPC server over a Unix domain socket or Windows named pipe. */
export declare function startNativeIpcServer(options: {
    readonly socketPath: string;
    readonly maxFrameBytes?: number;
    readonly onConnection: (conn: NativeIpcConnection) => void;
}): Promise<{
    readonly socketPath: string;
    close(): Promise<void>;
}>;
/** Connect to a local length-prefixed IPC server. */
export declare function connectNativeIpc(socketPath: string, maxFrameBytes?: number): Promise<NativeIpcConnection>;
