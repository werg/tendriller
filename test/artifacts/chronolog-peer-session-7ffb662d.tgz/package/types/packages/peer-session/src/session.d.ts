import { sha256Sync } from '../../canonical/src/index.js';
import { type SqlBranch } from './sql-extensions.js';
import { ContentAddressedStore, type BytesStore, type CasPartition, type PutPackageInput } from '../../records/src/index.js';
import { type LogGenesis, type JsonValue } from '../../protocol/src/index.js';
import { type ApplicationDescription, type BlockchainAnchorVerifier, type FinalityCheckpoint, type FinalityPolicyV2, type ScheduledFinalityEntry, type VerifiedFinalityV2 } from '../../authority/src/index.js';
import { type DerivationEvalResult, type QuickJsSandboxOptions, type WasiDerivationRunner } from '../../materializer/src/index.js';
import { SignalChannel } from '../../signals/src/index.js';
import { ApplicationContent } from './content.js';
import type { ApplicationDevice } from './device.js';
import { type ApplicationDefinition } from './definition.js';
import { FactIdSet } from './reconcile.js';
import { type EpochKeyBox } from './genesis.js';
import { type ApplicationPeerConnectOptions, type ApplicationPeerDiagnostics, type ApplicationPeerLink } from './network.js';
import { ApplicationOperation, type ApplicationSubmission, type OperationInspection, type RetentionEvidence } from './operation.js';
import { type ApplicationChange, type ApplicationEventBatch, type ApplicationEventOptions, type ApplicationReadView, type CommandOptions, type MaterializedRevision, type SessionStatus, type WaitOptions } from './session-types.js';
export interface SessionCasNode {
    readonly hash: string;
    readonly bytes: Uint8Array;
    readonly partition: CasPartition;
}
/** Sync-v3 fact scopes: public = public ops + finality checkpoints; private = encrypted envelopes. */
export type FactScope = 'public' | 'private';
/** Facts added since the last `onFacts` notification, tagged with the link that delivered them. */
export interface FactsDelta {
    readonly items: readonly {
        readonly scope: FactScope;
        readonly id: string;
        readonly source?: string;
    }[];
}
export interface SessionFacts {
    readonly genesisBytes?: Uint8Array;
    readonly publicOps: readonly Uint8Array[];
    readonly encryptedEnvelopes: readonly Uint8Array[];
    readonly casNodes: readonly SessionCasNode[];
    readonly retentions: readonly RetentionEvidence[];
    readonly checkpoints: readonly FinalityCheckpoint[];
}
export interface MemberRecord {
    readonly publicKey: string;
    readonly wrapKey?: string;
    readonly label?: string;
    readonly scopes?: readonly string[];
    readonly expiresAtMs?: number;
    readonly reader: boolean;
    readonly writer: boolean;
    readonly administrator: boolean;
    readonly publisher: boolean;
    readonly finalizer: boolean;
}
export interface GuardianMember {
    readonly publicKey: string;
    readonly wrapKey: string;
    readonly label?: string;
}
export interface GuardiansConfig {
    readonly threshold: number;
    readonly members: readonly GuardianMember[];
}
export interface RecoveryRequestRecord {
    readonly requestId: string;
    readonly newPublicKey: string;
    readonly newWrapKey: string;
    readonly label: string;
    readonly verificationCode: string;
    readonly approvals: readonly string[];
    readonly status: 'pending' | 'completed';
    readonly createdAtMs: number;
}
export interface PermissionsMultisigInfo {
    readonly threshold: number;
    readonly signers: readonly string[];
    readonly proposals: Readonly<Record<string, JsonValue>>;
}
export interface PermissionsTopicState {
    readonly mode?: 'attested' | 'open' | 'multisig' | 'custom';
    readonly members: readonly MemberRecord[];
    readonly readers?: readonly string[];
    readonly writers?: readonly string[];
    readonly administrators?: readonly string[];
    readonly publishers?: readonly string[];
    readonly openReaders?: boolean;
    readonly openWriters?: boolean;
    readonly blockedAuthors?: readonly string[];
    readonly admission: {
        readonly hostKey?: string;
    } | null;
    readonly guardians?: GuardiansConfig | null;
    readonly recoveryRequests?: Readonly<Record<string, RecoveryRequestRecord>>;
    readonly multisig?: PermissionsMultisigInfo | null;
}
export interface KeyRingState {
    readonly currentEpoch: number;
    readonly epochs: Readonly<Record<string, {
        readonly epoch: number;
        readonly keyCommitment: string;
        readonly boxes: Readonly<Record<string, EpochKeyBox>>;
    }>>;
}
export interface KeysTopicState {
    readonly currentEpoch: number;
    readonly epochs: Readonly<Record<string, {
        readonly epoch: number;
        readonly keyCommitment: string;
        readonly boxes: Readonly<Record<string, EpochKeyBox>>;
    }>>;
    readonly rings?: Readonly<Record<string, KeyRingState>>;
    readonly topicRings?: Readonly<Record<string, string>>;
    readonly recovery?: {
        readonly vault: {
            readonly nonce: string;
            readonly ciphertext: string;
        };
        readonly guardianShares: Readonly<Record<string, {
            readonly index: number;
            readonly box: EpochKeyBox;
        }>>;
    };
    readonly recoveryGrants?: Readonly<Record<string, Readonly<Record<string, {
        readonly index: number;
        readonly box: EpochKeyBox;
    }>>>>;
}
export interface CheckpointBootstrapSnapshot {
    readonly topics: Readonly<Record<string, JsonValue>>;
    readonly seenOpsRoot: string;
    readonly historyDigest: string;
    readonly stateRoot: string;
}
export interface OpenApplicationSessionOptions<D extends ApplicationDefinition = ApplicationDefinition> extends QuickJsSandboxOptions {
    readonly device: ApplicationDevice;
    readonly store: BytesStore;
    readonly genesis?: LogGenesis | Uint8Array;
    readonly logId?: string;
    /** Optional host-level application scope ID (defaults to `logId`). */
    readonly applicationId?: string;
    readonly casNodes?: readonly SessionCasNode[];
    readonly epochKeys?: ReadonlyMap<number, Uint8Array>;
    readonly definition?: D;
    readonly blindHostMode?: boolean;
    readonly blockchainVerifier?: BlockchainAnchorVerifier;
    readonly sqliteWasmModule?: WebAssembly.Module;
    readonly sqliteWasmLoader?: () => Promise<WebAssembly.Module>;
    readonly materializedSnapshot?: Uint8Array;
    /** Ask peers for a signed snapshot when this replica has no history yet (default true). */
    readonly snapshotBootstrap?: boolean;
    readonly maxOperations?: number;
    /** Optional read-only untrusted HTTP CAS mirror URLs (GET <mirror>/cas/sha256-<hex>). */
    readonly casMirrors?: readonly string[];
    readonly release: () => void | Promise<void>;
}
/**
 * Chronolog v2 ApplicationSession.
 *
 * Built directly on:
 * - Flat timestamp-ordered operation set: (authorTimestampMs, author, opId)
 * - Pure Merkle-DAG CAS (public/private partitions, explicit links, exact GC)
 * - TopicKernel + QuickJS-NG Import-Map ES Module reducers + lazy chronolog:sqlite
 * - Automatic HPKE $keys unsealing + reconnect rewrapping of offline encrypted ops
 * - Time-scoped $finality verification & checkpoint bootstrap
 * - State-root-cached $signal_policy enforcement
 */
export declare class ApplicationSession<D extends ApplicationDefinition = ApplicationDefinition> {
    #private;
    readonly applicationId: string;
    readonly logId: string;
    readonly genesis: LogGenesis;
    readonly genesisBytes: Uint8Array;
    readonly device: ApplicationDevice;
    readonly identity: {
        readonly publicKey: string;
    };
    readonly definition?: D;
    readonly cas: ContentAddressedStore;
    readonly content: ApplicationContent;
    readonly signals: SignalChannel;
    private constructor();
    static open<D extends ApplicationDefinition = ApplicationDefinition>(options: OpenApplicationSessionOptions<D>): Promise<ApplicationSession<D>>;
    get signal(): AbortSignal;
    get status(): SessionStatus;
    permissions(): PermissionsTopicState;
    member(publicKey: string): MemberRecord | null;
    isBlockedAuthor(publicKey: string): boolean;
    isMember(publicKey: string): boolean;
    isReader(publicKey: string): boolean;
    isWriter(publicKey: string): boolean;
    isAdministrator(publicKey: string): boolean;
    /** Query an arbitrary capability (standard or custom) against the chain's `$permissions` reducer. */
    checkPermission(capability: string, actor?: string): Promise<boolean>;
    keysState(): KeysTopicState;
    currentEpoch(): number;
    epochKey(epoch: number): Uint8Array | null;
    hasEpochKey(epoch: number): boolean;
    exportEpochKeys(): ReadonlyMap<number, Uint8Array>;
    installEpochKey(epoch: number, key: Uint8Array): Promise<void>;
    installRingKey(ring: string, epoch: number, key: Uint8Array): Promise<void>;
    ringKey(ring: string, epoch: number): Uint8Array | null;
    /**
     * Heal any admitted reader missing HPKE lockboxes in `$keys` for epochs we hold
     * (e.g. concurrent admission + epoch rotation, multisig approvals, or late wrapKey addition).
     */
    backfillMissingEpochBoxes(options?: {
        readonly minEpoch?: number;
    }): Promise<number>;
    /** Incrementally pull facts written by a sibling tab/PWA into the shared multi-tab BytesStore. */
    syncFromStore(): Promise<boolean>;
    topic(name: string): JsonValue | null;
    revision(view?: 'local' | 'final'): MaterializedRevision;
    retryMaterialization(): Promise<void>;
    /** Write the materialized cache now (hosts call this on visibility change / before unload). */
    flushMaterializedCache(): Promise<void>;
    onStatus(listener: (status: SessionStatus) => void): () => void;
    onChange(listener: (change: ApplicationChange) => void): () => void;
    onFacts(listener: (delta: FactsDelta) => void): () => void;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
    setConnectedPeers(count: number): void;
    /** Author locally and durably before network delivery (fast local-append lane; materializes in background unless awaitMaterialized is true). */
    submit(input: ApplicationSubmission): Promise<ApplicationOperation>;
    /** Execute a named command (via local ApplicationDefinition if present, else direct topic dispatch). */
    command(name: string, input?: unknown, options?: CommandOptions): Promise<ApplicationOperation>;
    /** Execute a named query (via local ApplicationDefinition if present, else reducer query()). */
    query(name: string, input?: unknown, _options?: {
        readonly signal?: AbortSignal;
    }): Promise<{
        readonly applicationId: string;
        readonly revision: MaterializedRevision;
        readonly value: unknown;
    }>;
    /** Describe available commands and queries (from local definition or in-chain reducer describe() exports). */
    describe(): Promise<ApplicationDescription>;
    opOutcome(opId: string): 'accepted' | 'rejected' | null;
    topicLastOpId(topic: string): string | null;
    /**
     * Plain-language finality lifecycle status for UI badges (Pending -> Confirmed -> Needs attention):
     * - 'equivocated': notary/witness equivocation detected (fraud proof available via equivocationProofs())
     * - 'finalized': op is included in a verified $finality checkpoint
     * - 'excluded': closed-time frontier passed op's timestamp without including it
     * - 'synced': op has retention evidence from at least one peer/host
     * - 'local': authored/stored locally, awaiting sync or finality
     */
    finalityStatus(opId: string): 'equivocated' | 'finalized' | 'excluded' | 'synced' | 'local';
    equivocationProofs(): readonly import("../../authority/src/index.js").EquivocationProof[];
    /**
     * Time-travel query: run any topic query against a historical opId or timestamp
     * without mutating live session state.
     */
    queryAsOf(topic: string, input: JsonValue | undefined, target: {
        readonly opId: string;
    } | {
        readonly atTimestampMs: bigint;
    }): Promise<{
        readonly applicationId: string;
        readonly revision: MaterializedRevision;
        readonly targetOpId: string | null;
        readonly value: JsonValue;
    }>;
    /**
     * Open a zero-copy O(1) SQLite branch over the current dbRoot of a chronolog/sql topic.
     * Run speculative queries/mutations, compute exact row-level diffs, and optionally export a guarded proposal.
     */
    forkSql(topic: string): Promise<SqlBranch>;
    /** Capture a coherent read snapshot for reactive views, queries, and event pagination. */
    readView(options?: {
        readonly view?: 'local' | 'final';
    }): Promise<ApplicationReadView>;
    readEvents(options?: ApplicationEventOptions & {
        readonly view?: 'local' | 'final';
    }): ApplicationEventBatch;
    admitMember(options: {
        readonly publicKey: string;
        readonly wrapKey?: string;
        readonly label?: string;
        readonly subject?: string;
        readonly scopes?: readonly string[];
        readonly expiresAtMs?: number;
        readonly reader?: boolean;
        readonly writer?: boolean;
        readonly administrator?: boolean;
        readonly publisher?: boolean;
        readonly finalizer?: boolean;
        readonly attestation?: {
            readonly payload: JsonValue;
            readonly signature: string;
        };
        readonly minEpoch?: number;
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<ApplicationOperation>;
    rotateEpoch(options?: {
        readonly excludeMembers?: readonly string[];
        readonly newEpochKey?: Uint8Array;
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<{
        readonly epoch: number;
        readonly operation: ApplicationOperation;
    }>;
    /**
     * Create or rotate a named compartment key ring in $keys (e.g. 'admins' or 'personal:<pk>'),
     * sealing its epoch key strictly to the chosen members and binding the specified topics to it.
     */
    createCompartment(ringName: string, options: {
        readonly topics: readonly string[];
        readonly members: readonly {
            readonly publicKey: string;
            readonly wrapKey: string;
        }[];
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<{
        readonly ring: string;
        readonly epoch: number;
        readonly operation: ApplicationOperation;
    }>;
    /**
     * Configure threshold Social Recovery ("Trusted Backup Contacts"):
     * - Splits a fresh 32-byte recoveryKey into N Shamir shares (threshold M).
     * - Encrypts all retained epoch + compartment keys inside a recovery vault under recoveryKey.
     * - HPKE-seals each Shamir share strictly to its guardian's wrapKey (guardians cannot read app data).
     * - Atomically updates $permissions.guardians and $keys.recovery.
     */
    setupSocialRecovery(options: {
        readonly guardians: readonly GuardianMember[];
        readonly threshold: number;
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<ApplicationOperation>;
    /** Fresh device requests recovery from configured guardians with a short human-readable match code. */
    requestSocialRecovery(options?: {
        readonly requestId?: string;
        readonly label?: string;
        readonly verificationCode?: string;
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<{
        readonly requestId: string;
        readonly verificationCode: string;
        readonly operation: ApplicationOperation;
    }>;
    /** Guardian approves a pending recovery request and re-seals their Shamir share to the recovering device. */
    approveSocialRecovery(requestId: string, options?: {
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<ApplicationOperation>;
    /**
     * Called by the recovering device once threshold guardians have approved:
     * unseals guardian shares, reconstructs recoveryKey via Shamir interpolation,
     * decrypts the recovery vault, installs all epoch + compartment keys, and rematerializes.
     */
    completeSocialRecovery(): Promise<{
        readonly restoredEpochs: number;
        readonly restoredRings: number;
    }>;
    removeMember(publicKey: string, options?: {
        readonly rotateEpoch?: boolean;
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<ApplicationOperation>;
    publishRelease(options: {
        readonly entry: string;
        readonly files: readonly {
            readonly path: string;
            readonly bytes?: Uint8Array;
            readonly hash?: string;
            readonly size?: number;
            readonly type: string;
        }[];
        readonly includeTreeRoot?: boolean;
        readonly expectedRevision?: number;
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<ApplicationOperation>;
    rollbackRelease(options: {
        readonly revision?: number;
        readonly opId?: string;
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<ApplicationOperation>;
    scheduleFinality(options: {
        readonly effectiveAfterMs: bigint | number;
        readonly policy: FinalityPolicyV2;
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<ApplicationOperation>;
    updateReducers(options: {
        readonly imports?: Readonly<Record<string, string | null>>;
        readonly topics?: Readonly<Record<string, JsonValue>>;
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<ApplicationOperation>;
    readonly finality: {
        status: () => VerifiedFinalityV2 & {
            readonly schedule: readonly ScheduledFinalityEntry[];
        };
        createCheckpoint: (options: {
            readonly throughMs: bigint;
        }) => Promise<{
            readonly checkpoint: FinalityCheckpoint;
            readonly snapshot: CheckpointBootstrapSnapshot;
        }>;
        submitCheckpoints: (checkpoints: readonly FinalityCheckpoint[]) => Promise<void>;
        bootstrapFromCheckpoint: (checkpoint: FinalityCheckpoint, snapshot: CheckpointBootstrapSnapshot) => Promise<void>;
    };
    inspectOperation(idOrOperationId: string): OperationInspection;
    waitOperation(id: string, fact: 'materialized' | 'retained' | 'finalized', options?: WaitOptions): Promise<OperationInspection>;
    readonly operations: {
        get: (idOrOperationId: string) => ApplicationOperation | null;
        retry: (idOrOperationId: string) => Promise<ApplicationOperation>;
    };
    retain(proposalId: string, subject: {
        readonly author: string;
        readonly envelopeDigest: string;
    }): Promise<RetentionEvidence>;
    /**
     * Sign ONE retention receipt covering every newly retained item (sync v3), instead of one
     * signature, store write and gossip fact per operation.
     */
    retainMany(items: readonly {
        readonly proposalId: string;
        readonly author?: string;
        readonly envelopeDigest?: string;
    }[]): Promise<readonly RetentionEvidence[]>;
    /** Number of times this session skipped full replay by restoring a verified materialized cache/snapshot. */
    get materializedCacheHits(): number;
    /**
     * Export a member-signed Snapshot Bundle (v3, see snapshot-codec.ts): the current state as a
     * frontier (topics, idempotency set, digests and the covered op ids — no outcomes or events)
     * plus the CAS nodes reachable from it (SQLite pages, seen set; standard modules excluded).
     * On private logs it is AEAD-encrypted under the current epoch key, so blind hosts can cache it
     * and peers can serve it without exposing plaintext.
     */
    exportMaterializedSnapshot(options?: {
        readonly includeReachableCas?: boolean;
        readonly minOps?: number;
    }): Promise<Uint8Array | null>;
    /**
     * True when this replica has no materialized history yet (no ops and no snapshot frontier) and
     * would benefit from adopting a peer's snapshot instead of replaying everything.
     */
    wantsSnapshotBootstrap(): boolean;
    /**
     * Stage and apply an exported materialized snapshot bundle (AEAD-decrypted on private logs).
     * Works on cold replicas with zero historical ops downloaded (frontier bootstrap).
     */
    importMaterializedSnapshot(bytes: Uint8Array): Promise<boolean>;
    readCasPayload(hash: string, partition?: CasPartition | 'any'): Promise<{
        readonly hash: string;
        readonly payload: Uint8Array;
        readonly links: readonly string[];
    } | null>;
    exportFacts(options?: {
        readonly includePrivateCas?: boolean;
        readonly includeGenesis?: boolean;
    }): Promise<SessionFacts>;
    /** Reconciliation id set for a sync-v3 scope (live view; do not mutate). */
    factIds(scope: FactScope): FactIdSet;
    /** Raw facts for the given ids of one scope (unknown ids are skipped). */
    exportFactsById(scope: FactScope, ids: readonly string[]): SessionFacts;
    /** CAS nodes by hash for an on-demand peer pull; walks explicit CasNode.links when subgraph=true. */
    exportCasNodes(hashes: readonly string[], includePrivate: boolean, options?: {
        readonly subgraph?: boolean;
        readonly maxNodes?: number;
        readonly maxBytes?: number;
    }): Promise<SessionCasNode[]>;
    /**
     * Install a content-addressed `chronolog-pkg/v1` package (or pre-packed bundle / existing CAS ref)
     * into this log's `$reducers` topic in one ergonomic call.
     */
    installPackage(pkg: string | (PutPackageInput & {
        readonly partition?: CasPartition;
    }) | {
        readonly ref: string;
        readonly casNodes: readonly SessionCasNode[];
    }, options: {
        readonly alias: string;
        readonly topics?: Readonly<Record<string, {
            readonly export?: string;
            readonly config?: JsonValue;
        }>>;
        readonly partition?: CasPartition;
        readonly attestations?: readonly JsonValue[];
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<{
        readonly pkgRef: string;
        readonly operation: ApplicationOperation;
    }>;
    /**
     * Pin a verified snapshot of an external Chronolog log into `$mounts` so reducers can query it
     * deterministically via `ctx.mount(name)` and `ctx.mountQuery(name, topic, input)`.
     */
    mountLog(name: string, source: ApplicationSession | {
        readonly logId: string;
        readonly stateRoot: string;
        readonly topics: Readonly<Record<string, JsonValue>>;
        readonly casNodes?: readonly SessionCasNode[];
        readonly trustedSigners?: readonly string[];
        readonly signer?: string;
        readonly signature?: string;
    }, options?: {
        readonly trustedSigners?: readonly string[];
        readonly operationId?: string;
        readonly authorTimestampMs?: bigint;
    }): Promise<ApplicationOperation>;
    /**
     * Evaluate (or retrieve from local memo cache or trusted `$builders` derivation mirror)
     * a content-addressed `chronolog-drv/v1` derivation.
     */
    evaluateDerivation(drvRefOrHash: string, options?: {
        readonly partition?: CasPartition;
        readonly skipMemo?: boolean;
        readonly skipMirror?: boolean;
        readonly mirrors?: readonly string[];
        readonly trustedBuilders?: readonly string[];
        readonly threshold?: number;
        readonly wasiRunners?: Readonly<Record<string, WasiDerivationRunner>>;
    }): Promise<DerivationEvalResult & {
        readonly attestedBy?: readonly string[];
    }>;
    /** CAS hashes replay is blocked on (modules, reducer-read nodes, SQLite pages). */
    missingCasDependencies(): string[];
    exportPublicControlFacts(): Promise<{
        readonly publicOps: readonly Uint8Array[];
        readonly casNodes: readonly SessionCasNode[];
        readonly checkpoints: readonly FinalityCheckpoint[];
    }>;
    mergeFacts(facts: SessionFacts, options?: {
        readonly source?: string;
    }): Promise<void>;
    collectGarbage(): Promise<{
        readonly kept: number;
        readonly deleted: number;
    }>;
    connectPeer(options: ApplicationPeerConnectOptions): Promise<ApplicationPeerLink>;
    diagnostics(): readonly ApplicationPeerDiagnostics[];
    peerLinks(): readonly ApplicationPeerLink[];
    onPeerLink(listener: (event: {
        readonly type: 'connected' | 'disconnected';
        readonly link: ApplicationPeerLink;
    }) => void): () => void;
    close(): Promise<void>;
}
export { sha256Sync };
