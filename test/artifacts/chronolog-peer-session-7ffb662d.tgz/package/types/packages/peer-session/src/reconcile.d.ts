/**
 * Range-fingerprint set reconciliation over 32-byte fact identifiers (Chronolog sync v3).
 *
 * Ids are kept sorted as lowercase hex, so a hex prefix names a contiguous range. A range is
 * summarized by `(count, fingerprint)` where the fingerprint is the XOR of the first 16 bytes of
 * every id in the range. Peers compare summaries top-down: equal ranges stop immediately, small
 * ranges are exchanged as explicit id lists, and large differing ranges split into 16 children.
 *
 * Cost: identical sets settle in one message each way; d differences in N ids cost
 * O(d · log16(N)) summaries. Fingerprints are not authenticated (a dishonest peer can only hide
 * facts it could equally withhold), and every fact is still verified on arrival.
 */
/** Ranges at or below this size are exchanged as explicit id lists instead of being split. */
export declare const RECONCILE_LIST_THRESHOLD = 32;
/** Deepest prefix (in hex nibbles) a peer may ask about; bounds recursion on adversarial input. */
export declare const RECONCILE_MAX_PREFIX = 16;
export interface RangeSummary {
    readonly prefix: string;
    readonly count: number;
    /** 16-byte XOR fingerprint. */
    readonly fp: Uint8Array;
}
/**
 * Unique set of 32-byte ids. Membership is a hash lookup; the sorted index (and its packed
 * fingerprint words) is rebuilt lazily on the first range query after a change, so bulk loads and
 * live appends stay O(1) and reconciliation rounds pay one O(N log N) sort at most.
 */
export declare class FactIdSet {
    #private;
    get size(): number;
    has(id: string): boolean;
    add(id: string): boolean;
    delete(id: string): boolean;
    clear(): void;
    ids(prefix?: string): string[];
    count(prefix?: string): number;
    summary(prefix?: string): RangeSummary;
}
/** One range in a reconciliation message: either a summary to compare or an explicit id list. */
export type ReconcileRange = {
    readonly prefix: string;
    readonly count: number;
    readonly fp: Uint8Array;
} | {
    readonly prefix: string;
    readonly ids: readonly string[];
};
export interface ReconcileStep {
    /** Ranges to send back (summaries need a reply; id lists do not). */
    readonly reply: readonly ReconcileRange[];
    /** Ids the peer lacks that we hold: push these facts. */
    readonly push: readonly string[];
    /** Ids the peer holds that we lack: request these facts. */
    readonly want: readonly string[];
}
/**
 * Process one batch of peer ranges against the local set. Pure: callers move facts and replies.
 * `peerHas` collects ids the peer revealed holding (used to avoid echoing those facts).
 */
export declare function reconcileRanges(local: FactIdSet, ranges: readonly ReconcileRange[]): ReconcileStep;
/** Does a range list contain anything that needs the peer to answer? */
export declare function rangesNeedReply(ranges: readonly ReconcileRange[]): boolean;
