import type { WorkerApplicationSession } from './worker-application.js';
export declare const TAB_OWNER_PROTOCOL = "chronolog/tab-owner/v1";
/**
 * Request persistent browser storage so IndexedDB/OPFS device keys and journals
 * are kept out of best-effort eviction. Never throws; returns null if unsupported.
 */
export declare function requestPersistentStorage(): Promise<boolean | null>;
export interface NetworkLeaderOptions {
    readonly tabId?: string;
    readonly namespace?: string;
    readonly signal?: AbortSignal;
    readonly hiddenGraceMs?: number;
    readonly pingTimeoutMs?: number;
    readonly onRole: (active: boolean) => void;
}
/**
 * Non-blocking, stealable networking leader election across concurrent tabs/PWAs of the same
 * profile using Web Locks (`navigator.locks`) + `BroadcastChannel` liveness probing.
 *
 * Never blocks local IndexedDB reads or writes — follower tabs stay interactive via shared
 * storage + BroadcastChannel `syncFromStore()`, while at most one live tab maintains host
 * discovery/relay sockets. Frozen or hidden holders are cleanly stolen by visible tabs.
 */
export declare function coordinateNetworkLeader(profileId: string, options: NetworkLeaderOptions): () => void;
export interface ConnectTabWorkerOwnerOptions {
    readonly profileId: string;
    readonly workerUrl: string | URL;
    readonly applicationId: string;
    readonly configuration?: unknown;
    readonly context?: Readonly<Record<string, unknown>>;
    readonly protocol?: string;
    readonly namespace?: string;
    readonly timeoutMs?: number;
    readonly signal?: AbortSignal;
}
export interface TabWorkerAttachment {
    readonly session: WorkerApplicationSession;
    readonly worker: Worker;
    readonly ownerInstanceId: string;
    close(): Promise<void>;
}
/**
 * Lock-free 1:1 dedicated Worker tab owner:
 * - Spawns a dedicated Worker backed by multi-tab IndexedDB/OPFS + BroadcastChannel sync.
 * - Transfers a direct MessageChannel port to `createApplicationOwner` inside the Worker.
 * - Coordinates a non-blocking stealable network leader lock across sibling tabs.
 */
export declare function connectTabWorkerOwner(options: ConnectTabWorkerOwnerOptions): Promise<TabWorkerAttachment>;
