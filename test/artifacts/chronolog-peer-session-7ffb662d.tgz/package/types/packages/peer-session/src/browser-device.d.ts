import { type ApplicationDevice } from './device.js';
/** Open the protocol identity in its Worker; uses multi-tab lock-free IndexedDB storage. */
export declare function openBrowserDevice(options: {
    readonly name: string;
    readonly create?: true;
}): Promise<ApplicationDevice>;
