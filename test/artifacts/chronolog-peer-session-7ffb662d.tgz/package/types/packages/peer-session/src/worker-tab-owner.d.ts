import type { ApplicationOwnerOptions, ApplicationSessionOwner } from './owner-types.js';
import type { ApplicationSession } from './session.js';
export interface TabWorkerOwnedSession {
    readonly session: ApplicationSession;
    readonly extensions?: ApplicationOwnerOptions['extensions'];
    setNetworkActive?(active: boolean): void;
    onWake?(): void | Promise<void>;
    close?(): void | Promise<void>;
}
export interface ServeTabWorkerOwnerOptions {
    readonly scope?: {
        postMessage(message: unknown): void;
        addEventListener(type: 'message', listener: (event: Event) => void): void;
        removeEventListener(type: 'message', listener: (event: Event) => void): void;
    };
    readonly profileId?: string;
    readonly protocol?: string;
    readonly namespace?: string;
    readonly openSession?: (ctx: {
        readonly signal: AbortSignal;
        readonly initialNetworkActive: boolean;
    }) => Promise<TabWorkerOwnedSession>;
    readonly ownerOptions?: ApplicationOwnerOptions;
    readonly load?: (ctx: {
        readonly signal: AbortSignal;
        readonly configuration: unknown;
    }) => Promise<{
        readonly profileId: string;
        readonly openSession: (ctx: {
            readonly signal: AbortSignal;
            readonly initialNetworkActive: boolean;
        }) => Promise<TabWorkerOwnedSession>;
        readonly ownerOptions?: ApplicationOwnerOptions;
    }>;
}
/**
 * Serve one dedicated Worker owned by a browser tab over lock-free multi-tab IndexedDB/OPFS.
 * - Attaches transferred `MessagePort` directly to `createApplicationOwner`.
 * - Broadcasts `facts-updated` across sibling tabs on `BroadcastChannel` and calls `session.syncFromStore()`.
 * - Forwards stealable `network-role` messages to `owned.setNetworkActive`.
 */
export declare function serveTabWorkerOwner(options: ServeTabWorkerOwnerOptions): {
    readonly owner: ApplicationSessionOwner | undefined;
    close(): Promise<void>;
};
