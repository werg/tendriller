import { type CasPartition, type PutPackageInput } from '../../records/src/index.js';
import { type LogGenesis, type GenesisLimits, type JsonValue, type RuntimeManifest } from '../../protocol/src/index.js';
import type { ScheduledFinalityEntry } from '../../authority/src/index.js';
export interface EpochKeyBox {
    readonly encapsulatedKey: string;
    readonly ciphertext: string;
}
export declare function epochKeyCommitmentV2(epochKey: Uint8Array): string;
export declare function hpkeSealEpochKey(recipientWrapPublicKeyHex: string, epochKey: Uint8Array, logIdHex: string, epoch: number): Promise<EpochKeyBox>;
export declare function hpkeOpenEpochKey(recipientWrapPrivateKey: CryptoKey, recipientWrapPublicKeyHex: string, box: EpochKeyBox, logIdHex: string, epoch: number): Promise<Uint8Array>;
export interface LogMemberSeed {
    readonly publicKey: string;
    readonly wrapKey?: string;
    readonly label?: string;
    readonly subject?: string;
    readonly reader?: boolean;
    readonly writer?: boolean;
    readonly administrator?: boolean;
    readonly publisher?: boolean;
    readonly finalizer?: boolean;
}
export interface LogTopicSeed {
    readonly module: string;
    readonly export?: string;
    readonly config?: JsonValue;
    readonly initialState?: JsonValue;
}
export interface GenesisCasNode {
    readonly hash: string;
    readonly bytes: Uint8Array;
    readonly partition: CasPartition;
}
export interface PackedBundleInput {
    readonly imports: Readonly<Record<string, string>>;
    readonly casNodes: readonly GenesisCasNode[];
}
export interface BuildersSeed {
    readonly builders: readonly string[];
    readonly auditors?: readonly string[];
    readonly threshold?: number;
    readonly requireAudit?: boolean;
    readonly requireMountApproval?: string | null;
}
export interface CreateLogGenesisOptions {
    readonly creator: LogMemberSeed;
    readonly members?: readonly LogMemberSeed[];
    readonly privateLog?: boolean;
    /** When true, omits the `$reducers` reducer so topic bindings and import maps are permanently frozen. */
    readonly frozenReducers?: boolean;
    /** ES Module sources (specifier -> UTF-8 JS source) pinned into public CAS and registered in `$reducers.imports`. */
    readonly imports?: Readonly<Record<string, string>>;
    /** Private application ES Module sources pinned into `private` CAS (only visible to encrypted ops on `privateLog: true`). */
    readonly privateImports?: Readonly<Record<string, string>>;
    /** Multi-file or WASM `chronolog-pkg/v1` packages pinned into CAS and registered in `$reducers.imports`. */
    readonly packages?: Readonly<Record<string, PutPackageInput & {
        readonly partition?: CasPartition;
    }>>;
    /** Pre-packed bundle from `packReducers()` (imports + verified CAS DAG nodes). */
    readonly bundle?: PackedBundleInput;
    /** Enable verified cross-log sub-state mounts (`$mounts` bound to `chronolog/mounts:verifiedMounts`). */
    readonly enableMounts?: boolean;
    /** Enable M-of-N attested builds/audits (`$builders` + `attestedReducers` on `$reducers`). */
    readonly builders?: BuildersSeed;
    /** Application topics to register in `$reducers.topics` alongside standard `$*` control topics. */
    readonly topics?: Readonly<Record<string, LogTopicSeed>>;
    /** Optional host public key for `chronolog/permissions` Ed25519 admission attestations. */
    readonly hostPublicKey?: string;
    /** Optional full initial `$permissions.admission` policy object (overrides `hostPublicKey` default). */
    readonly admission?: JsonValue | null;
    /** Initial `$finality` schedule (defaults to `finality: none`). */
    readonly finalitySchedule?: readonly ScheduledFinalityEntry[];
    readonly signalPolicy?: JsonValue;
    readonly runtime?: RuntimeManifest;
    readonly limits?: GenesisLimits;
    readonly salt?: Uint8Array;
    readonly epoch0Key?: Uint8Array;
}
export interface CreatedLogGenesis {
    readonly logId: string;
    readonly genesis: LogGenesis;
    readonly genesisBytes: Uint8Array;
    /** CAS nodes (standard + app modules & chronolog-pkg/v1 DAGs) that accompany this genesis. */
    readonly casNodes: readonly GenesisCasNode[];
    /** Epoch 0 key if `privateLog` is true (undefined for public chains). */
    readonly epoch0Key?: Uint8Array;
}
/**
 * Create a Chronolog v2 genesis block with hash-pinned standard modules, custom ES modules,
 * multi-file/WASM `chronolog-pkg/v1` packages, optional `$mounts`, and optional `$builders`.
 */
export declare function createLogGenesis(options: CreateLogGenesisOptions): Promise<CreatedLogGenesis>;
/**
 * Create a dogfooded Chronolog Package Registry genesis (public by default, or private org registry).
 * Uses `chronolog/registry` (SQLite + FTS5 full-text search + signed build/audit attestations).
 */
export declare function createRegistryGenesis(options: {
    readonly creator: LogMemberSeed;
    readonly members?: readonly LogMemberSeed[];
    readonly privateLog?: boolean;
    readonly salt?: Uint8Array;
    readonly epoch0Key?: Uint8Array;
}): Promise<CreatedLogGenesis>;
