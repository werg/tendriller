import { type BytesStore, type CasPartition, type ContentAddressedStore } from '../../records/src/index.js';
export declare const CAS_NODE_MEDIA_TYPE = "application/vnd.chronolog.cas-node+cbor";
export declare const CAS_SUBGRAPH_MEDIA_TYPE = "application/vnd.chronolog.cas-subgraph+cbor";
export interface MirrorBuildAttestation {
    readonly payload: {
        readonly format: 'chronolog-attestation/v1';
        readonly kind: 'build';
        readonly drvRef: string;
        readonly outputRef: string;
        readonly runtime: string;
    };
    readonly signer: string;
    readonly signature: string;
}
export interface MirrorAuditAttestation {
    readonly payload: {
        readonly format: 'chronolog-attestation/v1';
        readonly kind: 'audit';
        readonly pkgRef: string;
        readonly verdict: 'approved' | 'revoked';
        readonly notes?: string;
    };
    readonly signer: string;
    readonly signature: string;
}
export interface MirrorCasNode {
    readonly hash: string;
    readonly bytes: Uint8Array;
}
export interface CasMirrorStore {
    getNode(hash: string): Promise<Uint8Array | null>;
    hasNode?(hash: string): Promise<boolean>;
    putNode?(hash: string, encodedNode: Uint8Array): Promise<void>;
    listAttestations?(drvHash: string): Promise<readonly MirrorBuildAttestation[]>;
    putAttestation?(drvHash: string, attestation: MirrorBuildAttestation): Promise<void>;
    listAudits?(pkgHash: string): Promise<readonly MirrorAuditAttestation[]>;
    putAudit?(pkgHash: string, audit: MirrorAuditAttestation): Promise<void>;
}
export declare function verifyMirrorBuildAttestation(att: unknown): att is MirrorBuildAttestation;
export declare function verifyMirrorAuditAttestation(att: unknown): att is MirrorAuditAttestation;
/** Verify raw or pre-encoded CAS node bytes against expectedHash and return canonical CasNode bytes. */
export declare function normalizeVerifiedCasNode(expectedHash: string, raw: Uint8Array, maxBytes?: number): Uint8Array | null;
/** Encode a CAS subgraph response/batch payload as canonical CBOR. */
export declare function encodeCasSubgraphBundle(rootHash: string, nodes: readonly MirrorCasNode[]): Uint8Array;
/** Decode a CAS subgraph bundle produced by `encodeCasSubgraphBundle`. */
export declare function decodeCasSubgraphBundle(bytes: Uint8Array): {
    readonly root: string;
    readonly nodes: readonly MirrorCasNode[];
};
/**
 * Resolve trusted output consensus from a list of verified build attestations.
 * Returns the agreed outputRef and signing builder public keys when at least `threshold`
 * distinct trusted builders attested to the exact same outputRef.
 */
export declare function resolveTrustedBuildOutput(drvRef: string, attestations: readonly MirrorBuildAttestation[], trustedBuilders: readonly string[], threshold?: number): {
    readonly outputRef: string;
    readonly outputHash: string;
    readonly signers: readonly string[];
} | null;
/** Back a `CasMirrorStore` with any Chronolog `BytesStore` (Memory, node:sqlite, DO SQLite, IndexedDB). */
export declare function createBytesStoreCasMirrorStore(store: BytesStore, prefix?: string): CasMirrorStore;
/** Expose an existing `ContentAddressedStore` directly as a `CasMirrorStore`. */
export declare function createCasAdapterMirrorStore(cas: ContentAddressedStore, options?: {
    readonly partition?: CasPartition;
    readonly attestationStore?: BytesStore;
    readonly prefix?: string;
}): CasMirrorStore;
export interface CasMirrorHandlerOptions {
    readonly store: CasMirrorStore;
    /** Optional path prefix stripped before matching `/cas/...`, `/derivations/...`, `/audits/...`, `/trees/...`. */
    readonly basePath?: string;
    /** Whether PUT/POST writes are enabled (default false unless authorizeWrite is supplied). */
    readonly allowWrites?: boolean;
    /** Optional write authorization hook for PUT /cas/:hash, POST /cas/batch, PUT /derivations/:drvHash, PUT /audits/:pkgHash. */
    readonly authorizeWrite?: (request: Request, kind: 'cas' | 'derivation' | 'audit') => boolean | Promise<boolean>;
    /** Optional custom media-type resolver for `/trees/:treeHash/*path`. */
    readonly resolveMediaType?: (path: string) => string;
    readonly maxNodeBytes?: number;
    readonly maxSubgraphNodes?: number;
    readonly maxSubgraphBytes?: number;
    readonly maxTreeFileBytes?: number;
    /** Extra CORS headers (e.g. `{ 'Access-Control-Allow-Origin': '*' }`). */
    readonly headers?: Readonly<Record<string, string>>;
}
/**
 * Create a reusable, WinterCG-native (Cloudflare Workers, Deno, Bun, Node 22+) HTTP handler
 * serving content-addressed CAS nodes, BFS subgraphs (`?subgraph=1`), Ed25519-verified
 * derivation/audit attestations, and `chronolog-tree/v1` static files with metadata-first 304 & Range/206.
 */
export declare function createCasMirrorHandler(options: CasMirrorHandlerOptions): (request: Request) => Promise<Response>;
export interface CasMirrorClientOptions {
    readonly fetch?: typeof fetch;
    readonly headers?: Readonly<Record<string, string>>;
}
export interface CasMirrorClient {
    readonly baseUrl: string;
    fetchNode(hash: string): Promise<MirrorCasNode | null>;
    fetchSubgraph(hash: string, options?: {
        readonly maxNodes?: number;
        readonly maxBytes?: number;
    }): Promise<readonly MirrorCasNode[]>;
    pushNode(hash: string, bytes: Uint8Array): Promise<boolean>;
    pushSubgraph(rootHash: string, nodes: readonly MirrorCasNode[]): Promise<boolean>;
    fetchDerivationAttestations(drvRefOrHash: string, options?: {
        readonly trustedBuilders?: readonly string[];
        readonly threshold?: number;
    }): Promise<{
        readonly attestations: readonly MirrorBuildAttestation[];
        readonly trusted: {
            readonly outputRef: string;
            readonly outputHash: string;
            readonly signers: readonly string[];
        } | null;
    }>;
    publishDerivationAttestation(attestation: MirrorBuildAttestation): Promise<boolean>;
    fetchAuditAttestations(pkgRefOrHash: string): Promise<readonly MirrorAuditAttestation[]>;
    publishAuditAttestation(audit: MirrorAuditAttestation): Promise<boolean>;
}
/**
 * Zero-trust HTTP client for any Chronolog CAS & derivation mirror.
 * Every CAS node hash and every Ed25519 attestation signature is re-verified locally.
 */
export declare function createCasMirrorClient(baseUrl: string, options?: CasMirrorClientOptions): CasMirrorClient;
