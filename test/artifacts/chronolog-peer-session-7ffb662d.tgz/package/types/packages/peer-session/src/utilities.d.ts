import { type CasPartition } from '../../records/src/index.js';
import { type JsonValue, type TopicBinding } from '../../protocol/src/index.js';
/**
 * Recursively scan any JSON value (topic state, event payloads, etc.) for content-addressed
 * references (`cas:sha256-...`, `chronolog-blob-v2` refs, and `authored-content-v1` ids).
 */
export declare function collectCasRefsFromValue(value: unknown, options?: {
    readonly maxDepth?: number;
    readonly maxRefs?: number;
}): {
    readonly casHashes: readonly string[];
    readonly contentIds: readonly string[];
};
export interface BlueprintSqlSchema {
    readonly statements: readonly string[];
    readonly policies: Readonly<Record<string, JsonValue>>;
}
export interface LogBlueprintV1 {
    readonly format: 'chronolog-blueprint/v1';
    readonly privateLog: boolean;
    /** Non-control topic bindings (`topicName -> TopicBinding`). */
    readonly topics: Readonly<Record<string, TopicBinding>>;
    /** Non-standard specifier -> `cas:sha256-...` import map entries. */
    readonly imports: Readonly<Record<string, string>>;
    /** Base64-encoded canonical CAS nodes (including transitive `chronolog-pkg/v1` subgraphs!). */
    readonly casNodes: Readonly<Record<string, string>>;
    /** Extracted `chronolog/sql` schema DDL + RLS policies (strictly zero application rows). */
    readonly sqlSchemas: Readonly<Record<string, BlueprintSqlSchema>>;
    /** Optional current `$publications` metadata (zero secret data). */
    readonly publication?: JsonValue;
}
export interface BlueprintSessionLike {
    readonly genesis: {
        readonly privateLog: boolean;
    };
    topic(name: string): JsonValue | undefined;
    query(topic: string, input: JsonValue): Promise<{
        readonly value?: unknown;
    }>;
    exportCasNodes(hashes: readonly string[], includePrivate: boolean, options?: {
        readonly subgraph?: boolean;
        readonly maxNodes?: number;
        readonly maxBytes?: number;
    }): Promise<readonly {
        readonly hash: string;
        readonly bytes: Uint8Array;
        readonly partition: CasPartition;
    }[]>;
}
/**
 * Export a portable, secret-free `chronolog-blueprint/v1` snapshot of a log's application
 * reducers, transitive `chronolog-pkg/v1` / ES module CAS DAG nodes, `chronolog/sql` DDL & RLS
 * policies (zero rows), and optional `$publications` metadata.
 */
export declare function exportLogBlueprint(session: BlueprintSessionLike): Promise<LogBlueprintV1>;
/**
 * Validate a `chronolog-blueprint/v1` object: blocks `$*` control-topic injection and verifies
 * every included CAS node's cryptographic hash.
 */
export declare function validateLogBlueprint(blueprint: unknown): {
    readonly blueprint: LogBlueprintV1;
    readonly casNodes: readonly {
        readonly hash: string;
        readonly bytes: Uint8Array;
        readonly partition: 'public';
    }[];
};
export interface CasPinnerSessionLike {
    topic(name: string): JsonValue | undefined;
    readonly content: {
        get(refOrHash: string, options?: {
            readonly cache?: boolean;
        }): Promise<Uint8Array | null>;
        pin?(refOrHash: string): Promise<void>;
        pruneCache?(options: {
            readonly maxBytes: number;
        }): Promise<unknown>;
    };
    onChange(listener: () => void): () => void;
    onPeerLink?(listener: () => void): () => void;
}
/**
 * Attach a bounded proactive CAS/content reference pinner to a running session.
 * Scans specified (or all non-control) topics on changes/peer links, fetches up to
 * `maxRefsPerScan` referenced blobs into local cache, pins them, and enforces `maxBytes`.
 */
export declare function attachCasPinner(session: CasPinnerSessionLike, options?: {
    readonly topics?: readonly string[];
    readonly maxBytes?: number;
    readonly maxRefsPerScan?: number;
    readonly maxDepth?: number;
}): () => void;
