import { type ApplicationContent, type ContentManifest, type ContentReference, type ContentRetention } from './content.js';
/**
 * Content RPC v2: raw `Uint8Array` chunks (the peer wire is binary CBOR), range requests answered
 * by a stream of one `*-chunk-response` per chunk, and at most `pending`/`active` requests per peer.
 * `timeoutMs` is an inactivity timeout: every streamed chunk re-arms it.
 */
export declare const CONTENT_NETWORK_LIMITS: Readonly<{
    pending: 16;
    active: 16;
    rangeChunks: 16;
    timeoutMs: 30000;
    chunkBytes: number;
    blobNodes: 64;
    blobNodeBytes: number;
}>;
export type ContentWireMessage = {
    readonly type: 'manifest-request';
    readonly id: string;
    readonly reference: ContentReference;
} | {
    readonly type: 'chunks-request';
    readonly id: string;
    readonly reference: ContentReference;
    readonly start: number;
    readonly count: number;
} | {
    readonly type: 'retain-request';
    readonly id: string;
    readonly reference: ContentReference;
} | {
    readonly type: 'blob-info-request';
    readonly id: string;
    readonly hash: string;
} | {
    readonly type: 'blob-chunks-request';
    readonly id: string;
    readonly hash: string;
    readonly start: number;
    readonly count: number;
} | {
    readonly type: 'manifest-response';
    readonly id: string;
    readonly manifest: ContentManifest | null;
} | {
    readonly type: 'chunk-response';
    readonly id: string;
    readonly index: number;
    readonly bytes: Uint8Array | null;
} | {
    readonly type: 'retain-response';
    readonly id: string;
    readonly receipt: ContentRetention;
} | {
    readonly type: 'blob-info-response';
    readonly id: string;
    readonly bytes: number | null;
    readonly nodes: readonly Uint8Array[];
} | {
    readonly type: 'blob-chunk-response';
    readonly id: string;
    readonly index: number;
    readonly bytes: Uint8Array | null;
} | {
    readonly type: 'error';
    readonly id: string;
    readonly code: 'CONTENT_UNAVAILABLE' | 'CONTENT_FORBIDDEN' | 'CONTENT_BUSY';
} | {
    readonly type: 'cancel';
    readonly id: string;
};
/** Validate shape and every size bound before any hashing, decryption or allocation. */
export declare function assertContentWireMessage(input: unknown): asserts input is ContentWireMessage;
/** Content RPC on an already authenticated/encrypted channel. Owns no transport or writer queue. */
export declare function createNetworkContent(options: {
    readonly content: ApplicationContent;
    readonly send: (message: ContentWireMessage) => Promise<void>;
    readonly signal: AbortSignal;
    readonly authorize: () => boolean;
    readonly peerId: string;
}): {
    handle(message: ContentWireMessage): Promise<void>;
    close(): void;
};
