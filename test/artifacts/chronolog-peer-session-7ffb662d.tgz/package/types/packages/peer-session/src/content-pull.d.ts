/**
 * Windowed, multi-source chunk puller for lazy content transfer.
 *
 * The consumer takes chunks strictly in order; the puller keeps up to `windowChunks` chunks ahead
 * of it in flight as range requests of `batchChunks`, spread over every source that has not failed
 * that chunk (at most `perSource` concurrent requests each). Sources stream each chunk to
 * `onChunk` as it is read, so one request yields many chunks with no per-chunk round trip.
 * A chunk a source lacks (null), mis-delivers (rejected by `accept`) or never sends (request
 * error) is retried on the next source; busy sources are retried after their own work drains.
 */
/** Receives each chunk of a range in order; a returned promise is awaited by the producer (backpressure). */
export type ChunkSink = (index: number, bytes: Uint8Array | null) => void | Promise<void>;
export interface RangeSource {
    fetch(start: number, count: number, onChunk: ChunkSink, signal: AbortSignal): Promise<void>;
}
export interface PullOptions {
    readonly count: number;
    /** First index the consumer will take (earlier chunks are already handled). */
    readonly start?: number;
    readonly sources: readonly RangeSource[];
    /** Already-local verified chunk, or null. */
    readonly local: (index: number, signal: AbortSignal) => Promise<Uint8Array | null>;
    /** Verify (and usually persist) one remote chunk; throws on invalid bytes. Returns the chunk to hand out. */
    readonly accept: (index: number, bytes: Uint8Array, signal: AbortSignal) => Promise<Uint8Array>;
    readonly signal: AbortSignal;
    readonly windowChunks?: number;
    /** Window before slow start grows it (default 1; whole-object pulls pass `windowChunks`). */
    readonly initialWindow?: number;
    readonly batchChunks?: number;
    readonly perSource?: number;
    readonly missing: string;
}
export declare const CONTENT_PULL_DEFAULTS: Readonly<{
    windowChunks: 64;
    batchChunks: 8;
    perSource: 8;
}>;
export declare class ChunkPuller {
    #private;
    constructor(options: PullOptions);
    /** Resolve chunk `index` (taken in increasing order) and slide the window past it. */
    take(index: number): Promise<Uint8Array>;
    close(reason?: unknown): void;
}
