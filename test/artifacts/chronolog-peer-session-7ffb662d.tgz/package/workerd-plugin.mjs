// packages/peer-session/src/workerd-plugin.ts
import { copyFileSync, mkdirSync } from "node:fs";
import { basename, join, resolve } from "node:path";
function createWorkerdWasmPlugin(options) {
  const root = resolve(options.rootDir ?? process.cwd());
  const outDir = resolve(options.outDir);
  return {
    name: "chronolog-workerd-wasm",
    setup(builder) {
      builder.onResolve(
        { filter: /(?:\.wasm$|^@jitl\/quickjs-ng-wasmfile-release-sync\/wasm$|^@chronolog\/peer-session\/sqlite-cas\.wasm$)/ },
        (args) => {
          let resolved;
          if (args.path === "@jitl/quickjs-ng-wasmfile-release-sync/wasm") {
            resolved = join(root, "node_modules/@jitl/quickjs-ng-wasmfile-release-sync/dist/emscripten-module.wasm");
          } else if (args.path === "@chronolog/peer-session/sqlite-cas.wasm") {
            resolved = join(root, "node_modules/@chronolog/peer-session/wasm/sqlite-cas.wasm");
          } else {
            resolved = join(args.resolveDir, args.path);
          }
          const name = basename(resolved);
          mkdirSync(outDir, { recursive: true });
          copyFileSync(resolved, join(outDir, name));
          options.onAsset?.(name, resolved);
          return { path: `./${name}`, external: true };
        }
      );
      builder.onResolve({ filter: /^module$/ }, () => ({
        path: "chronolog-workerd-empty-module",
        namespace: "chronolog-workerd-stub"
      }));
      builder.onLoad({ filter: /.*/, namespace: "chronolog-workerd-stub" }, () => ({
        contents: 'export function createRequire() { throw new Error("node:module is unavailable in Cloudflare Workers"); }',
        loader: "js"
      }));
    }
  };
}
export {
  createWorkerdWasmPlugin
};
