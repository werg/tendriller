import {
  TopicKernel
} from "./chunk-JGQ4V7A4.mjs";
import {
  seedStandardModules
} from "./chunk-RLBWAHGI.mjs";
import {
  parseFinalitySchedule,
  verifyFinalityV2
} from "./chunk-3Z4G43EM.mjs";
import {
  ContentAddressedStore,
  MemoryBytesStore,
  decodeCasNode,
  encodeCasNode,
  hashCasNode,
  putPackageDag,
  tryParseCasRef
} from "./chunk-OWL5GQ66.mjs";
import {
  DEFAULT_GENESIS_LIMITS,
  DEFAULT_RUNTIME_MANIFEST,
  encodeLogGenesis,
  isControlTopic
} from "./chunk-XIJQU6SK.mjs";
import {
  bytesToHex,
  utf8
} from "./chunk-VRR2HFJY.mjs";

// packages/peer-session/src/blind-host.ts
var HEX32 = /^[0-9a-f]{64}$/u;
function collectCasStringsFromJson(value, out, depth = 0) {
  if (depth > 24 || value === null || value === void 0) return;
  if (typeof value === "string") {
    const hash = tryParseCasRef(value);
    if (hash !== null) out.add(hash);
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectCasStringsFromJson(item, out, depth + 1);
    return;
  }
  if (typeof value === "object") {
    const rec = value;
    if (Array.isArray(rec.casRoots)) {
      for (const h of rec.casRoots) {
        if (typeof h === "string" && HEX32.test(h)) out.add(h);
      }
    }
    for (const v of Object.values(rec)) collectCasStringsFromJson(v, out, depth + 1);
  }
}
async function collectControlReferencedCasHashes(options) {
  const roots = /* @__PURE__ */ new Set();
  if (options.genesis !== void 0) {
    for (const [topic, val] of Object.entries(options.genesis.initialTopics)) {
      if (isControlTopic(topic)) collectCasStringsFromJson(val, roots);
    }
  }
  if (options.topics !== void 0) {
    for (const [topic, val] of Object.entries(options.topics)) {
      if (isControlTopic(topic)) collectCasStringsFromJson(val, roots);
    }
  }
  if (options.publicOps !== void 0) {
    for (const op of options.publicOps) {
      for (const u of op.updates) {
        if (isControlTopic(u.topic)) collectCasStringsFromJson(u.input, roots);
      }
    }
  }
  const visited = new Set(roots);
  const queue = [...roots];
  while (queue.length > 0) {
    const hash = queue.shift();
    let links = [];
    if (options.cas !== void 0) {
      const node = await options.cas.get(hash, "public");
      if (node !== null) links = node.links;
    } else if (options.casNodes !== void 0) {
      const raw = options.casNodes.get(hash);
      if (raw !== void 0) {
        try {
          if (hashCasNode(raw) === hash) {
            links = decodeCasNode(raw).links;
          }
        } catch {
        }
      }
    }
    for (const link of links) {
      if (HEX32.test(link) && !visited.has(link)) {
        visited.add(link);
        queue.push(link);
      }
    }
  }
  return visited;
}
function stringList(v) {
  if (!Array.isArray(v)) return [];
  return [...new Set(v.filter((x) => typeof x === "string" && HEX32.test(x)))].sort();
}
async function extractControlPermissions(kernel, rawPermsTopic) {
  const rawObj = rawPermsTopic !== null && rawPermsTopic !== void 0 && typeof rawPermsTopic === "object" && !Array.isArray(rawPermsTopic) ? rawPermsTopic : {};
  let summary = null;
  try {
    const q = await kernel.query("$permissions", { summary: true });
    if (q !== null && typeof q === "object" && !Array.isArray(q)) {
      summary = q;
    }
  } catch {
  }
  const queryList = async (role) => {
    try {
      const q = await kernel.query("$permissions", { list: role });
      if (Array.isArray(q)) return q;
    } catch {
    }
    return null;
  };
  const rawMembers = Array.isArray(summary?.members) ? summary.members.filter((m) => m !== null && typeof m === "object" && !Array.isArray(m)) : Array.isArray(rawObj.members) ? rawObj.members.filter((m) => m !== null && typeof m === "object" && !Array.isArray(m)) : [];
  const hasWildcard = (v) => Array.isArray(v) && v.includes("*");
  const rawReadersList = summary !== null && Array.isArray(summary.readers) ? summary.readers : await queryList("readers");
  const rawWritersList = summary !== null && Array.isArray(summary.writers) ? summary.writers : await queryList("writers");
  const readers = rawReadersList !== null ? stringList(rawReadersList) : stringList(rawMembers.filter((m) => m.reader === true).map((m) => m.publicKey));
  const writers = rawWritersList !== null ? stringList(rawWritersList) : stringList(rawMembers.filter((m) => m.writer === true || m.administrator === true).map((m) => m.publicKey));
  const administrators = summary !== null && Array.isArray(summary.administrators) ? stringList(summary.administrators) : stringList(await queryList("administrators") ?? rawMembers.filter((m) => m.administrator === true).map((m) => m.publicKey));
  const publishers = summary !== null && Array.isArray(summary.publishers) ? stringList(summary.publishers) : stringList(await queryList("publishers") ?? rawMembers.filter((m) => m.publisher === true || m.administrator === true).map((m) => m.publicKey));
  const finalizers = summary !== null && Array.isArray(summary.finalizers) ? stringList(summary.finalizers) : stringList(await queryList("finalizers") ?? rawMembers.filter((m) => m.finalizer === true).map((m) => m.publicKey));
  const admission = (summary !== null && summary.admission !== void 0 ? summary.admission : rawObj.admission) ?? null;
  const admissionObj = admission !== null && typeof admission === "object" && !Array.isArray(admission) ? admission : null;
  const removedMembers = stringList(admissionObj?.removed);
  const blockedAuthors = stringList(summary?.blockedAuthors ?? rawObj.blockedAuthors);
  const openRead = summary?.openReaders === true || summary?.openRead === true || hasWildcard(rawReadersList) || rawObj.openRead === true;
  const openWrite = summary?.openWriters === true || summary?.openWrite === true || hasWildcard(rawWritersList) || rawObj.openWrite === true;
  let mode = "custom";
  if (summary?.mode === "open" || summary?.mode === "multisig" || summary?.mode === "attested") {
    mode = summary.mode;
  } else if (openRead || openWrite || rawObj.openRead !== void 0) mode = "open";
  else if (typeof rawObj.threshold === "number" || Array.isArray(rawObj.proposals)) mode = "multisig";
  else if (Array.isArray(rawObj.members)) mode = "attested";
  return {
    mode,
    openRead,
    openWrite,
    members: rawMembers,
    readers,
    writers,
    administrators,
    publishers,
    finalizers,
    blockedAuthors,
    removedMembers,
    admission
  };
}
async function replayBlindHostControl(options) {
  const cas = new ContentAddressedStore({ store: new MemoryBytesStore() });
  await seedStandardModules(cas);
  if (options.publicCasNodes.length > 0) {
    await cas.putManyVerified(options.publicCasNodes.map((n) => ({
      hash: n.hash,
      bytes: n.bytes,
      partition: "public"
    })));
  }
  const kernel = new TopicKernel({
    genesis: options.genesis,
    cas,
    blindHostMode: true,
    ...options.wasmModule === void 0 ? {} : { wasmModule: options.wasmModule }
  });
  try {
    const initialPermissions = await extractControlPermissions(kernel, options.genesis.initialTopics.$permissions);
    const result = await kernel.materialize(options.publicOps);
    const snap = kernel.snapshot();
    const permissions = await extractControlPermissions(kernel, snap.topics.$permissions);
    const logIdHex = bytesToHex(kernel.logId);
    const schedule = parseFinalitySchedule(snap.topics.$finality);
    const opList = options.publicOps.map((op) => ({
      opId: bytesToHex(op.opId),
      authorTimestampMs: op.core.authorTimestampMs
    }));
    const finality = await verifyFinalityV2({
      logId: logIdHex,
      schedule,
      checkpoints: options.checkpoints ?? [],
      knownOps: opList,
      ...options.anchorVerifier === void 0 ? {} : { blockchainVerifier: options.anchorVerifier }
    });
    let finalizedTopics = null;
    if (options.includeFinalized !== false && (options.checkpoints?.length ?? 0) > 0 && finality.closedThroughMs !== null) {
      const finalOps = options.publicOps.filter((op) => finality.includedOpIds.has(bytesToHex(op.opId)));
      const finalKernel = new TopicKernel({
        genesis: options.genesis,
        cas,
        blindHostMode: true,
        ...options.wasmModule === void 0 ? {} : { wasmModule: options.wasmModule }
      });
      try {
        await finalKernel.materialize(finalOps);
        finalizedTopics = finalKernel.snapshot().topics;
      } finally {
        finalKernel.dispose();
      }
    }
    const referencedCasHashes = await collectControlReferencedCasHashes({
      genesis: options.genesis,
      topics: snap.topics,
      publicOps: options.publicOps.map((op) => op.core),
      cas
    });
    return {
      stateRoot: snap.stateRoot,
      historyDigest: snap.historyDigest,
      topics: snap.topics,
      outcomes: result.outcomes,
      pendingDependencies: result.pendingDependencies,
      permissions,
      initialPermissions,
      finality,
      finalizedTopics,
      referencedCasHashes
    };
  } finally {
    kernel.dispose();
  }
}
async function dryRunReducerUpgrade(options) {
  if (options.source === void 0 && options.pkg === void 0) {
    throw new Error("DRY_RUN_REQUIRES_SOURCE_OR_PACKAGE");
  }
  const cas = new ContentAddressedStore({ store: new MemoryBytesStore() });
  await seedStandardModules(cas);
  let rootHash;
  if (options.pkg !== void 0) {
    const placed = await putPackageDag(cas, options.pkg, "public");
    rootHash = placed.hash;
  } else {
    const rawBytes = utf8(options.source);
    const encoded = encodeCasNode(rawBytes, []);
    rootHash = hashCasNode(encoded);
    await cas.putRaw(rootHash, encoded, "public");
  }
  const ref = `cas:sha256-${rootHash}`;
  const subgraph = await cas.collectSubgraph([rootHash], { allowedPartition: "public", maxNodes: 512, maxBytes: 16 * 1024 * 1024 });
  const topicName = options.topic ?? "dry_run";
  const authorHex = "11".repeat(32);
  const genesis = {
    version: 1,
    privateLog: false,
    initialTopics: {
      $reducers: {
        runtime: DEFAULT_RUNTIME_MANIFEST,
        imports: { [options.specifier]: ref },
        topics: {
          [topicName]: {
            module: options.specifier,
            ...options.exportName === void 0 ? {} : { export: options.exportName }
          }
        }
      },
      ...options.initialState === void 0 ? {} : { [topicName]: options.initialState }
    },
    limits: DEFAULT_GENESIS_LIMITS,
    salt: new Uint8Array(16)
  };
  const kernel = new TopicKernel({
    genesis,
    cas,
    ...options.wasmModule === void 0 ? {} : { wasmModule: options.wasmModule }
  });
  const sampleOutcomes = [];
  try {
    let description;
    try {
      const desc = await kernel.describe();
      if (desc !== null && desc !== void 0) description = desc;
    } catch {
    }
    const genesisBytes = encodeLogGenesis(genesis);
    const logIdBytes = kernel.logId;
    void genesisBytes;
    if (options.sampleInputs !== void 0 && options.sampleInputs.length > 0) {
      let idx = 0;
      const ops = options.sampleInputs.map((sample) => {
        idx += 1;
        const opId = new Uint8Array(32);
        opId[31] = idx;
        const authorBytes = new Uint8Array(32);
        const hex = sample.author ?? authorHex;
        for (let i = 0; i < 32; i++) authorBytes[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
        return {
          opId,
          verified: true,
          core: {
            version: 1,
            logId: logIdBytes,
            visibility: "public",
            author: authorBytes,
            authorTimestampMs: sample.timestampMs ?? BigInt(17e11 + idx),
            nonce: new Uint8Array(16),
            operationId: `dry-run-${idx}`,
            updates: [{ topic: topicName, input: sample.payload }]
          }
        };
      });
      const mat = await kernel.materialize(ops);
      const finalState = kernel.snapshot().topics[topicName];
      for (const out of mat.outcomes) {
        sampleOutcomes.push({
          ok: out.outcome === "accepted",
          ...typeof out.rejectionCode === "string" ? { code: out.rejectionCode } : {},
          ...finalState === void 0 ? {} : { state: finalState }
        });
      }
    }
    let sampleQueryResult;
    try {
      const q = await kernel.query(topicName, options.sampleQuery ?? {});
      if (q !== void 0) sampleQueryResult = q;
    } catch (qErr) {
      const msg = qErr instanceof Error ? qErr.message : String(qErr);
      if (!msg.includes("query_not_implemented") && options.sampleQuery !== void 0) {
        return {
          ok: false,
          ref,
          hash: rootHash,
          casNodes: subgraph,
          ...description === void 0 ? {} : { description },
          sampleOutcomes,
          error: msg
        };
      }
    }
    return {
      ok: true,
      ref,
      hash: rootHash,
      casNodes: subgraph,
      ...description === void 0 ? {} : { description },
      sampleOutcomes,
      ...sampleQueryResult === void 0 ? {} : { sampleQueryResult }
    };
  } catch (err) {
    return {
      ok: false,
      ref,
      hash: rootHash,
      casNodes: subgraph,
      sampleOutcomes,
      error: err instanceof Error ? err.message : String(err)
    };
  } finally {
    kernel.dispose();
  }
}

export {
  collectControlReferencedCasHashes,
  extractControlPermissions,
  replayBlindHostControl,
  dryRunReducerUpgrade
};
