import {
  verifyEd25519Sync
} from "./chunk-X5EWPYTE.mjs";
import {
  casRef,
  decodeDerivationNode,
  decodePackageNode,
  decodeTreeNode,
  normalizePosixPath,
  parseCasRef,
  putBlobDag,
  putTreeDag,
  readBlobDag,
  readBlobDagSync,
  resolvePackageRelativePath,
  tryDecodePackageNode,
  tryParseCasRef
} from "./chunk-OWL5GQ66.mjs";
import {
  DEFAULT_RUNTIME_MANIFEST,
  assertValidReducersConfig,
  canonicalEventPayload,
  canonicalJson,
  compareOperationOrder,
  decodeLogGenesis,
  encodeCanonicalJsonCbor,
  encodeLogGenesis,
  genesisLogId,
  isControlTopic,
  normalizeJsonValue,
  operationIdDigest
} from "./chunk-XIJQU6SK.mjs";
import {
  DEFAULT_DECODE_LIMITS,
  bytesToHex,
  decodeCanonicalCbor,
  decodeUtf8,
  encodeCanonicalCbor,
  hashDomainSync,
  hexToBytes,
  perfCount,
  perfTimeAsync,
  sha256Sync,
  utf8
} from "./chunk-VRR2HFJY.mjs";

// packages/materializer/src/wasm-sandbox.ts
var ALLOWED_IMPORT_MODULES = /* @__PURE__ */ new Set(["chronolog"]);
var ALLOWED_CHRONOLOG_IMPORTS = /* @__PURE__ */ new Set(["sha256", "cas_put", "cas_get", "fuel_consume"]);
var WasmSandbox = class {
  #moduleCache = /* @__PURE__ */ new Map();
  #maxCachedModules;
  constructor(options = {}) {
    this.#maxCachedModules = options.maxCachedModules ?? 128;
  }
  get cachedModuleCount() {
    return this.#moduleCache.size;
  }
  clearCache() {
    this.#moduleCache.clear();
  }
  #compileOrGet(wasmHash, host) {
    const existing = this.#moduleCache.get(wasmHash);
    if (existing !== void 0) {
      this.#moduleCache.delete(wasmHash);
      this.#moduleCache.set(wasmHash, existing);
      return existing;
    }
    const bytes = readBlobDagSync(host.cas, wasmHash, host.readPartition, host.onMissingCas);
    const copy = new Uint8Array(bytes.byteLength);
    copy.set(bytes);
    const mod = new WebAssembly.Module(copy);
    for (const imp of WebAssembly.Module.imports(mod)) {
      if (!ALLOWED_IMPORT_MODULES.has(imp.module) || !ALLOWED_CHRONOLOG_IMPORTS.has(imp.name)) {
        throw new Error(`WASM_IMPORT_FORBIDDEN:${imp.module}.${imp.name}`);
      }
    }
    const entry = { module: mod, byteLength: bytes.byteLength };
    this.#moduleCache.set(wasmHash, entry);
    while (this.#moduleCache.size > this.#maxCachedModules) {
      const oldest = this.#moduleCache.keys().next().value;
      if (oldest === void 0) break;
      this.#moduleCache.delete(oldest);
    }
    return entry;
  }
  #instantiate(wasmHash, host) {
    const compiled = this.#compileOrGet(wasmHash, host);
    let fuelUsed = 0;
    let exhausted = false;
    let mem = null;
    const getMemory = () => {
      if (mem === null) throw new Error("WASM_MEMORY_MISSING");
      if (mem.buffer.byteLength > host.maxMemoryBytes) {
        throw new Error("WASM_MEMORY_LIMIT_EXCEEDED");
      }
      return new Uint8Array(mem.buffer);
    };
    const imports = {
      chronolog: {
        fuel_consume(amount) {
          fuelUsed += Math.max(1, amount | 0);
          if (fuelUsed > host.maxFuel) {
            exhausted = true;
            throw new Error("WASM_FUEL_EXHAUSTED");
          }
        },
        sha256(inPtr, inLen, outPtr) {
          const view = getMemory();
          const slice = view.subarray(inPtr >>> 0, (inPtr >>> 0) + (inLen >>> 0));
          const digest = sha256Sync(slice);
          view.set(digest, outPtr >>> 0);
          return digest.byteLength;
        },
        cas_put(inPtr, inLen, outHashPtr) {
          if (host.readOnly) throw new Error("CAS_READ_ONLY");
          const view = getMemory();
          const slice = view.slice(inPtr >>> 0, (inPtr >>> 0) + (inLen >>> 0));
          const hashHex = host.cas.putSync(slice, [], host.writePartition);
          const hashBytes = hexToBytes(hashHex);
          view.set(hashBytes, outHashPtr >>> 0);
          return hashBytes.byteLength;
        },
        cas_get(hashPtr, outPtr, maxLen) {
          const view = getMemory();
          const hashBytes = view.subarray(hashPtr >>> 0, (hashPtr >>> 0) + 32);
          const hashHex = bytesToHex(hashBytes);
          const node = host.cas.getSync(hashHex, host.readPartition);
          if (node === null) host.onMissingCas(hashHex);
          const len = node.bytes.byteLength;
          if (len > maxLen >>> 0) return -len;
          view.set(node.bytes, outPtr >>> 0);
          return len;
        }
      }
    };
    const instance = new WebAssembly.Instance(compiled.module, imports);
    const exportedMem = instance.exports.memory;
    if (exportedMem instanceof WebAssembly.Memory) {
      mem = exportedMem;
      if (mem.buffer.byteLength > host.maxMemoryBytes) {
        throw new Error("WASM_MEMORY_LIMIT_EXCEEDED");
      }
    }
    return { instance, fuelExhausted: () => exhausted };
  }
  /** Invoke a numeric export on a cached pure WASM module (for JS reducers using chronolog:wasm). */
  invokeNumeric(wasmHash, exportName, args, host) {
    const { instance, fuelExhausted } = this.#instantiate(wasmHash, host);
    const fn = instance.exports[exportName];
    if (typeof fn !== "function") throw new Error(`WASM_EXPORT_NOT_FOUND:${exportName}`);
    try {
      const out = fn(...args);
      if (typeof out === "bigint") return Number(out);
      if (typeof out === "number") {
        if (!Number.isFinite(out)) throw new Error("WASM_NON_FINITE_RESULT");
        return Object.is(out, -0) ? 0 : out;
      }
      return 0;
    } catch (err) {
      if (fuelExhausted()) throw new Error("WASM_FUEL_EXHAUSTED", { cause: err });
      throw err;
    }
  }
  /** Invoke a JSON-ABI export (alloc + ptr/len -> packed i64 or i32 + result_len) on a pure WASM module. */
  invokeJson(wasmHash, exportName, input, host) {
    const { instance, fuelExhausted } = this.#instantiate(wasmHash, host);
    const mem = instance.exports.memory;
    const alloc = instance.exports.alloc;
    const fn = instance.exports[exportName];
    if (!(mem instanceof WebAssembly.Memory)) throw new Error("WASM_MEMORY_MISSING");
    if (typeof alloc !== "function") throw new Error("WASM_ALLOC_MISSING");
    if (typeof fn !== "function") throw new Error(`WASM_EXPORT_NOT_FOUND:${exportName}`);
    const inputBytes = utf8(JSON.stringify(input));
    const inPtr = Number(alloc(inputBytes.byteLength)) >>> 0;
    if (mem.buffer.byteLength > host.maxMemoryBytes) throw new Error("WASM_MEMORY_LIMIT_EXCEEDED");
    new Uint8Array(mem.buffer, inPtr, inputBytes.byteLength).set(inputBytes);
    let rawResult;
    try {
      rawResult = fn(inPtr, inputBytes.byteLength);
    } catch (err) {
      if (fuelExhausted()) throw new Error("WASM_FUEL_EXHAUSTED", { cause: err });
      throw err;
    }
    if (mem.buffer.byteLength > host.maxMemoryBytes) throw new Error("WASM_MEMORY_LIMIT_EXCEEDED");
    let outPtr;
    let outLen;
    if (typeof rawResult === "bigint") {
      outPtr = Number(rawResult >> 32n & 0xffffffffn) >>> 0;
      outLen = Number(rawResult & 0xffffffffn) >>> 0;
    } else if (typeof rawResult === "number") {
      const resultLenFn = instance.exports.result_len;
      if (typeof resultLenFn !== "function") throw new Error("WASM_RESULT_LEN_MISSING");
      outPtr = rawResult >>> 0;
      outLen = Number(resultLenFn()) >>> 0;
    } else {
      throw new Error("WASM_INVALID_RETURN_ABI");
    }
    if (outPtr + outLen > mem.buffer.byteLength) throw new Error("WASM_OUT_OF_BOUNDS_RESULT");
    const outText = decodeUtf8(new Uint8Array(mem.buffer, outPtr, outLen));
    return normalizeJsonValue(JSON.parse(outText));
  }
  /** Execute a standalone pure WASM topic reducer (chronolog-wasm/v1 ABI). */
  invokeReducer(input) {
    const { instance, fuelExhausted } = this.#instantiate(input.wasmHash, input.host);
    const fn = instance.exports[input.method];
    if (typeof fn !== "function") {
      return { ok: false, code: `vm:missing_method:${input.method}` };
    }
    const envelope = {
      state: input.state,
      payload: input.payload,
      tx: input.tx === void 0 ? null : { ...input.tx, payload: input.payload },
      conflict: input.conflict ?? null,
      topics: input.topics,
      config: input.config ?? null
    };
    try {
      const val = this.invokeJson(input.wasmHash, input.method, envelope, input.host);
      return { ok: true, value: val };
    } catch (err) {
      if (fuelExhausted() || err instanceof Error && err.message === "WASM_FUEL_EXHAUSTED") {
        return { ok: false, code: "vm:fuel_exhausted" };
      }
      if (err instanceof Error && err.message === "WASM_MEMORY_LIMIT_EXCEEDED") {
        return { ok: false, code: "vm:limit" };
      }
      if (err !== null && typeof err === "object" && "code" in err && err.code === "MISSING_DEPENDENCY") {
        throw err;
      }
      return { ok: false, code: "reducer:throw", detail: err instanceof Error ? err.message : String(err) };
    }
  }
};

// packages/materializer/src/quickjs-sandbox.ts
import {
  newQuickJSWASMModuleFromVariant,
  newVariant
} from "quickjs-emscripten-core";
import baseVariant from "@jitl/quickjs-ng-wasmfile-release-sync";
var DEFAULT_MAX_FUEL = 2e5;
var MissingDependencyError = class extends Error {
  constructor(hash, kind = "cas") {
    super(`MISSING_DEPENDENCY:${kind}/${hash}`);
    this.hash = hash;
    this.kind = kind;
    this.name = "MissingDependencyError";
  }
  hash;
  kind;
  code = "MISSING_DEPENDENCY";
};
var OperationalTimeoutError = class extends Error {
  code = "OPERATIONAL_TIMEOUT";
  constructor(message = "REDUCER_WATCHDOG_TIMEOUT") {
    super(message);
    this.name = "OperationalTimeoutError";
  }
};
var CRYPTO_MODULE_SHIM = `
export function sha256(input) { return globalThis.__chronologHost.sha256(input); }
export function verifyEd25519(pubKeyHex, message, sigHex) { return globalThis.__chronologHost.verifyEd25519(pubKeyHex, message, sigHex); }
export function canonicalJson(value) { return globalThis.__chronologHost.canonicalJson(value); }
`;
var CAS_MODULE_SHIM = `
export function put(bytes, links = []) { return globalThis.__chronologHost.casPut(bytes, links); }
export function get(hash) { return globalThis.__chronologHost.casGet(hash); }
`;
var WASM_MODULE_SHIM = `
export function invoke(wasmHashOrRef, exportName, args = []) {
  return JSON.parse(globalThis.__chronologHost.wasmInvoke(String(wasmHashOrRef), String(exportName), JSON.stringify(args ?? [])));
}
export function invokeJson(wasmHashOrRef, exportName, input = null) {
  return JSON.parse(globalThis.__chronologHost.wasmInvokeJson(String(wasmHashOrRef), String(exportName), JSON.stringify(input === undefined ? null : input)));
}
`;
var SQLITE_MODULE_SHIM = `
export function openDb(dbRoot = null) {
  const handleId = globalThis.__chronologHost.sqlOpen(dbRoot);
  return {
    exec(sql, params = [], options = {}) {
      return JSON.parse(globalThis.__chronologHost.sqlExec(handleId, String(sql), JSON.stringify(params ?? []), JSON.stringify(options ?? {})));
    },
    query(sql, params = []) {
      return JSON.parse(globalThis.__chronologHost.sqlQuery(handleId, String(sql), JSON.stringify(params ?? [])));
    },
    validateExpr(table, sqlOp, expr) {
      globalThis.__chronologHost.sqlValidateExpr(handleId, String(table), String(sqlOp), String(expr));
    },
    commit() {
      return globalThis.__chronologHost.sqlCommit(handleId);
    },
    close() {
      globalThis.__chronologHost.sqlClose(handleId);
    },
  };
}
`;
var DETERMINISM_PRELUDE = `
Object.defineProperty(globalThis, 'Date', { value: undefined, writable: false, configurable: false });
Object.defineProperty(Math, 'random', { value: () => { throw new Error('NONDETERMINISTIC_MATH_RANDOM'); }, writable: false, configurable: false });
for (const k of ['Intl', 'performance', 'WeakRef', 'FinalizationRegistry']) {
  if (typeof globalThis[k] !== 'undefined') {
    Object.defineProperty(globalThis, k, { value: undefined, writable: false, configurable: false });
  }
}
[JSON, JSON.parse, JSON.stringify, String, Object.is,
  (topic, query, mount, mountQuery, opOutcome, topicLastOpId, config) => Object.freeze({ topic, query, mount, mountQuery, opOutcome, topicLastOpId, config }),
  (out) => JSON.stringify({ __ok: true, value: out })];
`;
var VmThrow = class extends Error {
  constructor(error) {
    super("VM_EXCEPTION");
    this.error = error;
  }
  error;
};
var ENTRY_MODULE_NAME = "__chronolog_entry__";
function entryModuleSource(moduleSpecifier, exportName) {
  return exportName === "default" ? `import __target from ${JSON.stringify(moduleSpecifier)};
export default __target;` : `import { ${exportName} as __target } from ${JSON.stringify(moduleSpecifier)};
export default __target;`;
}
var MOUNT_HELPER_SOURCE = `(m, name) => m && typeof m === 'object' && m.mounts && Object.prototype.hasOwnProperty.call(m.mounts, String(name)) ? m.mounts[String(name)] : null`;
var HOST_BUILTIN_FUNCTIONS = {
  "chronolog:crypto": ["sha256", "verifyEd25519", "canonicalJson"],
  "chronolog:cas": ["casPut", "casGet"],
  "chronolog:wasm": ["wasmInvoke", "wasmInvokeJson"],
  "chronolog:sqlite": ["sqlOpen", "sqlExec", "sqlQuery", "sqlValidateExpr", "sqlCommit", "sqlClose"]
};
function txJson(input) {
  return input.tx === void 0 ? null : { ...input.tx, payload: input.payload };
}
var defaultQuickJsPromise = null;
var sharedQuickJs = /* @__PURE__ */ new WeakMap();
async function loadQuickJsModule(wasmModule) {
  const syncBase = baseVariant;
  if (wasmModule !== void 0) {
    let shared = sharedQuickJs.get(wasmModule);
    if (shared === void 0) {
      shared = newQuickJSWASMModuleFromVariant(newVariant(syncBase, { wasmModule }));
      sharedQuickJs.set(wasmModule, shared);
      shared.catch(() => sharedQuickJs.delete(wasmModule));
    }
    return shared;
  }
  if (defaultQuickJsPromise === null) {
    defaultQuickJsPromise = newQuickJSWASMModuleFromVariant(syncBase).catch((err) => {
      defaultQuickJsPromise = null;
      throw err;
    });
  }
  return defaultQuickJsPromise;
}
function splitBareSpecifier(spec) {
  if (spec.startsWith("@")) {
    const parts = spec.split("/");
    if (parts.length >= 2) {
      const pkgName = `${parts[0]}/${parts[1]}`;
      const rest = parts.slice(2).join("/");
      return { pkgName, subpath: rest.length === 0 ? "." : `./${rest}` };
    }
  }
  const slash = spec.indexOf("/");
  if (slash < 0) return { pkgName: spec, subpath: "." };
  return { pkgName: spec.slice(0, slash), subpath: `./${spec.slice(slash + 1)}` };
}
var QuickJsSandbox = class {
  #wasmPromise;
  #sqliteDriver;
  #watchdogMs;
  #runtimePool = [];
  #nestedQueryCache = /* @__PURE__ */ new Map();
  /** Content-addressed immutable cache: casHash -> parsed chronolog-pkg/v1 manifest or decoded UTF-8 JS source. */
  #moduleCache = /* @__PURE__ */ new Map();
  #wasmSandbox = new WasmSandbox();
  constructor(options = {}) {
    this.#wasmPromise = loadQuickJsModule(options.wasmModule);
    this.#sqliteDriver = options.sqliteDriver;
    this.#watchdogMs = options.watchdogMs ?? 2e3;
  }
  get sqliteBuiltinId() {
    return this.#sqliteDriver?.builtinId ?? null;
  }
  get wasmSandbox() {
    return this.#wasmSandbox;
  }
  #disposed = false;
  get disposed() {
    return this.#disposed;
  }
  /** Release pooled runtimes and caches. Idempotent; later invocations throw SANDBOX_DISPOSED. */
  dispose() {
    this.#disposed = true;
    for (let i = 0; i < this.#runtimePool.length; i++) {
      try {
        this.#runtimePool[i]?.dispose();
      } catch {
      }
      this.#runtimePool[i] = void 0;
    }
    this.#nestedQueryCache.clear();
    this.#moduleCache.clear();
    this.#wasmSandbox.clearCache();
  }
  /**
   * Inspect a module CAS node (demand-paging if needed) to check whether it is a pure-WASM package.
   */
  #inspectCasModuleSync(hash, cas, readPartition, onMissing) {
    const cached = this.#moduleCache.get(hash);
    if (cached !== void 0) {
      if (readPartition === "public" && !cas.hasSync(hash, "public")) {
        onMissing(hash);
      }
      return cached;
    }
    const node = cas.getSync(hash, readPartition);
    if (node === null) onMissing(hash);
    const pkg = tryDecodePackageNode(node.bytes);
    let entry;
    if (pkg !== null) {
      entry = { kind: "package", pkg };
    } else {
      const fullBytes = node.links.length === 0 ? node.bytes : readBlobDagSync(cas, hash, readPartition, onMissing);
      entry = { kind: "source", text: decodeUtf8(fullBytes) };
    }
    this.#moduleCache.set(hash, entry);
    if (this.#moduleCache.size > 1024) {
      const oldest = this.#moduleCache.keys().next().value;
      if (oldest !== void 0) this.#moduleCache.delete(oldest);
    }
    return entry;
  }
  /**
   * Execute one deterministic reduce/query/describe/onConflict/derive call.
   * Automatically dispatches runtime === 'wasm-pure' packages to WasmSandbox and
   * JS/hybrid packages to a fresh isolated QuickJSContext with 2-arg scoped resolution.
   */
  async invoke(input) {
    if (this.#disposed) throw new Error("SANDBOX_DISPOSED");
    const readPartition = input.casPartition === "public" ? "public" : "any";
    const maxFuel = input.maxFuel ?? DEFAULT_MAX_FUEL;
    for (let faults = 0; faults < 256; faults++) {
      try {
        perfCount(`vm.${input.method}`);
        const targetRef = tryParseCasRef(input.moduleSpecifier) !== null ? input.moduleSpecifier : input.imports[input.moduleSpecifier];
        const targetHash = targetRef !== void 0 ? tryParseCasRef(targetRef) : null;
        if (targetHash !== null && input.method !== "derive") {
          const onMissing = (h) => {
            throw new MissingDependencyError(h, "module");
          };
          const inspected = this.#inspectCasModuleSync(targetHash, input.cas, readPartition, onMissing);
          if (inspected.kind === "package" && inspected.pkg.runtime === "wasm-pure" && inspected.pkg.wasm !== void 0) {
            const wasmFileRef = inspected.pkg.files[inspected.pkg.wasm.entry];
            if (wasmFileRef === void 0) return { ok: false, code: "vm:module_load_error", detail: "WASM_ENTRY_MISSING" };
            const wasmHash = parseCasRef(wasmFileRef);
            return this.#wasmSandbox.invokeReducer({
              wasmHash,
              method: input.method,
              state: input.state,
              payload: input.payload,
              ...input.tx === void 0 ? {} : { tx: input.tx },
              ...input.conflict === void 0 ? {} : { conflict: input.conflict },
              topics: input.topics,
              ...input.config === void 0 ? {} : { config: input.config },
              host: {
                cas: input.cas,
                readPartition,
                writePartition: input.casPartition,
                readOnly: input.readOnly,
                maxMemoryBytes: input.maxMemoryBytes,
                maxFuel,
                onMissingCas: (h) => {
                  throw new MissingDependencyError(h, "cas");
                }
              }
            });
          }
        }
        const qjs2 = await this.#wasmPromise;
        return this.#invokeSync(qjs2, input, 0);
      } catch (err) {
        if (err instanceof MissingDependencyError && await input.cas.ensureLoaded(err.hash, readPartition)) {
          continue;
        }
        throw err;
      }
    }
    const qjs = await this.#wasmPromise;
    return this.#invokeSync(qjs, input, 0);
  }
  #acquireRuntime(qjs, depth) {
    const existing = this.#runtimePool[depth];
    if (existing !== void 0) {
      this.#runtimePool[depth] = void 0;
      return existing;
    }
    return qjs.newRuntime();
  }
  #releaseRuntime(runtime, depth, healthy) {
    if (healthy && this.#runtimePool[depth] === void 0) {
      this.#runtimePool[depth] = runtime;
      return;
    }
    try {
      runtime.dispose();
    } catch {
    }
  }
  #invokeSync(qjs, input, depth) {
    const runtime = this.#acquireRuntime(qjs, depth);
    const openDbs = /* @__PURE__ */ new Map();
    let nextDbId = 1;
    let missingDep = null;
    const moduleLoadState = { error: null };
    let fuelExhausted = false;
    let timedOut = false;
    let healthy = true;
    const maxFuel = input.maxFuel ?? DEFAULT_MAX_FUEL;
    let fuelTicks = 0;
    const deadline = Date.now() + this.#watchdogMs;
    const readPartition = input.casPartition === "public" ? "public" : "any";
    const writePartition = input.casPartition;
    const tripMissing = (hash, kind) => {
      const err = new MissingDependencyError(hash, kind);
      missingDep ??= err;
      throw err;
    };
    const resolveCasTargetToCanonical = (ref, subpath) => {
      const hash = tryParseCasRef(ref);
      if (hash === null) return { error: new Error(`MODULE_REF_INVALID:${ref}`) };
      try {
        const inspected = this.#inspectCasModuleSync(hash, input.cas, readPartition, (h) => tripMissing(h, "module"));
        if (inspected.kind === "package") {
          const exported = inspected.pkg.exports[subpath];
          if (exported !== void 0) return `pkg:${hash}/${exported}`;
          const direct = subpath.startsWith("./") ? subpath.slice(2) : subpath;
          if (Object.hasOwn(inspected.pkg.files, direct)) return `pkg:${hash}/${direct}`;
          return { error: new Error(`PACKAGE_EXPORT_NOT_FOUND:${casRef(hash)}:${subpath}`) };
        }
        if (subpath !== ".") return { error: new Error(`LEAF_MODULE_NO_SUBPATH:${ref}:${subpath}`) };
        return `cas:${hash}`;
      } catch (err) {
        if (err instanceof MissingDependencyError) return { error: err };
        return { error: err instanceof Error ? err : new Error(String(err)) };
      }
    };
    let installHost = () => {
      throw new Error("HOST_NOT_READY");
    };
    try {
      runtime.setMemoryLimit(input.maxMemoryBytes);
      runtime.setMaxStackSize(512 * 1024);
      runtime.setInterruptHandler(() => {
        if (missingDep !== null) return true;
        if (++fuelTicks > maxFuel) {
          fuelExhausted = true;
          return true;
        }
        if (input.readOnly && Date.now() > deadline) {
          timedOut = true;
          return true;
        }
        return false;
      });
      runtime.setModuleLoader(
        (moduleName) => {
          if (moduleName === "chronolog:crypto") {
            if (!Object.hasOwn(input.builtins, "chronolog:crypto")) return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:crypto") };
            installHost("chronolog:crypto");
            return CRYPTO_MODULE_SHIM;
          }
          if (moduleName === "chronolog:cas") {
            if (!Object.hasOwn(input.builtins, "chronolog:cas")) return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:cas") };
            installHost("chronolog:cas");
            return CAS_MODULE_SHIM;
          }
          if (moduleName === "chronolog:wasm") {
            if (!Object.hasOwn(input.builtins, "chronolog:wasm")) return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:wasm") };
            installHost("chronolog:wasm");
            return WASM_MODULE_SHIM;
          }
          if (moduleName === "chronolog:sqlite") {
            if (!Object.hasOwn(input.builtins, "chronolog:sqlite") || this.#sqliteDriver === void 0) {
              return { error: new Error("BUILTIN_NOT_ENABLED:chronolog:sqlite") };
            }
            installHost("chronolog:sqlite");
            return SQLITE_MODULE_SHIM;
          }
          if (moduleName === ENTRY_MODULE_NAME) return entryModuleSource(input.moduleSpecifier, input.exportName);
          if (moduleName.startsWith("pkg:")) {
            const rest = moduleName.slice(4);
            const slash = rest.indexOf("/");
            if (slash !== 64) return { error: new Error(`PACKAGE_MODULE_ID_INVALID:${moduleName}`) };
            const pkgHash = rest.slice(0, 64);
            const filePath = rest.slice(65);
            try {
              const inspected = this.#inspectCasModuleSync(pkgHash, input.cas, readPartition, (h) => tripMissing(h, "module"));
              if (inspected.kind !== "package") return { error: new Error(`PACKAGE_EXPECTED:${pkgHash}`) };
              const fileRef = inspected.pkg.files[filePath];
              if (fileRef === void 0) return { error: new Error(`PACKAGE_FILE_NOT_FOUND:${pkgHash}/${filePath}`) };
              const fileHash = parseCasRef(fileRef);
              const fileEntry = this.#inspectCasModuleSync(fileHash, input.cas, readPartition, (h) => tripMissing(h, "module"));
              if (fileEntry.kind !== "source") return { error: new Error(`PACKAGE_FILE_NOT_SOURCE:${filePath}`) };
              return fileEntry.text;
            } catch (err) {
              if (err instanceof MissingDependencyError) return { error: err };
              return { error: err instanceof Error ? err : new Error(String(err)) };
            }
          }
          if (moduleName.startsWith("cas:")) {
            const hash = moduleName.slice(4);
            try {
              const entry = this.#inspectCasModuleSync(hash, input.cas, readPartition, (h) => tripMissing(h, "module"));
              if (entry.kind !== "source") return { error: new Error(`MODULE_NOT_SOURCE:${moduleName}`) };
              return entry.text;
            } catch (err) {
              if (err instanceof MissingDependencyError) return { error: err };
              return { error: err instanceof Error ? err : new Error(String(err)) };
            }
          }
          return { error: new Error(`MODULE_NOT_FOUND:${moduleName}`) };
        },
        (baseModuleName, requestedName) => {
          if (requestedName === ENTRY_MODULE_NAME) return ENTRY_MODULE_NAME;
          if (requestedName.startsWith("chronolog:")) {
            if (!Object.hasOwn(input.builtins, requestedName)) {
              const err = new Error(`BUILTIN_NOT_ENABLED:${requestedName}`);
              moduleLoadState.error ??= err;
              return { error: err };
            }
            if (baseModuleName.startsWith("pkg:")) {
              const pkgHash = baseModuleName.slice(4, 68);
              try {
                const inspected = this.#inspectCasModuleSync(pkgHash, input.cas, readPartition, (h) => tripMissing(h, "module"));
                if (inspected.kind === "package") {
                  if (!inspected.pkg.builtins.includes(requestedName)) {
                    const err = new Error(`BUILTIN_CAPABILITY_DENIED:${requestedName}`);
                    moduleLoadState.error ??= err;
                    return { error: err };
                  }
                }
              } catch (err) {
                if (err instanceof MissingDependencyError) return { error: err };
                const wrapped = err instanceof Error ? err : new Error(String(err));
                moduleLoadState.error ??= wrapped;
                return { error: wrapped };
              }
            }
            return requestedName;
          }
          if (requestedName.startsWith("cas:sha256-")) {
            return resolveCasTargetToCanonical(requestedName, ".");
          }
          if (requestedName.startsWith("./") || requestedName.startsWith("../")) {
            if (!baseModuleName.startsWith("pkg:")) {
              return { error: new Error(`RELATIVE_IMPORT_OUTSIDE_PACKAGE:${requestedName}`) };
            }
            const rest = baseModuleName.slice(4);
            const pkgHash = rest.slice(0, 64);
            const currentFile = rest.slice(65);
            try {
              const inspected = this.#inspectCasModuleSync(pkgHash, input.cas, readPartition, (h) => tripMissing(h, "module"));
              if (inspected.kind !== "package") return { error: new Error(`PACKAGE_EXPECTED:${pkgHash}`) };
              const resolved = resolvePackageRelativePath(currentFile, requestedName);
              for (const candidate of [resolved, `${resolved}.js`, `${resolved}.mjs`, `${resolved}/index.js`]) {
                if (Object.hasOwn(inspected.pkg.files, candidate)) {
                  return `pkg:${pkgHash}/${candidate}`;
                }
              }
              return { error: new Error(`PACKAGE_FILE_NOT_FOUND:${pkgHash}/${resolved}`) };
            } catch (err) {
              if (err instanceof MissingDependencyError) return { error: err };
              return { error: err instanceof Error ? err : new Error(String(err)) };
            }
          }
          if (baseModuleName.startsWith("pkg:")) {
            const pkgHash = baseModuleName.slice(4, 68);
            try {
              const inspected = this.#inspectCasModuleSync(pkgHash, input.cas, readPartition, (h) => tripMissing(h, "module"));
              if (inspected.kind === "package") {
                const exactDep = inspected.pkg.dependencies[requestedName];
                if (exactDep !== void 0) {
                  return resolveCasTargetToCanonical(exactDep, ".");
                }
                const { pkgName: pkgName2, subpath: subpath2 } = splitBareSpecifier(requestedName);
                const scopedDep = inspected.pkg.dependencies[pkgName2];
                if (scopedDep !== void 0) {
                  return resolveCasTargetToCanonical(scopedDep, subpath2);
                }
              }
            } catch (err) {
              if (err instanceof MissingDependencyError) return { error: err };
              return { error: err instanceof Error ? err : new Error(String(err)) };
            }
          }
          const directRef = input.imports[requestedName];
          if (directRef !== void 0) {
            return resolveCasTargetToCanonical(directRef, ".");
          }
          const { pkgName, subpath } = splitBareSpecifier(requestedName);
          const pkgRef = input.imports[pkgName];
          if (pkgRef !== void 0) {
            return resolveCasTargetToCanonical(pkgRef, subpath);
          }
          return { error: new Error(`MODULE_NOT_FOUND:${requestedName}`) };
        }
      );
      perfCount("vm.newContext");
      const ctx = runtime.newContext();
      const owned = [];
      const own = (h) => {
        owned.push(h);
        return h;
      };
      try {
        const preludeRes = ctx.evalCode(DETERMINISM_PRELUDE, "__prelude__.js");
        if (preludeRes.error) {
          preludeRes.error.dispose();
          return { ok: false, code: "vm:prelude_failed" };
        }
        const preludeOut = own(preludeRes.value);
        const intrinsic = (i) => own(ctx.getProp(preludeOut, i));
        const hostImpls = /* @__PURE__ */ new Map();
        const bindFn = (name, fn) => {
          hostImpls.set(name, fn);
        };
        const hostObj = own(ctx.newObject());
        ctx.setProp(ctx.global, "__chronologHost", hostObj);
        const installed = /* @__PURE__ */ new Set();
        installHost = (builtin) => {
          if (installed.has(builtin)) return;
          installed.add(builtin);
          for (const name of HOST_BUILTIN_FUNCTIONS[builtin]) {
            const fn = hostImpls.get(name);
            if (fn === void 0) continue;
            const handle = ctx.newFunction(name, (...args) => {
              if (missingDep !== null) throw missingDep;
              return fn(...args);
            });
            ctx.setProp(hostObj, name, handle);
            handle.dispose();
          }
        };
        const queryTopic = (topicName, inputJson) => {
          if (depth >= 4) throw new Error("TOPIC_QUERY_DEPTH_EXCEEDED");
          if (readPartition === "public" && !isControlTopic(topicName)) {
            return "null";
          }
          const rawQueryInput = JSON.parse(inputJson);
          const topicState = Object.hasOwn(input.topics, topicName) ? input.topics[topicName] : null;
          const binding = input.topicBindings?.[topicName];
          if (binding === void 0) {
            return JSON.stringify(topicState);
          }
          const nestedPartition = readPartition === "public" || isControlTopic(topicName) ? "public" : input.casPartition;
          const modRef = input.imports[binding.module] ?? binding.module;
          const canMemoize = isControlTopic(topicName) && modRef.startsWith("cas:sha256-") && Object.keys(input.imports).length <= 32;
          let memoKey = null;
          if (canMemoize) {
            const stateKey = input.topicHash?.(topicName) ?? bytesToHex(sha256Sync(utf8(JSON.stringify(topicState))));
            const inputKey = JSON.stringify(rawQueryInput);
            const configKey = binding.config === void 0 ? "" : JSON.stringify(binding.config);
            memoKey = `${nestedPartition}\0${modRef}\0${binding.export ?? "default"}\0${stateKey}\0${configKey}\0${inputKey}`;
            const hit = this.#nestedQueryCache.get(memoKey);
            if (hit !== void 0) {
              this.#nestedQueryCache.delete(memoKey);
              this.#nestedQueryCache.set(memoKey, hit);
              return hit;
            }
          }
          let nestedRes;
          try {
            nestedRes = this.#invokeSync(qjs, {
              imports: input.imports,
              builtins: input.builtins,
              ...input.topicBindings === void 0 ? {} : { topicBindings: input.topicBindings },
              moduleSpecifier: binding.module,
              exportName: binding.export ?? "default",
              method: "query",
              state: topicState,
              payload: normalizeJsonValue(rawQueryInput),
              topics: input.topics,
              ...input.topicHash === void 0 ? {} : { topicHash: input.topicHash },
              ...binding.config === void 0 ? {} : { config: binding.config },
              cas: input.cas,
              casPartition: nestedPartition,
              readOnly: true,
              maxMemoryBytes: input.maxMemoryBytes,
              maxFuel
            }, depth + 1);
          } catch (err) {
            if (err instanceof MissingDependencyError) {
              missingDep ??= err;
              throw err;
            }
            throw err;
          }
          if (!nestedRes.ok) {
            if (nestedRes.code === "vm:missing_method:query") {
              return JSON.stringify(topicState);
            }
            throw new Error(`TOPIC_QUERY_FAILED:${nestedRes.code}:${nestedRes.detail ?? ""}`);
          }
          const serialized = JSON.stringify(nestedRes.value);
          if (memoKey !== null) {
            this.#nestedQueryCache.set(memoKey, serialized);
            if (this.#nestedQueryCache.size > 512) {
              const oldest = this.#nestedQueryCache.keys().next().value;
              if (oldest !== void 0) this.#nestedQueryCache.delete(oldest);
            }
          }
          return serialized;
        };
        const queryMount = (mountName, topicName, inputJson) => {
          if (depth >= 4) throw new Error("TOPIC_QUERY_DEPTH_EXCEEDED");
          const rawQueryInput = JSON.parse(inputJson);
          const mountsTopic = input.topics.$mounts;
          if (mountsTopic === null || typeof mountsTopic !== "object" || Array.isArray(mountsTopic)) {
            return "null";
          }
          const mountsMap = mountsTopic.mounts;
          if (mountsMap === null || typeof mountsMap !== "object" || Array.isArray(mountsMap)) {
            return "null";
          }
          const mountRec = mountsMap[mountName];
          if (mountRec === null || typeof mountRec !== "object" || Array.isArray(mountRec)) {
            return "null";
          }
          const mountedTopics = mountRec.topics;
          if (mountedTopics === null || typeof mountedTopics !== "object" || Array.isArray(mountedTopics)) {
            return "null";
          }
          const mt = mountedTopics;
          const targetState = Object.hasOwn(mt, topicName) ? mt[topicName] : null;
          const mountedReducersRaw = mt.$reducers;
          if (mountedReducersRaw === void 0) {
            return JSON.stringify(targetState);
          }
          const mountedReducers = assertValidReducersConfig(mountedReducersRaw);
          const binding = mountedReducers.topics[topicName];
          if (binding === void 0) {
            return JSON.stringify(targetState);
          }
          let nestedRes;
          try {
            nestedRes = this.#invokeSync(qjs, {
              imports: mountedReducers.imports,
              builtins: mountedReducers.runtime.builtins,
              topicBindings: mountedReducers.topics,
              moduleSpecifier: binding.module,
              exportName: binding.export ?? "default",
              method: "query",
              state: targetState,
              payload: normalizeJsonValue(rawQueryInput),
              topics: mt,
              ...binding.config === void 0 ? {} : { config: binding.config },
              cas: input.cas,
              casPartition: "public",
              readOnly: true,
              maxMemoryBytes: input.maxMemoryBytes,
              maxFuel
            }, depth + 1);
          } catch (err) {
            if (err instanceof MissingDependencyError) {
              missingDep ??= err;
              throw err;
            }
            throw err;
          }
          if (!nestedRes.ok) {
            if (nestedRes.code === "vm:missing_method:query") {
              return JSON.stringify(targetState);
            }
            throw new Error(`MOUNT_QUERY_FAILED:${nestedRes.code}:${nestedRes.detail ?? ""}`);
          }
          return JSON.stringify(nestedRes.value);
        };
        bindFn("sha256", (dataHandle) => {
          const raw = ctx.dump(dataHandle);
          const bytes = typeof raw === "string" ? utf8(raw) : raw instanceof Uint8Array ? raw : utf8(JSON.stringify(raw));
          return ctx.newString(bytesToHex(sha256Sync(bytes)));
        });
        bindFn("verifyEd25519", (pubH, msgH, sigH) => {
          const pubHex = ctx.getString(pubH);
          const msgRaw = ctx.dump(msgH);
          const sigHex = ctx.getString(sigH);
          if (!/^[0-9a-f]{64}$/u.test(pubHex) || !/^[0-9a-f]{128}$/u.test(sigHex)) return ctx.false;
          const msgBytes = typeof msgRaw === "string" ? utf8(msgRaw) : msgRaw instanceof Uint8Array ? msgRaw : utf8(JSON.stringify(msgRaw));
          return verifyEd25519Sync(hexToBytes(pubHex), msgBytes, hexToBytes(sigHex)) ? ctx.true : ctx.false;
        });
        bindFn("canonicalJson", (valH) => {
          const val = normalizeJsonValue(ctx.dump(valH));
          return ctx.newString(canonicalEventPayload(val));
        });
        bindFn("casPut", (bytesH, linksH) => {
          if (input.readOnly) throw new Error("CAS_READ_ONLY");
          const raw = ctx.dump(bytesH);
          const bytes = typeof raw === "string" ? utf8(raw) : raw instanceof Uint8Array ? raw : Array.isArray(raw) ? Uint8Array.from(raw) : (() => {
            throw new Error("CAS_PUT_BYTES_INVALID");
          })();
          const rawLinks = linksH === void 0 ? [] : ctx.dump(linksH);
          if (!Array.isArray(rawLinks) || !rawLinks.every((l) => typeof l === "string")) throw new Error("CAS_PUT_LINKS_INVALID");
          const hash = input.cas.putSync(bytes, rawLinks, writePartition);
          return ctx.newString(hash);
        });
        bindFn("casGet", (hashH) => {
          const rawHash = ctx.getString(hashH);
          const hash = tryParseCasRef(rawHash) ?? rawHash;
          if (!/^[0-9a-f]{64}$/u.test(hash)) throw new Error("CAS_HASH_INVALID");
          const node = input.cas.getSync(hash, readPartition);
          if (node === null) {
            tripMissing(hash, "cas");
            return ctx.undefined;
          }
          return ctx.newString(JSON.stringify({ bytesHex: bytesToHex(node.bytes), links: node.links }));
        });
        bindFn("wasmInvoke", (refH, exportH, argsJsonH) => {
          const rawRef = ctx.getString(refH);
          const hash = tryParseCasRef(rawRef) ?? rawRef;
          if (!/^[0-9a-f]{64}$/u.test(hash)) throw new Error("WASM_HASH_INVALID");
          const exportName = ctx.getString(exportH);
          const args = JSON.parse(ctx.getString(argsJsonH));
          if (!Array.isArray(args) || !args.every((n) => typeof n === "number" && Number.isFinite(n))) {
            throw new Error("WASM_ARGS_INVALID");
          }
          const result = this.#wasmSandbox.invokeNumeric(hash, exportName, args, {
            cas: input.cas,
            readPartition,
            writePartition,
            readOnly: input.readOnly,
            maxMemoryBytes: input.maxMemoryBytes,
            maxFuel,
            onMissingCas: (h) => tripMissing(h, "cas")
          });
          return ctx.newString(JSON.stringify(result));
        });
        bindFn("wasmInvokeJson", (refH, exportH, inputJsonH) => {
          const rawRef = ctx.getString(refH);
          const hash = tryParseCasRef(rawRef) ?? rawRef;
          if (!/^[0-9a-f]{64}$/u.test(hash)) throw new Error("WASM_HASH_INVALID");
          const exportName = ctx.getString(exportH);
          const parsedInput = normalizeJsonValue(JSON.parse(ctx.getString(inputJsonH)));
          const result = this.#wasmSandbox.invokeJson(hash, exportName, parsedInput, {
            cas: input.cas,
            readPartition,
            writePartition,
            readOnly: input.readOnly,
            maxMemoryBytes: input.maxMemoryBytes,
            maxFuel,
            onMissingCas: (h) => tripMissing(h, "cas")
          });
          return ctx.newString(JSON.stringify(result));
        });
        if (this.#sqliteDriver !== void 0) {
          const driver = this.#sqliteDriver;
          bindFn("sqlOpen", (rootH) => {
            const rawRoot = ctx.dump(rootH);
            const dbRoot = typeof rawRoot === "string" ? rawRoot : null;
            const db = driver.openDb({
              dbRoot,
              cas: input.cas,
              partition: input.casPartition,
              actor: input.tx?.author ?? "0".repeat(64),
              opId: input.tx?.opId ?? "0".repeat(64),
              opTimeMs: BigInt(input.tx?.authorTimestampMs ?? 0),
              readOnly: input.readOnly,
              onMissingCas: (hash) => tripMissing(hash, "sqlite")
            });
            const id = nextDbId++;
            openDbs.set(id, db);
            return ctx.newNumber(id);
          });
          bindFn("sqlExec", (idH, sqlH, paramsH, optsH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            const sql = ctx.getString(sqlH);
            const params = JSON.parse(ctx.getString(paramsH));
            const opts = JSON.parse(ctx.getString(optsH));
            const res = db.exec(sql, params, opts);
            return ctx.newString(JSON.stringify(res));
          });
          bindFn("sqlQuery", (idH, sqlH, paramsH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            const sql = ctx.getString(sqlH);
            const params = JSON.parse(ctx.getString(paramsH));
            const res = db.query(sql, params);
            return ctx.newString(JSON.stringify(res));
          });
          bindFn("sqlValidateExpr", (idH, tableH, opH, exprH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            db.validateExpr(ctx.getString(tableH), ctx.getString(opH), ctx.getString(exprH));
          });
          bindFn("sqlCommit", (idH) => {
            const db = openDbs.get(ctx.getNumber(idH));
            if (db === void 0) throw new Error("SQLITE_HANDLE_CLOSED");
            return ctx.newString(db.commit());
          });
          bindFn("sqlClose", (idH) => {
            const id = ctx.getNumber(idH);
            const db = openDbs.get(id);
            if (db !== void 0) {
              db.close();
              openDbs.delete(id);
            }
          });
        }
        const jsonH = intrinsic(0);
        const jsonParseH = intrinsic(1);
        const jsonStringifyH = intrinsic(2);
        const stringH = intrinsic(3);
        const objectIsH = intrinsic(4);
        const makeCtxH = intrinsic(5);
        const finishH = intrinsic(6);
        const vmParse = (text) => {
          const textH = ctx.newString(text);
          try {
            return ctx.callFunction(jsonParseH, jsonH, textH);
          } finally {
            textH.dispose();
          }
        };
        const vmString = (valueH) => {
          const res = ctx.callFunction(stringH, ctx.undefined, valueH ?? ctx.undefined);
          if (res.error) throw new VmThrow(res.error);
          try {
            return ctx.getString(res.value);
          } finally {
            res.value.dispose();
          }
        };
        const vmStringifyInput = (valueH) => {
          const res = valueH === void 0 || ctx.typeof(valueH) === "undefined" ? ctx.callFunction(jsonStringifyH, jsonH, ctx.null) : ctx.callFunction(jsonStringifyH, jsonH, valueH);
          if (res.error) throw new VmThrow(res.error);
          try {
            return ctx.getString(res.value);
          } finally {
            res.value.dispose();
          }
        };
        const ctxMethod = (name, fn) => {
          const handle = ctx.newFunction(name, (...args) => {
            if (missingDep !== null) throw missingDep;
            try {
              return fn(...args);
            } catch (err) {
              if (err instanceof VmThrow) return { error: err.error };
              throw err;
            }
          });
          ctxMembers.push(own(handle));
        };
        const topicCache = /* @__PURE__ */ new Map();
        const readTopicCached = (key) => {
          let cached = topicCache.get(key);
          if (cached === void 0) {
            const res = vmParse(JSON.stringify(Object.hasOwn(input.topics, key) ? input.topics[key] : null));
            if (res.error) throw new VmThrow(res.error);
            cached = own(res.value);
            topicCache.set(key, cached);
          }
          return cached;
        };
        let mountHelperH = null;
        const ctxMembers = [];
        ctxMethod("topic", (nameH) => readTopicCached(vmString(nameH)).dup());
        ctxMethod("query", (nameH, inputH) => {
          const name = vmString(nameH);
          return vmParse(queryTopic(name, vmStringifyInput(inputH)));
        });
        ctxMethod("mount", (nameH) => {
          const mountsH = readTopicCached("$mounts");
          if (mountHelperH === null) {
            const res = ctx.evalCode(MOUNT_HELPER_SOURCE, "__chronolog_mount__.js");
            if (res.error) return { error: res.error };
            mountHelperH = own(res.value);
          }
          return ctx.callFunction(mountHelperH, ctx.undefined, mountsH, nameH ?? ctx.undefined);
        });
        ctxMethod("mountQuery", (nameH, topicH, inputH) => {
          const name = vmString(nameH);
          const topic = vmString(topicH);
          return vmParse(queryMount(name, topic, vmStringifyInput(inputH)));
        });
        ctxMethod("opOutcome", (opIdH) => {
          const key = vmString(opIdH);
          const outcome = input.opOutcome !== void 0 ? input.opOutcome(key) : input.opOutcomes !== void 0 && Object.hasOwn(input.opOutcomes, key) ? input.opOutcomes[key] : null;
          return outcome === null ? ctx.null : ctx.newString(outcome);
        });
        ctxMethod("topicLastOpId", (nameH) => {
          const key = vmString(nameH);
          const ids = input.topicLastOpIds;
          return ids !== void 0 && Object.hasOwn(ids, key) ? ctx.newString(ids[key]) : ctx.null;
        });
        const configRes = vmParse(JSON.stringify(input.config ?? null));
        if (configRes.error) {
          configRes.error.dispose();
          return { ok: false, code: "vm:prelude_failed" };
        }
        ctxMembers.push(own(configRes.value));
        const ctxRes = ctx.callFunction(makeCtxH, ctx.undefined, ...ctxMembers);
        if (ctxRes.error) {
          ctxRes.error.dispose();
          return { ok: false, code: "vm:prelude_failed" };
        }
        const ctxObj = own(ctxRes.value);
        const loadRes = ctx.evalCode(
          entryModuleSource(input.moduleSpecifier, input.exportName),
          ENTRY_MODULE_NAME,
          { type: "module" }
        );
        if (loadRes.error) {
          const dumped = ctx.dump(loadRes.error);
          loadRes.error.dispose();
          if (missingDep !== null) throw missingDep;
          if (fuelExhausted) return { ok: false, code: "vm:fuel_exhausted" };
          if (timedOut) throw new OperationalTimeoutError();
          return { ok: false, code: "vm:module_load_error", detail: moduleLoadState.error !== null ? moduleLoadState.error.message : formatJsError(dumped) };
        }
        own(loadRes.value);
        if (missingDep !== null) throw missingDep;
        if (fuelExhausted) return { ok: false, code: "vm:fuel_exhausted" };
        if (timedOut) throw new OperationalTimeoutError();
        const runResult = (() => {
          const target = own(ctx.getProp(loadRes.value, "default"));
          const targetType = ctx.typeof(target);
          if (targetType !== "object" && targetType !== "function" && !ctx.dump(target)) return { kind: "missing" };
          if (targetType === "object") {
            const isNull = ctx.callFunction(objectIsH, ctx.undefined, target, ctx.null);
            if (isNull.error) return { kind: "error", error: isNull.error };
            const nullTarget = ctx.dump(isNull.value) === true;
            isNull.value.dispose();
            if (nullTarget) return { kind: "missing" };
          }
          const fnRes = ctx.getProp(target, input.method);
          own(fnRes);
          if (ctx.typeof(fnRes) !== "function") return { kind: "missing" };
          const argsJson = input.method === "reduce" ? [input.state, txJson(input)] : input.method === "onConflict" ? [input.state, txJson(input), input.conflict ?? null] : input.method === "query" ? [input.state, input.payload] : input.method === "derive" ? [input.payload] : [input.state];
          const argsRes = vmParse(JSON.stringify(argsJson));
          if (argsRes.error) return { kind: "error", error: argsRes.error };
          const argsArr = own(argsRes.value);
          const args = argsJson.map((_, i) => own(ctx.getProp(argsArr, i)));
          const ctxIndex = input.method === "derive" || input.method === "describe" ? 1 : 2;
          args.splice(ctxIndex, 0, ctxObj);
          const callRes = ctx.callFunction(fnRes, ctx.undefined, ...args);
          if (callRes.error) return { kind: "error", error: callRes.error };
          const out = own(callRes.value);
          const strRes = ctx.callFunction(finishH, ctx.undefined, out);
          if (strRes.error) return { kind: "error", error: strRes.error };
          const json = ctx.getString(strRes.value);
          strRes.value.dispose();
          return { kind: "ok", json };
        })();
        if (runResult.kind === "error") {
          const dumped = ctx.dump(runResult.error);
          runResult.error.dispose();
          if (missingDep !== null) throw missingDep;
          if (fuelExhausted) return { ok: false, code: "vm:fuel_exhausted" };
          if (timedOut) throw new OperationalTimeoutError();
          const detail = formatJsError(dumped);
          const code = /out of memory|memory limit/i.test(detail) ? "vm:limit" : "reducer:throw";
          return { ok: false, code, detail };
        }
        if (missingDep !== null) throw missingDep;
        if (fuelExhausted) return { ok: false, code: "vm:fuel_exhausted" };
        if (timedOut) throw new OperationalTimeoutError();
        if (runResult.kind === "missing") {
          return { ok: false, code: `vm:missing_method:${input.method}` };
        }
        const parsed = JSON.parse(runResult.json);
        try {
          const normalized = normalizeJsonValue(parsed.value);
          return { ok: true, value: normalized };
        } catch (err) {
          return { ok: false, code: "vm:invalid_output", detail: err instanceof Error ? err.message : String(err) };
        }
      } finally {
        for (const db of openDbs.values()) {
          try {
            db.close();
          } catch {
          }
        }
        openDbs.clear();
        for (let i = owned.length - 1; i >= 0; i--) {
          const h = owned[i];
          if (h.alive) h.dispose();
        }
        try {
          ctx.dispose();
        } catch {
          healthy = false;
        }
      }
    } catch (err) {
      healthy = false;
      throw err;
    } finally {
      if (timedOut || fuelExhausted || missingDep !== null) healthy = false;
      this.#releaseRuntime(runtime, depth, healthy);
    }
  }
};
function formatJsError(dumped) {
  if (typeof dumped === "string") return dumped;
  if (dumped !== null && typeof dumped === "object" && "message" in dumped) {
    return String(dumped.message);
  }
  try {
    return JSON.stringify(dumped);
  } catch {
    return String(dumped);
  }
}

// packages/materializer/src/derivation.ts
function canonicalAttestationMessage(payload) {
  return `chronolog/attestation/v1:${canonicalJson(payload)}`;
}
async function signBuildAttestation(payload, signerPublicKeyHex, privateKey) {
  const full = {
    format: "chronolog-attestation/v1",
    kind: "build",
    drvRef: casRef(parseCasRef(payload.drvRef)),
    outputRef: casRef(parseCasRef(payload.outputRef)),
    runtime: payload.runtime
  };
  const msg = utf8(canonicalAttestationMessage(full));
  const sig = new Uint8Array(await crypto.subtle.sign("Ed25519", privateKey, new Uint8Array(msg)));
  return { payload: full, signer: signerPublicKeyHex, signature: bytesToHex(sig) };
}
function verifyBuildAttestation(attestation) {
  if (attestation.payload.format !== "chronolog-attestation/v1" || attestation.payload.kind !== "build") return false;
  if (tryParseCasRef(attestation.payload.drvRef) === null || tryParseCasRef(attestation.payload.outputRef) === null) return false;
  if (!/^[0-9a-f]{64}$/u.test(attestation.signer) || !/^[0-9a-f]{128}$/u.test(attestation.signature)) return false;
  return verifyEd25519Sync(
    hexToBytes(attestation.signer),
    utf8(canonicalAttestationMessage(attestation.payload)),
    hexToBytes(attestation.signature)
  );
}
async function signAuditAttestation(payload, signerPublicKeyHex, privateKey) {
  const full = {
    format: "chronolog-attestation/v1",
    kind: "audit",
    pkgRef: casRef(parseCasRef(payload.pkgRef)),
    verdict: payload.verdict,
    ...payload.notes === void 0 ? {} : { notes: payload.notes }
  };
  const msg = utf8(canonicalAttestationMessage(full));
  const sig = new Uint8Array(await crypto.subtle.sign("Ed25519", privateKey, new Uint8Array(msg)));
  return { payload: full, signer: signerPublicKeyHex, signature: bytesToHex(sig) };
}
function verifyAuditAttestation(attestation) {
  if (attestation.payload.format !== "chronolog-attestation/v1" || attestation.payload.kind !== "audit") return false;
  if (tryParseCasRef(attestation.payload.pkgRef) === null) return false;
  if (attestation.payload.verdict !== "approved" && attestation.payload.verdict !== "revoked") return false;
  if (!/^[0-9a-f]{64}$/u.test(attestation.signer) || !/^[0-9a-f]{128}$/u.test(attestation.signature)) return false;
  return verifyEd25519Sync(
    hexToBytes(attestation.signer),
    utf8(canonicalAttestationMessage(attestation.payload)),
    hexToBytes(attestation.signature)
  );
}
function createBytesStoreDerivationMemo(store, prefix = "drv-memo/") {
  const mem = /* @__PURE__ */ new Map();
  return {
    async get(drvHash) {
      const hit = mem.get(drvHash);
      if (hit !== void 0) return hit;
      const raw = await store.get(`${prefix}${drvHash}`);
      if (raw === null) return null;
      const hash = new TextDecoder().decode(raw);
      if (!/^[0-9a-f]{64}$/u.test(hash)) return null;
      mem.set(drvHash, hash);
      return hash;
    },
    async set(drvHash, outputHash) {
      mem.set(drvHash, outputHash);
      await store.put(`${prefix}${drvHash}`, utf8(outputHash), { durability: "relaxed" });
    }
  };
}
async function evaluateDerivation(options) {
  const drvHash = tryParseCasRef(options.drvRefOrHash) ?? options.drvRefOrHash;
  if (!/^[0-9a-f]{64}$/u.test(drvHash)) throw new Error(`DRV_HASH_INVALID:${options.drvRefOrHash}`);
  const partition = options.partition ?? "public";
  if (!options.skipMemo && options.memo !== void 0) {
    const cached = await options.memo.get(drvHash);
    if (cached !== null && await options.cas.ensureLoaded(cached, partition)) {
      return {
        drvHash,
        drvRef: casRef(drvHash),
        outputHash: cached,
        outputRef: casRef(cached),
        fromCache: true
      };
    }
  }
  const drvNode = await options.cas.get(drvHash, partition);
  if (drvNode === null) throw new MissingDependencyError(drvHash, "cas");
  const drv = decodeDerivationNode(drvNode.bytes);
  let outputHash;
  if (drv.profile === "quickjs-inline") {
    options.cas.beginBatch();
    try {
      const res = await options.sandbox.invoke({
        imports: { ...options.imports ?? {}, __builder__: drv.builder },
        builtins: DEFAULT_RUNTIME_MANIFEST.builtins,
        moduleSpecifier: "__builder__",
        exportName: "default",
        method: "derive",
        state: null,
        payload: {
          inputs: drv.inputs,
          args: drv.args
        },
        topics: {},
        cas: options.cas,
        casPartition: partition,
        readOnly: false,
        maxMemoryBytes: drv.limits.maxMemoryBytes,
        maxFuel: drv.limits.maxFuel
      });
      if (!res.ok) {
        throw new Error(`DERIVATION_EXEC_FAILED:${res.code}:${res.detail ?? ""}`);
      }
      const val = res.value;
      const rawOut = typeof val === "string" ? val : val !== null && typeof val === "object" && !Array.isArray(val) && typeof val.output === "string" ? String(val.output) : null;
      if (rawOut === null) throw new Error("DERIVATION_OUTPUT_INVALID");
      const parsedOut = tryParseCasRef(rawOut) ?? rawOut;
      if (!/^[0-9a-f]{64}$/u.test(parsedOut)) throw new Error(`DERIVATION_OUTPUT_HASH_INVALID:${rawOut}`);
      if (!options.cas.hasSync(parsedOut, partition)) throw new Error(`DERIVATION_OUTPUT_MISSING_IN_CAS:${parsedOut}`);
      await options.cas.flushBatch();
      outputHash = parsedOut;
    } catch (err) {
      options.cas.rollbackBatch();
      throw err;
    }
  } else {
    const runner = options.wasiRunners?.[drv.builder] ?? options.wasiRunners?.["*"];
    if (runner === void 0) {
      throw new Error(`DERIVATION_WASI_RUNNER_MISSING:${drv.builder}`);
    }
    const rawOut = await runner(drv, options.cas, partition);
    const parsedOut = tryParseCasRef(rawOut) ?? rawOut;
    if (!/^[0-9a-f]{64}$/u.test(parsedOut)) throw new Error(`DERIVATION_OUTPUT_HASH_INVALID:${rawOut}`);
    outputHash = parsedOut;
  }
  if (options.memo !== void 0) {
    await options.memo.set(drvHash, outputHash);
  }
  return {
    drvHash,
    drvRef: casRef(drvHash),
    outputHash,
    outputRef: casRef(outputHash),
    fromCache: false
  };
}
async function verifyDerivationOutput(options) {
  const expectedHash = tryParseCasRef(options.expectedOutputRef) ?? options.expectedOutputRef;
  const evaluated = await evaluateDerivation({ ...options, skipMemo: true });
  return {
    valid: evaluated.outputHash === expectedHash,
    expectedOutputRef: casRef(expectedHash),
    actualOutputRef: evaluated.outputRef
  };
}

// packages/materializer/src/wasi-cas-runner.ts
var ERRNO_SUCCESS = 0;
var ERRNO_BADF = 8;
var ERRNO_INVAL = 28;
var ERRNO_NOENT = 44;
var ERRNO_NOSYS = 52;
var ERRNO_ROFS = 69;
var FILETYPE_DIRECTORY = 3;
var FILETYPE_REGULAR_FILE = 4;
var WasiExit = class extends Error {
  code;
  constructor(code) {
    super(`WASI_EXIT:${code}`);
    this.code = code;
  }
};
function concatChunks(a, b) {
  const out = new Uint8Array(a.byteLength + b.byteLength);
  out.set(a, 0);
  out.set(b, a.byteLength);
  return out;
}
function createWasiCasRunner() {
  const compiledCache = /* @__PURE__ */ new Map();
  return async (drv, cas, partition) => {
    const builderHash = parseCasRef(drv.builder);
    const builderNode = await cas.get(builderHash, partition);
    if (builderNode === null) throw new Error(`WASI_BUILDER_MISSING:${drv.builder}`);
    let wasmHash = builderHash;
    let wasmBytes;
    try {
      const pkg = decodePackageNode(builderNode.bytes);
      const entryPath = pkg.wasm?.entry ?? pkg.exports["."];
      if (entryPath === void 0 || pkg.files[entryPath] === void 0) {
        throw new Error(`WASI_BUILDER_ENTRY_MISSING:${drv.builder}`);
      }
      wasmHash = parseCasRef(pkg.files[entryPath]);
      wasmBytes = await readBlobDag(cas, wasmHash, partition);
    } catch (err) {
      if (err instanceof Error && err.message.startsWith("WASI_BUILDER_")) throw err;
      wasmBytes = await readBlobDag(cas, builderHash, partition);
    }
    if (wasmBytes === null) throw new Error(`WASI_BUILDER_BYTES_MISSING:${wasmHash}`);
    const roFiles = /* @__PURE__ */ new Map();
    for (const [inputName, ref] of Object.entries(drv.inputs).sort(([a], [b]) => a.localeCompare(b))) {
      const inputHash = parseCasRef(ref);
      const node = await cas.get(inputHash, partition);
      if (node === null) throw new Error(`WASI_INPUT_MISSING:${inputName}:${ref}`);
      let loadedTree = false;
      try {
        const tree2 = decodeTreeNode(node.bytes);
        for (const [relPath, fileRef] of Object.entries(tree2.entries)) {
          const fBytes = await readBlobDag(cas, parseCasRef(fileRef), partition);
          if (fBytes === null) throw new Error(`WASI_INPUT_FILE_MISSING:${relPath}`);
          roFiles.set(`inputs/${normalizePosixPath(inputName)}/${normalizePosixPath(relPath)}`, fBytes);
        }
        loadedTree = true;
      } catch (err) {
        if (err instanceof Error && err.message.startsWith("WASI_INPUT_")) throw err;
      }
      if (!loadedTree) {
        const fBytes = await readBlobDag(cas, inputHash, partition);
        if (fBytes === null) throw new Error(`WASI_INPUT_BYTES_MISSING:${inputName}`);
        roFiles.set(`inputs/${normalizePosixPath(inputName)}`, fBytes);
      }
    }
    const outFiles = /* @__PURE__ */ new Map();
    const fds = /* @__PURE__ */ new Map([
      [0, { kind: "stdio", path: "/dev/stdin", writable: false, offset: 0, data: new Uint8Array(0) }],
      [1, { kind: "stdio", path: "/dev/stdout", writable: true, offset: 0, data: new Uint8Array(0) }],
      [2, { kind: "stdio", path: "/dev/stderr", writable: true, offset: 0, data: new Uint8Array(0) }],
      [3, { kind: "preopen", path: "/", writable: true, offset: 0, data: new Uint8Array(0) }]
    ]);
    let nextFd = 4;
    const memBox = { current: null };
    const argsList = [utf8("chronolog-wasi-builder\0")];
    const envList = [utf8(`CHRONOLOG_ARGS=${canonicalJson(drv.args)}\0`)];
    const memView = () => new DataView(memBox.current.buffer);
    const memU8 = () => new Uint8Array(memBox.current.buffer);
    const resolvePath = (dirPath, rawRel) => {
      const cleaned = rawRel.replace(/^\/+/u, "");
      const base = dirPath === "/" ? "" : dirPath.replace(/^\/+|\/+$/gu, "");
      const joined = base.length > 0 ? `${base}/${cleaned}` : cleaned;
      try {
        return normalizePosixPath(joined);
      } catch {
        return null;
      }
    };
    const wasiImports = {
      args_sizes_get(argcPtr, argvBufSizePtr) {
        const dv = memView();
        dv.setUint32(argcPtr, argsList.length, true);
        dv.setUint32(argvBufSizePtr, argsList.reduce((s, a) => s + a.byteLength, 0), true);
        return ERRNO_SUCCESS;
      },
      args_get(argvPtr, argvBufPtr) {
        const dv = memView();
        const u8 = memU8();
        let bufOff = argvBufPtr;
        for (let i = 0; i < argsList.length; i++) {
          dv.setUint32(argvPtr + i * 4, bufOff, true);
          u8.set(argsList[i], bufOff);
          bufOff += argsList[i].byteLength;
        }
        return ERRNO_SUCCESS;
      },
      environ_sizes_get(countPtr, bufSizePtr) {
        const dv = memView();
        dv.setUint32(countPtr, envList.length, true);
        dv.setUint32(bufSizePtr, envList.reduce((s, e) => s + e.byteLength, 0), true);
        return ERRNO_SUCCESS;
      },
      environ_get(envPtr, envBufPtr) {
        const dv = memView();
        const u8 = memU8();
        let bufOff = envBufPtr;
        for (let i = 0; i < envList.length; i++) {
          dv.setUint32(envPtr + i * 4, bufOff, true);
          u8.set(envList[i], bufOff);
          bufOff += envList[i].byteLength;
        }
        return ERRNO_SUCCESS;
      },
      clock_time_get(_id, _precision, timePtr) {
        memView().setBigUint64(timePtr, 0n, true);
        return ERRNO_SUCCESS;
      },
      clock_res_get(_id, resPtr) {
        memView().setBigUint64(resPtr, 1000000n, true);
        return ERRNO_SUCCESS;
      },
      random_get() {
        throw new Error("WASI_NONDETERMINISTIC_RANDOM");
      },
      proc_exit(code) {
        throw new WasiExit(code);
      },
      fd_prestat_get(fd, bufPtr) {
        const entry = fds.get(fd);
        if (entry === void 0 || entry.kind !== "preopen") return ERRNO_BADF;
        const dv = memView();
        dv.setUint8(bufPtr, 0);
        dv.setUint32(bufPtr + 4, utf8(entry.path).byteLength, true);
        return ERRNO_SUCCESS;
      },
      fd_prestat_dir_name(fd, pathPtr, pathLen) {
        const entry = fds.get(fd);
        if (entry === void 0 || entry.kind !== "preopen") return ERRNO_BADF;
        const bytes = utf8(entry.path);
        if (bytes.byteLength > pathLen) return ERRNO_INVAL;
        memU8().set(bytes, pathPtr);
        return ERRNO_SUCCESS;
      },
      path_open(dirFd, _dirFlags, pathPtr, pathLen, oflags, _rightsBase, _rightsInheriting, _fdFlags, outFdPtr) {
        const dir = fds.get(dirFd);
        if (dir === void 0 || dir.kind !== "preopen") return ERRNO_BADF;
        const rawPath = new TextDecoder().decode(memU8().subarray(pathPtr, pathPtr + pathLen));
        const norm = resolvePath(dir.path, rawPath);
        if (norm === null) return ERRNO_INVAL;
        const wantsCreate = (oflags & 1) !== 0;
        const wantsTrunc = (oflags & 8) !== 0;
        if (norm.startsWith("out/")) {
          const outKey = norm.slice("out/".length);
          if (outKey.length === 0) return ERRNO_INVAL;
          const existing = outFiles.get(outKey);
          if (existing === void 0 && !wantsCreate) return ERRNO_NOENT;
          const initial = wantsTrunc || existing === void 0 ? new Uint8Array(0) : existing.slice();
          outFiles.set(outKey, initial);
          const fd2 = nextFd++;
          fds.set(fd2, { kind: "file", path: norm, writable: true, offset: 0, data: initial });
          memView().setUint32(outFdPtr, fd2, true);
          return ERRNO_SUCCESS;
        }
        if (wantsCreate || wantsTrunc) return ERRNO_ROFS;
        const data = roFiles.get(norm);
        if (data === void 0) return ERRNO_NOENT;
        const fd = nextFd++;
        fds.set(fd, { kind: "file", path: norm, writable: false, offset: 0, data });
        memView().setUint32(outFdPtr, fd, true);
        return ERRNO_SUCCESS;
      },
      fd_read(fd, iovsPtr, iovsLen, nreadPtr) {
        const entry = fds.get(fd);
        if (entry === void 0 || entry.kind === "preopen") return ERRNO_BADF;
        const dv = memView();
        const u8 = memU8();
        let total = 0;
        for (let i = 0; i < iovsLen; i++) {
          const ptr = dv.getUint32(iovsPtr + i * 8, true);
          const len = dv.getUint32(iovsPtr + i * 8 + 4, true);
          const avail = Math.max(0, entry.data.byteLength - entry.offset);
          const toRead = Math.min(len, avail);
          if (toRead > 0) {
            u8.set(entry.data.subarray(entry.offset, entry.offset + toRead), ptr);
            entry.offset += toRead;
            total += toRead;
          }
        }
        dv.setUint32(nreadPtr, total, true);
        return ERRNO_SUCCESS;
      },
      fd_write(fd, iovsPtr, iovsLen, nwrittenPtr) {
        const entry = fds.get(fd);
        if (entry === void 0 || entry.kind === "preopen") return ERRNO_BADF;
        if (!entry.writable) return ERRNO_ROFS;
        const dv = memView();
        const u8 = memU8();
        let total = 0;
        for (let i = 0; i < iovsLen; i++) {
          const ptr = dv.getUint32(iovsPtr + i * 8, true);
          const len = dv.getUint32(iovsPtr + i * 8 + 4, true);
          const slice = u8.slice(ptr, ptr + len);
          entry.data = concatChunks(entry.data, slice);
          entry.offset = entry.data.byteLength;
          total += len;
        }
        if (entry.kind === "file" && entry.path.startsWith("out/")) {
          outFiles.set(entry.path.slice("out/".length), entry.data);
        }
        dv.setUint32(nwrittenPtr, total, true);
        return ERRNO_SUCCESS;
      },
      fd_fdstat_get(fd, statPtr) {
        const entry = fds.get(fd);
        if (entry === void 0) return ERRNO_BADF;
        const dv = memView();
        dv.setUint8(statPtr, entry.kind === "preopen" ? FILETYPE_DIRECTORY : FILETYPE_REGULAR_FILE);
        dv.setUint16(statPtr + 2, 0, true);
        dv.setBigUint64(statPtr + 8, 0xffffffffffffffffn, true);
        dv.setBigUint64(statPtr + 16, 0xffffffffffffffffn, true);
        return ERRNO_SUCCESS;
      },
      fd_close(fd) {
        if (fd <= 3 || !fds.has(fd)) return ERRNO_BADF;
        fds.delete(fd);
        return ERRNO_SUCCESS;
      },
      fd_seek() {
        return ERRNO_NOSYS;
      },
      path_create_directory() {
        return ERRNO_SUCCESS;
      },
      path_filestat_get() {
        return ERRNO_NOSYS;
      }
    };
    let mod = compiledCache.get(wasmHash);
    if (mod === void 0) {
      mod = await WebAssembly.compile(wasmBytes.slice());
      for (const imp of WebAssembly.Module.imports(mod)) {
        if (imp.module !== "wasi_snapshot_preview1") {
          throw new Error(`WASI_DISALLOWED_HOST_IMPORT:${imp.module}.${imp.name}`);
        }
      }
      compiledCache.set(wasmHash, mod);
    }
    const instance = await WebAssembly.instantiate(mod, { wasi_snapshot_preview1: wasiImports });
    const exp = instance.exports;
    if (!(exp.memory instanceof WebAssembly.Memory)) throw new Error("WASI_MEMORY_EXPORT_REQUIRED");
    if (typeof exp._start !== "function") throw new Error("WASI_START_EXPORT_REQUIRED");
    memBox.current = exp.memory;
    try {
      ;
      exp._start();
    } catch (err) {
      if (err instanceof WasiExit) {
        if (err.code !== 0) throw new Error(`WASI_NONZERO_EXIT:${err.code}`, { cause: err });
      } else {
        throw err;
      }
    }
    if (outFiles.size === 0) throw new Error("WASI_NO_OUTPUT_PRODUCED");
    if (outFiles.size === 1 && outFiles.has("output")) {
      const stored = await putBlobDag(cas, outFiles.get("output"), partition);
      return casRef(stored.hash);
    }
    const filesRecord = {};
    for (const [k, v] of [...outFiles.entries()].sort(([a], [b]) => a.localeCompare(b))) {
      filesRecord[k] = v;
    }
    const tree = await putTreeDag(cas, filesRecord, partition);
    return tree.ref;
  };
}

// packages/materializer/src/kernel.ts
var AppendLog = class _AppendLog {
  keys = [];
  #map = /* @__PURE__ */ new Map();
  get length() {
    return this.keys.length;
  }
  has(key) {
    return this.#map.has(key);
  }
  get(key) {
    return this.#map.get(key)?.value;
  }
  /** Value only if it was appended at a position below `limit`. */
  getBefore(key, limit) {
    const entry = this.#map.get(key);
    return entry !== void 0 && entry.pos < limit && this.keys[entry.pos] === key ? entry.value : void 0;
  }
  /** Position of `key` if present below `limit`. */
  positionBefore(key, limit) {
    const entry = this.#map.get(key);
    return entry !== void 0 && entry.pos < limit && this.keys[entry.pos] === key ? entry.pos : void 0;
  }
  add(key, value) {
    if (this.#map.has(key)) return;
    this.#map.set(key, { value, pos: this.keys.length });
    this.keys.push(key);
  }
  truncate(length) {
    while (this.keys.length > length) {
      const key = this.keys.pop();
      const entry = this.#map.get(key);
      if (entry !== void 0 && entry.pos >= length) this.#map.delete(key);
    }
  }
  clear() {
    this.keys.length = 0;
    this.#map.clear();
  }
  clone(length = this.keys.length) {
    const out = new _AppendLog();
    for (let i = 0; i < length; i++) out.add(this.keys[i], this.#map.get(this.keys[i]).value);
    return out;
  }
};
var ZERO_HASH = "0".repeat(64);
var inputMeta = /* @__PURE__ */ new WeakMap();
function metaOf(item) {
  let meta = inputMeta.get(item);
  if (meta === void 0) {
    const opIdHex = bytesToHex(item.opId);
    if (item.verified !== true && bytesToHex(operationIdDigest(item.core)) !== opIdHex) throw new Error("KERNEL_OP_ID_MISMATCH");
    meta = { opIdHex, logIdHex: bytesToHex(item.core.logId) };
    inputMeta.set(item, meta);
  }
  return meta;
}
function seenOpKey(visibility, authorHex, operationId) {
  return `${visibility}:${authorHex}:${operationId}`;
}
function hashSeenOpsSet(seen, cas, partition) {
  const sorted = [...seen].sort();
  const bytes = encodeCanonicalCbor(sorted);
  return cas.putSync(bytes, [], partition);
}
function hashTopicBytes(encoded) {
  return bytesToHex(hashDomainSync("topic", encoded));
}
function topicHashOf(value) {
  return hashTopicBytes(encodeCanonicalJsonCbor(value));
}
function stateRootFromHashes(topicHashes) {
  const names = [...topicHashes.keys()].sort();
  const payload = encodeCanonicalCbor(new Map(names.map((name) => [name, topicHashes.get(name)])));
  return bytesToHex(hashDomainSync("state", payload));
}
function computeTopicHashes(topics) {
  const out = /* @__PURE__ */ new Map();
  for (const [name, value] of Object.entries(topics)) out.set(name, topicHashOf(value));
  return out;
}
function computeStateRoot(topics) {
  return stateRootFromHashes(computeTopicHashes(topics));
}
function advanceHistoryDigest(prev, opId, outcome, rejectionCode, events) {
  const eventsBytes = encodeCanonicalJsonCbor(
    events.map((e) => ({ o: e.eventOrdinal, t: e.topic, p: e.payload }))
  );
  const payload = encodeCanonicalCbor([prev, opId, outcome, rejectionCode ?? "", eventsBytes]);
  return bytesToHex(hashDomainSync("history", payload));
}
function computeRevisionDigest(historyDigest, stateRoot, view, policyContextDigest) {
  const payload = encodeCanonicalCbor([historyDigest, stateRoot, view, policyContextDigest]);
  return bytesToHex(hashDomainSync("revision", payload));
}
function filterPublicTopics(topics) {
  const out = {};
  for (const [k, v] of Object.entries(topics)) {
    if (isControlTopic(k)) out[k] = v;
  }
  return out;
}
function extractCasHashes(value, out) {
  if (typeof value === "string") {
    if (/^[0-9a-f]{64}$/u.test(value)) out.add(value);
    else if (value.startsWith("cas:sha256-") && value.length === 75) out.add(value.slice(11));
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) extractCasHashes(item, out);
    return;
  }
  if (value !== null && typeof value === "object") {
    for (const v of Object.values(value)) extractCasHashes(v, out);
  }
}
function extractRequiredCasHashes(value, out, key) {
  if (typeof value === "string") {
    if (value.startsWith("cas:sha256-") && value.length === 75) out.add(value.slice(11));
    else if (key === "dbRoot" && /^[0-9a-f]{64}$/u.test(value)) out.add(value);
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) extractRequiredCasHashes(item, out);
    return;
  }
  if (value !== null && typeof value === "object") {
    for (const [k, v] of Object.entries(value)) extractRequiredCasHashes(v, out, k);
  }
}
var TopicKernel = class {
  genesis;
  genesisBytes;
  logId;
  logIdHex;
  cas;
  sandbox;
  blindHostMode;
  #snapshotInterval;
  #policyContextDigest;
  #order = [];
  #outcomes = [];
  #topics;
  #topicHashes;
  /** Live idempotency log; `#committedSeenLength` is its committed prefix. */
  #seen = new AppendLog();
  #committedSeenLength = 0;
  /** Live outcome log, positionally aligned with `#order` (+ any restored base). */
  #outcomeLog = new AppendLog();
  #seenRootCache = null;
  /** Set when a materialize threw mid-replay: the live logs no longer match committed state. */
  #logsDirty = false;
  #topicLastOpIds = /* @__PURE__ */ new Map();
  #historyDigest = ZERO_HASH;
  #stateRoot;
  #pendingDependencies = /* @__PURE__ */ new Set();
  #skippedOpIds = /* @__PURE__ */ new Set();
  #snapshots = /* @__PURE__ */ new Map();
  /** All $reducers module/package CAS hashes ever activated in the current replay window (prevents GC from dropping intermediate upgrades). */
  #historicalReducerRoots = /* @__PURE__ */ new Set();
  #frontierOpIds = /* @__PURE__ */ new Set();
  #frontierOrderLength = 0;
  #frontierMaxTimestampMs = 0n;
  #genesisSnapshot;
  #cacheRestores = 0;
  /** describe() results per topic, keyed by binding + reducers config + topic content hash. */
  #describeCache = /* @__PURE__ */ new Map();
  /** query() results keyed by the exact state they can observe (see #queryScope). */
  #queryCache = /* @__PURE__ */ new Map();
  constructor(options) {
    this.genesisBytes = options.genesis instanceof Uint8Array ? options.genesis.slice() : encodeLogGenesis(options.genesis);
    this.genesis = decodeLogGenesis(this.genesisBytes);
    this.logId = genesisLogId(this.genesisBytes);
    this.logIdHex = bytesToHex(this.logId);
    this.cas = options.cas;
    this.blindHostMode = options.blindHostMode ?? false;
    this.#snapshotInterval = options.snapshotInterval ?? 16;
    this.#policyContextDigest = options.policyContextDigest ?? ZERO_HASH;
    this.sandbox = new QuickJsSandbox(options);
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(this.genesis.initialTopics)) : structuredClone(this.genesis.initialTopics);
    this.#topicHashes = computeTopicHashes(this.#topics);
    this.#stateRoot = stateRootFromHashes(this.#topicHashes);
    if (this.#topics.$reducers !== void 0) extractCasHashes(this.#topics.$reducers, this.#historicalReducerRoots);
    this.#genesisSnapshot = this.#captureSnapshot(0);
    this.#snapshots.set(0, this.#genesisSnapshot);
  }
  #captureSnapshotFrom(state, orderLength) {
    return {
      topics: { ...state.topics },
      topicHashes: new Map(state.topicHashes),
      topicLastOpIds: new Map(state.topicLastOpIds),
      seenLength: state.seen.length,
      historyDigest: state.historyDigest,
      stateRoot: state.stateRoot,
      orderLength
    };
  }
  #captureSnapshot(orderLength) {
    return {
      topics: { ...this.#topics },
      topicHashes: new Map(this.#topicHashes),
      topicLastOpIds: new Map(this.#topicLastOpIds),
      seenLength: this.#committedSeenLength,
      historyDigest: this.#historyDigest,
      stateRoot: this.#stateRoot,
      orderLength
    };
  }
  /** Reset live logs to a restored base: `seenKeys` consumed, no op outcomes yet. */
  #resetLogs(seenKeys) {
    this.#seen.clear();
    for (const key of seenKeys) this.#seen.add(key, true);
    this.#committedSeenLength = this.#seen.length;
    this.#outcomeLog.clear();
    this.#seenRootCache = null;
    this.#logsDirty = false;
  }
  get topics() {
    return structuredClone(this.#topics);
  }
  /** CAS root of the committed idempotency set; computed lazily (O(N log N)) and cached per commit. */
  get seenOpsRoot() {
    if (this.#seenRootCache === null || this.#seenRootCache.length !== this.#committedSeenLength) {
      const partition = this.genesis.privateLog && this.blindHostMode ? "public" : "private";
      const root = hashSeenOpsSet(this.#seen.keys.slice(0, this.#committedSeenLength), this.cas, partition);
      this.#seenRootCache = { length: this.#committedSeenLength, root };
    }
    return this.#seenRootCache.root;
  }
  #disposed = false;
  get disposed() {
    return this.#disposed;
  }
  /**
   * Release this kernel's VM runtimes, snapshots, logs and caches. Idempotent. Committed revision
   * fields stay readable; materialize/query/describe throw SANDBOX_DISPOSED afterwards.
   */
  dispose() {
    if (this.#disposed) return;
    this.#disposed = true;
    this.sandbox.dispose();
    this.#snapshots.clear();
    this.#queryCache.clear();
    this.#describeCache.clear();
    this.#seen.clear();
    this.#outcomeLog.clear();
    this.#logsDirty = true;
  }
  /** Durably persist the committed idempotency set node and return its root (call before exporting state). */
  async commitSeenOpsRoot() {
    const partition = this.genesis.privateLog && this.blindHostMode ? "public" : "private";
    const length = this.#committedSeenLength;
    const root = await this.cas.put(encodeCanonicalCbor([...this.#seen.keys.slice(0, length)].sort()), [], partition);
    if (this.#committedSeenLength === length) this.#seenRootCache = { length, root };
    return root;
  }
  /** Content hash of a committed topic state (or undefined when absent). */
  topicHash(name) {
    return this.#topicHashes.get(name);
  }
  snapshot() {
    return {
      topics: structuredClone(this.#topics),
      seenOpsRoot: this.seenOpsRoot,
      historyDigest: this.#historyDigest,
      stateRoot: this.#stateRoot
    };
  }
  topic(name) {
    return Object.hasOwn(this.#topics, name) ? structuredClone(this.#topics[name]) : null;
  }
  opOutcome(opId) {
    const committed = this.#outcomes.length;
    if (!this.#logsDirty) {
      const hit = this.#outcomeLog.getBefore(opId, committed);
      if (hit !== void 0) return hit.outcome;
    }
    for (let i = committed - 1; i >= 0; i--) if (this.#outcomes[i].opId === opId) return this.#outcomes[i].outcome;
    return null;
  }
  topicLastOpId(topic) {
    return this.#topicLastOpIds.get(topic) ?? null;
  }
  get outcomes() {
    return this.#outcomes.slice();
  }
  /** Committed outcome for one op in O(1) (falls back to a scan mid-replay). */
  outcomeOf(opId) {
    if (!this.#logsDirty) {
      const pos = this.#outcomeLog.positionBefore(opId, this.#outcomes.length);
      if (pos !== void 0 && this.#outcomes[pos]?.opId === opId) return this.#outcomes[pos];
    }
    return this.#outcomes.find((o) => o.opId === opId);
  }
  /** Committed outcome list without copying (replaced, never mutated, on each commit). */
  get materializedOutcomes() {
    return this.#outcomes;
  }
  get pendingDependencies() {
    return [...this.#pendingDependencies].sort();
  }
  revision(view = "local", policyContextDigest = this.#policyContextDigest) {
    return {
      stateRoot: this.#stateRoot,
      historyDigest: this.#historyDigest,
      digest: computeRevisionDigest(this.#historyDigest, this.#stateRoot, view, policyContextDigest),
      view,
      orderLength: this.#frontierOrderLength + this.#order.length
    };
  }
  get frontierOrderLength() {
    return this.#frontierOrderLength;
  }
  get frontierMaxTimestampMs() {
    return this.#frontierMaxTimestampMs;
  }
  hasFrontierOp(opId) {
    return this.#frontierOpIds.has(opId);
  }
  /** Collect all CAS root hashes reachable from current state + retained suffix snapshots + historical $reducers (for local GC). */
  gcRoots() {
    const roots = new Set(this.#historicalReducerRoots);
    if (this.#seenRootCache !== null) roots.add(this.#seenRootCache.root);
    extractCasHashes(this.#topics, roots);
    for (const snap of this.#snapshots.values()) extractCasHashes(snap.topics, roots);
    return roots;
  }
  get cacheRestores() {
    return this.#cacheRestores;
  }
  /**
   * Export the committed state for instant cold open (local cache) or snapshot bootstrap.
   * `suffix: false` omits the replayable suffix (order ids, outcomes and events) and folds it
   * into the frontier, giving a bundle whose size is O(state + op count x 32 bytes).
   * Outcome/event objects are immutable and shared, not cloned.
   */
  exportMaterializedCache(options = {}) {
    const orderOpIds = this.#order.map((item) => metaOf(item).opIdHex);
    const includeSuffix = options.suffix !== false;
    let maxTs = this.#frontierMaxTimestampMs;
    if (!includeSuffix) {
      for (const o of this.#outcomes) if (o.authorTimestampMs > maxTs) maxTs = o.authorTimestampMs;
    }
    return {
      v: 2,
      logId: this.logIdHex,
      blindHostMode: this.blindHostMode,
      topics: this.#topics,
      seenOpsRoot: this.seenOpsRoot,
      historyDigest: this.#historyDigest,
      stateRoot: this.#stateRoot,
      frontierOpIds: includeSuffix ? [...this.#frontierOpIds] : [...this.#frontierOpIds, ...orderOpIds],
      frontierMaxTimestampMs: maxTs,
      orderOpIds: includeSuffix ? orderOpIds : [],
      outcomes: includeSuffix ? this.#outcomes : [],
      topicLastOpIds: Object.fromEntries(this.#topicLastOpIds)
    };
  }
  /** Validate cache state against local CAS and decode its idempotency set (null on any miss). */
  async #loadCacheBase(cache) {
    if (cache.v !== 2 || cache.logId !== this.logIdHex || cache.blindHostMode !== this.blindHostMode || !Array.isArray(cache.orderOpIds) || !Array.isArray(cache.frontierOpIds) || !Array.isArray(cache.outcomes) || cache.orderOpIds.length !== cache.outcomes.length) {
      return null;
    }
    if (computeStateRoot(cache.topics) !== cache.stateRoot) return null;
    const seenNode = await this.cas.get(cache.seenOpsRoot, "any");
    if (seenNode === null) return null;
    const neededCas = /* @__PURE__ */ new Set();
    extractRequiredCasHashes(cache.topics, neededCas);
    for (const hash of neededCas) {
      if (!this.cas.hasSync(hash, "any") && await this.cas.get(hash, "any") === null) return null;
    }
    try {
      const raw = decodeCanonicalCbor(seenNode.bytes, DEFAULT_DECODE_LIMITS);
      if (!Array.isArray(raw)) return null;
      return raw.filter((v) => typeof v === "string");
    } catch {
      return null;
    }
  }
  /**
   * Restore materialized state directly from a previously exported cache if:
   * - logId, blindHostMode, and recomputed stateRoot match exactly,
   * - seenOpsRoot and every CAS node hash referenced by topics exist locally, and
   * - every suffix op id in cache.orderOpIds is present in `inputs` (in canonical order).
   * O(N) id lookups; no re-sort. Inputs not in the cache are applied by the next materialize().
   * Returns true on cache hit, false on miss.
   */
  async restoreMaterializedCache(cache, inputs) {
    if (cache.orderOpIds === void 0 || cache.orderOpIds.length === 0 && (cache.frontierOpIds?.length ?? 0) === 0) return false;
    const decodedSeen = await this.#loadCacheBase(cache);
    if (decodedSeen === null) return false;
    const byId = /* @__PURE__ */ new Map();
    for (const item of inputs) {
      const meta = metaOf(item);
      if (meta.logIdHex !== this.logIdHex) continue;
      if (this.blindHostMode && this.genesis.privateLog && item.core.visibility !== "public") continue;
      byId.set(meta.opIdHex, item);
    }
    const prefixLen = cache.orderOpIds.length;
    const order = new Array(prefixLen);
    for (let i = 0; i < prefixLen; i++) {
      const item = byId.get(cache.orderOpIds[i]);
      if (item === void 0) return false;
      if (i > 0) {
        const prev = order[i - 1];
        if (compareOperationOrder(
          { authorTimestampMs: prev.core.authorTimestampMs, author: prev.core.author, opId: prev.opId },
          { authorTimestampMs: item.core.authorTimestampMs, author: item.core.author, opId: item.opId }
        ) >= 0) return false;
      }
      order[i] = item;
    }
    this.#order = order;
    this.#outcomes = cache.outcomes.slice();
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(cache.topics)) : structuredClone(cache.topics);
    this.#topicHashes = computeTopicHashes(this.#topics);
    this.#resetLogs(decodedSeen);
    this.#seenRootCache = { length: this.#committedSeenLength, root: cache.seenOpsRoot };
    this.#topicLastOpIds = new Map(Object.entries(cache.topicLastOpIds ?? {}));
    for (const o of this.#outcomes) this.#outcomeLog.add(o.opId, { outcome: o.outcome, visibility: o.visibility });
    this.#frontierOpIds = new Set(cache.frontierOpIds);
    this.#frontierOrderLength = cache.frontierOpIds.length;
    this.#frontierMaxTimestampMs = BigInt(cache.frontierMaxTimestampMs ?? 0n);
    this.#historyDigest = cache.historyDigest;
    this.#stateRoot = cache.stateRoot;
    this.#pendingDependencies.clear();
    this.#skippedOpIds.clear();
    this.#snapshots.clear();
    if (this.#frontierOrderLength === 0) this.#snapshots.set(0, this.#genesisSnapshot);
    this.#snapshots.set(prefixLen, this.#captureSnapshot(prefixLen));
    this.#cacheRestores++;
    return true;
  }
  /**
   * Bootstrap kernel state directly from a verified FinalityCheckpoint snapshot.
   * Restores both topicsMap, seenOpsRoot (consumed handles), and rolling historyDigest
   * so subsequent suffix replay produces identical stateRoot AND revision.digest.
   */
  async bootstrapFromCheckpoint(checkpoint) {
    const seenNode = await this.cas.get(checkpoint.seenOpsRoot, "any");
    if (seenNode === null) throw new MissingDependencyError(checkpoint.seenOpsRoot, "cas");
    const decodedSeen = normalizeJsonValue(
      JSON.parse(JSON.stringify(
        // Decode CBOR array of strings stored in seenOpsRoot
        await import("./src-TVLZLKZX.mjs").then((m) => m.assertCanonicalCbor(seenNode.bytes, m.DEFAULT_DECODE_LIMITS))
      ))
    );
    const computedStateRoot = computeStateRoot(checkpoint.topics);
    if (computedStateRoot !== checkpoint.stateRoot) {
      throw new Error(`CHECKPOINT_STATE_ROOT_MISMATCH: expected ${checkpoint.stateRoot}, got ${computedStateRoot}`);
    }
    this.#order = [];
    this.#outcomes = [];
    this.#topicLastOpIds.clear();
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(checkpoint.topics)) : structuredClone(checkpoint.topics);
    this.#topicHashes = computeTopicHashes(this.#topics);
    this.#resetLogs(decodedSeen);
    this.#seenRootCache = { length: this.#committedSeenLength, root: checkpoint.seenOpsRoot };
    this.#historyDigest = checkpoint.historyDigest;
    this.#stateRoot = checkpoint.stateRoot;
    this.#snapshots.clear();
    this.#snapshots.set(0, this.#captureSnapshot(0));
    this.#historicalReducerRoots.clear();
    if (this.#topics.$reducers !== void 0) extractCasHashes(this.#topics.$reducers, this.#historicalReducerRoots);
  }
  /**
   * Bootstrap kernel state from a verified snapshot WITHOUT the historical operations: every op in
   * the cache (frontier and suffix) becomes frontier, so materialize(inputs) skips those ops and
   * applies only operations that are new. Trust: the caller has verified the snapshot's signer.
   */
  async restoreSnapshotFrontier(cache) {
    const decodedSeen = await this.#loadCacheBase(cache);
    if (decodedSeen === null) return false;
    let maxTs = BigInt(cache.frontierMaxTimestampMs ?? 0n);
    for (const o of cache.outcomes) if (o.authorTimestampMs > maxTs) maxTs = o.authorTimestampMs;
    this.#order = [];
    this.#outcomes = [];
    this.#topicLastOpIds = new Map(Object.entries(cache.topicLastOpIds ?? {}));
    this.#topics = this.blindHostMode ? filterPublicTopics(structuredClone(cache.topics)) : structuredClone(cache.topics);
    this.#topicHashes = computeTopicHashes(this.#topics);
    this.#resetLogs(decodedSeen);
    this.#seenRootCache = { length: this.#committedSeenLength, root: cache.seenOpsRoot };
    this.#historyDigest = cache.historyDigest;
    this.#stateRoot = cache.stateRoot;
    this.#frontierOpIds = /* @__PURE__ */ new Set([...cache.frontierOpIds, ...cache.orderOpIds]);
    this.#frontierOrderLength = this.#frontierOpIds.size;
    this.#frontierMaxTimestampMs = maxTs;
    this.#pendingDependencies.clear();
    this.#skippedOpIds.clear();
    this.#snapshots.clear();
    this.#snapshots.set(0, this.#captureSnapshot(0));
    this.#cacheRestores++;
    return true;
  }
  /**
   * Deterministically materialize an eligible operation set (arbitrary input order; sorted internally).
   * Rewinds only to the earliest snapshot before the first changed position (suffix replay).
   */
  async materialize(inputs) {
    return perfTimeAsync("kernel.materialize", () => this.materialize__impl(inputs));
  }
  async materialize__impl(inputs) {
    if (this.#disposed) throw new Error("SANDBOX_DISPOSED");
    const eligible = [];
    const seenIds = /* @__PURE__ */ new Set();
    for (const item of inputs) {
      const meta = metaOf(item);
      if (meta.logIdHex !== this.logIdHex) continue;
      if (this.blindHostMode && this.genesis.privateLog && item.core.visibility !== "public") continue;
      const opIdHex = meta.opIdHex;
      if (this.#frontierOpIds.has(opIdHex)) continue;
      if (seenIds.has(opIdHex)) continue;
      seenIds.add(opIdHex);
      eligible.push(item);
    }
    eligible.sort((a, b) => compareOperationOrder(
      { authorTimestampMs: a.core.authorTimestampMs, author: a.core.author, opId: a.opId },
      { authorTimestampMs: b.core.authorTimestampMs, author: b.core.author, opId: b.opId }
    ));
    let diff = 0;
    while (diff < this.#order.length && diff < eligible.length) {
      const prev = this.#order[diff], next = eligible[diff];
      if (prev !== next && metaOf(prev).opIdHex !== metaOf(next).opIdHex) break;
      diff++;
    }
    if (diff === eligible.length && this.#order.length === eligible.length && this.#pendingDependencies.size === 0) {
      return {
        revision: this.revision("local"),
        outcomes: this.#outcomes,
        replayedFrom: this.#outcomes.length,
        pendingDependencies: this.pendingDependencies,
        skippedOpIds: [...this.#skippedOpIds]
      };
    }
    if (this.#logsDirty) {
      diff = 0;
      for (const idx of [...this.#snapshots.keys()]) if (idx !== 0) this.#snapshots.delete(idx);
    }
    let snapIndex = 0;
    for (const idx of this.#snapshots.keys()) {
      if (idx <= diff && idx > snapIndex) snapIndex = idx;
    }
    const snapshotAt = this.#snapshots.get(snapIndex);
    if (snapshotAt === void 0) throw new Error("KERNEL_FRONTIER_REWIND");
    if (this.#frontierOrderLength > 0) {
      for (let i = diff; i < eligible.length; i++) {
        if (eligible[i].core.authorTimestampMs <= this.#frontierMaxTimestampMs) throw new Error("KERNEL_FRONTIER_REWIND");
      }
    }
    const snap = snapshotAt;
    this.#seen.truncate(snap.seenLength);
    this.#outcomeLog.truncate(snapIndex);
    this.#logsDirty = true;
    const work = {
      topics: { ...snap.topics },
      topicHashes: new Map(snap.topicHashes),
      seen: this.#seen,
      outcomes: this.#outcomeLog,
      topicLastOpIds: new Map(snap.topicLastOpIds),
      historyDigest: snap.historyDigest,
      stateRoot: snap.stateRoot
    };
    const nextSnapshots = /* @__PURE__ */ new Map();
    for (const [idx, s] of this.#snapshots) {
      if (idx <= snapIndex && (idx === 0 || idx % this.#snapshotInterval === 0 || idx === snapIndex)) {
        nextSnapshots.set(idx, s);
      }
    }
    const nextOutcomes = this.#outcomes.slice(0, snapIndex);
    const nextOrder = this.#order.slice(0, snapIndex);
    const nextPendingDeps = /* @__PURE__ */ new Set();
    const nextSkippedOps = /* @__PURE__ */ new Set();
    this.cas.beginBatch();
    try {
      for (let i = snapIndex; i < eligible.length; i++) {
        const entry = eligible[i];
        const opIdHex = bytesToHex(entry.opId);
        const authorHex = bytesToHex(entry.core.author);
        const step = await this.#applyOne(work, entry, opIdHex, authorHex);
        if (step.kind === "missing") {
          nextPendingDeps.add(step.dependency);
          nextSkippedOps.add(opIdHex);
          break;
        }
        nextOrder.push(entry);
        nextOutcomes.push(step.outcome);
        if (nextOrder.length % this.#snapshotInterval === 0) {
          nextSnapshots.set(nextOrder.length, this.#captureSnapshotFrom(work, nextOrder.length));
        }
      }
      if (nextOrder.length > 0 && !nextSnapshots.has(nextOrder.length)) {
        for (const idx of [...nextSnapshots.keys()]) {
          if (idx > 0 && idx % this.#snapshotInterval !== 0) nextSnapshots.delete(idx);
        }
        nextSnapshots.set(nextOrder.length, this.#captureSnapshotFrom(work, nextOrder.length));
      }
      await this.cas.flushBatch();
      this.#topics = work.topics;
      this.#topicHashes = work.topicHashes;
      this.#topicLastOpIds = work.topicLastOpIds;
      this.#historyDigest = work.historyDigest;
      this.#stateRoot = work.stateRoot;
      this.#order = nextOrder;
      this.#outcomes = nextOutcomes;
      this.#committedSeenLength = this.#seen.length;
      this.#seenRootCache = null;
      this.#logsDirty = false;
      this.#pendingDependencies = nextPendingDeps;
      this.#skippedOpIds = nextSkippedOps;
      this.#snapshots = nextSnapshots;
    } catch (err) {
      this.cas.rollbackBatch();
      throw err;
    }
    return {
      revision: this.revision("local"),
      // Committed outcome arrays are never mutated in place, so callers may hold this reference.
      outcomes: this.#outcomes,
      replayedFrom: Math.min(snapIndex, this.#outcomes.length),
      pendingDependencies: this.pendingDependencies,
      skippedOpIds: [...this.#skippedOpIds]
    };
  }
  async #applyOne(work, entry, opIdHex, authorHex) {
    const core = entry.core;
    const makeRejected = (code, detail, extra) => {
      const evs = extra?.events ?? [];
      const outcome = {
        opId: opIdHex,
        author: authorHex,
        operationId: core.operationId,
        authorTimestampMs: core.authorTimestampMs,
        visibility: core.visibility,
        outcome: "rejected",
        rejectionCode: code,
        ...detail === void 0 ? {} : { rejectionDetail: detail },
        ...extra?.conflictRecorded === true ? { conflictRecorded: true } : {},
        events: evs
      };
      work.outcomes.add(opIdHex, { outcome: "rejected", visibility: core.visibility });
      work.historyDigest = advanceHistoryDigest(work.historyDigest, opIdHex, "rejected", code, evs);
      return { kind: "done", outcome };
    };
    if (this.genesis.privateLog) {
      if (core.visibility === "public") {
        if (core.updates.some((u) => !isControlTopic(u.topic))) {
          return makeRejected("partition:public_op_private_topic");
        }
      } else {
        if (core.updates.some((u) => isControlTopic(u.topic))) {
          return makeRejected("partition:encrypted_op_control_topic");
        }
      }
    }
    if (core.updates.length > this.genesis.limits.maxUpdatesPerOp) {
      return makeRejected("limit:max_updates_per_op");
    }
    const dedupKey = seenOpKey(core.visibility, authorHex, core.operationId);
    if (work.seen.has(dedupKey)) {
      return makeRejected("operation_conflict");
    }
    const casPartition = this.genesis.privateLog && core.visibility === "public" ? "public" : "private";
    const isPublicOnPrivate = this.genesis.privateLog && core.visibility === "public";
    const visibleOutcome = (opId) => {
      const rec = work.outcomes.get(opId);
      if (rec === void 0 || isPublicOnPrivate && rec.visibility !== "public") return null;
      return rec.outcome;
    };
    const buildVisibleTopicLastOpIds = () => {
      const out = {};
      for (const [topicName, lastId] of work.topicLastOpIds) {
        if (isPublicOnPrivate && !isControlTopic(topicName)) continue;
        out[topicName] = lastId;
      }
      return out;
    };
    if (core.assumptions !== void 0 && core.assumptions.checks.length > 0) {
      const visibleTopicsForAssumptions = isPublicOnPrivate ? filterPublicTopics(work.topics) : work.topics;
      const visibleTopicLastOps = buildVisibleTopicLastOpIds();
      let failure = null;
      for (let i = 0; i < core.assumptions.checks.length; i++) {
        const chk = core.assumptions.checks[i];
        if (chk.kind === "op_accepted") {
          const st = visibleOutcome(chk.opId);
          if (st === null) {
            failure = { code: "assumption:missing_op", detail: `Required op ${chk.opId} not present`, checkIndex: i };
            break;
          }
          if (st !== "accepted") {
            failure = { code: "assumption:dependency_rejected", detail: `Required op ${chk.opId} was rejected`, checkIndex: i };
            break;
          }
        } else if (chk.kind === "op_rejected") {
          const st = visibleOutcome(chk.opId);
          if (st === null) {
            failure = { code: "assumption:missing_op", detail: `Referenced op ${chk.opId} not present`, checkIndex: i };
            break;
          }
          if (st !== "rejected") {
            failure = { code: "assumption:expected_rejected", detail: `Expected op ${chk.opId} to be rejected`, checkIndex: i };
            break;
          }
        } else if (chk.kind === "topic_revision") {
          if (isPublicOnPrivate && !isControlTopic(chk.topic)) {
            failure = { code: "partition:public_op_private_assumption", detail: `Public op cannot assume private topic ${chk.topic}`, checkIndex: i };
            break;
          }
          const actual = Object.hasOwn(visibleTopicLastOps, chk.topic) ? visibleTopicLastOps[chk.topic] : null;
          if (actual !== chk.lastOpId) {
            failure = { code: "assumption:topic_modified", detail: `Topic ${chk.topic} lastOpId expected ${String(chk.lastOpId)}, got ${String(actual)}`, checkIndex: i };
            break;
          }
        } else if (chk.kind === "query_match") {
          if (isPublicOnPrivate && !isControlTopic(chk.topic)) {
            failure = { code: "partition:public_op_private_assumption", detail: `Public op cannot query private topic ${chk.topic}`, checkIndex: i };
            break;
          }
          let reducersConfig;
          try {
            reducersConfig = assertValidReducersConfig(work.topics.$reducers);
          } catch (err) {
            failure = { code: "reducers_config_invalid", detail: err instanceof Error ? err.message : String(err), checkIndex: i };
            break;
          }
          const binding = reducersConfig.topics[chk.topic];
          const topicState = Object.hasOwn(visibleTopicsForAssumptions, chk.topic) ? visibleTopicsForAssumptions[chk.topic] : null;
          let actualValue = topicState;
          if (binding !== void 0) {
            let qRes;
            try {
              qRes = await this.sandbox.invoke({
                imports: reducersConfig.imports,
                builtins: reducersConfig.runtime.builtins,
                topicBindings: reducersConfig.topics,
                moduleSpecifier: binding.module,
                exportName: binding.export ?? "default",
                method: "query",
                state: topicState,
                payload: chk.query,
                opOutcome: visibleOutcome,
                topicLastOpIds: visibleTopicLastOps,
                topics: visibleTopicsForAssumptions,
                ...binding.config === void 0 ? {} : { config: binding.config },
                cas: this.cas,
                casPartition: isPublicOnPrivate || isControlTopic(chk.topic) ? "public" : "private",
                readOnly: true,
                maxMemoryBytes: this.genesis.limits.maxMemoryBytes,
                ...this.genesis.limits.maxFuel === void 0 ? {} : { maxFuel: this.genesis.limits.maxFuel }
              });
            } catch (err) {
              if (err instanceof MissingDependencyError) {
                return { kind: "missing", dependency: `${err.kind}/${err.hash}` };
              }
              throw err;
            }
            if (!qRes.ok) {
              if (qRes.code !== "vm:missing_method:query") {
                failure = { code: "assumption:query_failed", detail: qRes.detail ?? qRes.code, checkIndex: i };
                break;
              }
            } else {
              actualValue = qRes.value;
            }
          }
          if (canonicalJson(actualValue) !== canonicalJson(chk.expect)) {
            failure = { code: "assumption:query_mismatch", detail: `Query assumption ${i} on ${chk.topic} did not match`, checkIndex: i };
            break;
          }
        }
      }
      if (failure !== null) {
        work.seen.add(dedupKey, true);
        if (core.assumptions.onFailed === "record_conflict" && failure.code !== "partition:public_op_private_assumption") {
          const primaryUpdate = core.updates[0];
          let reducersConfig = null;
          try {
            reducersConfig = assertValidReducersConfig(work.topics.$reducers);
          } catch {
          }
          const binding = reducersConfig?.topics[primaryUpdate.topic];
          if (reducersConfig !== null && binding !== void 0) {
            const curTopicState = Object.hasOwn(work.topics, primaryUpdate.topic) ? work.topics[primaryUpdate.topic] : null;
            let conflictRes;
            try {
              conflictRes = await this.sandbox.invoke({
                imports: reducersConfig.imports,
                builtins: reducersConfig.runtime.builtins,
                topicBindings: reducersConfig.topics,
                moduleSpecifier: binding.module,
                exportName: binding.export ?? "default",
                method: "onConflict",
                state: curTopicState,
                payload: primaryUpdate.input,
                tx: {
                  opId: opIdHex,
                  author: authorHex,
                  authorTimestampMs: Number(core.authorTimestampMs),
                  operationId: core.operationId
                },
                conflict: failure,
                opOutcome: visibleOutcome,
                topicLastOpIds: visibleTopicLastOps,
                topics: visibleTopicsForAssumptions,
                ...binding.config === void 0 ? {} : { config: binding.config },
                cas: this.cas,
                casPartition,
                readOnly: false,
                maxMemoryBytes: this.genesis.limits.maxMemoryBytes,
                ...this.genesis.limits.maxFuel === void 0 ? {} : { maxFuel: this.genesis.limits.maxFuel }
              });
            } catch (err) {
              if (err instanceof MissingDependencyError) {
                return { kind: "missing", dependency: `${err.kind}/${err.hash}` };
              }
              throw err;
            }
            if (conflictRes.ok && conflictRes.value !== null && typeof conflictRes.value === "object" && !Array.isArray(conflictRes.value)) {
              const outRec = conflictRes.value;
              if (outRec.ok === true) {
                const nextTopicState = outRec.state === void 0 ? null : outRec.state;
                const encodedTopic = encodeCanonicalJsonCbor(nextTopicState);
                if (encodedTopic.length <= this.genesis.limits.maxTopicStateBytes) {
                  const conflictEvents = [];
                  let ord = 0;
                  if (Array.isArray(outRec.events)) {
                    for (const rawEv of outRec.events) {
                      if (rawEv !== null && typeof rawEv === "object" && !Array.isArray(rawEv)) {
                        const ev = rawEv;
                        if (typeof ev.topic === "string") {
                          conflictEvents.push({
                            opId: opIdHex,
                            eventOrdinal: ord++,
                            topic: ev.topic,
                            payload: ev.payload ?? null,
                            author: authorHex,
                            operationId: core.operationId,
                            authorTimestampMs: core.authorTimestampMs
                          });
                        }
                      }
                    }
                  }
                  work.topics = { ...work.topics, [primaryUpdate.topic]: nextTopicState };
                  work.topicHashes.set(primaryUpdate.topic, hashTopicBytes(encodedTopic));
                  work.stateRoot = stateRootFromHashes(work.topicHashes);
                  return makeRejected(failure.code, failure.detail, { conflictRecorded: true, events: conflictEvents });
                }
              }
            }
          }
        }
        return makeRejected(failure.code, failure.detail);
      }
    }
    const workingTopics = { ...work.topics };
    const workingHashes = /* @__PURE__ */ new Map();
    const topicHash = (name) => workingHashes.get(name) ?? work.topicHashes.get(name);
    const emitted = [];
    let ordinal = 0;
    const visibleTopicLastOpsForReduce = buildVisibleTopicLastOpIds();
    for (const update of core.updates) {
      let reducersConfig;
      try {
        reducersConfig = assertValidReducersConfig(workingTopics.$reducers);
      } catch (err) {
        return makeRejected("reducers_config_invalid", err instanceof Error ? err.message : String(err));
      }
      const binding = reducersConfig.topics[update.topic];
      if (binding === void 0) {
        return makeRejected(update.topic === "$reducers" ? "reducers_frozen" : `no_reducer:${update.topic}`);
      }
      const visibleTopics = this.genesis.privateLog && core.visibility === "public" ? filterPublicTopics(workingTopics) : workingTopics;
      const curTopicState = Object.hasOwn(workingTopics, update.topic) ? workingTopics[update.topic] : null;
      let res;
      try {
        res = await this.sandbox.invoke({
          imports: reducersConfig.imports,
          builtins: reducersConfig.runtime.builtins,
          topicBindings: reducersConfig.topics,
          moduleSpecifier: binding.module,
          exportName: binding.export ?? "default",
          method: "reduce",
          state: curTopicState,
          payload: update.input,
          tx: {
            opId: opIdHex,
            author: authorHex,
            authorTimestampMs: Number(core.authorTimestampMs),
            operationId: core.operationId
          },
          opOutcome: visibleOutcome,
          topicLastOpIds: visibleTopicLastOpsForReduce,
          topics: visibleTopics,
          topicHash,
          ...binding.config === void 0 ? {} : { config: binding.config },
          cas: this.cas,
          casPartition,
          readOnly: false,
          maxMemoryBytes: this.genesis.limits.maxMemoryBytes,
          ...this.genesis.limits.maxFuel === void 0 ? {} : { maxFuel: this.genesis.limits.maxFuel }
        });
      } catch (err) {
        if (err instanceof MissingDependencyError) {
          return { kind: "missing", dependency: `${err.kind}/${err.hash}` };
        }
        throw err;
      }
      if (!res.ok) {
        work.seen.add(dedupKey, true);
        return makeRejected(res.code, res.detail);
      }
      const outObj = res.value;
      if (outObj === null || typeof outObj !== "object" || Array.isArray(outObj)) {
        work.seen.add(dedupKey, true);
        return makeRejected("vm:invalid_reducer_return");
      }
      const outRec = outObj;
      if (typeof outRec.ok !== "boolean") {
        work.seen.add(dedupKey, true);
        return makeRejected("vm:invalid_reducer_return");
      }
      if (!outRec.ok) {
        const rejCode = typeof outRec.code === "string" && outRec.code.length > 0 ? outRec.code : "reducer:rejected";
        const rejDetail = typeof outRec.detail === "string" ? outRec.detail : void 0;
        work.seen.add(dedupKey, true);
        return makeRejected(rejCode, rejDetail);
      }
      const nextTopicState = outRec.state === void 0 ? null : outRec.state;
      const encodedTopic = encodeCanonicalJsonCbor(nextTopicState);
      if (encodedTopic.length > this.genesis.limits.maxTopicStateBytes) {
        work.seen.add(dedupKey, true);
        return makeRejected("limit:max_topic_state_bytes");
      }
      if (update.topic === "$reducers") {
        try {
          assertValidReducersConfig(nextTopicState);
        } catch (err) {
          work.seen.add(dedupKey, true);
          return makeRejected("reducers_config_invalid", err instanceof Error ? err.message : String(err));
        }
        extractCasHashes(nextTopicState, this.#historicalReducerRoots);
      }
      workingTopics[update.topic] = nextTopicState;
      workingHashes.set(update.topic, hashTopicBytes(encodedTopic));
      if (Array.isArray(outRec.events)) {
        for (const rawEv of outRec.events) {
          if (rawEv !== null && typeof rawEv === "object" && !Array.isArray(rawEv)) {
            const ev = rawEv;
            if (typeof ev.topic === "string") {
              emitted.push({
                opId: opIdHex,
                eventOrdinal: ordinal++,
                topic: ev.topic,
                payload: ev.payload ?? null,
                author: authorHex,
                operationId: core.operationId,
                authorTimestampMs: core.authorTimestampMs
              });
            }
          }
        }
      }
    }
    work.seen.add(dedupKey, true);
    work.topics = workingTopics;
    for (const [name, hash] of workingHashes) work.topicHashes.set(name, hash);
    work.outcomes.add(opIdHex, { outcome: "accepted", visibility: core.visibility });
    for (const u of core.updates) {
      work.topicLastOpIds.set(u.topic, opIdHex);
    }
    work.stateRoot = stateRootFromHashes(work.topicHashes);
    work.historyDigest = advanceHistoryDigest(work.historyDigest, opIdHex, "accepted", null, emitted);
    return {
      kind: "done",
      outcome: {
        opId: opIdHex,
        author: authorHex,
        operationId: core.operationId,
        authorTimestampMs: core.authorTimestampMs,
        visibility: core.visibility,
        outcome: "accepted",
        rejectionCode: null,
        events: emitted
      }
    };
  }
  /** Execute a pure read-only query against a topic's query() export (or return raw topic state if no query export). */
  async query(topic, input = null, topicsOverride) {
    const sourceTopics = topicsOverride ?? this.#topics;
    const normalizedInput = normalizeJsonValue(input);
    let cacheKey = null;
    if (topicsOverride === void 0) {
      cacheKey = `${topic}\0${this.#queryScope(topic)}\0${bytesToHex(encodeCanonicalJsonCbor(normalizedInput))}`;
      const hit = this.#queryCache.get(cacheKey);
      if (hit !== void 0) {
        this.#queryCache.delete(cacheKey);
        this.#queryCache.set(cacheKey, hit);
        return structuredClone(hit);
      }
    }
    const reducersConfig = assertValidReducersConfig(sourceTopics.$reducers);
    const binding = reducersConfig.topics[topic];
    const state = Object.hasOwn(sourceTopics, topic) ? sourceTopics[topic] : null;
    if (binding === void 0) return structuredClone(state);
    const casPartition = this.genesis.privateLog && isControlTopic(topic) ? "public" : "private";
    const visibleTopics = this.genesis.privateLog && isControlTopic(topic) ? filterPublicTopics(sourceTopics) : sourceTopics;
    const res = await this.sandbox.invoke({
      imports: reducersConfig.imports,
      builtins: reducersConfig.runtime.builtins,
      topicBindings: reducersConfig.topics,
      moduleSpecifier: binding.module,
      exportName: binding.export ?? "default",
      method: "query",
      state,
      payload: normalizedInput,
      topics: visibleTopics,
      ...topicsOverride === void 0 ? { topicHash: (name) => this.#topicHashes.get(name) } : {},
      ...binding.config === void 0 ? {} : { config: binding.config },
      cas: this.cas,
      casPartition,
      readOnly: true,
      maxMemoryBytes: this.genesis.limits.maxMemoryBytes,
      ...this.genesis.limits.maxFuel === void 0 ? {} : { maxFuel: this.genesis.limits.maxFuel }
    });
    if (!res.ok) {
      if (res.code === "vm:missing_method:query") return structuredClone(state);
      throw new Error(`KERNEL_QUERY_FAILED:${res.code}:${res.detail ?? ""}`);
    }
    if (cacheKey !== null && this.#topics === sourceTopics) {
      this.#queryCache.set(cacheKey, structuredClone(res.value));
      if (this.#queryCache.size > 256) {
        const oldest = this.#queryCache.keys().next().value;
        if (oldest !== void 0) this.#queryCache.delete(oldest);
      }
    }
    return res.value;
  }
  /**
   * Time-travel materialization: reconstructs the exact coherent state at a specific opId
   * or at/before a timestamp without mutating live kernel state.
   */
  async materializeAt(target) {
    let targetLen = 0;
    if ("opId" in target) {
      const idx = this.#order.findIndex((item) => bytesToHex(item.opId) === target.opId);
      if (idx < 0) throw new Error(`TIME_TRAVEL_OP_NOT_FOUND:${target.opId}`);
      targetLen = idx + 1;
    } else {
      for (let i = 0; i < this.#order.length; i++) {
        if (this.#order[i].core.authorTimestampMs <= target.atTimestampMs) {
          targetLen = i + 1;
        } else {
          break;
        }
      }
    }
    let snapIndex = 0;
    for (const idx of this.#snapshots.keys()) {
      if (idx <= targetLen && idx > snapIndex) snapIndex = idx;
    }
    const snap = this.#snapshots.get(snapIndex);
    if (snap === void 0) throw new Error("TIME_TRAVEL_BEFORE_FRONTIER");
    if (this.#logsDirty) throw new Error("KERNEL_REPLAY_IN_PROGRESS");
    const work = {
      topics: { ...snap.topics },
      topicHashes: new Map(snap.topicHashes),
      seen: this.#seen.clone(snap.seenLength),
      outcomes: this.#outcomeLog.clone(snapIndex),
      topicLastOpIds: new Map(snap.topicLastOpIds),
      historyDigest: snap.historyDigest,
      stateRoot: snap.stateRoot
    };
    this.cas.beginBatch();
    try {
      for (let i = snapIndex; i < targetLen; i++) {
        const entry = this.#order[i];
        const opIdHex = bytesToHex(entry.opId);
        const authorHex = bytesToHex(entry.core.author);
        const step = await this.#applyOne(work, entry, opIdHex, authorHex);
        if (step.kind === "missing") {
          throw new MissingDependencyError(step.dependency.split("/")[1] ?? step.dependency, "cas");
        }
      }
      this.cas.rollbackBatch();
    } catch (err) {
      this.cas.rollbackBatch();
      throw err;
    }
    const revision = {
      stateRoot: work.stateRoot,
      historyDigest: work.historyDigest,
      digest: computeRevisionDigest(work.historyDigest, work.stateRoot, "local", this.#policyContextDigest),
      view: "local",
      orderLength: targetLen
    };
    return {
      revision,
      topics: structuredClone(work.topics),
      orderLength: targetLen,
      targetOpId: targetLen > 0 ? bytesToHex(this.#order[targetLen - 1].opId) : null
    };
  }
  /** Execute a read-only query against a historical revision (by opId or timestamp). */
  async queryAt(topic, input, target) {
    const snap = await this.materializeAt(target);
    const value = await this.query(topic, input, snap.topics);
    return { revision: snap.revision, targetOpId: snap.targetOpId, value };
  }
  /** Collect exported command/query descriptions across all bound topics (for MCP & scoped tools). */
  async describe() {
    const reducersConfig = assertValidReducersConfig(this.#topics.$reducers);
    const out = {};
    const liveKeys = /* @__PURE__ */ new Set();
    for (const [topic, binding] of Object.entries(reducersConfig.topics)) {
      if (this.blindHostMode && this.genesis.privateLog && !isControlTopic(topic)) continue;
      const key = `${topic}\0${this.#queryScope(topic)}`;
      liveKeys.add(key);
      if (this.#describeCache.has(key)) {
        const hit = this.#describeCache.get(key);
        if (hit !== void 0) out[topic] = structuredClone(hit);
        continue;
      }
      const state = Object.hasOwn(this.#topics, topic) ? this.#topics[topic] : null;
      const casPartition = this.genesis.privateLog && isControlTopic(topic) ? "public" : "private";
      const res = await this.sandbox.invoke({
        imports: reducersConfig.imports,
        builtins: reducersConfig.runtime.builtins,
        topicBindings: reducersConfig.topics,
        moduleSpecifier: binding.module,
        exportName: binding.export ?? "default",
        method: "describe",
        state,
        payload: null,
        topics: this.blindHostMode ? filterPublicTopics(this.#topics) : this.#topics,
        ...binding.config === void 0 ? {} : { config: binding.config },
        cas: this.cas,
        casPartition,
        readOnly: true,
        maxMemoryBytes: this.genesis.limits.maxMemoryBytes,
        ...this.genesis.limits.maxFuel === void 0 ? {} : { maxFuel: this.genesis.limits.maxFuel }
      });
      if (res.ok) out[topic] = res.value;
      this.#describeCache.set(key, res.ok ? structuredClone(res.value) : void 0);
    }
    for (const key of [...this.#describeCache.keys()]) if (!liveKeys.has(key)) this.#describeCache.delete(key);
    return out;
  }
  /**
   * Cache scope for read-only calls on `topic`: everything such a call can observe. Control topics on
   * private logs can only observe control topics (partition rule), so app writes never invalidate them.
   */
  #queryScope(topic) {
    if (this.genesis.privateLog && isControlTopic(topic)) {
      let scope = "";
      for (const [name, hash] of this.#topicHashes) if (isControlTopic(name)) scope += `${name}=${hash};`;
      return scope;
    }
    return this.#stateRoot;
  }
  /** Evaluate signal authorization policy for the current stateRoot (cached by caller per stateRoot). */
  async signalPolicy() {
    const reducersConfig = assertValidReducersConfig(this.#topics.$reducers);
    if (reducersConfig.topics.$signal_policy !== void 0) {
      const val = await this.query("$signal_policy", null);
      if (val !== null && typeof val === "object" && !Array.isArray(val) && Array.isArray(val.rules)) {
        return val;
      }
    }
    const queriedReaders = await this.query("$permissions", { list: "readers" }).catch(() => null);
    if (Array.isArray(queriedReaders) && queriedReaders.every((x) => typeof x === "string")) {
      return {
        rules: [{ topicPattern: "*", allowedAuthors: queriedReaders, maxTtlMs: 3e4, allowRelay: true }]
      };
    }
    const perms = this.#topics.$permissions;
    const readers = (perms?.members ?? []).filter((m) => m.reader).map((m) => m.publicKey);
    return {
      rules: [{ topicPattern: "*", allowedAuthors: readers, maxTtlMs: 3e4, allowRelay: true }]
    };
  }
};

// packages/materializer/src/materialized-cache.ts
var MAGIC = 1129073987;
var FORMAT = 2;
var F_ENCRYPTED = 1;
var F_REJECTED = 2;
var F_CONFLICT = 4;
function encodeMaterializedCache(cache) {
  const authors = [];
  const authorIndex = /* @__PURE__ */ new Map();
  const authorOf = (hex) => {
    let index = authorIndex.get(hex);
    if (index === void 0) {
      index = authors.length;
      authors.push(hex);
      authorIndex.set(hex, index);
    }
    return index;
  };
  const outcomes = cache.outcomes.map((o) => {
    const flags = (o.visibility === "encrypted" ? F_ENCRYPTED : 0) | (o.outcome === "rejected" ? F_REJECTED : 0) | (o.conflictRecorded === true ? F_CONFLICT : 0);
    return [
      authorOf(o.author),
      o.operationId,
      o.authorTimestampMs.toString(),
      flags,
      o.rejectionCode,
      o.rejectionDetail ?? null,
      o.events.map((e) => [e.eventOrdinal, e.topic, e.payload])
    ];
  });
  const header = utf8(JSON.stringify({
    logId: cache.logId,
    blindHostMode: cache.blindHostMode,
    topics: cache.topics,
    seenOpsRoot: cache.seenOpsRoot,
    historyDigest: cache.historyDigest,
    stateRoot: cache.stateRoot,
    frontierMaxTimestampMs: cache.frontierMaxTimestampMs.toString(),
    topicLastOpIds: cache.topicLastOpIds,
    authors
  }));
  const body = utf8(JSON.stringify(outcomes));
  const total = 4 + 1 + 4 + header.length + 4 + 32 * cache.frontierOpIds.length + 4 + 32 * cache.orderOpIds.length + 4 + body.length;
  const out = new Uint8Array(total);
  const view = new DataView(out.buffer);
  let at = 0;
  view.setUint32(at, MAGIC);
  at += 4;
  out[at++] = FORMAT;
  view.setUint32(at, header.length);
  at += 4;
  out.set(header, at);
  at += header.length;
  for (const ids of [cache.frontierOpIds, cache.orderOpIds]) {
    view.setUint32(at, ids.length);
    at += 4;
    for (const id of ids) {
      out.set(hexToBytes(id), at);
      at += 32;
    }
  }
  view.setUint32(at, body.length);
  at += 4;
  out.set(body, at);
  return out;
}
function decodeMaterializedCache(bytes) {
  try {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let at = 0;
    if (view.getUint32(at) !== MAGIC) return null;
    at += 4;
    if (bytes[at++] !== FORMAT) return null;
    const text = new TextDecoder("utf-8", { fatal: true });
    const headerLen = view.getUint32(at);
    at += 4;
    const header = JSON.parse(text.decode(bytes.subarray(at, at + headerLen)));
    at += headerLen;
    const readIds = () => {
      const count = view.getUint32(at);
      at += 4;
      if (at + count * 32 > bytes.length) throw new Error("CACHE_TRUNCATED");
      const ids = new Array(count);
      for (let i = 0; i < count; i++) {
        ids[i] = bytesToHex(bytes.subarray(at, at + 32));
        at += 32;
      }
      return ids;
    };
    const frontierOpIds = readIds();
    const orderOpIds = readIds();
    const bodyLen = view.getUint32(at);
    at += 4;
    if (at + bodyLen !== bytes.length) return null;
    const rows = JSON.parse(text.decode(bytes.subarray(at, at + bodyLen)));
    if (!Array.isArray(rows) || rows.length !== orderOpIds.length) return null;
    const outcomes = rows.map((row, i) => {
      const [authorIdx, operationId, ts, flags, rejectionCode, rejectionDetail, events] = row;
      const opId = orderOpIds[i];
      const author = header.authors[authorIdx];
      const authorTimestampMs = BigInt(ts);
      return {
        opId,
        author,
        operationId,
        authorTimestampMs,
        visibility: (flags & F_ENCRYPTED) !== 0 ? "encrypted" : "public",
        outcome: (flags & F_REJECTED) !== 0 ? "rejected" : "accepted",
        rejectionCode,
        ...rejectionDetail === null ? {} : { rejectionDetail },
        ...(flags & F_CONFLICT) !== 0 ? { conflictRecorded: true } : {},
        events: events.map(([eventOrdinal, topic, payload]) => ({ opId, eventOrdinal, topic, payload, author, operationId, authorTimestampMs }))
      };
    });
    return {
      v: 2,
      logId: header.logId,
      blindHostMode: header.blindHostMode,
      topics: header.topics,
      seenOpsRoot: header.seenOpsRoot,
      historyDigest: header.historyDigest,
      stateRoot: header.stateRoot,
      frontierOpIds,
      frontierMaxTimestampMs: BigInt(header.frontierMaxTimestampMs),
      orderOpIds,
      outcomes,
      topicLastOpIds: header.topicLastOpIds
    };
  } catch {
    return null;
  }
}

export {
  WasmSandbox,
  MissingDependencyError,
  OperationalTimeoutError,
  QuickJsSandbox,
  signBuildAttestation,
  verifyBuildAttestation,
  signAuditAttestation,
  verifyAuditAttestation,
  createBytesStoreDerivationMemo,
  evaluateDerivation,
  verifyDerivationOutput,
  createWasiCasRunner,
  TopicKernel,
  encodeMaterializedCache,
  decodeMaterializedCache
};
