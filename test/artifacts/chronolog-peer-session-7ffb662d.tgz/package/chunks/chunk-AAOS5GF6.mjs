import {
  normalizeJsonValue
} from "./chunk-XIJQU6SK.mjs";

// packages/peer-session/src/tendriller.ts
function createApplicationBackend(session) {
  return {
    applicationId: session.applicationId,
    identity: session.identity,
    get status() {
      return session.status;
    },
    signal: session.signal,
    onStatus: session.onStatus.bind(session),
    submit: session.submit.bind(session),
    command: session.command.bind(session),
    query: session.query.bind(session),
    topic: session.topic.bind(session),
    describe: session.describe.bind(session),
    changes: session.changes.bind(session),
    readView: session.readView.bind(session),
    operations: session.operations,
    events: {
      publish: (topic, payload, options = {}) => session.submit({ ...options, updates: [{ topic, input: normalizeJsonValue(payload) }] }),
      read: session.readEvents.bind(session)
    }
  };
}

export {
  createApplicationBackend
};
