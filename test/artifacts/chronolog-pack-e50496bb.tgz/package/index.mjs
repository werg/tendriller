var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};

// packages/canonical/src/errors.ts
function canonicalInvariant(condition, code, message, details) {
  if (!condition) throw new CanonicalError(code, message, details);
}
var CanonicalError;
var init_errors = __esm({
  "packages/canonical/src/errors.ts"() {
    "use strict";
    CanonicalError = class extends Error {
      constructor(code, message, details) {
        super(message);
        this.code = code;
        this.details = details;
        this.name = "CanonicalError";
      }
      code;
      details;
    };
  }
});

// packages/canonical/src/bytes.ts
function utf8(value) {
  const encoded = textEncoder.encode(value);
  try {
    if (fatalTextDecoder.decode(encoded) !== value) throw new CanonicalError("INVALID_UTF8", "Text contains an unpaired UTF-16 surrogate");
  } catch (error) {
    if (error instanceof CanonicalError) throw error;
    throw new CanonicalError("INVALID_UTF8", "Text cannot be represented as canonical UTF-8");
  }
  return encoded;
}
function decodeUtf8(value) {
  try {
    return fatalTextDecoder.decode(value);
  } catch {
    throw new CanonicalError("INVALID_UTF8", "Bytes are not valid UTF-8");
  }
}
function concatBytes(...parts) {
  const size = parts.reduce((sum, part) => sum + part.length, 0);
  const result = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}
function compareBytes(left, right) {
  const size = Math.min(left.length, right.length);
  for (let index = 0; index < size; index += 1) {
    const difference = left[index] - right[index];
    if (difference !== 0) return difference < 0 ? -1 : 1;
  }
  return left.length === right.length ? 0 : left.length < right.length ? -1 : 1;
}
function equalBytes(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}
function bytesToHex(value) {
  let result = "";
  for (const byte of value) result += hexPairs[byte];
  return result;
}
function hexToBytes(value) {
  if (!/^(?:[0-9a-fA-F]{2})*$/u.test(value)) throw new CanonicalError("SCHEMA_INVALID", "Hex text is malformed");
  return Uint8Array.from({ length: value.length / 2 }, (_unused, index) => Number.parseInt(value.slice(index * 2, index * 2 + 2), 16));
}
var textEncoder, fatalTextDecoder, hexPairs;
var init_bytes = __esm({
  "packages/canonical/src/bytes.ts"() {
    "use strict";
    init_errors();
    textEncoder = new TextEncoder();
    fatalTextDecoder = new TextDecoder("utf-8", { fatal: true });
    hexPairs = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, "0"));
  }
});

// packages/canonical/src/perf.ts
function perfCount(name, n = 1) {
  counts.set(name, (counts.get(name) ?? 0) + n);
}
var counts, now;
var init_perf = __esm({
  "packages/canonical/src/perf.ts"() {
    "use strict";
    counts = /* @__PURE__ */ new Map();
    now = typeof globalThis.performance?.now === "function" ? () => globalThis.performance.now() : () => Date.now();
  }
});

// packages/canonical/src/cbor.ts
function encodeHead(major, value) {
  canonicalInvariant(value >= 0n && value <= MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR integer is outside uint64 range");
  if (value < 24n) return Uint8Array.of(major << 5 | Number(value));
  if (value <= 0xffn) return Uint8Array.of(major << 5 | 24, Number(value));
  if (value <= 0xffffn) return Uint8Array.of(major << 5 | 25, Number(value >> 8n), Number(value & 0xffn));
  if (value <= 0xffffffffn) {
    const bytes2 = new Uint8Array(5);
    bytes2[0] = major << 5 | 26;
    new DataView(bytes2.buffer).setUint32(1, Number(value), false);
    return bytes2;
  }
  const bytes = new Uint8Array(9);
  bytes[0] = major << 5 | 27;
  new DataView(bytes.buffer).setBigUint64(1, value, false);
  return bytes;
}
function magnitudeBytes(value) {
  canonicalInvariant(value > MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR bignum must exceed uint64 range");
  const octets = [];
  for (let remaining = value; remaining > 0n; remaining >>= 8n) octets.push(Number(remaining & 0xffn));
  octets.reverse();
  return Uint8Array.from(octets);
}
function encodeBigint(value) {
  const negative = value < 0n;
  const magnitude = negative ? -1n - value : value;
  if (magnitude <= MAX_UINT64) return encodeHead(negative ? 1 : 0, magnitude);
  const bytes = magnitudeBytes(magnitude);
  return concatBytes(
    encodeHead(6, negative ? NEGATIVE_BIGNUM_TAG : POSITIVE_BIGNUM_TAG),
    encodeHead(2, BigInt(bytes.length)),
    bytes
  );
}
function isMap(value) {
  return value instanceof Map;
}
function encodeCanonicalCbor(value) {
  perfCount("cbor.encode");
  return encodeValue(value);
}
function encodeValue(value) {
  if (value === null) return Uint8Array.of(246);
  if (value === false) return Uint8Array.of(244);
  if (value === true) return Uint8Array.of(245);
  if (typeof value === "bigint") return encodeBigint(value);
  if (typeof value === "string") {
    const bytes = utf8(value);
    return concatBytes(encodeHead(3, BigInt(bytes.length)), bytes);
  }
  if (value instanceof Uint8Array) return concatBytes(encodeHead(2, BigInt(value.length)), value);
  if (Array.isArray(value)) return concatBytes(encodeHead(4, BigInt(value.length)), ...value.map(encodeValue));
  if (isMap(value)) {
    const entries = [...value].map(([key, item]) => ({ key: encodeValue(key), value: encodeValue(item) })).sort((a, b) => a.key.length === b.key.length ? compareBytes(a.key, b.key) : a.key.length - b.key.length);
    for (let index = 1; index < entries.length; index += 1) canonicalInvariant(!equalBytes(entries[index - 1].key, entries[index].key), "CBOR_NON_CANONICAL", "Duplicate canonical CBOR map key");
    return concatBytes(encodeHead(5, BigInt(entries.length)), ...entries.flatMap((entry) => [entry.key, entry.value]));
  }
  throw new CanonicalError("SCHEMA_INVALID", "Value is not supported by the deterministic CBOR profile");
}
function decodeCanonicalCbor(input, limits) {
  perfCount("cbor.decode");
  perfCount("cbor.decode.bytes", input.length);
  return new Decoder(input, limits).decode();
}
function assertCanonicalCbor(input, limits) {
  const value = decodeCanonicalCbor(input, limits);
  canonicalInvariant(equalBytes(encodeCanonicalCbor(value), input), "CBOR_NON_CANONICAL", "CBOR bytes are not canonical");
  return value;
}
var DEFAULT_DECODE_LIMITS, MAX_UINT64, POSITIVE_BIGNUM_TAG, NEGATIVE_BIGNUM_TAG, Decoder;
var init_cbor = __esm({
  "packages/canonical/src/cbor.ts"() {
    "use strict";
    init_bytes();
    init_errors();
    init_perf();
    DEFAULT_DECODE_LIMITS = Object.freeze({
      maxBytes: 16 * 1024 * 1024,
      maxDepth: 64,
      maxArrayItems: 1e6,
      maxMapItems: 1e5,
      maxTextBytes: 4 * 1024 * 1024,
      maxBlobBytes: 16 * 1024 * 1024
    });
    MAX_UINT64 = (1n << 64n) - 1n;
    POSITIVE_BIGNUM_TAG = 2n;
    NEGATIVE_BIGNUM_TAG = 3n;
    Decoder = class {
      constructor(input, limits) {
        this.input = input;
        this.limits = limits;
        canonicalInvariant(input.length <= limits.maxBytes, "CBOR_LIMIT_EXCEEDED", "CBOR input exceeds byte limit");
      }
      input;
      limits;
      offset = 0;
      decode() {
        const value = this.value(0);
        canonicalInvariant(this.offset === this.input.length, "CBOR_INVALID", "Trailing bytes after CBOR value");
        return value;
      }
      byte() {
        canonicalInvariant(this.offset < this.input.length, "CBOR_INVALID", "Unexpected end of CBOR input");
        return this.input[this.offset++];
      }
      bytes(size) {
        canonicalInvariant(Number.isSafeInteger(size) && size >= 0 && this.offset + size <= this.input.length, "CBOR_INVALID", "Invalid or truncated CBOR byte range");
        const value = this.input.slice(this.offset, this.offset + size);
        this.offset += size;
        return value;
      }
      argument(additional) {
        if (additional < 24) return BigInt(additional);
        const read = (size) => {
          const bytes = this.bytes(size);
          const view = new DataView(bytes.buffer, bytes.byteOffset, size);
          return size === 1 ? BigInt(bytes[0]) : size === 2 ? BigInt(view.getUint16(0, false)) : size === 4 ? BigInt(view.getUint32(0, false)) : view.getBigUint64(0, false);
        };
        if (additional === 24) {
          const v = read(1);
          canonicalInvariant(v >= 24n, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
          return v;
        }
        if (additional === 25) {
          const v = read(2);
          canonicalInvariant(v > 0xffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
          return v;
        }
        if (additional === 26) {
          const v = read(4);
          canonicalInvariant(v > 0xffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
          return v;
        }
        if (additional === 27) {
          const v = read(8);
          canonicalInvariant(v > 0xffffffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
          return v;
        }
        if (additional === 31) throw new CanonicalError("CBOR_NON_CANONICAL", "Indefinite-length CBOR is prohibited");
        throw new CanonicalError("CBOR_INVALID", "Reserved CBOR additional information");
      }
      bignum(tag, depth) {
        canonicalInvariant(tag === POSITIVE_BIGNUM_TAG || tag === NEGATIVE_BIGNUM_TAG, "CBOR_INVALID", "Unsupported CBOR tag");
        canonicalInvariant(depth < this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
        const initial = this.byte(), major = initial >> 5, additional = initial & 31;
        canonicalInvariant(major === 2, "CBOR_INVALID", "CBOR bignum payload must be a byte string");
        const argument = this.argument(additional);
        canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR bignum is too large");
        const size = Number(argument);
        canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR bignum exceeds blob limit");
        const bytes = this.bytes(size);
        canonicalInvariant(bytes.length > 8 && bytes[0] !== 0, "CBOR_NON_CANONICAL", "CBOR bignum is not minimally encoded");
        let magnitude = 0n;
        for (const byte of bytes) magnitude = magnitude << 8n | BigInt(byte);
        canonicalInvariant(magnitude > MAX_UINT64, "CBOR_NON_CANONICAL", "CBOR bignum must use the ordinary integer representation");
        return tag === POSITIVE_BIGNUM_TAG ? magnitude : -1n - magnitude;
      }
      value(depth) {
        canonicalInvariant(depth <= this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
        const initial = this.byte(), major = initial >> 5, additional = initial & 31;
        if (major === 7) {
          if (additional === 20) return false;
          if (additional === 21) return true;
          if (additional === 22) return null;
          throw new CanonicalError("CBOR_INVALID", "Floating point and unsupported simple CBOR values are prohibited");
        }
        const argument = this.argument(additional);
        if (major === 6) return this.bignum(argument, depth + 1);
        if (major === 0) return argument;
        if (major === 1) return -1n - argument;
        canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR collection is too large");
        const size = Number(argument);
        if (major === 2) {
          canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR blob exceeds limit");
          return this.bytes(size);
        }
        if (major === 3) {
          canonicalInvariant(size <= this.limits.maxTextBytes, "CBOR_LIMIT_EXCEEDED", "CBOR text exceeds limit");
          return decodeUtf8(this.bytes(size));
        }
        if (major === 4) {
          canonicalInvariant(size <= this.limits.maxArrayItems, "CBOR_LIMIT_EXCEEDED", "CBOR array exceeds item limit");
          return Array.from({ length: size }, () => this.value(depth + 1));
        }
        if (major === 5) {
          canonicalInvariant(size <= this.limits.maxMapItems, "CBOR_LIMIT_EXCEEDED", "CBOR map exceeds item limit");
          const map = /* @__PURE__ */ new Map();
          let previous;
          for (let index = 0; index < size; index += 1) {
            const start = this.offset, key = this.value(depth + 1);
            canonicalInvariant(typeof key === "bigint" || typeof key === "string" || key instanceof Uint8Array, "CBOR_INVALID", "Unsupported CBOR map key");
            const encoded = this.input.slice(start, this.offset);
            if (previous !== void 0) canonicalInvariant(previous.length === encoded.length ? compareBytes(previous, encoded) < 0 : previous.length < encoded.length, "CBOR_NON_CANONICAL", "CBOR map keys are duplicate or incorrectly ordered");
            previous = encoded;
            map.set(key, this.value(depth + 1));
          }
          return map;
        }
        throw new CanonicalError("CBOR_INVALID", `Unsupported CBOR major type ${major}`);
      }
    };
  }
});

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/utils.js
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function abytes(b, ...lengths) {
  if (!isBytes(b))
    throw new Error("Uint8Array expected");
  if (lengths.length > 0 && !lengths.includes(b.length))
    throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
}
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput(out, instance) {
  abytes(out);
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error("digestInto() expects output buffer of length at least " + min);
  }
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word, shift) {
  return word << 32 - shift | word >>> shift;
}
function utf8ToBytes(str) {
  if (typeof str !== "string")
    throw new Error("string expected");
  return new Uint8Array(new TextEncoder().encode(str));
}
function toBytes(data) {
  if (typeof data === "string")
    data = utf8ToBytes(data);
  abytes(data);
  return data;
}
function createHasher(hashCons) {
  const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
  const tmp = hashCons();
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = () => hashCons();
  return hashC;
}
var Hash;
var init_utils = __esm({
  "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/utils.js"() {
    Hash = class {
    };
  }
});

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/_md.js
function setBigUint64(view, byteOffset, value, isLE) {
  if (typeof view.setBigUint64 === "function")
    return view.setBigUint64(byteOffset, value, isLE);
  const _32n2 = BigInt(32);
  const _u32_max = BigInt(4294967295);
  const wh = Number(value >> _32n2 & _u32_max);
  const wl = Number(value & _u32_max);
  const h = isLE ? 4 : 0;
  const l = isLE ? 0 : 4;
  view.setUint32(byteOffset + h, wh, isLE);
  view.setUint32(byteOffset + l, wl, isLE);
}
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD, SHA256_IV, SHA512_IV;
var init_md = __esm({
  "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/_md.js"() {
    init_utils();
    HashMD = class extends Hash {
      constructor(blockLen, outputLen, padOffset, isLE) {
        super();
        this.finished = false;
        this.length = 0;
        this.pos = 0;
        this.destroyed = false;
        this.blockLen = blockLen;
        this.outputLen = outputLen;
        this.padOffset = padOffset;
        this.isLE = isLE;
        this.buffer = new Uint8Array(blockLen);
        this.view = createView(this.buffer);
      }
      update(data) {
        aexists(this);
        data = toBytes(data);
        abytes(data);
        const { view, buffer, blockLen } = this;
        const len = data.length;
        for (let pos = 0; pos < len; ) {
          const take = Math.min(blockLen - this.pos, len - pos);
          if (take === blockLen) {
            const dataView = createView(data);
            for (; blockLen <= len - pos; pos += blockLen)
              this.process(dataView, pos);
            continue;
          }
          buffer.set(data.subarray(pos, pos + take), this.pos);
          this.pos += take;
          pos += take;
          if (this.pos === blockLen) {
            this.process(view, 0);
            this.pos = 0;
          }
        }
        this.length += data.length;
        this.roundClean();
        return this;
      }
      digestInto(out) {
        aexists(this);
        aoutput(out, this);
        this.finished = true;
        const { buffer, view, blockLen, isLE } = this;
        let { pos } = this;
        buffer[pos++] = 128;
        clean(this.buffer.subarray(pos));
        if (this.padOffset > blockLen - pos) {
          this.process(view, 0);
          pos = 0;
        }
        for (let i = pos; i < blockLen; i++)
          buffer[i] = 0;
        setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE);
        this.process(view, 0);
        const oview = createView(out);
        const len = this.outputLen;
        if (len % 4)
          throw new Error("_sha2: outputLen should be aligned to 32bit");
        const outLen = len / 4;
        const state = this.get();
        if (outLen > state.length)
          throw new Error("_sha2: outputLen bigger than state");
        for (let i = 0; i < outLen; i++)
          oview.setUint32(4 * i, state[i], isLE);
      }
      digest() {
        const { buffer, outputLen } = this;
        this.digestInto(buffer);
        const res = buffer.slice(0, outputLen);
        this.destroy();
        return res;
      }
      _cloneInto(to) {
        to || (to = new this.constructor());
        to.set(...this.get());
        const { blockLen, buffer, length, finished, destroyed, pos } = this;
        to.destroyed = destroyed;
        to.finished = finished;
        to.length = length;
        to.pos = pos;
        if (length % blockLen)
          to.buffer.set(buffer);
        return to;
      }
      clone() {
        return this._cloneInto();
      }
    };
    SHA256_IV = /* @__PURE__ */ Uint32Array.from([
      1779033703,
      3144134277,
      1013904242,
      2773480762,
      1359893119,
      2600822924,
      528734635,
      1541459225
    ]);
    SHA512_IV = /* @__PURE__ */ Uint32Array.from([
      1779033703,
      4089235720,
      3144134277,
      2227873595,
      1013904242,
      4271175723,
      2773480762,
      1595750129,
      1359893119,
      2917565137,
      2600822924,
      725511199,
      528734635,
      4215389547,
      1541459225,
      327033209
    ]);
  }
});

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/_u64.js
function fromBig(n, le = false) {
  if (le)
    return { h: Number(n & U32_MASK64), l: Number(n >> _32n & U32_MASK64) };
  return { h: Number(n >> _32n & U32_MASK64) | 0, l: Number(n & U32_MASK64) | 0 };
}
function split(lst, le = false) {
  const len = lst.length;
  let Ah = new Uint32Array(len);
  let Al = new Uint32Array(len);
  for (let i = 0; i < len; i++) {
    const { h, l } = fromBig(lst[i], le);
    [Ah[i], Al[i]] = [h, l];
  }
  return [Ah, Al];
}
function add(Ah, Al, Bh, Bl) {
  const l = (Al >>> 0) + (Bl >>> 0);
  return { h: Ah + Bh + (l / 2 ** 32 | 0) | 0, l: l | 0 };
}
var U32_MASK64, _32n, shrSH, shrSL, rotrSH, rotrSL, rotrBH, rotrBL, add3L, add3H, add4L, add4H, add5L, add5H;
var init_u64 = __esm({
  "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/_u64.js"() {
    U32_MASK64 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
    _32n = /* @__PURE__ */ BigInt(32);
    shrSH = (h, _l, s) => h >>> s;
    shrSL = (h, l, s) => h << 32 - s | l >>> s;
    rotrSH = (h, l, s) => h >>> s | l << 32 - s;
    rotrSL = (h, l, s) => h << 32 - s | l >>> s;
    rotrBH = (h, l, s) => h << 64 - s | l >>> s - 32;
    rotrBL = (h, l, s) => h >>> s - 32 | l << 64 - s;
    add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
    add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;
    add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0);
    add4H = (low, Ah, Bh, Ch, Dh) => Ah + Bh + Ch + Dh + (low / 2 ** 32 | 0) | 0;
    add5L = (Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0);
    add5H = (low, Ah, Bh, Ch, Dh, Eh) => Ah + Bh + Ch + Dh + Eh + (low / 2 ** 32 | 0) | 0;
  }
});

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha2.js
var SHA256_K, SHA256_W, SHA256, K512, SHA512_Kh, SHA512_Kl, SHA512_W_H, SHA512_W_L, SHA512, sha256, sha512;
var init_sha2 = __esm({
  "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha2.js"() {
    init_md();
    init_u64();
    init_utils();
    SHA256_K = /* @__PURE__ */ Uint32Array.from([
      1116352408,
      1899447441,
      3049323471,
      3921009573,
      961987163,
      1508970993,
      2453635748,
      2870763221,
      3624381080,
      310598401,
      607225278,
      1426881987,
      1925078388,
      2162078206,
      2614888103,
      3248222580,
      3835390401,
      4022224774,
      264347078,
      604807628,
      770255983,
      1249150122,
      1555081692,
      1996064986,
      2554220882,
      2821834349,
      2952996808,
      3210313671,
      3336571891,
      3584528711,
      113926993,
      338241895,
      666307205,
      773529912,
      1294757372,
      1396182291,
      1695183700,
      1986661051,
      2177026350,
      2456956037,
      2730485921,
      2820302411,
      3259730800,
      3345764771,
      3516065817,
      3600352804,
      4094571909,
      275423344,
      430227734,
      506948616,
      659060556,
      883997877,
      958139571,
      1322822218,
      1537002063,
      1747873779,
      1955562222,
      2024104815,
      2227730452,
      2361852424,
      2428436474,
      2756734187,
      3204031479,
      3329325298
    ]);
    SHA256_W = /* @__PURE__ */ new Uint32Array(64);
    SHA256 = class extends HashMD {
      constructor(outputLen = 32) {
        super(64, outputLen, 8, false);
        this.A = SHA256_IV[0] | 0;
        this.B = SHA256_IV[1] | 0;
        this.C = SHA256_IV[2] | 0;
        this.D = SHA256_IV[3] | 0;
        this.E = SHA256_IV[4] | 0;
        this.F = SHA256_IV[5] | 0;
        this.G = SHA256_IV[6] | 0;
        this.H = SHA256_IV[7] | 0;
      }
      get() {
        const { A, B, C, D, E, F, G: G2, H } = this;
        return [A, B, C, D, E, F, G2, H];
      }
      // prettier-ignore
      set(A, B, C, D, E, F, G2, H) {
        this.A = A | 0;
        this.B = B | 0;
        this.C = C | 0;
        this.D = D | 0;
        this.E = E | 0;
        this.F = F | 0;
        this.G = G2 | 0;
        this.H = H | 0;
      }
      process(view, offset) {
        for (let i = 0; i < 16; i++, offset += 4)
          SHA256_W[i] = view.getUint32(offset, false);
        for (let i = 16; i < 64; i++) {
          const W15 = SHA256_W[i - 15];
          const W2 = SHA256_W[i - 2];
          const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
          const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
          SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
        }
        let { A, B, C, D, E, F, G: G2, H } = this;
        for (let i = 0; i < 64; i++) {
          const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
          const T1 = H + sigma1 + Chi(E, F, G2) + SHA256_K[i] + SHA256_W[i] | 0;
          const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
          const T2 = sigma0 + Maj(A, B, C) | 0;
          H = G2;
          G2 = F;
          F = E;
          E = D + T1 | 0;
          D = C;
          C = B;
          B = A;
          A = T1 + T2 | 0;
        }
        A = A + this.A | 0;
        B = B + this.B | 0;
        C = C + this.C | 0;
        D = D + this.D | 0;
        E = E + this.E | 0;
        F = F + this.F | 0;
        G2 = G2 + this.G | 0;
        H = H + this.H | 0;
        this.set(A, B, C, D, E, F, G2, H);
      }
      roundClean() {
        clean(SHA256_W);
      }
      destroy() {
        this.set(0, 0, 0, 0, 0, 0, 0, 0);
        clean(this.buffer);
      }
    };
    K512 = /* @__PURE__ */ (() => split([
      "0x428a2f98d728ae22",
      "0x7137449123ef65cd",
      "0xb5c0fbcfec4d3b2f",
      "0xe9b5dba58189dbbc",
      "0x3956c25bf348b538",
      "0x59f111f1b605d019",
      "0x923f82a4af194f9b",
      "0xab1c5ed5da6d8118",
      "0xd807aa98a3030242",
      "0x12835b0145706fbe",
      "0x243185be4ee4b28c",
      "0x550c7dc3d5ffb4e2",
      "0x72be5d74f27b896f",
      "0x80deb1fe3b1696b1",
      "0x9bdc06a725c71235",
      "0xc19bf174cf692694",
      "0xe49b69c19ef14ad2",
      "0xefbe4786384f25e3",
      "0x0fc19dc68b8cd5b5",
      "0x240ca1cc77ac9c65",
      "0x2de92c6f592b0275",
      "0x4a7484aa6ea6e483",
      "0x5cb0a9dcbd41fbd4",
      "0x76f988da831153b5",
      "0x983e5152ee66dfab",
      "0xa831c66d2db43210",
      "0xb00327c898fb213f",
      "0xbf597fc7beef0ee4",
      "0xc6e00bf33da88fc2",
      "0xd5a79147930aa725",
      "0x06ca6351e003826f",
      "0x142929670a0e6e70",
      "0x27b70a8546d22ffc",
      "0x2e1b21385c26c926",
      "0x4d2c6dfc5ac42aed",
      "0x53380d139d95b3df",
      "0x650a73548baf63de",
      "0x766a0abb3c77b2a8",
      "0x81c2c92e47edaee6",
      "0x92722c851482353b",
      "0xa2bfe8a14cf10364",
      "0xa81a664bbc423001",
      "0xc24b8b70d0f89791",
      "0xc76c51a30654be30",
      "0xd192e819d6ef5218",
      "0xd69906245565a910",
      "0xf40e35855771202a",
      "0x106aa07032bbd1b8",
      "0x19a4c116b8d2d0c8",
      "0x1e376c085141ab53",
      "0x2748774cdf8eeb99",
      "0x34b0bcb5e19b48a8",
      "0x391c0cb3c5c95a63",
      "0x4ed8aa4ae3418acb",
      "0x5b9cca4f7763e373",
      "0x682e6ff3d6b2b8a3",
      "0x748f82ee5defb2fc",
      "0x78a5636f43172f60",
      "0x84c87814a1f0ab72",
      "0x8cc702081a6439ec",
      "0x90befffa23631e28",
      "0xa4506cebde82bde9",
      "0xbef9a3f7b2c67915",
      "0xc67178f2e372532b",
      "0xca273eceea26619c",
      "0xd186b8c721c0c207",
      "0xeada7dd6cde0eb1e",
      "0xf57d4f7fee6ed178",
      "0x06f067aa72176fba",
      "0x0a637dc5a2c898a6",
      "0x113f9804bef90dae",
      "0x1b710b35131c471b",
      "0x28db77f523047d84",
      "0x32caab7b40c72493",
      "0x3c9ebe0a15c9bebc",
      "0x431d67c49c100d4c",
      "0x4cc5d4becb3e42b6",
      "0x597f299cfc657e2a",
      "0x5fcb6fab3ad6faec",
      "0x6c44198c4a475817"
    ].map((n) => BigInt(n))))();
    SHA512_Kh = /* @__PURE__ */ (() => K512[0])();
    SHA512_Kl = /* @__PURE__ */ (() => K512[1])();
    SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
    SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);
    SHA512 = class extends HashMD {
      constructor(outputLen = 64) {
        super(128, outputLen, 16, false);
        this.Ah = SHA512_IV[0] | 0;
        this.Al = SHA512_IV[1] | 0;
        this.Bh = SHA512_IV[2] | 0;
        this.Bl = SHA512_IV[3] | 0;
        this.Ch = SHA512_IV[4] | 0;
        this.Cl = SHA512_IV[5] | 0;
        this.Dh = SHA512_IV[6] | 0;
        this.Dl = SHA512_IV[7] | 0;
        this.Eh = SHA512_IV[8] | 0;
        this.El = SHA512_IV[9] | 0;
        this.Fh = SHA512_IV[10] | 0;
        this.Fl = SHA512_IV[11] | 0;
        this.Gh = SHA512_IV[12] | 0;
        this.Gl = SHA512_IV[13] | 0;
        this.Hh = SHA512_IV[14] | 0;
        this.Hl = SHA512_IV[15] | 0;
      }
      // prettier-ignore
      get() {
        const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
        return [Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl];
      }
      // prettier-ignore
      set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
        this.Ah = Ah | 0;
        this.Al = Al | 0;
        this.Bh = Bh | 0;
        this.Bl = Bl | 0;
        this.Ch = Ch | 0;
        this.Cl = Cl | 0;
        this.Dh = Dh | 0;
        this.Dl = Dl | 0;
        this.Eh = Eh | 0;
        this.El = El | 0;
        this.Fh = Fh | 0;
        this.Fl = Fl | 0;
        this.Gh = Gh | 0;
        this.Gl = Gl | 0;
        this.Hh = Hh | 0;
        this.Hl = Hl | 0;
      }
      process(view, offset) {
        for (let i = 0; i < 16; i++, offset += 4) {
          SHA512_W_H[i] = view.getUint32(offset);
          SHA512_W_L[i] = view.getUint32(offset += 4);
        }
        for (let i = 16; i < 80; i++) {
          const W15h = SHA512_W_H[i - 15] | 0;
          const W15l = SHA512_W_L[i - 15] | 0;
          const s0h = rotrSH(W15h, W15l, 1) ^ rotrSH(W15h, W15l, 8) ^ shrSH(W15h, W15l, 7);
          const s0l = rotrSL(W15h, W15l, 1) ^ rotrSL(W15h, W15l, 8) ^ shrSL(W15h, W15l, 7);
          const W2h = SHA512_W_H[i - 2] | 0;
          const W2l = SHA512_W_L[i - 2] | 0;
          const s1h = rotrSH(W2h, W2l, 19) ^ rotrBH(W2h, W2l, 61) ^ shrSH(W2h, W2l, 6);
          const s1l = rotrSL(W2h, W2l, 19) ^ rotrBL(W2h, W2l, 61) ^ shrSL(W2h, W2l, 6);
          const SUMl = add4L(s0l, s1l, SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
          const SUMh = add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]);
          SHA512_W_H[i] = SUMh | 0;
          SHA512_W_L[i] = SUMl | 0;
        }
        let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
        for (let i = 0; i < 80; i++) {
          const sigma1h = rotrSH(Eh, El, 14) ^ rotrSH(Eh, El, 18) ^ rotrBH(Eh, El, 41);
          const sigma1l = rotrSL(Eh, El, 14) ^ rotrSL(Eh, El, 18) ^ rotrBL(Eh, El, 41);
          const CHIh = Eh & Fh ^ ~Eh & Gh;
          const CHIl = El & Fl ^ ~El & Gl;
          const T1ll = add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
          const T1h = add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
          const T1l = T1ll | 0;
          const sigma0h = rotrSH(Ah, Al, 28) ^ rotrBH(Ah, Al, 34) ^ rotrBH(Ah, Al, 39);
          const sigma0l = rotrSL(Ah, Al, 28) ^ rotrBL(Ah, Al, 34) ^ rotrBL(Ah, Al, 39);
          const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
          const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
          Hh = Gh | 0;
          Hl = Gl | 0;
          Gh = Fh | 0;
          Gl = Fl | 0;
          Fh = Eh | 0;
          Fl = El | 0;
          ({ h: Eh, l: El } = add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
          Dh = Ch | 0;
          Dl = Cl | 0;
          Ch = Bh | 0;
          Cl = Bl | 0;
          Bh = Ah | 0;
          Bl = Al | 0;
          const All = add3L(T1l, sigma0l, MAJl);
          Ah = add3H(All, T1h, sigma0h, MAJh);
          Al = All | 0;
        }
        ({ h: Ah, l: Al } = add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
        ({ h: Bh, l: Bl } = add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
        ({ h: Ch, l: Cl } = add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
        ({ h: Dh, l: Dl } = add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
        ({ h: Eh, l: El } = add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
        ({ h: Fh, l: Fl } = add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
        ({ h: Gh, l: Gl } = add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
        ({ h: Hh, l: Hl } = add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
        this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
      }
      roundClean() {
        clean(SHA512_W_H, SHA512_W_L);
      }
      destroy() {
        clean(this.buffer);
        this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
      }
    };
    sha256 = /* @__PURE__ */ createHasher(() => new SHA256());
    sha512 = /* @__PURE__ */ createHasher(() => new SHA512());
  }
});

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha256.js
var sha2562;
var init_sha256 = __esm({
  "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha256.js"() {
    init_sha2();
    sha2562 = sha256;
  }
});

// packages/canonical/src/sync-hash.ts
function sha256Sync(bytes) {
  perfCount("sha256Sync");
  perfCount("sha256Sync.bytes", bytes.length);
  return sha2562(bytes);
}
var init_sync_hash = __esm({
  "packages/canonical/src/sync-hash.ts"() {
    "use strict";
    init_sha256();
    init_bytes();
    init_perf();
  }
});

// packages/canonical/src/hash.ts
function domainSeparatedBytes(domain, payload) {
  const name = utf8(HASH_DOMAINS[domain]);
  const size = new Uint8Array(4);
  new DataView(size.buffer).setUint32(0, name.length, false);
  return concatBytes(size, name, Uint8Array.of(0), payload);
}
function hashDomainSync(domain, payload) {
  return sha256Sync(domainSeparatedBytes(domain, payload));
}
var HASH_DOMAINS;
var init_hash = __esm({
  "packages/canonical/src/hash.ts"() {
    "use strict";
    init_bytes();
    init_sync_hash();
    HASH_DOMAINS = Object.freeze({
      transaction: "chronolog/transaction",
      schema: "chronolog/schema",
      executionManifest: "chronolog/execution-manifest",
      queryResult: "chronolog/query-result",
      expectation: "chronolog/expectation",
      module: "chronolog/module",
      entropy: "chronolog/entropy",
      platformObject: "chronolog/platform-object",
      genesis: "chronolog/genesis/v1",
      op: "chronolog/op/v1",
      envelope: "chronolog/envelope/v1",
      state: "chronolog/state/v3",
      topic: "chronolog/topic/v1",
      cas: "chronolog/cas/v1",
      history: "chronolog/history/v1",
      revision: "chronolog/revision/v1"
    });
  }
});

// packages/canonical/src/schema.ts
var init_schema = __esm({
  "packages/canonical/src/schema.ts"() {
    "use strict";
    init_errors();
  }
});

// packages/canonical/src/index.ts
var init_src = __esm({
  "packages/canonical/src/index.ts"() {
    "use strict";
    init_bytes();
    init_cbor();
    init_errors();
    init_hash();
    init_sync_hash();
    init_schema();
    init_perf();
  }
});

// packages/pack/src/linter.ts
var LINT_RULES = [
  {
    code: "nondeterministic:date",
    pattern: /\b(?:new\s+Date\b|Date\.(?:now|parse|UTC)\b)/gu,
    message: "Wall-clock Date API is forbidden in deterministic reducers.",
    suggestion: "Use tx.authorTimestampMs instead."
  },
  {
    code: "nondeterministic:random",
    pattern: /\b(?:Math\.random\b|crypto\.(?:getRandomValues|randomUUID)\b)/gu,
    message: "Randomness APIs are forbidden in deterministic reducers.",
    suggestion: "Derive deterministic entropy via sha256(tx.opId + ...) from chronolog:crypto."
  },
  {
    code: "nondeterministic:intl",
    pattern: /\bIntl\./gu,
    message: "Locale-dependent Intl APIs are stripped in Chronolog.",
    suggestion: "Use explicit UTC/ASCII formatting or pure deterministic helpers."
  },
  {
    code: "nondeterministic:clock",
    pattern: /\b(?:performance\.now\b|setTimeout\b|setInterval\b|setImmediate\b)/gu,
    message: "Timers and high-resolution clocks are forbidden in deterministic reducers.",
    suggestion: "Model time explicitly using tx.authorTimestampMs."
  },
  {
    code: "forbidden:host-io",
    pattern: /\b(?:fetch\s*\(|XMLHttpRequest\b|WebSocket\b|from\s+['"]node:|import\s*\(\s*['"]node:)/gu,
    message: "Host I/O, network, and Node builtins are unavailable inside the Chronolog sandbox.",
    suggestion: "Move I/O outside reducers and pass verified data via operation payloads or CAS."
  },
  {
    code: "forbidden:async-reducer",
    pattern: /\basync\s+(?:function\s+)?(?:reduce|query|describe|onConflict)\s*\(/gu,
    message: "Chronolog reducer hooks (reduce, query, describe, onConflict) must be synchronous.",
    suggestion: "Remove async/await from reducer methods."
  }
];
function maskCommentsAndStrings(source) {
  const chars = [...source];
  let i = 0;
  while (i < chars.length) {
    const c = chars[i];
    const next = chars[i + 1];
    if (c === "/" && next === "/") {
      while (i < chars.length && chars[i] !== "\n") {
        chars[i] = " ";
        i++;
      }
      continue;
    }
    if (c === "/" && next === "*") {
      chars[i] = " ";
      chars[i + 1] = " ";
      i += 2;
      while (i < chars.length && !(chars[i] === "*" && chars[i + 1] === "/")) {
        if (chars[i] !== "\n") chars[i] = " ";
        i++;
      }
      if (i + 1 < chars.length) {
        chars[i] = " ";
        chars[i + 1] = " ";
        i += 2;
      }
      continue;
    }
    if (c === '"' || c === "'" || c === "`") {
      const quote = c;
      const prefix = source.slice(Math.max(0, i - 16), i);
      const isImportSpec = /(?:from\s+|import\s*\(\s*)$/u.test(prefix);
      i++;
      while (i < chars.length) {
        if (chars[i] === "\\") {
          if (!isImportSpec) {
            chars[i] = " ";
            if (i + 1 < chars.length && chars[i + 1] !== "\n") chars[i + 1] = " ";
          }
          i += 2;
          continue;
        }
        if (chars[i] === quote) {
          i++;
          break;
        }
        if (!isImportSpec && chars[i] !== "\n") chars[i] = " ";
        i++;
      }
      continue;
    }
    i++;
  }
  return chars.join("");
}
function lineColAt(source, index) {
  let line = 1;
  let lastNl = -1;
  for (let i = 0; i < index; i++) {
    if (source.charCodeAt(i) === 10) {
      line++;
      lastNl = i;
    }
  }
  return { line, column: index - lastNl };
}
function lintDeterminism(source, file = "index.js") {
  const masked = maskCommentsAndStrings(source);
  const diagnostics = [];
  for (const rule of LINT_RULES) {
    rule.pattern.lastIndex = 0;
    let match;
    while ((match = rule.pattern.exec(masked)) !== null) {
      const { line, column } = lineColAt(source, match.index);
      diagnostics.push({
        code: rule.code,
        file,
        line,
        column,
        message: rule.message,
        suggestion: rule.suggestion
      });
    }
  }
  diagnostics.sort((a, b) => a.line - b.line || a.column - b.column || a.code.localeCompare(b.code));
  return diagnostics;
}
var BUILTIN_IMPORT_RE = /(?:from\s*['"]|import\s*['"]|import\s*\(\s*['"])(chronolog:(?:crypto|cas|sqlite|wasm))['"]/gu;
function detectRequiredBuiltins(sources) {
  const found = /* @__PURE__ */ new Set();
  for (const src of sources) {
    BUILTIN_IMPORT_RE.lastIndex = 0;
    let match;
    while ((match = BUILTIN_IMPORT_RE.exec(src)) !== null) {
      found.add(match[1]);
    }
  }
  return [...found].sort();
}

// packages/pack/src/tarball.ts
import { createHash } from "node:crypto";
import { gunzipSync } from "node:zlib";

// packages/records/src/bytes-store.ts
var MemoryBytesStore = class {
  #values = /* @__PURE__ */ new Map();
  #changelog = [];
  #seq = 0;
  #quotaBytes;
  #maxValueBytes;
  #usedBytes = 0;
  constructor(options = {}) {
    for (const limit of [options.quotaBytes, options.maxValueBytes]) {
      if (limit !== void 0 && (!Number.isSafeInteger(limit) || limit < 1)) throw new Error("BYTES_STORE_QUOTA_INVALID");
    }
    this.#quotaBytes = options.quotaBytes ?? Infinity;
    this.#maxValueBytes = options.maxValueBytes ?? Infinity;
  }
  #recordChange(key, deleted) {
    this.#changelog.push({ seq: ++this.#seq, key, deleted });
    if (this.#changelog.length > 16384) this.#changelog.splice(0, this.#changelog.length - 8192);
  }
  async get(key) {
    return this.#values.get(key)?.slice() ?? null;
  }
  async put(key, bytes) {
    if (!(bytes instanceof Uint8Array) || bytes.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    const used = this.#usedBytes - (this.#values.get(key)?.byteLength ?? 0) + bytes.byteLength;
    if (used > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    this.#values.set(key, Uint8Array.from(bytes));
    this.#usedBytes = used;
    this.#recordChange(key, false);
  }
  async putMany(entries) {
    if (entries.length === 0) return;
    const staged = /* @__PURE__ */ new Map();
    for (const entry of entries) {
      if (!(entry.value instanceof Uint8Array) || entry.value.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
      staged.set(entry.key, Uint8Array.from(entry.value));
    }
    let used = this.#usedBytes;
    for (const [key, value] of staged) used = used - (this.#values.get(key)?.byteLength ?? 0) + value.byteLength;
    if (used > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    for (const [key, value] of staged) {
      this.#values.set(key, value);
      this.#recordChange(key, false);
    }
    this.#usedBytes = used;
  }
  async delete(key) {
    if (this.#values.has(key)) {
      this.#usedBytes -= this.#values.get(key)?.byteLength ?? 0;
      this.#values.delete(key);
      this.#recordChange(key, true);
    }
  }
  async deleteMany(keys) {
    for (const key of keys) {
      if (this.#values.has(key)) {
        this.#usedBytes -= this.#values.get(key)?.byteLength ?? 0;
        this.#values.delete(key);
        this.#recordChange(key, true);
      }
    }
  }
  async putAllIfEmpty(entries) {
    const captured = entries.map((entry) => ({ key: entry.key, value: Uint8Array.from(entry.value) }));
    if (new Set(captured.map((entry) => entry.key)).size !== captured.length) throw new Error("BYTES_STORE_DUPLICATE_KEY");
    if (captured.some((entry) => entry.value.byteLength > this.#maxValueBytes)) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    const bytes = captured.reduce((sum, entry) => sum + entry.value.byteLength, 0);
    if (bytes > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    if (this.#values.size !== 0) return false;
    for (const entry of captured) {
      this.#values.set(entry.key, entry.value);
      this.#recordChange(entry.key, false);
    }
    this.#usedBytes = bytes;
    return true;
  }
  async *iterateEntries() {
    const snapshot = [...this.#values].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    for (const [key, value] of snapshot) yield { key, value: value.slice() };
  }
  async *iteratePrefix(prefix) {
    const snapshot = [...this.#values].filter(([k]) => k.startsWith(prefix)).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    for (const [key, value] of snapshot) yield { key, value: value.slice() };
  }
  async latestChangeSeq() {
    return this.#seq;
  }
  async readChangesSince(afterSeq) {
    return {
      latestSeq: this.#seq,
      changes: this.#changelog.filter((c) => c.seq > afterSeq)
    };
  }
  async putStreamIfEmpty(entries) {
    if (this.#values.size !== 0) return false;
    const staged = /* @__PURE__ */ new Map();
    let bytes = 0;
    for await (const entry of entries) {
      if (staged.has(entry.key)) throw new Error("BYTES_STORE_DUPLICATE_KEY");
      if (!(entry.value instanceof Uint8Array) || entry.value.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
      bytes += entry.value.length;
      if (bytes > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
      staged.set(entry.key, Uint8Array.from(entry.value));
    }
    if (this.#values.size !== 0) return false;
    for (const [key, value] of staged) {
      this.#values.set(key, value);
      this.#recordChange(key, false);
    }
    this.#usedBytes = bytes;
    return true;
  }
  async entries() {
    return [...this.#values.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, value]) => ({ key, value: value.slice() }));
  }
};
async function writeBytesMany(store, entries, options) {
  if (entries.length === 0) return;
  if (entries.length === 1) {
    await store.put(entries[0].key, entries[0].value, options);
    return;
  }
  if (store.putMany !== void 0) {
    await store.putMany(entries, options);
    return;
  }
  for (const entry of entries) await store.put(entry.key, entry.value, options);
}
async function deleteBytesMany(store, keys, options) {
  if (keys.length === 0) return;
  if (store.deleteMany !== void 0) {
    await store.deleteMany(keys, options);
    return;
  }
  if (store.delete === void 0) return;
  for (const key of keys) await store.delete(key, options);
}

// packages/records/src/cas.ts
init_src();
var HEX32 = /^[0-9a-f]{64}$/u;
function assertHashHex(hash) {
  if (!HEX32.test(hash)) throw new Error(`CAS_HASH_INVALID: ${hash}`);
}
function encodeCasNode(bytes, links = []) {
  const unique = [...new Set(links)].sort();
  for (const hash of unique) assertHashHex(hash);
  const linkBytes = unique.map((h) => hexToBytes(h));
  return encodeCanonicalCbor([bytes, linkBytes]);
}
function decodeCasNode(encoded) {
  const decoded = assertCanonicalCbor(encoded, DEFAULT_DECODE_LIMITS);
  if (!Array.isArray(decoded) || decoded.length !== 2) throw new Error("CAS_NODE_INVALID");
  const [bytes, rawLinks] = decoded;
  if (!(bytes instanceof Uint8Array) || !Array.isArray(rawLinks)) throw new Error("CAS_NODE_INVALID");
  const links = [];
  for (const item of rawLinks) {
    if (!(item instanceof Uint8Array) || item.length !== 32) throw new Error("CAS_NODE_LINK_INVALID");
    links.push(bytesToHex(item));
  }
  return { bytes: bytes.slice(), links };
}
function decodeCasNodeTrusted(encoded) {
  const decoded = decodeCanonicalCbor(encoded, DEFAULT_DECODE_LIMITS);
  if (!Array.isArray(decoded) || decoded.length !== 2) throw new Error("CAS_NODE_INVALID");
  const [bytes, rawLinks] = decoded;
  if (!(bytes instanceof Uint8Array) || !Array.isArray(rawLinks)) throw new Error("CAS_NODE_INVALID");
  const links = [];
  for (const item of rawLinks) {
    if (!(item instanceof Uint8Array) || item.length !== 32) throw new Error("CAS_NODE_LINK_INVALID");
    links.push(bytesToHex(item));
  }
  return { bytes, links };
}
function hashCasNode(encoded) {
  return bytesToHex(hashDomainSync("cas", encoded));
}
function computeCasHash(bytes, links = []) {
  return hashCasNode(encodeCasNode(bytes, links));
}
var ContentAddressedStore = class {
  #store;
  #prefix;
  #maxCacheEntries;
  #maxChunkBytes;
  /** `node` is decoded lazily: nodes preloaded on cold open are only decoded when first read. */
  #cache = /* @__PURE__ */ new Map();
  #staged = /* @__PURE__ */ new Map();
  #known = /* @__PURE__ */ new Map();
  #pinned = /* @__PURE__ */ new Set();
  #inBatch = false;
  constructor(options) {
    this.#store = options.store;
    this.#prefix = options.prefix ?? "cas/";
    this.#maxCacheEntries = options.maxCacheEntries ?? 4096;
    this.#maxChunkBytes = options.maxChunkBytes ?? 4 * 1024 * 1024;
  }
  #key(partition, hash) {
    return `${this.#prefix}${partition === "public" ? "pub" : "priv"}/${hash}`;
  }
  #nodeOf(entry) {
    return entry.node ??= decodeCasNodeTrusted(entry.encoded);
  }
  #touchCache(hash, encoded, node, partition) {
    const existing = this.#cache.get(hash);
    if (existing !== void 0) {
      existing.partitions.add(partition);
      this.#cache.delete(hash);
      this.#cache.set(hash, existing);
      return;
    }
    this.#cache.set(hash, { encoded, node, partitions: /* @__PURE__ */ new Set([partition]) });
    while (this.#cache.size > this.#maxCacheEntries) {
      const oldest = this.#cache.keys().next().value;
      if (oldest === void 0) break;
      this.#cache.delete(oldest);
    }
  }
  /** Preload persisted CAS entries from BytesStore into the in-memory index/cache. */
  async preload() {
    if (this.#store.iteratePrefix !== void 0) {
      for await (const entry of this.#store.iteratePrefix(this.#prefix)) this.indexPersistedEntry(entry);
      return;
    }
    if (this.#store.iterateEntries !== void 0) {
      for await (const entry of this.#store.iterateEntries()) this.indexPersistedEntry(entry);
      return;
    }
    if (this.#store.entries !== void 0) {
      for (const entry of await this.#store.entries()) this.indexPersistedEntry(entry);
    }
  }
  /**
   * Index a single persisted BytesStore entry if it belongs to this CAS prefix.
   * Returns true if the key was a CAS entry (allowing single-pass hydration in ApplicationSession.open).
   */
  indexPersistedEntry(entry, options = {}) {
    if (!entry.key.startsWith(this.#prefix)) return false;
    const rest = entry.key.slice(this.#prefix.length);
    let partition;
    let hash;
    if (rest.startsWith("pub/")) {
      partition = "public";
      hash = rest.slice(4);
    } else if (rest.startsWith("priv/")) {
      partition = "private";
      hash = rest.slice(5);
    } else return true;
    if (!HEX32.test(hash)) return true;
    const verifyHash = options.verifyHash ?? true;
    if (verifyHash) {
      const verifiedHash = hashCasNode(entry.value);
      if (verifiedHash !== hash) throw new Error(`CAS_CORRUPT: ${hash}`);
    }
    const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
    parts.add(partition);
    this.#known.set(hash, parts);
    const shouldPreload = options.preloadCache ?? (partition === "public" || this.#cache.size < this.#maxCacheEntries);
    if (shouldPreload) this.#touchCache(hash, entry.value, null, partition);
    return true;
  }
  /** Begin a staged replay batch: synchronous puts stay in RAM until flushBatch(). */
  beginBatch() {
    if (this.#inBatch) throw new Error("CAS_BATCH_ALREADY_ACTIVE");
    this.#inBatch = true;
  }
  /** Discard all uncommitted staged writes from the active batch. */
  rollbackBatch() {
    this.#staged.clear();
    this.#inBatch = false;
  }
  /** Persist staged chunks (optionally filtered to a reachable set) to BytesStore in one flush. */
  async flushBatch(keepHashes) {
    if (!this.#inBatch) return;
    const entries = [];
    for (const [hash, item] of this.#staged) {
      if (keepHashes !== void 0 && !keepHashes.has(hash)) continue;
      const known = this.#known.get(hash);
      if (known?.has(item.partition)) continue;
      entries.push({ key: this.#key(item.partition, hash), value: item.encoded });
    }
    for (let i = 0; i < entries.length; i += 128) {
      await writeBytesMany(this.#store, entries.slice(i, i + 128), { durability: "relaxed" });
    }
    for (const [hash, item] of this.#staged) {
      if (keepHashes !== void 0 && !keepHashes.has(hash)) continue;
      const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
      parts.add(item.partition);
      this.#known.set(hash, parts);
      this.#touchCache(hash, item.encoded, item.node, item.partition);
    }
    this.#staged.clear();
    this.#inBatch = false;
  }
  /** Synchronous put into staged RAM (or cache) for deterministic reducer execution. */
  putSync(bytes, links = [], partition = "private") {
    if (bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
    const encoded = encodeCasNode(bytes, links);
    const hash = hashCasNode(encoded);
    const node = { bytes: bytes.slice(), links: [...new Set(links)].sort() };
    this.#staged.set(hash, { encoded, node, partition });
    this.#touchCache(hash, encoded, node, partition);
    return hash;
  }
  /** Async durable put (for seeding modules, syncing blobs from peers, or outside a batch). */
  async put(bytes, links = [], partition = "private", options = {}) {
    if (bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
    const encoded = encodeCasNode(bytes, links);
    const hash = hashCasNode(encoded);
    if (!this.#known.get(hash)?.has(partition)) {
      await this.#store.put(this.#key(partition, hash), encoded, { durability: "relaxed" });
      const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
      parts.add(partition);
      this.#known.set(hash, parts);
    }
    if (options.cache !== false) this.#touchCache(hash, encoded, { bytes: bytes.slice(), links: [...new Set(links)].sort() }, partition);
    return hash;
  }
  /**
   * Verify-and-store in one pass: encodes and hashes `bytes` exactly once, rejects with
   * `CAS_HASH_MISMATCH` unless the node hash equals `expectedHash`, then persists it. Bulk content
   * (`cache: false`) is not kept in the synchronous LRU, so large transfers never evict reducer pages.
   */
  async putVerified(expectedHash, bytes, links = [], partition = "private", options = {}) {
    assertHashHex(expectedHash);
    if (bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
    const encoded = encodeCasNode(bytes, links);
    if (hashCasNode(encoded) !== expectedHash) throw new Error("CAS_HASH_MISMATCH");
    if (!this.#known.get(expectedHash)?.has(partition)) {
      await this.#store.put(this.#key(partition, expectedHash), encoded, { durability: "relaxed" });
      const parts = this.#known.get(expectedHash) ?? /* @__PURE__ */ new Set();
      parts.add(partition);
      this.#known.set(expectedHash, parts);
    }
    if (options.cache !== false) this.#touchCache(expectedHash, encoded, { bytes: bytes.slice(), links: [...new Set(links)].sort() }, partition);
  }
  /** Put raw pre-encoded canonical CAS node bytes (verifying digest matches expectedHash). */
  async putRaw(expectedHash, encoded, partition = "private") {
    assertHashHex(expectedHash);
    if (encoded.byteLength > this.#maxChunkBytes + 65536) throw new Error("CAS_CHUNK_TOO_LARGE");
    const actual = hashCasNode(encoded);
    if (actual !== expectedHash) throw new Error(`CAS_HASH_MISMATCH: expected ${expectedHash}, got ${actual}`);
    const node = decodeCasNode(encoded);
    if (!equalBytes(encodeCasNode(node.bytes, node.links), encoded)) throw new Error("CAS_NODE_NOT_CANONICAL");
    await this.#store.put(this.#key(partition, expectedHash), encoded, { durability: "relaxed" });
    const parts = this.#known.get(expectedHash) ?? /* @__PURE__ */ new Set();
    parts.add(partition);
    this.#known.set(expectedHash, parts);
    this.#touchCache(expectedHash, encoded, node, partition);
  }
  /** Batched put for peer/host CAS sync (single putMany per 128 chunks instead of N transactions). */
  async putManyVerified(items) {
    const toWrite = [];
    const stagedMeta = [];
    for (const item of items) {
      if (this.hasSync(item.hash, item.partition)) continue;
      assertHashHex(item.hash);
      let encoded;
      let node;
      if (hashCasNode(item.bytes) === item.hash) {
        if (item.bytes.byteLength > this.#maxChunkBytes + 65536) throw new Error("CAS_CHUNK_TOO_LARGE");
        node = decodeCasNode(item.bytes);
        if (!equalBytes(encodeCasNode(node.bytes, node.links), item.bytes)) throw new Error("CAS_NODE_NOT_CANONICAL");
        encoded = item.bytes.slice();
      } else if (computeCasHash(item.bytes, []) === item.hash) {
        if (item.bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
        encoded = encodeCasNode(item.bytes, []);
        node = { bytes: item.bytes.slice(), links: [] };
      } else {
        throw new Error(`CAS_NODE_HASH_MISMATCH:${item.hash}`);
      }
      toWrite.push({ key: this.#key(item.partition, item.hash), value: encoded });
      stagedMeta.push({ hash: item.hash, encoded, node, partition: item.partition });
    }
    if (toWrite.length === 0) return 0;
    for (let i = 0; i < toWrite.length; i += 128) {
      await writeBytesMany(this.#store, toWrite.slice(i, i + 128), { durability: "relaxed" });
    }
    for (const meta of stagedMeta) {
      const parts = this.#known.get(meta.hash) ?? /* @__PURE__ */ new Set();
      parts.add(meta.partition);
      this.#known.set(meta.hash, parts);
      this.#touchCache(meta.hash, meta.encoded, meta.node, meta.partition);
    }
    return stagedMeta.length;
  }
  /** Fault a known-on-disk CAS node back into the synchronous RAM LRU (demand paging for >16 MiB DBs). */
  async ensureLoaded(hash, allowedPartition = "any") {
    if (!HEX32.test(hash)) return false;
    if (this.getSync(hash, allowedPartition) !== null) return true;
    const loaded = await this.get(hash, allowedPartition);
    return loaded !== null;
  }
  /** Synchronous read from staged RAM + LRU cache (respecting partition visibility). */
  getSync(hash, allowedPartition = "any") {
    assertHashHex(hash);
    const staged = this.#staged.get(hash);
    if (staged !== void 0 && (allowedPartition === "any" || staged.partition === allowedPartition)) {
      return { bytes: staged.node.bytes.slice(), links: [...staged.node.links] };
    }
    const cached = this.#cache.get(hash);
    if (cached !== void 0 && (allowedPartition === "any" || cached.partitions.has(allowedPartition))) {
      this.#cache.delete(hash);
      this.#cache.set(hash, cached);
      const node = this.#nodeOf(cached);
      return { bytes: node.bytes.slice(), links: [...node.links] };
    }
    return null;
  }
  /** Async read checking RAM cache first, then BytesStore (respecting partition visibility). */
  async get(hash, allowedPartition = "any", options = {}) {
    const sync = this.getSync(hash, allowedPartition);
    if (sync !== null) return sync;
    const partitions = allowedPartition === "any" ? ["public", "private"] : [allowedPartition];
    for (const partition of partitions) {
      const raw = await this.#store.get(this.#key(partition, hash));
      if (raw === null) continue;
      if (hashCasNode(raw) !== hash) throw new Error(`CAS_CORRUPT: ${hash}`);
      const node = decodeCasNode(raw);
      const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
      parts.add(partition);
      this.#known.set(hash, parts);
      if (options.cache === false) return node;
      this.#touchCache(hash, raw, node, partition);
      return { bytes: node.bytes.slice(), links: [...node.links] };
    }
    return null;
  }
  /** Get raw canonical node bytes for peer replication. */
  async getRaw(hash, allowedPartition = "any") {
    assertHashHex(hash);
    const staged = this.#staged.get(hash);
    if (staged !== void 0 && (allowedPartition === "any" || staged.partition === allowedPartition)) {
      return staged.encoded.slice();
    }
    const cached = this.#cache.get(hash);
    if (cached !== void 0 && (allowedPartition === "any" || cached.partitions.has(allowedPartition))) {
      return cached.encoded.slice();
    }
    const partitions = allowedPartition === "any" ? ["public", "private"] : [allowedPartition];
    for (const partition of partitions) {
      const raw = await this.#store.get(this.#key(partition, hash));
      if (raw !== null) return raw;
    }
    return null;
  }
  hasSync(hash, allowedPartition = "any") {
    if (!HEX32.test(hash)) return false;
    const staged = this.#staged.get(hash);
    if (staged !== void 0 && (allowedPartition === "any" || staged.partition === allowedPartition)) return true;
    const cached = this.#cache.get(hash);
    if (cached !== void 0 && (allowedPartition === "any" || cached.partitions.has(allowedPartition))) return true;
    const known = this.#known.get(hash);
    if (known !== void 0 && (allowedPartition === "any" || known.has(allowedPartition))) return true;
    return false;
  }
  /** Walk all explicit DAG links reachable from rootHashes (in RAM or durable store). */
  async reachable(rootHashes) {
    const visited = /* @__PURE__ */ new Set();
    const queue = [];
    for (const hash of rootHashes) {
      if (HEX32.test(hash) && !visited.has(hash)) {
        visited.add(hash);
        queue.push(hash);
      }
    }
    while (queue.length > 0) {
      const current = queue.pop();
      const node = await this.get(current, "any");
      if (node === null) continue;
      for (const link of node.links) {
        if (!visited.has(link)) {
          visited.add(link);
          queue.push(link);
        }
      }
    }
    return visited;
  }
  /** Pin a CAS root hash locally so mark-and-sweep GC preserves it and its transitive links. */
  pin(hash) {
    assertHashHex(hash);
    this.#pinned.add(hash);
  }
  /** Remove a local pin from a CAS root hash. */
  unpin(hash) {
    this.#pinned.delete(hash);
  }
  isPinned(hash) {
    return this.#pinned.has(hash);
  }
  pinnedHashes() {
    return [...this.#pinned].sort();
  }
  /**
   * Collect a bounded CAS subgraph reachable from rootHashes for single-round-trip peer replication.
   * Respects partition visibility (e.g. 'public' for unprivileged peers / blind hosts).
   */
  async collectSubgraph(rootHashes, options = {}) {
    const allowed = options.allowedPartition ?? "any";
    const maxNodes = options.maxNodes ?? 256;
    const maxBytes = options.maxBytes ?? 8 * 1024 * 1024;
    const visited = /* @__PURE__ */ new Set();
    const queue = [];
    for (const hash of rootHashes) {
      if (HEX32.test(hash) && !visited.has(hash)) {
        visited.add(hash);
        queue.push(hash);
      }
    }
    const out = [];
    let totalBytes = 0;
    while (queue.length > 0 && out.length < maxNodes) {
      const current = queue.shift();
      const partitions = allowed === "any" ? ["public", "private"] : [allowed];
      let chosenPartition = null;
      let raw = null;
      for (const p of partitions) {
        const candidate = await this.getRaw(current, p);
        if (candidate !== null) {
          chosenPartition = p;
          raw = candidate;
          break;
        }
      }
      if (raw === null || chosenPartition === null) continue;
      if (out.length > 0 && totalBytes + raw.byteLength > maxBytes) break;
      out.push({ hash: current, bytes: raw, partition: chosenPartition });
      totalBytes += raw.byteLength;
      const node = decodeCasNode(raw);
      for (const link of node.links) {
        if (!visited.has(link)) {
          visited.add(link);
          queue.push(link);
        }
      }
    }
    return out;
  }
  /** Delete specific unpinned CAS nodes from a partition (used for lazy-bulk LRU cache eviction). */
  async deleteNodes(hashes2, partition) {
    if (this.#inBatch) throw new Error("CAS_DELETE_DURING_BATCH");
    const keys = [];
    const dropped = [];
    for (const hash of hashes2) {
      if (!HEX32.test(hash) || this.#pinned.has(hash)) continue;
      const parts = this.#known.get(hash);
      if (parts !== void 0 && parts.has(partition)) {
        keys.push(this.#key(partition, hash));
        dropped.push(hash);
      }
    }
    if (keys.length === 0) return 0;
    for (let i = 0; i < keys.length; i += 32) {
      await deleteBytesMany(this.#store, keys.slice(i, i + 32), { durability: "relaxed" });
    }
    for (const hash of dropped) {
      const parts = this.#known.get(hash);
      if (parts !== void 0) {
        parts.delete(partition);
        if (parts.size === 0) this.#known.delete(hash);
      }
      const cached = this.#cache.get(hash);
      if (cached !== void 0) {
        cached.partitions.delete(partition);
        if (cached.partitions.size === 0) this.#cache.delete(hash);
      }
    }
    return dropped.length;
  }
  /** Exact local mark-and-sweep GC preserving everything reachable from rootHashes + pinned roots, deleting in yielding batches. */
  async collectGarbage(rootHashes) {
    if (this.#inBatch) throw new Error("CAS_GC_DURING_BATCH");
    const allRoots = new Set(this.#pinned);
    for (const h of rootHashes) allRoots.add(h);
    const keep = await this.reachable(allRoots);
    const keysToDelete = [];
    const hashesToDrop = [];
    for (const [hash, partitions] of [...this.#known.entries()]) {
      if (keep.has(hash)) continue;
      for (const partition of partitions) {
        keysToDelete.push(this.#key(partition, hash));
      }
      hashesToDrop.push(hash);
    }
    for (let i = 0; i < keysToDelete.length; i += 32) {
      await deleteBytesMany(this.#store, keysToDelete.slice(i, i + 32), { durability: "relaxed" });
      if (i + 32 < keysToDelete.length) {
        await new Promise((resolve2) => setTimeout(resolve2, 0));
      }
    }
    for (const hash of hashesToDrop) {
      this.#known.delete(hash);
      this.#cache.delete(hash);
    }
    return { kept: keep.size, deleted: keysToDelete.length };
  }
  listKnownHashes(partition) {
    const out = /* @__PURE__ */ new Set();
    for (const [hash, parts] of this.#known) {
      if (partition === void 0 || parts.has(partition)) out.add(hash);
    }
    for (const [hash, item] of this.#staged) {
      if (partition === void 0 || item.partition === partition) out.add(hash);
    }
    return [...out].sort();
  }
};

// packages/records/src/cas-objects.ts
init_src();
var HEX322 = /^[0-9a-f]{64}$/u;
var CAS_REF_RE = /^cas:sha256-([0-9a-f]{64})$/u;
var CAS_BLOB_CHUNK_BYTES = 65536;
var CAS_BLOB_FANOUT = 64;
var ALLOWED_BUILTINS = /* @__PURE__ */ new Set([
  "chronolog:crypto",
  "chronolog:cas",
  "chronolog:sqlite",
  "chronolog:wasm"
]);
function casRef(hash) {
  if (!HEX322.test(hash)) throw new Error(`CAS_HASH_INVALID:${hash}`);
  return `cas:sha256-${hash}`;
}
function parseCasRef(ref) {
  const match = CAS_REF_RE.exec(ref);
  if (match === null) throw new Error(`CAS_REF_INVALID:${ref}`);
  return match[1];
}
function tryParseCasRef(ref) {
  const match = CAS_REF_RE.exec(ref);
  return match === null ? null : match[1];
}
function normalizePosixPath(input) {
  if (typeof input !== "string" || input.length === 0 || input.length > 512) {
    throw new Error(`CAS_PATH_INVALID:${String(input)}`);
  }
  const normalized = input.replaceAll("\\", "/").replace(/^\.\//u, "");
  if (normalized.startsWith("/") || normalized.endsWith("/") || normalized.includes("\0")) {
    throw new Error(`CAS_PATH_INVALID:${input}`);
  }
  const parts = normalized.split("/");
  for (const part of parts) {
    if (part.length === 0 || part === "." || part === "..") {
      throw new Error(`CAS_PATH_INVALID:${input}`);
    }
  }
  return parts.join("/");
}
function unknownToCbor(value, depth = 0) {
  if (depth > 32) throw new Error("CAS_OBJECT_TOO_DEEP");
  if (value === null || typeof value === "boolean" || typeof value === "string") return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new Error("CAS_OBJECT_NON_FINITE_NUMBER");
    if (Number.isSafeInteger(value)) return BigInt(Object.is(value, -0) ? 0 : value);
    return /* @__PURE__ */ new Map([["$f", JSON.stringify(value)]]);
  }
  if (value instanceof Uint8Array) return value;
  if (Array.isArray(value)) return value.map((item) => unknownToCbor(item, depth + 1));
  if (typeof value === "object") {
    const rec = value;
    const map = /* @__PURE__ */ new Map();
    for (const k of Object.keys(rec).sort()) {
      const v = rec[k];
      if (v !== void 0) map.set(k, unknownToCbor(v, depth + 1));
    }
    return map;
  }
  throw new Error("CAS_OBJECT_UNSUPPORTED_VALUE");
}
function encodeBlobTreeNode(node) {
  const childArr = node.children.map((c) => [c.hash, BigInt(c.bytes)]);
  const bytes = encodeCanonicalCbor(/* @__PURE__ */ new Map([
    ["bytes", BigInt(node.bytes)],
    ["children", childArr],
    ["format", "chronolog-blob/v1"]
  ]));
  const links = [...new Set(node.children.map((c) => c.hash))].sort();
  return { bytes, links };
}
async function putBlobDag(cas, bytes, partition = "public") {
  if (bytes.byteLength <= CAS_BLOB_CHUNK_BYTES) {
    const hash = await cas.put(bytes, [], partition);
    return { hash, bytes: bytes.byteLength };
  }
  let level = [];
  for (let offset = 0; offset < bytes.byteLength; offset += CAS_BLOB_CHUNK_BYTES) {
    const slice = bytes.subarray(offset, Math.min(bytes.byteLength, offset + CAS_BLOB_CHUNK_BYTES));
    const hash = await cas.put(slice, [], partition);
    level.push({ hash, bytes: slice.byteLength });
  }
  while (level.length > 1) {
    const nextLevel = [];
    for (let i = 0; i < level.length; i += CAS_BLOB_FANOUT) {
      const group = level.slice(i, i + CAS_BLOB_FANOUT);
      const total = group.reduce((acc, item) => acc + item.bytes, 0);
      const encoded = encodeBlobTreeNode({ format: "chronolog-blob/v1", bytes: total, children: group });
      const hash = await cas.put(encoded.bytes, encoded.links, partition);
      nextLevel.push({ hash, bytes: total });
    }
    level = nextLevel;
  }
  return { hash: level[0].hash, bytes: bytes.byteLength };
}
function assertValidPackageNode(pkg) {
  if (pkg.format !== "chronolog-pkg/v1") throw new Error("PKG_FORMAT_INVALID");
  if (pkg.runtime !== "esm-quickjs" && pkg.runtime !== "wasm-pure" && pkg.runtime !== "hybrid") {
    throw new Error(`PKG_RUNTIME_INVALID:${String(pkg.runtime)}`);
  }
  if (pkg.name !== void 0 && (typeof pkg.name !== "string" || pkg.name.length === 0 || pkg.name.length > 256)) {
    throw new Error("PKG_NAME_INVALID");
  }
  if (pkg.version !== void 0 && (typeof pkg.version !== "string" || pkg.version.length === 0 || pkg.version.length > 128)) {
    throw new Error("PKG_VERSION_INVALID");
  }
  const files = {};
  for (const [rawPath, ref] of Object.entries(pkg.files).sort(([a], [b]) => a.localeCompare(b))) {
    const path = normalizePosixPath(rawPath);
    files[path] = casRef(parseCasRef(ref));
  }
  if (Object.keys(files).length === 0) throw new Error("PKG_FILES_EMPTY");
  const exportsMap = {};
  for (const [subpath, target] of Object.entries(pkg.exports).sort(([a], [b]) => a.localeCompare(b))) {
    if (subpath !== "." && !subpath.startsWith("./")) throw new Error(`PKG_EXPORT_SUBPATH_INVALID:${subpath}`);
    const normTarget = normalizePosixPath(target);
    if (!Object.hasOwn(files, normTarget)) throw new Error(`PKG_EXPORT_MISSING_FILE:${subpath}:${normTarget}`);
    exportsMap[subpath] = normTarget;
  }
  if (pkg.runtime !== "wasm-pure" && Object.keys(exportsMap).length === 0) {
    throw new Error("PKG_EXPORTS_EMPTY");
  }
  const dependencies = {};
  for (const [spec, ref] of Object.entries(pkg.dependencies).sort(([a], [b]) => a.localeCompare(b))) {
    if (typeof spec !== "string" || spec.length === 0 || spec.length > 256 || spec.startsWith(".") || spec.startsWith("/")) {
      throw new Error(`PKG_DEPENDENCY_SPEC_INVALID:${spec}`);
    }
    dependencies[spec] = casRef(parseCasRef(ref));
  }
  const builtinsSet = /* @__PURE__ */ new Set();
  for (const b of pkg.builtins) {
    if (!ALLOWED_BUILTINS.has(b)) throw new Error(`PKG_BUILTIN_INVALID:${String(b)}`);
    builtinsSet.add(b);
  }
  const builtins = [...builtinsSet].sort();
  let wasm;
  if (pkg.wasm !== void 0) {
    const entry = normalizePosixPath(pkg.wasm.entry);
    if (!Object.hasOwn(files, entry)) throw new Error(`PKG_WASM_ENTRY_MISSING:${entry}`);
    if (pkg.wasm.abi !== "chronolog-wasm/v1") throw new Error(`PKG_WASM_ABI_INVALID:${String(pkg.wasm.abi)}`);
    wasm = { entry, abi: "chronolog-wasm/v1" };
  } else if (pkg.runtime === "wasm-pure") {
    throw new Error("PKG_WASM_ENTRY_REQUIRED");
  }
  const derivation = pkg.derivation === void 0 ? void 0 : casRef(parseCasRef(pkg.derivation));
  return {
    format: "chronolog-pkg/v1",
    ...pkg.name === void 0 ? {} : { name: pkg.name },
    ...pkg.version === void 0 ? {} : { version: pkg.version },
    runtime: pkg.runtime,
    files,
    exports: exportsMap,
    dependencies,
    builtins,
    ...wasm === void 0 ? {} : { wasm },
    ...derivation === void 0 ? {} : { derivation }
  };
}
function encodePackageNode(pkg) {
  const clean2 = assertValidPackageNode(pkg);
  const linkSet = /* @__PURE__ */ new Set();
  const filesMap = /* @__PURE__ */ new Map();
  for (const [p, ref] of Object.entries(clean2.files)) {
    filesMap.set(p, ref);
    linkSet.add(parseCasRef(ref));
  }
  const exportsMap = /* @__PURE__ */ new Map();
  for (const [k, v] of Object.entries(clean2.exports)) exportsMap.set(k, v);
  const depsMap = /* @__PURE__ */ new Map();
  for (const [k, ref] of Object.entries(clean2.dependencies)) {
    depsMap.set(k, ref);
    linkSet.add(parseCasRef(ref));
  }
  const map = /* @__PURE__ */ new Map([
    ["builtins", [...clean2.builtins]],
    ["dependencies", depsMap],
    ["exports", exportsMap],
    ["files", filesMap],
    ["format", "chronolog-pkg/v1"],
    ["runtime", clean2.runtime]
  ]);
  if (clean2.name !== void 0) map.set("name", clean2.name);
  if (clean2.version !== void 0) map.set("version", clean2.version);
  if (clean2.wasm !== void 0) {
    map.set("wasm", /* @__PURE__ */ new Map([
      ["abi", clean2.wasm.abi],
      ["entry", clean2.wasm.entry]
    ]));
  }
  if (clean2.derivation !== void 0) map.set("derivation", clean2.derivation);
  return { bytes: encodeCanonicalCbor(map), links: [...linkSet].sort() };
}
async function putPackageDag(cas, input, partition = "public") {
  const fileRefs = {};
  const enc = new TextEncoder();
  for (const [rawPath, content] of Object.entries(input.files).sort(([a], [b]) => a.localeCompare(b))) {
    const path = normalizePosixPath(rawPath);
    const bytes = typeof content === "string" ? enc.encode(content) : content;
    const stored = await putBlobDag(cas, bytes, partition);
    fileRefs[path] = casRef(stored.hash);
  }
  const runtime = input.runtime ?? (input.wasm !== void 0 && Object.keys(fileRefs).length === 1 ? "wasm-pure" : "esm-quickjs");
  const firstFile = Object.keys(fileRefs).sort()[0];
  const exportsMap = input.exports ?? (runtime === "wasm-pure" ? {} : firstFile === void 0 ? {} : { ".": firstFile });
  const manifest = assertValidPackageNode({
    format: "chronolog-pkg/v1",
    ...input.name === void 0 ? {} : { name: input.name },
    ...input.version === void 0 ? {} : { version: input.version },
    runtime,
    files: fileRefs,
    exports: exportsMap,
    dependencies: input.dependencies ?? {},
    builtins: input.builtins ?? [],
    ...input.wasm === void 0 ? {} : { wasm: input.wasm },
    ...input.derivation === void 0 ? {} : { derivation: input.derivation }
  });
  const encoded = encodePackageNode(manifest);
  const hash = await cas.put(encoded.bytes, encoded.links, partition);
  return { hash, ref: casRef(hash), manifest };
}
function encodeTreeNode(tree) {
  if (tree.format !== "chronolog-tree/v1") throw new Error("TREE_FORMAT_INVALID");
  const entriesMap = /* @__PURE__ */ new Map();
  const linkSet = /* @__PURE__ */ new Set();
  for (const [rawPath, ref] of Object.entries(tree.entries).sort(([a], [b]) => a.localeCompare(b))) {
    const path = normalizePosixPath(rawPath);
    const hash = parseCasRef(ref);
    entriesMap.set(path, casRef(hash));
    linkSet.add(hash);
  }
  const map = /* @__PURE__ */ new Map([
    ["entries", entriesMap],
    ["format", "chronolog-tree/v1"]
  ]);
  return { bytes: encodeCanonicalCbor(map), links: [...linkSet].sort() };
}
async function putTreeDag(cas, files, partition = "public") {
  const entries = {};
  const enc = new TextEncoder();
  for (const [rawPath, content] of Object.entries(files).sort(([a], [b]) => a.localeCompare(b))) {
    const path = normalizePosixPath(rawPath);
    const bytes = typeof content === "string" ? enc.encode(content) : content;
    const stored = await putBlobDag(cas, bytes, partition);
    entries[path] = casRef(stored.hash);
  }
  const tree = { format: "chronolog-tree/v1", entries };
  const encoded = encodeTreeNode(tree);
  const hash = await cas.put(encoded.bytes, encoded.links, partition);
  return { hash, ref: casRef(hash), tree };
}
function assertValidDerivationNode(drv) {
  if (drv.format !== "chronolog-drv/v1") throw new Error("DRV_FORMAT_INVALID");
  if (drv.profile !== "quickjs-inline" && drv.profile !== "wasi-cas-v1") {
    throw new Error(`DRV_PROFILE_INVALID:${String(drv.profile)}`);
  }
  const builder = casRef(parseCasRef(drv.builder));
  const inputs = {};
  for (const [k, ref] of Object.entries(drv.inputs).sort(([a], [b]) => a.localeCompare(b))) {
    if (typeof k !== "string" || k.length === 0 || k.length > 256) throw new Error(`DRV_INPUT_KEY_INVALID:${k}`);
    inputs[k] = casRef(parseCasRef(ref));
  }
  if (drv.args === null || typeof drv.args !== "object" || Array.isArray(drv.args)) {
    throw new Error("DRV_ARGS_INVALID");
  }
  if (!Number.isSafeInteger(drv.limits.maxMemoryBytes) || drv.limits.maxMemoryBytes <= 0 || !Number.isSafeInteger(drv.limits.maxFuel) || drv.limits.maxFuel <= 0) {
    throw new Error("DRV_LIMITS_INVALID");
  }
  return {
    format: "chronolog-drv/v1",
    profile: drv.profile,
    builder,
    inputs,
    args: drv.args,
    limits: {
      maxMemoryBytes: drv.limits.maxMemoryBytes,
      maxFuel: drv.limits.maxFuel
    }
  };
}
function encodeDerivationNode(drv) {
  const clean2 = assertValidDerivationNode(drv);
  const linkSet = /* @__PURE__ */ new Set([parseCasRef(clean2.builder)]);
  const inputsMap = /* @__PURE__ */ new Map();
  for (const [k, ref] of Object.entries(clean2.inputs)) {
    inputsMap.set(k, ref);
    linkSet.add(parseCasRef(ref));
  }
  const map = /* @__PURE__ */ new Map([
    ["args", unknownToCbor(clean2.args)],
    ["builder", clean2.builder],
    ["format", "chronolog-drv/v1"],
    ["inputs", inputsMap],
    ["limits", /* @__PURE__ */ new Map([
      ["maxFuel", BigInt(clean2.limits.maxFuel)],
      ["maxMemoryBytes", BigInt(clean2.limits.maxMemoryBytes)]
    ])],
    ["profile", clean2.profile]
  ]);
  return { bytes: encodeCanonicalCbor(map), links: [...linkSet].sort() };
}
async function putDerivationNode(cas, drv, partition = "public") {
  const clean2 = assertValidDerivationNode(drv);
  const encoded = encodeDerivationNode(clean2);
  const hash = await cas.put(encoded.bytes, encoded.links, partition);
  return { hash, ref: casRef(hash), derivation: clean2 };
}

// packages/records/src/live-channel.ts
var PEER_LIVE_MESSAGE_LIMITS = Object.freeze({ frameBytes: 16448, queueFrames: 64, bufferedBytes: 65536 });

// packages/records/src/message-channel.ts
var PEER_MESSAGE_LIMITS = Object.freeze({
  frameBytes: 1048576 + 65536,
  packetBytes: 16 * 1024,
  queueBytes: 4 * 1024 * 1024,
  queueFrames: 16,
  bufferedBytes: 256 * 1024
});

// packages/pack/src/tarball.ts
function readCString(buf, start, len) {
  let end = start;
  const max = start + len;
  while (end < max && buf[end] !== 0) end++;
  return new TextDecoder().decode(buf.subarray(start, end));
}
function parseOctal(buf, start, len) {
  const str = readCString(buf, start, len).trim();
  if (str.length === 0) return 0;
  return Number.parseInt(str, 8);
}
function parseCanonicalTarball(archiveBytes, options = {}) {
  if (options.integrity !== void 0) {
    const match = /^(sha512|sha256)-(.+)$/u.exec(options.integrity);
    if (match === null) throw new Error(`TARBALL_INTEGRITY_FORMAT_INVALID:${options.integrity}`);
    const algo = match[1];
    const expected = match[2];
    const actualBase64 = createHash(algo).update(archiveBytes).digest("base64");
    const actualHex = createHash(algo).update(archiveBytes).digest("hex");
    if (actualBase64 !== expected && actualHex !== expected) {
      throw new Error(`TARBALL_INTEGRITY_MISMATCH: expected ${options.integrity}`);
    }
  }
  const tar = archiveBytes.byteLength >= 2 && archiveBytes[0] === 31 && archiveBytes[1] === 139 ? new Uint8Array(gunzipSync(archiveBytes)) : archiveBytes;
  const stripPrefix = options.stripPrefix ?? "package/";
  const entries = /* @__PURE__ */ new Map();
  let offset = 0;
  let paxPath = null;
  while (offset + 512 <= tar.byteLength) {
    const header = tar.subarray(offset, offset + 512);
    let allZero = true;
    for (let i = 0; i < 512; i++) {
      if (header[i] !== 0) {
        allZero = false;
        break;
      }
    }
    if (allZero) break;
    const name = readCString(header, 0, 100);
    const prefix = readCString(header, 345, 155);
    const size = parseOctal(header, 124, 12);
    const typeFlag = header[156] ?? 0;
    const dataStart = offset + 512;
    const dataEnd = dataStart + size;
    if (dataEnd > tar.byteLength) throw new Error("TARBALL_TRUNCATED");
    const data = tar.subarray(dataStart, dataEnd);
    offset = dataStart + Math.ceil(size / 512) * 512;
    if (typeFlag === 120) {
      const text = new TextDecoder().decode(data);
      for (const line of text.split("\n")) {
        const sp = line.indexOf(" ");
        if (sp > 0) {
          const kv = line.slice(sp + 1);
          if (kv.startsWith("path=")) paxPath = kv.slice(5);
        }
      }
      continue;
    }
    if (typeFlag === 76) {
      paxPath = new TextDecoder().decode(data).replace(/\0+$/u, "");
      continue;
    }
    let fullPath = paxPath ?? (prefix.length > 0 ? `${prefix}/${name}` : name);
    paxPath = null;
    if (typeFlag !== 48 && typeFlag !== 0) continue;
    fullPath = fullPath.replace(/^\.\//u, "");
    if (stripPrefix.length > 0 && fullPath.startsWith(stripPrefix)) {
      fullPath = fullPath.slice(stripPrefix.length);
    }
    if (fullPath.length === 0) continue;
    const norm = normalizePosixPath(fullPath);
    entries.set(norm, data.slice());
  }
  return [...entries.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([path, bytes]) => ({ path, bytes }));
}
async function ingestTarballToCas(cas, archiveBytes, options = {}) {
  const entries = parseCanonicalTarball(archiveBytes, options);
  const files = {};
  for (const e of entries) files[e.path] = e.bytes;
  const placed = await putTreeDag(cas, files, options.partition ?? "public");
  return { ...placed, fileCount: entries.length };
}
function createDeterministicTar(files, prefix = "package/") {
  const enc = new TextEncoder();
  const blocks = [];
  for (const [rawPath, content] of Object.entries(files).sort(([a], [b]) => a.localeCompare(b))) {
    const fullPath = `${prefix}${normalizePosixPath(rawPath)}`;
    const data = typeof content === "string" ? enc.encode(content) : content;
    const header = new Uint8Array(512);
    header.set(enc.encode(fullPath.slice(0, 100)), 0);
    header.set(enc.encode("0000644\0"), 100);
    header.set(enc.encode("0000000\0"), 108);
    header.set(enc.encode("0000000\0"), 116);
    header.set(enc.encode(`${data.byteLength.toString(8).padStart(11, "0")}\0`), 124);
    header.set(enc.encode("00000000000\0"), 136);
    header.fill(32, 148, 156);
    header[156] = 48;
    header.set(enc.encode("ustar\0"), 257);
    header.set(enc.encode("00"), 263);
    let sum = 0;
    for (let i = 0; i < 512; i++) sum += header[i];
    header.set(enc.encode(`${sum.toString(8).padStart(6, "0")}\0 `), 148);
    blocks.push(header);
    if (data.byteLength > 0) {
      const padded = new Uint8Array(Math.ceil(data.byteLength / 512) * 512);
      padded.set(data, 0);
      blocks.push(padded);
    }
  }
  blocks.push(new Uint8Array(1024));
  const total = blocks.reduce((acc, b) => acc + b.byteLength, 0);
  const out = new Uint8Array(total);
  let pos = 0;
  for (const b of blocks) {
    out.set(b, pos);
    pos += b.byteLength;
  }
  return out;
}

// packages/pack/src/lockfile.ts
function createLockfile(packages) {
  const sorted = {};
  for (const alias of Object.keys(packages).sort()) {
    const entry = packages[alias];
    parseCasRef(entry.pkgRef);
    if (entry.drvRef !== void 0) parseCasRef(entry.drvRef);
    const deps = {};
    for (const k of Object.keys(entry.dependencies).sort()) {
      parseCasRef(entry.dependencies[k]);
      deps[k] = entry.dependencies[k];
    }
    sorted[alias] = {
      pkgRef: entry.pkgRef,
      ...entry.drvRef === void 0 ? {} : { drvRef: entry.drvRef },
      runtime: entry.runtime,
      builtins: [...new Set(entry.builtins)].sort(),
      dependencies: deps,
      ...entry.integrity === void 0 ? {} : { integrity: entry.integrity }
    };
  }
  return { format: "chronolog-lock/v1", packages: sorted };
}
function formatLockfile(lockfile) {
  return `${JSON.stringify(createLockfile(lockfile.packages), null, 2)}
`;
}
function parseLockfile(raw) {
  const parsed = JSON.parse(raw);
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error("LOCKFILE_INVALID");
  }
  const obj = parsed;
  if (obj.format !== "chronolog-lock/v1" || obj.packages === null || typeof obj.packages !== "object" || Array.isArray(obj.packages)) {
    throw new Error("LOCKFILE_INVALID");
  }
  return createLockfile(obj.packages);
}

// packages/pack/src/packer.ts
init_src();
import { readFile } from "node:fs/promises";
import { dirname, isAbsolute, resolve } from "node:path";
import { build as esbuildBuild } from "esbuild";
var ESBUILD_BUILDER_ID = "esbuild-neutral-esm@0.28.2";
var ESBUILD_BUILDER_REF = casRef(computeCasHash(utf8(`chronolog-builder:${ESBUILD_BUILDER_ID}`), []));
var STANDARD_EXTERNALS = [
  "chronolog:crypto",
  "chronolog:cas",
  "chronolog:sqlite",
  "chronolog:wasm",
  "chronolog/*",
  "node:*"
];
async function bundleSingleEntry(entry, cwd, extraExternal) {
  const external = [
    ...STANDARD_EXTERNALS,
    ...Object.keys(entry.dependencies ?? {}),
    ...extraExternal
  ];
  const shouldBundle = entry.bundle !== false;
  if (!shouldBundle && entry.files !== void 0) {
    const compiledFiles = {};
    const sourceFiles = {};
    let defaultExportFile;
    for (const [rawPath, src] of Object.entries(entry.files).sort(([a], [b]) => a.localeCompare(b))) {
      const norm = normalizePosixPath(rawPath);
      sourceFiles[norm] = src;
      const outPath = norm.replace(/\.tsx?$/u, ".js");
      if (defaultExportFile === void 0 || outPath === "index.js") defaultExportFile = outPath;
      const res2 = await esbuildBuild({
        stdin: {
          contents: src,
          loader: norm.endsWith(".ts") ? "ts" : norm.endsWith(".tsx") ? "tsx" : "js",
          sourcefile: norm,
          resolveDir: cwd
        },
        bundle: false,
        write: false,
        format: "esm",
        target: "es2022",
        charset: "utf8",
        legalComments: "none"
      });
      compiledFiles[outPath] = res2.outputFiles[0].text;
    }
    return {
      compiledFiles,
      sourceFiles,
      exportsMap: defaultExportFile === void 0 ? {} : { ".": defaultExportFile }
    };
  }
  if (entry.source !== void 0 || entry.files !== void 0) {
    const virtualFiles = /* @__PURE__ */ new Map();
    const sourceFiles = {};
    if (entry.files !== void 0) {
      for (const [rawPath, src] of Object.entries(entry.files).sort(([a], [b]) => a.localeCompare(b))) {
        const norm = normalizePosixPath(rawPath);
        virtualFiles.set(norm, src);
        sourceFiles[norm] = src;
      }
    }
    const entryName = entry.path !== void 0 ? normalizePosixPath(entry.path) : "index.ts";
    if (entry.source !== void 0) {
      virtualFiles.set(entryName, entry.source);
      sourceFiles[entryName] = entry.source;
    }
    const entryCode = virtualFiles.get(entryName) ?? virtualFiles.values().next().value;
    if (entryCode === void 0) throw new Error("PACK_ENTRY_EMPTY");
    const res2 = await esbuildBuild({
      stdin: {
        contents: entryCode,
        loader: entryName.endsWith(".ts") ? "ts" : entryName.endsWith(".tsx") ? "tsx" : "js",
        sourcefile: entryName,
        resolveDir: cwd
      },
      plugins: [{
        name: "chronolog-virtual-fs",
        setup(build) {
          build.onResolve({ filter: /^\.\.?\// }, (args) => {
            if (args.importer && !isAbsolute(args.importer)) {
              const baseDir = dirname(args.importer);
              const rawJoined = baseDir === "." ? args.path : `${baseDir}/${args.path}`;
              const cleaned = rawJoined.replace(/^\.\//u, "");
              for (const cand of [cleaned, `${cleaned}.ts`, `${cleaned}.js`, `${cleaned}.mjs`, `${cleaned}/index.ts`, `${cleaned}/index.js`]) {
                try {
                  const norm = normalizePosixPath(cand);
                  if (virtualFiles.has(norm)) return { path: norm, namespace: "chronolog-vfs" };
                } catch {
                }
              }
            }
            return null;
          });
          build.onLoad({ filter: /.*/, namespace: "chronolog-vfs" }, (args) => {
            const contents = virtualFiles.get(args.path);
            if (contents === void 0) return null;
            return {
              contents,
              loader: args.path.endsWith(".ts") ? "ts" : args.path.endsWith(".tsx") ? "tsx" : "js",
              resolveDir: cwd
            };
          });
        }
      }],
      bundle: shouldBundle,
      write: false,
      platform: "neutral",
      mainFields: ["module", "main"],
      conditions: ["import", "default"],
      format: "esm",
      target: "es2022",
      treeShaking: true,
      minifySyntax: true,
      sourcemap: false,
      legalComments: "none",
      charset: "utf8",
      define: { "process.env.NODE_ENV": '"production"' },
      external
    });
    return {
      compiledFiles: { "index.js": res2.outputFiles[0].text },
      sourceFiles,
      exportsMap: { ".": "index.js" }
    };
  }
  if (entry.path === void 0) throw new Error("PACK_ENTRY_PATH_OR_SOURCE_REQUIRED");
  const absPath = isAbsolute(entry.path) ? entry.path : resolve(cwd, entry.path);
  const rawSource = await readFile(absPath, "utf8");
  const res = await esbuildBuild({
    entryPoints: [absPath],
    bundle: shouldBundle,
    write: false,
    platform: "neutral",
    mainFields: ["module", "main"],
    conditions: ["import", "default"],
    format: "esm",
    target: "es2022",
    treeShaking: true,
    minifySyntax: true,
    sourcemap: false,
    legalComments: "none",
    charset: "utf8",
    define: { "process.env.NODE_ENV": '"production"' },
    external,
    absWorkingDir: cwd
  });
  return {
    compiledFiles: { "index.js": res.outputFiles[0].text },
    sourceFiles: { "entry.ts": rawSource },
    exportsMap: { ".": "index.js" }
  };
}
async function packReducers(options) {
  const cwd = options.cwd ?? process.cwd();
  const cas = options.cas ?? new ContentAddressedStore({ store: new MemoryBytesStore() });
  const lintMode = options.lint ?? "error";
  const includeDerivation = options.includeDerivation ?? true;
  const extraExternal = options.external ?? [];
  const imports = {};
  const entriesOut = {};
  const lockEntries = {};
  const allDiagnostics = [];
  const collectedNodes = /* @__PURE__ */ new Map();
  for (const [alias, rawEntry] of Object.entries(options.entries).sort(([a], [b]) => a.localeCompare(b))) {
    const entry = typeof rawEntry === "string" ? { path: rawEntry } : rawEntry;
    const partition = entry.partition ?? "public";
    const { compiledFiles, sourceFiles, exportsMap } = await bundleSingleEntry(entry, cwd, extraExternal);
    const entryDiagnostics = [];
    if (lintMode !== "off") {
      for (const [file, code] of Object.entries(compiledFiles)) {
        entryDiagnostics.push(...lintDeterminism(code, `${alias}:${file}`));
      }
      allDiagnostics.push(...entryDiagnostics);
      if (lintMode === "error" && entryDiagnostics.length > 0) {
        const first = entryDiagnostics[0];
        throw new Error(`DETERMINISM_LINT_FAILED: ${first.file}:${first.line}:${first.column} [${first.code}] ${first.message} (${first.suggestion})`);
      }
    }
    const builtins = entry.builtins ?? detectRequiredBuiltins(Object.values(compiledFiles));
    let drvHash;
    let drvRef;
    if (includeDerivation) {
      const srcTree = await putTreeDag(cas, sourceFiles, partition);
      const drv = await putDerivationNode(cas, {
        format: "chronolog-drv/v1",
        profile: "wasi-cas-v1",
        builder: ESBUILD_BUILDER_REF,
        inputs: {
          src: srcTree.ref,
          ...entry.dependencies ?? {}
        },
        args: {
          alias,
          bundle: entry.bundle !== false,
          target: "chronolog-pkg/v1"
        },
        limits: {
          maxMemoryBytes: 64 * 1024 * 1024,
          maxFuel: 2e5
        }
      }, partition);
      drvHash = drv.hash;
      drvRef = drv.ref;
    }
    const pkg = await putPackageDag(cas, {
      name: entry.name ?? alias,
      version: entry.version ?? "0.0.0",
      runtime: "esm-quickjs",
      files: compiledFiles,
      exports: exportsMap,
      ...entry.dependencies === void 0 ? {} : { dependencies: entry.dependencies },
      builtins,
      ...drvRef === void 0 ? {} : { derivation: drvRef }
    }, partition);
    imports[alias] = pkg.ref;
    entriesOut[alias] = {
      alias,
      pkgHash: pkg.hash,
      pkgRef: pkg.ref,
      ...drvHash === void 0 ? {} : { drvHash },
      ...drvRef === void 0 ? {} : { drvRef },
      manifest: pkg.manifest,
      diagnostics: entryDiagnostics
    };
    lockEntries[alias] = {
      pkgRef: pkg.ref,
      ...drvRef === void 0 ? {} : { drvRef },
      runtime: pkg.manifest.runtime,
      builtins: pkg.manifest.builtins,
      dependencies: pkg.manifest.dependencies
    };
    const sub = await cas.collectSubgraph([pkg.hash], { allowedPartition: partition, maxNodes: 4096, maxBytes: 32 * 1024 * 1024 });
    for (const node of sub) {
      collectedNodes.set(`${node.partition}:${node.hash}`, node);
    }
  }
  return {
    imports,
    casNodes: [...collectedNodes.values()],
    entries: entriesOut,
    lockfile: createLockfile(lockEntries),
    diagnostics: allDiagnostics
  };
}
async function packNpmTarball(options) {
  const cas = options.cas ?? new ContentAddressedStore({ store: new MemoryBytesStore() });
  const tarEntries = parseCanonicalTarball(options.tarball, {
    ...options.integrity === void 0 ? {} : { integrity: options.integrity }
  });
  const dec = new TextDecoder();
  const files = {};
  for (const e of tarEntries) files[e.path] = dec.decode(e.bytes);
  let pkgJson = {};
  if (files["package.json"] !== void 0) {
    pkgJson = JSON.parse(files["package.json"]);
  }
  const entryFile = normalizePosixPath(
    options.entry ?? (typeof pkgJson.module === "string" ? pkgJson.module : void 0) ?? (typeof pkgJson.main === "string" ? pkgJson.main : void 0) ?? "index.js"
  );
  const name = options.name ?? pkgJson.name ?? "npm-pkg";
  const version = options.version ?? pkgJson.version ?? "0.0.0";
  const sourceTree = await putTreeDag(cas, files, "public");
  const packed = await packReducers({
    cas,
    lint: options.lint ?? "error",
    includeDerivation: true,
    entries: {
      [name]: {
        name,
        version,
        path: entryFile,
        files,
        bundle: true
      }
    }
  });
  const result = packed.entries[name];
  return {
    ...result,
    casNodes: packed.casNodes,
    sourceTreeRef: sourceTree.ref
  };
}
var INLINE_TS_BUILDER_SOURCE = `
import { get, put } from 'chronolog:cas';

function hexToUtf8(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  let out = '';
  for (let i = 0; i < bytes.length; i++) out += String.fromCharCode(bytes[i]);
  return out;
}

function stripSimpleTs(src) {
  return src
    .replace(/^\\s*(?:export\\s+)?(?:interface|type)\\s+[A-Za-z_$][\\w$]*[^{=]*(\\{[^}]*\\}|=[^;]+;)/gm, '')
    .replace(/(\\b(?:const|let|var)\\s+[A-Za-z_$][\\w$]*)\\s*:\\s*[A-Za-z_$][\\w$<>\\[\\]|&\\s?]*(?=\\s*=)/g, '$1')
    .replace(/(\\([A-Za-z_$][\\w$]*)\\s*:\\s*[A-Za-z_$][\\w$<>\\[\\]|&\\s?]*(?=[,)])/g, '$1')
    .replace(/(,\\s*[A-Za-z_$][\\w$]*)\\s*:\\s*[A-Za-z_$][\\w$<>\\[\\]|&\\s?]*(?=[,)])/g, '$1')
    .replace(/\\)\\s*:\\s*[A-Za-z_$][\\w$<>\\[\\]|&\\s?]*\\s*\\{/g, ') {');
}

export default {
  derive(payload) {
    const srcRef = payload && payload.inputs && payload.inputs.src;
    if (typeof srcRef !== 'string') throw new Error('INLINE_TS_MISSING_SRC');
    const raw = JSON.parse(get(srcRef));
    const tsSource = hexToUtf8(raw.bytesHex);
    const jsSource = stripSimpleTs(tsSource);
    const outHash = put(jsSource, []);
    return { output: 'cas:sha256-' + outHash };
  },
};
`.trimStart();

// packages/materializer/src/std-modules.ts
init_src();

// packages/materializer/src/std/crdt.ts
var STD_CRDT_SOURCE = `
function hasWriter(ctx, author) {
  const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
  if (cfg.allowPublicWrite === true) return true;
  const checked = ctx.query('$permissions', { check: 'writer', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  return perms.members.some(m => m.publicKey === author && (m.writer === true || m.administrator === true));
}

function compareStamp(a, b) {
  if (a.ts !== b.ts) return a.ts < b.ts ? -1 : 1;
  if (a.author !== b.author) return a.author < b.author ? -1 : 1;
  if (a.opId !== b.opId) return a.opId < b.opId ? -1 : 1;
  return 0;
}

/**
 * Out-of-order-safe Last-Write-Wins Map CRDT.
 * Each key resolves deterministically by (authorTimestampMs, author, opId).
 */
export const lwwMap = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.entries && typeof state.entries === 'object'
      ? state
      : { entries: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object' || Array.isArray(input)) return { ok: false, code: 'invalid_input' };
    const stamp = { ts: Number(tx.authorTimestampMs || 0), author: tx.author, opId: tx.opId };
    const nextEntries = { ...cur.entries };
    const action = typeof input.action === 'string' ? input.action : 'set';

    if (action === 'set') {
      if (typeof input.key !== 'string' || input.key.length === 0) return { ok: false, code: 'crdt:invalid_key' };
      const existing = nextEntries[input.key];
      if (!existing || compareStamp(stamp, existing) >= 0) {
        nextEntries[input.key] = { value: input.value === undefined ? null : input.value, deleted: false, ...stamp };
      }
      return { ok: true, state: { entries: nextEntries }, events: [{ topic: 'crdt.map.set', payload: { key: input.key } }] };
    }

    if (action === 'delete') {
      if (typeof input.key !== 'string' || input.key.length === 0) return { ok: false, code: 'crdt:invalid_key' };
      const existing = nextEntries[input.key];
      if (!existing || compareStamp(stamp, existing) >= 0) {
        nextEntries[input.key] = { value: null, deleted: true, ...stamp };
      }
      return { ok: true, state: { entries: nextEntries }, events: [{ topic: 'crdt.map.delete', payload: { key: input.key } }] };
    }

    if (action === 'merge') {
      if (!input.values || typeof input.values !== 'object' || Array.isArray(input.values)) {
        return { ok: false, code: 'crdt:invalid_values' };
      }
      const keys = Object.keys(input.values).sort();
      for (const k of keys) {
        const existing = nextEntries[k];
        if (!existing || compareStamp(stamp, existing) >= 0) {
          nextEntries[k] = { value: input.values[k], deleted: false, ...stamp };
        }
      }
      return { ok: true, state: { entries: nextEntries }, events: [{ topic: 'crdt.map.merge', payload: { keys } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const entries = state && state.entries && typeof state.entries === 'object' ? state.entries : {};
    if (input && typeof input === 'object' && typeof input.key === 'string') {
      const e = entries[input.key];
      return !e || e.deleted ? null : e.value;
    }
    const out = {};
    for (const k of Object.keys(entries).sort()) {
      const e = entries[k];
      if (e && !e.deleted) out[k] = e.value;
    }
    return out;
  },
  describe() {
    const anyScalar = { anyOf: [{ type: 'string' }, { type: 'number' }, { type: 'boolean' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'set', description: 'Set a key in the LWW map.', input: { type: 'object', properties: { key: { type: 'string' }, value: anyScalar }, required: ['key'] } },
        { name: 'delete', description: 'Tombstone a key in the LWW map.', input: { type: 'object', properties: { key: { type: 'string' } }, required: ['key'] } },
        { name: 'merge', description: 'Merge multiple key-value pairs into the LWW map.', input: { type: 'object', properties: { values: { type: 'object', properties: {} } }, required: ['values'] } },
      ],
      queries: [
        { name: 'get', description: 'Read all live entries or a single key.', input: { type: 'object', properties: { key: { type: 'string' } } } },
      ],
    };
  },
};

/**
 * Observed-Remove Set (OR-Set) CRDT.
 * Each add receives a unique opId tag; remove clears either explicitly observed tags or all tags present at replay time.
 */
export const orSet = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.tags && typeof state.tags === 'object'
      ? state
      : { tags: {}, removed: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const action = typeof input.action === 'string' ? input.action : 'add';
    const value = typeof input.value === 'string' ? input.value : null;
    if (value === null || value.length === 0) return { ok: false, code: 'crdt:invalid_value' };

    const nextTags = { ...cur.tags };
    const nextRemoved = { ...cur.removed };

    if (action === 'add') {
      const tag = tx.opId;
      if (!nextRemoved[tag]) {
        const list = Array.isArray(nextTags[value]) ? nextTags[value].slice() : [];
        if (!list.includes(tag)) list.push(tag);
        list.sort();
        nextTags[value] = list;
      }
      return { ok: true, state: { tags: nextTags, removed: nextRemoved }, events: [{ topic: 'crdt.set.add', payload: { value } }] };
    }

    if (action === 'remove') {
      const existing = Array.isArray(nextTags[value]) ? nextTags[value] : [];
      const toRemove = Array.isArray(input.observedTags) ? input.observedTags.filter(t => typeof t === 'string') : existing;
      for (const t of toRemove) nextRemoved[t] = true;
      const remaining = existing.filter(t => !nextRemoved[t]);
      if (remaining.length === 0) delete nextTags[value];
      else nextTags[value] = remaining;
      return { ok: true, state: { tags: nextTags, removed: nextRemoved }, events: [{ topic: 'crdt.set.remove', payload: { value } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const tags = state && state.tags && typeof state.tags === 'object' ? state.tags : {};
    const values = Object.keys(tags).filter(k => Array.isArray(tags[k]) && tags[k].length > 0).sort();
    if (input && typeof input === 'object' && typeof input.has === 'string') {
      return values.includes(input.has);
    }
    return { values, tags };
  },
  describe() {
    return {
      commands: [
        { name: 'add', description: 'Add a value with a unique op tag.', input: { type: 'object', properties: { value: { type: 'string' } }, required: ['value'] } },
        { name: 'remove', description: 'Remove observed tags for a value.', input: { type: 'object', properties: { value: { type: 'string' }, observedTags: { type: 'array', items: { type: 'string' } } }, required: ['value'] } },
      ],
      queries: [
        { name: 'values', description: 'List live set values or check membership.', input: { type: 'object', properties: { has: { type: 'string' } } } },
      ],
    };
  },
};

/**
 * Positive-Negative Counter (PN-Counter) CRDT.
 */
export const pnCounter = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.p && state.n ? state : { p: {}, n: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const action = typeof input.action === 'string' ? input.action : 'add';
    const amount = Number(input.amount === undefined ? 1 : input.amount);
    if (!Number.isSafeInteger(amount) || amount < 0) return { ok: false, code: 'crdt:invalid_amount' };

    const p = { ...cur.p };
    const n = { ...cur.n };
    if (action === 'increment' || action === 'add') {
      p[tx.author] = (Number(p[tx.author]) || 0) + amount;
      return { ok: true, state: { p, n }, events: [{ topic: 'crdt.counter.increment', payload: { amount } }] };
    }
    if (action === 'decrement' || action === 'sub') {
      n[tx.author] = (Number(n[tx.author]) || 0) + amount;
      return { ok: true, state: { p, n }, events: [{ topic: 'crdt.counter.decrement', payload: { amount } }] };
    }
    return { ok: false, code: 'unknown_action' };
  },
  query(state) {
    const p = state && state.p && typeof state.p === 'object' ? state.p : {};
    const n = state && state.n && typeof state.n === 'object' ? state.n : {};
    let total = 0;
    for (const v of Object.values(p)) total += Number(v) || 0;
    for (const v of Object.values(n)) total -= Number(v) || 0;
    return { value: total, p, n };
  },
  describe() {
    return {
      commands: [
        { name: 'increment', description: 'Increment the counter.', input: { type: 'object', properties: { amount: { type: 'integer', minimum: 0 } } } },
        { name: 'decrement', description: 'Decrement the counter.', input: { type: 'object', properties: { amount: { type: 'integer', minimum: 0 } } } },
      ],
      queries: [
        { name: 'value', description: 'Read the converged total and per-author vectors.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};

function linearizeOrderedNodes(nodes) {
  const byParent = {};
  for (const id of Object.keys(nodes)) {
    const node = nodes[id];
    const parentKey = node.afterId && nodes[node.afterId] ? node.afterId : '__root__';
    if (!byParent[parentKey]) byParent[parentKey] = [];
    byParent[parentKey].push(node);
  }
  for (const key of Object.keys(byParent)) {
    // RGA tie-break: newer (higher ts/author/opId) concurrent siblings come FIRST right after their parent
    byParent[key].sort((a, b) => compareStamp(b, a));
  }
  const result = [];
  const visited = {};
  function walk(parentKey) {
    const children = byParent[parentKey];
    if (!children) return;
    for (const child of children) {
      if (visited[child.id]) continue;
      visited[child.id] = true;
      if (!child.deleted) result.push(child);
      walk(child.id);
    }
  }
  walk('__root__');
  return result;
}

/**
 * RGA Ordered List CRDT with deterministic concurrent insert and move support (Kanban / checklists).
 */
export const orderedList = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.nodes && typeof state.nodes === 'object'
      ? state
      : { nodes: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const action = typeof input.action === 'string' ? input.action : 'insert';
    const stamp = { ts: Number(tx.authorTimestampMs || 0), author: tx.author, opId: tx.opId };
    const nextNodes = { ...cur.nodes };

    if (action === 'insert') {
      const id = typeof input.id === 'string' && input.id.length > 0 ? input.id : tx.opId;
      if (nextNodes[id]) return { ok: false, code: 'crdt:duplicate_id' };
      const afterId = typeof input.afterId === 'string' && input.afterId.length > 0 ? input.afterId : null;
      nextNodes[id] = { id, afterId, value: input.value === undefined ? null : input.value, deleted: false, ...stamp };
      return { ok: true, state: { nodes: nextNodes }, events: [{ topic: 'crdt.list.insert', payload: { id } }] };
    }

    if (action === 'move') {
      const id = typeof input.id === 'string' ? input.id : '';
      const existing = nextNodes[id];
      if (!existing || existing.deleted) return { ok: false, code: 'crdt:item_not_found' };
      const afterId = typeof input.afterId === 'string' && input.afterId.length > 0 ? input.afterId : null;
      if (afterId === id) return { ok: false, code: 'crdt:cycle_forbidden' };
      // Prevent cycle by walking ancestors of afterId
      let cursor = afterId;
      let guard = 0;
      while (cursor && nextNodes[cursor] && guard++ < 10000) {
        if (cursor === id) return { ok: false, code: 'crdt:cycle_forbidden' };
        cursor = nextNodes[cursor].afterId;
      }
      nextNodes[id] = { ...existing, afterId, ...stamp };
      return { ok: true, state: { nodes: nextNodes }, events: [{ topic: 'crdt.list.move', payload: { id, afterId } }] };
    }

    if (action === 'update') {
      const id = typeof input.id === 'string' ? input.id : '';
      const existing = nextNodes[id];
      if (!existing || existing.deleted) return { ok: false, code: 'crdt:item_not_found' };
      nextNodes[id] = { ...existing, value: input.value === undefined ? null : input.value };
      return { ok: true, state: { nodes: nextNodes }, events: [{ topic: 'crdt.list.update', payload: { id } }] };
    }

    if (action === 'delete') {
      const id = typeof input.id === 'string' ? input.id : '';
      const existing = nextNodes[id];
      if (!existing) return { ok: false, code: 'crdt:item_not_found' };
      nextNodes[id] = { ...existing, deleted: true };
      return { ok: true, state: { nodes: nextNodes }, events: [{ topic: 'crdt.list.delete', payload: { id } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state) {
    const nodes = state && state.nodes && typeof state.nodes === 'object' ? state.nodes : {};
    const items = linearizeOrderedNodes(nodes).map(n => ({ id: n.id, value: n.value }));
    return { items };
  },
  describe() {
    const anyScalar = { anyOf: [{ type: 'string' }, { type: 'number' }, { type: 'boolean' }, { type: 'null' }] };
    const optStr = { anyOf: [{ type: 'string' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'insert', description: 'Insert an item after an anchor ID (or null for head).', input: { type: 'object', properties: { id: { type: 'string' }, afterId: optStr, value: anyScalar } } },
        { name: 'move', description: 'Move an existing item after another anchor ID.', input: { type: 'object', properties: { id: { type: 'string' }, afterId: optStr }, required: ['id'] } },
        { name: 'update', description: 'Update an item value.', input: { type: 'object', properties: { id: { type: 'string' }, value: anyScalar }, required: ['id'] } },
        { name: 'delete', description: 'Tombstone an item.', input: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
      ],
      queries: [
        { name: 'items', description: 'Return the converged ordered list.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/text.ts
var STD_TEXT_SOURCE = `
function hasWriter(ctx, author) {
  const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
  if (cfg.allowPublicWrite === true) return true;
  const checked = ctx.query('$permissions', { check: 'writer', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  return perms.members.some(m => m.publicKey === author && (m.writer === true || m.administrator === true));
}

function compareStamp(a, b) {
  if (a.ts !== b.ts) return a.ts < b.ts ? -1 : 1;
  if (a.author !== b.author) return a.author < b.author ? -1 : 1;
  if (a.opId !== b.opId) return a.opId < b.opId ? -1 : 1;
  if (a.seq !== b.seq) return a.seq < b.seq ? -1 : 1;
  return 0;
}

/**
 * Linearize RGA character/token nodes deterministically.
 * Each character node has a stable ID "<opId>:<offset>" so concurrent edits merge cleanly
 * without index drift under arbitrary out-of-order replay.
 */
function linearize(nodes) {
  const byParent = {};
  for (const id of Object.keys(nodes)) {
    const n = nodes[id];
    const parent = n.afterId && nodes[n.afterId] ? n.afterId : '__root__';
    if (!byParent[parent]) byParent[parent] = [];
    byParent[parent].push(n);
  }
  for (const key of Object.keys(byParent)) {
    byParent[key].sort((a, b) => compareStamp(b, a));
  }
  const ordered = [];
  const visited = {};
  function walk(parent) {
    const children = byParent[parent];
    if (!children) return;
    for (const child of children) {
      if (visited[child.id]) continue;
      visited[child.id] = true;
      ordered.push(child);
      walk(child.id);
    }
  }
  walk('__root__');
  return ordered;
}

function visibleNodes(nodes) {
  return linearize(nodes).filter(n => !n.deleted);
}

/**
 * Deterministic RGA Collaborative Text CRDT for prose, notes, and code co-editing.
 * Supports stable node-anchored edits (insert/delete) and index convenience helpers (insertAt/deleteRange).
 */
export const collaborativeText = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = state && typeof state === 'object' && state.nodes && typeof state.nodes === 'object'
      ? state
      : { nodes: {}, anchors: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const action = typeof input.action === 'string' ? input.action : 'insert';
    const nextNodes = { ...cur.nodes };
    const nextAnchors = { ...(cur.anchors || {}) };
    const baseTs = Number(tx.authorTimestampMs || 0);

    if (action === 'insert' || action === 'insertAt') {
      if (typeof input.text !== 'string' || input.text.length === 0) {
        return { ok: false, code: 'text:empty_insert' };
      }
      if (input.text.length > 4096) return { ok: false, code: 'text:insert_too_large' };
      let afterId = null;
      if (action === 'insert') {
        afterId = typeof input.afterId === 'string' && input.afterId.length > 0 ? input.afterId : null;
      } else {
        const vis = visibleNodes(nextNodes);
        const idx = Number.isSafeInteger(input.index) ? Math.max(0, Math.min(input.index, vis.length)) : vis.length;
        afterId = idx === 0 ? null : vis[idx - 1].id;
      }
      const chars = Array.from(input.text);
      let prevId = afterId;
      const insertedIds = [];
      for (let i = 0; i < chars.length; i++) {
        const id = tx.opId + ':' + i;
        nextNodes[id] = {
          id,
          afterId: prevId,
          ch: chars[i],
          deleted: false,
          ts: baseTs,
          author: tx.author,
          opId: tx.opId,
          seq: i,
        };
        insertedIds.push(id);
        prevId = id;
      }
      return {
        ok: true,
        state: { nodes: nextNodes, anchors: nextAnchors },
        events: [{ topic: 'text.insert', payload: { count: chars.length, firstId: insertedIds[0], lastId: insertedIds[insertedIds.length - 1] } }],
      };
    }

    if (action === 'delete') {
      if (!Array.isArray(input.ids) || input.ids.length === 0) return { ok: false, code: 'text:ids_required' };
      let deletedCount = 0;
      for (const id of input.ids) {
        if (typeof id === 'string' && nextNodes[id] && !nextNodes[id].deleted) {
          nextNodes[id] = { ...nextNodes[id], deleted: true };
          deletedCount++;
        }
      }
      return {
        ok: true,
        state: { nodes: nextNodes, anchors: nextAnchors },
        events: [{ topic: 'text.delete', payload: { count: deletedCount } }],
      };
    }

    if (action === 'deleteRange') {
      const vis = visibleNodes(nextNodes);
      const index = Number(input.index);
      const length = Number(input.length);
      if (!Number.isSafeInteger(index) || !Number.isSafeInteger(length) || index < 0 || length < 0) {
        return { ok: false, code: 'text:invalid_range' };
      }
      const slice = vis.slice(index, index + length);
      for (const node of slice) {
        nextNodes[node.id] = { ...node, deleted: true };
      }
      return {
        ok: true,
        state: { nodes: nextNodes, anchors: nextAnchors },
        events: [{ topic: 'text.delete', payload: { count: slice.length } }],
      };
    }

    if (action === 'setAnchor') {
      if (typeof input.name !== 'string' || input.name.length === 0) return { ok: false, code: 'text:invalid_anchor' };
      const nodeId = typeof input.nodeId === 'string' && input.nodeId.length > 0 ? input.nodeId : null;
      nextAnchors[input.name] = { nodeId, updatedBy: tx.author, updatedAtMs: baseTs };
      return { ok: true, state: { nodes: nextNodes, anchors: nextAnchors } };
    }

    return { ok: false, code: 'unknown_action' };
  },

  query(state, input) {
    const nodes = state && state.nodes && typeof state.nodes === 'object' ? state.nodes : {};
    const anchors = state && state.anchors && typeof state.anchors === 'object' ? state.anchors : {};
    const vis = visibleNodes(nodes);
    const kind = input && typeof input === 'object' ? (input.query || input.kind) : 'text';
    if (kind === 'nodes') {
      return { nodes: vis.map(n => ({ id: n.id, ch: n.ch })) };
    }
    if (kind === 'anchors') {
      const idxById = {};
      for (let i = 0; i < vis.length; i++) idxById[vis[i].id] = i;
      const resolved = {};
      for (const name of Object.keys(anchors).sort()) {
        const a = anchors[name];
        resolved[name] = {
          ...a,
          index: a.nodeId && Object.prototype.hasOwnProperty.call(idxById, a.nodeId) ? idxById[a.nodeId] + 1 : 0,
        };
      }
      return { anchors: resolved };
    }
    const text = vis.map(n => n.ch).join('');
    if (kind === 'stats') {
      return { length: vis.length, totalNodes: Object.keys(nodes).length, text };
    }
    return { text, length: vis.length, lastNodeId: vis.length > 0 ? vis[vis.length - 1].id : null };
  },

  describe() {
    const optStr = { anyOf: [{ type: 'string' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'insert', description: 'Insert text anchored after a stable node ID (or null for start).', input: { type: 'object', properties: { afterId: optStr, text: { type: 'string' } }, required: ['text'] } },
        { name: 'insertAt', description: 'Insert text at a character index.', input: { type: 'object', properties: { index: { type: 'integer', minimum: 0 }, text: { type: 'string' } }, required: ['text'] } },
        { name: 'delete', description: 'Delete characters by stable node IDs.', input: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' } } }, required: ['ids'] } },
        { name: 'deleteRange', description: 'Delete a visible character range.', input: { type: 'object', properties: { index: { type: 'integer', minimum: 0 }, length: { type: 'integer', minimum: 0 } }, required: ['index', 'length'] } },
        { name: 'setAnchor', description: 'Save a named cursor/comment anchor on a stable node ID.', input: { type: 'object', properties: { name: { type: 'string' }, nodeId: optStr }, required: ['name'] } },
      ],
      queries: [
        { name: 'text', description: 'Read the converged string and tail node ID.', input: { type: 'object', properties: {} } },
        { name: 'nodes', description: 'Read visible character nodes with stable IDs.', input: { type: 'object', properties: {} } },
        { name: 'anchors', description: 'Resolve saved anchors to current character indices.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/ledger.ts
var STD_LEDGER_SOURCE = `
function hasCap(ctx, cap, author) {
  const checked = ctx.query('$permissions', { check: cap, actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  const m = perms.members.find(x => x.publicKey === author);
  if (!m) return false;
  if (cap === 'administrator') return m.administrator === true;
  if (cap === 'writer') return m.writer === true || m.administrator === true;
  return false;
}

function normalizeState(state) {
  const s = state && typeof state === 'object' ? state : {};
  return {
    accounts: s.accounts && typeof s.accounts === 'object' ? { ...s.accounts } : {},
    holds: s.holds && typeof s.holds === 'object' ? { ...s.holds } : {},
    allowances: s.allowances && typeof s.allowances === 'object' ? { ...s.allowances } : {},
    entries: Array.isArray(s.entries) ? s.entries.slice() : [],
  };
}

function reservedAmount(state, accountId, nowMs) {
  let reserved = 0;
  for (const h of Object.values(state.holds)) {
    if (h.status === 'active' && h.from === accountId && (h.expiresAtMs === null || nowMs <= h.expiresAtMs)) {
      reserved += h.amount;
    }
  }
  for (const a of Object.values(state.allowances)) {
    if (a.status === 'active' && a.fromAccount === accountId && (a.expiresAtMs === null || nowMs <= a.expiresAtMs)) {
      reserved += a.remaining;
    }
  }
  return reserved;
}

function availableBalance(state, accountId, nowMs) {
  const acct = state.accounts[accountId];
  if (!acct) return 0;
  return acct.balance - reservedAmount(state, accountId, nowMs);
}

/**
 * Deterministic Double-Entry Ledger with:
 * - Balanced integer postings (sum === 0) and per-account non-negative invariants
 * - Expiring holds/escrows (automatically release when authorTimestampMs > expiresAtMs)
 * - Offline Escrow CRDT allowances (grantee spends autonomously offline up to reserved quota)
 */
export const doubleEntryLedger = {
  reduce(state, tx, ctx) {
    const cur = normalizeState(state);
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const isAdmin = hasCap(ctx, 'administrator', tx.author);
    const isWriter = isAdmin || hasCap(ctx, 'writer', tx.author);
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = typeof input.action === 'string' ? input.action : 'post';

    if (action === 'createAccount') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const id = typeof input.id === 'string' && input.id.length > 0 ? input.id : null;
      if (!id) return { ok: false, code: 'ledger:invalid_account_id' };
      if (cur.accounts[id]) return { ok: false, code: 'ledger:account_exists' };
      const allowNegative = input.allowNegative === true;
      if (allowNegative && !isAdmin) return { ok: false, code: 'admin_required' };
      cur.accounts[id] = {
        id,
        currency: typeof input.currency === 'string' && input.currency.length > 0 ? input.currency : 'USD',
        balance: 0,
        allowNegative,
        owner: typeof input.owner === 'string' ? input.owner : tx.author,
      };
      return { ok: true, state: cur, events: [{ topic: 'ledger.account_created', payload: { id } }] };
    }

    if (action === 'post') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      if (!Array.isArray(input.postings) || input.postings.length < 2) return { ok: false, code: 'ledger:postings_required' };
      let sum = 0;
      const currencies = new Set();
      const deltas = {};
      for (const p of input.postings) {
        if (!p || typeof p.account !== 'string' || !Number.isSafeInteger(p.delta) || p.delta === 0) {
          return { ok: false, code: 'ledger:invalid_posting' };
        }
        const acct = cur.accounts[p.account];
        if (!acct) return { ok: false, code: 'ledger:account_not_found', detail: p.account };
        currencies.add(acct.currency);
        sum += p.delta;
        deltas[p.account] = (deltas[p.account] || 0) + p.delta;
      }
      if (currencies.size !== 1) return { ok: false, code: 'ledger:currency_mismatch' };
      if (sum !== 0) return { ok: false, code: 'ledger:unbalanced' };
      for (const [acctId, delta] of Object.entries(deltas)) {
        const acct = cur.accounts[acctId];
        if (!acct.allowNegative && availableBalance(cur, acctId, nowMs) + delta < 0) {
          return { ok: false, code: 'ledger:insufficient_funds', detail: acctId };
        }
      }
      for (const [acctId, delta] of Object.entries(deltas)) {
        cur.accounts[acctId] = { ...cur.accounts[acctId], balance: cur.accounts[acctId].balance + delta };
      }
      const entry = {
        opId: tx.opId,
        author: tx.author,
        ts: nowMs,
        memo: typeof input.memo === 'string' ? input.memo : '',
        postings: input.postings.map(p => ({ account: p.account, delta: p.delta })),
      };
      cur.entries = cur.entries.concat([entry]).slice(-512);
      return { ok: true, state: cur, events: [{ topic: 'ledger.posted', payload: { opId: tx.opId } }] };
    }

    if (action === 'hold') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const holdId = typeof input.holdId === 'string' && input.holdId.length > 0 ? input.holdId : tx.opId;
      if (cur.holds[holdId]) return { ok: false, code: 'ledger:hold_exists' };
      const amount = Number(input.amount);
      if (!Number.isSafeInteger(amount) || amount <= 0) return { ok: false, code: 'ledger:invalid_amount' };
      const fromAcct = cur.accounts[input.from];
      const toAcct = cur.accounts[input.to];
      if (!fromAcct || !toAcct) return { ok: false, code: 'ledger:account_not_found' };
      if (fromAcct.currency !== toAcct.currency) return { ok: false, code: 'ledger:currency_mismatch' };
      if (!fromAcct.allowNegative && availableBalance(cur, fromAcct.id, nowMs) < amount) {
        return { ok: false, code: 'ledger:insufficient_funds', detail: fromAcct.id };
      }
      const expiresAtMs = input.expiresAtMs === undefined || input.expiresAtMs === null ? null : Number(input.expiresAtMs);
      if (expiresAtMs !== null && !Number.isSafeInteger(expiresAtMs)) return { ok: false, code: 'ledger:invalid_expiry' };
      cur.holds[holdId] = {
        holdId,
        from: fromAcct.id,
        to: toAcct.id,
        amount,
        expiresAtMs,
        status: 'active',
        createdBy: tx.author,
        createdAtMs: nowMs,
      };
      return { ok: true, state: cur, events: [{ topic: 'ledger.hold_created', payload: { holdId, amount } }] };
    }

    if (action === 'captureHold') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const h = cur.holds[input.holdId];
      if (!h || h.status !== 'active') return { ok: false, code: 'ledger:hold_not_active' };
      if (h.expiresAtMs !== null && nowMs > h.expiresAtMs) return { ok: false, code: 'ledger:hold_expired' };
      const captureAmt = input.amount === undefined ? h.amount : Number(input.amount);
      if (!Number.isSafeInteger(captureAmt) || captureAmt <= 0 || captureAmt > h.amount) {
        return { ok: false, code: 'ledger:invalid_amount' };
      }
      cur.accounts[h.from] = { ...cur.accounts[h.from], balance: cur.accounts[h.from].balance - captureAmt };
      cur.accounts[h.to] = { ...cur.accounts[h.to], balance: cur.accounts[h.to].balance + captureAmt };
      cur.holds[h.holdId] = { ...h, status: 'captured', capturedAmount: captureAmt };
      cur.entries = cur.entries.concat([{
        opId: tx.opId,
        author: tx.author,
        ts: nowMs,
        memo: 'capture:' + h.holdId,
        postings: [{ account: h.from, delta: -captureAmt }, { account: h.to, delta: captureAmt }],
      }]).slice(-512);
      return { ok: true, state: cur, events: [{ topic: 'ledger.hold_captured', payload: { holdId: h.holdId, amount: captureAmt } }] };
    }

    if (action === 'releaseHold') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const h = cur.holds[input.holdId];
      if (!h || h.status !== 'active') return { ok: false, code: 'ledger:hold_not_active' };
      if (!isAdmin && h.createdBy !== tx.author) return { ok: false, code: 'admin_or_creator_required' };
      cur.holds[h.holdId] = { ...h, status: 'released' };
      return { ok: true, state: cur, events: [{ topic: 'ledger.hold_released', payload: { holdId: h.holdId } }] };
    }

    if (action === 'grantAllowance') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const allowanceId = typeof input.allowanceId === 'string' && input.allowanceId.length > 0 ? input.allowanceId : tx.opId;
      if (cur.allowances[allowanceId]) return { ok: false, code: 'ledger:allowance_exists' };
      const amount = Number(input.amount);
      if (!Number.isSafeInteger(amount) || amount <= 0) return { ok: false, code: 'ledger:invalid_amount' };
      const fromAcct = cur.accounts[input.fromAccount];
      if (!fromAcct) return { ok: false, code: 'ledger:account_not_found' };
      if (typeof input.grantee !== 'string' || input.grantee.length === 0) return { ok: false, code: 'ledger:invalid_grantee' };
      if (!fromAcct.allowNegative && availableBalance(cur, fromAcct.id, nowMs) < amount) {
        return { ok: false, code: 'ledger:insufficient_funds', detail: fromAcct.id };
      }
      const expiresAtMs = input.expiresAtMs === undefined || input.expiresAtMs === null ? null : Number(input.expiresAtMs);
      cur.allowances[allowanceId] = {
        allowanceId,
        fromAccount: fromAcct.id,
        grantee: input.grantee,
        granted: amount,
        remaining: amount,
        expiresAtMs,
        status: 'active',
        grantedBy: tx.author,
        grantedAtMs: nowMs,
      };
      return { ok: true, state: cur, events: [{ topic: 'ledger.allowance_granted', payload: { allowanceId, grantee: input.grantee, amount } }] };
    }

    if (action === 'spendFromAllowance') {
      const al = cur.allowances[input.allowanceId];
      if (!al || al.status !== 'active') return { ok: false, code: 'ledger:allowance_not_active' };
      if (al.grantee !== tx.author && !isAdmin) return { ok: false, code: 'ledger:grantee_required' };
      if (al.expiresAtMs !== null && nowMs > al.expiresAtMs) return { ok: false, code: 'ledger:allowance_expired' };
      const amount = Number(input.amount);
      if (!Number.isSafeInteger(amount) || amount <= 0 || amount > al.remaining) {
        return { ok: false, code: 'ledger:allowance_exceeded' };
      }
      const toAcct = cur.accounts[input.toAccount];
      const fromAcct = cur.accounts[al.fromAccount];
      if (!toAcct || !fromAcct) return { ok: false, code: 'ledger:account_not_found' };
      if (fromAcct.currency !== toAcct.currency) return { ok: false, code: 'ledger:currency_mismatch' };
      cur.accounts[fromAcct.id] = { ...fromAcct, balance: fromAcct.balance - amount };
      cur.accounts[toAcct.id] = { ...toAcct, balance: toAcct.balance + amount };
      cur.allowances[al.allowanceId] = { ...al, remaining: al.remaining - amount };
      cur.entries = cur.entries.concat([{
        opId: tx.opId,
        author: tx.author,
        ts: nowMs,
        memo: typeof input.memo === 'string' ? input.memo : ('allowance:' + al.allowanceId),
        postings: [{ account: fromAcct.id, delta: -amount }, { account: toAcct.id, delta: amount }],
      }]).slice(-512);
      return { ok: true, state: cur, events: [{ topic: 'ledger.allowance_spent', payload: { allowanceId: al.allowanceId, amount, remaining: al.remaining - amount } }] };
    }

    if (action === 'reclaimAllowance') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const al = cur.allowances[input.allowanceId];
      if (!al || al.status !== 'active') return { ok: false, code: 'ledger:allowance_not_active' };
      cur.allowances[al.allowanceId] = { ...al, status: 'reclaimed', remaining: 0 };
      return { ok: true, state: cur, events: [{ topic: 'ledger.allowance_reclaimed', payload: { allowanceId: al.allowanceId } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },

  query(state, input) {
    const cur = normalizeState(state);
    const q = input && typeof input === 'object' ? input : {};
    const atMs = Number.isSafeInteger(q.atMs) ? q.atMs : 0;
    const kind = q.query || q.kind || 'balances';
    if (kind === 'account' && typeof q.id === 'string') {
      const a = cur.accounts[q.id];
      if (!a) return null;
      return { ...a, available: availableBalance(cur, a.id, atMs) };
    }
    if (kind === 'holds') return { holds: Object.values(cur.holds) };
    if (kind === 'allowances') {
      const list = Object.values(cur.allowances);
      return { allowances: typeof q.grantee === 'string' ? list.filter(a => a.grantee === q.grantee) : list };
    }
    if (kind === 'entries') return { entries: cur.entries };
    const balances = {};
    for (const id of Object.keys(cur.accounts).sort()) {
      const a = cur.accounts[id];
      balances[id] = { currency: a.currency, balance: a.balance, available: availableBalance(cur, id, atMs) };
    }
    return { balances };
  },

  describe() {
    const optInt = { anyOf: [{ type: 'integer' }, { type: 'null' }] };
    const postingItem = { type: 'object', properties: { account: { type: 'string' }, delta: { type: 'integer' } }, required: ['account', 'delta'] };
    return {
      commands: [
        { name: 'createAccount', description: 'Create a ledger account.', input: { type: 'object', properties: { id: { type: 'string' }, currency: { type: 'string' }, allowNegative: { type: 'boolean' } }, required: ['id'] } },
        { name: 'post', description: 'Submit balanced double-entry postings.', input: { type: 'object', properties: { postings: { type: 'array', items: postingItem }, memo: { type: 'string' } }, required: ['postings'] } },
        { name: 'hold', description: 'Reserve funds in an expiring hold/escrow.', input: { type: 'object', properties: { holdId: { type: 'string' }, from: { type: 'string' }, to: { type: 'string' }, amount: { type: 'integer' }, expiresAtMs: optInt }, required: ['from', 'to', 'amount'] } },
        { name: 'captureHold', description: 'Settle an active hold.', input: { type: 'object', properties: { holdId: { type: 'string' }, amount: { type: 'integer' } }, required: ['holdId'] } },
        { name: 'releaseHold', description: 'Release an active hold.', input: { type: 'object', properties: { holdId: { type: 'string' } }, required: ['holdId'] } },
        { name: 'grantAllowance', description: 'Reserve an offline Escrow CRDT spending allowance for a peer or agent.', input: { type: 'object', properties: { allowanceId: { type: 'string' }, fromAccount: { type: 'string' }, grantee: { type: 'string' }, amount: { type: 'integer' }, expiresAtMs: optInt }, required: ['fromAccount', 'grantee', 'amount'] } },
        { name: 'spendFromAllowance', description: 'Spend offline from a granted allowance without global consensus.', input: { type: 'object', properties: { allowanceId: { type: 'string' }, toAccount: { type: 'string' }, amount: { type: 'integer' }, memo: { type: 'string' } }, required: ['allowanceId', 'toAccount', 'amount'] } },
        { name: 'reclaimAllowance', description: 'Reclaim unused funds from an allowance.', input: { type: 'object', properties: { allowanceId: { type: 'string' } }, required: ['allowanceId'] } },
      ],
      queries: [
        { name: 'balances', description: 'Read posted and available balances.', input: { type: 'object', properties: { atMs: { type: 'integer' } } } },
        { name: 'allowances', description: 'List active offline spending allowances.', input: { type: 'object', properties: { grantee: { type: 'string' } } } },
        { name: 'holds', description: 'List holds and escrows.', input: { type: 'object', properties: {} } },
        { name: 'entries', description: 'Read ledger entry history.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/workflow.ts
var STD_WORKFLOW_SOURCE = `
function hasCap(ctx, cap, author) {
  const checked = ctx.query('$permissions', { check: cap, actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  const m = perms.members.find(x => x.publicKey === author);
  if (!m) return false;
  if (cap === 'administrator') return m.administrator === true;
  if (cap === 'writer') return m.writer === true || m.administrator === true;
  return false;
}

function normalizeWorkflow(state, config) {
  const cfg = config && typeof config === 'object' ? config : {};
  const s = state && typeof state === 'object' ? state : {};
  const def = s.definition && typeof s.definition === 'object'
    ? s.definition
    : (cfg.definition && typeof cfg.definition === 'object' ? cfg.definition : {
        initialState: 'proposed',
        states: ['proposed', 'approved', 'rejected', 'expired'],
        transitions: [
          { name: 'approve', from: 'proposed', to: 'approved', roles: ['administrator'], distinctFromCreator: false, requiredApprovals: 1 },
          { name: 'reject', from: 'proposed', to: 'rejected', roles: ['administrator'], distinctFromCreator: false, requiredApprovals: 1 },
        ],
      });
  return {
    definition: def,
    items: s.items && typeof s.items === 'object' ? { ...s.items } : {},
  };
}

/**
 * Deterministic Workflow / State-Machine & Approval Queue Reducer.
 * Supports role guards, separation of duties (reviewer !== creator), M-of-N item sign-offs,
 * SLA expiry, and AI-agent proposal review queues.
 */
export const stateMachine = {
  reduce(state, tx, ctx) {
    const cur = normalizeWorkflow(state, ctx.config);
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const isAdmin = hasCap(ctx, 'administrator', tx.author);
    const isWriter = isAdmin || hasCap(ctx, 'writer', tx.author);
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = typeof input.action === 'string' ? input.action : 'create';

    if (action === 'configure') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const def = input.definition;
      if (!def || typeof def !== 'object' || !Array.isArray(def.states) || !Array.isArray(def.transitions) || typeof def.initialState !== 'string') {
        return { ok: false, code: 'workflow:invalid_definition' };
      }
      return { ok: true, state: { ...cur, definition: def }, events: [{ topic: 'workflow.configured', payload: { states: def.states } }] };
    }

    if (action === 'create') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      const id = typeof input.id === 'string' && input.id.length > 0 ? input.id : tx.opId;
      if (cur.items[id]) return { ok: false, code: 'workflow:item_exists' };
      const initialState = typeof input.initialState === 'string' ? input.initialState : cur.definition.initialState;
      if (!cur.definition.states.includes(initialState)) return { ok: false, code: 'workflow:invalid_state' };
      cur.items[id] = {
        id,
        title: typeof input.title === 'string' ? input.title : '',
        state: initialState,
        createdBy: tx.author,
        createdAtMs: nowMs,
        enteredAtMs: nowMs,
        payload: input.payload === undefined ? null : input.payload,
        approvals: {},
        history: [{ state: initialState, actor: tx.author, ts: nowMs, opId: tx.opId }],
      };
      return { ok: true, state: cur, events: [{ topic: 'workflow.created', payload: { id, state: initialState } }] };
    }

    if (action === 'transition') {
      const id = typeof input.id === 'string' ? input.id : '';
      const item = cur.items[id];
      if (!item) return { ok: false, code: 'workflow:item_not_found' };
      const tName = typeof input.transition === 'string' ? input.transition : '';
      const rule = cur.definition.transitions.find(r =>
        r.name === tName && (Array.isArray(r.from) ? r.from.includes(item.state) : r.from === item.state),
      );
      if (!rule) return { ok: false, code: 'workflow:transition_not_allowed' };
      if (rule.slaMs !== undefined && rule.slaMs !== null && nowMs > item.enteredAtMs + Number(rule.slaMs)) {
        return { ok: false, code: 'workflow:sla_expired' };
      }
      if (rule.distinctFromCreator === true && tx.author === item.createdBy) {
        return { ok: false, code: 'workflow:separation_of_duties' };
      }
      const roles = Array.isArray(rule.roles) && rule.roles.length > 0 ? rule.roles : ['writer'];
      const authorized = roles.some(role => {
        if (role === 'administrator' || role === 'admin') return isAdmin;
        if (role === 'writer') return isWriter;
        return Boolean(ctx.query('$permissions', { check: 'scope', actor: tx.author, scope: role, atMs: nowMs }));
      });
      if (!authorized) return { ok: false, code: 'workflow:role_required' };

      const required = Number.isSafeInteger(rule.requiredApprovals) && rule.requiredApprovals > 0 ? rule.requiredApprovals : 1;
      const nextApprovals = { ...(item.approvals || {}) };
      const currentSigners = Array.isArray(nextApprovals[tName]) ? nextApprovals[tName].slice() : [];
      if (!currentSigners.includes(tx.author)) currentSigners.push(tx.author);
      currentSigners.sort();
      nextApprovals[tName] = currentSigners;

      if (currentSigners.length < required) {
        cur.items[id] = { ...item, approvals: nextApprovals };
        return {
          ok: true,
          state: cur,
          events: [{ topic: 'workflow.approval_recorded', payload: { id, transition: tName, count: currentSigners.length, required } }],
        };
      }

      const nextHistory = item.history.concat([{
        transition: tName,
        from: item.state,
        state: rule.to,
        actor: tx.author,
        ts: nowMs,
        opId: tx.opId,
        ...(typeof input.note === 'string' && input.note.length > 0 ? { note: input.note } : {}),
      }]);
      cur.items[id] = {
        ...item,
        state: rule.to,
        enteredAtMs: nowMs,
        approvals: {},
        ...(input.payload !== undefined ? { payload: input.payload } : {}),
        history: nextHistory,
      };
      return {
        ok: true,
        state: cur,
        events: [{ topic: 'workflow.transitioned', payload: { id, transition: tName, from: item.state, to: rule.to } }],
      };
    }

    if (action === 'expire') {
      const id = typeof input.id === 'string' ? input.id : '';
      const item = cur.items[id];
      if (!item) return { ok: false, code: 'workflow:item_not_found' };
      const rule = cur.definition.transitions.find(r =>
        r.slaMs !== undefined && r.slaMs !== null && r.expiredTo &&
        (Array.isArray(r.from) ? r.from.includes(item.state) : r.from === item.state),
      );
      if (!rule) return { ok: false, code: 'workflow:no_sla_rule' };
      if (nowMs <= item.enteredAtMs + Number(rule.slaMs)) return { ok: false, code: 'workflow:not_yet_expired' };
      cur.items[id] = {
        ...item,
        state: rule.expiredTo,
        enteredAtMs: nowMs,
        approvals: {},
        history: item.history.concat([{ transition: 'expire', from: item.state, state: rule.expiredTo, actor: tx.author, ts: nowMs, opId: tx.opId }]),
      };
      return { ok: true, state: cur, events: [{ topic: 'workflow.expired', payload: { id, to: rule.expiredTo } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },

  query(state, input) {
    const cur = normalizeWorkflow(state, null);
    const q = input && typeof input === 'object' ? input : {};
    const kind = q.query || q.kind || 'list';
    if (kind === 'config') return cur.definition;
    if (kind === 'item' && typeof q.id === 'string') return cur.items[q.id] || null;
    const all = Object.values(cur.items);
    const filtered = typeof q.state === 'string' ? all.filter(i => i.state === q.state) : all;
    filtered.sort((a, b) => (a.createdAtMs !== b.createdAtMs ? a.createdAtMs - b.createdAtMs : (a.id < b.id ? -1 : 1)));
    return { items: filtered };
  },

  describe() {
    const anyPayload = { anyOf: [{ type: 'object', properties: {} }, { type: 'string' }, { type: 'number' }, { type: 'boolean' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'configure', description: 'Configure states, transitions, role guards, and SLA rules.', input: { type: 'object', properties: { definition: { type: 'object', properties: {} } }, required: ['definition'] } },
        { name: 'create', description: 'Create a workflow item or AI proposal.', input: { type: 'object', properties: { id: { type: 'string' }, title: { type: 'string' }, payload: anyPayload } } },
        { name: 'transition', description: 'Approve or execute a state transition.', input: { type: 'object', properties: { id: { type: 'string' }, transition: { type: 'string' }, note: { type: 'string' } }, required: ['id', 'transition'] } },
        { name: 'expire', description: 'Transition an item past its SLA deadline.', input: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
      ],
      queries: [
        { name: 'list', description: 'List workflow items (optionally filtered by state).', input: { type: 'object', properties: { state: { type: 'string' } } } },
        { name: 'item', description: 'Inspect one workflow item and its history.', input: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
        { name: 'config', description: 'Inspect active state machine definition.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/fs.ts
var STD_FS_SOURCE = `
function hasWriter(ctx, author) {
  const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
  if (cfg.allowPublicWrite === true) return true;
  const checked = ctx.query('$permissions', { check: 'writer', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  return perms.members.some(m => m.publicKey === author && (m.writer === true || m.administrator === true));
}

function normalizePath(raw) {
  if (typeof raw !== 'string') return null;
  const parts = raw.split('/').filter(Boolean);
  if (parts.length === 0) return '/';
  for (const p of parts) {
    if (p === '.' || p === '..' || p.length > 128) return null;
  }
  return '/' + parts.join('/');
}

function parentPath(p) {
  if (p === '/') return null;
  const idx = p.lastIndexOf('/');
  return idx <= 0 ? '/' : p.slice(0, idx);
}

function conflictPathFor(path, author, opId) {
  const slash = path.lastIndexOf('/');
  const dir = path.slice(0, slash + 1);
  const name = path.slice(slash + 1);
  const dot = name.lastIndexOf('.');
  const tag = ' (conflict-' + String(author).slice(0, 8) + '-' + String(opId).slice(0, 6) + ')';
  if (dot > 0) return dir + name.slice(0, dot) + tag + name.slice(dot);
  return dir + name + tag;
}

function normalizeFs(state) {
  const s = state && typeof state === 'object' && state.entries && typeof state.entries === 'object'
    ? { entries: { ...state.entries } }
    : { entries: { '/': { kind: 'dir', path: '/', createdAtMs: 0 } } };
  if (!s.entries['/']) s.entries['/'] = { kind: 'dir', path: '/', createdAtMs: 0 };
  return s;
}

function ensureParents(entries, path, nowMs, author) {
  let cur = parentPath(path);
  const toCreate = [];
  while (cur && !entries[cur]) {
    toCreate.push(cur);
    cur = parentPath(cur);
  }
  for (let i = toCreate.length - 1; i >= 0; i--) {
    const dirPath = toCreate[i];
    entries[dirPath] = { kind: 'dir', path: dirPath, createdBy: author, createdAtMs: nowMs };
  }
}

/**
 * Content-Addressed Virtual Filesystem Reducer.
 * Stores directory tree & metadata in the log while file bodies are lazy-pulled via session.content.
 * Concurrent edits to a file with a mismatched expectedOpId automatically create a non-destructive conflict fork.
 */
export const virtualFs = {
  reduce(state, tx, ctx) {
    if (!hasWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const cur = normalizeFs(state);
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = typeof input.action === 'string' ? input.action : 'writeFile';

    if (action === 'mkdir') {
      const path = normalizePath(input.path);
      if (!path || path === '/') return { ok: false, code: 'fs:invalid_path' };
      if (cur.entries[path] && cur.entries[path].kind !== 'dir') return { ok: false, code: 'fs:path_is_file' };
      ensureParents(cur.entries, path, nowMs, tx.author);
      if (!cur.entries[path]) {
        cur.entries[path] = { kind: 'dir', path, createdBy: tx.author, createdAtMs: nowMs };
      }
      return { ok: true, state: cur, events: [{ topic: 'fs.mkdir', payload: { path } }] };
    }

    if (action === 'writeFile') {
      const path = normalizePath(input.path);
      if (!path || path === '/') return { ok: false, code: 'fs:invalid_path' };
      const existing = cur.entries[path];
      if (existing && existing.kind === 'dir') return { ok: false, code: 'fs:path_is_dir' };
      ensureParents(cur.entries, path, nowMs, tx.author);

      const expectedOpId = input.expectedOpId;
      const isConflict = expectedOpId !== undefined &&
        ((existing && existing.opId !== expectedOpId) || (!existing && expectedOpId !== null));

      if (isConflict && input.onConflict === 'reject') {
        return { ok: false, code: 'fs:version_conflict', detail: path };
      }

      const targetPath = isConflict ? conflictPathFor(path, tx.author, tx.opId) : path;
      const prevVersion = existing && !isConflict ? (Number(existing.version) || 0) : 0;
      const prevHistory = existing && !isConflict && Array.isArray(existing.history) ? existing.history.slice(-15) : [];
      const meta = {
        kind: 'file',
        path: targetPath,
        ...(isConflict ? { conflictOf: path } : {}),
        ref: input.ref === undefined ? null : input.ref,
        sha256: typeof input.sha256 === 'string' ? input.sha256 : null,
        bytes: Number.isSafeInteger(input.bytes) ? input.bytes : 0,
        mediaType: typeof input.mediaType === 'string' ? input.mediaType : 'application/octet-stream',
        version: prevVersion + 1,
        opId: tx.opId,
        updatedBy: tx.author,
        updatedAtMs: nowMs,
        history: prevHistory.concat([{ version: prevVersion + 1, opId: tx.opId, ref: input.ref ?? null, updatedBy: tx.author, updatedAtMs: nowMs }]),
      };
      cur.entries[targetPath] = meta;
      return {
        ok: true,
        state: cur,
        events: [{ topic: isConflict ? 'fs.conflict_fork' : 'fs.write', payload: { path: targetPath, ...(isConflict ? { conflictOf: path } : {}), version: meta.version } }],
      };
    }

    if (action === 'move') {
      const from = normalizePath(input.from);
      const to = normalizePath(input.to);
      if (!from || !to || from === '/' || to === '/') return { ok: false, code: 'fs:invalid_path' };
      const entry = cur.entries[from];
      if (!entry) return { ok: false, code: 'fs:not_found' };
      if (cur.entries[to]) return { ok: false, code: 'fs:destination_exists' };
      ensureParents(cur.entries, to, nowMs, tx.author);
      if (entry.kind === 'file') {
        delete cur.entries[from];
        cur.entries[to] = { ...entry, path: to, updatedBy: tx.author, updatedAtMs: nowMs };
      } else {
        const prefix = from + '/';
        const moved = [];
        for (const p of Object.keys(cur.entries)) {
          if (p === from || p.startsWith(prefix)) moved.push(p);
        }
        for (const p of moved) {
          const nextP = p === from ? to : to + p.slice(from.length);
          cur.entries[nextP] = { ...cur.entries[p], path: nextP };
          delete cur.entries[p];
        }
      }
      return { ok: true, state: cur, events: [{ topic: 'fs.move', payload: { from, to } }] };
    }

    if (action === 'delete') {
      const path = normalizePath(input.path);
      if (!path || path === '/') return { ok: false, code: 'fs:invalid_path' };
      if (!cur.entries[path]) return { ok: false, code: 'fs:not_found' };
      const prefix = path + '/';
      for (const p of Object.keys(cur.entries)) {
        if (p === path || p.startsWith(prefix)) delete cur.entries[p];
      }
      return { ok: true, state: cur, events: [{ topic: 'fs.delete', payload: { path } }] };
    }

    if (action === 'resolveConflict') {
      const conflictPath = normalizePath(input.conflictPath);
      if (!conflictPath || !cur.entries[conflictPath] || !cur.entries[conflictPath].conflictOf) {
        return { ok: false, code: 'fs:conflict_not_found' };
      }
      const conflictEntry = cur.entries[conflictPath];
      const originalPath = conflictEntry.conflictOf;
      const strategy = input.strategy || 'keep_original';
      if (strategy === 'keep_original') {
        delete cur.entries[conflictPath];
      } else if (strategy === 'replace_original') {
        const prev = cur.entries[originalPath];
        const nextVersion = prev ? (Number(prev.version) || 0) + 1 : 1;
        delete cur.entries[conflictPath];
        const { conflictOf: _drop, ...clean } = conflictEntry;
        cur.entries[originalPath] = { ...clean, path: originalPath, version: nextVersion, opId: tx.opId, updatedBy: tx.author, updatedAtMs: nowMs };
      } else if (strategy === 'keep_both') {
        const { conflictOf: _drop, ...clean } = conflictEntry;
        cur.entries[conflictPath] = clean;
      } else {
        return { ok: false, code: 'fs:invalid_strategy' };
      }
      return { ok: true, state: cur, events: [{ topic: 'fs.conflict_resolved', payload: { conflictPath, originalPath, strategy } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },

  query(state, input) {
    const cur = normalizeFs(state);
    const q = input && typeof input === 'object' ? input : {};
    const kind = q.query || q.kind || 'list';
    if (kind === 'stat') {
      const p = normalizePath(q.path || '/');
      return p ? (cur.entries[p] || null) : null;
    }
    if (kind === 'conflicts') {
      const conflicts = Object.values(cur.entries).filter(e => e.kind === 'file' && e.conflictOf);
      conflicts.sort((a, b) => (a.path < b.path ? -1 : 1));
      return { conflicts };
    }
    if (kind === 'tree') {
      const entries = Object.values(cur.entries).sort((a, b) => (a.path < b.path ? -1 : 1));
      return { entries };
    }
    const dir = normalizePath(q.path || '/');
    if (!dir) return { entries: [] };
    const entries = Object.values(cur.entries)
      .filter(e => e.path !== '/' && parentPath(e.path) === dir)
      .sort((a, b) => (a.kind !== b.kind ? (a.kind === 'dir' ? -1 : 1) : (a.path < b.path ? -1 : 1)));
    return { path: dir, entries };
  },

  describe() {
    const optStr = { anyOf: [{ type: 'string' }, { type: 'null' }] };
    const optRef = { anyOf: [{ type: 'object', properties: {} }, { type: 'string' }, { type: 'null' }] };
    return {
      commands: [
        { name: 'mkdir', description: 'Create a directory.', input: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } },
        { name: 'writeFile', description: 'Write file metadata and content ref (auto-forks on concurrent version mismatch).', input: { type: 'object', properties: { path: { type: 'string' }, ref: optRef, bytes: { type: 'integer' }, mediaType: { type: 'string' }, expectedOpId: optStr }, required: ['path'] } },
        { name: 'move', description: 'Move or rename a file or directory.', input: { type: 'object', properties: { from: { type: 'string' }, to: { type: 'string' } }, required: ['from', 'to'] } },
        { name: 'delete', description: 'Delete a file or directory recursively.', input: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } },
        { name: 'resolveConflict', description: 'Resolve an auto-forked conflict file.', input: { type: 'object', properties: { conflictPath: { type: 'string' }, strategy: { type: 'string', enum: ['keep_original', 'replace_original', 'keep_both'] } }, required: ['conflictPath'] } },
      ],
      queries: [
        { name: 'list', description: 'List entries in a directory.', input: { type: 'object', properties: { path: { type: 'string' } } } },
        { name: 'stat', description: 'Inspect metadata and history for a path.', input: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } },
        { name: 'conflicts', description: 'List unresolved conflict forks.', input: { type: 'object', properties: {} } },
        { name: 'tree', description: 'List the entire directory tree.', input: { type: 'object', properties: {} } },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/mounts.ts
var STD_MOUNTS_SOURCE = `
import { verifyEd25519, canonicalJson } from 'chronolog:crypto';

const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;

function isAdmin(ctx, actor) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === actor && m.administrator === true));
}

export const verifiedMounts = {
  reduce(state, tx, ctx) {
    const cur = state && typeof state === 'object' && state.mounts && typeof state.mounts === 'object'
      ? { mounts: { ...state.mounts } }
      : { mounts: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_mount_input' };
    const action = input.action || 'update';
    const name = typeof input.name === 'string' ? input.name.trim() : '';
    if (!name || name.length > 128) return { ok: false, code: 'invalid_mount_name' };

    if (action === 'remove') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      delete cur.mounts[name];
      return { ok: true, state: cur, events: [{ topic: '$mounts.removed', payload: { name } }] };
    }

    if (action === 'configure') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      if (typeof input.logId !== 'string' || !HEX32.test(input.logId)) return { ok: false, code: 'invalid_log_id' };
      const signers = Array.isArray(input.trustedSigners)
        ? Array.from(new Set(input.trustedSigners.filter(k => typeof k === 'string' && HEX32.test(k)))).sort()
        : [];
      const prev = cur.mounts[name] || null;
      cur.mounts[name] = {
        logId: input.logId,
        stateRoot: prev ? prev.stateRoot : null,
        topics: prev ? prev.topics : {},
        casRoots: prev ? prev.casRoots : [],
        trustedSigners: signers,
        attestedBy: prev ? prev.attestedBy : null,
        updatedAtMs: tx.authorTimestampMs,
      };
      return { ok: true, state: cur, events: [{ topic: '$mounts.configured', payload: { name, logId: input.logId } }] };
    }

    if (action === 'update') {
      const prev = cur.mounts[name] || null;
      const logId = typeof input.logId === 'string' ? input.logId : (prev ? prev.logId : '');
      const stateRoot = typeof input.stateRoot === 'string' ? input.stateRoot : '';
      const topics = input.topics && typeof input.topics === 'object' && !Array.isArray(input.topics) ? input.topics : null;
      if (!HEX32.test(logId) || !HEX32.test(stateRoot) || !topics) {
        return { ok: false, code: 'invalid_mount_snapshot' };
      }
      if (prev && prev.logId !== logId) return { ok: false, code: 'mount_log_id_mismatch' };
      const trustedSigners = Array.isArray(input.trustedSigners) && isAdmin(ctx, tx.author)
        ? Array.from(new Set(input.trustedSigners.filter(k => typeof k === 'string' && HEX32.test(k)))).sort()
        : (prev && Array.isArray(prev.trustedSigners) ? prev.trustedSigners : []);

      let attestedBy = null;
      if (typeof input.signer === 'string' && typeof input.signature === 'string') {
        if (!HEX32.test(input.signer) || !HEX64.test(input.signature)) {
          return { ok: false, code: 'invalid_mount_signature' };
        }
        if (trustedSigners.length > 0 && !trustedSigners.includes(input.signer)) {
          return { ok: false, code: 'untrusted_mount_signer' };
        }
        const msg = 'chronolog/mount/v1:' + canonicalJson({ logId, stateRoot, topics });
        if (!verifyEd25519(input.signer, msg, input.signature)) {
          return { ok: false, code: 'mount_signature_failed' };
        }
        attestedBy = input.signer;
      } else if (!isAdmin(ctx, tx.author)) {
        return { ok: false, code: 'mount_authorization_required' };
      }

      const casRoots = Array.isArray(input.casRoots)
        ? Array.from(new Set(input.casRoots.filter(h => typeof h === 'string' && (HEX32.test(h) || /^cas:sha256-[0-9a-f]{64}$/.test(h))))).sort()
        : [];
      cur.mounts[name] = {
        logId,
        stateRoot,
        topics,
        casRoots,
        trustedSigners,
        attestedBy,
        updatedAtMs: tx.authorTimestampMs,
      };
      return {
        ok: true,
        state: cur,
        events: [{ topic: '$mounts.updated', payload: { name, logId, stateRoot, attestedBy } }],
      };
    }

    return { ok: false, code: 'unknown_mount_action' };
  },
  query(state, input) {
    const mounts = state && typeof state === 'object' && state.mounts && typeof state.mounts === 'object' ? state.mounts : {};
    if (input && typeof input === 'object' && typeof input.name === 'string') {
      return Object.prototype.hasOwnProperty.call(mounts, input.name) ? mounts[input.name] : null;
    }
    return { mounts };
  },
};
`.trimStart();

// packages/materializer/src/std/builders.ts
var STD_BUILDERS_SOURCE = `
import { verifyEd25519, canonicalJson } from 'chronolog:crypto';

const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;
const CAS_REF = /^cas:sha256-[0-9a-f]{64}$/;

function isAdmin(ctx, actor) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === actor && m.administrator === true));
}

function uniqueSortedHex(list) {
  return Array.from(new Set((Array.isArray(list) ? list : []).filter(k => typeof k === 'string' && HEX32.test(k)))).sort();
}

function verifyAttestation(att) {
  if (!att || typeof att !== 'object') return false;
  if (!att.payload || typeof att.payload !== 'object') return false;
  if (att.payload.format !== 'chronolog-attestation/v1') return false;
  if (typeof att.signer !== 'string' || !HEX32.test(att.signer)) return false;
  if (typeof att.signature !== 'string' || !HEX64.test(att.signature)) return false;
  const msg = 'chronolog/attestation/v1:' + canonicalJson(att.payload);
  return verifyEd25519(att.signer, msg, att.signature);
}

export const attestedBuilders = {
  reduce(state, tx, ctx) {
    if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
    const cur = state && typeof state === 'object'
      ? {
          builders: uniqueSortedHex(state.builders),
          auditors: uniqueSortedHex(state.auditors),
          threshold: typeof state.threshold === 'number' && state.threshold >= 1 ? Math.floor(state.threshold) : 1,
          requireAudit: Boolean(state.requireAudit),
          requireMountApproval: typeof state.requireMountApproval === 'string' ? state.requireMountApproval : null,
        }
      : { builders: [], auditors: [], threshold: 1, requireAudit: false, requireMountApproval: null };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_builders_input' };
    const next = { ...cur };
    if (Array.isArray(input.builders)) next.builders = uniqueSortedHex(input.builders);
    if (Array.isArray(input.auditors)) next.auditors = uniqueSortedHex(input.auditors);
    if (typeof input.threshold === 'number' && Number.isInteger(input.threshold) && input.threshold >= 1) {
      next.threshold = input.threshold;
    }
    if (typeof input.requireAudit === 'boolean') next.requireAudit = input.requireAudit;
    if (input.requireMountApproval === null || typeof input.requireMountApproval === 'string') {
      next.requireMountApproval = input.requireMountApproval;
    }
    return { ok: true, state: next, events: [{ topic: '$builders.updated', payload: { threshold: next.threshold } }] };
  },
  query(state) {
    return state || { builders: [], auditors: [], threshold: 1, requireAudit: false, requireMountApproval: null };
  },
};

/**
 * Governed $reducers policy that accepts upgrades either from an administrator
 * OR via M-of-N verified chronolog-attestation/v1 build/audit receipts from $builders
 * (and optional verification against a mounted Registry Chronolog via ctx.mountQuery).
 */
export const attestedReducers = {
  reduce(state, tx, ctx) {
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const admin = isAdmin(ctx, tx.author);
    const buildersCfg = ctx.topic('$builders');
    const builders = buildersCfg && Array.isArray(buildersCfg.builders) ? buildersCfg.builders : [];
    const auditors = buildersCfg && Array.isArray(buildersCfg.auditors) ? buildersCfg.auditors : [];
    const threshold = buildersCfg && typeof buildersCfg.threshold === 'number' && buildersCfg.threshold >= 1
      ? buildersCfg.threshold
      : 1;
    const requireAudit = Boolean(buildersCfg && buildersCfg.requireAudit);
    const requireMount = buildersCfg && typeof buildersCfg.requireMountApproval === 'string'
      ? buildersCfg.requireMountApproval
      : null;

    const newRefs = [];
    if (input.imports && typeof input.imports === 'object') {
      for (const [, v] of Object.entries(input.imports)) {
        if (typeof v === 'string' && CAS_REF.test(v)) newRefs.push(v);
      }
    }

    // If a mounted Registry approval policy is configured, verify every added/updated ref exists in the mount!
    if (requireMount && newRefs.length > 0) {
      for (const ref of newRefs) {
        const found = ctx.mountQuery(requireMount, 'packages', { query: 'resolveByHash', pkgRef: ref });
        if (!found || found.revoked) {
          return { ok: false, code: 'mount_approval_required', detail: 'Package not approved in mount ' + requireMount + ': ' + ref };
        }
      }
    }

    if (!admin) {
      if (builders.length === 0 || newRefs.length === 0) {
        return { ok: false, code: 'admin_or_attestation_required' };
      }
      const attestations = Array.isArray(input.attestations) ? input.attestations : [];
      for (const ref of newRefs) {
        const buildSigners = new Set();
        const auditSigners = new Set();
        for (const att of attestations) {
          if (!verifyAttestation(att)) continue;
          if (att.payload.kind === 'build' && att.payload.outputRef === ref && builders.includes(att.signer)) {
            buildSigners.add(att.signer);
          }
          if (att.payload.kind === 'audit' && att.payload.pkgRef === ref && att.payload.verdict === 'approved' && auditors.includes(att.signer)) {
            auditSigners.add(att.signer);
          }
        }
        if (buildSigners.size < threshold) {
          return { ok: false, code: 'build_attestation_threshold_unmet', detail: 'Need ' + threshold + ' builder attestations for ' + ref };
        }
        if (requireAudit && auditSigners.size < 1) {
          return { ok: false, code: 'audit_attestation_required', detail: 'Need approved auditor attestation for ' + ref };
        }
      }
    }

    const next = {
      runtime: state.runtime,
      imports: { ...(state.imports || {}) },
      topics: { ...(state.topics || {}) },
    };
    if (input.imports && typeof input.imports === 'object') {
      for (const [k, v] of Object.entries(input.imports)) {
        if (v === null) delete next.imports[k];
        else next.imports[k] = v;
      }
    }
    if (input.topics && typeof input.topics === 'object') {
      for (const [k, v] of Object.entries(input.topics)) {
        if (v === null) delete next.topics[k];
        else next.topics[k] = v;
      }
    }
    return {
      ok: true,
      state: next,
      events: [{ topic: '$reducers.updated', payload: { author: tx.author, attested: !admin } }],
    };
  },
};
`.trimStart();

// packages/materializer/src/std/registry.ts
var STD_REGISTRY_SOURCE = `
import { openDb } from 'chronolog:sqlite';
import { verifyEd25519, canonicalJson, sha256 } from 'chronolog:crypto';

const CAS_REF = /^cas:sha256-[0-9a-f]{64}$/;
const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;

function isWriter(ctx, actor) {
  const checked = ctx.query('$permissions', { check: 'writer', actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === actor && m.writer === true));
}

function isAdmin(ctx, actor) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === actor && m.administrator === true));
}

function ensureSchema(db) {
  db.exec(\`
    CREATE TABLE IF NOT EXISTS packages (
      name TEXT PRIMARY KEY,
      description TEXT NOT NULL DEFAULT '',
      latest_version TEXT NOT NULL,
      publisher TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS versions (
      name TEXT NOT NULL,
      version TEXT NOT NULL,
      pkg_ref TEXT NOT NULL,
      drv_ref TEXT,
      runtime TEXT NOT NULL,
      builtins_json TEXT NOT NULL DEFAULT '[]',
      describe_json TEXT,
      publisher TEXT NOT NULL,
      published_at INTEGER NOT NULL,
      revoked INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (name, version)
    );
    CREATE INDEX IF NOT EXISTS idx_versions_pkg_ref ON versions(pkg_ref);
    CREATE TABLE IF NOT EXISTS attestations (
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL,
      target_ref TEXT NOT NULL,
      drv_ref TEXT,
      verdict TEXT,
      runtime TEXT,
      signer TEXT NOT NULL,
      signature TEXT NOT NULL,
      notes TEXT,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_attestations_target ON attestations(target_ref);
    CREATE VIRTUAL TABLE IF NOT EXISTS packages_fts USING fts5(name, description);
  \`, [], { mode: 'admin' });
}

function withDb(dbRoot, fn) {
  const db = openDb(dbRoot || null);
  try {
    return fn(db);
  } finally {
    db.close();
  }
}

export const packageRegistry = {
  reduce(state, tx, ctx) {
    if (!isWriter(ctx, tx.author)) return { ok: false, code: 'writer_required' };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_registry_input' };
    const curRoot = state && typeof state === 'object' && typeof state.dbRoot === 'string' ? state.dbRoot : null;

    return withDb(curRoot, db => {
      ensureSchema(db);
      const action = input.action;

      if (action === 'publish') {
        const name = typeof input.name === 'string' ? input.name.trim() : '';
        const version = typeof input.version === 'string' ? input.version.trim() : '';
        const pkgRef = typeof input.pkgRef === 'string' ? input.pkgRef : '';
        const drvRef = typeof input.drvRef === 'string' && CAS_REF.test(input.drvRef) ? input.drvRef : null;
        const runtime = typeof input.runtime === 'string' ? input.runtime : 'esm-quickjs';
        const description = typeof input.description === 'string' ? input.description : '';
        const builtins = Array.isArray(input.builtins) ? input.builtins.filter(b => typeof b === 'string').sort() : [];
        const describeJson = input.describeSchema !== undefined ? JSON.stringify(input.describeSchema) : null;
        if (!name || name.length > 256 || !version || version.length > 128 || !CAS_REF.test(pkgRef)) {
          return { ok: false, code: 'invalid_package_release' };
        }
        const existingPkg = db.query('SELECT publisher FROM packages WHERE name = ?', [name]);
        if (existingPkg.rows.length > 0 && existingPkg.rows[0][0] !== tx.author && !isAdmin(ctx, tx.author)) {
          return { ok: false, code: 'package_owner_mismatch' };
        }
        const existingVer = db.query('SELECT pkg_ref FROM versions WHERE name = ? AND version = ?', [name, version]);
        if (existingVer.rows.length > 0) {
          return { ok: false, code: 'version_already_exists' };
        }
        db.exec(
          'INSERT INTO versions(name, version, pkg_ref, drv_ref, runtime, builtins_json, describe_json, publisher, published_at, revoked) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, 0)',
          [name, version, pkgRef, drvRef, runtime, JSON.stringify(builtins), describeJson, tx.author, tx.authorTimestampMs],
          { mode: 'admin' },
        );
        db.exec(
          'INSERT INTO packages(name, description, latest_version, publisher, updated_at) VALUES(?, ?, ?, ?, ?) ON CONFLICT(name) DO UPDATE SET description = excluded.description, latest_version = excluded.latest_version, updated_at = excluded.updated_at',
          [name, description, version, tx.author, tx.authorTimestampMs],
          { mode: 'admin' },
        );
        db.exec('DELETE FROM packages_fts WHERE name = ?', [name], { mode: 'admin' });
        db.exec('INSERT INTO packages_fts(name, description) VALUES(?, ?)', [name, description], { mode: 'admin' });
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { dbRoot },
          events: [{ topic: 'registry.published', payload: { name, version, pkgRef, drvRef } }],
        };
      }

      if (action === 'attest') {
        const att = input.attestation;
        if (!att || typeof att !== 'object' || !att.payload || typeof att.payload !== 'object') {
          return { ok: false, code: 'invalid_attestation' };
        }
        if (att.payload.format !== 'chronolog-attestation/v1') return { ok: false, code: 'invalid_attestation_format' };
        if (typeof att.signer !== 'string' || !HEX32.test(att.signer) || typeof att.signature !== 'string' || !HEX64.test(att.signature)) {
          return { ok: false, code: 'invalid_attestation_signature' };
        }
        const msg = 'chronolog/attestation/v1:' + canonicalJson(att.payload);
        if (!verifyEd25519(att.signer, msg, att.signature)) {
          return { ok: false, code: 'attestation_signature_failed' };
        }
        const kind = att.payload.kind;
        let targetRef = '';
        let drvRef = null;
        let verdict = null;
        let runtime = null;
        let notes = null;
        if (kind === 'build') {
          targetRef = typeof att.payload.outputRef === 'string' ? att.payload.outputRef : '';
          drvRef = typeof att.payload.drvRef === 'string' ? att.payload.drvRef : null;
          runtime = typeof att.payload.runtime === 'string' ? att.payload.runtime : null;
        } else if (kind === 'audit') {
          targetRef = typeof att.payload.pkgRef === 'string' ? att.payload.pkgRef : '';
          verdict = typeof att.payload.verdict === 'string' ? att.payload.verdict : null;
          notes = typeof att.payload.notes === 'string' ? att.payload.notes : null;
        } else {
          return { ok: false, code: 'unknown_attestation_kind' };
        }
        if (!CAS_REF.test(targetRef)) return { ok: false, code: 'invalid_attestation_target' };
        const id = sha256(att.signer + ':' + msg);
        db.exec(
          'INSERT OR IGNORE INTO attestations(id, kind, target_ref, drv_ref, verdict, runtime, signer, signature, notes, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [id, kind, targetRef, drvRef, verdict, runtime, att.signer, att.signature, notes, tx.authorTimestampMs],
          { mode: 'admin' },
        );
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { dbRoot },
          events: [{ topic: 'registry.attested', payload: { kind, targetRef, signer: att.signer } }],
        };
      }

      if (action === 'revoke') {
        const name = typeof input.name === 'string' ? input.name.trim() : '';
        const version = typeof input.version === 'string' ? input.version.trim() : '';
        const existing = db.query('SELECT publisher FROM versions WHERE name = ? AND version = ?', [name, version]);
        if (existing.rows.length === 0) return { ok: false, code: 'version_not_found' };
        if (existing.rows[0][0] !== tx.author && !isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_or_owner_required' };
        db.exec('UPDATE versions SET revoked = 1 WHERE name = ? AND version = ?', [name, version], { mode: 'admin' });
        const dbRoot = db.commit();
        return { ok: true, state: { dbRoot }, events: [{ topic: 'registry.revoked', payload: { name, version } }] };
      }

      return { ok: false, code: 'unknown_registry_action' };
    });
  },
  query(state, input) {
    const curRoot = state && typeof state === 'object' && typeof state.dbRoot === 'string' ? state.dbRoot : null;
    if (!curRoot) return input && input.query === 'resolve' ? null : [];
    const req = input && typeof input === 'object' ? input : { query: 'list' };

    return withDb(curRoot, db => {
      const q = req.query || 'list';
      if (q === 'search') {
        const term = typeof req.q === 'string' ? req.q.trim() : '';
        const limit = typeof req.limit === 'number' && req.limit > 0 ? Math.min(100, Math.floor(req.limit)) : 25;
        if (!term) {
          const all = db.query('SELECT name, description, latest_version, publisher, updated_at FROM packages ORDER BY name LIMIT ?', [limit]);
          return all.rows.map(r => ({ name: r[0], description: r[1], latestVersion: r[2], publisher: r[3], updatedAt: r[4] }));
        }
        let rows = [];
        try {
          const fts = db.query(
            'SELECT p.name, p.description, p.latest_version, p.publisher, p.updated_at FROM packages_fts f JOIN packages p ON p.name = f.name WHERE packages_fts MATCH ? LIMIT ?',
            [term, limit],
          );
          rows = fts.rows;
        } catch {
          const like = '%' + term + '%';
          rows = db.query(
            'SELECT name, description, latest_version, publisher, updated_at FROM packages WHERE name LIKE ? OR description LIKE ? ORDER BY name LIMIT ?',
            [like, like, limit],
          ).rows;
        }
        return rows.map(r => ({ name: r[0], description: r[1], latestVersion: r[2], publisher: r[3], updatedAt: r[4] }));
      }

      if (q === 'resolve') {
        const name = typeof req.name === 'string' ? req.name : '';
        const version = typeof req.version === 'string' && req.version.length > 0 ? req.version : null;
        const sql = version
          ? 'SELECT name, version, pkg_ref, drv_ref, runtime, builtins_json, describe_json, publisher, published_at, revoked FROM versions WHERE name = ? AND version = ? LIMIT 1'
          : 'SELECT v.name, v.version, v.pkg_ref, v.drv_ref, v.runtime, v.builtins_json, v.describe_json, v.publisher, v.published_at, v.revoked FROM packages p JOIN versions v ON v.name = p.name AND v.version = p.latest_version WHERE p.name = ? LIMIT 1';
        const res = db.query(sql, version ? [name, version] : [name]);
        if (res.rows.length === 0) return null;
        const r = res.rows[0];
        const att = db.query('SELECT kind, verdict, signer, signature, drv_ref, runtime, notes FROM attestations WHERE target_ref = ? ORDER BY created_at ASC', [r[2]]);
        return {
          name: r[0],
          version: r[1],
          pkgRef: r[2],
          drvRef: r[3],
          runtime: r[4],
          builtins: JSON.parse(r[5]),
          describeSchema: r[6] ? JSON.parse(r[6]) : null,
          publisher: r[7],
          publishedAt: r[8],
          revoked: Boolean(r[9]),
          attestations: att.rows.map(a => ({ kind: a[0], verdict: a[1], signer: a[2], signature: a[3], drvRef: a[4], runtime: a[5], notes: a[6] })),
        };
      }

      if (q === 'resolveByHash') {
        const pkgRef = typeof req.pkgRef === 'string' ? req.pkgRef : '';
        const res = db.query(
          'SELECT name, version, pkg_ref, drv_ref, runtime, builtins_json, publisher, published_at, revoked FROM versions WHERE pkg_ref = ? LIMIT 1',
          [pkgRef],
        );
        if (res.rows.length === 0) return null;
        const r = res.rows[0];
        const att = db.query('SELECT kind, verdict, signer FROM attestations WHERE target_ref = ?', [pkgRef]);
        return {
          name: r[0],
          version: r[1],
          pkgRef: r[2],
          drvRef: r[3],
          runtime: r[4],
          builtins: JSON.parse(r[5]),
          publisher: r[6],
          publishedAt: r[7],
          revoked: Boolean(r[8]),
          buildAttestations: att.rows.filter(a => a[0] === 'build').length,
          approvedAudits: att.rows.filter(a => a[0] === 'audit' && a[1] === 'approved').length,
        };
      }

      if (q === 'attestations') {
        const targetRef = typeof req.targetRef === 'string' ? req.targetRef : '';
        const res = db.query('SELECT id, kind, target_ref, drv_ref, verdict, runtime, signer, signature, notes, created_at FROM attestations WHERE target_ref = ? ORDER BY created_at ASC', [targetRef]);
        return res.rows.map(a => ({ id: a[0], kind: a[1], targetRef: a[2], drvRef: a[3], verdict: a[4], runtime: a[5], signer: a[6], signature: a[7], notes: a[8], createdAt: a[9] }));
      }

      const limit = typeof req.limit === 'number' && req.limit > 0 ? Math.min(200, Math.floor(req.limit)) : 50;
      const all = db.query('SELECT name, description, latest_version, publisher, updated_at FROM packages ORDER BY name LIMIT ?', [limit]);
      return all.rows.map(r => ({ name: r[0], description: r[1], latestVersion: r[2], publisher: r[3], updatedAt: r[4] }));
    });
  },
  describe() {
    return {
      commands: [
        { name: 'publish', description: 'Publish a content-addressed package release (pkgRef + optional drvRef).' },
        { name: 'attest', description: 'Record a signed Ed25519 reproducible-build or security audit attestation.' },
        { name: 'revoke', description: 'Revoke a published package version.' },
      ],
      queries: [
        { name: 'search', description: 'Full-text search packages via SQLite FTS5.' },
        { name: 'resolve', description: 'Resolve package name/version to its CAS root and attestations.' },
        { name: 'resolveByHash', description: 'Look up package provenance and attestations by cas:sha256-... root.' },
        { name: 'attestations', description: 'List verified attestations for a package CAS root.' },
        { name: 'list', description: 'List published packages.' },
      ],
    };
  },
};
`.trimStart();

// packages/materializer/src/std-stdlib-extra.ts
var STD_FINALITY_PREDICATES_SOURCE = `
import { canonicalJson, sha256, verifyEd25519 } from 'chronolog:crypto';

const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;

function canonicalCheckpointMessage(payload) {
  return canonicalJson(['chronolog/finality-predicate/v1', payload]);
}

function verifySigEntry(entry, payload) {
  if (!entry || typeof entry !== 'object') return false;
  if (typeof entry.signer !== 'string' || !HEX32.test(entry.signer)) return false;
  if (typeof entry.signature !== 'string' || !HEX64.test(entry.signature)) return false;
  return verifyEd25519(entry.signer, canonicalCheckpointMessage(payload), entry.signature);
}

/** Single-signer programmable finality predicate (config: { signer: 64-hex }). */
export const signedFrontierPredicate = {
  query(state, input, ctx) {
    const cfg = (input && input.policy && input.policy.config) || ctx.config || {};
    const cp = input && input.checkpoint;
    if (!cp || !cp.payload || !cp.attestation || typeof cfg.signer !== 'string' || !HEX32.test(cfg.signer)) {
      return { admitted: false, reason: 'invalid_input' };
    }
    const data = cp.attestation.kind === 'evidence' ? cp.attestation.data : cp.attestation;
    const sigs = Array.isArray(data && data.signatures) ? data.signatures : (data && data.signer ? [data] : []);
    for (const s of sigs) {
      if (s && s.signer === cfg.signer && verifySigEntry(s, cp.payload)) {
        return { admitted: true, signer: cfg.signer };
      }
    }
    return { admitted: false, reason: 'signature_missing_or_invalid' };
  },
};

/**
 * Weighted or M-of-N validator quorum predicate.
 * config: { validators: string[] | Record<string, number>, threshold: number }
 */
export const thresholdQuorumPredicate = {
  query(state, input, ctx) {
    const cfg = (input && input.policy && input.policy.config) || ctx.config || {};
    const cp = input && input.checkpoint;
    if (!cp || !cp.payload || !cp.attestation) return { admitted: false, reason: 'invalid_input' };
    const threshold = Number(cfg.threshold || 1);
    if (!Number.isFinite(threshold) || threshold < 1) return { admitted: false, reason: 'invalid_threshold' };

    const weights = {};
    if (Array.isArray(cfg.validators)) {
      for (const v of cfg.validators) if (typeof v === 'string' && HEX32.test(v)) weights[v] = 1;
    } else if (cfg.validators && typeof cfg.validators === 'object') {
      for (const [k, w] of Object.entries(cfg.validators)) {
        if (HEX32.test(k) && typeof w === 'number' && Number.isFinite(w) && w > 0) weights[k] = w;
      }
    }

    const data = cp.attestation.kind === 'evidence' ? cp.attestation.data : cp.attestation;
    const sigs = Array.isArray(data && data.signatures) ? data.signatures : [];
    const seen = new Set();
    let total = 0;
    for (const s of sigs) {
      if (!s || typeof s.signer !== 'string' || !Object.prototype.hasOwnProperty.call(weights, s.signer)) continue;
      if (seen.has(s.signer)) continue;
      if (verifySigEntry(s, cp.payload)) {
        seen.add(s.signer);
        total += weights[s.signer];
      }
    }
    return { admitted: total >= threshold, weight: total, threshold };
  },
};

/**
 * Optimistic challenge-window predicate:
 * Admits a signed checkpoint once an attested observation timestamp >= closedThroughMs + challengeWindowMs,
 * UNLESS a valid signed fraud/challenge counter-proof is present in attestation.data.challenges.
 * config: { proposers: string[], challengers?: string[], challengeWindowMs: number }
 */
export const optimisticChallengePredicate = {
  query(state, input, ctx) {
    const cfg = (input && input.policy && input.policy.config) || ctx.config || {};
    const cp = input && input.checkpoint;
    if (!cp || !cp.payload || !cp.attestation || cp.attestation.kind !== 'evidence') {
      return { admitted: false, reason: 'evidence_required' };
    }
    const data = cp.attestation.data || {};
    const proposers = Array.isArray(cfg.proposers) ? cfg.proposers : [];
    const challengers = Array.isArray(cfg.challengers) ? cfg.challengers : proposers;
    const windowMs = Number(cfg.challengeWindowMs || 0);
    const closedMs = Number(cp.payload.closedThroughMs || 0);
    const observedMs = Number(data.observedAtMs || 0);
    if (!Number.isFinite(observedMs) || observedMs < closedMs + windowMs) {
      return { admitted: false, reason: 'challenge_window_open' };
    }
    const proposal = data.proposal;
    if (!proposal || !proposers.includes(proposal.signer) || !verifySigEntry(proposal, cp.payload)) {
      return { admitted: false, reason: 'invalid_proposal_signature' };
    }
    const challenges = Array.isArray(data.challenges) ? data.challenges : [];
    for (const ch of challenges) {
      if (!ch || !challengers.includes(ch.signer) || typeof ch.signature !== 'string' || !HEX64.test(ch.signature)) continue;
      const challengeMsg = canonicalJson(['chronolog/finality-challenge/v1', cp.payload.logId, cp.payload.policyScopeId, cp.payload.closedThroughMs, ch.reason || 'fraud']);
      if (verifyEd25519(ch.signer, challengeMsg, ch.signature)) {
        return { admitted: false, challenged: true, challenger: ch.signer, reason: ch.reason || 'fraud' };
      }
    }
    return { admitted: true, proposer: proposal.signer };
  },
};

/**
 * External Merkle-anchor predicate:
 * Verifies a SHA-256 Merkle inclusion proof tying sha256(canonicalJson(checkpoint.payload))
 * into a root signed by a trusted anchor oracle (or pinned in config.trustedRoots).
 * config: { anchorSigners?: string[], trustedRoots?: string[] }
 */
export const merkleAnchorPredicate = {
  query(state, input, ctx) {
    const cfg = (input && input.policy && input.policy.config) || ctx.config || {};
    const cp = input && input.checkpoint;
    if (!cp || !cp.payload || !cp.attestation || cp.attestation.kind !== 'evidence') {
      return { admitted: false, reason: 'evidence_required' };
    }
    const data = cp.attestation.data || {};
    const root = data.root;
    const proof = Array.isArray(data.proof) ? data.proof : null;
    if (typeof root !== 'string' || !HEX32.test(root) || !proof || proof.length > 64) {
      return { admitted: false, reason: 'invalid_merkle_proof' };
    }
    let cur = sha256(canonicalCheckpointMessage(cp.payload));
    for (const step of proof) {
      if (!step || typeof step.sibling !== 'string' || !HEX32.test(step.sibling)) {
        return { admitted: false, reason: 'invalid_merkle_step' };
      }
      cur = step.position === 'left'
        ? sha256(step.sibling + cur)
        : sha256(cur + step.sibling);
    }
    if (cur !== root) return { admitted: false, reason: 'merkle_root_mismatch' };
    const trustedRoots = Array.isArray(cfg.trustedRoots) ? cfg.trustedRoots : [];
    if (trustedRoots.includes(root)) return { admitted: true, root };
    const signers = Array.isArray(cfg.anchorSigners) ? cfg.anchorSigners : [];
    const anchorSig = data.anchorSignature;
    if (anchorSig && signers.includes(anchorSig.signer) && HEX64.test(anchorSig.signature || '')) {
      const msg = canonicalJson(['chronolog/merkle-anchor/v1', root]);
      if (verifyEd25519(anchorSig.signer, msg, anchorSig.signature)) {
        return { admitted: true, root, anchorSigner: anchorSig.signer };
      }
    }
    return { admitted: false, reason: 'untrusted_anchor_root' };
  },
};

export default thresholdQuorumPredicate;
`.trimStart();
var STD_GUARDS_SOURCE = `
/**
 * Composable pre/post condition standard library for JS & SQL reducers.
 */

export function requireAuthorChain(ctx, tx, expectedLastOpId) {
  const actual = typeof ctx.authorLastOpId === 'function' ? ctx.authorLastOpId(tx.author) : null;
  if (actual !== expectedLastOpId) {
    return {
      ok: false,
      code: 'guard:author_history_mismatch',
      detail: 'Author ' + tx.author + ' expected last op ' + String(expectedLastOpId) + ', got ' + String(actual),
    };
  }
  return { ok: true };
}

export function requireOpsAccepted(ctx, opIds) {
  if (!Array.isArray(opIds)) return { ok: true };
  for (const id of opIds) {
    const st = typeof ctx.opOutcome === 'function' ? ctx.opOutcome(id) : null;
    if (st === null) return { ok: false, code: 'guard:missing_op', detail: 'Required op ' + id + ' not present' };
    if (st !== 'accepted') return { ok: false, code: 'guard:op_rejected', detail: 'Required op ' + id + ' was rejected' };
  }
  return { ok: true };
}

export function requireTopicVersion(ctx, topic, expectedLastOpId) {
  const actual = typeof ctx.topicLastOpId === 'function' ? ctx.topicLastOpId(topic) : null;
  if (actual !== expectedLastOpId) {
    return {
      ok: false,
      code: 'guard:topic_modified',
      detail: 'Topic ' + topic + ' expected last op ' + String(expectedLastOpId) + ', got ' + String(actual),
    };
  }
  return { ok: true };
}

export function checkPostInvariant(predicate, nextState, tx, ctx, code = 'guard:postcondition_failed', detail = 'Postcondition failed') {
  const res = predicate(nextState, tx, ctx);
  if (res === true) return { ok: true };
  if (res && typeof res === 'object' && res.ok === true) return { ok: true };
  if (res && typeof res === 'object' && res.ok === false) {
    return { ok: false, code: res.code || code, detail: res.detail || detail };
  }
  return { ok: false, code, detail };
}

/**
 * Higher-order reducer wrapper enforcing declarative pre/post conditions around any reducer.
 */
export function guardReducer(reducer, options = {}) {
  const preList = Array.isArray(options.pre) ? options.pre : (options.pre ? [options.pre] : []);
  const postList = Array.isArray(options.post) ? options.post : (options.post ? [options.post] : []);
  return {
    ...reducer,
    reduce(state, tx, ctx) {
      for (const check of preList) {
        const res = check(state, tx, ctx);
        if (res && res.ok === false) return res;
        if (res === false) return { ok: false, code: 'guard:precondition_failed' };
      }
      const out = reducer.reduce(state, tx, ctx);
      if (!out || out.ok !== true) return out;
      for (const check of postList) {
        const res = check(out.state, tx, ctx, state);
        if (res && res.ok === false) return res;
        if (res === false) return { ok: false, code: 'guard:postcondition_failed' };
      }
      return out;
    },
  };
}

/** SQL precondition/postcondition builders compatible with chronolog/sql. */
export function sqlBasedOnRow(table, where, lastOpId, code) {
  return { kind: 'based_on_row', table, where, lastOpId, ...(code ? { code } : {}) };
}

export function sqlRowMatches(table, where, expect, code) {
  return { kind: 'row_matches', table, where, expect, ...(code ? { code } : {}) };
}

export function sqlRequireAuthorLastOp(expectedLastOpId, author, code = 'sql:author_history_mismatch') {
  if (expectedLastOpId === null) {
    return {
      sql: author ? 'SELECT chronolog_author_last_op(?) IS NULL' : 'SELECT chronolog_author_last_op() IS NULL',
      params: author ? [author] : [],
      expect: { firstValue: 1 },
      code,
    };
  }
  return {
    sql: author ? 'SELECT chronolog_author_last_op(?)' : 'SELECT chronolog_author_last_op()',
    params: author ? [author] : [],
    expect: { firstValue: expectedLastOpId },
    code,
  };
}

export function sqlPostInvariant(sql, params = [], expect = { firstValue: 1 }, code = 'sql:postcondition_failed') {
  return { sql, params, expect, code };
}

export default {
  requireAuthorChain,
  requireOpsAccepted,
  requireTopicVersion,
  checkPostInvariant,
  guardReducer,
  sqlBasedOnRow,
  sqlRowMatches,
  sqlRequireAuthorLastOp,
  sqlPostInvariant,
};
`.trimStart();
var STD_QUOTAS_SOURCE = `
/**
 * Deterministic per-author token-bucket rate limiter & quota tracker driven purely by tx.authorTimestampMs.
 * Usable both as a standalone topic reducer AND as a helper inside custom reducers.
 */

export function consumeTokenBucket(buckets, actor, nowMs, { capacity = 60, refillPerSec = 1, cost = 1 } = {}) {
  const cur = (buckets && buckets[actor]) || { tokens: capacity, lastMs: nowMs };
  const elapsedSec = Math.max(0, (nowMs - cur.lastMs) / 1000);
  const replenished = Math.min(capacity, cur.tokens + elapsedSec * refillPerSec);
  if (replenished < cost) {
    return {
      ok: false,
      code: 'quota:rate_limited',
      retryAfterMs: Math.ceil(((cost - replenished) / Math.max(refillPerSec, 0.0001)) * 1000),
      remaining: replenished,
    };
  }
  const nextTokens = replenished - cost;
  return {
    ok: true,
    remaining: nextTokens,
    buckets: { ...(buckets || {}), [actor]: { tokens: nextTokens, lastMs: nowMs } },
  };
}

export const tokenBucketQuotas = {
  reduce(state, tx, ctx) {
    const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
    const cur = state && typeof state === 'object' ? state : { buckets: {}, usage: {} };
    const input = tx.payload || {};
    const action = input.action || 'consume';
    const nowMs = Number(tx.authorTimestampMs || 0);
    if (action === 'consume') {
      const cost = Number(input.cost === undefined ? 1 : input.cost);
      if (!Number.isFinite(cost) || cost <= 0) return { ok: false, code: 'quota:invalid_cost' };
      const res = consumeTokenBucket(cur.buckets, tx.author, nowMs, {
        capacity: Number(cfg.capacity || 60),
        refillPerSec: Number(cfg.refillPerSec || 1),
        cost,
      });
      if (!res.ok) return { ok: false, code: res.code, detail: 'Retry after ' + res.retryAfterMs + 'ms' };
      const prevUsage = Number((cur.usage && cur.usage[tx.author]) || 0);
      return {
        ok: true,
        state: { buckets: res.buckets, usage: { ...(cur.usage || {}), [tx.author]: prevUsage + cost } },
        events: [{ topic: 'quota.consumed', payload: { actor: tx.author, cost, remaining: res.remaining } }],
      };
    }
    return { ok: false, code: 'quota:unknown_action' };
  },
  query(state, input) {
    const cur = state && typeof state === 'object' ? state : { buckets: {}, usage: {} };
    if (input && typeof input.actor === 'string') {
      return {
        bucket: (cur.buckets && cur.buckets[input.actor]) || null,
        usage: Number((cur.usage && cur.usage[input.actor]) || 0),
      };
    }
    return cur;
  },
};

export default tokenBucketQuotas;
`.trimStart();
var STD_QUEUE_SOURCE = `
/**
 * Deterministic CRDT job queue with time-based leases (tx.authorTimestampMs),
 * idempotent claims, retries, and dead-letter queue \u2014 ideal for multi-agent workspaces.
 */

export const jobQueue = {
  reduce(state, tx, ctx) {
    const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
    const defaultLeaseMs = Number(cfg.defaultLeaseMs || 30_000);
    const defaultMaxAttempts = Number(cfg.maxAttempts || 3);
    const cur = state && typeof state === 'object' ? state : { jobs: {} };
    const jobs = { ...(cur.jobs || {}) };
    const input = tx.payload || {};
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = input.action;

    if (action === 'enqueue') {
      const id = String(input.id || tx.operationId || tx.opId);
      if (jobs[id]) return { ok: false, code: 'queue:job_exists' };
      jobs[id] = {
        id,
        kind: String(input.kind || 'default'),
        payload: input.payload === undefined ? null : input.payload,
        status: 'pending',
        attempts: 0,
        maxAttempts: Number(input.maxAttempts || defaultMaxAttempts),
        createdAtMs: nowMs,
        createdBy: tx.author,
        claimedBy: null,
        leaseUntilMs: null,
        result: null,
        lastError: null,
      };
      return { ok: true, state: { jobs }, events: [{ topic: 'queue.enqueued', payload: { id, kind: jobs[id].kind } }] };
    }

    if (action === 'claim') {
      const id = String(input.id || '');
      const job = jobs[id];
      if (!job) return { ok: false, code: 'queue:not_found' };
      const leaseExpired = job.status === 'claimed' && job.leaseUntilMs !== null && nowMs >= job.leaseUntilMs;
      if (job.status !== 'pending' && !leaseExpired) return { ok: false, code: 'queue:already_claimed' };
      const nextAttempts = job.attempts + 1;
      if (nextAttempts > job.maxAttempts) {
        jobs[id] = { ...job, status: 'dead', claimedBy: null, leaseUntilMs: null, lastError: 'max_attempts_exceeded' };
        return { ok: true, state: { jobs }, events: [{ topic: 'queue.dead_letter', payload: { id } }] };
      }
      const leaseMs = Number(input.leaseMs || defaultLeaseMs);
      jobs[id] = { ...job, status: 'claimed', attempts: nextAttempts, claimedBy: tx.author, leaseUntilMs: nowMs + leaseMs };
      return { ok: true, state: { jobs }, events: [{ topic: 'queue.claimed', payload: { id, worker: tx.author, leaseUntilMs: nowMs + leaseMs } }] };
    }

    if (action === 'complete') {
      const id = String(input.id || '');
      const job = jobs[id];
      if (!job) return { ok: false, code: 'queue:not_found' };
      if (job.status !== 'claimed' || job.claimedBy !== tx.author) return { ok: false, code: 'queue:not_lease_holder' };
      jobs[id] = { ...job, status: 'completed', leaseUntilMs: null, completedAtMs: nowMs, result: input.result === undefined ? null : input.result };
      return { ok: true, state: { jobs }, events: [{ topic: 'queue.completed', payload: { id, worker: tx.author } }] };
    }

    if (action === 'fail') {
      const id = String(input.id || '');
      const job = jobs[id];
      if (!job) return { ok: false, code: 'queue:not_found' };
      if (job.status !== 'claimed' || job.claimedBy !== tx.author) return { ok: false, code: 'queue:not_lease_holder' };
      const dead = job.attempts >= job.maxAttempts;
      jobs[id] = {
        ...job,
        status: dead ? 'dead' : 'pending',
        claimedBy: null,
        leaseUntilMs: null,
        lastError: typeof input.error === 'string' ? input.error : 'failed',
      };
      return { ok: true, state: { jobs }, events: [{ topic: dead ? 'queue.dead_letter' : 'queue.requeued', payload: { id } }] };
    }

    return { ok: false, code: 'queue:unknown_action' };
  },
  query(state, input) {
    const jobs = (state && state.jobs) || {};
    const list = Object.values(jobs);
    if (!input || typeof input !== 'object') return list;
    if (typeof input.id === 'string') return jobs[input.id] || null;
    const nowMs = typeof input.nowMs === 'number' ? input.nowMs : null;
    return list.filter(j => {
      if (input.kind && j.kind !== input.kind) return false;
      if (input.status === 'claimable') {
        return j.status === 'pending' || (j.status === 'claimed' && nowMs !== null && j.leaseUntilMs !== null && nowMs >= j.leaseUntilMs);
      }
      if (input.status && j.status !== input.status) return false;
      return true;
    });
  },
};

export default jobQueue;
`.trimStart();
var STD_VOTES_SOURCE = `
/**
 * Deterministic weighted voting, quorum polls, and timelocked decision reducer.
 */

export const weightedVotes = {
  reduce(state, tx) {
    const cur = state && typeof state === 'object' ? state : { polls: {} };
    const polls = { ...(cur.polls || {}) };
    const input = tx.payload || {};
    const nowMs = Number(tx.authorTimestampMs || 0);
    const action = input.action;

    if (action === 'create') {
      const id = String(input.id || tx.operationId || tx.opId);
      if (polls[id]) return { ok: false, code: 'votes:poll_exists' };
      const options = Array.isArray(input.options) ? input.options.map(String) : [];
      if (options.length < 2) return { ok: false, code: 'votes:options_required' };
      polls[id] = {
        id,
        title: String(input.title || id),
        options,
        quorum: Number(input.quorum || 1),
        weights: input.weights && typeof input.weights === 'object' ? input.weights : null,
        closesAtMs: typeof input.closesAtMs === 'number' ? input.closesAtMs : null,
        status: 'open',
        createdBy: tx.author,
        createdAtMs: nowMs,
        ballots: {},
      };
      return { ok: true, state: { polls }, events: [{ topic: 'votes.created', payload: { id } }] };
    }

    if (action === 'cast') {
      const id = String(input.id || '');
      const poll = polls[id];
      if (!poll) return { ok: false, code: 'votes:not_found' };
      if (poll.status !== 'open') return { ok: false, code: 'votes:closed' };
      if (poll.closesAtMs !== null && nowMs > poll.closesAtMs) return { ok: false, code: 'votes:deadline_passed' };
      const choice = String(input.choice || '');
      if (!poll.options.includes(choice)) return { ok: false, code: 'votes:invalid_option' };
      const weight = poll.weights ? Number(poll.weights[tx.author] || 0) : 1;
      if (weight <= 0) return { ok: false, code: 'votes:not_eligible' };
      polls[id] = { ...poll, ballots: { ...poll.ballots, [tx.author]: { choice, weight, atMs: nowMs } } };
      return { ok: true, state: { polls }, events: [{ topic: 'votes.cast', payload: { id, voter: tx.author, choice, weight } }] };
    }

    if (action === 'close') {
      const id = String(input.id || '');
      const poll = polls[id];
      if (!poll) return { ok: false, code: 'votes:not_found' };
      if (poll.status !== 'open') return { ok: false, code: 'votes:already_closed' };
      if (poll.createdBy !== tx.author && (poll.closesAtMs === null || nowMs < poll.closesAtMs)) {
        return { ok: false, code: 'votes:cannot_close_yet' };
      }
      polls[id] = { ...poll, status: 'closed', closedAtMs: nowMs };
      return { ok: true, state: { polls }, events: [{ topic: 'votes.closed', payload: { id } }] };
    }

    return { ok: false, code: 'votes:unknown_action' };
  },
  query(state, input) {
    const polls = (state && state.polls) || {};
    const tally = poll => {
      const counts = Object.fromEntries(poll.options.map(o => [o, 0]));
      let totalWeight = 0;
      for (const b of Object.values(poll.ballots || {})) {
        counts[b.choice] = (counts[b.choice] || 0) + b.weight;
        totalWeight += b.weight;
      }
      let winner = null;
      let best = -1;
      let tied = false;
      for (const [opt, score] of Object.entries(counts)) {
        if (score > best) { best = score; winner = opt; tied = false; }
        else if (score === best) { tied = true; }
      }
      return { ...poll, counts, totalWeight, quorumMet: totalWeight >= poll.quorum, winner: totalWeight >= poll.quorum && !tied ? winner : null };
    };
    if (input && typeof input.id === 'string') {
      const poll = polls[input.id];
      return poll ? tally(poll) : null;
    }
    return Object.values(polls).map(tally);
  },
};

export default weightedVotes;
`.trimStart();
var STD_SCHEMA_SOURCE = `
/**
 * Lightweight deterministic JSON schema validator and state migration helper for JS reducers.
 */

export function validate(schema, value, path = '$') {
  if (!schema || typeof schema !== 'object') return { ok: true };
  if (schema.enum && !schema.enum.some(v => JSON.stringify(v) === JSON.stringify(value))) {
    return { ok: false, code: 'schema:enum', detail: path + ' must be one of enum values' };
  }
  if (schema.type) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    const actual = value === null ? 'null' : Array.isArray(value) ? 'array' : typeof value;
    const matched = types.some(t => t === actual || (t === 'integer' && typeof value === 'number' && Number.isInteger(value)));
    if (!matched) return { ok: false, code: 'schema:type', detail: path + ' expected ' + types.join('|') + ', got ' + actual };
  }
  if (typeof value === 'string') {
    if (typeof schema.minLength === 'number' && value.length < schema.minLength) return { ok: false, code: 'schema:min_length', detail: path + ' too short' };
    if (typeof schema.maxLength === 'number' && value.length > schema.maxLength) return { ok: false, code: 'schema:max_length', detail: path + ' too long' };
  }
  if (typeof value === 'number') {
    if (typeof schema.minimum === 'number' && value < schema.minimum) return { ok: false, code: 'schema:minimum', detail: path + ' below minimum' };
    if (typeof schema.maximum === 'number' && value > schema.maximum) return { ok: false, code: 'schema:maximum', detail: path + ' above maximum' };
  }
  if (Array.isArray(value)) {
    if (typeof schema.minItems === 'number' && value.length < schema.minItems) return { ok: false, code: 'schema:min_items', detail: path + ' too few items' };
    if (typeof schema.maxItems === 'number' && value.length > schema.maxItems) return { ok: false, code: 'schema:max_items', detail: path + ' too many items' };
    if (schema.items) {
      for (let i = 0; i < value.length; i++) {
        const res = validate(schema.items, value[i], path + '[' + i + ']');
        if (!res.ok) return res;
      }
    }
  }
  if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
    if (Array.isArray(schema.required)) {
      for (const req of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(value, req) || value[req] === undefined) {
          return { ok: false, code: 'schema:required', detail: path + '.' + req + ' is required' };
        }
      }
    }
    if (schema.properties && typeof schema.properties === 'object') {
      for (const [k, propSchema] of Object.entries(schema.properties)) {
        if (Object.prototype.hasOwnProperty.call(value, k)) {
          const res = validate(propSchema, value[k], path + '.' + k);
          if (!res.ok) return res;
        }
      }
    }
    if (schema.additionalProperties === false && schema.properties) {
      for (const k of Object.keys(value)) {
        if (!Object.prototype.hasOwnProperty.call(schema.properties, k)) {
          return { ok: false, code: 'schema:additional_property', detail: path + '.' + k + ' is not allowed' };
        }
      }
    }
  }
  return { ok: true };
}

export function migrateState(state, migrations, targetVersion) {
  let cur = state && typeof state === 'object' ? state : { schemaVersion: 0 };
  let v = Number(cur.schemaVersion || 0);
  while (v < targetVersion) {
    const fn = migrations[v + 1];
    if (typeof fn !== 'function') throw new Error('SCHEMA_MIGRATION_MISSING:' + (v + 1));
    cur = { ...fn(cur), schemaVersion: v + 1 };
    v += 1;
  }
  return cur;
}

export default { validate, migrateState };
`.trimStart();
var STD_AUDIT_SOURCE = `
import { canonicalJson, sha256 } from 'chronolog:crypto';

const GENESIS_CHAIN_HASH = '0'.repeat(64);

/**
 * Deterministic hash-chained tamper-evident audit log reducer.
 */
export const auditLog = {
  reduce(state, tx) {
    const cur = state && typeof state === 'object' ? state : { head: GENESIS_CHAIN_HASH, entries: [] };
    const input = tx.payload || {};
    if (input.action && input.action !== 'append') return { ok: false, code: 'audit:unknown_action' };
    const entryCore = {
      seq: cur.entries.length,
      prevHash: cur.head,
      opId: tx.opId,
      actor: tx.author,
      atMs: Number(tx.authorTimestampMs || 0),
      category: String(input.category || 'general'),
      subject: input.subject === undefined ? null : input.subject,
      detail: input.detail === undefined ? null : input.detail,
    };
    const hash = sha256(canonicalJson(entryCore));
    const entry = { ...entryCore, hash };
    return {
      ok: true,
      state: { head: hash, entries: cur.entries.concat([entry]) },
      events: [{ topic: 'audit.appended', payload: { seq: entry.seq, category: entry.category, hash } }],
    };
  },
  query(state, input) {
    const cur = state && typeof state === 'object' ? state : { head: GENESIS_CHAIN_HASH, entries: [] };
    if (input && input.verify === true) {
      let prev = GENESIS_CHAIN_HASH;
      for (const e of cur.entries) {
        const { hash, ...core } = e;
        if (core.prevHash !== prev || sha256(canonicalJson(core)) !== hash) {
          return { valid: false, brokenAt: e.seq };
        }
        prev = hash;
      }
      return { valid: prev === cur.head, count: cur.entries.length, head: cur.head };
    }
    let list = cur.entries;
    if (input && typeof input.actor === 'string') list = list.filter(e => e.actor === input.actor);
    if (input && typeof input.category === 'string') list = list.filter(e => e.category === input.category);
    if (input && typeof input.sinceMs === 'number') list = list.filter(e => e.atMs >= input.sinceMs);
    return { head: cur.head, count: list.length, entries: list };
  },
};

export default auditLog;
`.trimStart();

// packages/materializer/src/std-modules.ts
var STD_PERMISSIONS_SOURCE = `
import { verifyEd25519, canonicalJson } from 'chronolog:crypto';

const HEX32 = /^[0-9a-f]{64}$/;
const HEX64 = /^[0-9a-f]{128}$/;

function sortedKeys(list) {
  return Array.from(new Set(list)).sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
}

function isLegacyAdmin(perms, author) {
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.administrator === true));
}

function hasCapability(ctx, capability, actor) {
  const checked = ctx.query('$permissions', { check: capability, actor });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  const m = perms.members.find(x => x.publicKey === actor);
  if (!m) return false;
  if (capability === 'administrator') return m.administrator === true;
  if (capability === 'publisher') return m.publisher === true || m.administrator === true;
  if (capability === 'writer') return m.writer === true || m.administrator === true;
  if (capability === 'reader') return m.reader === true;
  if (capability === 'finalizer') return m.finalizer === true;
  return true;
}

function normalizeMember(m) {
  if (!m || typeof m !== 'object' || !HEX32.test(m.publicKey || '') || (m.wrapKey !== undefined && m.wrapKey !== null && !HEX32.test(m.wrapKey))) {
    throw new Error('INVALID_MEMBER');
  }
  const scopes = Array.isArray(m.scopes)
    ? sortedKeys(m.scopes.filter(s => typeof s === 'string' && s.length > 0 && s.length <= 128))
    : undefined;
  const expiresAtMs = m.expiresAtMs !== undefined && m.expiresAtMs !== null && Number.isSafeInteger(m.expiresAtMs)
    ? m.expiresAtMs
    : undefined;
  return {
    publicKey: m.publicKey,
    ...(m.wrapKey ? { wrapKey: m.wrapKey } : {}),
    ...(typeof m.label === 'string' && m.label.length > 0 ? { label: m.label } : {}),
    ...(typeof m.subject === 'string' && m.subject.length > 0 ? { subject: m.subject } : {}),
    ...(scopes && scopes.length > 0 ? { scopes } : {}),
    ...(expiresAtMs !== undefined ? { expiresAtMs } : {}),
    reader: Boolean(m.reader),
    writer: Boolean(m.writer),
    administrator: Boolean(m.administrator),
    publisher: Boolean(m.publisher),
    finalizer: Boolean(m.finalizer),
  };
}

function isMemberExpired(member, atMs) {
  if (!member || member.expiresAtMs === undefined || member.expiresAtMs === null) return false;
  if (!Number.isSafeInteger(atMs) || atMs <= 0) return false;
  return atMs > member.expiresAtMs;
}

function queryMembersList(members, role) {
  if (role === 'members') return members;
  if (role === 'readers') return sortedKeys(members.filter(m => m.reader === true).map(m => m.publicKey));
  if (role === 'writers') return sortedKeys(members.filter(m => m.writer === true || m.administrator === true).map(m => m.publicKey));
  if (role === 'administrators') return sortedKeys(members.filter(m => m.administrator === true).map(m => m.publicKey));
  if (role === 'publishers') return sortedKeys(members.filter(m => m.publisher === true || m.administrator === true).map(m => m.publicKey));
  if (role === 'finalizers') return sortedKeys(members.filter(m => m.finalizer === true).map(m => m.publicKey));
  return [];
}

function checkMembersCapability(members, capability, actor, options) {
  const m = members.find(x => x.publicKey === actor);
  if (!m) return false;
  const atMs = options && Number.isSafeInteger(options.atMs) ? options.atMs : 0;
  if (isMemberExpired(m, atMs)) return false;
  if (capability === 'scope') {
    if (m.administrator === true) return true;
    const scope = options && typeof options.scope === 'string' ? options.scope : '';
    if (!scope) return false;
    if (!Array.isArray(m.scopes)) return false;
    return m.scopes.includes('*') || m.scopes.includes(scope);
  }
  if (capability === 'reader') return m.reader === true;
  if (capability === 'writer') return m.writer === true || m.administrator === true;
  if (capability === 'administrator') return m.administrator === true;
  if (capability === 'publisher') return m.publisher === true || m.administrator === true;
  if (capability === 'finalizer') return m.finalizer === true;
  if (capability === 'member') return true;
  return false;
}

function isLegacyReader(perms, author) {
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.reader === true));
}

function attestedMatchesPolicy(cur, attPayload, member) {
  const adm = cur.admission;
  if (!adm || adm.mode === 'strict') return false;
  if (Array.isArray(adm.removed) && adm.removed.includes(member.publicKey)) return false;
  if (cur.members.some(m => m.publicKey === member.publicKey)) return false;
  const accounts = Array.isArray(adm.accounts) ? adm.accounts : [];
  const email = typeof attPayload.email === 'string' ? attPayload.email.toLowerCase() : null;
  const accountOk = accounts.includes(attPayload.accountId) || (email !== null && accounts.includes('email:' + email));
  if (accountOk) {
    if (attPayload.subject === 'agent') {
      return member.administrator !== true && member.finalizer !== true;
    }
    const grant = adm.grant || { reader: true, writer: true, administrator: true };
    return Boolean(member.reader) === Boolean(grant.reader) &&
      Boolean(member.writer) === Boolean(grant.writer) &&
      Boolean(member.administrator) === Boolean(grant.administrator);
  }
  if (attPayload.inviteId && Array.isArray(adm.invites)) {
    const inv = adm.invites.find(i => i.inviteId === attPayload.inviteId && !i.revoked);
    if (!inv) return false;
    if (inv.binding && inv.binding.kind === 'email' && email !== inv.binding.email) return false;
    const expected = inv.role === 'admin'
      ? { reader: true, writer: true, administrator: true }
      : inv.role === 'reader'
        ? { reader: true, writer: false, administrator: false }
        : { reader: true, writer: true, administrator: false };
    return Boolean(member.reader) === expected.reader &&
      Boolean(member.writer) === expected.writer &&
      Boolean(member.administrator) === expected.administrator;
  }
  return false;
}

export const attestedMembers = {
  reduce(state, tx) {
    const cur = state && typeof state === 'object' ? state : { members: [], admission: null };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const authorIsAdmin = isLegacyAdmin(cur, tx.author);

    if (input.action === 'setMember') {
      if (!authorIsAdmin) {
        if (!isLegacyReader(cur, tx.author) || !input.attestation) {
          return { ok: false, code: 'admin_required' };
        }
      }
      if (input.attestation) {
        const att = input.attestation;
        const hostKey = cur.admission && cur.admission.hostKey;
        if (!hostKey || !HEX32.test(hostKey) || !HEX64.test(att.signature || '')) {
          return { ok: false, code: 'attestation_invalid' };
        }
        const msg = canonicalJson(['chronolog/host-attestation/v1', att.payload]);
        if (!verifyEd25519(hostKey, msg, att.signature)) {
          return { ok: false, code: 'attestation_signature_invalid' };
        }
        if (att.payload.publicKey !== input.member.publicKey) {
          return { ok: false, code: 'attestation_subject_mismatch' };
        }
        if (!authorIsAdmin && !attestedMatchesPolicy(cur, att.payload, input.member)) {
          return { ok: false, code: 'admin_required' };
        }
      }
      const next = normalizeMember(input.member);
      const members = cur.members.filter(m => m.publicKey !== next.publicKey).concat([next]);
      members.sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));
      let admission = cur.admission;
      if (authorIsAdmin && admission && Array.isArray(admission.removed) && admission.removed.includes(next.publicKey)) {
        admission = { ...admission, removed: admission.removed.filter(k => k !== next.publicKey) };
      }
      return { ok: true, state: { ...cur, members, admission }, events: [{ topic: '$permissions.member', payload: { publicKey: next.publicKey } }] };
    }

    if (input.action === 'requestRecovery') {
      const guardians = cur.guardians;
      if (!guardians || !Array.isArray(guardians.members) || guardians.members.length === 0) {
        return { ok: false, code: 'guardians_not_configured' };
      }
      if (!HEX32.test(input.newPublicKey || '') || !HEX32.test(input.newWrapKey || '')) {
        return { ok: false, code: 'invalid_recovery_key' };
      }
      if (tx.author !== input.newPublicKey && !authorIsAdmin) {
        return { ok: false, code: 'recovery_author_mismatch' };
      }
      const requestId = typeof input.requestId === 'string' && input.requestId.length > 0 ? input.requestId : tx.opId;
      const requests = { ...(cur.recoveryRequests || {}) };
      requests[requestId] = {
        requestId,
        newPublicKey: input.newPublicKey,
        newWrapKey: input.newWrapKey,
        label: typeof input.label === 'string' ? input.label.slice(0, 80) : 'Recovered device',
        verificationCode: typeof input.verificationCode === 'string' ? input.verificationCode.slice(0, 32) : '',
        approvals: [],
        status: 'pending',
        createdAtMs: Number(tx.authorTimestampMs || 0),
      };
      return {
        ok: true,
        state: { ...cur, recoveryRequests: requests },
        events: [{ topic: '$permissions.recovery_requested', payload: { requestId, newPublicKey: input.newPublicKey } }],
      };
    }

    if (input.action === 'approveRecovery') {
      const guardians = cur.guardians;
      if (!guardians || !Array.isArray(guardians.members) || !guardians.members.some(g => g.publicKey === tx.author)) {
        return { ok: false, code: 'guardian_required' };
      }
      const requests = { ...(cur.recoveryRequests || {}) };
      const req = requests[input.requestId];
      if (!req || req.status !== 'pending') return { ok: false, code: 'recovery_request_not_found' };
      const approvals = sortedKeys((req.approvals || []).concat([tx.author]));
      const completed = approvals.length >= guardians.threshold;
      requests[input.requestId] = { ...req, approvals, status: completed ? 'completed' : 'pending' };
      let members = cur.members;
      if (completed) {
        const promoted = normalizeMember({
          publicKey: req.newPublicKey,
          wrapKey: req.newWrapKey,
          label: req.label,
          reader: true,
          writer: true,
          administrator: true,
          publisher: true,
          finalizer: false,
        });
        members = cur.members.filter(m => m.publicKey !== promoted.publicKey).concat([promoted]);
        members.sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));
      }
      return {
        ok: true,
        state: { ...cur, members, recoveryRequests: requests },
        events: [{ topic: completed ? '$permissions.recovery_completed' : '$permissions.recovery_approved', payload: { requestId: input.requestId, guardian: tx.author, approvals: approvals.length, threshold: guardians.threshold } }],
      };
    }

    if (!authorIsAdmin) return { ok: false, code: 'admin_required' };

    if (input.action === 'setGuardians') {
      if (input.guardians === null) {
        return { ok: true, state: { ...cur, guardians: null }, events: [{ topic: '$permissions.guardians_cleared', payload: {} }] };
      }
      const g = input.guardians;
      if (!g || typeof g !== 'object' || !Array.isArray(g.members) || g.members.length === 0) {
        return { ok: false, code: 'invalid_guardians' };
      }
      const cleaned = [];
      const seen = new Set();
      for (const item of g.members) {
        if (!item || !HEX32.test(item.publicKey || '') || !HEX32.test(item.wrapKey || '') || seen.has(item.publicKey)) {
          return { ok: false, code: 'invalid_guardian' };
        }
        seen.add(item.publicKey);
        cleaned.push({
          publicKey: item.publicKey,
          wrapKey: item.wrapKey,
          ...(typeof item.label === 'string' && item.label.length > 0 ? { label: item.label.slice(0, 80) } : {}),
        });
      }
      cleaned.sort((a, b) => (a.publicKey < b.publicKey ? -1 : 1));
      const threshold = Number(g.threshold);
      if (!Number.isSafeInteger(threshold) || threshold < 1 || threshold > cleaned.length) {
        return { ok: false, code: 'invalid_guardian_threshold' };
      }
      return {
        ok: true,
        state: { ...cur, guardians: { threshold, members: cleaned } },
        events: [{ topic: '$permissions.guardians_updated', payload: { threshold, count: cleaned.length } }],
      };
    }

    if (input.action === 'removeMember') {
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      const members = cur.members.filter(m => m.publicKey !== input.publicKey);
      if (!members.some(m => m.administrator)) return { ok: false, code: 'last_admin_required' };
      let admission = cur.admission;
      if (admission && typeof admission === 'object') {
        const prevRemoved = Array.isArray(admission.removed) ? admission.removed : [];
        const removed = sortedKeys(prevRemoved.concat([input.publicKey])).slice(-512);
        admission = { ...admission, removed };
      }
      return { ok: true, state: { ...cur, members, admission }, events: [{ topic: '$permissions.removed', payload: { publicKey: input.publicKey } }] };
    }

    if (input.action === 'createInvite') {
      const inv = input.invite;
      if (!inv || typeof inv !== 'object' || typeof inv.inviteId !== 'string' || inv.inviteId.length < 1 || inv.inviteId.length > 128) {
        return { ok: false, code: 'invalid_invite' };
      }
      const admission = cur.admission && typeof cur.admission === 'object' ? cur.admission : { mode: 'attested' };
      const invites = (Array.isArray(admission.invites) ? admission.invites : []).filter(i => i.inviteId !== inv.inviteId).concat([{ ...inv, revoked: false }]).slice(-128);
      return { ok: true, state: { ...cur, admission: { ...admission, invites } }, events: [{ topic: '$permissions.invite_created', payload: { inviteId: inv.inviteId } }] };
    }

    if (input.action === 'revokeInvite') {
      if (typeof input.inviteId !== 'string' || !input.inviteId) return { ok: false, code: 'invalid_invite' };
      const admission = cur.admission && typeof cur.admission === 'object' ? cur.admission : null;
      if (!admission || !Array.isArray(admission.invites)) return { ok: false, code: 'invite_not_found' };
      let found = false;
      const invites = admission.invites.map(i => {
        if (i.inviteId !== input.inviteId) return i;
        found = true;
        return { ...i, revoked: true };
      });
      if (!found) return { ok: false, code: 'invite_not_found' };
      return { ok: true, state: { ...cur, admission: { ...admission, invites } }, events: [{ topic: '$permissions.invite_revoked', payload: { inviteId: input.inviteId } }] };
    }

    if (input.action === 'setAdmission') {
      return { ok: true, state: { ...cur, admission: input.admission ?? null } };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const cur = state && typeof state === 'object' ? state : { members: [], admission: null };
    const members = Array.isArray(cur.members) ? cur.members : [];
    if (input && typeof input === 'object') {
      if (typeof input.check === 'string' && typeof input.actor === 'string') {
        if (input.check === 'guardian') {
          return Boolean(cur.guardians && Array.isArray(cur.guardians.members) && cur.guardians.members.some(g => g.publicKey === input.actor));
        }
        return checkMembersCapability(members, input.check, input.actor, input);
      }
      if (typeof input.list === 'string') {
        if (input.list === 'guardians') return cur.guardians && Array.isArray(cur.guardians.members) ? cur.guardians.members.map(g => g.publicKey) : [];
        return queryMembersList(members, input.list);
      }
      if (input.guardians === true) {
        return { guardians: cur.guardians ?? null, recoveryRequests: cur.recoveryRequests ?? {} };
      }
      if (input.admission === true) {
        return cur.admission ?? null;
      }
      if (input.summary === true) {
        return {
          mode: 'attested',
          members,
          readers: queryMembersList(members, 'readers'),
          writers: queryMembersList(members, 'writers'),
          administrators: queryMembersList(members, 'administrators'),
          publishers: queryMembersList(members, 'publishers'),
          openReaders: false,
          openWriters: false,
          blockedAuthors: [],
          admission: cur.admission ?? null,
          guardians: cur.guardians ?? null,
          recoveryRequests: cur.recoveryRequests ?? {},
          multisig: null,
        };
      }
      if (input.publicKey) {
        return members.find(m => m.publicKey === input.publicKey) || null;
      }
    }
    return cur;
  },
};

/**
 * Open public-write / open-read authority model:
 * Any valid Ed25519 key can write (and read when openRead !== false), while listed
 * administrators govern control topics ($reducers, $finality, $publications).
 */
export const openMembers = {
  reduce(state, tx) {
    const cur = state && typeof state === 'object'
      ? {
          admins: Array.isArray(state.admins) ? state.admins : [],
          members: Array.isArray(state.members) ? state.members : [],
          openRead: state.openRead !== false,
          openWrite: state.openWrite !== false,
          blockedAuthors: Array.isArray(state.blockedAuthors) ? state.blockedAuthors : [],
          vouchedAuthors: Array.isArray(state.vouchedAuthors) ? state.vouchedAuthors : [],
          antiSpam: state.antiSpam && typeof state.antiSpam === 'object' ? state.antiSpam : null,
          admission: state.admission ?? null,
        }
      : { admins: [], members: [], openRead: true, openWrite: true, blockedAuthors: [], vouchedAuthors: [], antiSpam: null, admission: null };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };

    if (input.action === 'vouchAuthor') {
      const canVouch = cur.admins.includes(tx.author) || cur.vouchedAuthors.includes(tx.author);
      if (!canVouch) return { ok: false, code: 'vouch_permission_required' };
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      if (cur.blockedAuthors.includes(input.publicKey)) return { ok: false, code: 'author_blocked' };
      const vouchedAuthors = sortedKeys(cur.vouchedAuthors.concat([input.publicKey])).slice(-4096);
      return { ok: true, state: { ...cur, vouchedAuthors }, events: [{ topic: '$permissions.author_vouched', payload: { publicKey: input.publicKey, by: tx.author } }] };
    }

    if (!cur.admins.includes(tx.author)) return { ok: false, code: 'admin_required' };

    if (input.action === 'setAntiSpam') {
      if (input.antiSpam === null) {
        return { ok: true, state: { ...cur, antiSpam: null } };
      }
      const cfg = input.antiSpam;
      if (!cfg || typeof cfg !== 'object') return { ok: false, code: 'invalid_antispam' };
      const next = {
        requireVouch: Boolean(cfg.requireVouch),
        ...(Number.isSafeInteger(cfg.maxOpsPerWindow) && cfg.maxOpsPerWindow > 0 ? { maxOpsPerWindow: cfg.maxOpsPerWindow } : {}),
        ...(Number.isSafeInteger(cfg.windowMs) && cfg.windowMs > 0 ? { windowMs: cfg.windowMs } : {}),
      };
      return { ok: true, state: { ...cur, antiSpam: next }, events: [{ topic: '$permissions.antispam_updated', payload: next }] };
    }

    if (input.action === 'setAdmin') {
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      const admins = input.enabled === false
        ? cur.admins.filter(k => k !== input.publicKey)
        : sortedKeys(cur.admins.concat([input.publicKey]));
      if (admins.length === 0) return { ok: false, code: 'last_admin_required' };
      const blockedAuthors = input.enabled === false
        ? cur.blockedAuthors
        : cur.blockedAuthors.filter(k => k !== input.publicKey);
      return { ok: true, state: { ...cur, admins, blockedAuthors }, events: [{ topic: '$permissions.admin', payload: { publicKey: input.publicKey, enabled: input.enabled !== false } }] };
    }

    if (input.action === 'setOpen') {
      return {
        ok: true,
        state: {
          ...cur,
          ...(input.openRead === undefined ? {} : { openRead: Boolean(input.openRead) }),
          ...(input.openWrite === undefined ? {} : { openWrite: Boolean(input.openWrite) }),
        },
      };
    }

    if (input.action === 'blockAuthor') {
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      if (cur.admins.includes(input.publicKey)) return { ok: false, code: 'cannot_block_admin' };
      const blockedAuthors = sortedKeys(cur.blockedAuthors.concat([input.publicKey])).slice(-2048);
      return {
        ok: true,
        state: { ...cur, blockedAuthors },
        events: [{ topic: '$permissions.author_blocked', payload: { publicKey: input.publicKey, ...(typeof input.reason === 'string' && input.reason ? { reason: input.reason.slice(0, 160) } : {}) } }],
      };
    }

    if (input.action === 'unblockAuthor') {
      if (!HEX32.test(input.publicKey || '')) return { ok: false, code: 'invalid_member' };
      const blockedAuthors = cur.blockedAuthors.filter(k => k !== input.publicKey);
      return {
        ok: true,
        state: { ...cur, blockedAuthors },
        events: [{ topic: '$permissions.author_unblocked', payload: { publicKey: input.publicKey } }],
      };
    }

    if (input.action === 'setMember') {
      const next = normalizeMember(input.member);
      const members = cur.members.filter(m => m.publicKey !== next.publicKey).concat([next]);
      members.sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));
      const admins = next.administrator ? sortedKeys(cur.admins.concat([next.publicKey])) : cur.admins;
      const blockedAuthors = next.administrator ? cur.blockedAuthors.filter(k => k !== next.publicKey) : cur.blockedAuthors;
      return { ok: true, state: { ...cur, admins, members, blockedAuthors }, events: [{ topic: '$permissions.member', payload: { publicKey: next.publicKey } }] };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const cur = state && typeof state === 'object'
      ? {
          admins: Array.isArray(state.admins) ? state.admins : [],
          members: Array.isArray(state.members) ? state.members : [],
          openRead: state.openRead !== false,
          openWrite: state.openWrite !== false,
          blockedAuthors: Array.isArray(state.blockedAuthors) ? sortedKeys(state.blockedAuthors.filter(k => HEX32.test(k || ''))) : [],
          vouchedAuthors: Array.isArray(state.vouchedAuthors) ? sortedKeys(state.vouchedAuthors.filter(k => HEX32.test(k || ''))) : [],
          antiSpam: state.antiSpam && typeof state.antiSpam === 'object' ? state.antiSpam : null,
          admission: state.admission ?? null,
        }
      : { admins: [], members: [], openRead: true, openWrite: true, blockedAuthors: [], vouchedAuthors: [], antiSpam: null, admission: null };

    const adminSet = new Set(cur.admins);
    const blockedSet = new Set(cur.blockedAuthors);
    const vouchedSet = new Set(cur.vouchedAuthors);
    const synthesizedMap = new Map();
    for (const m of cur.members) synthesizedMap.set(m.publicKey, m);
    for (const a of cur.admins) {
      const existing = synthesizedMap.get(a);
      synthesizedMap.set(a, {
        publicKey: a,
        ...(existing && existing.wrapKey ? { wrapKey: existing.wrapKey } : {}),
        reader: true,
        writer: true,
        administrator: true,
        publisher: true,
        finalizer: Boolean(existing && existing.finalizer),
      });
    }
    const members = Array.from(synthesizedMap.values()).sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));

    if (input && typeof input === 'object') {
      if (typeof input.check === 'string' && typeof input.actor === 'string') {
        if (!HEX32.test(input.actor)) return false;
        if (input.check === 'blocked') return blockedSet.has(input.actor);
        if (input.check === 'administrator') return adminSet.has(input.actor);
        if (input.check === 'publisher') return adminSet.has(input.actor) || checkMembersCapability(members, 'publisher', input.actor);
        if (input.check === 'writer') {
          if (blockedSet.has(input.actor)) return false;
          if (adminSet.has(input.actor)) return true;
          if (checkMembersCapability(members, 'writer', input.actor, input)) return true;
          if (!cur.openWrite) return false;
          if (cur.antiSpam && cur.antiSpam.requireVouch === true) {
            return vouchedSet.has(input.actor);
          }
          return true;
        }
        if (input.check === 'reader') return cur.openRead || adminSet.has(input.actor) || checkMembersCapability(members, 'reader', input.actor, input);
        if (input.check === 'member') return cur.openWrite || cur.openRead || adminSet.has(input.actor) || checkMembersCapability(members, 'member', input.actor, input);
        return checkMembersCapability(members, input.check, input.actor, input);
      }
      if (typeof input.list === 'string') {
        if (input.list === 'blockedAuthors') return cur.blockedAuthors;
        if (input.list === 'readers' && cur.openRead) return ['*'];
        if (input.list === 'writers' && cur.openWrite) return ['*'];
        return queryMembersList(members, input.list);
      }
      if (input.admission === true) return cur.admission;
      if (input.summary === true) {
        return {
          mode: 'open',
          members,
          readers: cur.openRead ? ['*'] : queryMembersList(members, 'readers'),
          writers: cur.openWrite ? ['*'] : queryMembersList(members, 'writers'),
          administrators: sortedKeys(cur.admins),
          publishers: queryMembersList(members, 'publishers'),
          openReaders: cur.openRead,
          openWriters: cur.openWrite,
          blockedAuthors: cur.blockedAuthors,
          admission: cur.admission,
          multisig: null,
        };
      }
      if (input.publicKey) {
        return members.find(m => m.publicKey === input.publicKey) || null;
      }
    }
    return cur;
  },
};

/**
 * M-of-N multisig authority model (zero host attestation, completely distinct state shape):
 * State: { threshold: number, signers: string[], members: Record<pubkey, { wrapKey?, reader, writer, publisher, finalizer }>, proposals: Record<id, ...> }
 * Signers submit proposals (action: 'propose' | 'approve'); once approvals >= threshold, the proposal executes atomically.
 */
function normalizeMultisigState(state) {
  const s = state && typeof state === 'object' ? state : {};
  const signers = sortedKeys(Array.isArray(s.signers) ? s.signers.filter(k => HEX32.test(k || '')) : []);
  const threshold = Number.isSafeInteger(s.threshold) && s.threshold >= 1 ? Math.min(s.threshold, Math.max(1, signers.length)) : 1;
  const members = s.members && typeof s.members === 'object' && !Array.isArray(s.members) ? { ...s.members } : {};
  const proposals = s.proposals && typeof s.proposals === 'object' && !Array.isArray(s.proposals) ? { ...s.proposals } : {};
  return { threshold, signers, members, proposals };
}

function multisigMemberRecords(cur) {
  const byKey = new Map();
  for (const [pk, entry] of Object.entries(cur.members)) {
    if (!HEX32.test(pk) || !entry || typeof entry !== 'object') continue;
    byKey.set(pk, {
      publicKey: pk,
      ...(entry.wrapKey ? { wrapKey: entry.wrapKey } : {}),
      reader: Boolean(entry.reader),
      writer: Boolean(entry.writer),
      administrator: cur.signers.includes(pk),
      publisher: Boolean(entry.publisher) || cur.signers.includes(pk),
      finalizer: Boolean(entry.finalizer),
    });
  }
  for (const pk of cur.signers) {
    if (!byKey.has(pk)) {
      byKey.set(pk, {
        publicKey: pk,
        reader: true,
        writer: true,
        administrator: true,
        publisher: true,
        finalizer: false,
      });
    }
  }
  return Array.from(byKey.values()).sort((a, b) => (a.publicKey < b.publicKey ? -1 : a.publicKey > b.publicKey ? 1 : 0));
}

function applyMultisigProposal(cur, prop) {
  if (prop.kind === 'setMember') {
    const m = normalizeMember(prop.member);
    const nextMembers = {
      ...cur.members,
      [m.publicKey]: {
        ...(m.wrapKey ? { wrapKey: m.wrapKey } : {}),
        reader: m.reader,
        writer: m.writer,
        publisher: m.publisher,
        finalizer: m.finalizer,
      },
    };
    const nextSigners = m.administrator
      ? sortedKeys(cur.signers.concat([m.publicKey]))
      : cur.signers.filter(k => k !== m.publicKey);
    if (nextSigners.length === 0 || nextSigners.length < cur.threshold) {
      return { ok: false, code: 'threshold_unsatisfiable' };
    }
    return { ok: true, state: { ...cur, signers: nextSigners, members: nextMembers }, event: { topic: '$permissions.member', payload: { publicKey: m.publicKey } } };
  }
  if (prop.kind === 'removeMember') {
    if (!HEX32.test(prop.publicKey || '')) return { ok: false, code: 'invalid_member' };
    const nextMembers = { ...cur.members };
    delete nextMembers[prop.publicKey];
    const nextSigners = cur.signers.filter(k => k !== prop.publicKey);
    if (nextSigners.length === 0 || nextSigners.length < cur.threshold) return { ok: false, code: 'threshold_unsatisfiable' };
    return { ok: true, state: { ...cur, signers: nextSigners, members: nextMembers }, event: { topic: '$permissions.removed', payload: { publicKey: prop.publicKey } } };
  }
  if (prop.kind === 'setThreshold') {
    const t = prop.threshold;
    if (!Number.isSafeInteger(t) || t < 1 || t > cur.signers.length) return { ok: false, code: 'invalid_threshold' };
    return { ok: true, state: { ...cur, threshold: t }, event: { topic: '$permissions.threshold', payload: { threshold: t } } };
  }
  return { ok: false, code: 'unknown_proposal_kind' };
}

export const multisigMembers = {
  reduce(state, tx) {
    const cur = normalizeMultisigState(state);
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    if (!cur.signers.includes(tx.author)) return { ok: false, code: 'signer_required' };

    if (input.action === 'propose') {
      const id = typeof input.proposalId === 'string' && input.proposalId.length > 0 ? input.proposalId : tx.opId;
      if (cur.proposals[id]) return { ok: false, code: 'proposal_exists' };
      const prop = {
        kind: input.kind,
        ...(input.member !== undefined ? { member: input.member } : {}),
        ...(input.publicKey !== undefined ? { publicKey: input.publicKey } : {}),
        ...(input.threshold !== undefined ? { threshold: input.threshold } : {}),
        approvals: [tx.author],
      };
      if (prop.approvals.length >= cur.threshold) {
        const applied = applyMultisigProposal(cur, prop);
        if (!applied.ok) return applied;
        return { ok: true, state: applied.state, events: [applied.event] };
      }
      const nextProposals = { ...cur.proposals, [id]: prop };
      return {
        ok: true,
        state: { ...cur, proposals: nextProposals },
        events: [{ topic: '$permissions.proposed', payload: { proposalId: id, approvals: 1, threshold: cur.threshold } }],
      };
    }

    if (input.action === 'approve') {
      const id = input.proposalId;
      const existing = typeof id === 'string' ? cur.proposals[id] : null;
      if (!existing) return { ok: false, code: 'proposal_not_found' };
      const approvals = sortedKeys((existing.approvals || []).concat([tx.author]));
      const updated = { ...existing, approvals };
      if (approvals.length >= cur.threshold) {
        const nextProposals = { ...cur.proposals };
        delete nextProposals[id];
        const applied = applyMultisigProposal({ ...cur, proposals: nextProposals }, updated);
        if (!applied.ok) return applied;
        return { ok: true, state: applied.state, events: [applied.event] };
      }
      return {
        ok: true,
        state: { ...cur, proposals: { ...cur.proposals, [id]: updated } },
        events: [{ topic: '$permissions.approved', payload: { proposalId: id, approvals: approvals.length, threshold: cur.threshold } }],
      };
    }

    if (input.action === 'cancel') {
      const id = input.proposalId;
      if (typeof id !== 'string' || !cur.proposals[id]) return { ok: false, code: 'proposal_not_found' };
      const nextProposals = { ...cur.proposals };
      delete nextProposals[id];
      return {
        ok: true,
        state: { ...cur, proposals: nextProposals },
        events: [{ topic: '$permissions.cancelled', payload: { proposalId: id } }],
      };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const cur = normalizeMultisigState(state);
    const members = multisigMemberRecords(cur);
    if (input && typeof input === 'object') {
      if (typeof input.check === 'string' && typeof input.actor === 'string') {
        return checkMembersCapability(members, input.check, input.actor);
      }
      if (typeof input.list === 'string') {
        return queryMembersList(members, input.list);
      }
      if (input.admission === true) return null;
      if (input.summary === true) {
        return {
          mode: 'multisig',
          members,
          readers: queryMembersList(members, 'readers'),
          writers: queryMembersList(members, 'writers'),
          administrators: queryMembersList(members, 'administrators'),
          publishers: queryMembersList(members, 'publishers'),
          openReaders: false,
          openWriters: false,
          blockedAuthors: [],
          admission: null,
          multisig: {
            threshold: cur.threshold,
            signers: cur.signers,
            proposals: cur.proposals,
          },
        };
      }
      if (input.publicKey) {
        return members.find(m => m.publicKey === input.publicKey) || null;
      }
    }
    return cur;
  },
};

export const adminOnlyReducers = {
  reduce(state, tx, ctx) {
    if (!hasCapability(ctx, 'administrator', tx.author)) return { ok: false, code: 'admin_required' };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };
    const next = {
      runtime: state.runtime,
      imports: { ...(state.imports || {}) },
      topics: { ...(state.topics || {}) },
    };
    if (input.imports && typeof input.imports === 'object') {
      for (const [k, v] of Object.entries(input.imports)) {
        if (v === null) delete next.imports[k];
        else next.imports[k] = v;
      }
    }
    if (input.topics && typeof input.topics === 'object') {
      for (const [k, v] of Object.entries(input.topics)) {
        if (v === null) delete next.topics[k];
        else next.topics[k] = v;
      }
    }
    return { ok: true, state: next, events: [{ topic: '$reducers.updated', payload: { author: tx.author } }] };
  },
};

export const defaultSignalPolicy = {
  reduce(state, tx, ctx) {
    if (!hasCapability(ctx, 'administrator', tx.author)) return { ok: false, code: 'admin_required' };
    if (!tx.payload || !Array.isArray(tx.payload.rules)) return { ok: false, code: 'invalid_signal_policy' };
    return { ok: true, state: { rules: tx.payload.rules } };
  },
  query(state, _input, ctx) {
    if (state && Array.isArray(state.rules)) return state;
    const queried = ctx.query('$permissions', { list: 'readers' });
    if (Array.isArray(queried)) {
      return {
        rules: [{ topicPattern: '*', allowedAuthors: queried, maxTtlMs: 30000, allowRelay: true }],
      };
    }
    const perms = ctx.topic('$permissions') || { members: [] };
    const readers = Array.isArray(perms.members) ? perms.members.filter(m => m.reader).map(m => m.publicKey) : [];
    return {
      rules: [{ topicPattern: '*', allowedAuthors: readers, maxTtlMs: 30000, allowRelay: true }],
    };
  },
};
`.trimStart();
var STD_KEYS_SOURCE = `
const HEX32 = /^[0-9a-f]{64}$/;

function isAdmin(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.administrator === true));
}

function isReader(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'reader', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.reader === true));
}

function isGuardian(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'guardian', actor: author });
  return checked === true;
}

const RING_RE = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/;

export const hpkeEpochs = {
  reduce(state, tx, ctx) {
    const cur = state && typeof state === 'object' ? state : { currentEpoch: -1, epochs: {} };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_input' };

    if (input.action === 'setRecoveryVault') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      const vault = input.vault;
      if (!vault || typeof vault.nonce !== 'string' || typeof vault.ciphertext !== 'string') {
        return { ok: false, code: 'recovery_vault_invalid' };
      }
      if (!input.guardianShares || typeof input.guardianShares !== 'object') {
        return { ok: false, code: 'guardian_shares_invalid' };
      }
      const guardianShares = {};
      for (const [pk, item] of Object.entries(input.guardianShares)) {
        if (!HEX32.test(pk) || !item || !Number.isSafeInteger(item.index) || item.index < 1 || item.index > 255 || !item.box || typeof item.box.encapsulatedKey !== 'string' || typeof item.box.ciphertext !== 'string') {
          return { ok: false, code: 'guardian_share_invalid' };
        }
        guardianShares[pk] = { index: item.index, box: { encapsulatedKey: item.box.encapsulatedKey, ciphertext: item.box.ciphertext } };
      }
      return {
        ok: true,
        state: {
          ...cur,
          recovery: {
            vault: { nonce: vault.nonce, ciphertext: vault.ciphertext },
            guardianShares,
          },
        },
        events: [{ topic: '$keys.recovery_vault_updated', payload: { guardians: Object.keys(guardianShares).length } }],
      };
    }

    if (input.action === 'submitRecoveryShare') {
      if (!isGuardian(ctx, tx.author)) return { ok: false, code: 'guardian_required' };
      if (!HEX32.test(input.member || '') || !Number.isSafeInteger(input.index) || input.index < 1 || input.index > 255 || !input.box || typeof input.box.encapsulatedKey !== 'string' || typeof input.box.ciphertext !== 'string') {
        return { ok: false, code: 'recovery_share_invalid' };
      }
      const recoveryGrants = { ...(cur.recoveryGrants || {}) };
      const forMember = { ...(recoveryGrants[input.member] || {}) };
      forMember[tx.author] = {
        index: input.index,
        box: { encapsulatedKey: input.box.encapsulatedKey, ciphertext: input.box.ciphertext },
      };
      recoveryGrants[input.member] = forMember;
      return {
        ok: true,
        state: { ...cur, recoveryGrants },
        events: [{ topic: '$keys.recovery_share_submitted', payload: { member: input.member, guardian: tx.author } }],
      };
    }

    if (input.action === 'rotateRingEpoch') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      const ringName = typeof input.ring === 'string' && RING_RE.test(input.ring) ? input.ring : null;
      if (!ringName || ringName === 'default') return { ok: false, code: 'ring_name_invalid' };
      const rings = { ...(cur.rings || {}) };
      const prevRing = rings[ringName] || { currentEpoch: -1, epochs: {} };
      const epoch = input.epoch;
      if (!Number.isSafeInteger(epoch) || epoch !== prevRing.currentEpoch + 1) return { ok: false, code: 'epoch_sequence_invalid' };
      if (!HEX32.test(input.keyCommitment || '')) return { ok: false, code: 'key_commitment_invalid' };
      if (!input.boxes || typeof input.boxes !== 'object') return { ok: false, code: 'boxes_invalid' };
      const boxes = {};
      for (const [pk, box] of Object.entries(input.boxes)) {
        if (!HEX32.test(pk) || !box || typeof box.encapsulatedKey !== 'string' || typeof box.ciphertext !== 'string') {
          return { ok: false, code: 'box_invalid' };
        }
        boxes[pk] = { encapsulatedKey: box.encapsulatedKey, ciphertext: box.ciphertext };
      }
      rings[ringName] = {
        currentEpoch: epoch,
        epochs: { ...prevRing.epochs, [String(epoch)]: { epoch, keyCommitment: input.keyCommitment, boxes } },
      };
      const topicRings = { ...(cur.topicRings || {}) };
      if (Array.isArray(input.topics)) {
        for (const t of input.topics) {
          if (typeof t === 'string' && t.length > 0 && !t.startsWith('$')) topicRings[t] = ringName;
        }
      }
      return {
        ok: true,
        state: { ...cur, rings, topicRings },
        events: [{ topic: '$keys.ring_rotated', payload: { ring: ringName, epoch } }],
      };
    }

    if (input.action === 'grantRingBoxes') {
      if (!isAdmin(ctx, tx.author) && !isReader(ctx, tx.author)) return { ok: false, code: 'reader_required' };
      const ringName = typeof input.ring === 'string' && RING_RE.test(input.ring) ? input.ring : null;
      const rings = { ...(cur.rings || {}) };
      if (!ringName || !rings[ringName]) return { ok: false, code: 'ring_not_found' };
      if (!HEX32.test(input.member || '') || !input.epochBoxes || typeof input.epochBoxes !== 'object') {
        return { ok: false, code: 'grant_boxes_invalid' };
      }
      const nextEpochs = { ...rings[ringName].epochs };
      for (const [epKey, box] of Object.entries(input.epochBoxes)) {
        const existing = nextEpochs[epKey];
        if (!existing) return { ok: false, code: 'epoch_missing' };
        if (!box || typeof box.encapsulatedKey !== 'string' || typeof box.ciphertext !== 'string') {
          return { ok: false, code: 'box_invalid' };
        }
        nextEpochs[epKey] = {
          ...existing,
          boxes: { ...existing.boxes, [input.member]: { encapsulatedKey: box.encapsulatedKey, ciphertext: box.ciphertext } },
        };
      }
      rings[ringName] = { ...rings[ringName], epochs: nextEpochs };
      return {
        ok: true,
        state: { ...cur, rings },
        events: [{ topic: '$keys.ring_granted', payload: { ring: ringName, member: input.member } }],
      };
    }

    if (input.action === 'rotateEpoch') {
      if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
      const epoch = input.epoch;
      if (!Number.isSafeInteger(epoch) || epoch !== cur.currentEpoch + 1) return { ok: false, code: 'epoch_sequence_invalid' };
      if (!HEX32.test(input.keyCommitment || '')) return { ok: false, code: 'key_commitment_invalid' };
      if (!input.boxes || typeof input.boxes !== 'object') return { ok: false, code: 'boxes_invalid' };
      const boxes = {};
      for (const [pk, box] of Object.entries(input.boxes)) {
        if (!HEX32.test(pk) || !box || typeof box.encapsulatedKey !== 'string' || typeof box.ciphertext !== 'string') {
          return { ok: false, code: 'box_invalid' };
        }
        boxes[pk] = { encapsulatedKey: box.encapsulatedKey, ciphertext: box.ciphertext };
      }
      const nextEpochs = { ...cur.epochs, [String(epoch)]: { epoch, keyCommitment: input.keyCommitment, boxes } };
      return {
        ok: true,
        state: { ...cur, currentEpoch: epoch, epochs: nextEpochs },
        events: [{ topic: '$keys.rotated', payload: { epoch } }],
      };
    }

    // Grant a newly admitted fresh device lockboxes for one or more retained historical epochs (0..N or checkpointEpoch..N).
    // Any existing reader holding the epoch keys may seal lockboxes for an already-authorized reader in $permissions.
    if (input.action === 'grantBoxes') {
      if (!isAdmin(ctx, tx.author) && !isReader(ctx, tx.author)) return { ok: false, code: 'reader_required' };
      if (!HEX32.test(input.member || '') || !input.epochBoxes || typeof input.epochBoxes !== 'object') {
        return { ok: false, code: 'grant_boxes_invalid' };
      }
      if (!isAdmin(ctx, tx.author) && !isReader(ctx, input.member)) {
        return { ok: false, code: 'member_not_authorized' };
      }
      const nextEpochs = { ...cur.epochs };
      for (const [epKey, box] of Object.entries(input.epochBoxes)) {
        const existing = nextEpochs[epKey];
        if (!existing) return { ok: false, code: 'epoch_missing' };
        if (!box || typeof box.encapsulatedKey !== 'string' || typeof box.ciphertext !== 'string') {
          return { ok: false, code: 'box_invalid' };
        }
        nextEpochs[epKey] = {
          ...existing,
          boxes: { ...existing.boxes, [input.member]: { encapsulatedKey: box.encapsulatedKey, ciphertext: box.ciphertext } },
        };
      }
      return {
        ok: true,
        state: { ...cur, currentEpoch: cur.currentEpoch, epochs: nextEpochs },
        events: [{ topic: '$keys.granted', payload: { member: input.member } }],
      };
    }

    return { ok: false, code: 'unknown_action' };
  },
  query(state, input) {
    const cur = state || { currentEpoch: -1, epochs: {} };
    if (input && typeof input === 'object') {
      if (typeof input.recoveryFor === 'string') {
        const vault = cur.recovery ? cur.recovery.vault : null;
        const shares = cur.recoveryGrants && cur.recoveryGrants[input.recoveryFor] ? cur.recoveryGrants[input.recoveryFor] : {};
        return { vault, shares };
      }
      if (typeof input.guardianShareFor === 'string') {
        return cur.recovery && cur.recovery.guardianShares ? (cur.recovery.guardianShares[input.guardianShareFor] || null) : null;
      }
      if (typeof input.topicRing === 'string') {
        return cur.topicRings && cur.topicRings[input.topicRing] ? cur.topicRings[input.topicRing] : 'default';
      }
      if (typeof input.ring === 'string' && input.ring !== 'default') {
        const ring = cur.rings && cur.rings[input.ring] ? cur.rings[input.ring] : { currentEpoch: -1, epochs: {} };
        if (input.member) {
          const out = {};
          for (const [ep, entry] of Object.entries(ring.epochs || {})) {
            if (entry.boxes && entry.boxes[input.member]) {
              out[ep] = { epoch: entry.epoch, keyCommitment: entry.keyCommitment, box: entry.boxes[input.member] };
            }
          }
          return { ring: input.ring, currentEpoch: ring.currentEpoch, memberEpochs: out };
        }
        return ring;
      }
      if (input.member) {
        const out = {};
        for (const [ep, entry] of Object.entries(cur.epochs || {})) {
          if (entry.boxes && entry.boxes[input.member]) {
            out[ep] = { epoch: entry.epoch, keyCommitment: entry.keyCommitment, box: entry.boxes[input.member] };
          }
        }
        return { currentEpoch: cur.currentEpoch, memberEpochs: out };
      }
    }
    return cur;
  },
};
`.trimStart();
var STD_FINALITY_SOURCE = `
function isAdmin(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'administrator', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && m.administrator === true));
}

function validPolicy(policy) {
  if (!policy || typeof policy !== 'object') return false;
  if (policy.kind === 'none') return true;
  if (policy.kind === 'signed-frontier') return typeof policy.signer === 'string' && /^[0-9a-f]{64}$/.test(policy.signer);
  if (policy.kind === 'fixed-validator') {
    return Array.isArray(policy.validators) && policy.validators.length > 0 &&
      policy.validators.every(v => typeof v === 'string' && /^[0-9a-f]{64}$/.test(v)) &&
      Number.isSafeInteger(policy.threshold) && policy.threshold >= 1 && policy.threshold <= policy.validators.length;
  }
  if (policy.kind === 'blockchain-anchor') {
    return typeof policy.chain === 'string' && policy.chain.length > 0 && typeof policy.anchorId === 'string' && policy.anchorId.length > 0;
  }
  if (policy.kind === 'predicate') {
    return typeof policy.module === 'string' && policy.module.length > 0 &&
      (policy.export === undefined || (typeof policy.export === 'string' && policy.export.length > 0));
  }
  return false;
}

export const scheduledFinality = {
  reduce(state, tx, ctx) {
    if (!isAdmin(ctx, tx.author)) return { ok: false, code: 'admin_required' };
    const cur = state && Array.isArray(state.schedule) ? state : { schedule: [{ effectiveAfterMs: -1, policy: { kind: 'none' } }] };
    const input = tx.payload;
    if (!input || input.action !== 'schedulePolicy' || !validPolicy(input.policy)) return { ok: false, code: 'invalid_finality_policy' };
    const effectiveAfterMs = input.effectiveAfterMs;
    const last = cur.schedule[cur.schedule.length - 1];
    if (!Number.isSafeInteger(effectiveAfterMs) || effectiveAfterMs <= last.effectiveAfterMs) {
      return { ok: false, code: 'finality_activation_not_monotonic' };
    }
    if (effectiveAfterMs < tx.authorTimestampMs) {
      return { ok: false, code: 'finality_activation_in_past' };
    }
    const nextSchedule = cur.schedule.concat([{ effectiveAfterMs, policy: input.policy }]);
    return {
      ok: true,
      state: { schedule: nextSchedule },
      events: [{ topic: '$finality.scheduled', payload: { effectiveAfterMs, kind: input.policy.kind } }],
    };
  },
  query(state) {
    return state || { schedule: [{ effectiveAfterMs: -1, policy: { kind: 'none' } }] };
  },
};
`.trimStart();
var STD_PUBLICATIONS_SOURCE = `
const HEX32 = /^[0-9a-f]{64}$/;

function isPublisher(ctx, author) {
  const checked = ctx.query('$permissions', { check: 'publisher', actor: author });
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  return Boolean(perms && Array.isArray(perms.members) && perms.members.some(m => m.publicKey === author && (m.publisher === true || m.administrator === true)));
}

function validPublicationPath(path) {
  if (typeof path !== 'string' || path.length === 0 || path.length > 512 || path.startsWith('/')) return false;
  for (let i = 0; i < path.length; i++) {
    const code = path.charCodeAt(i);
    if (code < 0x20 || code === 0x7f || code === 0x5c) return false;
  }
  const parts = path.split('/');
  return !parts.some(p => p.length === 0 || p === '.' || p === '..');
}

export const signedReleases = {
  reduce(state, tx, ctx) {
    if (!isPublisher(ctx, tx.author)) return { ok: false, code: 'publisher_required' };
    const cur = state && typeof state === 'object' ? state : { revision: 0, current: null, history: [] };
    const input = tx.payload;
    if (!input || typeof input !== 'object') return { ok: false, code: 'invalid_publication' };

    if (input.action === 'rollback') {
      const hist = Array.isArray(cur.history) ? cur.history : [];
      const target = input.opId !== undefined
        ? hist.find(r => r.opId === input.opId)
        : Number.isSafeInteger(input.revision)
          ? hist.find(r => r.revision === input.revision)
          : null;
      if (!target || !Array.isArray(target.files)) return { ok: false, code: 'publication_not_found' };
      const revision = cur.revision + 1;
      const release = {
        revision,
        opId: tx.opId,
        author: tx.author,
        timestampMs: tx.authorTimestampMs,
        entry: target.entry,
        files: target.files,
        ...(typeof target.treeRoot === 'string' ? { treeRoot: target.treeRoot } : {}),
        rollbackOf: target.revision,
      };
      const history = hist.concat([release]).slice(-128);
      return {
        ok: true,
        state: { revision, current: release, history },
        events: [{ topic: '$publications.published', payload: { revision, opId: tx.opId, rollbackOf: target.revision } }],
      };
    }

    if (input.action !== 'publish' || typeof input.entry !== 'string' || !Array.isArray(input.files) || input.files.length === 0) {
      return { ok: false, code: 'invalid_publication' };
    }
    if (input.expectedRevision !== undefined && input.expectedRevision !== cur.revision) {
      return { ok: false, code: 'publication_revision_conflict' };
    }
    if (input.treeRoot !== undefined && (typeof input.treeRoot !== 'string' || !/^cas:sha256-[0-9a-f]{64}$/.test(input.treeRoot))) {
      return { ok: false, code: 'invalid_publication_tree_root' };
    }
    const files = [];
    const seenPaths = new Set();
    for (const f of input.files) {
      if (!f || !validPublicationPath(f.path) || seenPaths.has(f.path) || !HEX32.test(f.hash || '') || !Number.isSafeInteger(f.size) || f.size < 0 || typeof f.type !== 'string' || f.type.length === 0) {
        return { ok: false, code: 'invalid_publication_file' };
      }
      seenPaths.add(f.path);
      files.push({ path: f.path, hash: f.hash, size: f.size, type: f.type });
    }
    if (!files.some(f => f.path === input.entry)) return { ok: false, code: 'publication_entry_missing' };
    const revision = cur.revision + 1;
    const release = {
      revision,
      opId: tx.opId,
      author: tx.author,
      timestampMs: tx.authorTimestampMs,
      entry: input.entry,
      files,
      ...(typeof input.treeRoot === 'string' ? { treeRoot: input.treeRoot } : {}),
    };
    const history = (Array.isArray(cur.history) ? cur.history : []).concat([release]).slice(-128);
    return {
      ok: true,
      state: { revision, current: release, history },
      events: [{ topic: '$publications.published', payload: { revision, opId: tx.opId } }],
    };
  },
  query(state, input) {
    const cur = state && typeof state === 'object' ? state : { revision: 0, current: null, history: [] };
    if (input && typeof input === 'object') {
      const hist = Array.isArray(cur.history) ? cur.history : [];
      if (typeof input.opId === 'string') {
        if (cur.current && cur.current.opId === input.opId) return cur.current;
        return hist.find(r => r.opId === input.opId) || null;
      }
      if (Number.isSafeInteger(input.revision)) {
        if (cur.current && cur.current.revision === input.revision) return cur.current;
        return hist.find(r => r.revision === input.revision) || null;
      }
      if (input.history === true) return hist;
    }
    return cur;
  },
};
`.trimStart();
var STD_RLS_SOURCE = `
function quoteIdent(name) {
  if (typeof name !== 'string' || !/^[A-Za-z][A-Za-z0-9_]*$/.test(name) || name.startsWith('_rls_') || name.startsWith('sqlite_')) {
    throw new Error('RLS_INVALID_IDENTIFIER:' + String(name));
  }
  return '"' + name + '"';
}

/**
 * Install Postgres-style write RLS triggers on tables inside a chronolog:sqlite database.
 * Each predicate is validated via db.validateExpr() (SQLite mode:'readonly', zero trailing tokens)
 * before wrapping in a BEFORE INSERT/UPDATE/DELETE trigger with RAISE(ABORT, ...).
 */
export function applyRls(db, policies) {
  if (!policies || typeof policies !== 'object') throw new Error('RLS_POLICIES_INVALID');
  const ops = [
    ['insert', 'INSERT'],
    ['update', 'UPDATE'],
    ['delete', 'DELETE'],
  ];
  for (const [table, rule] of Object.entries(policies)) {
    const qTable = quoteIdent(table);
    for (const [key, sqlOp] of ops) {
      const trigName = '_rls_' + table + '_' + key;
      db.exec('DROP TRIGGER IF EXISTS ' + '"' + trigName + '"', [], { mode: 'admin' });
      const expr = rule && rule[key];
      if (expr === undefined || expr === null) continue;
      if (typeof expr !== 'string' || expr.trim().length === 0) throw new Error('RLS_EXPR_INVALID');
      // Validate pure single read-only SQL expression using SQLite's own parser in mode:'readonly'
      db.validateExpr(table, sqlOp, expr);
      const triggerSql =
        'CREATE TRIGGER "' + trigName + '" BEFORE ' + sqlOp + ' ON ' + qTable +
        " BEGIN SELECT CASE WHEN NOT (" + expr + ") THEN RAISE(ABORT, 'rls_denied:" + table + ":" + key + "') END; END";
      db.exec(triggerSql, [], { mode: 'admin' });
    }
  }
}

export function ensureTableOwners(db) {
  db.exec(
    'CREATE TABLE IF NOT EXISTS _rls_table_owners (name TEXT PRIMARY KEY NOT NULL, owner TEXT NOT NULL)',
    [],
    { mode: 'admin' },
  );
}

export function getOwnedTables(db, owner) {
  ensureTableOwners(db);
  const res = db.query('SELECT name FROM _rls_table_owners WHERE owner = ? ORDER BY name', [owner]);
  return res.rows.map(r => r[0]);
}

export function recordTableOwners(db, createdTables, droppedTables, owner) {
  ensureTableOwners(db);
  for (const name of createdTables || []) {
    db.exec('INSERT OR REPLACE INTO _rls_table_owners (name, owner) VALUES (?, ?)', [name, owner], { mode: 'admin' });
  }
  for (const name of droppedTables || []) {
    db.exec('DELETE FROM _rls_table_owners WHERE name = ?', [name], { mode: 'admin' });
  }
}

/**
 * Install automatic row-version stamping triggers on tables that have '_last_op_id TEXT'
 * (and optional '_updated_at INTEGER') columns. Powers 1-line 'based_on_row' optimistic concurrency.
 */
export function stampRowOp(db, tables, options = {}) {
  const list = Array.isArray(tables) ? tables : [tables];
  const withUpdatedAt = options && options.updatedAt === true;
  for (const table of list) {
    const qTable = quoteIdent(table);
    const insName = '_rls_stamp_' + table + '_ins';
    const updName = '_rls_stamp_' + table + '_upd';
    db.exec('DROP TRIGGER IF EXISTS "' + insName + '"', [], { mode: 'admin' });
    db.exec('DROP TRIGGER IF EXISTS "' + updName + '"', [], { mode: 'admin' });
    const setClause = withUpdatedAt
      ? '_last_op_id = op_id(), _updated_at = op_time()'
      : '_last_op_id = op_id()';
    db.exec(
      'CREATE TRIGGER "' + insName + '" AFTER INSERT ON ' + qTable +
      ' WHEN NEW._last_op_id IS NOT op_id() BEGIN UPDATE ' + qTable +
      ' SET ' + setClause + ' WHERE rowid = NEW.rowid; END',
      [],
      { mode: 'admin' },
    );
    db.exec(
      'CREATE TRIGGER "' + updName + '" AFTER UPDATE ON ' + qTable +
      ' WHEN NEW._last_op_id IS NOT op_id() BEGIN UPDATE ' + qTable +
      ' SET ' + setClause + ' WHERE rowid = NEW.rowid; END',
      [],
      { mode: 'admin' },
    );
    db.exec(
      'UPDATE ' + qTable + ' SET ' + setClause + ' WHERE _last_op_id IS NULL',
      [],
      { mode: 'admin' },
    );
  }
}

export function ensureConflictsTable(db) {
  db.exec(
    'CREATE TABLE IF NOT EXISTS _chronolog_conflicts (' +
    'op_id TEXT PRIMARY KEY NOT NULL, ' +
    'author TEXT NOT NULL, ' +
    'author_time INTEGER NOT NULL, ' +
    'code TEXT NOT NULL, ' +
    'detail TEXT, ' +
    'payload_json TEXT NOT NULL, ' +
    'resolved INTEGER NOT NULL DEFAULT 0, ' +
    'resolution TEXT' +
    ')',
    [],
    { mode: 'admin' },
  );
}

export function recordConflict(db, tx, failure) {
  ensureConflictsTable(db);
  db.exec(
    'INSERT OR REPLACE INTO _chronolog_conflicts (op_id, author, author_time, code, detail, payload_json, resolved, resolution) VALUES (?, ?, ?, ?, ?, ?, 0, NULL)',
    [
      String(tx.opId),
      String(tx.author),
      Number(tx.authorTimestampMs || 0),
      String((failure && failure.code) || 'assumption:failed'),
      failure && failure.detail ? String(failure.detail) : null,
      JSON.stringify(tx.payload === undefined ? null : tx.payload),
    ],
    { mode: 'admin' },
  );
}

export function ensureAuditTable(db) {
  db.exec(
    'CREATE TABLE IF NOT EXISTS _chronolog_audit (' +
    'seq INTEGER PRIMARY KEY AUTOINCREMENT, ' +
    'table_name TEXT NOT NULL, ' +
    'row_rowid INTEGER NOT NULL, ' +
    'action TEXT NOT NULL, ' +
    'actor TEXT NOT NULL, ' +
    'op_id TEXT NOT NULL, ' +
    'op_time INTEGER NOT NULL, ' +
    'before_json TEXT, ' +
    'after_json TEXT' +
    ')',
    [],
    { mode: 'admin' },
  );
}

/**
 * Install deterministic AFTER INSERT/UPDATE/DELETE audit triggers on tables, recording
 * actor(), op_id(), op_time(), and JSON row snapshots into _chronolog_audit.
 */
export function enableAuditLog(db, tables) {
  ensureAuditTable(db);
  const list = Array.isArray(tables) ? tables : [tables];
  for (const table of list) {
    const qTable = quoteIdent(table);
    const info = db.query('SELECT * FROM ' + qTable + ' LIMIT 0', []);
    const cols = Array.isArray(info.columns) ? info.columns : [];
    const quoteCol = c => {
      if (typeof c !== 'string' || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(c)) {
        throw new Error('RLS_INVALID_COLUMN:' + String(c));
      }
      return '"' + c + '"';
    };
    const buildJsonObj = prefix => {
      if (cols.length === 0) return "'{}'";
      const pairs = cols.map(c => "'" + String(c).replace(/'/g, "''") + "', " + prefix + '.' + quoteCol(c));
      return 'json_object(' + pairs.join(', ') + ')';
    };
    const insTrig = '_rls_audit_' + table + '_ins';
    const updTrig = '_rls_audit_' + table + '_upd';
    const delTrig = '_rls_audit_' + table + '_del';
    db.exec('DROP TRIGGER IF EXISTS "' + insTrig + '"', [], { mode: 'admin' });
    db.exec('DROP TRIGGER IF EXISTS "' + updTrig + '"', [], { mode: 'admin' });
    db.exec('DROP TRIGGER IF EXISTS "' + delTrig + '"', [], { mode: 'admin' });
    db.exec(
      'CREATE TRIGGER "' + insTrig + '" AFTER INSERT ON ' + qTable +
      " BEGIN INSERT INTO _chronolog_audit (table_name, row_rowid, action, actor, op_id, op_time, before_json, after_json) VALUES ('" +
      table + "', NEW.rowid, 'insert', actor(), op_id(), op_time(), NULL, " + buildJsonObj('NEW') + '); END',
      [],
      { mode: 'admin' },
    );
    db.exec(
      'CREATE TRIGGER "' + updTrig + '" AFTER UPDATE ON ' + qTable +
      " BEGIN INSERT INTO _chronolog_audit (table_name, row_rowid, action, actor, op_id, op_time, before_json, after_json) VALUES ('" +
      table + "', NEW.rowid, 'update', actor(), op_id(), op_time(), " + buildJsonObj('OLD') + ', ' + buildJsonObj('NEW') + '); END',
      [],
      { mode: 'admin' },
    );
    db.exec(
      'CREATE TRIGGER "' + delTrig + '" AFTER DELETE ON ' + qTable +
      " BEGIN INSERT INTO _chronolog_audit (table_name, row_rowid, action, actor, op_id, op_time, before_json, after_json) VALUES ('" +
      table + "', OLD.rowid, 'delete', actor(), op_id(), op_time(), " + buildJsonObj('OLD') + ', NULL); END',
      [],
      { mode: 'admin' },
    );
  }
}

export function queryAuditHistory(db, options = {}) {
  const hasTable = db.query("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = '_chronolog_audit'", []);
  if (hasTable.rows.length === 0) return [];
  const limit = Number.isSafeInteger(options.limit) && options.limit > 0 ? Math.min(options.limit, 500) : 100;
  const where = [];
  const params = [];
  if (typeof options.table === 'string' && options.table.length > 0) {
    where.push('table_name = ?');
    params.push(options.table);
  }
  if (typeof options.opId === 'string' && options.opId.length > 0) {
    where.push('op_id = ?');
    params.push(options.opId);
  }
  const whereSql = where.length > 0 ? ' WHERE ' + where.join(' AND ') : '';
  params.push(limit);
  const res = db.query(
    'SELECT seq, table_name, row_rowid, action, actor, op_id, op_time, before_json, after_json FROM _chronolog_audit' +
    whereSql + ' ORDER BY seq DESC LIMIT ?',
    params,
  );
  return res.rows.map(r => ({
    seq: r[0],
    table: r[1],
    rowid: r[2],
    action: r[3],
    actor: r[4],
    opId: r[5],
    opTimeMs: r[6],
    before: r[7] ? JSON.parse(String(r[7])) : null,
    after: r[8] ? JSON.parse(String(r[8])) : null,
  }));
}
`.trimStart();
var STD_SQL_SOURCE = `
import { openDb } from 'chronolog:sqlite';
import { applyRls, enableAuditLog, ensureConflictsTable, getOwnedTables, queryAuditHistory, recordConflict, recordTableOwners, stampRowOp } from 'chronolog/rls';

function extractTouchedTables(sql) {
  const out = [];
  const re = /(?:INSERT\\s+(?:OR\\s+\\w+\\s+)?INTO|UPDATE\\s+(?:OR\\s+\\w+\\s+)?|DELETE\\s+FROM|CREATE\\s+(?:VIRTUAL\\s+)?TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?|ALTER\\s+TABLE|DROP\\s+TABLE\\s+(?:IF\\s+EXISTS\\s+)?)\\s+["']?([A-Za-z_][A-Za-z0-9_]*)["']?/gi;
  let m;
  while ((m = re.exec(String(sql))) !== null) {
    if (m[1] && !out.includes(m[1])) out.push(m[1]);
  }
  return out;
}

function hasCapability(ctx, capability, actor, extra) {
  const queryInput = extra ? { check: capability, actor, ...extra } : { check: capability, actor };
  const checked = ctx.query('$permissions', queryInput);
  if (typeof checked === 'boolean') return checked;
  const perms = ctx.topic('$permissions');
  if (!perms || !Array.isArray(perms.members)) return false;
  const m = perms.members.find(x => x.publicKey === actor);
  if (!m) return false;
  if (capability === 'administrator') return m.administrator === true;
  if (capability === 'writer') return m.writer === true || m.administrator === true;
  if (capability === 'reader') return m.reader === true;
  return false;
}

function normalizeSqlState(state, config) {
  const cfg = config && typeof config === 'object' ? config : {};
  const s = state && typeof state === 'object' ? state : {};
  return {
    dbRoot: typeof s.dbRoot === 'string' ? s.dbRoot : null,
    schemaVersion: Number.isSafeInteger(s.schemaVersion) ? s.schemaVersion : 0,
    policies: s.policies && typeof s.policies === 'object' && !Array.isArray(s.policies) ? { ...s.policies } : {},
    allowUserDdl: s.allowUserDdl !== undefined ? Boolean(s.allowUserDdl) : cfg.allowUserDdl !== false,
  };
}

function normalizeStatement(stmt) {
  if (typeof stmt === 'string') return { sql: stmt, params: [] };
  if (stmt && typeof stmt === 'object' && typeof stmt.sql === 'string') {
    return { sql: stmt.sql, params: Array.isArray(stmt.params) ? stmt.params : [] };
  }
  return null;
}

function quoteSqlIdent(name) {
  if (typeof name !== 'string' || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(name)) {
    throw new Error('SQL_INVALID_IDENTIFIER:' + String(name));
  }
  return '"' + name + '"';
}

function buildWhereClause(whereObj) {
  if (!whereObj || typeof whereObj !== 'object' || Array.isArray(whereObj)) {
    throw new Error('PRECONDITION_WHERE_INVALID');
  }
  const keys = Object.keys(whereObj).sort();
  if (keys.length === 0) throw new Error('PRECONDITION_WHERE_EMPTY');
  const clauses = [];
  const params = [];
  for (const k of keys) {
    const val = whereObj[k];
    if (val === null) {
      clauses.push(quoteSqlIdent(k) + ' IS NULL');
    } else {
      clauses.push(quoteSqlIdent(k) + ' = ?');
      params.push(val);
    }
  }
  return { clause: clauses.join(' AND '), params };
}

function checkPreconditions(db, preconditions) {
  if (!Array.isArray(preconditions)) return { ok: true };
  for (let i = 0; i < preconditions.length; i++) {
    const pre = preconditions[i];
    if (!pre || typeof pre !== 'object') {
      return { ok: false, code: 'sql:invalid_precondition', detail: 'Precondition ' + i + ' invalid' };
    }
    const failCode = typeof pre.code === 'string' && pre.code.length > 0 ? pre.code : 'sql:precondition_failed';

    if (pre.kind === 'based_on_row') {
      try {
        const qTable = quoteSqlIdent(pre.table);
        const { clause, params } = buildWhereClause(pre.where);
        const res = db.query('SELECT _last_op_id FROM ' + qTable + ' WHERE ' + clause, params);
        if (pre.lastOpId === null) {
          if (res.rows.length > 0) {
            return { ok: false, code: failCode === 'sql:precondition_failed' ? 'sql:row_already_exists' : failCode, detail: 'Expected row to not exist in ' + pre.table };
          }
          continue;
        }
        if (res.rows.length !== 1) {
          return { ok: false, code: failCode === 'sql:precondition_failed' ? 'sql:row_missing' : failCode, detail: 'Expected 1 row in ' + pre.table + ', got ' + res.rows.length };
        }
        if (res.rows[0][0] !== pre.lastOpId) {
          return { ok: false, code: failCode === 'sql:precondition_failed' ? 'sql:row_modified' : failCode, detail: 'Row in ' + pre.table + ' modified (expected op ' + pre.lastOpId + ', got ' + String(res.rows[0][0]) + ')' };
        }
        continue;
      } catch (err) {
        return { ok: false, code: failCode, detail: String(err && err.message ? err.message : err) };
      }
    }

    if (pre.kind === 'row_matches') {
      try {
        const qTable = quoteSqlIdent(pre.table);
        const { clause, params } = buildWhereClause(pre.where);
        const expectObj = pre.expect && typeof pre.expect === 'object' && !Array.isArray(pre.expect) ? pre.expect : null;
        if (!expectObj) return { ok: false, code: 'sql:invalid_precondition', detail: 'row_matches requires expect object' };
        const cols = Object.keys(expectObj).sort();
        if (cols.length === 0) return { ok: false, code: 'sql:invalid_precondition', detail: 'row_matches expect empty' };
        const sel = cols.map(quoteSqlIdent).join(', ');
        const res = db.query('SELECT ' + sel + ' FROM ' + qTable + ' WHERE ' + clause, params);
        if (res.rows.length !== 1) {
          return { ok: false, code: failCode, detail: 'Expected 1 matching row in ' + pre.table + ', got ' + res.rows.length };
        }
        for (let c = 0; c < cols.length; c++) {
          const actual = res.rows[0][c];
          const expected = expectObj[cols[c]];
          if (JSON.stringify(actual) !== JSON.stringify(expected)) {
            return { ok: false, code: failCode, detail: 'Column ' + cols[c] + ' expected ' + JSON.stringify(expected) + ', got ' + JSON.stringify(actual) };
          }
        }
        continue;
      } catch (err) {
        return { ok: false, code: failCode, detail: String(err && err.message ? err.message : err) };
      }
    }

    if (typeof pre.sql !== 'string') {
      return { ok: false, code: 'sql:invalid_precondition', detail: 'Precondition ' + i + ' missing sql' };
    }
    let res;
    try {
      res = db.query(pre.sql, Array.isArray(pre.params) ? pre.params : []);
    } catch (err) {
      return { ok: false, code: failCode, detail: String(err && err.message ? err.message : err) };
    }
    const exp = pre.expect;
    if (exp === undefined || exp === null) {
      const ok = res.rows.length > 0 && Boolean(res.rows[0][0]);
      if (!ok) return { ok: false, code: failCode, detail: 'Precondition ' + i + ' evaluated falsy' };
      continue;
    }
    if (typeof exp !== 'object') {
      return { ok: false, code: 'sql:invalid_precondition', detail: 'Precondition ' + i + ' expect must be an object' };
    }
    if (exp.exists !== undefined) {
      const hasRows = res.rows.length > 0;
      if (hasRows !== Boolean(exp.exists)) {
        return { ok: false, code: failCode, detail: 'Expected exists=' + Boolean(exp.exists) + ', got ' + hasRows };
      }
    }
    if (exp.rowCount !== undefined && res.rows.length !== exp.rowCount) {
      return { ok: false, code: failCode, detail: 'Expected rowCount ' + exp.rowCount + ', got ' + res.rows.length };
    }
    if (exp.minRows !== undefined && res.rows.length < exp.minRows) {
      return { ok: false, code: failCode, detail: 'Expected minRows ' + exp.minRows + ', got ' + res.rows.length };
    }
    if (exp.maxRows !== undefined && res.rows.length > exp.maxRows) {
      return { ok: false, code: failCode, detail: 'Expected maxRows ' + exp.maxRows + ', got ' + res.rows.length };
    }
    if (exp.firstValue !== undefined) {
      const actual = res.rows.length > 0 ? res.rows[0][0] : undefined;
      if (JSON.stringify(actual) !== JSON.stringify(exp.firstValue)) {
        return { ok: false, code: failCode, detail: 'Expected firstValue ' + JSON.stringify(exp.firstValue) + ', got ' + JSON.stringify(actual) };
      }
    }
    if (exp.equals !== undefined) {
      if (JSON.stringify(res.rows) !== JSON.stringify(exp.equals)) {
        return { ok: false, code: failCode, detail: 'Precondition ' + i + ' rows mismatch' };
      }
    }
  }
  return { ok: true };
}

function extractSqlErrorCode(err) {
  const msg = String(err && err.message ? err.message : err);
  const rls = /rls_denied:[A-Za-z0-9_]+:(?:insert|update|delete)/.exec(msg);
  if (rls) return rls[0];
  if (/not authorized|AUTHORIZER/i.test(msg)) return 'sql:not_authorized';
  if (/UNIQUE constraint|PRIMARY KEY/i.test(msg)) return 'sql:constraint_unique';
  if (/FOREIGN KEY constraint/i.test(msg)) return 'sql:constraint_fk';
  if (/CHECK constraint/i.test(msg)) return 'sql:constraint_check';
  if (/NOT NULL constraint/i.test(msg)) return 'sql:constraint_not_null';
  return 'sql:error';
}

function normalizeEvents(events) {
  if (!Array.isArray(events)) return [];
  const out = [];
  for (const ev of events) {
    if (ev && typeof ev === 'object' && typeof ev.topic === 'string' && ev.topic.length > 0) {
      out.push({ topic: ev.topic, payload: ev.payload === undefined ? null : ev.payload });
    }
  }
  return out;
}

function rowsToObjects(res) {
  return res.rows.map(row => {
    const obj = {};
    for (let i = 0; i < res.columns.length; i++) obj[res.columns[i]] = row[i];
    return obj;
  });
}

function mergeRlsPolicies(existing, incoming) {
  const next = { ...existing };
  const toApply = {};
  for (const [table, rule] of Object.entries(incoming)) {
    if (rule === null) {
      delete next[table];
      toApply[table] = { insert: null, update: null, delete: null };
      continue;
    }
    if (!rule || typeof rule !== 'object' || Array.isArray(rule)) {
      throw new Error('RLS_POLICIES_INVALID');
    }
    const merged = { ...(existing[table] || {}), ...rule };
    const clean = {};
    for (const op of ['insert', 'update', 'delete']) {
      if (merged[op] !== undefined && merged[op] !== null) clean[op] = merged[op];
    }
    if (Object.keys(clean).length === 0) delete next[table];
    else next[table] = clean;
    toApply[table] = {
      insert: merged.insert ?? null,
      update: merged.update ?? null,
      delete: merged.delete ?? null,
    };
  }
  return { nextPolicies: next, toApply };
}

/**
 * First-class deterministic Merkle-paged SQLite topic reducer.
 * - Declarative SQL transactions with atomic preconditions, postconditions, and automatic rollback on failure
 * - Postgres-style write RLS policies (chronolog/rls) + host-bound actor()/op_id()/op_time()
 * - Admin DDL (mode:'admin') and non-admin user-owned dynamic table & view DDL (mode:'user')
 * - Multiple topics in one chain can each bind chronolog/sql for independent hash-addressed databases
 */
export const sqlDatabase = {
  reduce(state, tx, ctx) {
    const cur = normalizeSqlState(state, ctx.config);
    const input = tx.payload;
    if (!input || typeof input !== 'object' || Array.isArray(input)) {
      return { ok: false, code: 'invalid_input' };
    }

    const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
    const allowPublicWrite = cfg.allowPublicWrite === true;
    const atMs = Number(tx.authorTimestampMs || 0);
    const isAdmin = hasCapability(ctx, 'administrator', tx.author, { atMs });
    const isWriter = allowPublicWrite || isAdmin || hasCapability(ctx, 'writer', tx.author, { atMs });
    const action = typeof input.action === 'string' ? input.action : 'exec';

    if (action === 'setConfig') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const next = {
        ...cur,
        ...(input.allowUserDdl === undefined ? {} : { allowUserDdl: Boolean(input.allowUserDdl) }),
      };
      return { ok: true, state: next, events: normalizeEvents(input.events) };
    }

    if (action === 'setRls' || action === 'setPolicies') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      if (!input.policies || typeof input.policies !== 'object' || Array.isArray(input.policies)) {
        return { ok: false, code: 'rls:invalid_policies' };
      }
      const db = openDb(cur.dbRoot);
      try {
        const { nextPolicies, toApply } = mergeRlsPolicies(cur.policies, input.policies);
        applyRls(db, toApply);
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { ...cur, dbRoot, policies: nextPolicies },
          events: normalizeEvents(input.events).concat([{ topic: 'sql.rls_updated', payload: { tables: Object.keys(input.policies) } }]),
        };
      } catch (err) {
        return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
      } finally {
        db.close();
      }
    }

    if (action === 'migrate') {
      if (!isAdmin) return { ok: false, code: 'admin_required' };
      const statements = Array.isArray(input.statements) ? input.statements : [];
      const db = openDb(cur.dbRoot);
      try {
        const preCheck = checkPreconditions(db, input.preconditions);
        if (!preCheck.ok) {
          if (input.onPreconditionFailed === 'record_conflict') {
            recordConflict(db, tx, preCheck);
            const dbRoot = db.commit();
            return {
              ok: true,
              state: { ...cur, dbRoot },
              events: [{ topic: 'sql.conflict_recorded', payload: { opId: tx.opId, code: preCheck.code, detail: preCheck.detail || null } }],
            };
          }
          return preCheck;
        }
        for (const rawStmt of statements) {
          const stmt = normalizeStatement(rawStmt);
          if (!stmt) return { ok: false, code: 'sql:invalid_statement' };
          db.exec(stmt.sql, stmt.params, { mode: 'admin' });
        }
        let nextPolicies = cur.policies;
        if (input.policies && typeof input.policies === 'object' && !Array.isArray(input.policies)) {
          const merged = mergeRlsPolicies(cur.policies, input.policies);
          applyRls(db, merged.toApply);
          nextPolicies = merged.nextPolicies;
        }
        if (Array.isArray(input.stampTables) && input.stampTables.length > 0) {
          stampRowOp(db, input.stampTables, { updatedAt: input.stampUpdatedAt === true });
        }
        if (Array.isArray(input.auditTables) && input.auditTables.length > 0) {
          enableAuditLog(db, input.auditTables);
        }
        const postCheck = checkPreconditions(db, input.postconditions);
        if (!postCheck.ok) return postCheck;
        const dbRoot = db.commit();
        const schemaVersion = Number.isSafeInteger(input.schemaVersion) ? input.schemaVersion : cur.schemaVersion + 1;
        const allowUserDdl = input.allowUserDdl === undefined ? cur.allowUserDdl : Boolean(input.allowUserDdl);
        return {
          ok: true,
          state: { ...cur, dbRoot, schemaVersion, policies: nextPolicies, allowUserDdl },
          events: normalizeEvents(input.events).concat([{ topic: 'sql.migrated', payload: { schemaVersion } }]),
        };
      } catch (err) {
        return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
      } finally {
        db.close();
      }
    }

    if (action === 'exec') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      if (!isAdmin && typeof input.requiredScope === 'string' && input.requiredScope.length > 0) {
        if (!hasCapability(ctx, 'scope', tx.author, { scope: input.requiredScope, atMs })) {
          return { ok: false, code: 'scope_required', detail: input.requiredScope };
        }
      }
      const mode = input.mode === 'admin' ? 'admin' : 'user';
      if (mode === 'admin' && !isAdmin) return { ok: false, code: 'admin_required' };
      const statements = Array.isArray(input.statements)
        ? input.statements
        : typeof input.sql === 'string'
          ? [{ sql: input.sql, params: Array.isArray(input.params) ? input.params : [] }]
          : null;
      if (!statements || (statements.length === 0 && !Array.isArray(input.preconditions))) {
        return { ok: false, code: 'sql:statements_required' };
      }

      const db = openDb(cur.dbRoot);
      try {
        const preCheck = checkPreconditions(db, input.preconditions);
        if (!preCheck.ok) {
          if (input.onPreconditionFailed === 'record_conflict') {
            recordConflict(db, tx, preCheck);
            const dbRoot = db.commit();
            return {
              ok: true,
              state: { ...cur, dbRoot },
              events: [{ topic: 'sql.conflict_recorded', payload: { opId: tx.opId, code: preCheck.code, detail: preCheck.detail || null } }],
            };
          }
          return preCheck;
        }

        let owned = mode === 'user' && cur.allowUserDdl ? getOwnedTables(db, tx.author) : null;
        const touchedSet = new Set();
        for (const rawStmt of statements) {
          const stmt = normalizeStatement(rawStmt);
          if (!stmt) return { ok: false, code: 'sql:invalid_statement' };
          for (const tbl of extractTouchedTables(stmt.sql)) touchedSet.add(tbl);
          const execOpts = mode === 'admin'
            ? { mode: 'admin' }
            : cur.allowUserDdl
              ? {
                  mode: 'user',
                  ddl: {
                    createTable: true,
                    alterTable: owned,
                    dropTable: owned,
                    indexOn: owned,
                    createView: true,
                    dropView: owned,
                  },
                }
              : { mode: 'user' };
          const res = db.exec(stmt.sql, stmt.params, execOpts);
          const created = (res.createdTables || []).concat(res.createdViews || []);
          const dropped = (res.droppedTables || []).concat(res.droppedViews || []);
          for (const tbl of created) touchedSet.add(tbl);
          for (const tbl of dropped) touchedSet.add(tbl);
          if (mode === 'user' && cur.allowUserDdl && (created.length > 0 || dropped.length > 0)) {
            recordTableOwners(db, created, dropped, tx.author);
            owned = getOwnedTables(db, tx.author);
          }
        }

        const postCheck = checkPreconditions(db, input.postconditions);
        if (!postCheck.ok) return postCheck;

        const dbRoot = db.commit();
        const touchedTables = Array.from(touchedSet).sort();
        const baseEvents = normalizeEvents(input.events);
        const events = touchedTables.length > 0
          ? baseEvents.concat([{ topic: 'sql.tables_changed', payload: { tables: touchedTables, dbRoot } }])
          : baseEvents;
        return {
          ok: true,
          state: { ...cur, dbRoot },
          events,
        };
      } catch (err) {
        return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
      } finally {
        db.close();
      }
    }

    if (action === 'resolveConflict') {
      if (!isWriter) return { ok: false, code: 'writer_required' };
      if (typeof input.opId !== 'string' || input.opId.length === 0) return { ok: false, code: 'sql:invalid_conflict_id' };
      const db = openDb(cur.dbRoot);
      try {
        ensureConflictsTable(db);
        const existing = db.query('SELECT author FROM _chronolog_conflicts WHERE op_id = ?', [input.opId]);
        if (existing.rows.length === 0) return { ok: false, code: 'sql:conflict_not_found' };
        if (!isAdmin && existing.rows[0][0] !== tx.author) return { ok: false, code: 'conflict_owner_or_admin_required' };
        db.exec(
          'UPDATE _chronolog_conflicts SET resolved = 1, resolution = ? WHERE op_id = ?',
          [typeof input.resolution === 'string' ? input.resolution : 'resolved', input.opId],
          { mode: 'admin' },
        );
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { ...cur, dbRoot },
          events: normalizeEvents(input.events).concat([{ topic: 'sql.conflict_resolved', payload: { opId: input.opId } }]),
        };
      } catch (err) {
        return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
      } finally {
        db.close();
      }
    }

    return { ok: false, code: 'unknown_action' };
  },

  onConflict(state, tx, ctx, failure) {
    const cur = normalizeSqlState(state, ctx.config);
    const cfg = ctx.config && typeof ctx.config === 'object' ? ctx.config : {};
    const allowPublicWrite = cfg.allowPublicWrite === true;
    const isAdmin = hasCapability(ctx, 'administrator', tx.author);
    const isWriter = allowPublicWrite || isAdmin || hasCapability(ctx, 'writer', tx.author);
    if (!isWriter) return { ok: false, code: 'writer_required' };
    const db = openDb(cur.dbRoot);
    try {
      recordConflict(db, tx, failure);
      const dbRoot = db.commit();
      return {
        ok: true,
        state: { ...cur, dbRoot },
        events: [{ topic: 'sql.conflict_recorded', payload: { opId: tx.opId, code: (failure && failure.code) || 'assumption:failed', detail: (failure && failure.detail) || null } }],
      };
    } catch (err) {
      return { ok: false, code: extractSqlErrorCode(err), detail: String(err && err.message ? err.message : err) };
    } finally {
      db.close();
    }
  },

  query(state, input, ctx) {
    const cur = normalizeSqlState(state, ctx.config);
    if (input === null || input === undefined) {
      return {
        dbRoot: cur.dbRoot,
        schemaVersion: cur.schemaVersion,
        policies: cur.policies,
        allowUserDdl: cur.allowUserDdl,
      };
    }
    const kind = typeof input === 'object' ? (input.query || input.kind || input.action) : null;
    if (typeof input === 'object' && typeof input.sql === 'string') {
      const db = openDb(cur.dbRoot);
      try {
        const res = db.query(input.sql, Array.isArray(input.params) ? input.params : []);
        return input.format === 'objects'
          ? { columns: res.columns, rows: rowsToObjects(res) }
          : res;
      } finally {
        db.close();
      }
    }
    if (kind === 'audit') {
      const db = openDb(cur.dbRoot);
      try {
        return { dbRoot: cur.dbRoot, audit: queryAuditHistory(db, input || {}) };
      } finally {
        db.close();
      }
    }
    if (kind === 'conflicts') {
      const db = openDb(cur.dbRoot);
      try {
        const hasTable = db.query("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = '_chronolog_conflicts'", []);
        if (hasTable.rows.length === 0) return { dbRoot: cur.dbRoot, conflicts: [] };
        const unresolvedOnly = input && input.unresolvedOnly !== false;
        const sql = unresolvedOnly
          ? 'SELECT op_id, author, author_time, code, detail, payload_json, resolved, resolution FROM _chronolog_conflicts WHERE resolved = 0 ORDER BY author_time DESC'
          : 'SELECT op_id, author, author_time, code, detail, payload_json, resolved, resolution FROM _chronolog_conflicts ORDER BY author_time DESC';
        const res = db.query(sql, []);
        return {
          dbRoot: cur.dbRoot,
          conflicts: res.rows.map(r => ({
            opId: r[0],
            author: r[1],
            authorTimeMs: r[2],
            code: r[3],
            detail: r[4],
            payload: JSON.parse(String(r[5] || 'null')),
            resolved: Boolean(r[6]),
            resolution: r[7],
          })),
        };
      } finally {
        db.close();
      }
    }
    if (kind === 'tables') {
      const db = openDb(cur.dbRoot);
      try {
        const res = db.query("SELECT name, type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_rls_%' ORDER BY name", []);
        return { dbRoot: cur.dbRoot, tables: res.rows.map(r => ({ name: r[0], type: r[1] })) };
      } finally {
        db.close();
      }
    }
    if (kind === 'schema') {
      const db = openDb(cur.dbRoot);
      try {
        const res = db.query("SELECT type, name, tbl_name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name", []);
        const objects = res.rows.map(r => ({ type: r[0], name: r[1], table: r[2], sql: r[3] }));
        const owners = {};
        const hasOwners = objects.some(o => o.type === 'table' && o.name === '_rls_table_owners');
        if (hasOwners) {
          const ownRes = db.query('SELECT name, owner FROM _rls_table_owners ORDER BY name', []);
          for (const row of ownRes.rows) owners[String(row[0])] = String(row[1]);
        }
        const tables = [];
        for (const obj of objects) {
          if ((obj.type !== 'table' && obj.type !== 'view') || String(obj.name).startsWith('_rls_')) continue;
          const quoted = '"' + String(obj.name).replace(/"/g, '""') + '"';
          let columns = [];
          try {
            const info = db.query('SELECT * FROM ' + quoted + ' LIMIT 0', []);
            columns = Array.isArray(info.columns) ? info.columns.slice() : [];
          } catch {}
          tables.push({
            name: obj.name,
            type: obj.type,
            owner: Object.prototype.hasOwnProperty.call(owners, obj.name) ? owners[obj.name] : null,
            columns,
            rls: Object.prototype.hasOwnProperty.call(cur.policies, obj.name) ? cur.policies[obj.name] : null,
          });
        }
        return {
          dbRoot: cur.dbRoot,
          schemaVersion: cur.schemaVersion,
          policies: cur.policies,
          allowUserDdl: cur.allowUserDdl,
          userOwnedObjects: owners,
          tables,
          objects,
        };
      } finally {
        db.close();
      }
    }
    return {
      dbRoot: cur.dbRoot,
      schemaVersion: cur.schemaVersion,
      policies: cur.policies,
      allowUserDdl: cur.allowUserDdl,
    };
  },

  describe() {
    const scalarParam = {
      anyOf: [{ type: 'string' }, { type: 'number' }, { type: 'boolean' }, { type: 'null' }],
    };
    const statementSchema = {
      anyOf: [
        { type: 'string' },
        {
          type: 'object',
          properties: {
            sql: { type: 'string' },
            params: { type: 'array', items: scalarParam },
          },
          required: ['sql'],
        },
      ],
    };
    return {
      commands: [
        {
          name: 'exec',
          description: 'Execute a deterministic SQL transaction with optional atomic preconditions under write RLS.',
          input: {
            type: 'object',
            properties: {
              mode: { type: 'string', enum: ['user', 'admin'] },
              preconditions: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    sql: { type: 'string' },
                    params: { type: 'array', items: scalarParam },
                    code: { type: 'string' },
                  },
                  required: ['sql'],
                },
              },
              postconditions: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    sql: { type: 'string' },
                    params: { type: 'array', items: scalarParam },
                    code: { type: 'string' },
                  },
                  required: ['sql'],
                },
              },
              statements: { type: 'array', items: statementSchema },
              events: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: { topic: { type: 'string' } },
                  required: ['topic'],
                },
              },
            },
          },
        },
        {
          name: 'migrate',
          description: 'Run administrator DDL migrations and optionally install write RLS policies atomically.',
          input: {
            type: 'object',
            properties: {
              statements: { type: 'array', items: statementSchema },
              schemaVersion: { type: 'integer' },
              allowUserDdl: { type: 'boolean' },
            },
          },
        },
        {
          name: 'setRls',
          description: 'Install or update Postgres-style write RLS policies (administrator only).',
          input: {
            type: 'object',
            properties: {
              policies: { type: 'object', properties: {} },
            },
            required: ['policies'],
          },
        },
        {
          name: 'setConfig',
          description: 'Update SQL topic configuration such as allowUserDdl (administrator only).',
          input: {
            type: 'object',
            properties: {
              allowUserDdl: { type: 'boolean' },
            },
          },
        },
      ],
      queries: [
        {
          name: 'sql',
          description: 'Execute a read-only SQL query against the deterministic SQLite-CAS state.',
          input: {
            type: 'object',
            properties: {
              sql: { type: 'string' },
              params: { type: 'array', items: scalarParam },
              format: { type: 'string', enum: ['rows', 'objects'] },
            },
            required: ['sql'],
          },
        },
        {
          name: 'tables',
          description: 'List user tables and views in this SQLite-CAS database.',
          input: { type: 'object', properties: {} },
        },
        {
          name: 'schema',
          description: 'Inspect schema objects, dbRoot, and active write RLS policies.',
          input: { type: 'object', properties: {} },
        },
      ],
    };
  },
};

export default sqlDatabase;
`.trimStart();
var STD_SQLITE_HELPERS_SOURCE = `
import { openDb } from 'chronolog:sqlite';
import { applyRls } from 'chronolog/rls';

export function rowsToObjects(res) {
  return (res.rows || []).map(row => {
    const obj = {};
    for (let i = 0; i < res.columns.length; i++) obj[res.columns[i]] = row[i];
    return obj;
  });
}

/**
 * Open a deterministic chronolog:sqlite database, invoke fn(db), auto-close in finally,
 * and optionally commit when mutate === true.
 */
export function withDb(dbRoot, fn, options) {
  const db = openDb(dbRoot ?? null);
  try {
    const value = fn(db);
    if (options && options.commit === true) {
      return { value, dbRoot: db.commit() };
    }
    return value;
  } finally {
    db.close();
  }
}

/**
 * Build a concise, self-describing chronolog:sqlite ES Module reducer with automatic
 * schema/tables/read-only SQL query introspection, permission checks, and write RLS.
 */
export function defineSqlReducer(spec) {
  const commands = (spec && spec.commands) || {};
  const queries = (spec && spec.queries) || {};
  const setup = typeof (spec && spec.setup) === 'function' ? spec.setup : null;
  const policies = (spec && spec.policies) || null;
  const allowPublicWrite = Boolean(spec && spec.allowPublicWrite);

  function checkCap(ctx, cap, actor) {
    const checked = ctx.query('$permissions', { check: cap, actor });
    if (typeof checked === 'boolean') return checked;
    const perms = ctx.topic('$permissions');
    if (!perms || !Array.isArray(perms.members)) return false;
    const m = perms.members.find(x => x.publicKey === actor);
    if (!m) return false;
    if (cap === 'administrator') return m.administrator === true;
    if (cap === 'writer') return m.writer === true || m.administrator === true;
    return m.reader === true;
  }

  return {
    reduce(state, tx, ctx) {
      const cur = state && typeof state === 'object' ? state : { dbRoot: null, initialized: false };
      const input = tx.payload;
      if (!input || typeof input !== 'object' || Array.isArray(input)) {
        return { ok: false, code: 'invalid_input' };
      }
      const action = typeof input.action === 'string' ? input.action : null;
      const handler = action && Object.prototype.hasOwnProperty.call(commands, action) ? commands[action] : null;
      if (!handler) return { ok: false, code: 'unknown_action' };
      const reqAdmin = Boolean(handler.adminOnly);
      if (reqAdmin) {
        if (!checkCap(ctx, 'administrator', tx.author)) return { ok: false, code: 'admin_required' };
      } else if (!allowPublicWrite && !checkCap(ctx, 'writer', tx.author)) {
        return { ok: false, code: 'writer_required' };
      }
      const db = openDb(cur.dbRoot ?? null);
      try {
        if (!cur.initialized) {
          if (setup) setup(db);
          if (policies) applyRls(db, policies);
        }
        const run = typeof handler === 'function' ? handler : handler.run;
        const out = run(db, input, tx, ctx);
        if (out && out.ok === false) return out;
        const dbRoot = db.commit();
        return {
          ok: true,
          state: { ...cur, dbRoot, initialized: true },
          ...(out && Array.isArray(out.events) ? { events: out.events } : {}),
        };
      } catch (err) {
        const msg = String(err && err.message ? err.message : err);
        const rls = /rls_denied:[A-Za-z0-9_]+:(?:insert|update|delete)/.exec(msg);
        return { ok: false, code: rls ? rls[0] : 'sql:error', detail: msg };
      } finally {
        db.close();
      }
    },
    query(state, input, ctx) {
      const cur = state && typeof state === 'object' ? state : { dbRoot: null, initialized: false };
      const qObj = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
      const qName = typeof qObj.query === 'string' ? qObj.query : (typeof qObj.kind === 'string' ? qObj.kind : null);
      if (qName && Object.prototype.hasOwnProperty.call(queries, qName)) {
        const qHandler = queries[qName];
        const run = typeof qHandler === 'function' ? qHandler : qHandler.run;
        return withDb(cur.dbRoot, db => run(db, qObj, ctx));
      }
      if (typeof qObj.sql === 'string') {
        return withDb(cur.dbRoot, db => {
          const res = db.query(qObj.sql, Array.isArray(qObj.params) ? qObj.params : []);
          return qObj.format === 'objects' ? { columns: res.columns, rows: rowsToObjects(res) } : res;
        });
      }
      if (qName === 'tables') {
        return withDb(cur.dbRoot, db => {
          const res = db.query("SELECT name, type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_rls_%' ORDER BY name", []);
          return { dbRoot: cur.dbRoot, tables: res.rows.map(r => ({ name: r[0], type: r[1] })) };
        });
      }
      if (qName === 'schema') {
        return withDb(cur.dbRoot, db => {
          const res = db.query("SELECT type, name, tbl_name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name", []);
          const objects = res.rows.map(r => ({ type: r[0], name: r[1], table: r[2], sql: r[3] }));
          const tables = [];
          for (const obj of objects) {
            if ((obj.type !== 'table' && obj.type !== 'view') || String(obj.name).startsWith('_rls_')) continue;
            let columns = [];
            try {
              const info = db.query('SELECT * FROM "' + String(obj.name).replace(/"/g, '""') + '" LIMIT 0', []);
              columns = Array.isArray(info.columns) ? info.columns.slice() : [];
            } catch {}
            tables.push({ name: obj.name, type: obj.type, owner: null, columns, rls: policies && policies[obj.name] ? policies[obj.name] : null });
          }
          return { dbRoot: cur.dbRoot, schemaVersion: 1, policies: policies || {}, allowUserDdl: false, userOwnedObjects: {}, tables, objects };
        });
      }
      return { dbRoot: cur.dbRoot, initialized: Boolean(cur.initialized) };
    },
    describe() {
      return {
        commands: Object.entries(commands).map(([name, entry]) => ({
          name,
          description: (entry && entry.description) || '',
          input: (entry && entry.input) || { type: 'object', properties: {} },
        })),
        queries: [
          ...Object.entries(queries).map(([name, entry]) => ({
            name,
            description: (entry && entry.description) || '',
            input: (entry && entry.input) || { type: 'object', properties: {} },
          })),
          { name: 'schema', description: 'Inspect SQLite-CAS schema tables and RLS policies.', input: { type: 'object', properties: {} } },
          { name: 'tables', description: 'List user tables and views.', input: { type: 'object', properties: {} } },
        ],
      };
    },
  };
}
`.trimStart();
var STANDARD_MODULE_SOURCES = Object.freeze({
  "chronolog/permissions": STD_PERMISSIONS_SOURCE,
  "chronolog/keys": STD_KEYS_SOURCE,
  "chronolog/finality": STD_FINALITY_SOURCE,
  "chronolog/publications": STD_PUBLICATIONS_SOURCE,
  "chronolog/rls": STD_RLS_SOURCE,
  "chronolog/sql": STD_SQL_SOURCE,
  "chronolog/sqlite-helpers": STD_SQLITE_HELPERS_SOURCE,
  "chronolog/crdt": STD_CRDT_SOURCE,
  "chronolog/text": STD_TEXT_SOURCE,
  "chronolog/ledger": STD_LEDGER_SOURCE,
  "chronolog/workflow": STD_WORKFLOW_SOURCE,
  "chronolog/fs": STD_FS_SOURCE,
  "chronolog/mounts": STD_MOUNTS_SOURCE,
  "chronolog/builders": STD_BUILDERS_SOURCE,
  "chronolog/registry": STD_REGISTRY_SOURCE,
  "chronolog/finality-predicates": STD_FINALITY_PREDICATES_SOURCE,
  "chronolog/guards": STD_GUARDS_SOURCE,
  "chronolog/quotas": STD_QUOTAS_SOURCE,
  "chronolog/queue": STD_QUEUE_SOURCE,
  "chronolog/votes": STD_VOTES_SOURCE,
  "chronolog/schema": STD_SCHEMA_SOURCE,
  "chronolog/audit": STD_AUDIT_SOURCE
});
var STANDARD_MODULE_BUILTINS = Object.freeze({
  "chronolog/permissions": ["chronolog:crypto"],
  "chronolog/keys": ["chronolog:crypto"],
  "chronolog/finality": ["chronolog:crypto"],
  "chronolog/publications": ["chronolog:crypto"],
  "chronolog/rls": [],
  "chronolog/sql": ["chronolog:sqlite"],
  "chronolog/sqlite-helpers": ["chronolog:sqlite"],
  "chronolog/crdt": [],
  "chronolog/text": [],
  "chronolog/ledger": [],
  "chronolog/workflow": [],
  "chronolog/fs": ["chronolog:cas"],
  "chronolog/mounts": ["chronolog:crypto"],
  "chronolog/builders": ["chronolog:crypto"],
  "chronolog/registry": ["chronolog:sqlite", "chronolog:crypto"],
  "chronolog/finality-predicates": ["chronolog:crypto"],
  "chronolog/guards": [],
  "chronolog/quotas": [],
  "chronolog/queue": [],
  "chronolog/votes": [],
  "chronolog/schema": [],
  "chronolog/audit": ["chronolog:crypto"]
});
var STANDARD_MODULE_IMPORTS = Object.freeze(
  Object.fromEntries(
    Object.entries(STANDARD_MODULE_SOURCES).map(([spec, src]) => [spec, `cas:sha256-${computeCasHash(utf8(src))}`])
  )
);

// packages/materializer/src/quickjs-sandbox.ts
init_src();

// packages/protocol/src/bytes.ts
init_src();

// packages/protocol/src/errors.ts
var ProtocolError = class extends Error {
  code;
  details;
  constructor(code, message, details) {
    super(message);
    this.name = "ProtocolError";
    this.code = code;
    this.details = details;
  }
  toJSON() {
    return this.details === void 0 ? { name: this.name, code: this.code, message: this.message } : { name: this.name, code: this.code, message: this.message, details: this.details };
  }
};
function protocolInvariant(condition, code, message, details) {
  if (!condition) throw new ProtocolError(code, message, details);
}

// packages/protocol/src/bytes.ts
function wrap(operation) {
  try {
    return operation();
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
    throw error;
  }
}
function utf82(value) {
  return wrap(() => utf8(value));
}

// packages/protocol/src/cbor.ts
init_src();

// packages/protocol/src/primitives.ts
init_src();

// packages/protocol/src/v2.ts
init_src();
var CONTROL_TOPICS = Object.freeze([
  "$reducers",
  "$permissions",
  "$keys",
  "$finality",
  "$publications",
  "$signal_policy",
  "$mounts",
  "$builders"
]);
var CONTROL_TOPIC_SET = new Set(CONTROL_TOPICS);
function canonicalJson(payload, limits = { maxBytes: 65536, maxNodes: 8192, maxDepth: 32 }) {
  for (const bound of [limits.maxBytes, limits.maxNodes, limits.maxDepth]) {
    protocolInvariant(Number.isSafeInteger(bound) && bound > 0, "SCHEMA_INVALID", "Invalid JSON limits");
  }
  let nodes = 0;
  const visit = (value, depth) => {
    protocolInvariant(depth <= limits.maxDepth && ++nodes <= limits.maxNodes, "SCHEMA_INVALID", "JSON payload is too complex");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "Numbers must be finite");
      return JSON.stringify(Object.is(value, -0) ? 0 : value);
    }
    if (Array.isArray(value)) {
      protocolInvariant(Reflect.ownKeys(value).length === value.length + 1, "SCHEMA_INVALID", "Arrays cannot carry extra properties");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const desc = Object.getOwnPropertyDescriptor(value, i);
        protocolInvariant(desc !== void 0 && "value" in desc && desc.enumerable === true, "SCHEMA_INVALID", "Arrays require dense elements");
        entries.push(visit(desc.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    protocolInvariant(
      typeof value === "object" && value !== null && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null),
      "SCHEMA_INVALID",
      "Payload must contain JSON values"
    );
    const keys = Object.keys(value).sort();
    protocolInvariant(Reflect.ownKeys(value).length === keys.length, "SCHEMA_INVALID", "Objects require enumerable string keys");
    return `{${keys.map((key) => {
      const desc = Object.getOwnPropertyDescriptor(value, key);
      protocolInvariant("value" in desc, "SCHEMA_INVALID", "Accessors are prohibited");
      return `${JSON.stringify(key)}:${visit(desc.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const encoded = visit(payload, 0);
  protocolInvariant(utf8(encoded).length <= limits.maxBytes, "SCHEMA_INVALID", "JSON payload is too large");
  return encoded;
}
var DEFAULT_RUNTIME_MANIFEST = Object.freeze({
  js: "quickjs-ng@0.32.0",
  builtins: Object.freeze({
    "chronolog:crypto": "crypto@1",
    "chronolog:cas": "cas@1",
    "chronolog:sqlite": "sqlite-cas@1#sha256-4b2ef04a5c2f285d7df273e3187665d17ade145075f9f5b4816ec1bab0a0b241",
    "chronolog:wasm": "wasm@1"
  })
});
var DEFAULT_GENESIS_LIMITS = Object.freeze({
  maxMemoryBytes: 64 * 1024 * 1024,
  maxTopicStateBytes: 4 * 1024 * 1024,
  maxUpdatesPerOp: 16,
  maxFuel: 2e5
});

// packages/crypto/src/hpke.ts
var KEM_ID = Uint8Array.of(0, 32);
var KDF_ID = Uint8Array.of(0, 1);
var AEAD_ID = Uint8Array.of(0, 2);
var KEM_SUITE_ID = concatBytes(utf82("KEM"), KEM_ID);
var HPKE_SUITE_ID = concatBytes(utf82("HPKE"), KEM_ID, KDF_ID, AEAD_ID);
var HPKE_VERSION = utf82("HPKE-v1");

// node_modules/.pnpm/@noble+ed25519@3.2.0/node_modules/@noble/ed25519/index.js
var freeze = Object.freeze;
var P = 0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffedn;
var N = 0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3edn;
var _d = 0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3n;
var Gx = 0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51an;
var Gy = 0x6666666666666666666666666666666666666666666666666666666666666658n;
var _a = P - 1n;
var ed25519_CURVE = freeze({
  p: P,
  n: N,
  h: 8n,
  a: _a,
  d: _d,
  Gx,
  Gy
});
var LEN = 32;
var isBytes2 = (a) => {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && a.BYTES_PER_ELEMENT === 1;
};
var abytes2 = (value, length, title = "") => {
  if (isBytes2(value) && (length === void 0 || value.length === length))
    return value;
  const bytes = isBytes2(value);
  const ofLen = length !== void 0 ? ` of length ${length}` : "";
  const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
  const message = (title ? `"${title}" ` : "") + "expected Uint8Array" + ofLen + ", got " + got;
  if (!bytes)
    throw new TypeError(message);
  throw new RangeError(message);
};
var snapshotBytes = (value, title = "", length) => Uint8Array.from(abytes2(value, length, title));
var padh = (n, pad) => n.toString(16).padStart(pad, "0");
var bytesToHex2 = (bytes) => {
  let hex = "";
  for (const byte of abytes2(bytes))
    hex += padh(byte, 2);
  return hex;
};
var hexToBytes2 = (hex) => {
  const e = "hex invalid";
  if (typeof hex !== "string")
    throw new TypeError(e);
  if (hex.length % 2 || !/^[\da-f]*$/i.test(hex))
    throw new RangeError(e);
  const array = new Uint8Array(hex.length / 2);
  for (let ai = 0, hi = 0; ai < array.length; ai++, hi += 2) {
    const n1 = hex.charCodeAt(hi);
    const n2 = hex.charCodeAt(hi + 1);
    array[ai] = ((n1 & 15) + (n1 >> 6) * 9) * 16 + (n2 & 15) + (n2 >> 6) * 9;
  }
  return array;
};
var concatBytes2 = (...arrays) => {
  let sum = 0;
  for (const a of arrays)
    sum += abytes2(a).length;
  const res = new Uint8Array(sum);
  let pad = 0;
  for (const a of arrays) {
    res.set(a, pad);
    pad += a.length;
  }
  return res;
};
var arange = (n, min, max, msg = "bad number: out of range") => {
  if (typeof n !== "bigint")
    throw new TypeError(msg);
  if (min <= n && n < max)
    return n;
  throw new RangeError(msg);
};
var mod = (a, b = P) => (a %= b) >= 0n ? a : b + a;
var P_MASK = (1n << 255n) - 1n;
var modP = (num) => {
  if (num < 0n)
    throw new RangeError("negative coordinate");
  let r = (num >> 255n) * 19n + (num & P_MASK);
  r = (r >> 255n) * 19n + (r & P_MASK);
  return r % P;
};
var modN = (a) => mod(a, N);
var invert = (number, modulo) => {
  if (number === 0n)
    throw new Error("invert: expected non-zero number");
  if (modulo <= 1n)
    throw new Error("invert: expected modulus > 1, got " + modulo);
  let a = mod(number, modulo);
  let b = modulo;
  let x = 0n, u = 1n;
  while (a !== 0n) {
    const q = b / a;
    const r = b - a * q;
    const m = x - u * q;
    b = a, a = r, x = u, u = m;
  }
  const gcd = b;
  if (gcd !== 1n)
    throw new Error("invert: does not exist");
  return mod(x, modulo);
};
var _hash = (name) => {
  const fn = hashes[name];
  if (typeof fn !== "function")
    throw new Error("hashes." + name + " not set");
  return fn;
};
var callHash = (name, ...m) => abytes2(_hash(name)(concatBytes2(...m)), 64, "digest");
var apoint = (p) => {
  if (p instanceof Point)
    return p;
  throw new TypeError("Point expected");
};
var B256 = 2n ** 256n;
var Point = class _Point {
  static BASE;
  static ZERO;
  X;
  Y;
  Z;
  T;
  // Constructor only bounds-checks and freezes XYZT coordinates; it does not prove the point is
  // on-curve or that T matches X*Y/Z.
  constructor(X, Y, Z, T) {
    const max = B256;
    this.X = arange(X, 0n, max);
    this.Y = arange(Y, 0n, max);
    this.Z = arange(Z, 1n, max);
    this.T = arange(T, 0n, max);
    freeze(this);
  }
  static CURVE() {
    return ed25519_CURVE;
  }
  static fromAffine(p) {
    return new _Point(p.x, p.y, 1n, modP(p.x * p.y));
  }
  /** RFC8032 5.1.3: Uint8Array to Point. */
  static fromBytes(bytes, zip215 = false) {
    const normed = snapshotBytes(bytes, "point", LEN);
    const lastByte = normed[31];
    normed[31] = lastByte & ~128;
    const y = bytesToNumberLE(normed);
    if (!zip215)
      arange(y, 0n, P);
    const y2 = modP(y * y);
    const u = mod(y2 - 1n);
    const v = modP(_d * y2 + 1n);
    let { isValid, value: x } = uvRatio(u, v);
    if (!isValid)
      throw new Error("bad point: y not sqrt");
    const isLastByteOdd = !!(lastByte & 128);
    if (!zip215 && x === 0n && isLastByteOdd)
      throw new Error("bad point: x==0, isLastByteOdd");
    if (isLastByteOdd !== !!(x & 1n))
      x = mod(-x);
    return new _Point(x, y, 1n, modP(x * y));
  }
  static fromHex(hex, zip215) {
    return _Point.fromBytes(hexToBytes2(hex), zip215);
  }
  get x() {
    return this.toAffine().x;
  }
  get y() {
    return this.toAffine().y;
  }
  /** Checks if the point is valid and on-curve. */
  assertValidity() {
    const a = _a;
    const d = _d;
    const p = this;
    if (p.is0())
      throw new Error("bad point: ZERO");
    const { X, Y, Z, T } = p;
    const X2 = modP(X * X);
    const Y2 = modP(Y * Y);
    const Z2 = modP(Z * Z);
    const Z4 = modP(Z2 * Z2);
    const aX2 = modP(X2 * a);
    const left = modP(Z2 * (aX2 + Y2));
    const right = mod(Z4 + modP(d * modP(X2 * Y2)));
    if (left !== right)
      throw new Error("bad point: equation left != right (1)");
    const XY = modP(X * Y);
    const ZT = modP(Z * T);
    if (XY !== ZT)
      throw new Error("bad point: equation left != right (2)");
    return this;
  }
  /** Equality check: compare points P&Q. */
  equals(other) {
    const { X: X1, Y: Y1, Z: Z1 } = this;
    const { X: X2, Y: Y2, Z: Z2 } = apoint(other);
    return modP(X1 * Z2) === modP(X2 * Z1) && modP(Y1 * Z2) === modP(Y2 * Z1);
  }
  is0() {
    return this.equals(I);
  }
  /** Flip point over y coordinate. */
  negate() {
    return new _Point(mod(-this.X), this.Y, this.Z, mod(-this.T));
  }
  /** Point doubling. Complete formula. Cost: `4M + 4S + 1*a + 6add + 1*2`. */
  double() {
    const { X: X1, Y: Y1, Z: Z1 } = this;
    const a = _a;
    const A = modP(X1 * X1);
    const B = modP(Y1 * Y1);
    const C = modP(2n * Z1 * Z1);
    const D = modP(a * A);
    const x1y1 = mod(X1 + Y1);
    const E = mod(modP(x1y1 * x1y1) - A - B);
    const G2 = mod(D + B);
    const F = mod(G2 - C);
    const H = mod(D - B);
    const X3 = modP(E * F);
    const Y3 = modP(G2 * H);
    const T3 = modP(E * H);
    const Z3 = modP(F * G2);
    return new _Point(X3, Y3, Z3, T3);
  }
  /** Point addition. Complete formula. Cost: `9M + 1*a + 1*d + 7add`. */
  add(other) {
    const { X: X1, Y: Y1, Z: Z1, T: T1 } = this;
    const { X: X2, Y: Y2, Z: Z2, T: T2 } = apoint(other);
    const a = _a;
    const d = _d;
    const A = modP(X1 * X2);
    const B = modP(Y1 * Y2);
    const C = modP(modP(T1 * d) * T2);
    const D = modP(Z1 * Z2);
    const E = mod(modP(mod(X1 + Y1) * mod(X2 + Y2)) - A - B);
    const F = mod(D - C);
    const G2 = mod(D + C);
    const H = mod(B - modP(a * A));
    const X3 = modP(E * F);
    const Y3 = modP(G2 * H);
    const T3 = modP(E * H);
    const Z3 = modP(F * G2);
    return new _Point(X3, Y3, Z3, T3);
  }
  subtract(other) {
    return this.add(apoint(other).negate());
  }
  /**
   * Point-by-scalar multiplication. Safe mode requires `1 <= n < CURVE.n`.
   * Unsafe mode additionally permits `n = 0` and returns the identity point for that case.
   * Uses {@link wNAF} for base point.
   * Uses fake point to mitigate side-channel leakage.
   * @param n - scalar by which point is multiplied
   * @param safe - safe mode guards against timing attacks; unsafe mode is faster
   */
  multiply(n, safe = true) {
    if (!safe && n === 0n)
      return I;
    arange(n, 1n, N);
    if (!safe && this.is0())
      return I;
    if (n === 1n)
      return this;
    if (this.equals(G))
      return wNAF(n).p;
    let p = I;
    let f = G;
    let d = this;
    for (let i = 0; safe ? i < 256 : n > 0n; i++) {
      if (n & 1n)
        p = p.add(d);
      else if (safe)
        f = f.add(d);
      d = d.double();
      n >>= 1n;
    }
    return p;
  }
  multiplyUnsafe(scalar) {
    return this.multiply(scalar, false);
  }
  /** Convert point to 2d xy affine point. (X, Y, Z) ∋ (x=X/Z, y=Y/Z) */
  toAffine() {
    const { X, Y, Z } = this;
    if (this.equals(I))
      return { x: 0n, y: 1n };
    const iz = invert(Z, P);
    if (modP(Z * iz) !== 1n)
      throw new Error("invalid inverse");
    return { x: modP(X * iz), y: modP(Y * iz) };
  }
  toBytes() {
    const { x, y } = this.toAffine();
    const b = numTo32bLE(y);
    b[31] |= x & 1n ? 128 : 0;
    return b;
  }
  toHex() {
    return bytesToHex2(this.toBytes());
  }
  clearCofactor() {
    return this.multiply(8n, false);
  }
  isSmallOrder() {
    return this.clearCofactor().is0();
  }
  isTorsionFree() {
    return this.multiply(N / 2n, false).double().add(this).is0();
  }
};
var G = new Point(Gx, Gy, 1n, mod(Gx * Gy));
var I = new Point(0n, 1n, 1n, 0n);
Point.BASE = G;
Point.ZERO = I;
var numTo32bLE = (num) => hexToBytes2(padh(arange(num, 0n, B256), 64)).reverse();
var bytesToNumberLE = (b) => BigInt("0x" + bytesToHex2(Uint8Array.from(abytes2(b)).reverse()));
var pow2 = (x, power) => {
  let r = x;
  while (power-- > 0) {
    r = modP(r * r);
  }
  return r;
};
var pow_2_252_3 = (x) => {
  const x2 = modP(x * x);
  const b2 = modP(x2 * x);
  const b4 = modP(pow2(b2, 2) * b2);
  const b5 = modP(pow2(b4, 1) * x);
  const b10 = modP(pow2(b5, 5) * b5);
  const b20 = modP(pow2(b10, 10) * b10);
  const b40 = modP(pow2(b20, 20) * b20);
  const b80 = modP(pow2(b40, 40) * b40);
  const b160 = modP(pow2(b80, 80) * b80);
  const b240 = modP(pow2(b160, 80) * b80);
  const b250 = modP(pow2(b240, 10) * b10);
  return modP(pow2(b250, 2) * x);
};
var RM1 = 0x2b8324804fc1df0b2b4d00993dfbd7a72f431806ad2fe478c4ee1b274a0ea0b0n;
var uvRatio = (u, v) => {
  const v3 = modP(v * modP(v * v));
  const v7 = modP(modP(v3 * v3) * v);
  const pow = pow_2_252_3(modP(u * v7));
  let x = modP(u * modP(v3 * pow));
  const vx2 = modP(v * modP(x * x));
  const root1 = x;
  const root2 = modP(x * RM1);
  const useRoot1 = vx2 === u;
  const useRoot2 = vx2 === mod(-u);
  const noRoot = vx2 === mod(-u * RM1);
  if (useRoot1)
    x = root1;
  if (useRoot2 || noRoot)
    x = root2;
  if ((mod(x) & 1n) === 1n)
    x = mod(-x);
  return { isValid: useRoot1 || useRoot2, value: x };
};
var modL_LE = (hash) => modN(bytesToNumberLE(hash));
var hashFinishSync = (res) => res[1](callHash("sha512", res[0]));
var getZip215 = (options) => {
  if (options === null || typeof options !== "object")
    throw new TypeError("expected valid options object");
  return options.zip215 ?? true;
};
var _verify = (sig, msg, publicKey, options) => {
  sig = abytes2(sig, 64, "signature");
  msg = abytes2(msg, void 0, "message");
  publicKey = abytes2(publicKey, LEN, "publicKey");
  const zip215 = getZip215(options);
  const r = sig.subarray(0, LEN);
  const s = bytesToNumberLE(sig.subarray(LEN, 64));
  let A, R, SB;
  let hashable = Uint8Array.of();
  let finished = false;
  try {
    A = Point.fromBytes(publicKey, zip215);
    R = Point.fromBytes(r, zip215);
    SB = G.multiply(s, false);
    hashable = concatBytes2(r, publicKey, msg);
    finished = true;
  } catch (error) {
  }
  const finish = (hashed) => {
    if (!finished)
      return false;
    if (!zip215 && A.isSmallOrder())
      return false;
    const k = modL_LE(hashed);
    const RkA = R.add(A.multiply(k, false));
    return RkA.subtract(SB).clearCofactor().is0();
  };
  return [hashable, finish];
};
var verify = (signature, message, publicKey, opts = {}) => hashFinishSync(_verify(signature, message, publicKey, opts));
var hashes = {
  sha512Async: async (message) => {
    const s = globalThis?.crypto?.subtle;
    if (!s)
      throw new Error("crypto.subtle must be defined, consider polyfill");
    return new Uint8Array(await s.digest("SHA-512", concatBytes2(message)));
  },
  sha512: void 0
};
var precompute = () => {
  const points = [];
  let p = G;
  let b;
  for (let w = 0; w < 33; w++) {
    b = p;
    points.push(b);
    for (let i = 1; i < 128; i++) {
      b = b.add(p);
      points.push(b);
    }
    p = b.double();
  }
  return points;
};
var Gpows = void 0;
var ctneg = (cnd, p) => {
  const n = p.negate();
  return cnd ? n : p;
};
var wNAF = (n) => {
  const comp = Gpows || (Gpows = precompute());
  let p = I;
  let f = G;
  for (let w = 0; w < 33; w++) {
    let wbits = Number(n & 255n);
    n >>= 8n;
    if (wbits > 128) {
      wbits -= 256;
      n += 1n;
    }
    const off = w * 128;
    const offP = off + Math.abs(wbits) - 1;
    const isOddW = w % 2 !== 0;
    const isNeg = wbits < 0;
    if (wbits === 0) {
      f = f.add(ctneg(isOddW, comp[off]));
    } else {
      p = p.add(ctneg(isNeg, comp[offP]));
    }
  }
  if (n !== 0n)
    throw new Error("invalid wnaf");
  return { p, f };
};

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha512.js
init_sha2();
var sha5122 = sha512;

// packages/crypto/src/ed25519-sync.ts
hashes.sha512 = (message) => sha5122(message);
function verifyEd25519Sync(publicKey, message, signature) {
  if (publicKey.length !== 32 || signature.length !== 64) return false;
  try {
    return verify(signature, message, publicKey);
  } catch {
    return false;
  }
}

// packages/materializer/src/wasm-sandbox.ts
init_src();

// packages/materializer/src/derivation.ts
init_src();
function canonicalAttestationMessage(payload) {
  return `chronolog/attestation/v1:${canonicalJson(payload)}`;
}
async function signBuildAttestation(payload, signerPublicKeyHex, privateKey) {
  const full = {
    format: "chronolog-attestation/v1",
    kind: "build",
    drvRef: casRef(parseCasRef(payload.drvRef)),
    outputRef: casRef(parseCasRef(payload.outputRef)),
    runtime: payload.runtime
  };
  const msg = utf8(canonicalAttestationMessage(full));
  const sig = new Uint8Array(await crypto.subtle.sign("Ed25519", privateKey, new Uint8Array(msg)));
  return { payload: full, signer: signerPublicKeyHex, signature: bytesToHex(sig) };
}
function verifyBuildAttestation(attestation) {
  if (attestation.payload.format !== "chronolog-attestation/v1" || attestation.payload.kind !== "build") return false;
  if (tryParseCasRef(attestation.payload.drvRef) === null || tryParseCasRef(attestation.payload.outputRef) === null) return false;
  if (!/^[0-9a-f]{64}$/u.test(attestation.signer) || !/^[0-9a-f]{128}$/u.test(attestation.signature)) return false;
  return verifyEd25519Sync(
    hexToBytes(attestation.signer),
    utf8(canonicalAttestationMessage(attestation.payload)),
    hexToBytes(attestation.signature)
  );
}
async function signAuditAttestation(payload, signerPublicKeyHex, privateKey) {
  const full = {
    format: "chronolog-attestation/v1",
    kind: "audit",
    pkgRef: casRef(parseCasRef(payload.pkgRef)),
    verdict: payload.verdict,
    ...payload.notes === void 0 ? {} : { notes: payload.notes }
  };
  const msg = utf8(canonicalAttestationMessage(full));
  const sig = new Uint8Array(await crypto.subtle.sign("Ed25519", privateKey, new Uint8Array(msg)));
  return { payload: full, signer: signerPublicKeyHex, signature: bytesToHex(sig) };
}
function verifyAuditAttestation(attestation) {
  if (attestation.payload.format !== "chronolog-attestation/v1" || attestation.payload.kind !== "audit") return false;
  if (tryParseCasRef(attestation.payload.pkgRef) === null) return false;
  if (attestation.payload.verdict !== "approved" && attestation.payload.verdict !== "revoked") return false;
  if (!/^[0-9a-f]{64}$/u.test(attestation.signer) || !/^[0-9a-f]{128}$/u.test(attestation.signature)) return false;
  return verifyEd25519Sync(
    hexToBytes(attestation.signer),
    utf8(canonicalAttestationMessage(attestation.payload)),
    hexToBytes(attestation.signature)
  );
}

// packages/materializer/src/wasi-cas-runner.ts
init_src();

// packages/materializer/src/kernel.ts
init_src();
init_src();
var ZERO_HASH = "0".repeat(64);

// packages/materializer/src/materialized-cache.ts
init_src();

// packages/pack/src/registry-client.ts
var RegistryClient = class {
  constructor(session) {
    this.session = session;
  }
  session;
  async publish(options) {
    if (options.casNodes !== void 0 && options.casNodes.length > 0) {
      await this.session.cas.putManyVerified(options.casNodes);
    }
    return this.session.submit({
      awaitMaterialized: true,
      updates: [{
        topic: "packages",
        input: {
          action: "publish",
          name: options.name,
          version: options.version,
          pkgRef: options.pkgRef,
          ...options.drvRef === void 0 ? {} : { drvRef: options.drvRef },
          runtime: options.runtime ?? "esm-quickjs",
          builtins: [...options.builtins ?? []],
          description: options.description ?? "",
          ...options.describeSchema === void 0 ? {} : { describeSchema: options.describeSchema }
        }
      }]
    });
  }
  async attestBuild(options) {
    const attestation = await signBuildAttestation(
      { drvRef: options.drvRef, outputRef: options.outputRef, runtime: options.runtime },
      options.signer ?? this.session.device.identity.publicKey,
      options.privateKey ?? this.session.device.identity.privateKey
    );
    const operation = await this.session.submit({
      awaitMaterialized: true,
      updates: [{
        topic: "packages",
        input: { action: "attest", attestation }
      }]
    });
    return { attestation, operation };
  }
  async attestAudit(options) {
    const attestation = await signAuditAttestation(
      {
        pkgRef: options.pkgRef,
        verdict: options.verdict,
        ...options.notes === void 0 ? {} : { notes: options.notes }
      },
      options.signer ?? this.session.device.identity.publicKey,
      options.privateKey ?? this.session.device.identity.privateKey
    );
    const operation = await this.session.submit({
      awaitMaterialized: true,
      updates: [{
        topic: "packages",
        input: { action: "attest", attestation }
      }]
    });
    return { attestation, operation };
  }
  async search(q, limit = 25) {
    const res = await this.session.query("packages", { query: "search", q, limit });
    return Array.isArray(res.value) ? res.value : [];
  }
  async resolve(name, version) {
    const res = await this.session.query("packages", {
      query: "resolve",
      name,
      ...version === void 0 ? {} : { version }
    });
    return res.value === null ? null : res.value;
  }
  async resolveByHash(pkgRef) {
    const res = await this.session.query("packages", { query: "resolveByHash", pkgRef });
    return res.value;
  }
  /**
   * Resolve a package from this Registry Chronolog, verify optional attestation policy,
   * transfer its CAS Merkle-DAG subgraph to `targetSession`, and install it into `$reducers`.
   */
  async installInto(targetSession, options) {
    const resolved = await this.resolve(options.name, options.version);
    if (resolved === null) throw new Error(`REGISTRY_PACKAGE_NOT_FOUND:${options.name}`);
    if (resolved.revoked) throw new Error(`REGISTRY_PACKAGE_REVOKED:${options.name}@${resolved.version}`);
    const verifiedAttestations = [];
    const buildSigners = /* @__PURE__ */ new Set();
    const auditSigners = /* @__PURE__ */ new Set();
    for (const a of resolved.attestations) {
      if (a.kind === "build" && a.drvRef !== null && a.runtime !== null) {
        const signed = {
          payload: {
            format: "chronolog-attestation/v1",
            kind: "build",
            drvRef: a.drvRef,
            outputRef: resolved.pkgRef,
            runtime: a.runtime
          },
          signer: a.signer,
          signature: a.signature
        };
        if (verifyBuildAttestation(signed)) {
          if (options.trustedBuilders === void 0 || options.trustedBuilders.includes(a.signer)) {
            buildSigners.add(a.signer);
            verifiedAttestations.push(signed);
          }
        }
      } else if (a.kind === "audit" && (a.verdict === "approved" || a.verdict === "revoked")) {
        const signed = {
          payload: {
            format: "chronolog-attestation/v1",
            kind: "audit",
            pkgRef: resolved.pkgRef,
            verdict: a.verdict,
            ...a.notes === null ? {} : { notes: a.notes }
          },
          signer: a.signer,
          signature: a.signature
        };
        if (verifyAuditAttestation(signed) && a.verdict === "approved") {
          if (options.trustedAuditors === void 0 || options.trustedAuditors.includes(a.signer)) {
            auditSigners.add(a.signer);
            verifiedAttestations.push(signed);
          }
        }
      }
    }
    if (options.minBuildAttestations !== void 0 && buildSigners.size < options.minBuildAttestations) {
      throw new Error(`REGISTRY_BUILD_ATTESTATIONS_INSUFFICIENT:${buildSigners.size}<${options.minBuildAttestations}`);
    }
    if (options.requireAudit === true && auditSigners.size < 1) {
      throw new Error(`REGISTRY_AUDIT_REQUIRED:${resolved.pkgRef}`);
    }
    const pkgHash = parseCasRef(resolved.pkgRef);
    const casNodes = await this.session.exportCasNodes([pkgHash], false, { subgraph: true });
    const installed = await targetSession.installPackage(
      { ref: resolved.pkgRef, casNodes },
      {
        alias: options.alias ?? resolved.name,
        ...options.topics === void 0 ? {} : { topics: options.topics },
        ...verifiedAttestations.length > 0 ? { attestations: verifiedAttestations } : {}
      }
    );
    return { resolved, operation: installed.operation };
  }
};
export {
  ESBUILD_BUILDER_ID,
  ESBUILD_BUILDER_REF,
  INLINE_TS_BUILDER_SOURCE,
  RegistryClient,
  createDeterministicTar,
  createLockfile,
  detectRequiredBuiltins,
  formatLockfile,
  ingestTarballToCas,
  lintDeterminism,
  packNpmTarball,
  packReducers,
  parseCanonicalTarball,
  parseLockfile
};
/*! Bundled license information:

@noble/hashes/esm/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)

@noble/ed25519/index.js:
  (*! noble-ed25519 - MIT License (c) 2019 Paul Miller (paulmillr.com) *)
*/
