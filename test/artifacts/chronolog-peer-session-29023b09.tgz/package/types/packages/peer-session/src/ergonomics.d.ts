import type { AppliedResult, OperationState, PeerRevision } from '../../peer-generation/src/index.js';
export type OperationLifecycleState = 'recorded' | 'submitted' | 'applied' | 'rejected' | 'unknown';
export interface OperationLifecycleSummary {
    readonly operationId: string;
    readonly lifecycle: OperationLifecycleState;
    readonly status: OperationState['status'] | 'unknown';
    readonly outcome: 'accepted' | 'rejected' | null;
    readonly sequence: number | null;
    readonly generation: string | null;
    readonly errorCode: string | null;
    readonly reason: string | null;
    readonly safeToReconcile: boolean;
}
export interface BatchCommandEntry {
    readonly operationId: string;
    readonly command: string;
    readonly input: unknown;
    readonly basedOn?: PeerRevision;
}
export interface BatchCommandResult {
    readonly operationId: string;
    readonly command: string;
    readonly lifecycle: OperationLifecycleState;
    readonly applied: AppliedResult | null;
    readonly state: OperationState | null;
    readonly error: {
        readonly code: string;
        readonly message: string;
    } | null;
}
export interface BatchSubmitOptions {
    readonly wait?: 'applied' | 'recorded';
    readonly signal?: AbortSignal;
    readonly stopOnError?: boolean;
    /** Optional durable pre-submission persistence hook called before each command transmits. */
    readonly beforeSubmit?: (entry: BatchCommandEntry) => void | Promise<void>;
}
export interface ErgonomicSession {
    readonly applicationId: string;
    readonly deviceId: string;
    readonly historyId?: string;
    readonly status?: unknown;
    query(name: string, input: unknown): Promise<{
        readonly revision: PeerRevision;
        readonly value: unknown;
    }>;
    command(name: string, input: unknown, options: {
        readonly operationId: string;
        readonly basedOn?: PeerRevision;
    }): Promise<{
        get(): Promise<OperationState | null>;
        applied(options?: {
            readonly signal?: AbortSignal;
        }): Promise<AppliedResult>;
    }>;
    readonly operations: {
        get(operationId: string, options?: {
            readonly author?: string;
        }): Promise<OperationState | null>;
        inspect(operationId: string, options?: {
            readonly author?: string;
        }): Promise<{
            readonly state: OperationState;
            readonly attempt: unknown;
        } | null>;
    };
    close?(): Promise<void> | void;
}
/**
 * Map Chronolog's exact operation journal state and optional transport error into
 * the canonical five-state lifecycle envelope without conflating recorded/submitted with applied.
 */
export declare function describeOperationLifecycle(operationId: string, state: OperationState | null | undefined, options?: {
    readonly transmitted?: boolean;
    readonly error?: unknown;
}): OperationLifecycleSummary;
/**
 * Submit an ordered batch of idempotent commands over one session, optionally persisting
 * pre-submission outbox entries and mapping each item to its honest lifecycle state.
 */
export declare function submitBatch(session: ErgonomicSession, entries: readonly BatchCommandEntry[], options?: BatchSubmitOptions): Promise<readonly BatchCommandResult[]>;
export interface UnifiedAppClient {
    readonly applicationId: string;
    readonly deviceId: string;
    readonly historyId: string | null;
    submitCommand(entry: BatchCommandEntry, options?: {
        readonly wait?: 'applied' | 'recorded';
        readonly signal?: AbortSignal;
    }): Promise<BatchCommandResult>;
    submitBatch(entries: readonly BatchCommandEntry[], options?: BatchSubmitOptions): Promise<readonly BatchCommandResult[]>;
    inspectOperation(operationId: string): Promise<OperationLifecycleSummary>;
    query(name: string, input?: unknown): Promise<{
        readonly revision: PeerRevision;
        readonly value: unknown;
    }>;
    flush(): Promise<void>;
    close(): Promise<void>;
}
/**
 * Uniform five-step ergonomic client over any Chronolog peer session (native, Worker, or attached).
 */
export declare function createAppClient(session: ErgonomicSession, options?: {
    readonly beforeSubmit?: (entry: BatchCommandEntry) => void | Promise<void>;
    readonly flush?: () => void | Promise<void>;
    readonly close?: () => void | Promise<void>;
}): UnifiedAppClient;
