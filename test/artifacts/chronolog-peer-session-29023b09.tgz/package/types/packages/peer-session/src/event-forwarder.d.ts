import type { ApplicationChange, ApplicationEvent, ApplicationEventBatch, ApplicationEventOptions } from './session-types.js';
export interface EventForwarderSession {
    readonly signal: AbortSignal;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
    readView(): Promise<{
        readEvents(options?: ApplicationEventOptions): ApplicationEventBatch | Promise<ApplicationEventBatch>;
        release(): void | Promise<void>;
    }>;
}
export interface EventForwarderCheckpoint {
    load(): string | undefined | Promise<string | undefined>;
    save(cursor: string): void | Promise<void>;
}
export interface EventForwarderOptions<Projected> {
    readonly session: EventForwarderSession;
    readonly topics?: readonly string[];
    readonly limit?: number;
    readonly checkpoint: EventForwarderCheckpoint;
    readonly project: (event: ApplicationEvent, batch: ApplicationEventBatch) => Projected | null | undefined | Promise<Projected | null | undefined>;
    readonly deliver: (projected: Projected, event: ApplicationEvent, batch: ApplicationEventBatch, signal: AbortSignal) => void | Promise<void>;
    readonly signal?: AbortSignal;
}
/**
 * Durable cursor-based topic forwarder over an owned peer session.
 * Advances its checkpoint only after each projected batch is delivered, and halts
 * on generation recovery when a prior cursor exists so callers review exclusion.
 */
export declare function forwardSessionEvents<Projected>(options: EventForwarderOptions<Projected>): Promise<void>;
