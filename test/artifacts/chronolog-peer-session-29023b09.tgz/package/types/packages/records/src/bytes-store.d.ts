/**
 * The single local byte-storage contract for identity, controls, journals and projections.
 * One owner serializes mutations. Each put atomically replaces one key and resolves only
 * after durable persistence. get and put must not expose mutable internal byte buffers.
 */
export interface BytesStoreEntry {
    readonly key: string;
    readonly value: Uint8Array;
}
export interface BytesStore {
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, bytes: Uint8Array): Promise<void>;
    /** Optional deterministic snapshot enumeration for atomic encrypted device checkpoints. */
    entries?(): Promise<readonly BytesStoreEntry[]>;
}
/** Independent ephemeral storage for disposable peers and tests; not a durability claim. */
export declare class MemoryBytesStore implements BytesStore {
    #private;
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, bytes: Uint8Array): Promise<void>;
    entries(): Promise<readonly BytesStoreEntry[]>;
}
