import type { BytesStore } from './bytes-store.js';
/** Transaction-complete, per-key atomic durable records; no signer or protocol state lives here. */
export declare class IndexedDbBytesStore implements BytesStore {
    #private;
    private constructor();
    static open(name: string, { create }?: {
        create?: boolean | undefined;
    }): Promise<IndexedDbBytesStore>;
    get(key: string): Promise<Uint8Array | null>;
    put(key: string, input: Uint8Array): Promise<void>;
    entries(): Promise<readonly {
        readonly key: string;
        readonly value: Uint8Array;
    }[]>;
    close(): Promise<void>;
}
/** Scratch-only conformance probe; never opens the device's actual database. */
export declare function probeIndexedDbBytesStore(): Promise<boolean>;
/**
 * Read-only existence inspection for a data database whose metadata/pin may
 * have been erased. Abort the version-0 upgrade rather than creating a
 * replacement; callers must fail closed when an orphaned data DB exists.
 */
export declare function inspectExistingIndexedDbRecords(name: string): Promise<boolean>;
