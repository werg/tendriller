import {
  PEER_GENERATION_POLICY,
  PEER_GENERATION_PROFILE,
  Serial,
  boundedText,
  bytesDigest,
  check,
  decodePeerValue,
  encodePeerValue,
  hex,
  isArray,
  object,
  peerDigest,
  samePeerValue,
  signPeerValue,
  uint,
  verifyPeerValue
} from "./chunk-R6JLOHZW.mjs";
import {
  DOMAINS,
  ProtocolError,
  decodeChangeProgram,
  decodeTransactionCore,
  encodeTransactionCore,
  integerMap,
  isPlatformOp,
  protocolInvariant,
  transactionDigest,
  utf8
} from "./chunk-KPMB233Z.mjs";
import {
  bytesToHex,
  concatBytes,
  encodeCanonicalCbor,
  equalBytes,
  hexToBytes
} from "./chunk-DEFS6EFN.mjs";

// packages/peer-generation/src/schema.ts
function validateSchema(value) {
  object(value, ["applicationId", "definitionDigest", "executionManifestDigest", "program"]);
  hex(value.applicationId);
  hex(value.definitionDigest);
  hex(value.executionManifestDigest);
  check(typeof value.program === "string" && value.program.length <= 2 * 262144 && /^(?:[0-9a-f]{2})+$/u.test(value.program), "PEER_SCHEMA_PROGRAM_INVALID");
  decodeChangeProgram(hexToBytes(value.program));
}
async function signApplicationSchema(payload, signer) {
  validateSchema(payload);
  return signPeerValue(DOMAINS.peerSchema, payload, signer);
}
async function verifyApplicationSchema(schema, descriptor) {
  validateSchema(schema.payload);
  check(schema.payload.applicationId === descriptor.applicationId && schema.payload.definitionDigest === descriptor.definitionDigest && schema.payload.executionManifestDigest === descriptor.executionManifestDigest && descriptor.schemaDigest === await peerDigest(schema), "PEER_SCHEMA_BINDING_MISMATCH");
  await verifyPeerValue(DOMAINS.peerSchema, schema, descriptor.schemaAdministrator);
  return decodeChangeProgram(hexToBytes(schema.payload.program));
}

// packages/peer-generation/src/participant.ts
var PARTICIPANT_PROTOCOL = "chronolog-participant-v1";
var PARTICIPANT_LIMITS = Object.freeze({
  pending: 4,
  depth: 32,
  bytes: Object.freeze({
    control: 16 * 1024 * 1024,
    publication: 12 * 1024 * 1024,
    discovery: 256 * 1024,
    ephemeral: 64 * 1024,
    database: 32 * 1024 * 1024,
    content: 512 * 1024
  })
});
function policy(role, actions) {
  return Object.freeze({ role, interests: Object.freeze(Object.entries(actions).flatMap(([facet, names]) => names.map((action) => Object.freeze({ facet, action })))) });
}
var CONTROL_PARTICIPANT_POLICY = policy("control", {
  control: ["read", "configure", "select", "administer"],
  publication: ["definition", "read", "publish"],
  discovery: ["read", "advertise", "withdraw"],
  ephemeral: ["invite"]
});
var PEER_PARTICIPANT_POLICY = policy("peer", {
  control: ["state", "keyShare"],
  publication: ["definition", "read"],
  database: ["open", "submit", "range", "coverage"],
  content: ["manifest", "chunk", "retained", "observeRetention"],
  ephemeral: ["signal", "hint"]
});
var ParticipantProtocolError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "ParticipantProtocolError";
  }
  code;
};
function requireParticipant(condition, code) {
  if (!condition) throw new ParticipantProtocolError(code);
}
function applicationId(value) {
  requireParticipant(typeof value === "string" && /^[0-9a-f]{64}$/u.test(value), "PEER_PARTICIPANT_SCOPE_INVALID");
}
function jsonValue(value, depth = 0) {
  requireParticipant(depth <= PARTICIPANT_LIMITS.depth, "PEER_PARTICIPANT_DEPTH_LIMIT");
  if (value === null || typeof value === "string" || typeof value === "boolean") return;
  if (typeof value === "number") {
    requireParticipant(Number.isFinite(value), "PEER_PARTICIPANT_PAYLOAD_INVALID");
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) jsonValue(item, depth + 1);
    return;
  }
  requireParticipant(
    value !== null && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype,
    "PEER_PARTICIPANT_PAYLOAD_INVALID"
  );
  for (const item of Object.values(value)) jsonValue(item, depth + 1);
}
function participantAccepts(policy2, interest) {
  return policy2.interests.some((value) => value.facet === interest.facet && value.action === interest.action);
}
function validateParticipantRequest(value, selected = CONTROL_PARTICIPANT_POLICY) {
  requireParticipant(
    value !== null && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype,
    "PEER_PARTICIPANT_ENVELOPE_INVALID"
  );
  const request = value;
  const fields = ["protocol", "applicationId", "requestId", "facet", "action", "payload"];
  requireParticipant(
    Object.keys(request).length === fields.length && fields.every((key) => Object.hasOwn(request, key)),
    "PEER_PARTICIPANT_ENVELOPE_INVALID"
  );
  requireParticipant(request.protocol === PARTICIPANT_PROTOCOL, "PEER_PARTICIPANT_PROTOCOL_UNSUPPORTED");
  applicationId(request.applicationId);
  requireParticipant(
    typeof request.requestId === "string" && /^[A-Za-z0-9_.:-]{1,128}$/u.test(request.requestId),
    "PEER_PARTICIPANT_REQUEST_INVALID"
  );
  requireParticipant(typeof request.facet === "string" && Object.hasOwn(PARTICIPANT_LIMITS.bytes, request.facet) && typeof request.action === "string" && /^[a-z][A-Za-z-]{0,47}$/u.test(request.action), "PEER_PARTICIPANT_INTEREST_INVALID");
  requireParticipant(participantAccepts(selected, request), "PEER_PARTICIPANT_FACET_FORBIDDEN");
  jsonValue(request.payload);
  requireParticipant(
    new TextEncoder().encode(JSON.stringify(request)).length <= PARTICIPANT_LIMITS.bytes[request.facet],
    "PEER_PARTICIPANT_SIZE_LIMIT"
  );
  return structuredClone(request);
}
function createParticipantRequest(input, selected = CONTROL_PARTICIPANT_POLICY) {
  return validateParticipantRequest({
    protocol: PARTICIPANT_PROTOCOL,
    applicationId: input.applicationId,
    requestId: input.requestId ?? crypto.randomUUID(),
    facet: input.facet,
    action: input.action,
    payload: input.payload
  }, selected);
}
function createParticipantResponse(request, payload, selected = CONTROL_PARTICIPANT_POLICY) {
  return validateParticipantRequest({ ...validateParticipantRequest(request, selected), payload }, selected);
}
function validateParticipantResponse(value, request, selected = CONTROL_PARTICIPANT_POLICY) {
  const response = validateParticipantRequest(value, selected);
  requireParticipant(response.applicationId === request.applicationId && response.requestId === request.requestId && response.facet === request.facet && response.action === request.action, "PEER_PARTICIPANT_RESPONSE_MISMATCH");
  return response;
}
function createParticipantTransport(options) {
  applicationId(options.applicationId);
  const scope2 = options.applicationId, dispatch = options.exchange;
  const selected = structuredClone(options.policy ?? CONTROL_PARTICIPANT_POLICY);
  let pending = 0;
  const exchange = async (input, inputOptions = {}) => {
    const request = validateParticipantRequest(input, selected);
    requireParticipant(request.applicationId === scope2, "PEER_PARTICIPANT_SCOPE_MISMATCH");
    inputOptions.signal?.throwIfAborted();
    requireParticipant(pending < PARTICIPANT_LIMITS.pending, "PEER_PARTICIPANT_BUSY");
    pending++;
    try {
      const response = await dispatch(request, inputOptions);
      inputOptions.signal?.throwIfAborted();
      return validateParticipantResponse(response, request, selected);
    } finally {
      pending--;
    }
  };
  return Object.freeze({
    applicationId: scope2,
    policy: policy(
      selected.role,
      Object.fromEntries([...new Set(selected.interests.map((value) => value.facet))].map((facet) => [facet, selected.interests.filter((value) => value.facet === facet).map((value) => value.action)]))
    ),
    exchange,
    async request(facet, action, payload, inputOptions = {}) {
      return (await exchange(createParticipantRequest({ applicationId: scope2, facet, action, payload }, selected), inputOptions)).payload;
    }
  });
}

// packages/peer-generation/src/control.ts
function assertAuthorityExtension(previous, next) {
  const old = previous.bundle, current = next.bundle;
  check(samePeerValue(old.descriptor, current.descriptor), "PEER_DESCRIPTOR_MISMATCH");
  check(current.generations.length >= old.generations.length && current.controls.length >= old.controls.length, "PEER_AUTHORITY_REGRESSION");
  for (let index = 0; index < old.generations.length; index++) check(samePeerValue(old.generations[index], current.generations[index]), "PEER_CONTROL_EQUIVOCATION");
  for (let index = 0; index < old.controls.length; index++) check(samePeerValue(old.controls[index], current.controls[index]), "PEER_CONTROL_EQUIVOCATION");
}
function scope(value, descriptor) {
  check(value.applicationId === descriptor.applicationId && value.profile === PEER_GENERATION_PROFILE && (value.policy === void 0 || value.policy === descriptor.policy), "PEER_SCOPE_MISMATCH");
}
function validateDescriptor(value) {
  object(value, ["applicationId", "historyId", "profile", "policy", "controlPublicKey", "schemaAdministrator", "executionManifestDigest", "definitionDigest", "schemaDigest"]);
  hex(value.applicationId);
  boundedText(value.historyId, 128);
  hex(value.controlPublicKey);
  hex(value.schemaAdministrator);
  hex(value.executionManifestDigest);
  hex(value.definitionDigest);
  if (value.schemaDigest !== null) hex(value.schemaDigest);
  check(value.profile === PEER_GENERATION_PROFILE && value.policy === PEER_GENERATION_POLICY, "PEER_PROFILE_UNSUPPORTED");
}
function validateHistoryPoint(point) {
  object(point, ["generation", "sequence", "root"]);
  hex(point.generation);
  uint(point.sequence);
  hex(point.root);
}
function validateControl(value) {
  object(value, ["applicationId", "profile", "policy", "revision", "previous", "epoch", "keyDigest", "grants", "recoveryFloor"]);
  hex(value.applicationId);
  uint(value.revision);
  uint(value.epoch);
  hex(value.keyDigest);
  if (value.previous !== null) hex(value.previous);
  check(isArray(value.grants) && value.grants.length > 0 && value.grants.length <= 1024, "PEER_GRANTS_INVALID");
  const keys = /* @__PURE__ */ new Set();
  for (const grant of value.grants) {
    object(grant, ["publicKey", "reader", "writer", "coordinator", "recovery", "administrator", "publisher", "dataRole"]);
    hex(grant.publicKey);
    for (const key of ["reader", "writer", "coordinator", "recovery", "administrator", "publisher"]) check(typeof grant[key] === "boolean", "PEER_GRANT_INVALID");
    check(!keys.has(grant.publicKey), "PEER_DUPLICATE_GRANT");
    keys.add(grant.publicKey);
    check(!grant.coordinator || grant.reader, "PEER_COORDINATOR_MUST_READ");
    check(grant.dataRole === null || grant.dataRole === "member" || grant.dataRole === "admin", "PEER_DATA_ROLE_INVALID");
  }
  check(value.grants.some((grant) => grant.administrator), "PEER_ADMINISTRATOR_REQUIRED");
  if (value.recoveryFloor !== null) validateHistoryPoint(value.recoveryFloor);
}
function validateRequest(value) {
  object(value, ["applicationId", "profile", "policy", "transitionId", "expectedGeneration", "coordinator", "requester", "controlRevision", "reason", "base"]);
  hex(value.applicationId);
  boundedText(value.transitionId, 128);
  hex(value.coordinator);
  hex(value.requester);
  uint(value.controlRevision);
  if (value.expectedGeneration !== null) hex(value.expectedGeneration);
  check(["create", "handover", "takeover", "control-change"].includes(value.reason), "PEER_TRANSITION_REASON_INVALID");
  if (value.base !== null) {
    object(value.base, ["point", "receipt", "bridge"]);
    validateHistoryPoint(value.base.point);
    check(isArray(value.base.bridge) && value.base.bridge.length <= 4096, "PEER_PREFIX_PROOF_TOO_LARGE");
  }
}
function validateGeneration(value) {
  object(value, ["applicationId", "profile", "policy", "number", "previous", "coordinator", "controlRevision", "controlDigest", "adopted", "recoveryFloor", "executionManifestDigest", "transition"]);
  hex(value.applicationId);
  uint(value.number);
  hex(value.coordinator);
  uint(value.controlRevision);
  hex(value.controlDigest);
  hex(value.executionManifestDigest);
  if (value.previous !== null) hex(value.previous);
  if (value.adopted !== null) validateHistoryPoint(value.adopted);
  if (value.recoveryFloor !== null) validateHistoryPoint(value.recoveryFloor);
}
async function signApplicationDescriptor(payload, signer) {
  validateDescriptor(payload);
  check(payload.controlPublicKey === signer.publicKey, "PEER_CONTROL_KEY_MISMATCH");
  return signPeerValue(DOMAINS.peerDescriptor, payload, signer);
}
function participantGrant(publicKey, options = {}) {
  hex(publicKey);
  return {
    publicKey,
    reader: true,
    writer: true,
    coordinator: true,
    recovery: true,
    administrator: options.administrator ?? false,
    publisher: options.publisher ?? false,
    dataRole: options.dataRole === void 0 ? "member" : options.dataRole
  };
}
function controlParticipantGrant(publicKey) {
  hex(publicKey);
  return { publicKey, reader: false, writer: false, coordinator: false, recovery: true, administrator: true, publisher: false, dataRole: null };
}
async function signControlRevision(payload, signer) {
  validateControl(payload);
  return signPeerValue(DOMAINS.peerControl, payload, signer);
}
async function signTransitionRequest(payload, signer) {
  validateRequest(payload);
  check(payload.requester === signer.publicKey, "PEER_REQUESTER_KEY_MISMATCH");
  return signPeerValue(DOMAINS.peerTransition, payload, signer);
}
async function generationStartRoot(generation) {
  return peerDigest(["chronolog/peer-generation/start/v1", generation.id, generation.payload.adopted]);
}
async function verifyOrderReceipt(receipt, generation, descriptor) {
  object(receipt, ["payload", "signature", "root"]);
  hex(receipt.root);
  const value = receipt.payload;
  object(value, ["applicationId", "profile", "generation", "sequence", "previousRoot", "attemptId", "author", "operationId", "bodyHash", "bodyBytes"]);
  scope(value, descriptor);
  hex(value.generation);
  uint(value.sequence);
  check(value.sequence > 0, "PEER_ORDER_POSITION_INVALID");
  hex(value.previousRoot);
  hex(value.attemptId);
  hex(value.author);
  boundedText(value.operationId);
  hex(value.bodyHash);
  uint(value.bodyBytes, 2 * 1024 * 1024);
  check(value.bodyBytes > 0 && value.generation === generation.id, "PEER_ORDER_GENERATION_MISMATCH");
  check(receipt.root === await peerDigest(["chronolog/peer-generation/order/v1", value]), "PEER_ORDER_ROOT_MISMATCH");
  await verifyPeerValue(DOMAINS.peerOrder, { payload: value, signature: receipt.signature }, generation.payload.coordinator);
}
var PeerAuthority = class _PeerAuthority {
  #bundle;
  constructor(bundle) {
    this.#bundle = structuredClone(bundle);
  }
  get bundle() {
    return structuredClone(this.#bundle);
  }
  get descriptor() {
    return structuredClone(this.#bundle.descriptor.payload);
  }
  get current() {
    return structuredClone(this.#bundle.generations.at(-1) ?? null);
  }
  get control() {
    return structuredClone(this.#bundle.controls.at(-1));
  }
  generation(id) {
    const value = this.#bundle.generations.find((generation) => generation.id === id);
    check(value !== void 0, "PEER_GENERATION_UNKNOWN");
    return structuredClone(value);
  }
  controlAt(revision) {
    const value = this.#bundle.controls[revision];
    check(value !== void 0, "PEER_CONTROL_UNKNOWN");
    return structuredClone(value);
  }
  grant(publicKey, revision = this.control.payload.revision) {
    return structuredClone(this.controlAt(revision).payload.grants.find((grant) => grant.publicKey === publicKey) ?? null);
  }
  selectedSegments() {
    const current = this.current;
    if (current === null) return [];
    const reversed = [{ generation: current, cutoff: null }];
    let adopted = current.payload.adopted;
    while (adopted !== null) {
      const generation = this.generation(adopted.generation);
      reversed.push({ generation, cutoff: adopted });
      adopted = generation.payload.adopted;
      check(reversed.length <= this.#bundle.generations.length, "PEER_ANCESTRY_CYCLE");
    }
    return reversed.reverse();
  }
  /** Structural inclusion; a complete replica additionally checks the local retained root. */
  contains(point) {
    validateHistoryPoint(point);
    const segment = this.selectedSegments().find((value) => value.generation.id === point.generation);
    return segment !== void 0 && (segment.cutoff === null || point.sequence <= segment.cutoff.sequence && (point.sequence !== segment.cutoff.sequence || point.root === segment.cutoff.root));
  }
  async verifyPrefix(proof) {
    object(proof, ["point", "receipt", "bridge"]);
    validateHistoryPoint(proof.point);
    check(isArray(proof.bridge) && proof.bridge.length <= 4096, "PEER_PREFIX_PROOF_TOO_LARGE");
    const segment = this.selectedSegments().find((value) => value.generation.id === proof.point.generation);
    check(segment !== void 0 && this.contains(proof.point), "PEER_PREFIX_EXCLUDED");
    const { point } = proof;
    if (point.sequence === 0) {
      check(proof.receipt === null && point.root === await generationStartRoot(segment.generation), "PEER_PREFIX_ROOT_MISMATCH");
    } else {
      check(proof.receipt !== null, "PEER_PREFIX_RECEIPT_REQUIRED");
      await verifyOrderReceipt(proof.receipt, segment.generation, this.descriptor);
      check(proof.receipt.payload.sequence === point.sequence && proof.receipt.root === point.root, "PEER_PREFIX_ROOT_MISMATCH");
    }
    let position = point.sequence, root = point.root;
    for (const receipt of proof.bridge) {
      await verifyOrderReceipt(receipt, segment.generation, this.descriptor);
      check(receipt.payload.sequence === position + 1 && receipt.payload.previousRoot === root, "PEER_PREFIX_BRIDGE_INVALID");
      position++;
      root = receipt.root;
    }
    if (segment.cutoff === null) check(proof.bridge.length === 0, "PEER_PREFIX_BRIDGE_UNNECESSARY");
    else check(position === segment.cutoff.sequence && root === segment.cutoff.root, "PEER_PREFIX_BRIDGE_INCOMPLETE");
  }
  /** Compare points on the selected history after their roots have been authenticated. */
  atOrAfter(point, floor) {
    const segments = this.selectedSegments();
    const left = segments.findIndex((value) => value.generation.id === point.generation);
    const right = segments.findIndex((value) => value.generation.id === floor.generation);
    return left >= 0 && right >= 0 && (left > right || left === right && point.sequence >= floor.sequence);
  }
  async authorizeTransition(request, nextControl = this.control) {
    validateRequest(request.payload);
    scope(request.payload, this.descriptor);
    await verifyPeerValue(DOMAINS.peerTransition, request, request.payload.requester);
    const value = request.payload, current = this.current, currentControl = this.control;
    check(value.expectedGeneration === (current?.id ?? null), "PEER_GENERATION_CONFLICT");
    check(value.controlRevision === nextControl.payload.revision, "PEER_CONTROL_REVISION_MISMATCH");
    const requester = this.grant(value.requester, currentControl.payload.revision);
    const candidate = nextControl.payload.grants.find((grant) => grant.publicKey === value.coordinator);
    check(requester?.recovery === true, "PEER_RECOVERY_FORBIDDEN");
    check(candidate?.coordinator === true && candidate.reader, "PEER_COORDINATOR_FORBIDDEN");
    if (current === null) {
      check(value.reason === "create" && value.base === null && nextControl.payload.revision === 0, "PEER_INITIAL_SELECTION_INVALID");
    } else {
      check(value.reason !== "create" && value.base !== null, "PEER_RECOVERY_BASE_REQUIRED");
      await this.verifyPrefix(value.base);
      if (value.reason === "handover") check(value.requester === current.payload.coordinator, "PEER_HANDOVER_FORBIDDEN");
      if (nextControl.payload.revision !== currentControl.payload.revision) {
        check(value.reason === "control-change" && requester.administrator, "PEER_CONTROL_CHANGE_FORBIDDEN");
        await verifyNextControl(this.descriptor, currentControl, nextControl);
      } else check(value.reason !== "control-change", "PEER_CONTROL_CHANGE_REQUIRED");
      const previousFloor = currentControl.payload.recoveryFloor;
      const floor = nextControl.payload.recoveryFloor;
      if (previousFloor !== null) {
        check(floor !== null && this.contains(floor) && this.atOrAfter(floor, previousFloor), "PEER_RECOVERY_FLOOR_REGRESSION");
      }
      if (floor !== null) check(this.contains(floor) && this.atOrAfter(value.base.point, floor), "PEER_RECOVERY_FLOOR_UNAVAILABLE");
      if (floor !== null && !samePeerValue(floor, previousFloor)) check(samePeerValue(floor, value.base.point), "PEER_NEW_FLOOR_MUST_MATCH_BASE");
    }
  }
  static async verify(input, pinned) {
    const bundle = structuredClone(input);
    object(bundle, ["descriptor", "controls", "generations"]);
    validateDescriptor(bundle.descriptor.payload);
    await verifyPeerValue(DOMAINS.peerDescriptor, bundle.descriptor, bundle.descriptor.payload.controlPublicKey);
    if (pinned !== void 0) check(samePeerValue(bundle.descriptor, pinned), "PEER_DESCRIPTOR_CHANGED");
    check(isArray(bundle.controls) && bundle.controls.length > 0 && bundle.controls.length <= 4096 && isArray(bundle.generations) && bundle.generations.length <= 4096, "PEER_AUTHORITY_LIMIT");
    const descriptor = bundle.descriptor.payload;
    for (const [index, control] of bundle.controls.entries()) {
      validateControl(control.payload);
      scope(control.payload, descriptor);
      await verifyPeerValue(DOMAINS.peerControl, control, descriptor.controlPublicKey);
      check(control.payload.revision === index, "PEER_CONTROL_CHAIN_INVALID");
      if (index === 0) check(control.payload.previous === null && control.payload.recoveryFloor === null, "PEER_INITIAL_CONTROL_INVALID");
      else await verifyNextControl(descriptor, bundle.controls[index - 1], control);
    }
    let verified = new _PeerAuthority({ descriptor: bundle.descriptor, controls: [bundle.controls[0]], generations: [] });
    const transitions = /* @__PURE__ */ new Set();
    for (const [number, generation] of bundle.generations.entries()) {
      object(generation, ["payload", "signature", "id"]);
      hex(generation.id);
      validateGeneration(generation.payload);
      const value = generation.payload;
      scope(value, descriptor);
      await verifyPeerValue(DOMAINS.peerGeneration, { payload: value, signature: generation.signature }, descriptor.controlPublicKey);
      check(generation.id === await peerDigest(["chronolog/peer-generation/generation/v1", value]), "PEER_GENERATION_ID_INVALID");
      check(value.number === number && value.previous === (verified.current?.id ?? null), "PEER_GENERATION_CHAIN_INVALID");
      const control = bundle.controls[value.controlRevision];
      check(control !== void 0 && value.controlDigest === await peerDigest(control), "PEER_CONTROL_DIGEST_MISMATCH");
      check(value.controlRevision === verified.control.payload.revision || value.controlRevision === verified.control.payload.revision + 1, "PEER_CONTROL_CHAIN_INVALID");
      await verified.authorizeTransition(value.transition, control);
      check(value.coordinator === value.transition.payload.coordinator && samePeerValue(value.adopted, value.transition.payload.base?.point ?? null) && samePeerValue(value.recoveryFloor, control.payload.recoveryFloor) && value.executionManifestDigest === descriptor.executionManifestDigest, "PEER_DELEGATION_MISMATCH");
      check(!transitions.has(value.transition.payload.transitionId), "PEER_TRANSITION_DUPLICATE");
      transitions.add(value.transition.payload.transitionId);
      verified = new _PeerAuthority({ descriptor: bundle.descriptor, controls: bundle.controls.slice(0, value.controlRevision + 1), generations: bundle.generations.slice(0, number + 1) });
    }
    check(verified.control.payload.revision === bundle.controls.length - 1, "PEER_CONTROL_NOT_ACTIVATED");
    return verified;
  }
};
async function verifyNextControl(descriptor, previous, next) {
  validateControl(next.payload);
  scope(next.payload, descriptor);
  await verifyPeerValue(DOMAINS.peerControl, next, descriptor.controlPublicKey);
  check(
    next.payload.revision === previous.payload.revision + 1 && next.payload.previous === await peerDigest(previous) && next.payload.epoch >= previous.payload.epoch,
    "PEER_CONTROL_CHAIN_INVALID"
  );
  const revokedReader = previous.payload.grants.some((old) => old.reader && !next.payload.grants.some((grant) => grant.publicKey === old.publicKey && grant.reader));
  if (revokedReader) check(next.payload.epoch > previous.payload.epoch && next.payload.keyDigest !== previous.payload.keyDigest, "PEER_REVOCATION_REQUIRES_KEY_ROTATION");
  if (next.payload.epoch === previous.payload.epoch) check(next.payload.keyDigest === previous.payload.keyDigest, "PEER_EPOCH_KEY_CHANGED");
}
function verifyAuthorityBundle(bundle, pinned) {
  return PeerAuthority.verify(bundle, pinned);
}
var registryLocks = /* @__PURE__ */ new WeakMap();
function registryLock(store, key) {
  let keys = registryLocks.get(store);
  if (keys === void 0) {
    keys = /* @__PURE__ */ new Map();
    registryLocks.set(store, keys);
  }
  let lock = keys.get(key);
  if (lock === void 0) {
    lock = new Serial();
    keys.set(key, lock);
  }
  return lock;
}
async function createGenerationRegistry(options) {
  const key = `peer-generation/registry/${options.descriptor.payload.applicationId}`;
  const lock = registryLock(options.store, key);
  check(options.signer.publicKey === options.descriptor.payload.controlPublicKey, "PEER_CONTROL_KEY_MISMATCH");
  const read = async () => {
    const bytes = await options.store.get(key);
    check(bytes !== null, "PEER_CONTROL_STATE_MISSING");
    const bundle = decodePeerValue(bytes);
    await verifyAuthorityBundle(bundle, options.descriptor);
    return bundle;
  };
  await lock.run(async () => {
    if (await options.store.get(key) === null) {
      check(options.requireExisting !== true, "PEER_CONTROL_STATE_MISSING");
      const initial = { descriptor: options.descriptor, controls: options.controls, generations: [] };
      await verifyAuthorityBundle(initial);
      await options.store.put(key, encodePeerValue(initial));
    }
    await read();
  });
  return {
    read: () => lock.run(read),
    async select(input, inputOptions = {}) {
      const request = structuredClone(input), next = structuredClone(inputOptions.control);
      return lock.run(async () => {
        const bundle = await read(), authority = await verifyAuthorityBundle(bundle);
        validateRequest(request.payload);
        await verifyPeerValue(DOMAINS.peerTransition, request, request.payload.requester);
        const retry = bundle.generations.find((value) => value.payload.transition.payload.transitionId === request.payload.transitionId);
        if (retry !== void 0) {
          check(samePeerValue(retry.payload.transition, request), "PEER_TRANSITION_ID_REUSED");
          if (next !== void 0) check(samePeerValue(bundle.controls[retry.payload.controlRevision], next), "PEER_TRANSITION_ID_REUSED");
          return retry;
        }
        const control = next ?? authority.control;
        await authority.authorizeTransition(request, control);
        const payload = {
          applicationId: authority.descriptor.applicationId,
          profile: PEER_GENERATION_PROFILE,
          policy: PEER_GENERATION_POLICY,
          number: bundle.generations.length,
          previous: authority.current?.id ?? null,
          coordinator: request.payload.coordinator,
          controlRevision: control.payload.revision,
          controlDigest: await peerDigest(control),
          adopted: request.payload.base?.point ?? null,
          recoveryFloor: control.payload.recoveryFloor,
          executionManifestDigest: authority.descriptor.executionManifestDigest,
          transition: request
        };
        const signed = await signPeerValue(DOMAINS.peerGeneration, payload, options.signer);
        const generation = { ...signed, id: await peerDigest(["chronolog/peer-generation/generation/v1", payload]) };
        const updated = {
          descriptor: bundle.descriptor,
          controls: next === void 0 ? bundle.controls : [...bundle.controls, next],
          generations: [...bundle.generations, generation]
        };
        await verifyAuthorityBundle(updated, options.descriptor);
        await options.store.put(key, encodePeerValue(updated));
        return structuredClone(generation);
      });
    }
  };
}

// packages/peer-generation/src/publication.ts
var PUBLICATION_LIMITS = Object.freeze({
  files: 128,
  bytes: 8 * 1024 * 1024,
  manifestBytes: 256 * 1024,
  revisions: 256,
  historyBytes: 16 * 1024 * 1024
});
function path(value) {
  boundedText(value, 1024);
  check(
    !/[\\?#%]/u.test(value) && value.split("/").every((part) => part.length > 0 && part !== "." && part !== ".."),
    "PEER_PUBLICATION_PATH_INVALID"
  );
}
function validatePublicationManifest(input) {
  object(input, [
    "applicationId",
    "historyId",
    "profile",
    "controlRevision",
    "author",
    "operationId",
    "revision",
    "previous",
    "definitionDigest",
    "executionManifestDigest",
    "entry",
    "files"
  ]);
  const value = input;
  hex(value.applicationId);
  boundedText(value.historyId, 128);
  hex(value.author);
  boundedText(value.operationId, 128);
  check(value.profile === PEER_GENERATION_PROFILE, "PEER_PROFILE_UNSUPPORTED");
  uint(value.controlRevision);
  uint(value.revision, PUBLICATION_LIMITS.revisions - 1);
  if (value.previous !== null) hex(value.previous);
  check(value.revision === 0 === (value.previous === null), "PEER_PUBLICATION_CHAIN_INVALID");
  hex(value.definitionDigest);
  hex(value.executionManifestDigest);
  path(value.entry);
  check(isArray(value.files) && value.files.length > 0 && value.files.length <= PUBLICATION_LIMITS.files, "PEER_PUBLICATION_FILES_LIMIT");
  let previous, total = 0;
  for (const file of value.files) {
    object(file, ["path", "hash", "size", "type"]);
    path(file.path);
    hex(file.hash);
    uint(file.size, PUBLICATION_LIMITS.bytes);
    boundedText(file.type, 256);
    check(/^[a-z][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*(?:;[ -~]*)?$/iu.test(file.type), "PEER_PUBLICATION_TYPE_INVALID");
    check(previous === void 0 || previous < file.path, "PEER_PUBLICATION_FILES_NOT_ORDERED");
    previous = file.path;
    total += file.size;
  }
  check(total <= PUBLICATION_LIMITS.bytes, "PEER_PUBLICATION_BYTES_LIMIT");
  check(value.files.some((file) => file.path === value.entry), "PEER_PUBLICATION_ENTRY_MISSING");
  check(encodePeerValue(value).length <= PUBLICATION_LIMITS.manifestBytes, "PEER_PUBLICATION_MANIFEST_LIMIT");
  return structuredClone(value);
}
async function signPublicationManifest(input, signer) {
  const payload = validatePublicationManifest(input);
  check(payload.author === signer.publicKey, "PEER_PUBLICATION_AUTHOR_MISMATCH");
  const signed = await signPeerValue(DOMAINS.peerPublication, payload, signer);
  return { ...signed, id: await peerDigest(["chronolog/publication/v1", signed.payload]) };
}
async function verifyPublicationManifest(input, authority) {
  const publication = structuredClone(input);
  object(publication, ["payload", "signature", "id"]);
  hex(publication.id);
  const value = validatePublicationManifest(publication.payload), descriptor = authority.descriptor;
  check(value.applicationId === descriptor.applicationId && value.historyId === descriptor.historyId && value.profile === descriptor.profile, "PEER_PUBLICATION_SCOPE_MISMATCH");
  check(
    value.definitionDigest === descriptor.definitionDigest && value.executionManifestDigest === descriptor.executionManifestDigest,
    "PEER_PUBLICATION_SEMANTICS_MISMATCH"
  );
  check(authority.grant(value.author, value.controlRevision)?.publisher === true, "PEER_PUBLICATION_FORBIDDEN");
  check(publication.id === await peerDigest(["chronolog/publication/v1", value]), "PEER_PUBLICATION_ID_INVALID");
  await verifyPeerValue(DOMAINS.peerPublication, { payload: value, signature: publication.signature }, value.author);
}
async function authorizePublication(input, authority, previous) {
  const publication = structuredClone(input), head = structuredClone(previous);
  await verifyPublicationManifest(publication, authority);
  check(
    publication.payload.controlRevision === authority.control.payload.revision && authority.grant(publication.payload.author)?.publisher === true,
    "PEER_PUBLICATION_CONTROL_CHANGED"
  );
  if (head !== null) await verifyPublicationManifest(head, authority);
  check(
    publication.payload.previous === (head?.id ?? null) && publication.payload.revision === (head === null ? 0 : head.payload.revision + 1),
    "PEER_PUBLICATION_CONFLICT"
  );
}
async function verifyPublicationAsset(file, input) {
  object(file, ["path", "hash", "size", "type"]);
  path(file.path);
  hex(file.hash);
  uint(file.size, PUBLICATION_LIMITS.bytes);
  const bytes = input.slice();
  check(bytes.length === file.size && await bytesDigest(bytes) === file.hash, "PEER_PUBLICATION_ASSET_MISMATCH");
}
var locks = /* @__PURE__ */ new WeakMap();
function publicationLock(store, key) {
  let keys = locks.get(store);
  if (keys === void 0) {
    keys = /* @__PURE__ */ new Map();
    locks.set(store, keys);
  }
  let lock = keys.get(key);
  if (lock === void 0) {
    lock = new Serial();
    keys.set(key, lock);
  }
  return lock;
}
async function createPublicationRegistry(options) {
  const store = options.store, readAuthority = options.authority;
  const initial = await verifyAuthorityBundle(await readAuthority()), descriptor = initial.bundle.descriptor;
  const key = `peer-generation/publications/${descriptor.payload.applicationId}`, lock = publicationLock(store, key);
  const authority = async () => verifyAuthorityBundle(await readAuthority(), descriptor);
  const read = async (verified) => {
    const bytes = await store.get(key);
    check(bytes !== null, "PEER_PUBLICATION_STATE_MISSING");
    check(bytes.length <= PUBLICATION_LIMITS.historyBytes, "PEER_PUBLICATION_HISTORY_LIMIT");
    const values = decodePeerValue(bytes);
    check(isArray(values) && values.length <= PUBLICATION_LIMITS.revisions, "PEER_PUBLICATION_HISTORY_LIMIT");
    const operations = /* @__PURE__ */ new Set();
    for (const [index, publication] of values.entries()) {
      await verifyPublicationManifest(publication, verified);
      check(publication.payload.revision === index && publication.payload.previous === (values[index - 1]?.id ?? null), "PEER_PUBLICATION_CHAIN_INVALID");
      check(!operations.has(publication.payload.operationId), "PEER_PUBLICATION_OPERATION_REUSED");
      operations.add(publication.payload.operationId);
    }
    return values;
  };
  await lock.run(async () => {
    if (await store.get(key) === null) {
      check(options.requireExisting !== true, "PEER_PUBLICATION_STATE_MISSING");
      await store.put(key, encodePeerValue([]));
    }
    await read(await authority());
  });
  return {
    read: () => lock.run(async () => structuredClone(await read(await authority()))),
    async publish(input) {
      const publication = structuredClone(input);
      return lock.run(async () => {
        const verified = await authority(), values = await read(verified);
        await verifyPublicationManifest(publication, verified);
        const retry = values.find((value) => value.payload.operationId === publication.payload.operationId);
        if (retry !== void 0) {
          check(samePeerValue(retry, publication), "PEER_PUBLICATION_OPERATION_REUSED");
          return structuredClone(retry);
        }
        await authorizePublication(publication, verified, values.at(-1) ?? null);
        check(values.length < PUBLICATION_LIMITS.revisions, "PEER_PUBLICATION_HISTORY_LIMIT");
        const bytes = encodePeerValue([...values, publication]);
        check(bytes.length <= PUBLICATION_LIMITS.historyBytes, "PEER_PUBLICATION_HISTORY_LIMIT");
        const latest = await authority();
        assertAuthorityExtension(verified, latest);
        await authorizePublication(publication, latest, values.at(-1) ?? null);
        await store.put(key, bytes);
        return structuredClone(publication);
      });
    }
  };
}

// packages/crypto/src/epoch.ts
function source(value) {
  return Uint8Array.from(value).buffer;
}
function payloadAad(epoch, associatedData) {
  return encodeCanonicalCbor(integerMap([[0, 1n], [1, epoch], [2, associatedData]]));
}
async function encryptEpochPayload(contentKey, epoch, plaintext, associatedData) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  const key = await globalThis.crypto.subtle.importKey("raw", source(contentKey), "AES-GCM", false, ["encrypt"]);
  const nonce = globalThis.crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source(nonce), additionalData: source(payloadAad(epoch, associatedData)), tagLength: 128 },
    key,
    source(plaintext)
  ));
  return { epoch, nonce, ciphertext };
}
async function decryptEpochPayload(contentKey, payload, associatedData) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  protocolInvariant(payload.nonce.length === 12, "SCHEMA_INVALID", "Epoch payload nonce must contain 12 bytes");
  try {
    const key = await globalThis.crypto.subtle.importKey("raw", source(contentKey), "AES-GCM", false, ["decrypt"]);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source(payload.nonce), additionalData: source(payloadAad(payload.epoch, associatedData)), tagLength: 128 },
      key,
      source(payload.ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "Epoch payload authentication failed");
  }
}

// packages/crypto/src/hpke.ts
var HPKE_SUITE = "DHKEM(X25519,HKDF-SHA256)/HKDF-SHA256/AES-256-GCM";
var KEM_ID = Uint8Array.of(0, 32);
var KDF_ID = Uint8Array.of(0, 1);
var AEAD_ID = Uint8Array.of(0, 2);
var KEM_SUITE_ID = concatBytes(utf8("KEM"), KEM_ID);
var HPKE_SUITE_ID = concatBytes(utf8("HPKE"), KEM_ID, KDF_ID, AEAD_ID);
var HPKE_VERSION = utf8("HPKE-v1");
var HASH_SIZE = 32;
var X25519 = { name: "X25519" };
function source2(value) {
  return Uint8Array.from(value).buffer;
}
function i2osp(value, length) {
  protocolInvariant(Number.isSafeInteger(value) && value >= 0 && value < 2 ** (8 * length), "INTEGER_OUT_OF_RANGE", "Integer does not fit HPKE field");
  const result = new Uint8Array(length);
  let remainder = value;
  for (let index = length - 1; index >= 0; index -= 1) {
    result[index] = remainder & 255;
    remainder = Math.floor(remainder / 256);
  }
  return result;
}
async function hmac(keyBytes, data) {
  const key = await globalThis.crypto.subtle.importKey(
    "raw",
    source2(keyBytes),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return new Uint8Array(await globalThis.crypto.subtle.sign("HMAC", key, source2(data)));
}
async function hkdfExtract(salt, ikm) {
  return hmac(salt.length === 0 ? new Uint8Array(HASH_SIZE) : salt, ikm);
}
async function hkdfExpand(prk, info, length) {
  protocolInvariant(length <= 255 * HASH_SIZE, "INTEGER_OUT_OF_RANGE", "HKDF output is too long");
  let previous = new Uint8Array();
  const blocks = [];
  for (let counter = 1; blocks.reduce((sum, block) => sum + block.length, 0) < length; counter += 1) {
    previous = await hmac(prk, concatBytes(previous, info, Uint8Array.of(counter)));
    blocks.push(previous);
  }
  return concatBytes(...blocks).slice(0, length);
}
async function labeledExtract(suiteId, salt, label, ikm) {
  return hkdfExtract(salt, concatBytes(HPKE_VERSION, suiteId, utf8(label), ikm));
}
async function labeledExpand(suiteId, prk, label, info, length) {
  return hkdfExpand(prk, concatBytes(i2osp(length, 2), HPKE_VERSION, suiteId, utf8(label), info), length);
}
async function generateX25519KeyPair(extractable = true) {
  const pair = await globalThis.crypto.subtle.generateKey(X25519, extractable, ["deriveBits"]);
  return {
    publicKey: pair.publicKey,
    privateKey: pair.privateKey,
    publicKeyBytes: new Uint8Array(await globalThis.crypto.subtle.exportKey("raw", pair.publicKey))
  };
}
async function importX25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "X25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", source2(raw), X25519, true, []);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import X25519 public key");
  }
}
async function dh(privateKey, publicKey) {
  try {
    const bits = await globalThis.crypto.subtle.deriveBits({ name: "X25519", public: publicKey }, privateKey, 256);
    const result = new Uint8Array(bits);
    protocolInvariant(result.some((byte) => byte !== 0), "INVALID_KEY", "X25519 produced the prohibited all-zero shared secret");
    return result;
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    throw new ProtocolError("INVALID_KEY", "X25519 key agreement failed");
  }
}
async function extractAndExpand(dhValue, kemContext) {
  const eaePrk = await labeledExtract(KEM_SUITE_ID, new Uint8Array(), "eae_prk", dhValue);
  return labeledExpand(KEM_SUITE_ID, eaePrk, "shared_secret", kemContext, HASH_SIZE);
}
async function keySchedule(sharedSecret, info) {
  const pskIdHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "psk_id_hash", new Uint8Array());
  const infoHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "info_hash", info);
  const keyScheduleContext = concatBytes(Uint8Array.of(0), pskIdHash, infoHash);
  const secret = await labeledExtract(HPKE_SUITE_ID, sharedSecret, "secret", new Uint8Array());
  return {
    key: await labeledExpand(HPKE_SUITE_ID, secret, "key", keyScheduleContext, 32),
    nonce: await labeledExpand(HPKE_SUITE_ID, secret, "base_nonce", keyScheduleContext, 12),
    exporterSecret: await labeledExpand(HPKE_SUITE_ID, secret, "exp", keyScheduleContext, HASH_SIZE)
  };
}
async function aesGcmSeal(keyBytes, nonce, plaintext, aad) {
  const key = await globalThis.crypto.subtle.importKey("raw", source2(keyBytes), "AES-GCM", false, ["encrypt"]);
  return new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source2(nonce), additionalData: source2(aad), tagLength: 128 },
    key,
    source2(plaintext)
  ));
}
async function aesGcmOpen(keyBytes, nonce, ciphertext, aad) {
  try {
    const key = await globalThis.crypto.subtle.importKey("raw", source2(keyBytes), "AES-GCM", false, ["decrypt"]);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source2(nonce), additionalData: source2(aad), tagLength: 128 },
      key,
      source2(ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "HPKE ciphertext authentication failed");
  }
}
async function senderContext(recipientPublicKeyBytes, info) {
  const recipientPublicKey = await importX25519PublicKey(recipientPublicKeyBytes);
  const ephemeral = await generateX25519KeyPair(false);
  const sharedSecret = await extractAndExpand(
    await dh(ephemeral.privateKey, recipientPublicKey),
    concatBytes(ephemeral.publicKeyBytes, recipientPublicKeyBytes)
  );
  try {
    return { encapsulatedKey: ephemeral.publicKeyBytes, context: await keySchedule(sharedSecret, info) };
  } finally {
    sharedSecret.fill(0);
  }
}
async function recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info) {
  protocolInvariant(recipientPublicKeyBytes.length === 32 && encapsulatedKey.length === 32, "INVALID_KEY", "HPKE X25519 keys must contain 32 bytes");
  const ephemeralPublicKey = await importX25519PublicKey(encapsulatedKey);
  const sharedSecret = await extractAndExpand(
    await dh(recipientPrivateKey, ephemeralPublicKey),
    concatBytes(encapsulatedKey, recipientPublicKeyBytes)
  );
  try {
    return await keySchedule(sharedSecret, info);
  } finally {
    sharedSecret.fill(0);
  }
}
function clearContext(context) {
  context.key.fill(0);
  context.nonce.fill(0);
  context.exporterSecret.fill(0);
}
async function hpkeSealBase(recipientPublicKeyBytes, plaintext, info, aad) {
  const { encapsulatedKey, context } = await senderContext(recipientPublicKeyBytes, info);
  try {
    return { encapsulatedKey, ciphertext: await aesGcmSeal(context.key, context.nonce, plaintext, aad) };
  } finally {
    clearContext(context);
  }
}
async function hpkeOpenBase(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, ciphertext, info, aad) {
  const context = await recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info);
  try {
    return await aesGcmOpen(context.key, context.nonce, ciphertext, aad);
  } finally {
    clearContext(context);
  }
}
async function hpkeSendExportBase(recipientPublicKeyBytes, info, exporterContext, length) {
  const { encapsulatedKey, context } = await senderContext(recipientPublicKeyBytes, info);
  try {
    return { encapsulatedKey, exportedSecret: await labeledExpand(HPKE_SUITE_ID, context.exporterSecret, "sec", exporterContext, length) };
  } finally {
    clearContext(context);
  }
}
async function hpkeReceiveExportBase(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info, exporterContext, length) {
  const context = await recipientContext(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, info);
  try {
    return await labeledExpand(HPKE_SUITE_ID, context.exporterSecret, "sec", exporterContext, length);
  } finally {
    clearContext(context);
  }
}

// packages/peer-generation/src/attempt.ts
function validatePeerRevision(value) {
  object(value, ["applicationId", "historyId", "generation", "point", "controlRevision", "materializationRevision"]);
  hex(value.applicationId);
  boundedText(value.historyId, 128);
  hex(value.generation);
  uint(value.controlRevision);
  validateHistoryPoint(value.point);
  check(typeof value.materializationRevision === "string" && /^[0-9]{1,32}$/u.test(value.materializationRevision), "PEER_REVISION_INVALID");
}
function validateHeader(value) {
  object(value, [
    "applicationId",
    "profile",
    "generation",
    "controlRevision",
    "epoch",
    "author",
    "operationId",
    "definitionDigest",
    "command",
    "commandVersion",
    "basedOn",
    "reapplyOf",
    "coreDigest"
  ]);
  hex(value.applicationId);
  hex(value.generation);
  uint(value.controlRevision);
  uint(value.epoch);
  hex(value.author);
  boundedText(value.operationId);
  hex(value.definitionDigest);
  hex(value.coreDigest);
  boundedText(value.command, 128);
  boundedText(value.commandVersion, 128);
  if (value.basedOn !== null) validatePeerRevision(value.basedOn);
  if (value.reapplyOf !== null) hex(value.reapplyOf);
  check(value.profile === "peer-generation-v1", "PEER_PROFILE_UNSUPPORTED");
}
async function createSignedAttempt(header, core, key, device) {
  validateHeader(header);
  check(header.author === device.publicKey && header.operationId === core.operationId, "PEER_AUTHOR_MISMATCH");
  const plaintext = encodeTransactionCore(core);
  check(header.coreDigest === bytesToHex(await transactionDigest(plaintext)), "PEER_ATTEMPT_CORE_MISMATCH");
  const encrypted = await encryptEpochPayload(key, BigInt(header.epoch), plaintext, encodePeerValue(header));
  const payload = { header: structuredClone(header), nonce: bytesToHex(encrypted.nonce), ciphertext: bytesToHex(encrypted.ciphertext) };
  const signed = await signPeerValue(DOMAINS.peerAttempt, payload, device);
  return { ...signed, id: await peerDigest(["chronolog/peer-generation/attempt/v1", payload]) };
}
async function verifyAttempt(attempt, authority, epochKeys) {
  object(attempt, ["payload", "signature", "id"]);
  hex(attempt.id);
  object(attempt.payload, ["header", "nonce", "ciphertext"]);
  validateHeader(attempt.payload.header);
  hex(attempt.payload.nonce, 12);
  check(typeof attempt.payload.ciphertext === "string" && attempt.payload.ciphertext.length <= 2 * 524288 && attempt.payload.ciphertext.length >= 32 && /^(?:[0-9a-f]{2})+$/u.test(attempt.payload.ciphertext), "PEER_ATTEMPT_BODY_INVALID");
  const { header } = attempt.payload, descriptor = authority.descriptor;
  check(header.applicationId === descriptor.applicationId && header.definitionDigest === descriptor.definitionDigest, "PEER_SCOPE_MISMATCH");
  const generation = authority.generation(header.generation), control = authority.controlAt(generation.payload.controlRevision);
  check(header.controlRevision === control.payload.revision && header.epoch === control.payload.epoch, "PEER_ATTEMPT_CONTROL_MISMATCH");
  check(authority.grant(header.author, header.controlRevision)?.writer === true, "PEER_AUTHOR_FORBIDDEN");
  check(attempt.id === await peerDigest(["chronolog/peer-generation/attempt/v1", attempt.payload]), "PEER_ATTEMPT_ID_INVALID");
  await verifyPeerValue(DOMAINS.peerAttempt, { payload: attempt.payload, signature: attempt.signature }, header.author);
  const key = epochKeys.get(header.epoch);
  check(key !== void 0, "PEER_EPOCH_KEY_UNAVAILABLE");
  check(await bytesDigest(key) === control.payload.keyDigest, "PEER_EPOCH_KEY_MISMATCH");
  const encoded = await decryptEpochPayload(key, {
    epoch: BigInt(header.epoch),
    nonce: hexToBytes(attempt.payload.nonce),
    ciphertext: hexToBytes(attempt.payload.ciphertext)
  }, encodePeerValue(header));
  const core = decodeTransactionCore(encoded);
  check(header.coreDigest === bytesToHex(await transactionDigest(encoded)) && core.operationId === header.operationId && bytesToHex(core.authorId) === header.author && bytesToHex(core.groupId) === descriptor.applicationId && bytesToHex(core.executionManifestDigest) === descriptor.executionManifestDigest && bytesToHex(core.membershipRevision) === await peerDigest(control) && bytesToHex(core.validationPolicy) === await peerDigest([descriptor.profile, descriptor.policy]) && equalBytes(encodeTransactionCore(core), encoded), "PEER_ATTEMPT_CORE_MISMATCH");
  check(!core.program.steps.some(isPlatformOp), "PEER_PROTECTED_CHANGE_REQUIRED");
  return core;
}

export {
  signApplicationSchema,
  verifyApplicationSchema,
  PARTICIPANT_PROTOCOL,
  PARTICIPANT_LIMITS,
  CONTROL_PARTICIPANT_POLICY,
  PEER_PARTICIPANT_POLICY,
  ParticipantProtocolError,
  participantAccepts,
  validateParticipantRequest,
  createParticipantRequest,
  createParticipantResponse,
  validateParticipantResponse,
  createParticipantTransport,
  PUBLICATION_LIMITS,
  validatePublicationManifest,
  signPublicationManifest,
  verifyPublicationManifest,
  authorizePublication,
  verifyPublicationAsset,
  createPublicationRegistry,
  assertAuthorityExtension,
  validateHistoryPoint,
  signApplicationDescriptor,
  participantGrant,
  controlParticipantGrant,
  signControlRevision,
  signTransitionRequest,
  generationStartRoot,
  verifyOrderReceipt,
  PeerAuthority,
  verifyAuthorityBundle,
  createGenerationRegistry,
  HPKE_SUITE,
  generateX25519KeyPair,
  hpkeSealBase,
  hpkeOpenBase,
  hpkeSendExportBase,
  hpkeReceiveExportBase,
  validatePeerRevision,
  createSignedAttempt,
  verifyAttempt
};
