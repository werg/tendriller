// packages/canonical/src/errors.ts
var CanonicalError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.details = details;
    this.name = "CanonicalError";
  }
  code;
  details;
};
function canonicalInvariant(condition, code, message, details) {
  if (!condition) throw new CanonicalError(code, message, details);
}

// packages/canonical/src/bytes.ts
var textEncoder = new TextEncoder();
var fatalTextDecoder = new TextDecoder("utf-8", { fatal: true });
function utf8(value) {
  const encoded = textEncoder.encode(value);
  try {
    if (fatalTextDecoder.decode(encoded) !== value) throw new CanonicalError("INVALID_UTF8", "Text contains an unpaired UTF-16 surrogate");
  } catch (error) {
    if (error instanceof CanonicalError) throw error;
    throw new CanonicalError("INVALID_UTF8", "Text cannot be represented as canonical UTF-8");
  }
  return encoded;
}
function decodeUtf8(value) {
  try {
    return fatalTextDecoder.decode(value);
  } catch {
    throw new CanonicalError("INVALID_UTF8", "Bytes are not valid UTF-8");
  }
}
function concatBytes(...parts) {
  const size = parts.reduce((sum, part) => sum + part.length, 0);
  const result = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}
function compareBytes(left, right) {
  const size = Math.min(left.length, right.length);
  for (let index = 0; index < size; index += 1) {
    const difference = left[index] - right[index];
    if (difference !== 0) return difference < 0 ? -1 : 1;
  }
  return left.length === right.length ? 0 : left.length < right.length ? -1 : 1;
}
function equalBytes(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}
function bytesToHex(value) {
  return [...value].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

// packages/canonical/src/cbor.ts
var DEFAULT_DECODE_LIMITS = Object.freeze({
  maxBytes: 16 * 1024 * 1024,
  maxDepth: 64,
  maxArrayItems: 1e6,
  maxMapItems: 1e5,
  maxTextBytes: 4 * 1024 * 1024,
  maxBlobBytes: 16 * 1024 * 1024
});
var MAX_UINT64 = (1n << 64n) - 1n;
var POSITIVE_BIGNUM_TAG = 2n;
var NEGATIVE_BIGNUM_TAG = 3n;
function encodeHead(major, value) {
  canonicalInvariant(value >= 0n && value <= MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR integer is outside uint64 range");
  if (value < 24n) return Uint8Array.of(major << 5 | Number(value));
  if (value <= 0xffn) return Uint8Array.of(major << 5 | 24, Number(value));
  if (value <= 0xffffn) return Uint8Array.of(major << 5 | 25, Number(value >> 8n), Number(value & 0xffn));
  if (value <= 0xffffffffn) {
    const bytes4 = new Uint8Array(5);
    bytes4[0] = major << 5 | 26;
    new DataView(bytes4.buffer).setUint32(1, Number(value), false);
    return bytes4;
  }
  const bytes3 = new Uint8Array(9);
  bytes3[0] = major << 5 | 27;
  new DataView(bytes3.buffer).setBigUint64(1, value, false);
  return bytes3;
}
function magnitudeBytes(value) {
  canonicalInvariant(value > MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR bignum must exceed uint64 range");
  const octets = [];
  for (let remaining = value; remaining > 0n; remaining >>= 8n) octets.push(Number(remaining & 0xffn));
  octets.reverse();
  return Uint8Array.from(octets);
}
function encodeBigint(value) {
  const negative = value < 0n;
  const magnitude = negative ? -1n - value : value;
  if (magnitude <= MAX_UINT64) return encodeHead(negative ? 1 : 0, magnitude);
  const bytes3 = magnitudeBytes(magnitude);
  return concatBytes(
    encodeHead(6, negative ? NEGATIVE_BIGNUM_TAG : POSITIVE_BIGNUM_TAG),
    encodeHead(2, BigInt(bytes3.length)),
    bytes3
  );
}
function isMap(value) {
  return value instanceof Map;
}
function encodeCanonicalCbor(value) {
  if (value === null) return Uint8Array.of(246);
  if (value === false) return Uint8Array.of(244);
  if (value === true) return Uint8Array.of(245);
  if (typeof value === "bigint") return encodeBigint(value);
  if (typeof value === "string") {
    const bytes3 = utf8(value);
    return concatBytes(encodeHead(3, BigInt(bytes3.length)), bytes3);
  }
  if (value instanceof Uint8Array) return concatBytes(encodeHead(2, BigInt(value.length)), value);
  if (Array.isArray(value)) return concatBytes(encodeHead(4, BigInt(value.length)), ...value.map(encodeCanonicalCbor));
  if (isMap(value)) {
    const entries = [...value].map(([key, item]) => ({ key: encodeCanonicalCbor(key), value: encodeCanonicalCbor(item) })).sort((a, b) => a.key.length === b.key.length ? compareBytes(a.key, b.key) : a.key.length - b.key.length);
    for (let index = 1; index < entries.length; index += 1) canonicalInvariant(!equalBytes(entries[index - 1].key, entries[index].key), "CBOR_NON_CANONICAL", "Duplicate canonical CBOR map key");
    return concatBytes(encodeHead(5, BigInt(entries.length)), ...entries.flatMap((entry) => [entry.key, entry.value]));
  }
  throw new CanonicalError("SCHEMA_INVALID", "Value is not supported by the deterministic CBOR profile");
}
var Decoder = class {
  constructor(input, limits) {
    this.input = input;
    this.limits = limits;
    canonicalInvariant(input.length <= limits.maxBytes, "CBOR_LIMIT_EXCEEDED", "CBOR input exceeds byte limit");
  }
  input;
  limits;
  offset = 0;
  decode() {
    const value = this.value(0);
    canonicalInvariant(this.offset === this.input.length, "CBOR_INVALID", "Trailing bytes after CBOR value");
    return value;
  }
  byte() {
    canonicalInvariant(this.offset < this.input.length, "CBOR_INVALID", "Unexpected end of CBOR input");
    return this.input[this.offset++];
  }
  bytes(size) {
    canonicalInvariant(Number.isSafeInteger(size) && size >= 0 && this.offset + size <= this.input.length, "CBOR_INVALID", "Invalid or truncated CBOR byte range");
    const value = this.input.slice(this.offset, this.offset + size);
    this.offset += size;
    return value;
  }
  argument(additional) {
    if (additional < 24) return BigInt(additional);
    const read = (size) => {
      const bytes3 = this.bytes(size);
      const view = new DataView(bytes3.buffer, bytes3.byteOffset, size);
      return size === 1 ? BigInt(bytes3[0]) : size === 2 ? BigInt(view.getUint16(0, false)) : size === 4 ? BigInt(view.getUint32(0, false)) : view.getBigUint64(0, false);
    };
    if (additional === 24) {
      const v = read(1);
      canonicalInvariant(v >= 24n, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 25) {
      const v = read(2);
      canonicalInvariant(v > 0xffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 26) {
      const v = read(4);
      canonicalInvariant(v > 0xffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 27) {
      const v = read(8);
      canonicalInvariant(v > 0xffffffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 31) throw new CanonicalError("CBOR_NON_CANONICAL", "Indefinite-length CBOR is prohibited");
    throw new CanonicalError("CBOR_INVALID", "Reserved CBOR additional information");
  }
  bignum(tag, depth) {
    canonicalInvariant(tag === POSITIVE_BIGNUM_TAG || tag === NEGATIVE_BIGNUM_TAG, "CBOR_INVALID", "Unsupported CBOR tag");
    canonicalInvariant(depth < this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    canonicalInvariant(major === 2, "CBOR_INVALID", "CBOR bignum payload must be a byte string");
    const argument = this.argument(additional);
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR bignum is too large");
    const size = Number(argument);
    canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR bignum exceeds blob limit");
    const bytes3 = this.bytes(size);
    canonicalInvariant(bytes3.length > 8 && bytes3[0] !== 0, "CBOR_NON_CANONICAL", "CBOR bignum is not minimally encoded");
    let magnitude = 0n;
    for (const byte of bytes3) magnitude = magnitude << 8n | BigInt(byte);
    canonicalInvariant(magnitude > MAX_UINT64, "CBOR_NON_CANONICAL", "CBOR bignum must use the ordinary integer representation");
    return tag === POSITIVE_BIGNUM_TAG ? magnitude : -1n - magnitude;
  }
  value(depth) {
    canonicalInvariant(depth <= this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    if (major === 7) {
      if (additional === 20) return false;
      if (additional === 21) return true;
      if (additional === 22) return null;
      throw new CanonicalError("CBOR_INVALID", "Floating point and unsupported simple CBOR values are prohibited");
    }
    const argument = this.argument(additional);
    if (major === 6) return this.bignum(argument, depth + 1);
    if (major === 0) return argument;
    if (major === 1) return -1n - argument;
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR collection is too large");
    const size = Number(argument);
    if (major === 2) {
      canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR blob exceeds limit");
      return this.bytes(size);
    }
    if (major === 3) {
      canonicalInvariant(size <= this.limits.maxTextBytes, "CBOR_LIMIT_EXCEEDED", "CBOR text exceeds limit");
      return decodeUtf8(this.bytes(size));
    }
    if (major === 4) {
      canonicalInvariant(size <= this.limits.maxArrayItems, "CBOR_LIMIT_EXCEEDED", "CBOR array exceeds item limit");
      return Array.from({ length: size }, () => this.value(depth + 1));
    }
    if (major === 5) {
      canonicalInvariant(size <= this.limits.maxMapItems, "CBOR_LIMIT_EXCEEDED", "CBOR map exceeds item limit");
      const map = /* @__PURE__ */ new Map();
      let previous;
      for (let index = 0; index < size; index += 1) {
        const start = this.offset, key = this.value(depth + 1);
        canonicalInvariant(typeof key === "bigint" || typeof key === "string" || key instanceof Uint8Array, "CBOR_INVALID", "Unsupported CBOR map key");
        const encoded = this.input.slice(start, this.offset);
        if (previous !== void 0) canonicalInvariant(previous.length === encoded.length ? compareBytes(previous, encoded) < 0 : previous.length < encoded.length, "CBOR_NON_CANONICAL", "CBOR map keys are duplicate or incorrectly ordered");
        previous = encoded;
        map.set(key, this.value(depth + 1));
      }
      return map;
    }
    throw new CanonicalError("CBOR_INVALID", `Unsupported CBOR major type ${major}`);
  }
};
function decodeCanonicalCbor(input, limits) {
  return new Decoder(input, limits).decode();
}
function assertCanonicalCbor(input, limits) {
  const value = decodeCanonicalCbor(input, limits);
  canonicalInvariant(equalBytes(encodeCanonicalCbor(value), input), "CBOR_NON_CANONICAL", "CBOR bytes are not canonical");
  return value;
}

// packages/canonical/src/hash.ts
var HASH_DOMAINS = Object.freeze({
  transaction: "chronolog/transaction",
  schema: "chronolog/schema",
  executionManifest: "chronolog/execution-manifest",
  queryResult: "chronolog/query-result",
  expectation: "chronolog/expectation",
  module: "chronolog/module",
  entropy: "chronolog/entropy",
  platformObject: "chronolog/platform-object"
});
function bufferSource(value) {
  return Uint8Array.from(value).buffer;
}
async function sha256(payload) {
  return new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bufferSource(payload)));
}

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/utils.js
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function abytes(b, ...lengths) {
  if (!isBytes(b))
    throw new Error("Uint8Array expected");
  if (lengths.length > 0 && !lengths.includes(b.length))
    throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
}
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput(out, instance) {
  abytes(out);
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error("digestInto() expects output buffer of length at least " + min);
  }
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word, shift) {
  return word << 32 - shift | word >>> shift;
}
function utf8ToBytes(str) {
  if (typeof str !== "string")
    throw new Error("string expected");
  return new Uint8Array(new TextEncoder().encode(str));
}
function toBytes(data) {
  if (typeof data === "string")
    data = utf8ToBytes(data);
  abytes(data);
  return data;
}
var Hash = class {
};
function createHasher(hashCons) {
  const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
  const tmp = hashCons();
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = () => hashCons();
  return hashC;
}

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/_md.js
function setBigUint64(view, byteOffset, value, isLE) {
  if (typeof view.setBigUint64 === "function")
    return view.setBigUint64(byteOffset, value, isLE);
  const _32n = BigInt(32);
  const _u32_max = BigInt(4294967295);
  const wh = Number(value >> _32n & _u32_max);
  const wl = Number(value & _u32_max);
  const h = isLE ? 4 : 0;
  const l = isLE ? 0 : 4;
  view.setUint32(byteOffset + h, wh, isLE);
  view.setUint32(byteOffset + l, wl, isLE);
}
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD = class extends Hash {
  constructor(blockLen, outputLen, padOffset, isLE) {
    super();
    this.finished = false;
    this.length = 0;
    this.pos = 0;
    this.destroyed = false;
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
  update(data) {
    aexists(this);
    data = toBytes(data);
    abytes(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        continue;
      }
      buffer.set(data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
      }
    }
    this.length += data.length;
    this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    clean(this.buffer.subarray(pos));
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      pos = 0;
    }
    for (let i = pos; i < blockLen; i++)
      buffer[i] = 0;
    setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE);
    this.process(view, 0);
    const oview = createView(out);
    const len = this.outputLen;
    if (len % 4)
      throw new Error("_sha2: outputLen should be aligned to 32bit");
    const outLen = len / 4;
    const state = this.get();
    if (outLen > state.length)
      throw new Error("_sha2: outputLen bigger than state");
    for (let i = 0; i < outLen; i++)
      oview.setUint32(4 * i, state[i], isLE);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneInto(to) {
    to || (to = new this.constructor());
    to.set(...this.get());
    const { blockLen, buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (length % blockLen)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha2.js
var SHA256_K = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
var SHA256 = class extends HashMD {
  constructor(outputLen = 32) {
    super(64, outputLen, 8, false);
    this.A = SHA256_IV[0] | 0;
    this.B = SHA256_IV[1] | 0;
    this.C = SHA256_IV[2] | 0;
    this.D = SHA256_IV[3] | 0;
    this.E = SHA256_IV[4] | 0;
    this.F = SHA256_IV[5] | 0;
    this.G = SHA256_IV[6] | 0;
    this.H = SHA256_IV[7] | 0;
  }
  get() {
    const { A, B, C, D, E, F, G, H } = this;
    return [A, B, C, D, E, F, G, H];
  }
  // prettier-ignore
  set(A, B, C, D, E, F, G, H) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
    this.F = F | 0;
    this.G = G | 0;
    this.H = H | 0;
  }
  process(view, offset) {
    for (let i = 0; i < 16; i++, offset += 4)
      SHA256_W[i] = view.getUint32(offset, false);
    for (let i = 16; i < 64; i++) {
      const W15 = SHA256_W[i - 15];
      const W2 = SHA256_W[i - 2];
      const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
      const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
      SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
    }
    let { A, B, C, D, E, F, G, H } = this;
    for (let i = 0; i < 64; i++) {
      const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
      const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
      const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
      const T2 = sigma0 + Maj(A, B, C) | 0;
      H = G;
      G = F;
      F = E;
      E = D + T1 | 0;
      D = C;
      C = B;
      B = A;
      A = T1 + T2 | 0;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    F = F + this.F | 0;
    G = G + this.G | 0;
    H = H + this.H | 0;
    this.set(A, B, C, D, E, F, G, H);
  }
  roundClean() {
    clean(SHA256_W);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    clean(this.buffer);
  }
};
var sha2562 = /* @__PURE__ */ createHasher(() => new SHA256());

// node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes/esm/sha256.js
var sha2563 = sha2562;

// packages/canonical/src/sync-hash.ts
function sha256Sync(bytes3) {
  return sha2563(bytes3);
}

// packages/protocol/src/errors.ts
var ProtocolError = class extends Error {
  code;
  details;
  constructor(code, message, details) {
    super(message);
    this.name = "ProtocolError";
    this.code = code;
    this.details = details;
  }
  toJSON() {
    return this.details === void 0 ? { name: this.name, code: this.code, message: this.message } : { name: this.name, code: this.code, message: this.message, details: this.details };
  }
};
function protocolInvariant(condition, code, message, details) {
  if (!condition) throw new ProtocolError(code, message, details);
}

// packages/protocol/src/bytes.ts
function wrap(operation) {
  try {
    return operation();
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
    throw error;
  }
}
function utf82(value) {
  return wrap(() => utf8(value));
}
function bytesToHex2(value) {
  return bytesToHex(value);
}

// packages/protocol/src/cbor.ts
function sharedLimits(limits) {
  return {
    maxBytes: limits.maxBytes ?? DEFAULT_DECODE_LIMITS.maxBytes,
    maxDepth: limits.maxDepth ?? DEFAULT_DECODE_LIMITS.maxDepth,
    maxArrayItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxArrayItems,
    maxMapItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxMapItems,
    maxTextBytes: limits.maxTextBytes ?? DEFAULT_DECODE_LIMITS.maxTextBytes,
    maxBlobBytes: limits.maxByteStringBytes ?? DEFAULT_DECODE_LIMITS.maxBlobBytes
  };
}
function protocolError(error) {
  if (error instanceof ProtocolError) throw error;
  if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
  throw error;
}
function assertCanonicalCbor2(input, limits = {}) {
  try {
    return assertCanonicalCbor(input, sharedLimits(limits));
  } catch (error) {
    return protocolError(error);
  }
}

// packages/protocol/src/schema.ts
function integerMap(entries) {
  const result = /* @__PURE__ */ new Map();
  for (const [key, value] of entries) {
    if (value !== void 0) result.set(BigInt(key), value);
  }
  return result;
}
function expectMap(value, name2) {
  protocolInvariant(value instanceof Map, "SCHEMA_INVALID", `${name2} must be a CBOR map`);
  return value;
}
function expectArray(value, name2) {
  protocolInvariant(Array.isArray(value), "SCHEMA_INVALID", `${name2} must be a CBOR array`);
  return value;
}
function expectBytes(value, name2, length) {
  protocolInvariant(value instanceof Uint8Array, "SCHEMA_INVALID", `${name2} must be bytes`);
  if (length !== void 0) {
    protocolInvariant(value.length === length, "SCHEMA_INVALID", `${name2} must contain ${length} bytes`);
  }
  return value;
}
function expectString(value, name2) {
  protocolInvariant(typeof value === "string", "SCHEMA_INVALID", `${name2} must be text`);
  return value;
}
function expectBigint(value, name2) {
  protocolInvariant(typeof value === "bigint", "SCHEMA_INVALID", `${name2} must be an integer`);
  return value;
}
function expectUint64(value, name2) {
  const integer = expectBigint(value, name2);
  protocolInvariant(integer >= 0n && integer <= (1n << 64n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside uint64 range`);
  return integer;
}
function expectInt64(value, name2) {
  const integer = expectBigint(value, name2);
  protocolInvariant(integer >= -(1n << 63n) && integer <= (1n << 63n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside int64 range`);
  return integer;
}
function required(map, key, name2) {
  const value = map.get(BigInt(key));
  if (value === void 0) throw new ProtocolError("SCHEMA_INVALID", `Missing required field ${name2}`, { field: name2 });
  return value;
}
function optional(map, key) {
  return map.get(BigInt(key));
}
function assertKnownIntegerKeys(map, knownKeys, name2) {
  const known = new Set(knownKeys.map(BigInt));
  for (const key of map.keys()) {
    protocolInvariant(typeof key === "bigint", "SCHEMA_INVALID", `${name2} contains a non-integer field key`);
    protocolInvariant(known.has(key), "SCHEMA_INVALID", `${name2} contains unknown critical field ${String(key)}`);
  }
}
function expectVersion(map, expected, name2) {
  const version2 = expectUint64(required(map, 0, `${name2}.version`), `${name2}.version`);
  protocolInvariant(version2 === expected, "UNSUPPORTED_VERSION", `Unsupported ${name2} version`, { version: version2.toString() });
}

// packages/protocol/src/sql.ts
var MIN_INT64 = -(1n << 63n);
var MAX_INT64 = (1n << 63n) - 1n;
var sqlValue = Object.freeze({
  null: () => ({ kind: "null" }),
  integer: (value) => {
    const integer = typeof value === "bigint" ? value : BigInt(value);
    protocolInvariant(integer >= MIN_INT64 && integer <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
    return { kind: "integer", value: integer };
  },
  real: (value) => {
    protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "SQL REAL must be finite");
    return { kind: "real", value };
  },
  text: (value) => {
    utf82(value);
    return { kind: "text", value };
  },
  blob: (value) => ({ kind: "blob", value: Uint8Array.from(value) })
});
function toSqlValue(value) {
  if (value === null || value === void 0) return sqlValue.null();
  if (typeof value === "bigint") return sqlValue.integer(value);
  if (typeof value === "number") return Number.isSafeInteger(value) ? sqlValue.integer(value) : sqlValue.real(value);
  if (typeof value === "boolean") return sqlValue.integer(value ? 1n : 0n);
  if (typeof value === "string") return sqlValue.text(value);
  if (value instanceof Uint8Array) return sqlValue.blob(value);
  if (isSqlValue(value)) return value;
  throw new TypeError("SQL values must be null, boolean, bigint, number, string, Uint8Array or a tagged SqlValue");
}
function isSqlValue(value) {
  if (typeof value !== "object" || value === null || !("kind" in value)) return false;
  const tagged = value;
  switch (tagged.kind) {
    case "null":
      return true;
    case "integer":
      return typeof tagged.value === "bigint";
    case "real":
      return typeof tagged.value === "number";
    case "text":
      return typeof tagged.value === "string";
    case "blob":
      return tagged.value instanceof Uint8Array;
    default:
      return false;
  }
}
function realBits(value) {
  const bits = new Uint8Array(8);
  new DataView(bits.buffer).setFloat64(0, value, false);
  return bits;
}
function sqlValueToCanonicalCbor(value) {
  switch (value.kind) {
    case "null":
      return [0n];
    case "integer":
      protocolInvariant(value.value >= MIN_INT64 && value.value <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
      return [1n, value.value];
    case "real":
      protocolInvariant(Number.isFinite(value.value), "SCHEMA_INVALID", "SQL REAL must be finite");
      return [2n, realBits(value.value)];
    case "text":
      utf82(value.value);
      return [3n, value.value];
    case "blob":
      return [4n, Uint8Array.from(value.value)];
  }
}
function sqlValueFromCanonicalCbor(value, name2 = "sql_value") {
  const tuple = expectArray(value, name2);
  const kind = expectUint64(tuple[0] ?? null, `${name2}.kind`);
  protocolInvariant(tuple.length === (kind === 0n ? 1 : 2), "SCHEMA_INVALID", `${name2} has invalid arity`);
  switch (kind) {
    case 0n:
      return { kind: "null" };
    case 1n:
      return { kind: "integer", value: expectInt64(tuple[1] ?? null, `${name2}.integer`) };
    case 2n: {
      const bits = expectBytes(tuple[1] ?? null, `${name2}.real`, 8);
      const real = new DataView(bits.buffer, bits.byteOffset, 8).getFloat64(0, false);
      protocolInvariant(Number.isFinite(real), "SCHEMA_INVALID", `${name2}.real must be finite`);
      return { kind: "real", value: real };
    }
    case 3n:
      return { kind: "text", value: expectString(tuple[1] ?? null, `${name2}.text`) };
    case 4n:
      return { kind: "blob", value: Uint8Array.from(expectBytes(tuple[1] ?? null, `${name2}.blob`)) };
    default:
      protocolInvariant(false, "SCHEMA_INVALID", `${name2} has unknown kind`);
  }
}
var DEFAULT_EXECUTION_LIMITS = Object.freeze({
  maxSqlBytes: 1e6,
  maxVmSteps: 1e6,
  maxValueBytes: 16 * 1024 * 1024
});

// packages/protocol/src/sealed.ts
var MAX_SEALED_READERS = 256;
var MAX_SEALED_NAME_BYTES = 128;
var MAX_SEALED_ROW_KEY_VALUES = 64;
var MAX_SEALED_PLAINTEXT_BYTES = 1024 * 1024;
var MAX_SEALED_ENVELOPE_BYTES = MAX_SEALED_PLAINTEXT_BYTES + MAX_SEALED_READERS * 192 + 1024;
var MAX_SEALED_VERSION = (1n << 63n) - 1n;
var SEALED_OP_CODES = Object.freeze({
  register_reader_key: 64n,
  reader_policy: 65n,
  sealed_put: 66n
});
function isSealedPlatformOp(value) {
  return typeof value === "object" && value !== null && "op" in value && typeof value.op === "string" && Object.hasOwn(SEALED_OP_CODES, value.op);
}
var sealedOp = Object.freeze({
  registerReaderKey: (publicKey) => checked({ op: "register_reader_key", publicKey: id(publicKey, "register_reader_key.public_key") }),
  readerPolicy: (input) => checked({
    op: "reader_policy",
    table: input.table,
    rowKey: input.rowKey.map(toSqlValue),
    expectedVersion: input.expectedVersion,
    ...input.expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(input.expectedPolicyId, "reader_policy.expected_policy_id") },
    readers: input.readers.map((reader) => id(reader, "reader_policy.reader")).sort(compareBytes)
  }),
  put: (input) => checked({
    op: "sealed_put",
    policyId: id(input.policyId, "sealed_put.policy_id"),
    expectedPolicyVersion: input.expectedPolicyVersion,
    expectedDataVersion: input.expectedDataVersion,
    slot: input.slot,
    envelope: decodeSealedEnvelope(encodeSealedEnvelope(input.envelope))
  })
});
function checked(op) {
  return sealedPlatformOpFromCanonicalCbor(sealedPlatformOpToCanonicalCbor(op));
}
function id(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === 32, "SCHEMA_INVALID", `${field} must contain 32 bytes`);
  return Uint8Array.from(value);
}
function name(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0 && !value.includes("\0"), "SCHEMA_INVALID", `${field} must be nonempty text without U+0000`);
  protocolInvariant(utf82(value).length <= MAX_SEALED_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function version(value, field, minimum = 1n, maximum = MAX_SEALED_VERSION) {
  const parsed = expectUint64(value, field);
  protocolInvariant(parsed >= minimum && parsed <= maximum, "INTEGER_OUT_OF_RANGE", `${field} is outside the supported version range`);
  return parsed;
}
var isList = (value) => Array.isArray(value);
function orderedReaders(readers, field) {
  protocolInvariant(isList(readers) && readers.length <= MAX_SEALED_READERS, "SCHEMA_INVALID", `${field} has too many readers or is not an array`);
  return readers.map((reader, index) => {
    const key = id(reader, field);
    if (index > 0) protocolInvariant(compareBytes(readers[index - 1], reader) < 0, "SCHEMA_INVALID", `${field} must be sorted and unique`);
    return key;
  });
}
function sealedContextToCanonicalCbor(value) {
  return integerMap([
    [0, 1n],
    [1, id(value.groupId, "sealed_context.group_id")],
    [2, id(value.policyId, "sealed_context.policy_id")],
    [3, version(value.policyVersion, "sealed_context.policy_version")],
    [4, name(value.slot, "sealed_context.slot")],
    [5, version(value.dataVersion, "sealed_context.data_version")]
  ]);
}
function sealedContextFromCanonicalCbor(value) {
  const map = expectMap(value, "sealed_context");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], "sealed_context");
  expectVersion(map, 1n, "sealed_context");
  const context = {
    groupId: id(expectBytes(required(map, 1, "group_id"), "group_id", 32), "group_id"),
    policyId: id(expectBytes(required(map, 2, "policy_id"), "policy_id", 32), "policy_id"),
    policyVersion: expectUint64(required(map, 3, "policy_version"), "policy_version"),
    slot: expectString(required(map, 4, "slot"), "slot"),
    dataVersion: expectUint64(required(map, 5, "data_version"), "data_version")
  };
  sealedContextToCanonicalCbor(context);
  return context;
}
function sealedEnvelopeToCanonicalCbor(value) {
  protocolInvariant(value.nonce instanceof Uint8Array && value.nonce.length === 12, "SCHEMA_INVALID", "sealed_envelope.nonce must contain 12 bytes");
  protocolInvariant(
    value.ciphertext instanceof Uint8Array && value.ciphertext.length >= 16 && value.ciphertext.length <= MAX_SEALED_PLAINTEXT_BYTES + 16,
    "SCHEMA_INVALID",
    "sealed_envelope.ciphertext has an invalid length"
  );
  protocolInvariant(isList(value.wraps), "SCHEMA_INVALID", "sealed_envelope.wraps must be an array");
  orderedReaders(value.wraps.map((wrap2) => wrap2.readerId), "sealed_envelope.wraps");
  return integerMap([
    [0, 1n],
    [1, sealedContextToCanonicalCbor(value.context)],
    [2, Uint8Array.from(value.nonce)],
    [3, Uint8Array.from(value.ciphertext)],
    [4, value.wraps.map((wrap2) => {
      protocolInvariant(wrap2.ciphertext instanceof Uint8Array && wrap2.ciphertext.length === 48, "SCHEMA_INVALID", "sealed_wrap.ciphertext must contain 48 bytes");
      return [
        id(wrap2.readerId, "sealed_wrap.reader_id"),
        id(wrap2.publicKey, "sealed_wrap.public_key"),
        id(wrap2.encapsulatedKey, "sealed_wrap.encapsulated_key"),
        Uint8Array.from(wrap2.ciphertext)
      ];
    })]
  ]);
}
function sealedEnvelopeFromCanonicalCbor(value) {
  const map = expectMap(value, "sealed_envelope");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4], "sealed_envelope");
  expectVersion(map, 1n, "sealed_envelope");
  const envelope = {
    context: sealedContextFromCanonicalCbor(required(map, 1, "context")),
    nonce: Uint8Array.from(expectBytes(required(map, 2, "nonce"), "nonce", 12)),
    ciphertext: Uint8Array.from(expectBytes(required(map, 3, "ciphertext"), "ciphertext")),
    wraps: expectArray(required(map, 4, "wraps"), "wraps").map((entry) => {
      const fields = expectArray(entry, "sealed_wrap");
      protocolInvariant(fields.length === 4, "SCHEMA_INVALID", "sealed_wrap must contain four fields");
      return {
        readerId: id(expectBytes(fields[0], "reader_id", 32), "reader_id"),
        publicKey: id(expectBytes(fields[1], "public_key", 32), "public_key"),
        encapsulatedKey: id(expectBytes(fields[2], "encapsulated_key", 32), "encapsulated_key"),
        ciphertext: Uint8Array.from(expectBytes(fields[3], "wrapped_key", 48))
      };
    })
  };
  sealedEnvelopeToCanonicalCbor(envelope);
  return envelope;
}
function encodeSealedEnvelope(envelope) {
  return encodeCanonicalCbor(sealedEnvelopeToCanonicalCbor(envelope));
}
function decodeSealedEnvelope(bytes3) {
  protocolInvariant(bytes3.length <= MAX_SEALED_ENVELOPE_BYTES, "SCHEMA_INVALID", "sealed_envelope exceeds the encoded size limit");
  return sealedEnvelopeFromCanonicalCbor(assertCanonicalCbor2(bytes3));
}
function sealedPlatformOpToCanonicalCbor(op) {
  protocolInvariant(isSealedPlatformOp(op), "SCHEMA_INVALID", "Unknown sealed operation");
  const entries = [[0, SEALED_OP_CODES[op.op]]];
  switch (op.op) {
    case "register_reader_key":
      entries.push([1, id(op.publicKey, "register_reader_key.public_key")]);
      break;
    case "reader_policy": {
      const expected = version(op.expectedVersion, "reader_policy.expected_version", 0n, MAX_SEALED_VERSION - 1n);
      protocolInvariant(expected === 0n === (op.expectedPolicyId === void 0), "SCHEMA_INVALID", "reader_policy creation uses version 0 without an id; replacement requires an id and positive version");
      protocolInvariant(isList(op.rowKey) && op.rowKey.length >= 1 && op.rowKey.length <= MAX_SEALED_ROW_KEY_VALUES, "SCHEMA_INVALID", "reader_policy.row_key has an invalid length");
      entries.push(
        [1, name(op.table, "reader_policy.table")],
        [2, op.rowKey.map(sqlValueToCanonicalCbor)],
        [3, op.expectedPolicyId === void 0 ? void 0 : id(op.expectedPolicyId, "reader_policy.expected_policy_id")],
        [4, expected],
        [5, orderedReaders(op.readers, "reader_policy.readers")]
      );
      break;
    }
    case "sealed_put": {
      const policyId = id(op.policyId, "sealed_put.policy_id");
      const policyVersion = version(op.expectedPolicyVersion, "sealed_put.expected_policy_version");
      const dataVersion = version(op.expectedDataVersion, "sealed_put.expected_data_version", 0n, MAX_SEALED_VERSION - 1n);
      const slot = name(op.slot, "sealed_put.slot");
      const envelope = sealedEnvelopeToCanonicalCbor(op.envelope);
      protocolInvariant(
        equalBytes(op.envelope.context.policyId, policyId) && op.envelope.context.policyVersion === policyVersion && op.envelope.context.slot === slot && op.envelope.context.dataVersion === dataVersion + 1n,
        "SCHEMA_INVALID",
        "sealed_put envelope does not match its policy, slot or next data version"
      );
      entries.push([1, policyId], [2, policyVersion], [3, dataVersion], [4, slot], [5, envelope]);
      break;
    }
  }
  return integerMap(entries);
}
function sealedPlatformOpFromCanonicalCbor(value, field = "sealed_op") {
  const map = expectMap(value, field);
  const code = expectUint64(required(map, 0, `${field}.op`), `${field}.op`);
  let op;
  if (code === SEALED_OP_CODES.register_reader_key) {
    assertKnownIntegerKeys(map, [0, 1], field);
    op = { op: "register_reader_key", publicKey: id(expectBytes(required(map, 1, "public_key"), "public_key", 32), "public_key") };
  } else if (code === SEALED_OP_CODES.reader_policy) {
    assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], field);
    const expectedPolicyId = optional(map, 3);
    op = {
      op: "reader_policy",
      table: expectString(required(map, 1, "table"), "table"),
      rowKey: expectArray(required(map, 2, "row_key"), "row_key").map((item, index) => sqlValueFromCanonicalCbor(item, `row_key[${index}]`)),
      ...expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(expectBytes(expectedPolicyId, "expected_policy_id", 32), "expected_policy_id") },
      expectedVersion: expectUint64(required(map, 4, "expected_version"), "expected_version"),
      readers: expectArray(required(map, 5, "readers"), "readers").map((reader) => id(expectBytes(reader, "reader", 32), "reader"))
    };
  } else if (code === SEALED_OP_CODES.sealed_put) {
    assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], field);
    op = {
      op: "sealed_put",
      policyId: id(expectBytes(required(map, 1, "policy_id"), "policy_id", 32), "policy_id"),
      expectedPolicyVersion: expectUint64(required(map, 2, "expected_policy_version"), "expected_policy_version"),
      expectedDataVersion: expectUint64(required(map, 3, "expected_data_version"), "expected_data_version"),
      slot: expectString(required(map, 4, "slot"), "slot"),
      envelope: sealedEnvelopeFromCanonicalCbor(required(map, 5, "envelope"))
    };
  } else {
    protocolInvariant(false, "SCHEMA_INVALID", `${field} has an unknown sealed operation`);
  }
  sealedPlatformOpToCanonicalCbor(op);
  return op;
}

// packages/protocol/src/platform.ts
var PLATFORM_ID_BYTES = 32;
var MAX_PLATFORM_NAME_BYTES = 128;
var MAX_PLATFORM_LIST_ENTRIES = 256;
var MAX_ROW_KEY_VALUES = 64;
var MAX_SEED_ROWS = 1e4;
var GROUP_COLLECTIVE_ID = new Uint8Array(PLATFORM_ID_BYTES);
var OP_CODES = [
  "grant",
  "revoke_grant",
  "create_collective",
  "accept_membership",
  "leave",
  "set_members",
  "transfer_offer",
  "transfer_accept",
  "seed_rows",
  "end_seeding",
  "transfer_cancel"
];
var OPERATION_BITS = { insert: 1n, update: 2n, delete: 4n };
var GRANT_OPERATIONS = ["insert", "update", "delete"];
var bytes = (value) => Uint8Array.from(value);
var rowKey = (values) => values.map(toSqlValue);
var platformOp = Object.freeze({
  ...sealedOp,
  grant: (input) => checked2({
    op: "grant",
    table: input.table,
    grantee: bytes(input.grantee),
    operations: [...input.operations],
    ...input.grantor === void 0 ? {} : { grantor: bytes(input.grantor) },
    ...input.rowKey === void 0 ? {} : { rowKey: rowKey(input.rowKey) },
    ...input.columns === void 0 ? {} : { columns: [...input.columns] }
  }),
  revokeGrant: (grantId) => checked2({ op: "revoke_grant", grantId: bytes(grantId) }),
  createCollective: (input) => checked2({ op: "create_collective", governance: { ...input.governance }, invitees: (input.invitees ?? []).map(bytes) }),
  acceptMembership: (collectiveId) => checked2({ op: "accept_membership", collectiveId: bytes(collectiveId) }),
  leave: (collectiveId) => checked2({ op: "leave", collectiveId: bytes(collectiveId) }),
  setMembers: (collectiveId, changes) => checked2({
    op: "set_members",
    collectiveId: bytes(collectiveId),
    changes: changes.map((change) => ({ member: bytes(change.member), role: change.role }))
  }),
  transferRow: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "row", table: input.table, rowKey: rowKey(input.rowKey) },
    toOwner: bytes(input.toOwner),
    carry: input.carry ?? false,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  transferAll: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "all" },
    toOwner: bytes(input.toOwner),
    carry: true,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  acceptTransfer: (offerId) => checked2({ op: "transfer_accept", offerId: bytes(offerId) }),
  cancelTransfer: (offerId) => checked2({ op: "transfer_cancel", offerId: bytes(offerId) }),
  seedRows: (table, columns, rows) => checked2({ op: "seed_rows", table, columns: [...columns], rows: rows.map(rowKey) }),
  endSeeding: () => checked2({ op: "end_seeding" })
});
function checked2(op) {
  platformOpToCanonicalCbor(op);
  return op;
}
function nameToCbor(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0, "SCHEMA_INVALID", `${field} cannot be empty`);
  protocolInvariant(!value.includes("\0"), "SCHEMA_INVALID", `${field} cannot contain U+0000`);
  protocolInvariant(utf82(value).length <= MAX_PLATFORM_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function idToCbor(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === PLATFORM_ID_BYTES, "SCHEMA_INVALID", `${field} must contain ${PLATFORM_ID_BYTES} bytes`);
  return Uint8Array.from(value);
}
function listToCbor(values, field, encode2, minimum = 0) {
  protocolInvariant(isList2(values), "SCHEMA_INVALID", `${field} must be a list`);
  protocolInvariant(values.length >= minimum && values.length <= MAX_PLATFORM_LIST_ENTRIES, "SCHEMA_INVALID", `${field} has an invalid number of entries`);
  return values.map(encode2);
}
function uniqueBy(values, key, field) {
  const seen = /* @__PURE__ */ new Set();
  for (const value of values) {
    const entry = key(value);
    protocolInvariant(!seen.has(entry), "SCHEMA_INVALID", `${field} contains a duplicate`);
    seen.add(entry);
  }
}
var hex = (value) => bytesToHex2(value);
var isList2 = (value) => Array.isArray(value);
function rowKeyToCbor(values, field) {
  protocolInvariant(isList2(values) && values.length >= 1 && values.length <= MAX_ROW_KEY_VALUES, "SCHEMA_INVALID", `${field} must have 1 to ${MAX_ROW_KEY_VALUES} values`);
  return values.map(sqlValueToCanonicalCbor);
}
function roleCode(role, field) {
  protocolInvariant(role === "member" || role === "admin", "SCHEMA_INVALID", `${field} must be member or admin`);
  return role === "member" ? 0n : 1n;
}
function platformOpToCanonicalCbor(op) {
  if (isSealedPlatformOp(op)) return sealedPlatformOpToCanonicalCbor(op);
  const code = OP_CODES.indexOf(op.op);
  protocolInvariant(code >= 0, "SCHEMA_INVALID", "Unknown platform operation");
  const entries = [[0, BigInt(code)]];
  switch (op.op) {
    case "grant": {
      protocolInvariant(isList2(op.operations) && op.operations.length > 0, "SCHEMA_INVALID", "grant.operations cannot be empty");
      uniqueBy(op.operations, (value) => value, "grant.operations");
      let mask = 0n;
      for (const operation of op.operations) {
        protocolInvariant(GRANT_OPERATIONS.includes(operation), "SCHEMA_INVALID", "grant.operations has an unknown operation");
        mask |= OPERATION_BITS[operation];
      }
      protocolInvariant(
        GRANT_OPERATIONS.filter((operation) => op.operations.includes(operation)).every((operation, index) => op.operations[index] === operation),
        "SCHEMA_INVALID",
        "grant.operations must be in insert, update, delete order"
      );
      if (op.columns !== void 0) uniqueBy(op.columns, (value) => value, "grant.columns");
      entries.push(
        [1, nameToCbor(op.table, "grant.table")],
        [2, idToCbor(op.grantee, "grant.grantee")],
        [3, mask],
        [4, op.grantor === void 0 ? void 0 : idToCbor(op.grantor, "grant.grantor")],
        [5, op.rowKey === void 0 ? void 0 : rowKeyToCbor(op.rowKey, "grant.row_key")],
        [6, op.columns === void 0 ? void 0 : listToCbor(op.columns, "grant.columns", (column) => nameToCbor(column, "grant.columns"), 1)]
      );
      break;
    }
    case "revoke_grant":
      entries.push([1, idToCbor(op.grantId, "revoke_grant.grant_id")]);
      break;
    case "create_collective":
      uniqueBy(op.invitees, hex, "create_collective.invitees");
      entries.push(
        [1, integerMap([
          [0, roleCode(op.governance.insert, "governance.insert")],
          [1, roleCode(op.governance.update, "governance.update")],
          [2, roleCode(op.governance.delete, "governance.delete")]
        ])],
        [2, listToCbor(op.invitees, "create_collective.invitees", (key) => idToCbor(key, "create_collective.invitees"))]
      );
      break;
    case "accept_membership":
    case "leave":
      entries.push([1, idToCbor(op.collectiveId, `${op.op}.collective_id`)]);
      break;
    case "set_members":
      uniqueBy(op.changes, (change) => hex(change.member), "set_members.changes");
      entries.push(
        [1, idToCbor(op.collectiveId, "set_members.collective_id")],
        [2, listToCbor(op.changes, "set_members.changes", (change) => [
          idToCbor(change.member, "set_members.member"),
          change.role === "remove" ? 2n : roleCode(change.role, "set_members.role")
        ], 1)]
      );
      break;
    case "transfer_offer": {
      protocolInvariant(typeof op.carry === "boolean", "SCHEMA_INVALID", "transfer_offer.carry must be a boolean");
      let scope;
      if (op.scope.kind === "all") {
        protocolInvariant(op.carry, "SCHEMA_INVALID", "A transfer of all rows always carries dependents");
        scope = [1n];
      } else {
        protocolInvariant(op.scope.kind === "row", "SCHEMA_INVALID", "transfer_offer.scope is unknown");
        scope = [0n, nameToCbor(op.scope.table, "transfer_offer.table"), rowKeyToCbor(op.scope.rowKey, "transfer_offer.row_key")];
      }
      entries.push(
        [1, scope],
        [2, op.fromOwner === void 0 ? void 0 : idToCbor(op.fromOwner, "transfer_offer.from_owner")],
        [3, idToCbor(op.toOwner, "transfer_offer.to_owner")],
        [4, op.carry ? 1n : 0n]
      );
      break;
    }
    case "transfer_accept":
    case "transfer_cancel":
      entries.push([1, idToCbor(op.offerId, `${op.op}.offer_id`)]);
      break;
    case "seed_rows": {
      uniqueBy(op.columns, (value) => value.toLowerCase(), "seed_rows.columns");
      protocolInvariant(isList2(op.rows) && op.rows.length >= 1 && op.rows.length <= MAX_SEED_ROWS, "SCHEMA_INVALID", "seed_rows.rows has an invalid number of rows");
      entries.push(
        [1, nameToCbor(op.table, "seed_rows.table")],
        [2, listToCbor(op.columns, "seed_rows.columns", (column) => nameToCbor(column, "seed_rows.columns"), 1)],
        [3, op.rows.map((row) => {
          protocolInvariant(isList2(row) && row.length === op.columns.length, "SCHEMA_INVALID", "seed_rows row width must match its columns");
          return row.map(sqlValueToCanonicalCbor);
        })]
      );
      break;
    }
    case "end_seeding":
      break;
  }
  return integerMap(entries);
}

// packages/protocol/src/program.ts
var MAX_TOPIC_BYTES = 128;
function assertEventTopic(topic) {
  protocolInvariant(
    typeof topic === "string" && /^[A-Za-z0-9][A-Za-z0-9._/-]*$/u.test(topic) && utf82(topic).length <= MAX_TOPIC_BYTES,
    "SCHEMA_INVALID",
    "Event topic must be a bounded application label"
  );
}

// packages/protocol/src/messages.ts
var MESSAGE_TYPES = ["candidate", "attestation", "heartbeat", "capability", null, "epoch-manifest", "proof-bundle", "snapshot"];
function encodeEnvelope(value) {
  const messageIndex = MESSAGE_TYPES.indexOf(value.messageType);
  protocolInvariant(messageIndex >= 0, "SCHEMA_INVALID", "Unknown envelope message type");
  return encodeCanonicalCbor(integerMap([[0, 1n], [1, value.groupRoute], [2, BigInt(messageIndex)], [3, value.encryptionEpoch], [4, value.payload]]));
}
function decodeEnvelope(bytes3) {
  const map = expectMap(assertCanonicalCbor2(bytes3), "envelope");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4], "envelope");
  expectVersion(map, 1n, "envelope");
  const typeIndex = expectUint64(required(map, 2, "envelope.message_type"), "envelope.message_type");
  protocolInvariant(typeIndex < BigInt(MESSAGE_TYPES.length), "SCHEMA_INVALID", "Unknown envelope message type");
  const messageType = MESSAGE_TYPES[Number(typeIndex)];
  protocolInvariant(messageType !== void 0 && messageType !== null, "SCHEMA_INVALID", "Unknown envelope message type");
  const epoch = required(map, 3, "envelope.encryption_epoch");
  protocolInvariant(epoch === null || epoch instanceof Uint8Array, "SCHEMA_INVALID", "Envelope encryption epoch must be null or bytes");
  return { groupRoute: expectBytes(required(map, 1, "envelope.group_route"), "envelope.group_route"), messageType, encryptionEpoch: epoch, payload: expectBytes(required(map, 4, "envelope.payload"), "envelope.payload") };
}

// packages/protocol/src/primitives.ts
var DOMAINS = {
  transaction: "chronolog/transaction-core/v1",
  transactionDigest: "chronolog/transaction-digest/v1",
  attestation: "chronolog/transaction-attestation/v1",
  heartbeat: "chronolog/validator-heartbeat/v1",
  envelope: "chronolog/envelope/v1",
  canonicalResult: "chronolog/sql-result/v1",
  genesis: "chronolog/genesis/v2",
  capabilityRevision: "chronolog/capability-revision/v1",
  capabilityGrant: "chronolog/capability-grant/v1",
  validationPolicy: "chronolog/validation-policy/v1",
  capabilitySnapshot: "chronolog/capability-snapshot/v1",
  enrollmentRequest: "chronolog/enrollment-request/v1",
  enrollmentApproval: "chronolog/enrollment-approval/v1",
  publisherRequest: "chronolog/publisher-request/v1",
  publisherApproval: "chronolog/publisher-approval/v1",
  governanceClosure: "chronolog/governance-closure/v1",
  snapshotManifest: "chronolog/snapshot-manifest/v1",
  materializedLog: "chronolog/materialized-log/v1",
  epochManifest: "chronolog/epoch-manifest/v1",
  epochWrap: "chronolog/epoch-wrap/v1",
  epochPayload: "chronolog/epoch-payload/v1",
  drillEvidence: "chronolog/drill-evidence/v1"
};
function domainSeparatedBytes2(domain, payload) {
  return concatBytes(utf82(domain), Uint8Array.of(0), payload);
}
async function hashDomain2(domain, payload) {
  return sha256(domainSeparatedBytes2(domain, payload));
}
var ED25519 = { name: "Ed25519" };
function bufferSource2(value) {
  return Uint8Array.from(value).buffer;
}
async function generateEd25519KeyPair(extractable = true) {
  const pair = await globalThis.crypto.subtle.generateKey(ED25519, extractable, ["sign", "verify"]);
  const publicKeyBytes = new Uint8Array(await globalThis.crypto.subtle.exportKey("raw", pair.publicKey));
  return { publicKey: pair.publicKey, privateKey: pair.privateKey, publicKeyBytes };
}
async function importEd25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "Ed25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", bufferSource2(raw), ED25519, true, ["verify"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 public key");
  }
}
async function importEd25519PrivateKey(pkcs8, extractable = true) {
  try {
    return await globalThis.crypto.subtle.importKey("pkcs8", bufferSource2(pkcs8), ED25519, extractable, ["sign"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 private key");
  }
}
async function exportEd25519PrivateKey(privateKey) {
  try {
    return new Uint8Array(await globalThis.crypto.subtle.exportKey("pkcs8", privateKey));
  } catch {
    throw new ProtocolError("INVALID_KEY", "Ed25519 private key is not extractable");
  }
}
async function signDomain(domain, payload, privateKey) {
  try {
    const signature = await globalThis.crypto.subtle.sign(ED25519, privateKey, bufferSource2(domainSeparatedBytes2(domain, payload)));
    return new Uint8Array(signature);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to sign with Ed25519 key");
  }
}
async function verifyDomain(domain, payload, signature, publicKey) {
  if (signature.length !== 64) return false;
  try {
    const key = publicKey instanceof Uint8Array ? await importEd25519PublicKey(publicKey) : publicKey;
    return await globalThis.crypto.subtle.verify(
      ED25519,
      key,
      bufferSource2(signature),
      bufferSource2(domainSeparatedBytes2(domain, payload))
    );
  } catch {
    return false;
  }
}

// packages/capabilities/src/codec.ts
var ROLES = ["reader", "writer", "validator", "administrator"];
function roleIndex(role) {
  const index = ROLES.indexOf(role);
  protocolInvariant(index >= 0, "SCHEMA_INVALID", "Unknown capability role");
  return BigInt(index);
}
function grantToCbor(grant) {
  if (grant.program !== void 0) {
    protocolInvariant(grant.role === "writer" && typeof grant.program.sql === "boolean", "SCHEMA_INVALID", "Only writer grants carry program rights");
    for (const topics of [grant.program.topics, grant.program.signals]) {
      const input = topics;
      protocolInvariant(Array.isArray(input) && topics.length <= 128 && new Set(topics).size === topics.length, "SCHEMA_INVALID", "Invalid publication scopes");
      topics.forEach((topic) => {
        if (topic !== "*") assertEventTopic(topic);
      });
    }
    protocolInvariant(grant.program.forwarded === void 0 || typeof grant.program.forwarded === "boolean", "SCHEMA_INVALID", "Invalid forwarding right");
  }
  protocolInvariant(grant.signingPublicKey.length === 32, "SCHEMA_INVALID", "Capability signing key must contain 32 bytes");
  protocolInvariant(grant.validFromRevision >= 0n, "INTEGER_OUT_OF_RANGE", "Capability revision cannot be negative");
  if (grant.role === "validator") {
    protocolInvariant(grant.minimumAuthorTimestampMs !== void 0, "SCHEMA_INVALID", "Validator capability requires a timestamp floor");
  } else {
    protocolInvariant(grant.minimumAuthorTimestampMs === void 0, "SCHEMA_INVALID", "Only validators may carry validator fields");
  }
  if (grant.role === "reader") {
    protocolInvariant(grant.hpkePublicKey !== void 0, "SCHEMA_INVALID", "Reader capability requires an HPKE key");
    protocolInvariant(grant.hpkePublicKey.length === 32, "SCHEMA_INVALID", "Reader HPKE key must contain 32 bytes");
  } else {
    protocolInvariant(grant.hpkePublicKey === void 0, "SCHEMA_INVALID", "Only readers may carry reader fields");
  }
  if (grant.transportAuthor !== void 0) {
    protocolInvariant(grant.transportAuthor.length > 0, "SCHEMA_INVALID", "Capability transport author must not be empty");
  }
  return integerMap([
    [0, grant.subjectId],
    [1, grant.signingPublicKey],
    [2, roleIndex(grant.role)],
    [3, grant.validFromRevision],
    [7, grant.minimumAuthorTimestampMs],
    [9, grant.hpkePublicKey],
    [10, grant.transportAuthor],
    [11, grant.program === void 0 ? void 0 : [grant.program.sql, [...grant.program.topics].sort(), [...grant.program.signals].sort(), grant.program.forwarded ?? false]]
  ]);
}
function grantFromCbor(value, field) {
  const map = expectMap(value, field);
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 7, 9, 10, 11], field);
  const roleValue = expectUint64(required(map, 2, `${field}.role`), `${field}.role`);
  protocolInvariant(roleValue < BigInt(ROLES.length), "SCHEMA_INVALID", `${field}.role is unknown`);
  const role = ROLES[Number(roleValue)];
  protocolInvariant(role !== void 0, "SCHEMA_INVALID", `${field}.role is unknown`);
  const floor = optional(map, 7);
  const hpkeKey = optional(map, 9);
  const transportAuthor = optional(map, 10);
  const programValue = optional(map, 11);
  const program = programValue === void 0 ? void 0 : decodeProgramRights(programValue);
  const grant = {
    subjectId: expectBytes(required(map, 0, `${field}.subject_id`), `${field}.subject_id`),
    signingPublicKey: expectBytes(required(map, 1, `${field}.signing_key`), `${field}.signing_key`, 32),
    role,
    validFromRevision: expectUint64(required(map, 3, `${field}.valid_from`), `${field}.valid_from`),
    ...program === void 0 ? {} : { program },
    ...floor === void 0 ? {} : { minimumAuthorTimestampMs: expectUint64(floor, `${field}.minimum_timestamp`) },
    ...hpkeKey === void 0 ? {} : { hpkePublicKey: expectBytes(hpkeKey, `${field}.hpke_key`, 32) },
    ...transportAuthor === void 0 ? {} : { transportAuthor: expectString(transportAuthor, `${field}.transport_author`) }
  };
  grantToCbor(grant);
  return grant;
}
function decodeProgramRights(value) {
  const tuple = expectArray(value, "grant.program");
  protocolInvariant(tuple.length === 4 && typeof tuple[0] === "boolean" && typeof tuple[3] === "boolean", "SCHEMA_INVALID", "Invalid program rights");
  const topics = (index) => expectArray(tuple[index], "grant.topics").map((topic) => expectString(topic, "grant.topic"));
  return { sql: tuple[0], topics: topics(1), signals: topics(2), forwarded: tuple[3] };
}
function policyToCbor(policy) {
  protocolInvariant(policy.minimumValidators > 0n, "SCHEMA_INVALID", "Validation threshold must be positive");
  return integerMap([[0, policy.version], [1, policy.minimumValidators]]);
}
function policyFromCbor(value, field) {
  const map = expectMap(value, field);
  assertKnownIntegerKeys(map, [0, 1], field);
  const policy = {
    version: expectUint64(required(map, 0, `${field}.version`), `${field}.version`),
    minimumValidators: expectUint64(required(map, 1, `${field}.minimum`), `${field}.minimum`)
  };
  policyToCbor(policy);
  return policy;
}
function clockToCbor(policy) {
  return integerMap([[0, policy.maxFutureSkewMs], [1, policy.cutoffLagMs], [2, policy.heartbeatIntervalMs]]);
}
function clockFromCbor(value) {
  const map = expectMap(value, "genesis.clock_policy");
  assertKnownIntegerKeys(map, [0, 1, 2], "genesis.clock_policy");
  return {
    maxFutureSkewMs: expectUint64(required(map, 0, "clock.max_future_skew"), "clock.max_future_skew"),
    cutoffLagMs: expectUint64(required(map, 1, "clock.cutoff_lag"), "clock.cutoff_lag"),
    heartbeatIntervalMs: expectUint64(required(map, 2, "clock.heartbeat_interval"), "clock.heartbeat_interval")
  };
}
function resourceToCbor(policy) {
  return integerMap([[0, policy.maxCandidateBytes], [1, policy.maxProgramNodes], [2, policy.maxPreconditions], [3, policy.maxMutations]]);
}
function resourceFromCbor(value) {
  const map = expectMap(value, "genesis.resource_policy");
  assertKnownIntegerKeys(map, [0, 1, 2, 3], "genesis.resource_policy");
  return {
    maxCandidateBytes: expectUint64(required(map, 0, "resource.max_candidate_bytes"), "resource.max_candidate_bytes"),
    maxProgramNodes: expectUint64(required(map, 1, "resource.max_program_nodes"), "resource.max_program_nodes"),
    maxPreconditions: expectUint64(required(map, 2, "resource.max_preconditions"), "resource.max_preconditions"),
    maxMutations: expectUint64(required(map, 3, "resource.max_mutations"), "resource.max_mutations")
  };
}
function genesisToCbor(value) {
  protocolInvariant(value.rootAdminPublicKey.length === 32, "SCHEMA_INVALID", "Genesis root key must contain 32 bytes");
  protocolInvariant(
    value.schemaAdminPublicKey instanceof Uint8Array && value.schemaAdminPublicKey.length === 32,
    "SCHEMA_INVALID",
    "Genesis schema administrator key must contain 32 bytes"
  );
  protocolInvariant(value.validationPolicies.length > 0, "SCHEMA_INVALID", "Genesis requires at least one validation policy");
  return integerMap([
    [0, 2n],
    [1, value.groupId],
    [2, value.schemaId],
    [3, value.rootAdminPublicKey],
    [4, value.schemaAdminPublicKey],
    [5, value.capabilityLogFeed],
    [6, value.initialCapabilities.map(grantToCbor)],
    [7, value.validationPolicies.map(policyToCbor)],
    [8, clockToCbor(value.clockPolicy)],
    [9, resourceToCbor(value.resourcePolicy)],
    [10, value.encryptionSuite],
    [11, value.createdAtMs],
    [12, value.forkedFrom === void 0 ? void 0 : integerMap([
      [0, value.forkedFrom.groupId],
      [1, value.forkedFrom.snapshotManifestSha256],
      [2, value.forkedFrom.materializedRevision]
    ])],
    [13, value.historyPolicy === void 0 ? void 0 : historyPolicyToCbor(value.historyPolicy)]
  ]);
}
function historyPolicyToCbor(value) {
  protocolInvariant(value.executionManifestDigest.length === 32, "SCHEMA_INVALID", "History requires an execution manifest digest");
  protocolInvariant(value.kind === "peer" || value.kind === "coordinated", "SCHEMA_INVALID", "Unknown history policy");
  const providerId = value.providerId ?? (value.kind === "peer" ? "peer-validators-v1" : "signed-inclusion-v1");
  protocolInvariant(/^[a-z][a-z0-9._-]{0,127}$/u.test(providerId), "SCHEMA_INVALID", "Invalid finality provider");
  const parameters = value.providerParameters ?? new Uint8Array();
  protocolInvariant(parameters instanceof Uint8Array && parameters.length <= 16384, "SCHEMA_INVALID", "Invalid finality parameters");
  if (value.kind === "coordinated") {
    protocolInvariant(typeof value.historyId === "string" && /^h_[0-9a-f]{32}$/u.test(value.historyId), "SCHEMA_INVALID", "History identity is invalid");
    protocolInvariant(value.authorityPublicKey?.length === 32, "SCHEMA_INVALID", "Authority public key is invalid");
    return [1n, value.executionManifestDigest, value.historyId, value.authorityPublicKey, providerId, parameters];
  }
  protocolInvariant(value.historyId === void 0 && value.authorityPublicKey === void 0, "SCHEMA_INVALID", "Peer policy cannot carry an authority");
  protocolInvariant(providerId === "peer-validators-v1" && parameters.length === 0, "SCHEMA_INVALID", "Unknown validator finality provider");
  return [0n, value.executionManifestDigest, providerId, parameters];
}
function historyPolicyFromCbor(value) {
  const fields = expectArray(value, "genesis.history_policy");
  if (fields[0] === 0n && fields.length === 4) return {
    kind: "peer",
    executionManifestDigest: expectBytes(fields[1], "genesis.history_policy.manifest", 32),
    providerId: expectString(fields[2], "genesis.history_policy.provider"),
    providerParameters: expectBytes(fields[3], "genesis.history_policy.parameters")
  };
  protocolInvariant(fields[0] === 1n && fields.length === 6, "SCHEMA_INVALID", "History policy is invalid");
  const policy = {
    kind: "coordinated",
    executionManifestDigest: expectBytes(fields[1], "genesis.history_policy.manifest", 32),
    historyId: expectString(fields[2], "genesis.history_policy.history"),
    authorityPublicKey: expectBytes(fields[3], "genesis.history_policy.authority", 32),
    providerId: expectString(fields[4], "genesis.history_policy.provider"),
    providerParameters: expectBytes(fields[5], "genesis.history_policy.parameters")
  };
  historyPolicyToCbor(policy);
  return policy;
}
function forkOriginFromCbor(value) {
  const map = expectMap(value, "genesis.forked_from");
  assertKnownIntegerKeys(map, [0, 1, 2], "genesis.forked_from");
  return {
    groupId: expectBytes(required(map, 0, "genesis.forked_from.group_id"), "genesis.forked_from.group_id", 32),
    snapshotManifestSha256: expectBytes(required(map, 1, "genesis.forked_from.snapshot_sha256"), "genesis.forked_from.snapshot_sha256", 32),
    materializedRevision: expectUint64(required(map, 2, "genesis.forked_from.revision"), "genesis.forked_from.revision")
  };
}
function encodeGenesisManifest(value) {
  return encodeCanonicalCbor(genesisToCbor(value));
}
function decodeGenesisManifest(bytes3) {
  const map = expectMap(assertCanonicalCbor2(bytes3), "genesis");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13], "genesis");
  expectVersion(map, 2n, "genesis");
  const forkedFrom = optional(map, 12);
  const historyPolicy = optional(map, 13);
  const manifest = {
    groupId: expectBytes(required(map, 1, "genesis.group_id"), "genesis.group_id"),
    schemaId: expectBytes(required(map, 2, "genesis.schema_id"), "genesis.schema_id"),
    rootAdminPublicKey: expectBytes(required(map, 3, "genesis.root_key"), "genesis.root_key", 32),
    schemaAdminPublicKey: expectBytes(required(map, 4, "genesis.schema_admin_key"), "genesis.schema_admin_key", 32),
    capabilityLogFeed: expectBytes(required(map, 5, "genesis.capability_feed"), "genesis.capability_feed"),
    initialCapabilities: expectArray(required(map, 6, "genesis.capabilities"), "genesis.capabilities").map((item, index) => grantFromCbor(item, `genesis.capabilities[${index}]`)),
    validationPolicies: expectArray(required(map, 7, "genesis.policies"), "genesis.policies").map((item, index) => policyFromCbor(item, `genesis.policies[${index}]`)),
    clockPolicy: clockFromCbor(required(map, 8, "genesis.clock_policy")),
    resourcePolicy: resourceFromCbor(required(map, 9, "genesis.resource_policy")),
    encryptionSuite: expectString(required(map, 10, "genesis.encryption_suite"), "genesis.encryption_suite"),
    createdAtMs: expectUint64(required(map, 11, "genesis.created_at"), "genesis.created_at"),
    ...forkedFrom === void 0 ? {} : { forkedFrom: forkOriginFromCbor(forkedFrom) },
    ...historyPolicy === void 0 ? {} : { historyPolicy: historyPolicyFromCbor(historyPolicy) }
  };
  genesisToCbor(manifest);
  return manifest;
}
function encodeSignedGenesis(value) {
  return encodeCanonicalCbor(integerMap([
    [0, 2n],
    [1, encodeGenesisManifest(value.manifest)],
    [2, value.signature]
  ]));
}
function decodeSignedGenesis(bytes3) {
  const map = expectMap(assertCanonicalCbor2(bytes3), "signed_genesis");
  assertKnownIntegerKeys(map, [0, 1, 2], "signed_genesis");
  expectVersion(map, 2n, "signed_genesis");
  return {
    manifest: decodeGenesisManifest(expectBytes(required(map, 1, "signed_genesis.manifest"), "signed_genesis.manifest")),
    signature: expectBytes(required(map, 2, "signed_genesis.signature"), "signed_genesis.signature", 64)
  };
}
function revisionToCbor(value) {
  protocolInvariant(value.revision > 0n, "SCHEMA_INVALID", "Capability revision must be positive");
  protocolInvariant(value.issuerRootPublicKey.length === 32, "SCHEMA_INVALID", "Revision issuer key must contain 32 bytes");
  protocolInvariant(value.successorRootPublicKey === void 0 === (value.successorCapabilityLogFeed === void 0), "SCHEMA_INVALID", "Root and feed succession must be declared together");
  return integerMap([
    [0, 1n],
    [1, value.groupId],
    [2, value.revision],
    [3, value.previousRevisionDigest],
    [4, value.issuerRootPublicKey],
    [5, value.grants.map(grantToCbor)],
    [6, value.revocations],
    [7, value.validationPolicies.map(policyToCbor)],
    [8, value.successorRootPublicKey],
    [9, value.successorCapabilityLogFeed]
  ]);
}
function encodeCapabilityRevision(value) {
  return encodeCanonicalCbor(revisionToCbor(value));
}
function decodeCapabilityRevision(bytes3) {
  const map = expectMap(assertCanonicalCbor2(bytes3), "capability_revision");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], "capability_revision");
  expectVersion(map, 1n, "capability_revision");
  const successorRoot = optional(map, 8);
  const successorFeed = optional(map, 9);
  const revision = {
    groupId: expectBytes(required(map, 1, "revision.group_id"), "revision.group_id"),
    revision: expectUint64(required(map, 2, "revision.number"), "revision.number"),
    previousRevisionDigest: expectBytes(required(map, 3, "revision.previous_digest"), "revision.previous_digest", 32),
    issuerRootPublicKey: expectBytes(required(map, 4, "revision.issuer"), "revision.issuer", 32),
    grants: expectArray(required(map, 5, "revision.grants"), "revision.grants").map((item, index) => grantFromCbor(item, `revision.grants[${index}]`)),
    revocations: expectArray(required(map, 6, "revision.revocations"), "revision.revocations").map((item, index) => expectBytes(item, `revision.revocations[${index}]`, 32)),
    validationPolicies: expectArray(required(map, 7, "revision.policies"), "revision.policies").map((item, index) => policyFromCbor(item, `revision.policies[${index}]`)),
    ...successorRoot === void 0 ? {} : { successorRootPublicKey: expectBytes(successorRoot, "revision.successor_root", 32) },
    ...successorFeed === void 0 ? {} : { successorCapabilityLogFeed: expectBytes(successorFeed, "revision.successor_feed") }
  };
  revisionToCbor(revision);
  return revision;
}
function encodeSignedCapabilityRevision(value) {
  return encodeCanonicalCbor(integerMap([
    [0, 1n],
    [1, encodeCapabilityRevision(value.revision)],
    [2, value.signature]
  ]));
}
function decodeSignedCapabilityRevision(bytes3) {
  const map = expectMap(assertCanonicalCbor2(bytes3), "signed_capability_revision");
  assertKnownIntegerKeys(map, [0, 1, 2], "signed_capability_revision");
  expectVersion(map, 1n, "signed_capability_revision");
  return {
    revision: decodeCapabilityRevision(expectBytes(required(map, 1, "signed_revision.payload"), "signed_revision.payload")),
    signature: expectBytes(required(map, 2, "signed_revision.signature"), "signed_revision.signature", 64)
  };
}
var capabilityCodecInternals = {
  grantToCbor,
  policyToCbor,
  genesisToCbor,
  revisionToCbor
};

// packages/capabilities/src/reducer.ts
async function capabilityId(grant) {
  return hashDomain2(DOMAINS.capabilityGrant, encodeCanonicalCbor(capabilityCodecInternals.grantToCbor(grant)));
}
async function validationPolicyId(policy) {
  return hashDomain2(DOMAINS.validationPolicy, encodeCanonicalCbor(capabilityCodecInternals.policyToCbor(policy)));
}
async function signGenesis(manifest, rootPrivateKey) {
  const bytes3 = encodeGenesisManifest(manifest);
  return { manifest, signature: await signDomain(DOMAINS.genesis, bytes3, rootPrivateKey) };
}
async function verifySignedGenesis(value) {
  return verifyDomain(DOMAINS.genesis, encodeGenesisManifest(value.manifest), value.signature, value.manifest.rootAdminPublicKey);
}
async function signCapabilityRevision(revision, rootPrivateKey) {
  return { revision, signature: await signDomain(DOMAINS.capabilityRevision, encodeCapabilityRevision(revision), rootPrivateKey) };
}
async function capabilityRevisionDigest(revision) {
  return hashDomain2(DOMAINS.capabilityRevision, encodeCapabilityRevision(revision));
}
async function genesisSnapshot(genesis) {
  protocolInvariant(await verifySignedGenesis(genesis), "INVALID_SIGNATURE", "Genesis signature is invalid");
  const manifest = decodeGenesisManifest(encodeGenesisManifest(genesis.manifest));
  const genesisDigest = await hashDomain2(DOMAINS.genesis, encodeGenesisManifest(manifest));
  const capabilities = /* @__PURE__ */ new Map();
  for (const grant of manifest.initialCapabilities) {
    protocolInvariant(grant.validFromRevision === 0n, "SCHEMA_INVALID", "Genesis capability must begin at revision zero");
    const id2 = await capabilityId(grant);
    protocolInvariant(!capabilities.has(bytesToHex2(id2)), "SCHEMA_INVALID", "Genesis contains a duplicate capability");
    capabilities.set(bytesToHex2(id2), { id: id2, grant, grantedAtRevision: 0n });
  }
  const policies = /* @__PURE__ */ new Map();
  for (const policy of manifest.validationPolicies) {
    const id2 = await validationPolicyId(policy);
    protocolInvariant(!policies.has(bytesToHex2(id2)), "SCHEMA_INVALID", "Genesis contains a duplicate policy");
    policies.set(bytesToHex2(id2), { id: id2, policy, installedAtRevision: 0n });
  }
  return {
    groupId: manifest.groupId,
    revision: 0n,
    revisionDigest: genesisDigest,
    rootAdminPublicKey: manifest.rootAdminPublicKey,
    capabilityLogFeed: manifest.capabilityLogFeed,
    capabilities,
    policies,
    validatorFloorMs: raiseValidatorFloor(0n, manifest.initialCapabilities)
  };
}
function raiseValidatorFloor(floor, grants) {
  return grants.reduce((maximum, grant) => {
    const granted = grant.role === "validator" ? grant.minimumAuthorTimestampMs ?? 0n : 0n;
    return granted > maximum ? granted : maximum;
  }, floor);
}
async function reduceCapabilityLog(genesis, inputRevisions) {
  let snapshot = await genesisSnapshot(genesis);
  const revisions = [...inputRevisions].sort((a, b) => a.revision.revision < b.revision.revision ? -1 : a.revision.revision > b.revision.revision ? 1 : 0);
  for (const signed of revisions) snapshot = await applyCapabilityRevision(snapshot, signed);
  return snapshot;
}
async function applyCapabilityRevision(snapshot, signed) {
  const revision = decodeCapabilityRevision(encodeCapabilityRevision(signed.revision));
  protocolInvariant(equalBytes(revision.groupId, snapshot.groupId), "SCHEMA_INVALID", "Capability revision belongs to another group");
  protocolInvariant(revision.revision === snapshot.revision + 1n, "SCHEMA_INVALID", "Capability log contains a gap or conflicting revision");
  protocolInvariant(equalBytes(revision.previousRevisionDigest, snapshot.revisionDigest), "DIGEST_MISMATCH", "Capability revision does not extend current chain");
  protocolInvariant(equalBytes(revision.issuerRootPublicKey, snapshot.rootAdminPublicKey), "INVALID_KEY", "Capability revision has the wrong root issuer");
  protocolInvariant(await verifyDomain(DOMAINS.capabilityRevision, encodeCapabilityRevision(revision), signed.signature, snapshot.rootAdminPublicKey), "INVALID_SIGNATURE", "Capability revision signature is invalid");
  const capabilities = new Map(snapshot.capabilities);
  for (const revokedId of revision.revocations) {
    const key = bytesToHex2(revokedId);
    const active = capabilities.get(key);
    protocolInvariant(active !== void 0, "SCHEMA_INVALID", "Capability revision revokes an unknown capability");
    protocolInvariant(active.revokedAtRevision === void 0, "SCHEMA_INVALID", "Capability is already revoked");
    capabilities.set(key, { ...active, revokedAtRevision: revision.revision });
  }
  for (const grant of revision.grants) {
    protocolInvariant(grant.validFromRevision === revision.revision, "SCHEMA_INVALID", "New capability must begin at its containing revision");
    if (grant.role === "validator") {
      protocolInvariant((grant.minimumAuthorTimestampMs ?? -1n) >= snapshot.validatorFloorMs, "SCHEMA_INVALID", "New validator would reopen closed timestamp history");
    }
    const id2 = await capabilityId(grant);
    protocolInvariant(!capabilities.has(bytesToHex2(id2)), "SCHEMA_INVALID", "Capability revision contains a duplicate grant");
    capabilities.set(bytesToHex2(id2), { id: id2, grant, grantedAtRevision: revision.revision });
  }
  const policies = new Map(snapshot.policies);
  for (const policy of revision.validationPolicies) {
    const id2 = await validationPolicyId(policy);
    protocolInvariant(!policies.has(bytesToHex2(id2)), "SCHEMA_INVALID", "Capability revision repeats an existing policy");
    policies.set(bytesToHex2(id2), { id: id2, policy, installedAtRevision: revision.revision });
  }
  const revisionDigest = await capabilityRevisionDigest(revision);
  return {
    ...snapshot,
    revision: revision.revision,
    revisionDigest,
    rootAdminPublicKey: revision.successorRootPublicKey ?? snapshot.rootAdminPublicKey,
    capabilityLogFeed: revision.successorCapabilityLogFeed ?? snapshot.capabilityLogFeed,
    capabilities,
    policies,
    validatorFloorMs: raiseValidatorFloor(snapshot.validatorFloorMs, revision.grants)
  };
}
function isCapabilityActive(capability, revision) {
  return capability.grant.validFromRevision <= revision && (capability.revokedAtRevision === void 0 || revision < capability.revokedAtRevision);
}

// packages/capabilities/src/program-rights.ts
function normalizeProgramRights(value) {
  if (value === void 0) return { sql: true, topics: [], signals: [], forwarded: false };
  if (typeof value.sql !== "boolean" || value.forwarded !== void 0 && typeof value.forwarded !== "boolean") throw new Error("PROGRAM_RIGHTS_INVALID");
  const topics = (items) => {
    const input = items;
    if (!Array.isArray(input) || items.length > 128 || new Set(items).size !== items.length) throw new Error("PROGRAM_RIGHTS_INVALID");
    items.forEach((topic) => {
      if (topic !== "*") assertEventTopic(topic);
    });
    return [...items].sort();
  };
  return { sql: value.sql, topics: topics(value.topics), signals: topics(value.signals), forwarded: value.forwarded ?? false };
}
function programRightsSubset(granted, requested) {
  const next = normalizeProgramRights(granted), allowed = normalizeProgramRights(requested);
  return (!next.sql || allowed.sql) && (!next.forwarded || allowed.forwarded) && next.topics.every((topic) => allowed.topics.includes("*") || allowed.topics.includes(topic)) && next.signals.every((topic) => allowed.signals.includes("*") || allowed.signals.includes(topic));
}

// packages/records/src/types.ts
function cloneRecord(record) {
  return {
    ...record,
    payload: record.payload.slice()
  };
}

// packages/records/src/feed-codec.ts
var RECORD_DOMAIN = utf8("chronolog/feed-record/v1\0");
var DEFAULT_MAX_RECORD_BYTES = 64 * 1024 * 1024;
var FeedRecordError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "FeedRecordError";
  }
  code;
};
function encodeBase64(bytes3) {
  let binary = "";
  for (let offset = 0; offset < bytes3.length; offset += 32768) {
    binary += String.fromCharCode(...bytes3.subarray(offset, offset + 32768));
  }
  return btoa(binary);
}
function decodeBase64(value) {
  let bytes3;
  try {
    bytes3 = Uint8Array.from(atob(value), (character) => character.charCodeAt(0));
  } catch {
    throw new FeedRecordError("FEED_BASE64_INVALID");
  }
  if (encodeBase64(bytes3) !== value) throw new FeedRecordError("FEED_BASE64_INVALID");
  return bytes3;
}
function feedIdFromPublicKey(publicKey) {
  if (publicKey.length !== 32) throw new FeedRecordError("FEED_ID_INVALID");
  return `@${encodeBase64(publicKey)}.ed25519`;
}
function publicKeyFromFeedId(feedId) {
  const match = /^@([A-Za-z0-9+/]{43}=)\.ed25519$/u.exec(feedId);
  if (match === null) throw new FeedRecordError("FEED_ID_INVALID");
  try {
    return decodeBase64(match[1]);
  } catch {
    throw new FeedRecordError("FEED_ID_INVALID");
  }
}
function feedRecordId(digest) {
  if (digest.length !== 32) throw new FeedRecordError("FEED_RECORD_ID_INVALID");
  return `%${encodeBase64(digest)}.sha256`;
}
function idHash(id2) {
  const match = /^%([A-Za-z0-9+/]{43}=)\.sha256$/u.exec(id2);
  if (match === null) throw new FeedRecordError("FEED_RECORD_ID_INVALID");
  try {
    return decodeBase64(match[1]);
  } catch {
    throw new FeedRecordError("FEED_RECORD_ID_INVALID");
  }
}
function signedFields(record) {
  if (record.sequence < 1n || record.sequence === 1n !== (record.previous === null)) {
    throw new FeedRecordError("FEED_RECORD_PREVIOUS_INVALID");
  }
  return [
    1n,
    publicKeyFromFeedId(record.author),
    record.sequence,
    record.previous === null ? null : idHash(record.previous),
    record.timestampMs,
    record.payload
  ];
}
function feedSigningBytes(record) {
  return concatBytes(RECORD_DOMAIN, encodeCanonicalCbor(signedFields(record)));
}
function encodeSignedFeedRecord(record, signature) {
  if (signature.length !== 64) throw new FeedRecordError("FEED_RECORD_SIGNATURE_INVALID");
  return encodeCanonicalCbor([signedFields(record), signature]);
}
function decodeSignedFeedRecord(raw, maxRecordBytes = DEFAULT_MAX_RECORD_BYTES) {
  if (!Number.isSafeInteger(maxRecordBytes) || maxRecordBytes < 1) throw new FeedRecordError("FEED_RECORD_LIMIT_INVALID");
  if (raw.length > maxRecordBytes) throw new FeedRecordError("FEED_RECORD_TOO_LARGE");
  let decoded;
  try {
    decoded = assertCanonicalCbor(raw, { ...DEFAULT_DECODE_LIMITS, maxBytes: maxRecordBytes, maxBlobBytes: maxRecordBytes });
  } catch {
    throw new FeedRecordError("FEED_RECORD_MALFORMED");
  }
  if (!Array.isArray(decoded) || decoded.length !== 2) throw new FeedRecordError("FEED_RECORD_MALFORMED");
  const [fields, signature] = decoded;
  if (!Array.isArray(fields) || fields.length !== 6 || !(signature instanceof Uint8Array) || signature.length !== 64) {
    throw new FeedRecordError("FEED_RECORD_MALFORMED");
  }
  const [version2, publicKey, sequence, previousHash, timestampMs, payload] = fields;
  if (version2 !== 1n || !(publicKey instanceof Uint8Array) || publicKey.length !== 32 || typeof sequence !== "bigint" || sequence < 1n || !(previousHash === null || previousHash instanceof Uint8Array && previousHash.length === 32) || typeof timestampMs !== "bigint" || !(payload instanceof Uint8Array)) {
    throw new FeedRecordError("FEED_RECORD_MALFORMED");
  }
  if (sequence === 1n !== (previousHash === null)) throw new FeedRecordError("FEED_RECORD_PREVIOUS_INVALID");
  const record = {
    author: feedIdFromPublicKey(publicKey),
    sequence,
    previous: previousHash === null ? null : feedRecordId(previousHash),
    timestampMs,
    payload: payload.slice()
  };
  return { ...record, signature: signature.slice(), signingBytes: feedSigningBytes(record), raw: raw.slice() };
}
async function createFeedRecord(signer, crypto2, sequence, previous, timestampMs, payload) {
  const fields = { author: signer.identity, sequence, previous, timestampMs, payload: payload.slice() };
  const raw = encodeSignedFeedRecord(fields, await signer.sign(feedSigningBytes(fields)));
  return verifyFeedRecord(raw, crypto2);
}
async function verifyFeedRecord(raw, crypto2, maxRecordBytes = DEFAULT_MAX_RECORD_BYTES) {
  const decoded = decodeSignedFeedRecord(raw, maxRecordBytes);
  if (!await crypto2.verify(publicKeyFromFeedId(decoded.author), decoded.signingBytes, decoded.signature)) {
    throw new FeedRecordError("FEED_RECORD_SIGNATURE_INVALID");
  }
  const { author, sequence, previous, timestampMs, payload } = decoded;
  return { id: feedRecordId(await crypto2.sha256(decoded.raw)), author, sequence, previous, timestampMs, payload, raw: decoded.raw };
}
var webFeedCrypto = {
  async sha256(bytes3) {
    return new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bytes3.slice().buffer));
  },
  async verify(publicKey, bytes3, signature) {
    const key = await globalThis.crypto.subtle.importKey("raw", publicKey.slice().buffer, "Ed25519", false, ["verify"]);
    return globalThis.crypto.subtle.verify("Ed25519", key, signature.slice().buffer, bytes3.slice().buffer);
  }
};
function webFeedSigner(identity, privateKey) {
  publicKeyFromFeedId(identity);
  return {
    identity,
    async sign(bytes3) {
      return new Uint8Array(await globalThis.crypto.subtle.sign("Ed25519", privateKey, bytes3.slice().buffer));
    }
  };
}

// packages/records/src/payload.ts
function validatePayloadHash(hash) {
  if (!/^[0-9a-f]{64}$/u.test(hash)) throw new Error("PAYLOAD_HASH_INVALID");
}
async function payloadHash(bytes3) {
  return bytesToHex(await sha256(bytes3));
}
async function verifyPayloadHash(hash, bytes3) {
  validatePayloadHash(hash);
  if (await payloadHash(bytes3) !== hash) throw new Error("PAYLOAD_HASH_MISMATCH");
}

// packages/records/src/store.ts
function classifyFeedAppend(record, head, existingId) {
  if (existingId !== void 0) return existingId === record.id ? "duplicate" : "fork";
  return record.sequence === head.sequence + 1n && record.previous === head.id ? "append" : "out_of_order";
}
function toTransportRecord(record, receivedAtMs) {
  return {
    id: record.id,
    author: record.author,
    sequence: record.sequence,
    ...record.previous === null ? {} : { previous: record.previous },
    receivedAtMs,
    payload: record.payload.slice()
  };
}
var DurableFeedStore = class _DurableFeedStore {
  #bytes;
  #crypto;
  #records = [];
  #forks = [];
  #byId = /* @__PURE__ */ new Map();
  #byAuthor = /* @__PURE__ */ new Map();
  #payloads = /* @__PURE__ */ new Map();
  #evidence = [];
  #evidenceIndex = /* @__PURE__ */ new Map();
  #pending = Promise.resolve();
  #closed = false;
  #writeFailed = false;
  #writeFailure;
  constructor(bytes3, crypto2) {
    this.#bytes = bytes3;
    this.#crypto = crypto2;
  }
  /** Explicit first setup; durable empty history precedes creation of its signer. */
  static async create(bytes3, crypto2) {
    if (await bytes3.get("feed/manifest") !== null) throw new Error("FEED_STORE_ALREADY_EXISTS");
    await bytes3.put("feed/manifest", encodeCanonicalCbor([1n, [], [], []]));
    return new _DurableFeedStore(bytes3, crypto2);
  }
  static async open(bytes3, crypto2) {
    const store = new _DurableFeedStore(bytes3, crypto2);
    const manifest = await bytes3.get("feed/manifest");
    if (manifest === null) return store;
    const decoded = assertCanonicalCbor(manifest, DEFAULT_DECODE_LIMITS);
    if (!Array.isArray(decoded) || decoded.length !== 4 || decoded[0] !== 1n || !Array.isArray(decoded[1]) || !Array.isArray(decoded[2]) || !Array.isArray(decoded[3])) {
      throw new Error("FEED_STORE_MANIFEST_INVALID");
    }
    for (const [items, forks] of [[decoded[1], false], [decoded[2], true]]) {
      for (const value of items) {
        if (!Array.isArray(value) || value.length !== 2 || typeof value[0] !== "string" || typeof value[1] !== "bigint" || value[1] < 0n || value[1] > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("FEED_STORE_MANIFEST_INVALID");
        const raw = await bytes3.get(objectKey(value[0]));
        if (raw === null) throw new Error("FEED_STORE_RECORD_MISSING");
        const record = await verifyFeedRecord(raw, crypto2);
        if (record.id !== value[0]) throw new Error("FEED_STORE_RECORD_MISMATCH");
        const item = { record, receivedAtMs: Number(value[1]) };
        if (forks) store.#forks.push(item);
        else {
          if (classifyFeedAppend(record, store.head(record.author), store.#byAuthor.get(record.author)?.[Number(record.sequence - 1n)]?.record.id) !== "append") {
            throw new Error("FEED_STORE_CONTINUITY_INVALID");
          }
          await store.#remember(item);
        }
      }
    }
    for (const id2 of decoded[3]) {
      if (typeof id2 !== "string" || store.#evidenceIndex.has(id2)) throw new Error("FEED_STORE_MANIFEST_INVALID");
      const raw = await bytes3.get(objectKey(id2));
      if (raw === null) throw new Error("FEED_STORE_EVIDENCE_MISSING");
      if (feedRecordId(await crypto2.sha256(raw)) !== id2) throw new Error("FEED_STORE_EVIDENCE_MISMATCH");
      store.#evidenceIndex.set(id2, store.#evidence.length);
      store.#evidence.push({ id: id2, bytes: raw.slice() });
    }
    return store;
  }
  head(author) {
    const last = this.#byAuthor.get(author)?.at(-1)?.record;
    return last === void 0 ? { sequence: 0n, id: null } : { sequence: last.sequence, id: last.id };
  }
  append(input, receivedAtMs = Date.now()) {
    const raw = input.raw.slice();
    const task = this.#pending.then(async () => {
      this.#assertWritable();
      if (!Number.isSafeInteger(receivedAtMs) || receivedAtMs < 0) throw new Error("FEED_RECEIVED_AT_INVALID");
      const record = await verifyFeedRecord(raw, this.#crypto);
      if (record.id !== input.id) throw new Error("FEED_STORE_RECORD_MISMATCH");
      const head = this.head(record.author);
      const existing = this.#byAuthor.get(record.author)?.[Number(record.sequence - 1n)]?.record.id;
      const kind = classifyFeedAppend(record, head, existing);
      if (kind === "duplicate") return { kind };
      if (kind === "out_of_order") return { kind, head: head.sequence };
      const item = { record, receivedAtMs };
      const records = kind === "append" ? [...this.#records, item] : this.#records;
      const forks = kind === "fork" && !this.#forks.some((fork) => fork.record.id === record.id) ? [...this.#forks, item] : this.#forks;
      try {
        await this.#put(objectKey(record.id), record.raw);
        await this.#put("feed/manifest", encodeCanonicalCbor([1n, manifestRows(records), manifestRows(forks), this.#evidence.map((item2) => item2.id)]));
        if (kind === "append") await this.#remember(item);
        else if (forks !== this.#forks) this.#forks.push(item);
      } catch (error) {
        this.#failWrite(error);
        throw error;
      }
      return { kind: kind === "append" ? "appended" : "fork", record: toTransportRecord(record, receivedAtMs) };
    });
    this.#pending = task.catch(() => void 0);
    return task;
  }
  putEvidence(input) {
    const bytes3 = input.slice();
    const task = this.#pending.then(async () => {
      this.#assertWritable();
      if (bytes3.length > 64 * 1024 * 1024) throw new Error("FEED_RECORD_TOO_LARGE");
      const id2 = feedRecordId(await this.#crypto.sha256(bytes3));
      const existing = this.#evidenceIndex.get(id2);
      if (existing !== void 0) return { kind: "duplicate", index: BigInt(existing + 1), evidence: { id: id2, bytes: bytes3.slice() } };
      const evidence = { id: id2, bytes: bytes3 };
      await this.#put(objectKey(id2), bytes3);
      await this.#put("feed/manifest", encodeCanonicalCbor([
        1n,
        manifestRows(this.#records),
        manifestRows(this.#forks),
        [...this.#evidence.map((item) => item.id), id2]
      ]));
      this.#evidenceIndex.set(id2, this.#evidence.length);
      this.#evidence.push(evidence);
      return { kind: "appended", index: BigInt(this.#evidence.length), evidence: { id: id2, bytes: bytes3.slice() } };
    });
    this.#pending = task.catch(() => void 0);
    return task;
  }
  evidenceAfter(index, limit) {
    assertRange(index, limit);
    return this.#evidence.slice(Number(index), Number(index) + limit).map((item, offset) => ({ index: index + BigInt(offset) + 1n, evidence: { id: item.id, bytes: item.bytes.slice() } }));
  }
  get(id2) {
    const stored = this.#byId.get(id2);
    return stored === void 0 ? void 0 : toTransportRecord(stored.record, stored.receivedAtMs);
  }
  async getPayload(hash) {
    validatePayloadHash(hash);
    const bytes3 = this.#payloads.get(hash) ?? await this.#bytes.get(`feed/payload/${hash}`);
    if (bytes3 === null) return null;
    await verifyPayloadHash(hash, bytes3);
    return bytes3.slice();
  }
  async putPayload(input) {
    this.#assertWritable();
    const bytes3 = input.slice();
    if (bytes3.length > 64 * 1024 * 1024) throw new Error("FEED_RECORD_TOO_LARGE");
    const hash = await payloadHash(bytes3);
    if (!this.#payloads.has(hash)) await this.#put(`feed/payload/${hash}`, bytes3);
    return hash;
  }
  after(index, limit) {
    assertRange(index, limit);
    return this.#records.slice(Number(index), Number(index) + limit).map((item, offset) => ({ index: index + BigInt(offset) + 1n, record: toTransportRecord(item.record, item.receivedAtMs) }));
  }
  forksAfter(index, limit) {
    assertRange(index, limit);
    return this.#forks.slice(Number(index), Number(index) + limit).map((item, offset) => ({ index: index + BigInt(offset) + 1n, record: toTransportRecord(item.record, item.receivedAtMs) }));
  }
  feedAfter(author, sequence, limit) {
    assertRange(sequence, limit);
    return (this.#byAuthor.get(author) ?? []).slice(Number(sequence), Number(sequence) + limit).map(({ record }) => ({ sequence: record.sequence, raw: record.raw.slice() }));
  }
  heads() {
    return new Map([...this.#byAuthor].map(([author, rows]) => [author, BigInt(rows.length)]));
  }
  count() {
    return this.#records.length;
  }
  forkedAuthors() {
    return [...new Set(this.#forks.map(({ record }) => record.author))].sort();
  }
  async close() {
    await this.#pending;
    this.#closed = true;
  }
  #assertWritable() {
    if (this.#closed) throw new Error("FEED_STORE_CLOSED");
    if (this.#writeFailed) throw new Error("FEED_STORE_REOPEN_REQUIRED", { cause: this.#writeFailure });
  }
  async #put(key, bytes3) {
    this.#assertWritable();
    try {
      await this.#bytes.put(key, bytes3);
    } catch (error) {
      this.#failWrite(error);
      throw error;
    }
  }
  #failWrite(error) {
    if (this.#writeFailed) return;
    this.#writeFailed = true;
    this.#writeFailure = error;
  }
  async #remember(item) {
    this.#payloads.set(await payloadHash(item.record.payload), item.record.payload);
    this.#records.push(item);
    this.#byId.set(item.record.id, item);
    const author = this.#byAuthor.get(item.record.author) ?? [];
    author.push(item);
    this.#byAuthor.set(item.record.author, author);
  }
};
function manifestRows(items) {
  return items.map((item) => [item.record.id, BigInt(item.receivedAtMs)]);
}
function objectKey(id2) {
  const match = /^%([A-Za-z0-9+/]{43}=)\.sha256$/u.exec(id2);
  if (match === null) throw new Error("FEED_STORE_RECORD_ID_INVALID");
  const digest = Uint8Array.from(atob(match[1]), (character) => character.charCodeAt(0));
  if (feedRecordId(digest) !== id2) throw new Error("FEED_STORE_RECORD_ID_INVALID");
  return `feed/object/${[...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}
function assertRange(after, limit) {
  if (after < 0n || after > BigInt(Number.MAX_SAFE_INTEGER) || !Number.isSafeInteger(limit) || limit < 1 || limit > 4096) {
    throw new Error("FEED_RANGE_INVALID");
  }
}

// packages/records/src/replication.ts
async function ingestFeedBytes(raw, options) {
  const record = await verifyFeedRecord(raw, options.crypto, options.maxRecordBytes ?? DEFAULT_MAX_RECORD_BYTES);
  if (options.feed !== void 0 && record.author !== options.feed) throw new Error("FEED_RANGE_AUTHOR_MISMATCH");
  const result = await options.store.append(record);
  if (result.kind === "appended" || result.kind === "fork") options.onStored?.(record, result);
  return result;
}
async function pullFeed(link, feed, options, signal, batchSize = 64) {
  if (!Number.isSafeInteger(batchSize) || batchSize < 1 || batchSize > 4096) throw new Error("FEED_RANGE_INVALID");
  while (signal?.aborted !== true) {
    const before = await options.store.head(feed);
    const batch = await link.read(feed, before.sequence, batchSize);
    if (batch.length > batchSize) throw new Error("FEED_RANGE_TOO_LARGE");
    if (batch.length === 0) return;
    for (const raw of batch) {
      if (signal?.aborted) return;
      const result = await ingestFeedBytes(raw, { ...options, feed });
      if (result.kind === "out_of_order") throw new Error("FEED_RANGE_NOT_CONTIGUOUS");
    }
    const after = await options.store.head(feed);
    if (after.sequence <= before.sequence) throw new Error("FEED_RANGE_NO_PROGRESS");
    if (batch.length < batchSize) return;
  }
}
var ChangeSignal = class {
  #waiters = /* @__PURE__ */ new Set();
  #version = 0;
  #closed = false;
  get version() {
    return this.#version;
  }
  notify() {
    this.#version += 1;
    for (const waiter of [...this.#waiters]) waiter();
  }
  close() {
    this.#closed = true;
    this.notify();
  }
  wait(version2, signal) {
    return new Promise((resolve) => {
      const done = () => {
        this.#waiters.delete(done);
        signal?.removeEventListener("abort", done);
        resolve();
      };
      this.#waiters.add(done);
      signal?.addEventListener("abort", done, { once: true });
      if (this.#closed || signal?.aborted === true || this.#version !== version2) done();
    });
  }
  async *watch(signal) {
    while (!this.#closed && signal?.aborted !== true) {
      const version2 = this.#version;
      yield void 0;
      await this.wait(version2, signal);
    }
  }
};

// packages/records/src/transport.ts
var PortableFeedTransport = class {
  #store;
  #signer;
  #crypto;
  #maxRecordBytes;
  #changes = new ChangeSignal();
  #wanted = /* @__PURE__ */ new Set();
  #connections = /* @__PURE__ */ new Map();
  #publish = Promise.resolve();
  #closed = false;
  constructor(options) {
    this.#store = options.store;
    this.#signer = options.signer;
    this.#crypto = options.crypto;
    this.#maxRecordBytes = options.maxRecordBytes ?? DEFAULT_MAX_RECORD_BYTES;
    this.#wanted.add(this.identity);
  }
  get identity() {
    return this.#signer.identity;
  }
  publish(payload, options = {}) {
    const exactPayload = payload.slice();
    const timestamp = BigInt(Math.trunc(options.timestampMs ?? Date.now()));
    const pending = this.#publish.then(async () => {
      if (this.#closed) throw new Error("FEED_TRANSPORT_CLOSED");
      const head = await this.#store.head(this.identity);
      const record = await createFeedRecord(this.#signer, this.#crypto, head.sequence + 1n, head.id, timestamp, exactPayload);
      if (record.raw.length > this.#maxRecordBytes) throw new Error("FEED_RECORD_TOO_LARGE");
      const result = await this.#store.append(record);
      if (result.kind !== "appended") throw new Error(`FEED_LOCAL_APPEND_${result.kind.toUpperCase()}`);
      this.#changes.notify();
      return result.record;
    });
    this.#publish = pending.catch(() => void 0);
    return pending;
  }
  async get(id2) {
    return this.#store.get(id2);
  }
  async getPayload(hash) {
    validatePayloadHash(hash);
    const local = await this.#store.getPayload(hash);
    if (local !== null) return local;
    let failure;
    for (const connection of this.#connections.values()) {
      try {
        const bytes3 = await connection.link.readPayload(hash);
        if (bytes3 === null) continue;
        if (bytes3.length > this.#maxRecordBytes) throw new Error("FEED_RECORD_TOO_LARGE");
        await verifyPayloadHash(hash, bytes3);
        await this.#store.putPayload(bytes3);
        return bytes3.slice();
      } catch (error) {
        failure = error instanceof Error ? error : new Error(String(error));
      }
    }
    if (failure !== void 0) throw failure;
    return null;
  }
  async history() {
    const records = [];
    for (const read of [this.#store.after.bind(this.#store), this.#store.forksAfter.bind(this.#store)]) {
      let after = 0n;
      for (; ; ) {
        const batch = await read(after, 4096);
        if (batch.length === 0) break;
        records.push(...batch.map(({ record }) => record));
        after = batch.at(-1).index;
      }
    }
    return records;
  }
  async *subscribe(signal) {
    let after = 0n;
    let forkCursor = 0n;
    while (!this.#closed && signal?.aborted !== true) {
      const version2 = this.#changes.version;
      const batch = await this.#store.after(after, 256);
      for (const entry of batch) {
        after = entry.index;
        yield cloneRecord(entry.record);
      }
      const forks = await this.#store.forksAfter(forkCursor, 256);
      for (const entry of forks) {
        forkCursor = entry.index;
        yield cloneRecord(entry.record);
      }
      if (batch.length < 256 && forks.length < 256) await this.#changes.wait(version2, signal);
    }
  }
  async feedContiguousThrough(feed) {
    return (await this.#store.head(feed)).sequence;
  }
  requestFeed(feed) {
    if (this.#wanted.has(feed)) return;
    this.#wanted.add(feed);
    for (const connection of this.#connections.values()) this.#queueSync(connection);
  }
  /** Attaches a link and starts retained catch-up. Errors remain observable and retryable. */
  connect(link) {
    if (this.#closed) throw new Error("FEED_TRANSPORT_CLOSED");
    this.disconnect(link.identity);
    this.#wanted.add(link.identity);
    const connection = { link, controller: new AbortController(), pending: Promise.resolve(), evidenceAfter: 0n };
    this.#connections.set(link.identity, connection);
    this.#queueSync(connection);
    void (async () => {
      try {
        for await (const _hint of link.watch(connection.controller.signal)) {
          if (connection.controller.signal.aborted) return;
          this.#queueSync(connection);
          await connection.pending;
        }
      } catch (error) {
        connection.error = error instanceof Error ? error.message : String(error);
      }
    })();
  }
  disconnect(identity) {
    this.#connections.get(identity)?.controller.abort();
    this.#connections.delete(identity);
  }
  /** Explicit repair after a missed hint; no cursor is advanced without durable storage. */
  async catchUp() {
    for (const connection of this.#connections.values()) this.#queueSync(connection);
    await Promise.all([...this.#connections.values()].map((connection) => connection.pending));
    const error = [...this.#connections.values()].find((connection) => connection.error !== void 0)?.error;
    if (error !== void 0) throw new Error(error);
  }
  asLink() {
    return {
      identity: this.identity,
      read: async (feed, after, limit) => {
        if (this.#closed) throw new Error("FEED_TRANSPORT_CLOSED");
        return (await this.#store.feedAfter(feed, after, limit)).map(({ raw }) => raw.slice());
      },
      readEvidence: async (after, limit) => (await this.#store.evidenceAfter(after, limit)).map(({ evidence }) => evidence.bytes.slice()),
      readPayload: async (hash) => this.#store.getPayload(hash),
      watch: (signal) => this.#changes.watch(signal)
    };
  }
  async putEvidence(bytes3) {
    if (this.#closed) throw new Error("FEED_TRANSPORT_CLOSED");
    const result = await this.#store.putEvidence(bytes3);
    if (result.kind === "appended") this.#changes.notify();
    return result.evidence;
  }
  async evidenceHistory() {
    const result = [];
    let after = 0n;
    for (; ; ) {
      const batch = await this.#store.evidenceAfter(after, 256);
      if (batch.length === 0) return result;
      result.push(...batch.map((item) => item.evidence));
      after = batch.at(-1).index;
    }
  }
  async *subscribeEvidence(signal) {
    let after = 0n;
    while (!this.#closed && !signal?.aborted) {
      const version2 = this.#changes.version;
      const batch = await this.#store.evidenceAfter(after, 256);
      for (const item of batch) {
        after = item.index;
        yield item.evidence;
      }
      if (batch.length < 256) await this.#changes.wait(version2, signal);
    }
  }
  async status() {
    const heads = await this.#store.heads();
    const error = [...this.#connections.values()].find((connection) => connection.error !== void 0)?.error;
    return {
      identity: this.identity,
      records: await this.#store.count(),
      closed: this.#closed,
      peers: [...this.#connections.keys()].sort(),
      feedsWithGaps: 0,
      feedStates: [...heads].map(([feedId, sequence]) => ({ feedId, contiguousThrough: String(sequence), maximumSequence: String(sequence), hasGaps: false })),
      ...error === void 0 ? {} : { lastCatchUpError: error }
    };
  }
  async close() {
    if (this.#closed) return;
    this.#closed = true;
    for (const connection of this.#connections.values()) connection.controller.abort();
    await this.#publish;
    await Promise.all([...this.#connections.values()].map((connection) => connection.pending));
    this.#connections.clear();
    this.#changes.close();
    await this.#store.close();
  }
  #queueSync(connection) {
    connection.pending = connection.pending.then(async () => {
      if (connection.controller.signal.aborted || this.#closed) return;
      try {
        for (const feed of this.#wanted) {
          await pullFeed(connection.link, feed, {
            store: this.#store,
            crypto: this.#crypto,
            maxRecordBytes: this.#maxRecordBytes,
            onStored: () => {
              this.#changes.notify();
            }
          }, connection.controller.signal);
        }
        while (!connection.controller.signal.aborted) {
          const batch = await connection.link.readEvidence(connection.evidenceAfter, 64);
          if (batch.length > 64) throw new Error("FEED_RANGE_TOO_LARGE");
          for (const bytes3 of batch) {
            await this.putEvidence(bytes3);
            connection.evidenceAfter += 1n;
          }
          if (batch.length < 64) break;
        }
        delete connection.error;
      } catch (error) {
        connection.error = error instanceof Error ? error.message : String(error);
      }
    });
  }
};

// packages/node-core/src/async.ts
var Mutex = class {
  #tail = Promise.resolve();
  async run(operation) {
    let release;
    const previous = this.#tail;
    this.#tail = new Promise((resolve) => {
      release = resolve;
    });
    await previous;
    try {
      return await operation();
    } finally {
      release();
    }
  }
};
var Subscription = class {
  #values = [];
  #waiters = [];
  #onClose;
  #closed = false;
  constructor(onClose, initial) {
    this.#onClose = onClose;
    if (initial !== void 0) this.#values.push(initial);
  }
  emit(value) {
    if (this.#closed) return;
    const waiter = this.#waiters.shift();
    if (waiter) waiter.resolve({ value, done: false });
    else this.#values.push(value);
  }
  close() {
    if (this.#closed) return;
    this.#closed = true;
    this.#onClose();
    for (const waiter of this.#waiters.splice(0)) waiter.resolve({ value: void 0, done: true });
  }
  [Symbol.asyncIterator]() {
    return {
      next: () => {
        const value = this.#values.shift();
        if (value !== void 0) return Promise.resolve({ value, done: false });
        if (this.#closed) return Promise.resolve({ value: void 0, done: true });
        return new Promise((resolve, reject) => {
          this.#waiters.push({ resolve, reject });
        });
      },
      return: async () => {
        this.close();
        return { value: void 0, done: true };
      }
    };
  }
};
var RevisionBroadcaster = class {
  #subscriptions = /* @__PURE__ */ new Set();
  #latest;
  #closed = false;
  constructor(initial) {
    this.#latest = initial;
  }
  get latest() {
    return this.#latest;
  }
  emit(value) {
    if (this.#closed) throw new Error("broadcaster is closed");
    this.#latest = value;
    for (const subscription of this.#subscriptions) subscription.emit(value);
  }
  subscribe(options = {}) {
    const subscription = new Subscription(
      () => this.#subscriptions.delete(subscription),
      options.replayLatest === false ? void 0 : this.#latest
    );
    if (this.#closed) subscription.close();
    else this.#subscriptions.add(subscription);
    const abort = () => subscription.close();
    if (options.signal?.aborted) abort();
    else options.signal?.addEventListener("abort", abort, { once: true });
    return subscription;
  }
  close() {
    if (this.#closed) return;
    this.#closed = true;
    for (const subscription of [...this.#subscriptions]) subscription.close();
  }
};

// packages/crypto/src/hpke.ts
var HPKE_SUITE = "DHKEM(X25519,HKDF-SHA256)/HKDF-SHA256/AES-256-GCM";
var KEM_ID = Uint8Array.of(0, 32);
var KDF_ID = Uint8Array.of(0, 1);
var AEAD_ID = Uint8Array.of(0, 2);
var KEM_SUITE_ID = concatBytes(utf82("KEM"), KEM_ID);
var HPKE_SUITE_ID = concatBytes(utf82("HPKE"), KEM_ID, KDF_ID, AEAD_ID);
var HPKE_VERSION = utf82("HPKE-v1");
var HASH_SIZE = 32;
var X25519 = { name: "X25519" };
function source(value) {
  return Uint8Array.from(value).buffer;
}
function i2osp(value, length) {
  protocolInvariant(Number.isSafeInteger(value) && value >= 0 && value < 2 ** (8 * length), "INTEGER_OUT_OF_RANGE", "Integer does not fit HPKE field");
  const result = new Uint8Array(length);
  let remainder = value;
  for (let index = length - 1; index >= 0; index -= 1) {
    result[index] = remainder & 255;
    remainder = Math.floor(remainder / 256);
  }
  return result;
}
async function hmac(keyBytes, data) {
  const key = await globalThis.crypto.subtle.importKey(
    "raw",
    source(keyBytes),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return new Uint8Array(await globalThis.crypto.subtle.sign("HMAC", key, source(data)));
}
async function hkdfExtract(salt, ikm) {
  return hmac(salt.length === 0 ? new Uint8Array(HASH_SIZE) : salt, ikm);
}
async function hkdfExpand(prk, info, length) {
  protocolInvariant(length <= 255 * HASH_SIZE, "INTEGER_OUT_OF_RANGE", "HKDF output is too long");
  let previous = new Uint8Array();
  const blocks = [];
  for (let counter = 1; blocks.reduce((sum, block) => sum + block.length, 0) < length; counter += 1) {
    previous = await hmac(prk, concatBytes(previous, info, Uint8Array.of(counter)));
    blocks.push(previous);
  }
  return concatBytes(...blocks).slice(0, length);
}
async function labeledExtract(suiteId, salt, label, ikm) {
  return hkdfExtract(salt, concatBytes(HPKE_VERSION, suiteId, utf82(label), ikm));
}
async function labeledExpand(suiteId, prk, label, info, length) {
  return hkdfExpand(prk, concatBytes(i2osp(length, 2), HPKE_VERSION, suiteId, utf82(label), info), length);
}
async function generateX25519KeyPair(extractable = true) {
  const pair = await globalThis.crypto.subtle.generateKey(X25519, extractable, ["deriveBits"]);
  return {
    publicKey: pair.publicKey,
    privateKey: pair.privateKey,
    publicKeyBytes: new Uint8Array(await globalThis.crypto.subtle.exportKey("raw", pair.publicKey))
  };
}
async function importX25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "X25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", source(raw), X25519, true, []);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import X25519 public key");
  }
}
async function importX25519PrivateKey(pkcs8, extractable = true) {
  try {
    return await globalThis.crypto.subtle.importKey("pkcs8", source(pkcs8), X25519, extractable, ["deriveBits"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import X25519 private key");
  }
}
async function exportX25519PrivateKey(privateKey) {
  try {
    return new Uint8Array(await globalThis.crypto.subtle.exportKey("pkcs8", privateKey));
  } catch {
    throw new ProtocolError("INVALID_KEY", "X25519 private key is not extractable");
  }
}
async function dh(privateKey, publicKey) {
  try {
    const bits = await globalThis.crypto.subtle.deriveBits({ name: "X25519", public: publicKey }, privateKey, 256);
    const result = new Uint8Array(bits);
    protocolInvariant(result.some((byte) => byte !== 0), "INVALID_KEY", "X25519 produced the prohibited all-zero shared secret");
    return result;
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    throw new ProtocolError("INVALID_KEY", "X25519 key agreement failed");
  }
}
async function extractAndExpand(dhValue, kemContext) {
  const eaePrk = await labeledExtract(KEM_SUITE_ID, new Uint8Array(), "eae_prk", dhValue);
  return labeledExpand(KEM_SUITE_ID, eaePrk, "shared_secret", kemContext, HASH_SIZE);
}
async function keySchedule(sharedSecret, info) {
  const pskIdHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "psk_id_hash", new Uint8Array());
  const infoHash = await labeledExtract(HPKE_SUITE_ID, new Uint8Array(), "info_hash", info);
  const keyScheduleContext = concatBytes(Uint8Array.of(0), pskIdHash, infoHash);
  const secret = await labeledExtract(HPKE_SUITE_ID, sharedSecret, "secret", new Uint8Array());
  return {
    key: await labeledExpand(HPKE_SUITE_ID, secret, "key", keyScheduleContext, 32),
    nonce: await labeledExpand(HPKE_SUITE_ID, secret, "base_nonce", keyScheduleContext, 12)
  };
}
async function aesGcmSeal(keyBytes, nonce, plaintext, aad) {
  const key = await globalThis.crypto.subtle.importKey("raw", source(keyBytes), "AES-GCM", false, ["encrypt"]);
  return new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source(nonce), additionalData: source(aad), tagLength: 128 },
    key,
    source(plaintext)
  ));
}
async function aesGcmOpen(keyBytes, nonce, ciphertext, aad) {
  try {
    const key = await globalThis.crypto.subtle.importKey("raw", source(keyBytes), "AES-GCM", false, ["decrypt"]);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source(nonce), additionalData: source(aad), tagLength: 128 },
      key,
      source(ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "HPKE ciphertext authentication failed");
  }
}
async function hpkeSealBase(recipientPublicKeyBytes, plaintext, info, aad) {
  const recipientPublicKey = await importX25519PublicKey(recipientPublicKeyBytes);
  const ephemeral = await generateX25519KeyPair(false);
  const sharedSecret = await extractAndExpand(
    await dh(ephemeral.privateKey, recipientPublicKey),
    concatBytes(ephemeral.publicKeyBytes, recipientPublicKeyBytes)
  );
  const context = await keySchedule(sharedSecret, info);
  return {
    encapsulatedKey: ephemeral.publicKeyBytes,
    ciphertext: await aesGcmSeal(context.key, context.nonce, plaintext, aad)
  };
}
async function hpkeOpenBase(recipientPrivateKey, recipientPublicKeyBytes, encapsulatedKey, ciphertext, info, aad) {
  protocolInvariant(recipientPublicKeyBytes.length === 32 && encapsulatedKey.length === 32, "INVALID_KEY", "HPKE X25519 keys must contain 32 bytes");
  const ephemeralPublicKey = await importX25519PublicKey(encapsulatedKey);
  const sharedSecret = await extractAndExpand(
    await dh(recipientPrivateKey, ephemeralPublicKey),
    concatBytes(encapsulatedKey, recipientPublicKeyBytes)
  );
  const context = await keySchedule(sharedSecret, info);
  return aesGcmOpen(context.key, context.nonce, ciphertext, aad);
}

// packages/crypto/src/epoch.ts
function source2(value) {
  return Uint8Array.from(value).buffer;
}
function wrapContext(groupId, epoch, previous, recipientId) {
  return encodeCanonicalCbor(integerMap([[0, groupId], [1, epoch], [2, previous], [3, recipientId], [4, HPKE_SUITE]]));
}
function wrapToCbor(value) {
  return integerMap([[0, value.recipientId], [1, value.recipientPublicKey], [2, value.encapsulatedKey], [3, value.ciphertext]]);
}
function manifestToCbor(value) {
  protocolInvariant(value.epoch >= 0n, "INTEGER_OUT_OF_RANGE", "Encryption epoch cannot be negative");
  protocolInvariant(value.suite === HPKE_SUITE, "SCHEMA_INVALID", "Unsupported HPKE suite");
  const sorted = [...value.wraps].sort((a, b) => compareBytes(a.recipientId, b.recipientId));
  for (let index = 1; index < sorted.length; index += 1) {
    protocolInvariant(compareBytes(sorted[index - 1]?.recipientId ?? new Uint8Array(), sorted[index]?.recipientId ?? new Uint8Array()) !== 0, "SCHEMA_INVALID", "Epoch manifest contains duplicate recipient");
  }
  return integerMap([
    [0, 1n],
    [1, value.groupId],
    [2, value.epoch],
    [3, value.previousEpochDigest],
    [4, value.suite],
    [5, value.createdAtMs],
    [6, sorted.map(wrapToCbor)]
  ]);
}
function encodeEpochManifest(value) {
  return encodeCanonicalCbor(manifestToCbor(value));
}
function decodeEpochManifest(bytes3) {
  const map = expectMap(assertCanonicalCbor2(bytes3), "epoch_manifest");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5, 6], "epoch_manifest");
  expectVersion(map, 1n, "epoch_manifest");
  const previous = required(map, 3, "epoch_manifest.previous");
  protocolInvariant(previous === null || previous instanceof Uint8Array, "SCHEMA_INVALID", "Previous epoch digest must be null or bytes");
  const suite = expectString(required(map, 4, "epoch_manifest.suite"), "epoch_manifest.suite");
  protocolInvariant(suite === HPKE_SUITE, "SCHEMA_INVALID", "Unsupported HPKE suite");
  const manifest = {
    groupId: expectBytes(required(map, 1, "epoch_manifest.group_id"), "epoch_manifest.group_id"),
    epoch: expectUint64(required(map, 2, "epoch_manifest.epoch"), "epoch_manifest.epoch"),
    previousEpochDigest: previous,
    suite,
    createdAtMs: expectUint64(required(map, 5, "epoch_manifest.created_at"), "epoch_manifest.created_at"),
    wraps: expectArray(required(map, 6, "epoch_manifest.wraps"), "epoch_manifest.wraps").map((item, index) => {
      const wrap2 = expectMap(item, `epoch_manifest.wraps[${index}]`);
      assertKnownIntegerKeys(wrap2, [0, 1, 2, 3], `epoch_manifest.wraps[${index}]`);
      return {
        recipientId: expectBytes(required(wrap2, 0, "wrap.recipient_id"), "wrap.recipient_id"),
        recipientPublicKey: expectBytes(required(wrap2, 1, "wrap.recipient_key"), "wrap.recipient_key", 32),
        encapsulatedKey: expectBytes(required(wrap2, 2, "wrap.encapsulated_key"), "wrap.encapsulated_key", 32),
        ciphertext: expectBytes(required(wrap2, 3, "wrap.ciphertext"), "wrap.ciphertext")
      };
    })
  };
  manifestToCbor(manifest);
  return manifest;
}
function encodeSignedEpochManifest(value) {
  return encodeCanonicalCbor(integerMap([
    [0, 1n],
    [1, encodeEpochManifest(value.manifest)],
    [2, value.signerPublicKey],
    [3, value.signature]
  ]));
}
function decodeSignedEpochManifest(bytes3) {
  const map = expectMap(assertCanonicalCbor2(bytes3), "signed_epoch_manifest");
  assertKnownIntegerKeys(map, [0, 1, 2, 3], "signed_epoch_manifest");
  expectVersion(map, 1n, "signed_epoch_manifest");
  return {
    manifest: decodeEpochManifest(expectBytes(required(map, 1, "signed_epoch_manifest.payload"), "signed_epoch_manifest.payload")),
    signerPublicKey: expectBytes(required(map, 2, "signed_epoch_manifest.signer"), "signed_epoch_manifest.signer", 32),
    signature: expectBytes(required(map, 3, "signed_epoch_manifest.signature"), "signed_epoch_manifest.signature", 64)
  };
}
async function createEpochManifest(input) {
  const contentKey = input.contentKey === void 0 ? globalThis.crypto.getRandomValues(new Uint8Array(32)) : Uint8Array.from(input.contentKey);
  protocolInvariant(contentKey.length === 32, "SCHEMA_INVALID", "Epoch content key must contain 32 bytes");
  const recipients = [...input.recipients].sort((a, b) => compareBytes(a.recipientId, b.recipientId));
  const wraps = [];
  for (let index = 0; index < recipients.length; index += 1) {
    const recipient = recipients[index];
    if (index > 0) protocolInvariant(compareBytes(recipients[index - 1]?.recipientId ?? new Uint8Array(), recipient.recipientId) !== 0, "SCHEMA_INVALID", "Epoch recipients must be unique");
    const context = wrapContext(input.groupId, input.epoch, input.previousEpochDigest, recipient.recipientId);
    const sealed = await hpkeSealBase(recipient.publicKey, contentKey, context, context);
    wraps.push({
      recipientId: recipient.recipientId,
      recipientPublicKey: recipient.publicKey,
      encapsulatedKey: sealed.encapsulatedKey,
      ciphertext: sealed.ciphertext
    });
  }
  const manifest = {
    groupId: input.groupId,
    epoch: input.epoch,
    previousEpochDigest: input.previousEpochDigest,
    suite: HPKE_SUITE,
    createdAtMs: input.createdAtMs,
    wraps
  };
  const signature = await signDomain(DOMAINS.epochManifest, encodeEpochManifest(manifest), input.signerPrivateKey);
  return { signedManifest: { manifest, signerPublicKey: input.signerPublicKey, signature }, contentKey };
}
async function verifyEpochManifest(value, trustedSigner) {
  return equalBytes(value.signerPublicKey, trustedSigner) && verifyDomain(DOMAINS.epochManifest, encodeEpochManifest(value.manifest), value.signature, trustedSigner);
}
async function unwrapEpochKey(input) {
  protocolInvariant(await verifyEpochManifest(input.signedManifest, input.trustedSigner), "INVALID_SIGNATURE", "Epoch manifest signature is invalid");
  const { manifest } = input.signedManifest;
  const wrap2 = manifest.wraps.find((candidate) => equalBytes(candidate.recipientId, input.recipientId));
  protocolInvariant(wrap2 !== void 0, "INVALID_KEY", "Epoch manifest has no wrap for recipient");
  const context = wrapContext(manifest.groupId, manifest.epoch, manifest.previousEpochDigest, input.recipientId);
  const key = await hpkeOpenBase(
    input.recipientPrivateKey,
    wrap2.recipientPublicKey,
    wrap2.encapsulatedKey,
    wrap2.ciphertext,
    context,
    context
  );
  protocolInvariant(key.length === 32, "INVALID_KEY", "Unwrapped epoch key has invalid length");
  return key;
}
function payloadAad(epoch, associatedData) {
  return encodeCanonicalCbor(integerMap([[0, 1n], [1, epoch], [2, associatedData]]));
}
async function encryptEpochPayload(contentKey, epoch, plaintext, associatedData) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  const key = await globalThis.crypto.subtle.importKey("raw", source2(contentKey), "AES-GCM", false, ["encrypt"]);
  const nonce = globalThis.crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = new Uint8Array(await globalThis.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: source2(nonce), additionalData: source2(payloadAad(epoch, associatedData)), tagLength: 128 },
    key,
    source2(plaintext)
  ));
  return { epoch, nonce, ciphertext };
}
async function decryptEpochPayload(contentKey, payload, associatedData) {
  protocolInvariant(contentKey.length === 32, "INVALID_KEY", "Epoch content key must contain 32 bytes");
  protocolInvariant(payload.nonce.length === 12, "SCHEMA_INVALID", "Epoch payload nonce must contain 12 bytes");
  try {
    const key = await globalThis.crypto.subtle.importKey("raw", source2(contentKey), "AES-GCM", false, ["decrypt"]);
    return new Uint8Array(await globalThis.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: source2(payload.nonce), additionalData: source2(payloadAad(payload.epoch, associatedData)), tagLength: 128 },
      key,
      source2(payload.ciphertext)
    ));
  } catch {
    throw new ProtocolError("INVALID_SIGNATURE", "Epoch payload authentication failed");
  }
}

// packages/node-core/src/finality.ts
var FORMAT = "chronolog/finality-closure";
var SIGNING_DOMAIN = "chronolog/finality-closure/v1\0";
var MAX_TIMESTAMP = (1n << 63n) - 1n;
var MAX_CLOSURE_BYTES = 32768;
function encodeFinalityClosureRecord(value) {
  const fields = closureFields(value);
  if (!(value.signature instanceof Uint8Array) || value.signature.length !== 64) throw new Error("FINALITY_CLOSURE_INVALID");
  return encodeCanonicalCbor([...fields, value.signature]);
}
function isFinalityClosureRecord(bytes3) {
  try {
    const value = assertCanonicalCbor2(bytes3, { maxBytes: 1048576, maxDepth: 16, maxItems: 256 });
    return Array.isArray(value) && value[1] === FORMAT;
  } catch {
    return false;
  }
}
function decodeFinalityClosureRecord(bytes3) {
  let value;
  try {
    value = assertCanonicalCbor2(bytes3, { maxBytes: MAX_CLOSURE_BYTES, maxDepth: 2, maxItems: 8 });
  } catch {
    throw new Error("FINALITY_CLOSURE_INVALID");
  }
  if (!Array.isArray(value) || value.length !== 8 || value[0] !== 1n || value[1] !== FORMAT || !(value[2] instanceof Uint8Array) || typeof value[3] !== "string" || typeof value[4] !== "bigint" || typeof value[5] !== "string" || typeof value[6] !== "bigint" || !(value[7] instanceof Uint8Array)) throw new Error("FINALITY_CLOSURE_INVALID");
  const position = Number(value[4]);
  if (!Number.isSafeInteger(position) || BigInt(position) !== value[4]) throw new Error("FINALITY_CLOSURE_INVALID");
  const closure = {
    configuration: value[2],
    includedHead: { historyId: value[3], position, root: value[5] },
    closedThroughMs: value[6],
    signature: value[7]
  };
  encodeFinalityClosureRecord(closure);
  return structuredClone(closure);
}
async function verifyFinalityClosureRecord(bytes3, configuration) {
  const expected = encodeHistoryConfiguration(configuration);
  const publicKey = configuration.authorityPublicKey.slice();
  const historyId = configuration.historyId;
  const closure = decodeFinalityClosureRecord(bytes3.slice());
  if (closure.includedHead.historyId !== historyId || !equalBytes(closure.configuration, expected)) {
    throw new Error("FINALITY_CLOSURE_CONFIGURATION_MISMATCH");
  }
  const key = await crypto.subtle.importKey("raw", publicKey.slice().buffer, "Ed25519", false, ["verify"]);
  if (!await crypto.subtle.verify(
    "Ed25519",
    key,
    closure.signature.slice().buffer,
    closureSigningPayload(closure).slice().buffer
  )) throw new Error("FINALITY_CLOSURE_SIGNATURE_INVALID");
  return closure;
}
async function evaluateFinalitySnapshot(configuration, entries, receivedThrough) {
  configuration = structuredClone(configuration);
  entries = structuredClone(entries);
  const records = [];
  const closures = [];
  let root = await orderedGenesisRoot(configuration.historyId);
  let position = 0;
  let closedThroughMs = -1n;
  let coveredRecords = 0;
  for (const entry of entries) {
    if (entry.historyId !== configuration.historyId || entry.position !== position + 1 || entry.previousRoot !== root) {
      throw new Error("FINALITY_CLOSURE_PREFIX_INCOMPLETE");
    }
    await verifyOrderedEntry(entry);
    let closure = null;
    if (isFinalityClosureRecord(entry.bytes)) {
      try {
        closure = await verifyFinalityClosureRecord(entry.bytes, configuration);
      } catch (error) {
        if (!(error instanceof Error) || !/^FINALITY_CLOSURE_(INVALID|SIGNATURE_INVALID|CONFIGURATION_MISMATCH)$/u.test(error.message)) throw error;
      }
    }
    if (closure !== null) {
      if (closure.includedHead.position !== position || closure.includedHead.root !== root) {
        throw new Error("FINALITY_CLOSURE_HEAD_MISMATCH");
      }
      if (closure.closedThroughMs < closedThroughMs) throw new Error("FINALITY_CLOSURE_REGRESSION");
      const boundary = {
        position: entry.position,
        root: entry.root,
        includedThrough: position,
        includedRoot: root,
        closedThroughMs: closure.closedThroughMs
      };
      closures.push(boundary);
      for (; coveredRecords < records.length; coveredRecords += 1) {
        records[coveredRecords] = {
          ...records[coveredRecords],
          closureBoundary: boundary,
          closedThroughMs: boundary.closedThroughMs
        };
      }
      closedThroughMs = closure.closedThroughMs;
    } else records.push({ entry, admissionFloorMs: closedThroughMs, closedThroughMs: -1n, closureBoundary: null });
    root = entry.root;
    position = entry.position;
  }
  const received = receivedThrough ?? position;
  if (!Number.isSafeInteger(received) || received < position) throw new Error("FINALITY_CLOSURE_PREFIX_INCOMPLETE");
  return {
    checkpointId: root,
    receivedThrough: received,
    includedThrough: position,
    closedReceiptThrough: closures.at(-1)?.includedThrough ?? 0,
    closedThroughMs,
    records,
    closures
  };
}
function closureFields(value) {
  const { configuration, includedHead: head, closedThroughMs } = value;
  if (!(configuration instanceof Uint8Array) || configuration.length < 1 || configuration.length > 32e3 || !/^h_[0-9a-f]{32}$/u.test(head.historyId) || !Number.isSafeInteger(head.position) || head.position < 0 || !/^[0-9a-f]{64}$/u.test(head.root) || typeof closedThroughMs !== "bigint" || closedThroughMs < 0n || closedThroughMs > MAX_TIMESTAMP) throw new Error("FINALITY_CLOSURE_INVALID");
  return [1n, FORMAT, configuration, head.historyId, BigInt(head.position), head.root, closedThroughMs];
}
function closureSigningPayload(value) {
  return concatBytes(utf82(SIGNING_DOMAIN), encodeCanonicalCbor(closureFields(value)));
}

// packages/node-core/src/history-policy.ts
var LOG_DOMAIN = "record-log/v1";
var CERTIFICATE_DOMAIN = "chronolog/prefix-certificate/v1\0";
var MAX_RETAINED_HISTORY_ENTRIES = 65536;
var MAX_RETAINED_EVIDENCE = MAX_RETAINED_HISTORY_ENTRIES * 2;
var DEFAULT_EVIDENCE_QUOTA_BYTES = 128 * 1024 * 1024;
var MAX_LOCAL_HISTORY_BYTES = 512 * 1024 * 1024;
function encodeHistoryConfiguration(configuration) {
  for (const bytes3 of [configuration.groupId, configuration.genesisDigest, configuration.executionManifestDigest]) {
    if (!(bytes3 instanceof Uint8Array) || bytes3.length !== 32) throw new Error("HISTORY_CONFIGURATION_INVALID");
  }
  const providerId = configuration.providerId ?? (configuration.kind === "peer" ? "peer-validators-v1" : "signed-inclusion-v1");
  if (!/^[a-z][a-z0-9._-]{0,127}$/u.test(providerId)) throw new Error("HISTORY_PROVIDER_ID_INVALID");
  const parameters = configuration.providerParameters ?? new Uint8Array();
  if (!(parameters instanceof Uint8Array) || parameters.length > 16384) throw new Error("HISTORY_PROVIDER_PARAMETERS_INVALID");
  if (configuration.kind === "peer") {
    return encodeCanonicalCbor([2n, "peer", configuration.groupId, configuration.genesisDigest, configuration.executionManifestDigest, providerId, parameters]);
  }
  assertHistoryId(configuration.historyId);
  if (configuration.authorityPublicKey.length !== 32) throw new Error("HISTORY_AUTHORITY_KEY_INVALID");
  return encodeCanonicalCbor([
    2n,
    "coordinated",
    configuration.groupId,
    configuration.genesisDigest,
    configuration.executionManifestDigest,
    configuration.historyId,
    configuration.authorityPublicKey,
    providerId,
    parameters
  ]);
}
async function historyConfigurationDigest(configuration) {
  return sha256(encodeHistoryConfiguration(configuration));
}
async function orderedRecordId(bytes3) {
  return bytesToHex(await sha256(bytes3));
}
async function orderedGenesisRoot(historyId) {
  assertHistoryId(historyId);
  return orderedRecordId(utf82(JSON.stringify([LOG_DOMAIN, "genesis", historyId])));
}
async function orderedEntryRoot(entry) {
  assertHistoryId(entry.historyId);
  assertPosition(entry.position, false);
  assertHash(entry.previousRoot);
  assertHash(entry.recordId);
  return orderedRecordId(utf82(JSON.stringify([
    LOG_DOMAIN,
    "entry",
    entry.historyId,
    entry.position,
    entry.previousRoot,
    entry.recordId
  ])));
}
async function verifyOrderedEntry(entry) {
  if (!(entry.bytes instanceof Uint8Array)) throw new Error("ORDERED_RECORD_BYTES_INVALID");
  if (entry.bytes.byteLength > 1048576) throw new Error("ORDERED_RECORD_TOO_LARGE");
  assertHash(entry.root);
  if (await orderedRecordId(entry.bytes) !== entry.recordId) throw new Error("ORDERED_RECORD_DIGEST_MISMATCH");
  if (await orderedEntryRoot(entry) !== entry.root) throw new Error("ORDERED_RECORD_ROOT_MISMATCH");
}
function certificatePayload(certificate) {
  assertHistoryId(certificate.historyId);
  assertPosition(certificate.position, true);
  assertHash(certificate.root);
  return encodeCanonicalCbor([
    CERTIFICATE_DOMAIN,
    certificate.configuration,
    certificate.historyId,
    BigInt(certificate.position),
    certificate.root
  ]);
}
async function verifyPrefixCertificate(certificate, configuration) {
  if (certificate.historyId !== configuration.historyId || !equalBytes(certificate.configuration, encodeHistoryConfiguration(configuration))) {
    throw new Error("HISTORY_CERTIFICATE_CONFIGURATION_MISMATCH");
  }
  if (certificate.signature.length !== 64) throw new Error("HISTORY_CERTIFICATE_SIGNATURE_INVALID");
  const key = await crypto.subtle.importKey("raw", configuration.authorityPublicKey.slice().buffer, "Ed25519", false, ["verify"]);
  if (!await crypto.subtle.verify("Ed25519", key, certificate.signature.slice().buffer, certificatePayload(certificate).slice().buffer)) {
    throw new Error("HISTORY_CERTIFICATE_SIGNATURE_INVALID");
  }
}
function encodeOrderingEvidence(evidence) {
  if (evidence.kind === "ordered-entry") {
    const e = evidence.entry;
    return encodeCanonicalCbor([1n, "ordered-entry", e.historyId, BigInt(e.position), e.recordId, e.previousRoot, e.root, e.bytes]);
  }
  const c = evidence.certificate;
  return encodeCanonicalCbor([1n, "prefix-certificate", c.configuration, c.historyId, BigInt(c.position), c.root, c.signature]);
}
function decodeOrderingEvidence(bytes3) {
  const value = assertCanonicalCbor2(bytes3);
  if (!Array.isArray(value) || value[0] !== 1n) throw new Error("ORDERING_EVIDENCE_INVALID");
  if (value[1] === "ordered-entry" && value.length === 8 && typeof value[2] === "string" && typeof value[3] === "bigint" && typeof value[4] === "string" && typeof value[5] === "string" && typeof value[6] === "string" && value[7] instanceof Uint8Array) {
    const position = Number(value[3]);
    assertPosition(position, false);
    if (BigInt(position) !== value[3]) throw new Error("ORDERING_EVIDENCE_INVALID");
    return { kind: "ordered-entry", entry: {
      historyId: value[2],
      position,
      recordId: value[4],
      previousRoot: value[5],
      root: value[6],
      bytes: value[7]
    } };
  }
  if (value[1] === "prefix-certificate" && value.length === 7 && value[2] instanceof Uint8Array && typeof value[3] === "string" && typeof value[4] === "bigint" && typeof value[5] === "string" && value[6] instanceof Uint8Array) {
    const position = Number(value[4]);
    assertPosition(position, true);
    if (BigInt(position) !== value[4]) throw new Error("ORDERING_EVIDENCE_INVALID");
    return { kind: "prefix-certificate", certificate: {
      configuration: value[2],
      historyId: value[3],
      position,
      root: value[5],
      signature: value[6]
    } };
  }
  throw new Error("ORDERING_EVIDENCE_INVALID");
}
var CoordinatedHistoryPolicy = class _CoordinatedHistoryPolicy {
  #configuration;
  #store;
  #key;
  #quotaBytes;
  #mutex = new Mutex();
  // Entry roots authenticate bytes, not the authority's choice of position.
  // Retain competing untrusted alternatives until a certificate selects one.
  #entries = /* @__PURE__ */ new Map();
  #selectedEntries = /* @__PURE__ */ new Map();
  #certificates = /* @__PURE__ */ new Map();
  #progress;
  #finality;
  constructor(configuration, store, root, quotaBytes) {
    this.#configuration = structuredClone(configuration);
    this.#store = store;
    this.#key = `history/${bytesToHex(configuration.groupId)}/coordinated`;
    this.#quotaBytes = quotaBytes;
    this.#progress = { receivedThrough: 0, verifiedThrough: 0, certifiedThrough: 0, finalThrough: 0, root, missing: [] };
    this.#finality = {
      checkpointId: root,
      receivedThrough: 0,
      includedThrough: 0,
      closedReceiptThrough: 0,
      closedThroughMs: -1n,
      records: [],
      closures: []
    };
  }
  static async open(configuration, store, options = {}) {
    encodeHistoryConfiguration(configuration);
    const quotaBytes = options.quotaBytes ?? DEFAULT_EVIDENCE_QUOTA_BYTES;
    if (!Number.isSafeInteger(quotaBytes) || quotaBytes < 1024 || quotaBytes > MAX_LOCAL_HISTORY_BYTES) throw new Error("HISTORY_STORAGE_QUOTA_INVALID");
    const policy = new _CoordinatedHistoryPolicy(configuration, store, await orderedGenesisRoot(configuration.historyId), quotaBytes);
    const saved = await store.get(policy.#key);
    if (saved !== null) {
      if (saved.length > quotaBytes) throw new Error("HISTORY_STORAGE_QUOTA_EXCEEDED");
      const decoded = decodeRetainedHistory(saved, quotaBytes, MAX_RETAINED_EVIDENCE);
      if (!Array.isArray(decoded) || decoded.length !== 3 || decoded[0] !== 1n || !(decoded[1] instanceof Uint8Array) || !equalBytes(decoded[1], encodeHistoryConfiguration(configuration)) || !Array.isArray(decoded[2])) throw new Error("HISTORY_STORED_CONFIGURATION_MISMATCH");
      for (const bytes3 of decoded[2]) {
        if (!(bytes3 instanceof Uint8Array)) throw new Error("HISTORY_STORED_EVIDENCE_INVALID");
        await policy.#validateAndInsert(decodeOrderingEvidence(bytes3), policy.#entries, policy.#certificates);
      }
      const evaluated = await policy.#evaluate(policy.#entries, policy.#certificates);
      policy.#progress = evaluated.progress;
      policy.#selectedEntries = evaluated.selectedEntries;
      policy.#finality = evaluated.finality;
      discardUncommittedAlternatives(policy.#entries, evaluated.selectedEntries);
    }
    return policy;
  }
  get progress() {
    return structuredClone(this.#progress);
  }
  get configuration() {
    return structuredClone(this.#configuration);
  }
  get closedThroughMs() {
    return this.#finality.closedThroughMs;
  }
  get closedReceiptThrough() {
    return this.#finality.closedReceiptThrough;
  }
  snapshot() {
    return structuredClone(this.#finality);
  }
  async ingestEvidence(bytes3) {
    let evidence;
    try {
      evidence = decodeOrderingEvidence(bytes3.slice());
    } catch {
      throw new Error("ORDERING_EVIDENCE_INVALID");
    }
    return this.ingest(evidence);
  }
  evidenceBytes() {
    return this.evidence().map(encodeOrderingEvidence);
  }
  boundaryForEntry(position) {
    return this.#finality.records.find((record) => record.entry.position === position)?.closureBoundary?.closedThroughMs ?? null;
  }
  admissionFloor(position) {
    const record = this.#finality.records.find((record2) => record2.entry.position === position);
    if (record === void 0) throw new Error("FINALITY_RECORD_NOT_INCLUDED");
    return record.admissionFloorMs;
  }
  isClosure(position) {
    return this.#finality.closures.some((closure) => closure.position === position);
  }
  entries(through = this.#progress.verifiedThrough) {
    assertPosition(through, true);
    if (through > this.#progress.verifiedThrough) throw new Error("HISTORY_PREFIX_INCOMPLETE");
    return Array.from({ length: through }, (_, i) => structuredClone(this.#selectedEntries.get(i + 1)));
  }
  evidence() {
    return [
      ...allEntries(this.#entries).sort((a, b) => a.position - b.position || a.root.localeCompare(b.root)).map((entry) => ({ kind: "ordered-entry", entry: structuredClone(entry) })),
      ...[...this.#certificates.values()].sort((a, b) => a.position - b.position).map((certificate) => ({ kind: "prefix-certificate", certificate: structuredClone(certificate) }))
    ];
  }
  async ingest(evidence) {
    return this.ingestBatch([evidence]);
  }
  /** Atomically retain one bounded page (up to 128 entries plus its certificate). */
  async ingestBatch(evidence) {
    if (!Array.isArray(evidence) || evidence.length > 129) throw new Error("HISTORY_EVIDENCE_BATCH_INVALID");
    const captured = structuredClone(evidence);
    return this.#mutex.run(async () => {
      const entries = new Map([...this.#entries].map(([position, alternatives]) => [position, new Map(alternatives)]));
      const certificates = new Map(this.#certificates);
      let changed = false;
      for (const item of captured) {
        const inserted = await this.#validateAndInsert(item, entries, certificates);
        changed ||= inserted;
      }
      if (!changed) return this.progress;
      const { progress, selectedEntries, finality } = await this.#evaluate(entries, certificates);
      if (progress.finalThrough < this.#progress.finalThrough) throw new Error("HISTORY_FINAL_PREFIX_REGRESSION");
      discardUncommittedAlternatives(entries, selectedEntries);
      const all = [
        ...allEntries(entries).map((entry) => ({ kind: "ordered-entry", entry })),
        ...[...certificates.values()].map((certificate) => ({ kind: "prefix-certificate", certificate }))
      ];
      if (all.length > MAX_RETAINED_EVIDENCE) throw new Error("HISTORY_STORAGE_QUOTA_EXCEEDED");
      const persisted = encodeCanonicalCbor([
        1n,
        encodeHistoryConfiguration(this.#configuration),
        all.map(encodeOrderingEvidence)
      ]);
      if (persisted.length > this.#quotaBytes) throw new Error("HISTORY_STORAGE_QUOTA_EXCEEDED");
      await this.#store.put(this.#key, persisted);
      this.#entries = entries;
      this.#certificates = certificates;
      this.#selectedEntries = selectedEntries;
      this.#progress = progress;
      this.#finality = finality;
      return this.progress;
    });
  }
  async #validateAndInsert(evidence, entries, certificates) {
    if (evidence.kind === "ordered-entry") {
      const entry = evidence.entry;
      if (entry.historyId !== this.#configuration.historyId) throw new Error("HISTORY_ID_MISMATCH");
      await verifyOrderedEntry(entry);
      const final = this.#selectedEntries.get(entry.position);
      if (final !== void 0 && final.root !== entry.root) {
        throw new Error("HISTORY_POSITION_CONFLICT");
      }
      const alternatives = entries.get(entry.position) ?? /* @__PURE__ */ new Map();
      const previous = alternatives.get(entry.root);
      if (previous !== void 0 && !equalBytes(previous.bytes, entry.bytes)) throw new Error("HISTORY_RECORD_HASH_COLLISION");
      alternatives.set(entry.root, entry);
      entries.set(entry.position, alternatives);
      return previous === void 0;
    } else {
      const certificate = evidence.certificate;
      await verifyPrefixCertificate(certificate, this.#configuration);
      const previous = certificates.get(certificate.position);
      if (previous !== void 0 && previous.root !== certificate.root) throw new Error("HISTORY_AUTHORITY_EQUIVOCATION");
      certificates.set(certificate.position, certificate);
      return previous === void 0;
    }
  }
  async #evaluate(entries, certificates) {
    const genesisRoot = await orderedGenesisRoot(this.#configuration.historyId);
    let finalThrough = 0;
    let finalRoot = genesisRoot;
    const selectedEntries = /* @__PURE__ */ new Map();
    const missing = /* @__PURE__ */ new Set();
    const genesisCertificate = certificates.get(0);
    if (genesisCertificate !== void 0 && genesisCertificate.root !== genesisRoot) throw new Error("HISTORY_CERTIFICATE_ROOT_MISMATCH");
    for (const certificate of [...certificates.values()].sort((a, b) => a.position - b.position)) {
      if (certificate.position === 0) continue;
      let root = certificate.root;
      let position = certificate.position;
      const path = /* @__PURE__ */ new Map();
      let complete = true;
      while (position > finalThrough) {
        const covered = certificates.get(position);
        if (covered !== void 0 && covered.root !== root) throw new Error("HISTORY_AUTHORITY_EQUIVOCATION");
        const entry = entries.get(position)?.get(root);
        if (entry === void 0) {
          missing.add(position);
          complete = false;
          break;
        }
        path.set(position, entry);
        root = entry.previousRoot;
        position -= 1;
      }
      if (!complete) continue;
      if (root !== finalRoot) throw new Error("HISTORY_AUTHORITY_EQUIVOCATION");
      for (const [index, entry] of path) selectedEntries.set(index, entry);
      finalThrough = certificate.position;
      finalRoot = certificate.root;
    }
    const receivedThrough = maximumPosition(entries.keys());
    const certifiedThrough = maximumPosition(certificates.keys());
    const windowEnd = Math.min(certifiedThrough, finalThrough + 1024);
    for (let position = finalThrough + 1; position <= windowEnd; position += 1) {
      if (!entries.has(position)) missing.add(position);
    }
    const gaps = [...missing].filter((position) => position > finalThrough).sort((a, b) => a - b).slice(0, 1024);
    const finality = finalThrough === this.#finality.includedThrough && finalRoot === this.#finality.checkpointId ? { ...this.#finality, receivedThrough } : await evaluateFinalitySnapshot(
      this.#configuration,
      [...selectedEntries.values()].sort((left, right) => left.position - right.position),
      receivedThrough
    );
    return {
      progress: {
        receivedThrough,
        verifiedThrough: finalThrough,
        certifiedThrough,
        finalThrough,
        root: finalRoot,
        missing: gaps
      },
      selectedEntries,
      finality
    };
  }
};
function allEntries(entries) {
  const result = [];
  for (const alternatives of entries.values()) {
    for (const entry of alternatives.values()) result.push(entry);
  }
  return result;
}
function discardUncommittedAlternatives(entries, selected) {
  for (const [position, entry] of selected) entries.set(position, /* @__PURE__ */ new Map([[entry.root, entry]]));
}
function maximumPosition(values) {
  let maximum = 0;
  for (const value of values) if (value > maximum) maximum = value;
  return maximum;
}
function decodeRetainedHistory(bytes3, maxBytes, maxItems) {
  return assertCanonicalCbor2(bytes3, {
    maxBytes,
    maxItems,
    maxDepth: 4,
    maxTextBytes: 1024,
    maxByteStringBytes: 1048576 + 2048
  });
}
function assertHistoryId(value) {
  if (!/^h_[0-9a-f]{32}$/u.test(value)) throw new Error("HISTORY_ID_INVALID");
}
function assertHash(value) {
  if (!/^[0-9a-f]{64}$/u.test(value)) throw new Error("HISTORY_HASH_INVALID");
}
function assertPosition(value, zero) {
  if (!Number.isSafeInteger(value) || value < (zero ? 0 : 1)) throw new Error("HISTORY_POSITION_INVALID");
}

// packages/node-core/src/operations.ts
var DurableOperationJournal = class {
  #store;
  #prefix;
  #mutex = new Mutex();
  constructor(store, namespace2) {
    if (namespace2.length === 0) throw new Error("OPERATION_NAMESPACE_REQUIRED");
    this.#store = store;
    this.#prefix = namespace2;
  }
  async run(options) {
    const { operationId, prepare, apply } = options;
    const fingerprint = options.fingerprint.slice();
    validateOperationId(operationId);
    return this.#mutex.run(async () => {
      const previous = await this.#completed(operationId);
      if (previous !== null) return matching(previous, fingerprint);
      const pending = await this.#pending();
      if (pending !== null) {
        if (pending.id === operationId) matching(pending, fingerprint);
        await this.#finish(pending, apply);
        if (pending.id === operationId) return pending.payload.slice();
      }
      const prepared = {
        id: operationId,
        fingerprint,
        payload: (await prepare()).slice()
      };
      await this.#store.put(`${this.#prefix}/pending`, encode(prepared));
      await this.#finish(prepared, apply);
      return prepared.payload.slice();
    });
  }
  async recover(apply) {
    await this.#mutex.run(async () => {
      const pending = await this.#pending();
      if (pending !== null) await this.#finish(pending, apply);
    });
  }
  async lookup(operationId) {
    validateOperationId(operationId);
    const completed = await this.#completed(operationId);
    if (completed !== null) return completed.payload.slice();
    const pending = await this.#pending();
    if (pending?.id === operationId) return pending.payload.slice();
    return (await this.#completed(operationId))?.payload.slice() ?? null;
  }
  async #finish(prepared, apply) {
    const completed = await this.#completed(prepared.id);
    if (completed !== null) {
      matching(completed, prepared.fingerprint);
      if (!equalBytes(completed.payload, prepared.payload)) throw new Error("OPERATION_STORE_CONFLICT");
    } else {
      await apply(prepared.payload.slice());
      await this.#store.put(this.#key(prepared.id), encode(prepared));
    }
    await this.#store.put(`${this.#prefix}/pending`, encodeCanonicalCbor(null));
  }
  async #pending() {
    const bytes3 = await this.#store.get(`${this.#prefix}/pending`);
    return bytes3 === null ? null : decode(bytes3);
  }
  async #completed(id2) {
    const bytes3 = await this.#store.get(this.#key(id2));
    const result = bytes3 === null ? null : decode(bytes3);
    if (result !== null && result.id !== id2) throw new Error("OPERATION_STORE_CONFLICT");
    return result;
  }
  #key(id2) {
    return `${this.#prefix}/completed/${encodeURIComponent(id2)}`;
  }
};
function validateOperationId(value) {
  if (value.length === 0 || value.length > 512 || [...value].some((character) => character.charCodeAt(0) < 32)) {
    throw new Error("OPERATION_ID_INVALID");
  }
}
function matching(operation, fingerprint) {
  if (!equalBytes(operation.fingerprint, fingerprint)) throw new Error("OPERATION_ID_CONFLICT");
  return operation.payload.slice();
}
function encode(operation) {
  return encodeCanonicalCbor([1n, operation.id, operation.fingerprint, operation.payload]);
}
function decode(bytes3) {
  const value = assertCanonicalCbor2(bytes3);
  if (value === null) return null;
  if (!Array.isArray(value) || value.length !== 4 || value[0] !== 1n || typeof value[1] !== "string" || !(value[2] instanceof Uint8Array) || !(value[3] instanceof Uint8Array)) throw new Error("OPERATION_STORE_INVALID");
  validateOperationId(value[1]);
  return { id: value[1], fingerprint: value[2], payload: value[3] };
}
var MemoryOperationStore = class {
  #values = /* @__PURE__ */ new Map();
  async get(key) {
    return this.#values.get(key)?.slice() ?? null;
  }
  async put(key, value) {
    this.#values.set(key, value.slice());
  }
};

// packages/node-core/src/enrollment.ts
var storeLocks = /* @__PURE__ */ new WeakMap();
function storeLock(store) {
  let mutex = storeLocks.get(store);
  if (mutex === void 0) {
    mutex = new Mutex();
    storeLocks.set(store, mutex);
  }
  return mutex;
}
async function loadOrCreateEnrollmentIdentity(store, namespace2) {
  validateOperationId(namespace2);
  return storeLock(store).run(async () => {
    const key = `enrollment/identity/${encodeURIComponent(namespace2)}`;
    let saved = await store.get(key);
    if (saved === null) {
      const signing = await generateEd25519KeyPair();
      const reader = await generateX25519KeyPair();
      saved = encodeCanonicalCbor([
        1n,
        signing.publicKeyBytes,
        await exportEd25519PrivateKey(signing.privateKey),
        reader.publicKeyBytes,
        await exportX25519PrivateKey(reader.privateKey)
      ]);
      await store.put(key, saved);
    }
    return decodeEnrollmentIdentity(saved);
  });
}
async function decodeEnrollmentIdentity(saved) {
  const value = array(saved, 5);
  if (value[0] !== 1n) throw new Error("ENROLLMENT_IDENTITY_INVALID");
  const signingPublicKey = bytes2(value[1], 32);
  const readerPublicKey = bytes2(value[3], 32);
  const signing = {
    publicKeyBytes: signingPublicKey,
    publicKey: await importEd25519PublicKey(signingPublicKey),
    privateKey: await importEd25519PrivateKey(bytes2(value[2]))
  };
  const reader = {
    publicKeyBytes: readerPublicKey,
    publicKey: await importX25519PublicKey(readerPublicKey),
    privateKey: await importX25519PrivateKey(bytes2(value[4]))
  };
  return { signing, reader };
}
async function prepareEnrollmentRequest(options) {
  const descriptor = structuredClone(options.descriptor), store = options.store;
  const identity = { ...options.identity, publicKeyBytes: options.identity.publicKeyBytes.slice() };
  const readerPublicKey = options.readerPublicKey.slice(), requestId = options.requestId, transportAuthor = options.transportAuthor;
  const requestedRoles = roles(options.requestedRoles);
  const writerProgram = options.writerProgram === void 0 ? void 0 : normalizeProgramRights(options.writerProgram);
  await verifyEnrollmentDescriptor(descriptor);
  const request = {
    requestId,
    groupId: descriptor.history.groupId,
    genesisDigest: descriptor.history.genesisDigest,
    policyDigest: await historyConfigurationDigest(descriptor.history),
    executionManifestDigest: descriptor.history.executionManifestDigest,
    signingPublicKey: identity.publicKeyBytes,
    readerPublicKey,
    transportAuthor,
    requestedRoles,
    historyAccess: "full",
    ...writerProgram === void 0 ? {} : { writerProgram }
  };
  const payload = encodeEnrollmentRequest(request);
  return storeLock(store).run(async () => {
    const key = `enrollment/request/${bytesToHex2(request.groupId)}/${encodeURIComponent(request.requestId)}`;
    const saved = await store.get(key);
    if (saved !== null) {
      const original = decodeSignedEnrollmentRequest(saved);
      if (!equalBytes(encodeEnrollmentRequest(original.request), payload)) throw new Error("ENROLLMENT_REQUEST_ID_CONFLICT");
      if (!await verifySignedEnrollmentRequest(original)) throw new Error("ENROLLMENT_STORED_REQUEST_INVALID");
      return original;
    }
    const signed = { request, signature: await signDomain(DOMAINS.enrollmentRequest, payload, identity.privateKey) };
    await store.put(key, encodeSignedEnrollmentRequest(signed));
    return signed;
  });
}
async function verifyEnrollmentDescriptor(descriptor) {
  descriptor = structuredClone(descriptor);
  const { genesis, history } = descriptor;
  if (!await verifySignedGenesis(genesis) || descriptor.groupRoute.length !== 32 || !equalBytes(genesis.manifest.groupId, history.groupId) || !equalBytes(await hashDomain2(DOMAINS.genesis, encodeGenesisManifest(genesis.manifest)), history.genesisDigest) || !equalBytes(genesis.manifest.schemaId, history.executionManifestDigest)) throw new Error("ENROLLMENT_DESCRIPTOR_INVALID");
  const configured = genesis.manifest.historyPolicy;
  if (configured === void 0) {
    if (history.kind !== "peer") throw new Error("ENROLLMENT_POLICY_NOT_AUTHENTICATED");
  } else if (configured.kind !== history.kind || !equalBytes(configured.executionManifestDigest, history.executionManifestDigest) || (configured.providerId ?? (configured.kind === "peer" ? "peer-validators-v1" : "signed-inclusion-v1")) !== (history.providerId ?? (history.kind === "peer" ? "peer-validators-v1" : "signed-inclusion-v1")) || !equalBytes(configured.providerParameters ?? new Uint8Array(), history.providerParameters ?? new Uint8Array()) || history.kind === "coordinated" && (configured.historyId !== history.historyId || configured.authorityPublicKey === void 0 || !equalBytes(configured.authorityPublicKey, history.authorityPublicKey))) {
    throw new Error("ENROLLMENT_POLICY_NOT_AUTHENTICATED");
  }
}
function encodeEnrollmentRequest(request) {
  validateOperationId(request.requestId);
  for (const value of [
    request.groupId,
    request.genesisDigest,
    request.policyDigest,
    request.executionManifestDigest,
    request.signingPublicKey,
    request.readerPublicKey
  ]) if (value.length !== 32) throw new Error("ENROLLMENT_REQUEST_INVALID");
  if (request.transportAuthor.length === 0 || request.transportAuthor.length > 512 || request.historyAccess !== "full") {
    throw new Error("ENROLLMENT_REQUEST_INVALID");
  }
  if (request.writerProgram !== void 0 && !request.requestedRoles.includes("writer")) throw new Error("ENROLLMENT_PROGRAM_WITHOUT_WRITER");
  return encodeCanonicalCbor([
    2n,
    request.requestId,
    request.groupId,
    request.genesisDigest,
    request.policyDigest,
    request.executionManifestDigest,
    request.signingPublicKey,
    request.readerPublicKey,
    request.transportAuthor,
    roles(request.requestedRoles),
    request.historyAccess,
    rightsValue(request.writerProgram)
  ]);
}
function encodeSignedEnrollmentRequest(signed) {
  if (signed.signature.length !== 64) throw new Error("ENROLLMENT_REQUEST_INVALID");
  return encodeCanonicalCbor([encodeEnrollmentRequest(signed.request), signed.signature]);
}
function decodeSignedEnrollmentRequest(encoded) {
  const signed = array(encoded, 2);
  const value = array(bytes2(signed[0]), 12);
  if (value[0] !== 2n || value[10] !== "full") throw new Error("ENROLLMENT_REQUEST_INVALID");
  const request = {
    requestId: string(value[1]),
    groupId: bytes2(value[2], 32),
    genesisDigest: bytes2(value[3], 32),
    policyDigest: bytes2(value[4], 32),
    executionManifestDigest: bytes2(value[5], 32),
    signingPublicKey: bytes2(value[6], 32),
    readerPublicKey: bytes2(value[7], 32),
    transportAuthor: string(value[8]),
    requestedRoles: rolesValue(value[9]),
    historyAccess: "full",
    ...value[11] === null ? {} : { writerProgram: rightsFromValue(value[11]) }
  };
  if (!equalBytes(encodeEnrollmentRequest(request), bytes2(signed[0]))) throw new Error("ENROLLMENT_REQUEST_INVALID");
  return { request, signature: bytes2(signed[1], 64) };
}
async function verifySignedEnrollmentRequest(signed) {
  signed = decodeSignedEnrollmentRequest(encodeSignedEnrollmentRequest(signed));
  return verifyDomain(DOMAINS.enrollmentRequest, encodeEnrollmentRequest(signed.request), signed.signature, signed.request.signingPublicKey);
}
var EnrollmentIssuer = class {
  #options;
  #mutex;
  constructor(options) {
    this.#options = { ...options, descriptor: structuredClone(options.descriptor) };
    this.#mutex = storeLock(options.store);
  }
  async approve(signed, decision) {
    signed = decodeSignedEnrollmentRequest(encodeSignedEnrollmentRequest(signed));
    decision = structuredClone(decision);
    validateOperationId(decision.operationId);
    await verifyEnrollmentDescriptor(this.#options.descriptor);
    const request = signed.request;
    const grantedRoles = roles(decision.roles);
    if (!await verifySignedEnrollmentRequest(signed) || !equalBytes(request.groupId, this.#options.descriptor.history.groupId) || !equalBytes(request.genesisDigest, this.#options.descriptor.history.genesisDigest) || !equalBytes(request.policyDigest, await historyConfigurationDigest(this.#options.descriptor.history)) || !equalBytes(request.executionManifestDigest, this.#options.descriptor.history.executionManifestDigest) || grantedRoles.some((role) => !request.requestedRoles.includes(role)) || decision.writerProgram !== void 0 && !grantedRoles.includes("writer") || grantedRoles.includes("writer") && !programRightsSubset(decision.writerProgram, request.writerProgram)) throw new Error("ENROLLMENT_REQUEST_UNAUTHORIZED");
    const requestBytes = encodeSignedEnrollmentRequest(signed);
    const requestDigest = await hashDomain2(DOMAINS.enrollmentRequest, requestBytes);
    const fingerprint = encodeCanonicalCbor([requestBytes, grantedRoles, decision.grantFullHistory, rightsValue(decision.writerProgram)]);
    const prefix = `enrollment/issuer/${bytesToHex2(request.groupId)}`;
    const key = `${prefix}/request/${bytesToHex2(request.signingPublicKey)}/${encodeURIComponent(request.requestId)}`;
    const operationKey = `${prefix}/operation/${encodeURIComponent(decision.operationId)}`;
    const operationId = `enrollment:${bytesToHex2(requestDigest)}`;
    return this.#mutex.run(async () => {
      const priorOperation = await this.#options.store.get(operationKey);
      if (priorOperation !== null && !equalBytes(priorOperation, fingerprint)) throw new Error("OPERATION_ID_CONFLICT");
      let state = decodeApprovalState(await this.#options.store.get(key));
      if (state !== null && !equalBytes(state.fingerprint, fingerprint)) throw new Error("ENROLLMENT_DECISION_CONFLICT");
      await this.#options.store.put(operationKey, fingerprint);
      if (state === null) {
        state = { fingerprint, revision: null, target: null, approval: null };
        await this.#options.store.put(key, encodeApprovalState(state));
      }
      if (state.approval !== null) return state.approval;
      if (state.revision === null) {
        const grants = grantedRoles.map((role) => ({
          subjectId: request.signingPublicKey,
          signingPublicKey: request.signingPublicKey,
          role,
          transportAuthor: request.transportAuthor,
          ...role === "reader" ? { hpkePublicKey: request.readerPublicKey } : {},
          ...role !== "writer" || decision.writerProgram === void 0 ? {} : { program: normalizeProgramRights(decision.writerProgram) }
        }));
        const revision2 = await this.#options.governance.publishCapabilityChange({ grants }, this.#options.rootPrivateKey, { operationId: `${operationId}:grants` });
        state = { ...state, revision: revision2 };
        await this.#options.store.put(key, encodeApprovalState(state));
      }
      if (this.#options.governance.currentEpoch === null) {
        await this.#options.governance.rotateEpoch(this.#options.rootPrivateKey, void 0, { operationId: `${operationId}:initial-epoch` });
      }
      if (decision.grantFullHistory) {
        await this.#options.governance.grantHistoricalAccess(request.signingPublicKey, this.#options.rootPrivateKey, { operationId: `${operationId}:history` });
      }
      if (state.target === null) {
        const captured = structuredClone(await this.#options.captureFinalTarget());
        if (!equalBytes(captured.executionManifestDigest, request.executionManifestDigest)) throw new Error("ENROLLMENT_ENGINE_MISMATCH");
        const target = { ...captured, requiredEpochs: uniqueEpochs([...captured.requiredEpochs, ...this.#options.governance.knownEpochs]) };
        state = { ...state, target };
        await this.#options.store.put(key, encodeApprovalState(state));
      }
      const revision = state.revision;
      const approval = {
        requestId: request.requestId,
        requestDigest,
        groupId: request.groupId,
        membershipRevision: await capabilityRevisionDigest(revision.revision),
        grantedRevision: revision.revision.revision,
        roles: grantedRoles,
        capabilityIds: await Promise.all(revision.revision.grants.map(capabilityId)),
        fullHistoryGranted: decision.grantFullHistory,
        target: state.target,
        ...decision.writerProgram === void 0 ? {} : { writerProgram: normalizeProgramRights(decision.writerProgram) }
      };
      const result = { approval, signature: await signDomain(DOMAINS.enrollmentApproval, encodeEnrollmentApproval(approval), this.#options.rootPrivateKey) };
      await this.#options.store.put(key, encodeApprovalState({ ...state, approval: result }));
      return result;
    });
  }
};
async function enrollmentProgress(options) {
  const progress = (state, missingEpochs = [], granted = []) => ({ state, missingEpochs, roles: granted });
  const { isFinalTargetApplied, ...evidence } = options;
  options = { ...structuredClone(evidence), isFinalTargetApplied };
  if (options.approval === null) return progress("requested");
  const { approval } = options.approval;
  const request = options.request.request;
  await verifyEnrollmentApproval(options.descriptor, options.request, options.approval);
  if (!equalBytes(options.activeMembership.groupId, request.groupId)) throw new Error("ENROLLMENT_MEMBERSHIP_GROUP_MISMATCH");
  if (options.activeMembership.revision < approval.grantedRevision) return progress("approved", [], approval.roles);
  for (let i = 0; i < approval.capabilityIds.length; i += 1) {
    const capability = options.activeMembership.capabilities.get(bytesToHex2(approval.capabilityIds[i]));
    if (capability === void 0 || capability.grant.role !== approval.roles[i] || !equalBytes(capability.grant.subjectId, request.signingPublicKey) || !equalBytes(capability.grant.signingPublicKey, request.signingPublicKey) || capability.grant.transportAuthor !== request.transportAuthor || capability.grant.validFromRevision !== approval.grantedRevision || capability.grantedAtRevision !== approval.grantedRevision || capability.grant.role === "writer" && !equalBytes(encodeCanonicalCbor(rightsValue(capability.grant.program)), encodeCanonicalCbor(rightsValue(approval.writerProgram))) || capability.grant.role === "reader" && (capability.grant.hpkePublicKey === void 0 || !equalBytes(capability.grant.hpkePublicKey, request.readerPublicKey))) throw new Error("ENROLLMENT_APPROVAL_INVALID");
    if (!isCapabilityActive(capability, options.activeMembership.revision)) return progress("revoked", [], approval.roles);
  }
  if (!options.connected) return progress("authorized-disconnected", [], approval.roles);
  if (!equalBytes(options.executionManifestDigest, approval.target.executionManifestDigest)) return progress("unsupported-engine", [], approval.roles);
  const available = new Set(options.availableEpochs.map(String));
  const missing = approval.target.requiredEpochs.filter((epoch) => !available.has(String(epoch)));
  if (!approval.fullHistoryGranted || missing.length > 0) return progress("awaiting-keys", missing, approval.roles);
  if (!await options.isFinalTargetApplied(approval.target)) return progress("awaiting-history", [], approval.roles);
  return progress("ready", [], approval.roles);
}
async function verifyEnrollmentApproval(descriptor, signedRequest, signed) {
  descriptor = structuredClone(descriptor);
  signedRequest = decodeSignedEnrollmentRequest(encodeSignedEnrollmentRequest(signedRequest));
  signed = decodeSignedEnrollmentApproval(encodeSignedEnrollmentApproval(signed));
  const { approval, signature } = signed;
  const request = signedRequest.request;
  if (!await verifyDomain(DOMAINS.enrollmentApproval, encodeEnrollmentApproval(approval), signature, descriptor.genesis.manifest.rootAdminPublicKey) || !await verifySignedEnrollmentRequest(signedRequest) || approval.requestId !== request.requestId || !equalBytes(approval.groupId, request.groupId) || !equalBytes(request.groupId, descriptor.history.groupId) || !equalBytes(request.genesisDigest, descriptor.history.genesisDigest) || !equalBytes(request.policyDigest, await historyConfigurationDigest(descriptor.history)) || !equalBytes(approval.target.executionManifestDigest, request.executionManifestDigest) || approval.roles.some((role) => !request.requestedRoles.includes(role)) || approval.roles.includes("writer") && !programRightsSubset(approval.writerProgram, request.writerProgram) || !equalBytes(approval.requestDigest, await hashDomain2(DOMAINS.enrollmentRequest, encodeSignedEnrollmentRequest(signedRequest)))) {
    throw new Error("ENROLLMENT_APPROVAL_INVALID");
  }
}
function encodeEnrollmentApproval(approval) {
  validateOperationId(approval.requestId);
  if (approval.capabilityIds.length !== approval.roles.length || approval.grantedRevision < 1n) throw new Error("ENROLLMENT_APPROVAL_INVALID");
  if (approval.writerProgram !== void 0 && !approval.roles.includes("writer")) throw new Error("ENROLLMENT_PROGRAM_WITHOUT_WRITER");
  for (const id2 of [approval.requestDigest, approval.groupId, approval.membershipRevision, ...approval.capabilityIds]) {
    if (id2.length !== 32) throw new Error("ENROLLMENT_APPROVAL_INVALID");
  }
  return encodeCanonicalCbor([
    2n,
    approval.requestId,
    approval.requestDigest,
    approval.groupId,
    approval.membershipRevision,
    approval.grantedRevision,
    roles(approval.roles),
    [...approval.capabilityIds],
    approval.fullHistoryGranted,
    targetValue(approval.target),
    rightsValue(approval.writerProgram)
  ]);
}
function encodeSignedEnrollmentApproval(signed) {
  if (signed.signature.length !== 64) throw new Error("ENROLLMENT_APPROVAL_INVALID");
  return encodeCanonicalCbor([encodeEnrollmentApproval(signed.approval), signed.signature]);
}
function decodeSignedEnrollmentApproval(encoded) {
  const signed = array(encoded, 2);
  const value = array(bytes2(signed[0]), 11);
  if (value[0] !== 2n || typeof value[5] !== "bigint" || !Array.isArray(value[7]) || typeof value[8] !== "boolean") {
    throw new Error("ENROLLMENT_APPROVAL_INVALID");
  }
  const approval = {
    requestId: string(value[1]),
    requestDigest: bytes2(value[2], 32),
    groupId: bytes2(value[3], 32),
    membershipRevision: bytes2(value[4], 32),
    grantedRevision: value[5],
    roles: rolesValue(value[6]),
    capabilityIds: value[7].map((id2) => bytes2(id2, 32)),
    fullHistoryGranted: value[8],
    target: targetFromValue(value[9]),
    ...value[10] === null ? {} : { writerProgram: rightsFromValue(value[10]) }
  };
  if (!equalBytes(encodeEnrollmentApproval(approval), bytes2(signed[0]))) throw new Error("ENROLLMENT_APPROVAL_INVALID");
  return { approval, signature: bytes2(signed[1], 64) };
}
function encodeApprovalState(state) {
  return encodeCanonicalCbor([
    1n,
    state.fingerprint,
    state.revision === null ? null : encodeSignedCapabilityRevision(state.revision),
    state.target === null ? null : targetValue(state.target),
    state.approval === null ? null : encodeSignedEnrollmentApproval(state.approval)
  ]);
}
function decodeApprovalState(encoded) {
  if (encoded === null) return null;
  const value = array(encoded, 5);
  if (value[0] !== 1n) throw new Error("ENROLLMENT_STATE_INVALID");
  return {
    fingerprint: bytes2(value[1]),
    revision: value[2] === null ? null : decodeSignedCapabilityRevision(bytes2(value[2])),
    target: value[3] === null ? null : targetFromValue(value[3]),
    approval: value[4] === null ? null : decodeSignedEnrollmentApproval(bytes2(value[4]))
  };
}
function targetValue(target) {
  if (target.frontier.length === 0 || target.executionManifestDigest.length !== 32) throw new Error("ENROLLMENT_TARGET_INVALID");
  return [target.frontier, uniqueEpochs(target.requiredEpochs), target.executionManifestDigest];
}
function targetFromValue(value) {
  if (!Array.isArray(value) || value.length !== 3 || !Array.isArray(value[1]) || !value[1].every((item) => typeof item === "bigint")) {
    throw new Error("ENROLLMENT_TARGET_INVALID");
  }
  const fields = value;
  const epochs = [];
  for (const epoch of fields[1]) {
    if (typeof epoch !== "bigint") throw new Error("ENROLLMENT_TARGET_INVALID");
    epochs.push(epoch);
  }
  const target = { frontier: bytes2(fields[0]), requiredEpochs: uniqueEpochs(epochs), executionManifestDigest: bytes2(fields[2], 32) };
  targetValue(target);
  return target;
}
function uniqueEpochs(values) {
  if (values.some((epoch) => epoch < 0n)) throw new Error("ENROLLMENT_TARGET_INVALID");
  return [...new Set(values)].sort((a, b) => a < b ? -1 : a > b ? 1 : 0);
}
function roles(values) {
  if (!values.includes("reader") || values.some((role) => role !== "reader" && role !== "writer") || new Set(values).size !== values.length) {
    throw new Error("ENROLLMENT_ROLES_INVALID");
  }
  return values.includes("writer") ? ["reader", "writer"] : ["reader"];
}
function rolesValue(value) {
  if (!Array.isArray(value) || !value.every((role) => role === "reader" || role === "writer")) throw new Error("ENROLLMENT_ROLES_INVALID");
  return roles(value);
}
function array(encoded, length) {
  const value = assertCanonicalCbor2(encoded);
  if (!Array.isArray(value) || value.length !== length) throw new Error("ENROLLMENT_ENCODING_INVALID");
  return value;
}
function bytes2(value, length) {
  if (!(value instanceof Uint8Array) || length !== void 0 && value.length !== length) throw new Error("ENROLLMENT_ENCODING_INVALID");
  return value;
}
function string(value) {
  if (typeof value !== "string") throw new Error("ENROLLMENT_ENCODING_INVALID");
  return value;
}
function rightsValue(input) {
  if (input === void 0) return null;
  const rights = normalizeProgramRights(input);
  return [rights.sql, rights.topics, rights.signals, rights.forwarded];
}
function rightsFromValue(value) {
  if (!Array.isArray(value) || value.length !== 4 || typeof value[0] !== "boolean" || typeof value[3] !== "boolean" || !Array.isArray(value[1]) || !value[1].every((item) => typeof item === "string") || !Array.isArray(value[2]) || !value[2].every((item) => typeof item === "string")) throw new Error("ENROLLMENT_PROGRAM_INVALID");
  return normalizeProgramRights({ sql: value[0], topics: value[1], signals: value[2], forwarded: value[3] });
}

// packages/node-core/src/governance-activation.ts
function encodeGovernanceClosure(value) {
  for (const bytes3 of [value.groupId, value.membershipRevision, value.nextMembershipRevision, value.validatorId, value.validatorCapability]) {
    if (bytes3.length !== 32) throw new Error("GOVERNANCE_CLOSURE_INVALID");
  }
  if (value.throughMs < 0n || value.lastAdmissionSequence < 0n) throw new Error("GOVERNANCE_CLOSURE_INVALID");
  return encodeCanonicalCbor([
    1n,
    value.groupId,
    value.membershipRevision,
    value.nextMembershipRevision,
    value.validatorId,
    value.validatorCapability,
    value.throughMs,
    value.lastAdmissionSequence
  ]);
}
async function verifyGovernanceClosure(signed) {
  return verifyDomain(DOMAINS.governanceClosure, encodeGovernanceClosure(signed.closure), signed.signature, signed.closure.validatorId);
}
var GovernanceActivationIndex = class {
  #kind;
  #groupId;
  #snapshots = /* @__PURE__ */ new Map();
  #activations;
  #validators;
  constructor(genesis, kind) {
    if (genesis.revision !== 0n) throw new Error("GOVERNANCE_ACTIVATION_GENESIS_REQUIRED");
    this.#kind = kind;
    this.#groupId = genesis.groupId.slice();
    this.#validators = activeValidators(genesis);
    this.#activations = [{ snapshot: structuredClone(genesis), after: -1n }];
    this.observe(genesis);
  }
  /** Register a snapshot already verified by the signed governance reducer. */
  observe(snapshot) {
    if (!equalBytes(snapshot.groupId, this.#groupId)) throw new Error("GOVERNANCE_ACTIVATION_GROUP_MISMATCH");
    this.#snapshots.set(bytesToHex2(snapshot.revisionDigest), structuredClone(snapshot));
  }
  get activeSnapshot() {
    return structuredClone(this.#activations[this.#activations.length - 1].snapshot);
  }
  get activationBoundary() {
    return this.#activations[this.#activations.length - 1].after;
  }
  /** The provider proved inclusion and closed this author-time boundary. */
  activateFinalized(snapshot, cutoffMs) {
    if (this.#kind !== "coordinated" || cutoffMs < 0n) throw new Error("GOVERNANCE_ACTIVATION_POLICY_MISMATCH");
    this.#activate(snapshot, cutoffMs < this.activationBoundary ? this.activationBoundary : cutoffMs);
  }
  async activatePeer(snapshot, evidence) {
    if (this.#kind !== "peer") throw new Error("GOVERNANCE_ACTIVATION_POLICY_MISMATCH");
    const previous = this.activeSnapshot;
    this.#assertSuccessor(snapshot);
    if (this.#validators.length === 0 || evidence.length !== this.#validators.length) throw new Error("GOVERNANCE_CLOSURE_INCOMPLETE");
    const expected = new Map(this.#validators.map((item) => [bytesToHex2(item.id), item]));
    const remaining = new Set(expected.keys());
    let through = this.activationBoundary;
    for (const proof of evidence) {
      const signed = proof.signed;
      const closure = signed.closure;
      const id2 = bytesToHex2(closure.validatorCapability);
      const validator = expected.get(id2);
      if (validator === void 0 || !remaining.delete(id2) || !equalBytes(closure.groupId, this.#groupId) || !equalBytes(closure.membershipRevision, previous.revisionDigest) || !equalBytes(closure.nextMembershipRevision, snapshot.revisionDigest) || !equalBytes(closure.validatorId, validator.grant.signingPublicKey) || proof.transportAuthor !== validator.grant.transportAuthor || !await verifyGovernanceClosure(signed)) {
        throw new Error("GOVERNANCE_CLOSURE_INVALID");
      }
      if (proof.sequence <= 0n || proof.contiguousThrough < proof.sequence || proof.lastAdmissionSequence !== closure.lastAdmissionSequence || proof.lastAdmissionSequence >= proof.sequence || proof.maximumAdmittedTimestampMs > closure.throughMs) throw new Error("GOVERNANCE_CLOSURE_INCOMPLETE");
      if (closure.throughMs > through) through = closure.throughMs;
    }
    if (remaining.size !== 0) throw new Error("GOVERNANCE_CLOSURE_INCOMPLETE");
    this.#activate(snapshot, through);
    return through;
  }
  snapshotFor(context) {
    if (!equalBytes(context.groupId, this.#groupId) || !this.#snapshots.has(bytesToHex2(context.membershipRevision))) return null;
    if (this.#snapshots.get(bytesToHex2(context.membershipRevision)).revision > this.activeSnapshot.revision) return null;
    const point = context.authorTimestampMs;
    if (point === void 0 || point < 0n) return null;
    for (let index = this.#activations.length - 1; index >= 0; index -= 1) {
      const activation = this.#activations[index];
      if (point > activation.after) return structuredClone(activation.snapshot);
    }
    return null;
  }
  #activate(snapshot, after) {
    this.#assertSuccessor(snapshot);
    if (after < this.activationBoundary) throw new Error("GOVERNANCE_ACTIVATION_REGRESSION");
    this.observe(snapshot);
    this.#activations.push({ snapshot: structuredClone(snapshot), after });
  }
  #assertSuccessor(snapshot) {
    const active = this.activeSnapshot;
    if (!equalBytes(snapshot.groupId, this.#groupId) || snapshot.revision !== active.revision + 1n) {
      throw new Error("GOVERNANCE_ACTIVATION_CHAIN_INVALID");
    }
    if (!equalBytes(snapshot.rootAdminPublicKey, active.rootAdminPublicKey) || !equalBytes(snapshot.capabilityLogFeed, active.capabilityLogFeed)) throw new Error("GOVERNANCE_AUTHORITY_RECONFIGURATION_UNSUPPORTED");
    if (snapshot.policies.size !== active.policies.size || [...snapshot.policies.keys()].some((key) => !active.policies.has(key))) {
      throw new Error("GOVERNANCE_POLICY_RECONFIGURATION_UNSUPPORTED");
    }
    const validators = activeValidators(snapshot);
    if (validators.length !== this.#validators.length || validators.some((item, index) => !equalBytes(item.id, this.#validators[index].id))) throw new Error("GOVERNANCE_VALIDATOR_RECONFIGURATION_UNSUPPORTED");
  }
};
function activeValidators(snapshot) {
  return [...snapshot.capabilities.values()].filter((item) => item.grant.role === "validator" && isCapabilityActive(item, snapshot.revision)).sort((left, right) => bytesToHex2(left.id).localeCompare(bytesToHex2(right.id)));
}

// packages/node-core/src/ledger-record.ts
var MAX_LEDGER_RECORD_BYTES = 256 * 1024;
var MAX_LEDGER_INLINE_PAYLOAD_BYTES = MAX_LEDGER_RECORD_BYTES - 512;
var MAX_LEDGER_PAYLOAD_BYTES = 1024 * 1024;
var MAX_LEDGER_EPOCH_BYTES = 32;
var FORMAT2 = "chronolog/ledger-record";
var LedgerRecordError = class extends Error {
  constructor(code, detail, cause) {
    super(detail === void 0 ? code : `${code}: ${detail}`, cause === void 0 ? void 0 : { cause });
    this.code = code;
    this.name = "LedgerRecordError";
  }
  code;
};
async function createLedgerRecord(envelopeBytes) {
  if (!(envelopeBytes instanceof Uint8Array)) throw new LedgerRecordError("LEDGER_RECORD_INVALID");
  checkPayloadLength(envelopeBytes.length);
  const payload = ownBytes(envelopeBytes, "LEDGER_RECORD_INVALID");
  const envelope = envelopeMetadata(payload);
  if (!isKind(envelope.messageType)) throw new LedgerRecordError("LEDGER_KIND_UNSUPPORTED");
  if (envelope.messageType !== "candidate" && payload.length > MAX_LEDGER_INLINE_PAYLOAD_BYTES) {
    throw new LedgerRecordError("LEDGER_CONTROL_TOO_LARGE", `governance envelopes must not exceed ${MAX_LEDGER_INLINE_PAYLOAD_BYTES} bytes`);
  }
  const fields = {
    groupRoute: ownBytes(envelope.groupRoute, "LEDGER_RECORD_INVALID"),
    encryptionEpoch: envelope.encryptionEpoch === null ? null : ownBytes(envelope.encryptionEpoch, "LEDGER_RECORD_INVALID"),
    payloadHash: bytesToHex(await sha256(payload)),
    payloadLength: payload.length
  };
  const record = ownRecord(envelope.messageType === "candidate" ? { ...fields, kind: "candidate", inlinePayload: null } : { ...fields, kind: envelope.messageType, inlinePayload: payload });
  const recordBytes = encodeRecord(record);
  if (recordBytes.length > MAX_LEDGER_RECORD_BYTES) throw new LedgerRecordError("LEDGER_RECORD_TOO_LARGE");
  return { recordBytes, record, detachedPayload: record.kind === "candidate" ? payload : null };
}
function decodeLedgerRecord(recordBytes) {
  if (!(recordBytes instanceof Uint8Array)) throw new LedgerRecordError("LEDGER_RECORD_INVALID");
  if (recordBytes.length > MAX_LEDGER_RECORD_BYTES) throw new LedgerRecordError("LEDGER_RECORD_TOO_LARGE");
  const exact = ownBytes(recordBytes, "LEDGER_RECORD_INVALID");
  let value;
  try {
    value = assertCanonicalCbor2(exact, {
      maxBytes: MAX_LEDGER_RECORD_BYTES,
      maxDepth: 4,
      maxItems: 8,
      maxTextBytes: 128,
      maxByteStringBytes: MAX_LEDGER_INLINE_PAYLOAD_BYTES
    });
  } catch (cause) {
    throw new LedgerRecordError("LEDGER_RECORD_INVALID", void 0, cause);
  }
  if (!Array.isArray(value) || value.length !== 8) throw new LedgerRecordError("LEDGER_RECORD_INVALID");
  const wire = value;
  if (wire[0] !== 1n || wire[1] !== FORMAT2 || !isKind(wire[2]) || !(wire[3] instanceof Uint8Array) || !(wire[4] === null || wire[4] instanceof Uint8Array) || typeof wire[5] !== "string" || typeof wire[6] !== "bigint" || wire[6] < 1n || wire[6] > BigInt(MAX_LEDGER_PAYLOAD_BYTES) || !(wire[7] === null || wire[7] instanceof Uint8Array)) throw new LedgerRecordError("LEDGER_RECORD_INVALID");
  const fields = {
    groupRoute: wire[3],
    encryptionEpoch: wire[4],
    payloadHash: wire[5],
    payloadLength: Number(wire[6])
  };
  if (wire[2] === "candidate") {
    if (wire[7] !== null) throw new LedgerRecordError("LEDGER_PAYLOAD_INLINE_INVALID");
    return ownRecord({ ...fields, kind: "candidate", inlinePayload: null });
  }
  if (!(wire[7] instanceof Uint8Array)) throw new LedgerRecordError("LEDGER_PAYLOAD_INLINE_INVALID");
  return ownRecord({ ...fields, kind: wire[2], inlinePayload: wire[7] });
}
async function verifyLedgerPayload(record, payloadBytes) {
  const expected = ownRecord(record);
  if (!(payloadBytes instanceof Uint8Array) || payloadBytes.length < 1 || payloadBytes.length > MAX_LEDGER_PAYLOAD_BYTES) {
    throw new LedgerRecordError("LEDGER_PAYLOAD_LENGTH_INVALID");
  }
  const payload = ownBytes(payloadBytes, "LEDGER_RECORD_INVALID");
  if (bytesToHex(await sha256(payload)) !== expected.payloadHash) {
    throw new LedgerRecordError(payload.length === expected.payloadLength ? "LEDGER_PAYLOAD_DIGEST_MISMATCH" : "LEDGER_PAYLOAD_LENGTH_INVALID");
  }
  if (payload.length !== expected.payloadLength) {
    throw new LedgerRecordError("LEDGER_PAYLOAD_METADATA_MISMATCH", "committed payload length contradicts descriptor");
  }
  verifyMetadata(expected, payload);
  return payload;
}
function isKind(value) {
  return value === "candidate" || value === "capability" || value === "epoch-manifest";
}
function ownBytes(value, code) {
  if (!(value instanceof Uint8Array)) throw new LedgerRecordError(code);
  return new Uint8Array(value);
}
function checkPayloadLength(length) {
  if (!Number.isSafeInteger(length) || length < 1) throw new LedgerRecordError("LEDGER_PAYLOAD_LENGTH_INVALID");
  if (length > MAX_LEDGER_PAYLOAD_BYTES) throw new LedgerRecordError("LEDGER_PAYLOAD_TOO_LARGE");
}
function ownRecord(value) {
  if (value === null || typeof value !== "object" || !isKind(value.kind)) throw new LedgerRecordError("LEDGER_RECORD_INVALID");
  const groupRoute = ownBytes(value.groupRoute, "LEDGER_RECORD_INVALID");
  if (groupRoute.length !== 32) throw new LedgerRecordError("LEDGER_RECORD_INVALID");
  const encryptionEpoch = value.encryptionEpoch === null ? null : ownBytes(value.encryptionEpoch, "LEDGER_RECORD_INVALID");
  if (encryptionEpoch !== null && (encryptionEpoch.length < 1 || encryptionEpoch.length > MAX_LEDGER_EPOCH_BYTES)) {
    throw new LedgerRecordError("LEDGER_RECORD_INVALID");
  }
  if (typeof value.payloadHash !== "string" || !/^[0-9a-f]{64}$/u.test(value.payloadHash)) throw new LedgerRecordError("LEDGER_PAYLOAD_HASH_INVALID");
  checkPayloadLength(value.payloadLength);
  const fields = { groupRoute, encryptionEpoch, payloadHash: value.payloadHash, payloadLength: value.payloadLength };
  if (value.kind === "candidate") {
    if (value.inlinePayload !== null) throw new LedgerRecordError("LEDGER_PAYLOAD_INLINE_INVALID");
    return { ...fields, kind: "candidate", inlinePayload: null };
  }
  if (value.payloadLength > MAX_LEDGER_INLINE_PAYLOAD_BYTES) {
    throw new LedgerRecordError("LEDGER_CONTROL_TOO_LARGE", `governance envelopes must not exceed ${MAX_LEDGER_INLINE_PAYLOAD_BYTES} bytes`);
  }
  if (encryptionEpoch !== null) throw new LedgerRecordError("LEDGER_PAYLOAD_METADATA_MISMATCH", "governance must be unencrypted");
  if (!(value.inlinePayload instanceof Uint8Array)) throw new LedgerRecordError("LEDGER_PAYLOAD_INLINE_INVALID");
  if (value.inlinePayload.length !== value.payloadLength) throw new LedgerRecordError("LEDGER_PAYLOAD_LENGTH_INVALID");
  const inlinePayload = ownBytes(value.inlinePayload, "LEDGER_PAYLOAD_INLINE_INVALID");
  if (bytesToHex(sha256Sync(inlinePayload)) !== value.payloadHash) throw new LedgerRecordError("LEDGER_PAYLOAD_DIGEST_MISMATCH");
  const record = { ...fields, kind: value.kind, inlinePayload };
  verifyMetadata(record, inlinePayload);
  return record;
}
function encodeRecord(record) {
  return encodeCanonicalCbor([
    1n,
    FORMAT2,
    record.kind,
    record.groupRoute,
    record.encryptionEpoch,
    record.payloadHash,
    BigInt(record.payloadLength),
    record.inlinePayload
  ]);
}
function envelopeMetadata(payload) {
  try {
    return decodeEnvelope(payload);
  } catch (cause) {
    throw new LedgerRecordError("LEDGER_PAYLOAD_METADATA_MISMATCH", "invalid envelope", cause);
  }
}
function verifyMetadata(record, payload) {
  const envelope = envelopeMetadata(payload);
  const epochMatches = record.encryptionEpoch === null ? envelope.encryptionEpoch === null : envelope.encryptionEpoch !== null && equalBytes(record.encryptionEpoch, envelope.encryptionEpoch);
  if (envelope.messageType !== record.kind || !equalBytes(envelope.groupRoute, record.groupRoute) || !epochMatches) {
    throw new LedgerRecordError("LEDGER_PAYLOAD_METADATA_MISMATCH");
  }
}

// packages/node-core/src/cipher.ts
function createEpochEnvelopeCipher(contentKey, epoch) {
  if (contentKey.length !== 32) throw new Error("EPOCH_CONTENT_KEY_INVALID");
  const key = contentKey.slice();
  const epochId = encodeCanonicalCbor(epoch);
  return {
    epochId,
    async seal(plaintext, associatedData) {
      const encrypted = await encryptEpochPayload(key, epoch, plaintext, associatedData);
      return encodeCanonicalCbor([1n, encrypted.epoch, encrypted.nonce, encrypted.ciphertext]);
    },
    async open(ciphertext, associatedData) {
      const value = assertCanonicalCbor2(ciphertext);
      if (!Array.isArray(value) || value.length !== 4 || value[0] !== 1n || typeof value[1] !== "bigint" || value[1] !== epoch || !(value[2] instanceof Uint8Array) || !(value[3] instanceof Uint8Array)) throw new Error("EPOCH_CIPHERTEXT_INVALID");
      return decryptEpochPayload(key, {
        epoch: value[1],
        nonce: value[2],
        ciphertext: value[3]
      }, associatedData);
    }
  };
}
var EpochCipherRing = class {
  #epochs = /* @__PURE__ */ new Map();
  #currentKey;
  install(contentKey, epoch, makeCurrent = false) {
    const cipher = createEpochEnvelopeCipher(contentKey, epoch);
    const key = epochKey(cipher.epochId);
    const existing = this.#epochs.get(key);
    if (existing !== void 0) {
      if (makeCurrent) this.#currentKey = key;
      return existing;
    }
    this.#epochs.set(key, cipher);
    if (makeCurrent || this.#currentKey === void 0) this.#currentKey = key;
    return cipher;
  }
  current() {
    const cipher = this.#currentKey === void 0 ? void 0 : this.#epochs.get(this.#currentKey);
    if (cipher === void 0) throw new Error("EPOCH_CIPHER_CURRENT_UNAVAILABLE");
    return cipher;
  }
  resolve(epochId) {
    return this.#epochs.get(epochKey(epochId));
  }
  remove(epoch) {
    const key = epochKey(encodeCanonicalCbor(epoch));
    if (key === this.#currentKey) throw new Error("EPOCH_CIPHER_CURRENT_REMOVAL_PROHIBITED");
    this.#epochs.delete(key);
  }
  epochs() {
    return [...this.#epochs.values()].map((cipher) => {
      const value = assertCanonicalCbor2(cipher.epochId);
      if (typeof value !== "bigint") throw new Error("EPOCH_CIPHER_ID_INVALID");
      return value;
    }).sort((a, b) => a < b ? -1 : a > b ? 1 : 0);
  }
};
function epochKey(value) {
  return bytesToHex2(value);
}

// packages/node-core/src/governance.ts
var GovernanceControlPlane = class _GovernanceControlPlane {
  #options;
  #cipherRing;
  #snapshots = /* @__PURE__ */ new Map();
  #seen = /* @__PURE__ */ new Set();
  #pendingRecords = /* @__PURE__ */ new Map();
  #mutex = new Mutex();
  // Ingestion and authoring have different locks: publish awaits ingestion,
  // while revision/epoch selection, signing and publication must be one turn.
  #authoring = new Mutex();
  #operationStore;
  #operations;
  #operationPrefix;
  #events = new RevisionBroadcaster();
  #epochManifests = /* @__PURE__ */ new Map();
  #epochDigests = /* @__PURE__ */ new Map();
  #contentKeys = /* @__PURE__ */ new Map();
  #finalizedEpochs = [];
  #abort = new AbortController();
  #snapshot;
  #eventRevision = 0n;
  #currentEpoch = -1n;
  #consumeTask;
  #started = false;
  #lastError;
  constructor(options, snapshot) {
    this.#options = options;
    this.#snapshot = snapshot;
    this.#cipherRing = options.cipherRing ?? new EpochCipherRing();
    this.#operationStore = options.operationStore ?? new MemoryOperationStore();
    this.#operationPrefix = `governance/${bytesToHex2(snapshot.groupId)}`;
    this.#operations = new DurableOperationJournal(this.#operationStore, this.#operationPrefix);
    this.#rememberSnapshot(snapshot);
  }
  static async create(options) {
    return new _GovernanceControlPlane(options, await reduceCapabilityLog(options.genesis, []));
  }
  get snapshot() {
    return structuredClone(this.#snapshot);
  }
  get revisionSnapshots() {
    return [...this.#snapshots.values()].sort((a, b) => compareBigint(a.revision, b.revision)).map((snapshot) => structuredClone(snapshot));
  }
  get pendingRecordCount() {
    return this.#pendingRecords.size;
  }
  get lastError() {
    return this.#lastError;
  }
  get cipherRing() {
    return this.#cipherRing;
  }
  get currentEpoch() {
    return this.#currentEpoch < 0n ? null : this.#currentEpoch;
  }
  get knownEpochs() {
    return [...this.#epochManifests.keys()].sort(compareBigint);
  }
  get missingHistoricalEpochs() {
    return this.knownEpochs.filter((epoch) => !this.#contentKeys.has(epoch));
  }
  /** Rebuilt from included controls covered by verified author-time closures. */
  finalizedEpochAt(authorTimestampMs) {
    if (authorTimestampMs < 0n) throw new Error("GOVERNANCE_AUTHOR_TIMESTAMP_INVALID");
    for (let index = this.#finalizedEpochs.length - 1; index >= 0; index--) {
      const activation = this.#finalizedEpochs[index];
      if (authorTimestampMs > activation.after) return encodeCanonicalCbor(activation.epoch);
    }
    return null;
  }
  /** Issuance depends on finalized author time, never received wraps or local keys. */
  finalizedEpochStatusAt(authorTimestampMs, epochId) {
    const active = this.finalizedEpochAt(authorTimestampMs);
    if (epochId === null || active === null) return "unissued";
    if (equalBytes(active, epochId)) return "active";
    return this.#finalizedEpochs.some((epoch) => epoch.after < authorTimestampMs && equalBytes(encodeCanonicalCbor(epoch.epoch), epochId)) ? "closed" : "unissued";
  }
  /** Availability only: this does not authorize an epoch at an application timestamp. */
  hasFinalizedEpoch(epochId, includedThrough = Number.MAX_SAFE_INTEGER) {
    return epochId !== null && this.#finalizedEpochs.some((epoch) => epoch.includedThrough <= includedThrough && equalBytes(encodeCanonicalCbor(epoch.epoch), epochId));
  }
  /** Whether this node's transport feed is the current administration feed. */
  get ownsCapabilityFeed() {
    return this.#options.transport.identity === feedAuthor(this.#snapshot.capabilityLogFeed);
  }
  snapshotForRevision(digest) {
    const snapshot = this.#snapshots.get(bytesToHex2(digest));
    return snapshot === void 0 ? null : structuredClone(snapshot);
  }
  async start() {
    if (this.#started) return;
    const history = await this.#options.transport.history();
    for (const record of history) {
      try {
        await this.ingest(record);
      } catch (error) {
        if (!isInvalidGovernanceRecord(error)) throw error;
        this.#seen.add(record.id);
        this.#lastError = error.message;
      }
    }
    if (this.ownsCapabilityFeed) await this.#authoring.run(() => this.#operations.recover((prepared) => this.#applyPrepared(prepared)));
    this.#started = true;
    this.#consumeTask = this.#consume();
  }
  async close() {
    this.#abort.abort();
    await this.#consumeTask?.catch(() => void 0);
    this.#events.close();
  }
  events(afterRevision = 0n, signal) {
    const source3 = this.#events.subscribe(signal === void 0 ? {} : { signal });
    return {
      async *[Symbol.asyncIterator]() {
        for await (const event of source3) if (event.revision > afterRevision) yield event;
      }
    };
  }
  async publishCapabilityChange(change, rootPrivateKey, options = {}) {
    const captured = structuredClone(change), capturedOptions = { ...options };
    return this.#authoring.run(() => this.#publishCapabilityChange(captured, rootPrivateKey, capturedOptions));
  }
  async #publishCapabilityChange(change, rootPrivateKey, options) {
    this.#assertCapabilityFeedOwner();
    this.#assertSupportedChange(change, this.#snapshot);
    const fingerprint = encodeCapabilityRevision({
      groupId: this.#snapshot.groupId,
      revision: 1n,
      previousRevisionDigest: new Uint8Array(32),
      issuerRootPublicKey: this.#options.genesis.manifest.rootAdminPublicKey,
      grants: (change.grants ?? []).map((grant) => ({ ...grant, validFromRevision: 1n })),
      revocations: [...change.revocations ?? []],
      validationPolicies: [...change.validationPolicies ?? []],
      ...change.successorRootPublicKey === void 0 ? {} : { successorRootPublicKey: change.successorRootPublicKey },
      ...change.successorCapabilityLogFeed === void 0 ? {} : { successorCapabilityLogFeed: change.successorCapabilityLogFeed }
    });
    const prepared = await this.#operations.run({
      operationId: options.operationId ?? crypto.randomUUID(),
      fingerprint: encodeCanonicalCbor(["capability", fingerprint]),
      prepare: async () => {
        const revisionNumber = this.#snapshot.revision + 1n;
        const revision = {
          groupId: this.#snapshot.groupId,
          revision: revisionNumber,
          previousRevisionDigest: this.#snapshot.revisionDigest,
          issuerRootPublicKey: this.#snapshot.rootAdminPublicKey,
          grants: (change.grants ?? []).map((grant) => ({ ...grant, validFromRevision: revisionNumber })),
          revocations: (change.revocations ?? []).map((id2) => id2.slice()),
          validationPolicies: [...change.validationPolicies ?? []],
          ...change.successorRootPublicKey === void 0 ? {} : { successorRootPublicKey: change.successorRootPublicKey },
          ...change.successorCapabilityLogFeed === void 0 ? {} : { successorCapabilityLogFeed: change.successorCapabilityLogFeed }
        };
        const signed = await signCapabilityRevision(revision, rootPrivateKey);
        const result = encodeSignedCapabilityRevision(signed);
        return this.#prepare(result, [await this.#envelope("capability", encodeCanonicalCbor([1n, result]))]);
      },
      apply: (bytes3) => this.#applyPrepared(bytes3)
    });
    return decodeSignedCapabilityRevision(preparedResult(prepared));
  }
  async revoke(capabilityIds, rootPrivateKey, options = {}) {
    return this.publishCapabilityChange({ revocations: capabilityIds }, rootPrivateKey, options);
  }
  async rotateEpoch(rootPrivateKey, contentKey, options = {}) {
    const captured = contentKey?.slice(), capturedOptions = { ...options };
    return this.#authoring.run(() => this.#rotateEpoch(rootPrivateKey, captured, capturedOptions));
  }
  async #rotateEpoch(rootPrivateKey, contentKey, options) {
    this.#assertCapabilityFeedOwner();
    const prepared = await this.#operations.run({
      operationId: options.operationId ?? crypto.randomUUID(),
      fingerprint: encodeCanonicalCbor(["rotate-epoch", contentKey ?? null]),
      prepare: async () => {
        const recipients = [...this.#snapshot.capabilities.values()].filter((capability) => capability.grant.role === "reader" && isCapabilityActive(capability, this.#snapshot.revision)).map((capability) => ({
          recipientId: capability.grant.subjectId,
          publicKey: capability.grant.hpkePublicKey
        }));
        const epoch = this.#currentEpoch + 1n;
        const created = await createEpochManifest({
          groupId: this.#snapshot.groupId,
          epoch,
          previousEpochDigest: this.#currentEpoch < 0n ? null : this.#epochDigests.get(this.#currentEpoch) ?? null,
          createdAtMs: BigInt(Math.trunc(this.#options.now?.() ?? Date.now())),
          recipients,
          signerPublicKey: this.#snapshot.rootAdminPublicKey,
          signerPrivateKey: rootPrivateKey,
          ...contentKey === void 0 ? {} : { contentKey }
        });
        const result = encodeSignedEpochManifest(created.signedManifest);
        return this.#prepare(result, [await this.#envelope("epoch-manifest", encodeCanonicalCbor([1n, result]))], [[epoch, created.contentKey]]);
      },
      apply: (bytes3) => this.#applyPrepared(bytes3)
    });
    return decodeSignedEpochManifest(preparedResult(prepared));
  }
  async grantHistoricalAccess(subjectId, rootPrivateKey, options = {}) {
    const captured = subjectId.slice(), capturedOptions = { ...options };
    return this.#authoring.run(() => this.#grantHistoricalAccess(captured, rootPrivateKey, capturedOptions));
  }
  async #grantHistoricalAccess(subjectId, rootPrivateKey, options) {
    this.#assertCapabilityFeedOwner();
    const prepared = await this.#operations.run({
      operationId: options.operationId ?? crypto.randomUUID(),
      fingerprint: encodeCanonicalCbor(["historical-access", subjectId]),
      prepare: async () => {
        const reader = [...this.#snapshot.capabilities.values()].find((capability) => capability.grant.role === "reader" && equalBytes(capability.grant.subjectId, subjectId) && isCapabilityActive(capability, this.#snapshot.revision));
        if (reader === void 0) throw new Error("GOVERNANCE_READER_REQUIRED");
        if (this.missingHistoricalEpochs.length !== 0) throw new Error("GOVERNANCE_HISTORICAL_KEY_UNAVAILABLE");
        let published = 0;
        const envelopes = [];
        for (const [epoch, key] of [...this.#contentKeys].sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0)) {
          const original = this.#epochManifests.get(epoch);
          if (original === void 0) continue;
          const created = await createEpochManifest({
            groupId: this.#snapshot.groupId,
            epoch,
            previousEpochDigest: original.manifest.previousEpochDigest,
            createdAtMs: BigInt(Math.trunc(this.#options.now?.() ?? Date.now())),
            recipients: [{ recipientId: subjectId, publicKey: reader.grant.hpkePublicKey }],
            signerPublicKey: this.#snapshot.rootAdminPublicKey,
            signerPrivateKey: rootPrivateKey,
            contentKey: key
          });
          envelopes.push(await this.#envelope("epoch-manifest", encodeCanonicalCbor([2n, encodeSignedEpochManifest(created.signedManifest)])));
          published += 1;
        }
        return this.#prepare(encodeCanonicalCbor(BigInt(published)), envelopes);
      },
      apply: (bytes3) => this.#applyPrepared(bytes3)
    });
    return Number(assertCanonicalCbor2(preparedResult(prepared)));
  }
  async ingest(record) {
    return this.#mutex.run(async () => {
      const attempt = async (input) => {
        try {
          const changed2 = await this.#ingest(input);
          this.#pendingRecords.delete(input.id);
          return changed2;
        } catch (error) {
          if (!(error instanceof GovernanceRecordPendingError)) throw error;
          this.#pendingRecords.set(input.id, input);
          return false;
        }
      };
      const changed = await attempt(record);
      let progressed = true;
      while (progressed && this.#pendingRecords.size > 0) {
        progressed = false;
        for (const pending of [...this.#pendingRecords.values()]) {
          try {
            if (await attempt(pending)) progressed = true;
          } catch (error) {
            if (!isInvalidGovernanceRecord(error)) throw error;
            this.#pendingRecords.delete(pending.id);
            this.#seen.add(pending.id);
            this.#lastError = error.message;
          }
        }
      }
      return changed;
    });
  }
  /** Called only for an included control covered by a verified author-time closure. */
  async ingestFinalized(entry, activeSnapshot, cutoffMs) {
    if (cutoffMs < 0n) throw new Error("GOVERNANCE_FINALITY_BOUNDARY_INVALID");
    entry = { ...entry, bytes: Uint8Array.from(entry.bytes) };
    const activeDigest = activeSnapshot.revisionDigest.slice(), activeRevision = activeSnapshot.revision;
    return this.#mutex.run(async () => {
      const ledger = decodeLedgerRecord(entry.bytes);
      if (ledger.kind === "candidate") return null;
      const bytes3 = await verifyLedgerPayload(ledger, ledger.inlinePayload);
      const active = this.#snapshots.get(bytesToHex2(activeDigest));
      if (active === void 0 || active.revision !== activeRevision) throw new Error("GOVERNANCE_CANONICAL_CONTEXT_INVALID");
      const decoded = await decodeGovernanceEnvelope(bytes3, this.#options.groupRoute);
      const tagged = assertCanonicalCbor2(decoded.payload);
      if (!Array.isArray(tagged) || tagged.length !== 2 || !(tagged[1] instanceof Uint8Array) || tagged[0] !== 1n && !(decoded.type === "epoch-manifest" && tagged[0] === 2n)) {
        throw new Error("GOVERNANCE_PAYLOAD_INVALID");
      }
      let snapshot = null;
      let epoch = null;
      if (decoded.type === "capability") {
        snapshot = await this.#verifyFinalizedRevision(decodeSignedCapabilityRevision(tagged[1]), active);
      } else {
        epoch = await this.#verifyFinalizedEpoch(decodeSignedEpochManifest(tagged[1]), tagged[0] === 2n, active, cutoffMs, entry.position);
      }
      const record = {
        id: `canonical:${entry.historyId}:${entry.position}`,
        author: "",
        sequence: BigInt(entry.position),
        receivedAtMs: 0,
        payload: bytes3
      };
      await this.#ingest(record, true);
      if (epoch !== null) this.#finalizedEpochs.push(epoch);
      return snapshot === null ? null : structuredClone(snapshot);
    });
  }
  async #verifyFinalizedRevision(signed, active) {
    if (!equalBytes(signed.revision.groupId, active.groupId) || !await verifyDomain(
      DOMAINS.capabilityRevision,
      encodeCapabilityRevision(signed.revision),
      signed.signature,
      signed.revision.issuerRootPublicKey
    )) throw new Error("GOVERNANCE_REVISION_CONFLICT");
    this.#assertSupportedChange(signed.revision, active);
    if (signed.revision.revision <= active.revision) {
      const known = this.#snapshots.get(bytesToHex2(await capabilityRevisionDigest(signed.revision)));
      if (known === void 0) throw new Error("GOVERNANCE_REVISION_CONFLICT");
      return known;
    }
    if (!equalBytes(signed.revision.issuerRootPublicKey, active.rootAdminPublicKey)) throw new Error("GOVERNANCE_REVISION_CONFLICT");
    if (signed.revision.revision !== active.revision + 1n) throw new GovernanceRecordPendingError();
    return applyCapabilityRevision(active, signed);
  }
  async #verifyFinalizedEpoch(signed, historical, active, cutoffMs, includedPosition) {
    if (!equalBytes(signed.manifest.groupId, active.groupId) || !await verifyEpochManifest(signed, active.rootAdminPublicKey)) {
      throw new Error("GOVERNANCE_EPOCH_INVALID");
    }
    const known = this.#finalizedEpochs.find((item) => item.epoch === signed.manifest.epoch);
    if (historical) {
      if (known === void 0) throw new GovernanceRecordPendingError();
      return null;
    }
    const digest = await hashDomain2(DOMAINS.epochManifest, encodeEpochManifest(signed.manifest));
    if (known !== void 0) {
      if (!equalBytes(known.digest, digest)) throw new Error("GOVERNANCE_EPOCH_CHAIN_INVALID");
      return null;
    }
    const previous = this.#finalizedEpochs.at(-1);
    if (signed.manifest.epoch !== (previous?.epoch ?? -1n) + 1n) throw new GovernanceRecordPendingError();
    if (!nullableBytesEqual(signed.manifest.previousEpochDigest, previous?.digest ?? null)) throw new Error("GOVERNANCE_EPOCH_CHAIN_INVALID");
    const finalizedAt = previous !== void 0 && previous.finalizedAt > cutoffMs ? previous.finalizedAt : cutoffMs;
    const after = previous === void 0 ? -1n : finalizedAt;
    return {
      epoch: signed.manifest.epoch,
      digest,
      after,
      finalizedAt,
      includedThrough: Math.max(includedPosition, previous?.includedThrough ?? 0)
    };
  }
  async #ingest(record, canonical = false) {
    if (this.#seen.has(record.id)) return false;
    let decoded;
    try {
      decoded = await decodeGovernanceEnvelope(record.payload, this.#options.groupRoute);
    } catch {
      return false;
    }
    if (!canonical && record.author !== feedAuthor(this.#snapshot.capabilityLogFeed)) {
      throw new Error("GOVERNANCE_CAPABILITY_FEED_UNAUTHORIZED");
    }
    if (!canonical && this.#options.transport.feedContiguousThrough !== void 0 && await this.#options.transport.feedContiguousThrough(record.author) < record.sequence) throw new GovernanceRecordPendingError();
    const tagged = assertCanonicalCbor2(decoded.payload);
    if (!Array.isArray(tagged) || tagged.length !== 2 || typeof tagged[0] !== "bigint" || !(tagged[1] instanceof Uint8Array)) {
      throw new Error("GOVERNANCE_PAYLOAD_INVALID");
    }
    if (decoded.type === "capability") {
      const signed = decodeSignedCapabilityRevision(tagged[1]);
      this.#assertSupportedChange(signed.revision, this.#snapshot);
      if (signed.revision.revision > this.#snapshot.revision + 1n) {
        if (!equalBytes(signed.revision.groupId, this.#snapshot.groupId) || !equalBytes(signed.revision.issuerRootPublicKey, this.#snapshot.rootAdminPublicKey) || !await verifyDomain(
          DOMAINS.capabilityRevision,
          encodeCapabilityRevision(signed.revision),
          signed.signature,
          this.#snapshot.rootAdminPublicKey
        )) throw new Error("GOVERNANCE_REVISION_CONFLICT");
        throw new GovernanceRecordPendingError();
      }
      if (signed.revision.revision <= this.#snapshot.revision) {
        const known = this.#snapshots.get(bytesToHex2(await capabilityRevisionDigest(signed.revision)));
        if (known === void 0 || !await verifyDomain(DOMAINS.capabilityRevision, encodeCapabilityRevision(signed.revision), signed.signature, signed.revision.issuerRootPublicKey)) {
          throw new Error("GOVERNANCE_REVISION_CONFLICT");
        }
        this.#seen.add(record.id);
        return false;
      }
      this.#snapshot = await applyCapabilityRevision(this.#snapshot, signed);
      this.#rememberSnapshot(this.#snapshot);
      this.#emit("capability", record.id);
    } else {
      const signed = decodeSignedEpochManifest(tagged[1]);
      await this.#ingestEpoch(signed, tagged[0] === 2n, record.id);
    }
    this.#seen.add(record.id);
    return true;
  }
  async capabilityIdsForSubject(subjectId) {
    const ids = [];
    for (const capability of this.#snapshot.capabilities.values()) {
      if (equalBytes(capability.grant.subjectId, subjectId) && isCapabilityActive(capability, this.#snapshot.revision)) {
        ids.push(await capabilityId(capability.grant));
      }
    }
    return ids;
  }
  async #ingestEpoch(signed, historical, recordId) {
    if (!equalBytes(signed.manifest.groupId, this.#snapshot.groupId) || !await verifyEpochManifest(signed, this.#snapshot.rootAdminPublicKey)) throw new Error("GOVERNANCE_EPOCH_INVALID");
    const digest = await hashDomain2(DOMAINS.epochManifest, encodeEpochManifest(signed.manifest));
    if (!historical) {
      if (nullableBytesEqual(this.#epochDigests.get(signed.manifest.epoch) ?? null, digest)) return;
      const expectedEpoch = this.#currentEpoch + 1n;
      if (signed.manifest.epoch > expectedEpoch) throw new GovernanceRecordPendingError();
      const expectedPrevious = this.#currentEpoch < 0n ? null : this.#epochDigests.get(this.#currentEpoch) ?? null;
      if (signed.manifest.epoch !== expectedEpoch || !nullableBytesEqual(signed.manifest.previousEpochDigest, expectedPrevious)) {
        throw new Error("GOVERNANCE_EPOCH_CHAIN_INVALID");
      }
    } else if (!this.#epochManifests.has(signed.manifest.epoch)) {
      throw new GovernanceRecordPendingError();
    }
    let unwrapped;
    if (this.#options.recipient !== void 0) {
      try {
        const key = await unwrapEpochKey({
          signedManifest: signed,
          trustedSigner: this.#snapshot.rootAdminPublicKey,
          recipientId: this.#options.recipient.id,
          recipientPrivateKey: this.#options.recipient.privateKey
        });
        unwrapped = key;
      } catch {
      }
    }
    const retained = unwrapped ?? this.#contentKeys.get(signed.manifest.epoch) ?? await this.#operationStore.get(`${this.#operationPrefix}/epoch-key/${signed.manifest.epoch}`);
    if (retained !== null && retained !== void 0 && retained.length !== 32) throw new Error("GOVERNANCE_STORED_KEY_INVALID");
    if (!historical) {
      this.#currentEpoch = signed.manifest.epoch;
      this.#epochManifests.set(signed.manifest.epoch, signed);
      this.#epochDigests.set(signed.manifest.epoch, digest);
    }
    if (retained !== null && retained !== void 0) {
      this.#contentKeys.set(signed.manifest.epoch, retained.slice());
      this.#cipherRing.install(retained, signed.manifest.epoch, !historical);
    }
    this.#emit(historical ? "historical_access_granted" : "epoch_rotated", recordId, signed.manifest.epoch);
  }
  async #envelope(type, payload) {
    return encodeGovernanceEnvelope(
      this.#options.groupRoute,
      type,
      payload,
      this.#options.identity
    );
  }
  #prepare(result, envelopes, keys = []) {
    return encodeCanonicalCbor([1n, result, [...envelopes], keys.map(([epoch, key]) => [epoch, key])]);
  }
  async #applyPrepared(bytes3) {
    const prepared = decodePrepared(bytes3);
    for (const [epoch, key] of prepared.keys) {
      await this.#operationStore.put(`${this.#operationPrefix}/epoch-key/${epoch}`, key);
      this.#contentKeys.set(epoch, key.slice());
    }
    for (const envelope of prepared.envelopes) {
      const history = await this.#options.transport.history();
      const existing = history.find((record2) => record2.author === this.#options.transport.identity && equalBytes(record2.payload, envelope));
      const record = existing ?? await this.#options.transport.publish(envelope, { timestampMs: this.#options.now?.() ?? Date.now() });
      await this.#options.transport.ensurePublished?.(record);
      await this.ingest(record);
    }
  }
  async #consume() {
    while (!this.#abort.signal.aborted) {
      try {
        for await (const record of this.#options.transport.subscribe(this.#abort.signal)) {
          if (this.#abort.signal.aborted) return;
          try {
            await this.ingest(record);
          } catch (error) {
            if (!isInvalidGovernanceRecord(error)) throw error;
            this.#seen.add(record.id);
            this.#lastError = error.message;
          }
        }
      } catch (error) {
        this.#lastError = error instanceof Error ? error.message : String(error);
      }
      if (!this.#abort.signal.aborted) await new Promise((resolve) => {
        const finish = () => {
          clearTimeout(timer);
          this.#abort.signal.removeEventListener("abort", finish);
          resolve();
        };
        const timer = setTimeout(finish, 100);
        this.#abort.signal.addEventListener("abort", finish, { once: true });
      });
    }
  }
  #rememberSnapshot(snapshot) {
    this.#snapshots.set(bytesToHex2(snapshot.revisionDigest), structuredClone(snapshot));
    const request = this.#options.transport.requestFeed?.bind(this.#options.transport);
    if (request === void 0) return;
    request(feedAuthor(snapshot.capabilityLogFeed));
    if (this.#options.replication === "administration") return;
    for (const capability of snapshot.capabilities.values()) {
      if (capability.grant.transportAuthor !== void 0) request(capability.grant.transportAuthor);
    }
  }
  #assertCapabilityFeedOwner() {
    if (this.#options.transport.identity !== feedAuthor(this.#snapshot.capabilityLogFeed)) {
      throw new Error("GOVERNANCE_CAPABILITY_FEED_OWNER_REQUIRED");
    }
  }
  #assertSupportedChange(change, snapshot) {
    if (this.#options.genesis.manifest.historyPolicy === void 0) return;
    if (change.successorRootPublicKey !== void 0) throw new Error("GOVERNANCE_FIXED_ROOT");
    if (change.successorCapabilityLogFeed !== void 0) throw new Error("GOVERNANCE_FIXED_ADMINISTRATION_FEED");
    if ((change.validationPolicies?.length ?? 0) > 0) throw new Error("GOVERNANCE_FIXED_VALIDATION_POLICY");
    if (change.grants?.some((grant) => grant.role === "validator") === true || change.revocations?.some((id2) => snapshot.capabilities.get(bytesToHex2(id2))?.grant.role === "validator") === true) {
      throw new Error("GOVERNANCE_FIXED_VALIDATORS");
    }
  }
  #emit(type, recordId, epoch) {
    this.#eventRevision += 1n;
    this.#events.emit({
      revision: this.#eventRevision,
      type,
      recordId,
      membershipRevision: this.#snapshot.revisionDigest.slice(),
      ...epoch === void 0 ? {} : { epoch }
    });
  }
};
async function orderFinalizedGovernanceRecords(records, groupRoute) {
  const route = groupRoute.slice();
  const captured = records.map((input) => ({ entry: { ...input.entry, bytes: input.entry.bytes.slice() }, cutoffMs: input.cutoffMs }));
  const controls = [];
  for (const record of captured) {
    try {
      const ledger = decodeLedgerRecord(record.entry.bytes);
      if (ledger.kind === "candidate" || !equalBytes(ledger.groupRoute, route)) continue;
      const bytes3 = await verifyLedgerPayload(ledger, ledger.inlinePayload);
      const decoded = await decodeGovernanceEnvelope(bytes3, route);
      const tagged = assertCanonicalCbor2(decoded.payload);
      if (!Array.isArray(tagged) || tagged.length !== 2 || !(tagged[1] instanceof Uint8Array) || tagged[0] !== 1n && !(decoded.type === "epoch-manifest" && tagged[0] === 2n)) continue;
      const revision = decoded.type === "capability" ? decodeSignedCapabilityRevision(tagged[1]).revision.revision : decodeSignedEpochManifest(tagged[1]).manifest.epoch;
      controls.push({
        record,
        kind: decoded.type === "capability" ? 0 : 1,
        revision,
        historical: tagged[0] === 2n ? 1 : 0,
        id: ledger.payloadHash
      });
    } catch {
    }
  }
  controls.sort((left, right) => left.kind - right.kind || compareBigint(left.revision, right.revision) || left.historical - right.historical || left.id.localeCompare(right.id));
  return controls.map((item) => item.record);
}
async function encodeGovernanceEnvelope(groupRoute, type, payload, signer) {
  const signature = await signDomain(domainFor(type), payload, signer.privateKey);
  const wire = encodeCanonicalCbor([1n, payload, signer.publicKeyBytes, signature]);
  return encodeEnvelope({
    groupRoute,
    messageType: type,
    encryptionEpoch: null,
    payload: wire
  });
}
async function decodeGovernanceEnvelope(bytes3, groupRoute) {
  const envelope = decodeEnvelope(bytes3);
  if (!equalBytes(envelope.groupRoute, groupRoute) || envelope.encryptionEpoch !== null || envelope.messageType !== "capability" && envelope.messageType !== "epoch-manifest") {
    throw new Error("GOVERNANCE_ENVELOPE_INVALID");
  }
  const value = assertCanonicalCbor2(envelope.payload);
  if (!Array.isArray(value) || value.length !== 4 || value[0] !== 1n || !(value[1] instanceof Uint8Array) || !(value[2] instanceof Uint8Array) || !(value[3] instanceof Uint8Array)) throw new Error("GOVERNANCE_ENVELOPE_INVALID");
  const fields = value;
  const payload = fields[1];
  const signer = fields[2];
  const signature = fields[3];
  if (!await verifyDomain(domainFor(envelope.messageType), payload, signature, signer)) throw new Error("GOVERNANCE_ENVELOPE_SIGNATURE_INVALID");
  return { type: envelope.messageType, payload };
}
function domainFor(type) {
  if (type === "capability") return DOMAINS.capabilityRevision;
  return DOMAINS.epochManifest;
}
function feedAuthor(value) {
  return new TextDecoder().decode(value);
}
function nullableBytesEqual(left, right) {
  return left === null ? right === null : right !== null && equalBytes(left, right);
}
function decodePrepared(bytes3) {
  const value = assertCanonicalCbor2(bytes3);
  if (!Array.isArray(value) || value.length !== 4 || value[0] !== 1n || !(value[1] instanceof Uint8Array) || !Array.isArray(value[2]) || !value[2].every((item) => item instanceof Uint8Array) || !Array.isArray(value[3])) {
    throw new Error("GOVERNANCE_OPERATION_INVALID");
  }
  const keys = [];
  for (const entry of value[3]) {
    if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "bigint" || entry[0] < 0n || !(entry[1] instanceof Uint8Array) || entry[1].length !== 32) throw new Error("GOVERNANCE_OPERATION_INVALID");
    keys.push([entry[0], entry[1]]);
  }
  return { result: value[1], envelopes: value[2], keys };
}
function preparedResult(bytes3) {
  return decodePrepared(bytes3).result;
}
function compareBigint(left, right) {
  return left < right ? -1 : left > right ? 1 : 0;
}
var GovernanceRecordPendingError = class extends Error {
  constructor() {
    super("GOVERNANCE_PREDECESSOR_PENDING");
    this.name = "GovernanceRecordPendingError";
  }
};
function isInvalidGovernanceRecord(error) {
  return error instanceof ProtocolError || error instanceof Error && /^GOVERNANCE_(CAPABILITY_FEED_UNAUTHORIZED|PAYLOAD_INVALID|EPOCH_INVALID|EPOCH_CHAIN_INVALID|REVISION_CONFLICT|ENVELOPE_INVALID|ENVELOPE_SIGNATURE_INVALID|FIXED_(ROOT|ADMINISTRATION_FEED|VALIDATION_POLICY|VALIDATORS))$/u.test(error.message);
}

// packages/node-core/src/membership-wire.ts
var DOMAIN = "chronolog/membership-ledger/v1";
var MAX_MEMBERSHIP_LEDGER_BYTES = 2 * 1024 * 1024;
var MAX_TTL_MS = 6e4;
async function signMembershipLedgerRequest(options) {
  const descriptor = structuredClone(options.descriptor), request = structuredClone(options.request);
  const privateKey = options.identity.privateKey, publicKey = options.identity.publicKeyBytes.slice();
  if (!equalBytes(publicKey, descriptor.genesis.manifest.rootAdminPublicKey)) throw new Error("MEMBERSHIP_ROOT_KEY_REQUIRED");
  const history = coordinated(descriptor), now = options.now ?? Date.now();
  if (!Number.isSafeInteger(now) || now < 0 || now > Number.MAX_SAFE_INTEGER - MAX_TTL_MS) throw new Error("MEMBERSHIP_TIME_INVALID");
  validateRequest(request, descriptor);
  const payload = encodeCanonicalCbor([
    1n,
    DOMAIN,
    history.groupId,
    history.historyId,
    encodeHistoryConfiguration(history),
    BigInt(now + MAX_TTL_MS),
    crypto.getRandomValues(new Uint8Array(16)),
    request.kind,
    request.kind === "read" ? BigInt(request.after) : request.recordBytes,
    request.kind === "read" ? BigInt(request.limit) : null
  ]);
  const signature = new Uint8Array(await crypto.subtle.sign("Ed25519", privateKey, payload.slice().buffer));
  return encodeCanonicalCbor([payload, signature]);
}
async function verifyMembershipLedgerRequest(bytes3, descriptor, now = Date.now()) {
  bytes3 = bytes3.slice();
  descriptor = structuredClone(descriptor);
  if (!Number.isSafeInteger(now) || now < 0 || now > Number.MAX_SAFE_INTEGER - MAX_TTL_MS) throw new Error("MEMBERSHIP_TIME_INVALID");
  if (bytes3.length > MAX_MEMBERSHIP_LEDGER_BYTES) throw new Error("MEMBERSHIP_REQUEST_TOO_LARGE");
  const history = coordinated(descriptor), signed = assertCanonicalCbor2(bytes3);
  if (!Array.isArray(signed) || signed.length !== 2 || !(signed[0] instanceof Uint8Array) || !(signed[1] instanceof Uint8Array) || signed[1].length !== 64) throw new Error("MEMBERSHIP_REQUEST_INVALID");
  const value = assertCanonicalCbor2(signed[0]);
  if (!Array.isArray(value) || value.length !== 10 || value[0] !== 1n || value[1] !== DOMAIN || !(value[2] instanceof Uint8Array) || !equalBytes(value[2], history.groupId) || value[3] !== history.historyId || !(value[4] instanceof Uint8Array) || !equalBytes(value[4], encodeHistoryConfiguration(history)) || typeof value[5] !== "bigint" || value[5] < BigInt(now) || value[5] > BigInt(now + MAX_TTL_MS) || !(value[6] instanceof Uint8Array) || value[6].length !== 16) throw new Error("MEMBERSHIP_REQUEST_INVALID");
  const key = await crypto.subtle.importKey(
    "raw",
    descriptor.genesis.manifest.rootAdminPublicKey.slice().buffer,
    "Ed25519",
    false,
    ["verify"]
  );
  if (!await crypto.subtle.verify("Ed25519", key, signed[1].slice().buffer, signed[0].slice().buffer)) {
    throw new Error("MEMBERSHIP_REQUEST_UNAUTHORIZED");
  }
  let request;
  if (value[7] === "read" && typeof value[8] === "bigint" && typeof value[9] === "bigint" && value[8] <= BigInt(Number.MAX_SAFE_INTEGER) && value[9] <= 128n) {
    request = { kind: "read", after: Number(value[8]), limit: Number(value[9]) };
  } else if (value[7] === "append" && value[8] instanceof Uint8Array && value[9] === null) {
    request = { kind: "append", recordBytes: value[8].slice() };
  } else throw new Error("MEMBERSHIP_REQUEST_INVALID");
  validateRequest(request, descriptor);
  return request;
}
function encodeMembershipLedgerResponse(value) {
  return "entries" in value ? encodeCanonicalCbor([
    1n,
    "read",
    value.entries.map((entry) => encodeOrderingEvidence({ kind: "ordered-entry", entry })),
    encodeOrderingEvidence({ kind: "prefix-certificate", certificate: value.certificate }),
    value.hasMore
  ]) : encodeCanonicalCbor([1n, "append", encodeOrderingEvidence({ kind: "ordered-entry", entry: value })]);
}
function decodeMembershipLedgerResponse(bytes3, kind) {
  if (bytes3.length > MAX_MEMBERSHIP_LEDGER_BYTES) throw new Error("MEMBERSHIP_RESPONSE_TOO_LARGE");
  const value = assertCanonicalCbor2(bytes3);
  if (!Array.isArray(value) || value[0] !== 1n || value[1] !== kind) throw new Error("MEMBERSHIP_RESPONSE_INVALID");
  const entry = (raw) => {
    if (!(raw instanceof Uint8Array)) throw new Error("MEMBERSHIP_RESPONSE_INVALID");
    const evidence2 = decodeOrderingEvidence(raw);
    if (evidence2.kind !== "ordered-entry") throw new Error("MEMBERSHIP_RESPONSE_INVALID");
    return evidence2.entry;
  };
  if (kind === "append" && value.length === 3) return entry(value[2]);
  if (kind !== "read" || value.length !== 5 || !Array.isArray(value[2]) || value[2].length > 128 || !(value[3] instanceof Uint8Array) || typeof value[4] !== "boolean") throw new Error("MEMBERSHIP_RESPONSE_INVALID");
  const evidence = decodeOrderingEvidence(value[3]);
  if (evidence.kind !== "prefix-certificate") throw new Error("MEMBERSHIP_RESPONSE_INVALID");
  return { entries: value[2].map(entry), certificate: evidence.certificate, hasMore: value[4] };
}
function createMembershipLedgerClient(options) {
  const descriptor = structuredClone(options.descriptor), identity = { ...options.identity, publicKeyBytes: options.identity.publicKeyBytes.slice() };
  const history = coordinated(descriptor), url = new URL(options.url), fetcher = options.fetch ?? globalThis.fetch;
  if (url.username || url.password || url.hash || !(url.protocol === "https:" || url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname))) throw new Error("MEMBERSHIP_URL_INVALID");
  const call = async (request, signal) => {
    const body = await signMembershipLedgerRequest({ descriptor, identity, request, now: options.now?.() ?? Date.now() });
    const response = await fetcher(url, {
      method: "POST",
      body: body.slice().buffer,
      headers: { "Content-Type": "application/cbor" },
      cache: "no-store",
      ...signal === void 0 ? {} : { signal }
    });
    if (!response.ok) throw new Error(`MEMBERSHIP_LEDGER_HTTP_${response.status}`);
    if (response.body === null) throw new Error("MEMBERSHIP_RESPONSE_INVALID");
    const reader = response.body.getReader(), chunks = [];
    let length = 0;
    try {
      for (; ; ) {
        const item = await reader.read();
        if (item.done) break;
        length += item.value.length;
        if (length > MAX_MEMBERSHIP_LEDGER_BYTES) throw new Error("MEMBERSHIP_RESPONSE_TOO_LARGE");
        chunks.push(item.value);
      }
    } finally {
      await reader.cancel().catch(() => void 0);
      reader.releaseLock();
    }
    const bytes3 = new Uint8Array(length);
    let offset = 0;
    for (const chunk of chunks) {
      bytes3.set(chunk, offset);
      offset += chunk.length;
    }
    return bytes3;
  };
  return {
    async read(input) {
      const page = decodeMembershipLedgerResponse(await call({ kind: "read", after: input.after, limit: input.limit }, input.signal), "read");
      if (page.entries.length > input.limit) throw new Error("MEMBERSHIP_RANGE_TOO_LARGE");
      await verifyPrefixCertificate(page.certificate, history);
      return page;
    },
    async append(recordBytes, input = {}) {
      const exact = recordBytes.slice();
      const entry = decodeMembershipLedgerResponse(await call({ kind: "append", recordBytes: exact }, input.signal), "append");
      await verifyOrderedEntry(entry);
      if (entry.historyId !== history.historyId || !equalBytes(entry.bytes, exact)) throw new Error("MEMBERSHIP_APPEND_MISMATCH");
      return entry;
    }
  };
}
function coordinated(descriptor) {
  if (descriptor.history.kind !== "coordinated") throw new Error("MEMBERSHIP_COORDINATED_HISTORY_REQUIRED");
  return descriptor.history;
}
function validateRequest(request, descriptor) {
  if (request.kind === "read") {
    if (!Number.isSafeInteger(request.after) || request.after < 0 || !Number.isSafeInteger(request.limit) || request.limit < 1 || request.limit > 128) throw new Error("MEMBERSHIP_RANGE_INVALID");
  } else {
    const record = decodeLedgerRecord(request.recordBytes);
    if (record.kind === "candidate" || !equalBytes(record.groupRoute, descriptor.groupRoute)) {
      throw new Error("MEMBERSHIP_CONTROL_RECORD_REQUIRED");
    }
  }
}

// packages/node-core/src/membership.ts
var provisionLocks = /* @__PURE__ */ new WeakMap();
function provisionLock(store) {
  let mutex = provisionLocks.get(store);
  if (mutex === void 0) {
    mutex = new Mutex();
    provisionLocks.set(store, mutex);
  }
  return mutex;
}
async function provisionMembership(options) {
  const store = options.store, now = options.now ?? Date.now;
  const input = structuredClone({
    executionManifestDigest: options.executionManifestDigest,
    schemaAdministratorPublicKey: options.schemaAdministratorPublicKey,
    nativeAuthority: options.nativeAuthority,
    providerId: options.providerId,
    providerParameters: options.providerParameters,
    initialCapabilities: options.initialCapabilities ?? [],
    groupId: options.groupId,
    groupRoute: options.groupRoute
  });
  for (const value of [input.executionManifestDigest, input.schemaAdministratorPublicKey, input.nativeAuthority.publicKey, input.groupId, input.groupRoute]) {
    if (value !== void 0 && (!(value instanceof Uint8Array) || value.length !== 32)) throw new Error("MEMBERSHIP_CONFIGURATION_INVALID");
  }
  if (input.initialCapabilities.some((grant) => grant.validFromRevision !== 0n || !["reader", "writer"].includes(grant.role))) {
    throw new Error("MEMBERSHIP_INITIAL_GRANT_INVALID");
  }
  return provisionLock(store).run(async () => {
    const identity = await loadAdministratorIdentity(store);
    const manifest = (groupId, createdAtMs) => ({
      groupId,
      schemaId: input.executionManifestDigest,
      rootAdminPublicKey: identity.publicKeyBytes,
      schemaAdminPublicKey: input.schemaAdministratorPublicKey,
      capabilityLogFeed: utf82(feedIdFromPublicKey(identity.publicKeyBytes)),
      historyPolicy: {
        kind: "coordinated",
        executionManifestDigest: input.executionManifestDigest,
        historyId: input.nativeAuthority.historyId,
        authorityPublicKey: input.nativeAuthority.publicKey,
        ...input.providerId === void 0 ? {} : { providerId: input.providerId },
        ...input.providerParameters === void 0 ? {} : { providerParameters: input.providerParameters }
      },
      initialCapabilities: [{
        subjectId: identity.publicKeyBytes,
        signingPublicKey: identity.publicKeyBytes,
        transportAuthor: feedIdFromPublicKey(identity.publicKeyBytes),
        role: "administrator",
        validFromRevision: 0n
      }, ...input.initialCapabilities],
      validationPolicies: [{ version: 1n, minimumValidators: 1n }],
      clockPolicy: { maxFutureSkewMs: 30000n, cutoffLagMs: 1000n, heartbeatIntervalMs: 1000n },
      resourcePolicy: { maxCandidateBytes: 1000000n, maxProgramNodes: 10000n, maxPreconditions: 100n, maxMutations: 100n },
      encryptionSuite: "HPKE-X25519-HKDF-SHA256-AES-256-GCM",
      createdAtMs
    });
    const fingerprint = encodeCanonicalCbor([encodeGenesisManifest(manifest(input.groupId ?? new Uint8Array(32), 0n)), input.groupRoute ?? null]);
    const saved = await store.get("membership/provision");
    if (saved !== null) {
      const value = assertCanonicalCbor2(saved);
      if (!Array.isArray(value) || value.length !== 4 || value[0] !== 1n || !(value[1] instanceof Uint8Array) || !(value[2] instanceof Uint8Array) || !(value[3] instanceof Uint8Array)) throw new Error("MEMBERSHIP_STORE_INVALID");
      if (!equalBytes(value[1], fingerprint)) throw new Error("MEMBERSHIP_CONFIGURATION_CONFLICT");
      const descriptor2 = await membershipDescriptor(decodeSignedGenesis(value[2]), value[3]);
      if (!equalBytes(descriptor2.genesis.manifest.rootAdminPublicKey, identity.publicKeyBytes)) throw new Error("MEMBERSHIP_ROOT_KEY_MISMATCH");
      return { descriptor: descriptor2, identity };
    }
    const timestamp = now();
    if (!Number.isSafeInteger(timestamp) || timestamp < 0) throw new Error("MEMBERSHIP_TIME_INVALID");
    const genesis = await signGenesis(manifest(input.groupId ?? crypto.getRandomValues(new Uint8Array(32)), BigInt(timestamp)), identity.privateKey);
    const descriptor = await membershipDescriptor(genesis, input.groupRoute ?? crypto.getRandomValues(new Uint8Array(32)));
    await store.put("membership/provision", encodeCanonicalCbor([1n, fingerprint, encodeSignedGenesis(genesis), descriptor.groupRoute]));
    return { descriptor, identity };
  });
}
async function membershipDescriptor(genesis, groupRoute) {
  genesis = decodeSignedGenesis(encodeSignedGenesis(genesis));
  groupRoute = groupRoute.slice();
  const history = genesis.manifest.historyPolicy;
  if (history?.kind !== "coordinated" || history.historyId === void 0 || history.authorityPublicKey === void 0) {
    throw new Error("MEMBERSHIP_COORDINATED_HISTORY_REQUIRED");
  }
  const descriptor = { genesis, groupRoute, history: {
    kind: "coordinated",
    historyId: history.historyId,
    authorityPublicKey: history.authorityPublicKey,
    groupId: genesis.manifest.groupId,
    executionManifestDigest: history.executionManifestDigest,
    genesisDigest: await hashDomain2(DOMAINS.genesis, encodeGenesisManifest(genesis.manifest)),
    ...history.providerId === void 0 ? {} : { providerId: history.providerId },
    ...history.providerParameters === void 0 ? {} : { providerParameters: history.providerParameters }
  } };
  await verifyEnrollmentDescriptor(descriptor);
  return descriptor;
}
function encodeMembershipFinalTarget(descriptor, position, root, closedThroughMs) {
  if (descriptor.history.kind !== "coordinated" || !Number.isSafeInteger(position) || position < 0 || !/^[0-9a-f]{64}$/u.test(root) || closedThroughMs < 0n) {
    throw new Error("MEMBERSHIP_TARGET_INVALID");
  }
  return encodeCanonicalCbor([4n, descriptor.history.groupId, "chronological", descriptor.history.historyId, BigInt(position), root, closedThroughMs]);
}
var MembershipAdministrator = class _MembershipAdministrator {
  #descriptor;
  #identity;
  #store;
  #ledger;
  #local;
  #governance;
  #policy;
  #activation;
  #issuer;
  #revocations;
  #mutex = new Mutex();
  #abort = new AbortController();
  #signal;
  #handledControls = /* @__PURE__ */ new Set();
  #pendingControls = false;
  #published = 0;
  #closed = false;
  constructor(options) {
    this.#descriptor = options.descriptor;
    this.#identity = options.identity;
    this.#store = options.store;
    this.#ledger = options.ledger;
    this.#local = options.local;
    this.#governance = options.governance;
    this.#policy = options.policy;
    this.#activation = new GovernanceActivationIndex(options.governance.revisionSnapshots[0], "coordinated");
    this.#signal = this.#abort.signal;
    this.#revocations = new DurableOperationJournal(options.store, "membership/revocations");
    this.#issuer = new EnrollmentIssuer({
      descriptor: options.descriptor,
      governance: options.governance,
      store: options.store,
      rootPrivateKey: options.identity.privateKey,
      captureFinalTarget: async () => {
        await this.#sync();
        if (this.#activation.activeSnapshot.revision !== this.#governance.snapshot.revision || this.#policy.closedReceiptThrough < this.#published || this.#pendingControls) throw new Error("MEMBERSHIP_PREFIX_PENDING");
        return this.#target();
      }
    });
  }
  static async open(input) {
    const descriptor = structuredClone(input.descriptor), identity = { ...input.identity, publicKeyBytes: input.identity.publicKeyBytes.slice() };
    await verifyEnrollmentDescriptor(descriptor);
    if (descriptor.history.kind !== "coordinated") throw new Error("MEMBERSHIP_COORDINATED_HISTORY_REQUIRED");
    if ((descriptor.history.providerId ?? "signed-inclusion-v1") !== "signed-inclusion-v1") throw new Error("FINALITY_PROVIDER_UNAVAILABLE");
    const history = descriptor.history;
    if (!equalBytes(identity.publicKeyBytes, descriptor.genesis.manifest.rootAdminPublicKey) || new TextDecoder().decode(descriptor.genesis.manifest.capabilityLogFeed) !== feedIdFromPublicKey(identity.publicKeyBytes)) {
      throw new Error("MEMBERSHIP_ROOT_KEY_REQUIRED");
    }
    const local = new PortableFeedTransport({
      store: await DurableFeedStore.open(namespace(input.store, "membership/control/"), webFeedCrypto),
      crypto: webFeedCrypto,
      signer: webFeedSigner(feedIdFromPublicKey(identity.publicKeyBytes), identity.privateKey)
    });
    const transport = {
      identity: local.identity,
      publish: (bytes3, options) => local.publish(bytes3, options),
      get: (id2) => local.get(id2),
      history: () => local.history(),
      subscribe: (signal) => local.subscribe(signal),
      getPayload: async () => {
        throw new Error("MEMBERSHIP_APPLICATION_PAYLOAD_DISABLED");
      },
      status: () => local.status(),
      close: () => local.close(),
      requestFeed: (feed) => local.requestFeed(feed),
      feedContiguousThrough: (feed) => local.feedContiguousThrough(feed),
      ensurePublished: async (record) => {
        const saved = await local.get(record.id);
        if (saved === void 0 || saved.author !== local.identity || !equalBytes(saved.payload, record.payload)) {
          throw new Error("MEMBERSHIP_CONTROL_NOT_DURABLE");
        }
        const { recordBytes, record: descriptorRecord } = await createLedgerRecord(saved.payload);
        if (descriptorRecord.kind === "candidate") throw new Error("MEMBERSHIP_CONTROL_RECORD_REQUIRED");
        const entry = await input.ledger.append(recordBytes, { signal: administrator.#signal });
        await verifyOrderedEntry(entry);
        if (entry.historyId !== history.historyId || !equalBytes(entry.bytes, recordBytes)) throw new Error("MEMBERSHIP_APPEND_MISMATCH");
        administrator.#published = Math.max(administrator.#published, entry.position);
      }
    };
    const governance = await GovernanceControlPlane.create({
      genesis: descriptor.genesis,
      groupRoute: descriptor.groupRoute,
      identity,
      operationStore: input.store,
      transport,
      replication: "administration"
    });
    const policy = await CoordinatedHistoryPolicy.open(descriptor.history, namespace(input.store, "membership/ledger/"));
    const administrator = new _MembershipAdministrator({ descriptor, identity, store: input.store, ledger: input.ledger, local, governance, policy });
    try {
      await governance.start();
      await administrator.#revocations.recover((bytes3) => administrator.#applyRevocation(bytes3));
      if (governance.currentEpoch === null) await governance.rotateEpoch(identity.privateKey, void 0, { operationId: "membership-bootstrap-epoch" });
      await administrator.#sync();
      return administrator;
    } catch (error) {
      await administrator.close();
      throw error;
    }
  }
  get descriptor() {
    return structuredClone(this.#descriptor);
  }
  get snapshot() {
    return this.#activation.activeSnapshot;
  }
  get progress() {
    return this.#policy.progress;
  }
  get epochs() {
    return this.#governance.knownEpochs;
  }
  /** Approved devices obtain verified inline grants/key wraps before their reader-authenticated peer connection. */
  read(options) {
    const after = options.after, limit = options.limit ?? 128, through = this.#policy.progress.verifiedThrough;
    if (!Number.isSafeInteger(after) || after < 0 || after > through || !Number.isSafeInteger(limit) || limit < 1 || limit > 128) {
      throw new Error("MEMBERSHIP_RANGE_INVALID");
    }
    const certificate = this.#policy.evidence().find((evidence) => evidence.kind === "prefix-certificate" && evidence.certificate.position === through);
    if (certificate?.kind !== "prefix-certificate") throw new Error("MEMBERSHIP_PREFIX_PENDING");
    const entries = [];
    let bytes3 = 0;
    for (const entry of this.#policy.entries().slice(after, after + limit)) {
      if (entries.length && bytes3 + entry.bytes.length > 1024 * 1024) break;
      entries.push(entry);
      bytes3 += entry.bytes.length;
    }
    return { entries, certificate: certificate.certificate, hasMore: after + entries.length < through };
  }
  sync(options = {}) {
    return this.#run(async () => {
      await this.#sync();
      return this.progress;
    }, options.signal);
  }
  approve(request, decision, options = {}) {
    const capturedRequest = structuredClone(request), capturedDecision = structuredClone(decision);
    return this.#run(async () => {
      await this.#revocations.recover((bytes3) => this.#applyRevocation(bytes3));
      await this.#sync();
      return this.#issuer.approve(capturedRequest, capturedDecision);
    }, options.signal);
  }
  revoke(input, options = {}) {
    const captured = structuredClone(input);
    validateOperationId(captured.operationId);
    if (!captured.capabilityIds.length || captured.capabilityIds.length > 128 || captured.capabilityIds.some((id2) => id2.length !== 32)) {
      throw new Error("MEMBERSHIP_REVOCATION_INVALID");
    }
    const ids = [...new Map(captured.capabilityIds.map((id2) => [bytesToHex2(id2), id2])).entries()].sort(([a], [b]) => a.localeCompare(b)).map(([, id2]) => id2);
    return this.#run(async () => {
      await this.#sync();
      const payload = await this.#revocations.run({
        operationId: captured.operationId,
        fingerprint: encodeCanonicalCbor(ids),
        prepare: async () => {
          for (const id2 of ids) {
            const capability = this.#governance.snapshot.capabilities.get(bytesToHex2(id2));
            if (capability === void 0 || !["reader", "writer"].includes(capability.grant.role) || !isCapabilityActive(capability, this.#governance.snapshot.revision)) throw new Error("MEMBERSHIP_REVOCATION_INVALID");
          }
          const key2 = bytesToHex2(await hashDomain2(DOMAINS.capabilityRevision, encodeCanonicalCbor([captured.operationId, ids])));
          return encodeCanonicalCbor([1n, key2, ids]);
        },
        apply: (bytes3) => this.#applyRevocation(bytes3)
      });
      const key = revocationInput(payload).key, result = await this.#store.get(`membership/revocation-result/${key}`);
      if (result === null) throw new Error("MEMBERSHIP_REVOCATION_RESULT_MISSING");
      return decodeRevocation(result);
    }, options.signal);
  }
  async close() {
    if (this.#closed) return;
    this.#closed = true;
    this.#abort.abort();
    await this.#mutex.run(async () => {
      await this.#governance.close();
      await this.#local.close();
    });
  }
  #run(operation, signal) {
    return this.#mutex.run(async () => {
      if (this.#closed) throw new Error("MEMBERSHIP_CLOSED");
      this.#signal = signal === void 0 ? this.#abort.signal : AbortSignal.any([signal, this.#abort.signal]);
      this.#signal.throwIfAborted();
      try {
        return await operation();
      } finally {
        this.#signal = this.#abort.signal;
      }
    });
  }
  async #sync() {
    this.#signal.throwIfAborted();
    let cursor = this.#policy.progress.verifiedThrough, target;
    do {
      const page = await this.#ledger.read({ after: cursor, limit: 128, signal: this.#signal });
      if (page.entries.length > 128) throw new Error("MEMBERSHIP_RANGE_TOO_LARGE");
      for (const entry of page.entries) {
        if (entry.position !== cursor + 1) throw new Error("MEMBERSHIP_RANGE_GAP");
        cursor = entry.position;
      }
      await this.#policy.ingestBatch([
        ...page.entries.map((entry) => ({ kind: "ordered-entry", entry })),
        { kind: "prefix-certificate", certificate: page.certificate }
      ]);
      target ??= page.certificate.position;
      if (cursor < target && page.entries.length === 0) throw new Error("MEMBERSHIP_RANGE_GAP");
      this.#signal.throwIfAborted();
    } while (cursor < target);
    const controls = await orderFinalizedGovernanceRecords(this.#policy.snapshot().records.flatMap((record) => record.closureBoundary === null || this.#handledControls.has(record.entry.position) ? [] : [{ entry: record.entry, cutoffMs: record.closureBoundary.closedThroughMs }]), this.#descriptor.groupRoute);
    this.#pendingControls = false;
    for (const { entry, cutoffMs } of controls) {
      try {
        const snapshot = await this.#governance.ingestFinalized(entry, this.#activation.activeSnapshot, cutoffMs);
        if (snapshot !== null && snapshot.revision > this.#activation.activeSnapshot.revision) {
          this.#activation.observe(snapshot);
          this.#activation.activateFinalized(snapshot, cutoffMs);
        }
      } catch (error) {
        if (error instanceof GovernanceRecordPendingError) {
          this.#pendingControls = true;
          continue;
        }
        if (!isInvalidGovernanceRecord(error)) throw error;
      }
      this.#handledControls.add(entry.position);
    }
  }
  #target() {
    const closure = this.#policy.snapshot().closures.at(-1);
    if (closure === void 0 || this.#pendingControls) throw new Error("MEMBERSHIP_PREFIX_PENDING");
    return {
      frontier: encodeMembershipFinalTarget(this.#descriptor, closure.includedThrough, closure.includedRoot, closure.closedThroughMs),
      requiredEpochs: this.#governance.knownEpochs,
      executionManifestDigest: this.#descriptor.history.executionManifestDigest.slice()
    };
  }
  async #applyRevocation(bytes3) {
    const { key, ids } = revocationInput(bytes3), resultKey = `membership/revocation-result/${key}`;
    if (await this.#store.get(resultKey) !== null) return;
    const revision = await this.#governance.revoke(ids, this.#identity.privateKey, { operationId: `revoke:${key}` });
    const epoch = await this.#governance.rotateEpoch(this.#identity.privateKey, void 0, { operationId: `rotate:${key}` });
    await this.#sync();
    if (this.#policy.closedReceiptThrough < this.#published || this.#pendingControls) throw new Error("MEMBERSHIP_PREFIX_PENDING");
    const target = this.#target();
    await this.#store.put(resultKey, encodeCanonicalCbor([
      1n,
      await capabilityRevisionDigest(revision.revision),
      epoch.manifest.epoch,
      target.frontier,
      target.requiredEpochs,
      target.executionManifestDigest
    ]));
  }
};
async function loadAdministratorIdentity(store) {
  let saved = await store.get("membership/identity");
  if (saved === null) {
    const identity = await generateEd25519KeyPair();
    saved = encodeCanonicalCbor([1n, identity.publicKeyBytes, await exportEd25519PrivateKey(identity.privateKey)]);
    await store.put("membership/identity", saved);
  }
  const value = assertCanonicalCbor2(saved);
  if (!Array.isArray(value) || value.length !== 3 || value[0] !== 1n || !(value[1] instanceof Uint8Array) || value[1].length !== 32 || !(value[2] instanceof Uint8Array)) throw new Error("MEMBERSHIP_IDENTITY_INVALID");
  return { publicKeyBytes: value[1].slice(), publicKey: await importEd25519PublicKey(value[1]), privateKey: await importEd25519PrivateKey(value[2]) };
}
function namespace(store, prefix) {
  return { get: (key) => store.get(prefix + key), put: (key, bytes3) => store.put(prefix + key, bytes3) };
}
function revocationInput(bytes3) {
  const value = assertCanonicalCbor2(bytes3);
  if (!Array.isArray(value) || value.length !== 3 || value[0] !== 1n || typeof value[1] !== "string" || !/^[0-9a-f]{64}$/u.test(value[1]) || !Array.isArray(value[2]) || !value[2].length || !value[2].every((id2) => id2 instanceof Uint8Array && id2.length === 32)) {
    throw new Error("MEMBERSHIP_REVOCATION_STORE_INVALID");
  }
  return { key: value[1], ids: value[2] };
}
function decodeRevocation(bytes3) {
  const value = assertCanonicalCbor2(bytes3);
  if (!Array.isArray(value) || value.length !== 6 || value[0] !== 1n || !(value[1] instanceof Uint8Array) || typeof value[2] !== "bigint" || !(value[3] instanceof Uint8Array) || !Array.isArray(value[4]) || !value[4].every((epoch) => typeof epoch === "bigint") || !(value[5] instanceof Uint8Array)) throw new Error("MEMBERSHIP_REVOCATION_STORE_INVALID");
  return { membershipRevision: value[1], epoch: value[2], target: { frontier: value[3], requiredEpochs: value[4], executionManifestDigest: value[5] } };
}
export {
  MAX_MEMBERSHIP_LEDGER_BYTES,
  MembershipAdministrator,
  createMembershipLedgerClient,
  decodeMembershipLedgerResponse,
  decodeSignedEnrollmentApproval,
  decodeSignedEnrollmentRequest,
  decodeSignedGenesis,
  encodeMembershipFinalTarget,
  encodeMembershipLedgerResponse,
  encodeSignedEnrollmentApproval,
  encodeSignedEnrollmentRequest,
  encodeSignedGenesis,
  enrollmentProgress,
  loadOrCreateEnrollmentIdentity,
  membershipDescriptor,
  prepareEnrollmentRequest,
  provisionMembership,
  signMembershipLedgerRequest,
  verifyEnrollmentApproval,
  verifyMembershipLedgerRequest,
  verifySignedEnrollmentRequest
};
/*! Bundled license information:

@noble/hashes/esm/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)
*/
