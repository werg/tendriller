import {
  createApplicationBackend
} from "./chunks/chunk-I6TQG23U.mjs";
import "./chunks/chunk-MAGRVNAE.mjs";
import "./chunks/chunk-HYFY2E3E.mjs";
export {
  createApplicationBackend
};
