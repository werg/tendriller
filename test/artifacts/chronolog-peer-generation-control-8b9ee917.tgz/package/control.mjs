// packages/canonical/src/errors.ts
var CanonicalError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.details = details;
    this.name = "CanonicalError";
  }
  code;
  details;
};
function canonicalInvariant(condition, code, message, details) {
  if (!condition) throw new CanonicalError(code, message, details);
}

// packages/canonical/src/bytes.ts
var textEncoder = new TextEncoder();
var fatalTextDecoder = new TextDecoder("utf-8", { fatal: true });
function utf8(value) {
  const encoded = textEncoder.encode(value);
  try {
    if (fatalTextDecoder.decode(encoded) !== value) throw new CanonicalError("INVALID_UTF8", "Text contains an unpaired UTF-16 surrogate");
  } catch (error) {
    if (error instanceof CanonicalError) throw error;
    throw new CanonicalError("INVALID_UTF8", "Text cannot be represented as canonical UTF-8");
  }
  return encoded;
}
function decodeUtf8(value) {
  try {
    return fatalTextDecoder.decode(value);
  } catch {
    throw new CanonicalError("INVALID_UTF8", "Bytes are not valid UTF-8");
  }
}
function concatBytes(...parts) {
  const size = parts.reduce((sum, part) => sum + part.length, 0);
  const result = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}
function compareBytes(left, right) {
  const size = Math.min(left.length, right.length);
  for (let index = 0; index < size; index += 1) {
    const difference = left[index] - right[index];
    if (difference !== 0) return difference < 0 ? -1 : 1;
  }
  return left.length === right.length ? 0 : left.length < right.length ? -1 : 1;
}
function equalBytes(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}
function bytesToHex(value) {
  return [...value].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function hexToBytes(value) {
  if (!/^(?:[0-9a-fA-F]{2})*$/u.test(value)) throw new CanonicalError("SCHEMA_INVALID", "Hex text is malformed");
  return Uint8Array.from({ length: value.length / 2 }, (_unused, index) => Number.parseInt(value.slice(index * 2, index * 2 + 2), 16));
}

// packages/canonical/src/cbor.ts
var DEFAULT_DECODE_LIMITS = Object.freeze({
  maxBytes: 16 * 1024 * 1024,
  maxDepth: 64,
  maxArrayItems: 1e6,
  maxMapItems: 1e5,
  maxTextBytes: 4 * 1024 * 1024,
  maxBlobBytes: 16 * 1024 * 1024
});
var MAX_UINT64 = (1n << 64n) - 1n;
var POSITIVE_BIGNUM_TAG = 2n;
var NEGATIVE_BIGNUM_TAG = 3n;
function encodeHead(major, value) {
  canonicalInvariant(value >= 0n && value <= MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR integer is outside uint64 range");
  if (value < 24n) return Uint8Array.of(major << 5 | Number(value));
  if (value <= 0xffn) return Uint8Array.of(major << 5 | 24, Number(value));
  if (value <= 0xffffn) return Uint8Array.of(major << 5 | 25, Number(value >> 8n), Number(value & 0xffn));
  if (value <= 0xffffffffn) {
    const bytes3 = new Uint8Array(5);
    bytes3[0] = major << 5 | 26;
    new DataView(bytes3.buffer).setUint32(1, Number(value), false);
    return bytes3;
  }
  const bytes2 = new Uint8Array(9);
  bytes2[0] = major << 5 | 27;
  new DataView(bytes2.buffer).setBigUint64(1, value, false);
  return bytes2;
}
function magnitudeBytes(value) {
  canonicalInvariant(value > MAX_UINT64, "INTEGER_OUT_OF_RANGE", "CBOR bignum must exceed uint64 range");
  const octets = [];
  for (let remaining = value; remaining > 0n; remaining >>= 8n) octets.push(Number(remaining & 0xffn));
  octets.reverse();
  return Uint8Array.from(octets);
}
function encodeBigint(value) {
  const negative = value < 0n;
  const magnitude = negative ? -1n - value : value;
  if (magnitude <= MAX_UINT64) return encodeHead(negative ? 1 : 0, magnitude);
  const bytes2 = magnitudeBytes(magnitude);
  return concatBytes(
    encodeHead(6, negative ? NEGATIVE_BIGNUM_TAG : POSITIVE_BIGNUM_TAG),
    encodeHead(2, BigInt(bytes2.length)),
    bytes2
  );
}
function isMap(value) {
  return value instanceof Map;
}
function encodeCanonicalCbor(value) {
  if (value === null) return Uint8Array.of(246);
  if (value === false) return Uint8Array.of(244);
  if (value === true) return Uint8Array.of(245);
  if (typeof value === "bigint") return encodeBigint(value);
  if (typeof value === "string") {
    const bytes2 = utf8(value);
    return concatBytes(encodeHead(3, BigInt(bytes2.length)), bytes2);
  }
  if (value instanceof Uint8Array) return concatBytes(encodeHead(2, BigInt(value.length)), value);
  if (Array.isArray(value)) return concatBytes(encodeHead(4, BigInt(value.length)), ...value.map(encodeCanonicalCbor));
  if (isMap(value)) {
    const entries = [...value].map(([key, item]) => ({ key: encodeCanonicalCbor(key), value: encodeCanonicalCbor(item) })).sort((a, b) => a.key.length === b.key.length ? compareBytes(a.key, b.key) : a.key.length - b.key.length);
    for (let index = 1; index < entries.length; index += 1) canonicalInvariant(!equalBytes(entries[index - 1].key, entries[index].key), "CBOR_NON_CANONICAL", "Duplicate canonical CBOR map key");
    return concatBytes(encodeHead(5, BigInt(entries.length)), ...entries.flatMap((entry) => [entry.key, entry.value]));
  }
  throw new CanonicalError("SCHEMA_INVALID", "Value is not supported by the deterministic CBOR profile");
}
var Decoder = class {
  constructor(input, limits) {
    this.input = input;
    this.limits = limits;
    canonicalInvariant(input.length <= limits.maxBytes, "CBOR_LIMIT_EXCEEDED", "CBOR input exceeds byte limit");
  }
  input;
  limits;
  offset = 0;
  decode() {
    const value = this.value(0);
    canonicalInvariant(this.offset === this.input.length, "CBOR_INVALID", "Trailing bytes after CBOR value");
    return value;
  }
  byte() {
    canonicalInvariant(this.offset < this.input.length, "CBOR_INVALID", "Unexpected end of CBOR input");
    return this.input[this.offset++];
  }
  bytes(size) {
    canonicalInvariant(Number.isSafeInteger(size) && size >= 0 && this.offset + size <= this.input.length, "CBOR_INVALID", "Invalid or truncated CBOR byte range");
    const value = this.input.slice(this.offset, this.offset + size);
    this.offset += size;
    return value;
  }
  argument(additional) {
    if (additional < 24) return BigInt(additional);
    const read = (size) => {
      const bytes2 = this.bytes(size);
      const view = new DataView(bytes2.buffer, bytes2.byteOffset, size);
      return size === 1 ? BigInt(bytes2[0]) : size === 2 ? BigInt(view.getUint16(0, false)) : size === 4 ? BigInt(view.getUint32(0, false)) : view.getBigUint64(0, false);
    };
    if (additional === 24) {
      const v = read(1);
      canonicalInvariant(v >= 24n, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 25) {
      const v = read(2);
      canonicalInvariant(v > 0xffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 26) {
      const v = read(4);
      canonicalInvariant(v > 0xffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 27) {
      const v = read(8);
      canonicalInvariant(v > 0xffffffffn, "CBOR_NON_CANONICAL", "Non-shortest CBOR integer");
      return v;
    }
    if (additional === 31) throw new CanonicalError("CBOR_NON_CANONICAL", "Indefinite-length CBOR is prohibited");
    throw new CanonicalError("CBOR_INVALID", "Reserved CBOR additional information");
  }
  bignum(tag, depth) {
    canonicalInvariant(tag === POSITIVE_BIGNUM_TAG || tag === NEGATIVE_BIGNUM_TAG, "CBOR_INVALID", "Unsupported CBOR tag");
    canonicalInvariant(depth < this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    canonicalInvariant(major === 2, "CBOR_INVALID", "CBOR bignum payload must be a byte string");
    const argument = this.argument(additional);
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR bignum is too large");
    const size = Number(argument);
    canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR bignum exceeds blob limit");
    const bytes2 = this.bytes(size);
    canonicalInvariant(bytes2.length > 8 && bytes2[0] !== 0, "CBOR_NON_CANONICAL", "CBOR bignum is not minimally encoded");
    let magnitude = 0n;
    for (const byte of bytes2) magnitude = magnitude << 8n | BigInt(byte);
    canonicalInvariant(magnitude > MAX_UINT64, "CBOR_NON_CANONICAL", "CBOR bignum must use the ordinary integer representation");
    return tag === POSITIVE_BIGNUM_TAG ? magnitude : -1n - magnitude;
  }
  value(depth) {
    canonicalInvariant(depth <= this.limits.maxDepth, "CBOR_LIMIT_EXCEEDED", "CBOR nesting exceeds limit");
    const initial = this.byte(), major = initial >> 5, additional = initial & 31;
    if (major === 7) {
      if (additional === 20) return false;
      if (additional === 21) return true;
      if (additional === 22) return null;
      throw new CanonicalError("CBOR_INVALID", "Floating point and unsupported simple CBOR values are prohibited");
    }
    const argument = this.argument(additional);
    if (major === 6) return this.bignum(argument, depth + 1);
    if (major === 0) return argument;
    if (major === 1) return -1n - argument;
    canonicalInvariant(argument <= BigInt(Number.MAX_SAFE_INTEGER), "CBOR_LIMIT_EXCEEDED", "CBOR collection is too large");
    const size = Number(argument);
    if (major === 2) {
      canonicalInvariant(size <= this.limits.maxBlobBytes, "CBOR_LIMIT_EXCEEDED", "CBOR blob exceeds limit");
      return this.bytes(size);
    }
    if (major === 3) {
      canonicalInvariant(size <= this.limits.maxTextBytes, "CBOR_LIMIT_EXCEEDED", "CBOR text exceeds limit");
      return decodeUtf8(this.bytes(size));
    }
    if (major === 4) {
      canonicalInvariant(size <= this.limits.maxArrayItems, "CBOR_LIMIT_EXCEEDED", "CBOR array exceeds item limit");
      return Array.from({ length: size }, () => this.value(depth + 1));
    }
    if (major === 5) {
      canonicalInvariant(size <= this.limits.maxMapItems, "CBOR_LIMIT_EXCEEDED", "CBOR map exceeds item limit");
      const map = /* @__PURE__ */ new Map();
      let previous;
      for (let index = 0; index < size; index += 1) {
        const start = this.offset, key = this.value(depth + 1);
        canonicalInvariant(typeof key === "bigint" || typeof key === "string" || key instanceof Uint8Array, "CBOR_INVALID", "Unsupported CBOR map key");
        const encoded = this.input.slice(start, this.offset);
        if (previous !== void 0) canonicalInvariant(previous.length === encoded.length ? compareBytes(previous, encoded) < 0 : previous.length < encoded.length, "CBOR_NON_CANONICAL", "CBOR map keys are duplicate or incorrectly ordered");
        previous = encoded;
        map.set(key, this.value(depth + 1));
      }
      return map;
    }
    throw new CanonicalError("CBOR_INVALID", `Unsupported CBOR major type ${major}`);
  }
};
function decodeCanonicalCbor(input, limits) {
  return new Decoder(input, limits).decode();
}
function assertCanonicalCbor(input, limits) {
  const value = decodeCanonicalCbor(input, limits);
  canonicalInvariant(equalBytes(encodeCanonicalCbor(value), input), "CBOR_NON_CANONICAL", "CBOR bytes are not canonical");
  return value;
}

// packages/canonical/src/hash.ts
var HASH_DOMAINS = Object.freeze({
  transaction: "chronolog/transaction",
  schema: "chronolog/schema",
  executionManifest: "chronolog/execution-manifest",
  queryResult: "chronolog/query-result",
  expectation: "chronolog/expectation",
  module: "chronolog/module",
  entropy: "chronolog/entropy",
  platformObject: "chronolog/platform-object"
});
function bufferSource(value) {
  return Uint8Array.from(value).buffer;
}
async function sha256(payload) {
  return new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bufferSource(payload)));
}

// packages/protocol/src/errors.ts
var ProtocolError = class extends Error {
  code;
  details;
  constructor(code, message, details) {
    super(message);
    this.name = "ProtocolError";
    this.code = code;
    this.details = details;
  }
  toJSON() {
    return this.details === void 0 ? { name: this.name, code: this.code, message: this.message } : { name: this.name, code: this.code, message: this.message, details: this.details };
  }
};
function protocolInvariant(condition, code, message, details) {
  if (!condition) throw new ProtocolError(code, message, details);
}

// packages/protocol/src/bytes.ts
function wrap(operation) {
  try {
    return operation();
  } catch (error) {
    if (error instanceof ProtocolError) throw error;
    if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
    throw error;
  }
}
function utf82(value) {
  return wrap(() => utf8(value));
}
function bytesToHex2(value) {
  return bytesToHex(value);
}
function hexToBytes2(value) {
  return wrap(() => hexToBytes(value));
}

// packages/protocol/src/cbor.ts
function sharedLimits(limits) {
  return {
    maxBytes: limits.maxBytes ?? DEFAULT_DECODE_LIMITS.maxBytes,
    maxDepth: limits.maxDepth ?? DEFAULT_DECODE_LIMITS.maxDepth,
    maxArrayItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxArrayItems,
    maxMapItems: limits.maxItems ?? DEFAULT_DECODE_LIMITS.maxMapItems,
    maxTextBytes: limits.maxTextBytes ?? DEFAULT_DECODE_LIMITS.maxTextBytes,
    maxBlobBytes: limits.maxByteStringBytes ?? DEFAULT_DECODE_LIMITS.maxBlobBytes
  };
}
function protocolError(error) {
  if (error instanceof ProtocolError) throw error;
  if (error instanceof CanonicalError) throw new ProtocolError(error.code, error.message, error.details);
  throw error;
}
function assertCanonicalCbor2(input, limits = {}) {
  try {
    return assertCanonicalCbor(input, sharedLimits(limits));
  } catch (error) {
    return protocolError(error);
  }
}

// packages/protocol/src/schema.ts
function integerMap(entries) {
  const result = /* @__PURE__ */ new Map();
  for (const [key, value] of entries) {
    if (value !== void 0) result.set(BigInt(key), value);
  }
  return result;
}
function expectMap(value, name2) {
  protocolInvariant(value instanceof Map, "SCHEMA_INVALID", `${name2} must be a CBOR map`);
  return value;
}
function expectArray(value, name2) {
  protocolInvariant(Array.isArray(value), "SCHEMA_INVALID", `${name2} must be a CBOR array`);
  return value;
}
function expectBytes(value, name2, length) {
  protocolInvariant(value instanceof Uint8Array, "SCHEMA_INVALID", `${name2} must be bytes`);
  if (length !== void 0) {
    protocolInvariant(value.length === length, "SCHEMA_INVALID", `${name2} must contain ${length} bytes`);
  }
  return value;
}
function expectString(value, name2) {
  protocolInvariant(typeof value === "string", "SCHEMA_INVALID", `${name2} must be text`);
  return value;
}
function expectBigint(value, name2) {
  protocolInvariant(typeof value === "bigint", "SCHEMA_INVALID", `${name2} must be an integer`);
  return value;
}
function expectUint64(value, name2) {
  const integer = expectBigint(value, name2);
  protocolInvariant(integer >= 0n && integer <= (1n << 64n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside uint64 range`);
  return integer;
}
function expectInt64(value, name2) {
  const integer = expectBigint(value, name2);
  protocolInvariant(integer >= -(1n << 63n) && integer <= (1n << 63n) - 1n, "INTEGER_OUT_OF_RANGE", `${name2} is outside int64 range`);
  return integer;
}
function required(map, key, name2) {
  const value = map.get(BigInt(key));
  if (value === void 0) throw new ProtocolError("SCHEMA_INVALID", `Missing required field ${name2}`, { field: name2 });
  return value;
}
function optional(map, key) {
  return map.get(BigInt(key));
}
function assertKnownIntegerKeys(map, knownKeys, name2) {
  const known = new Set(knownKeys.map(BigInt));
  for (const key of map.keys()) {
    protocolInvariant(typeof key === "bigint", "SCHEMA_INVALID", `${name2} contains a non-integer field key`);
    protocolInvariant(known.has(key), "SCHEMA_INVALID", `${name2} contains unknown critical field ${String(key)}`);
  }
}
function expectVersion(map, expected, name2) {
  const version2 = expectUint64(required(map, 0, `${name2}.version`), `${name2}.version`);
  protocolInvariant(version2 === expected, "UNSUPPORTED_VERSION", `Unsupported ${name2} version`, { version: version2.toString() });
}

// packages/protocol/src/sql.ts
var MAX_SQL_STATEMENT_BINDINGS = 1e3;
var MIN_INT64 = -(1n << 63n);
var MAX_INT64 = (1n << 63n) - 1n;
var sqlValue = Object.freeze({
  null: () => ({ kind: "null" }),
  integer: (value) => {
    const integer = typeof value === "bigint" ? value : BigInt(value);
    protocolInvariant(integer >= MIN_INT64 && integer <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
    return { kind: "integer", value: integer };
  },
  real: (value) => {
    protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "SQL REAL must be finite");
    return { kind: "real", value };
  },
  text: (value) => {
    utf82(value);
    return { kind: "text", value };
  },
  blob: (value) => ({ kind: "blob", value: Uint8Array.from(value) })
});
function toSqlValue(value) {
  if (value === null || value === void 0) return sqlValue.null();
  if (typeof value === "bigint") return sqlValue.integer(value);
  if (typeof value === "number") return Number.isSafeInteger(value) ? sqlValue.integer(value) : sqlValue.real(value);
  if (typeof value === "boolean") return sqlValue.integer(value ? 1n : 0n);
  if (typeof value === "string") return sqlValue.text(value);
  if (value instanceof Uint8Array) return sqlValue.blob(value);
  if (isSqlValue(value)) return value;
  throw new TypeError("SQL values must be null, boolean, bigint, number, string, Uint8Array or a tagged SqlValue");
}
function isSqlValue(value) {
  if (typeof value !== "object" || value === null || !("kind" in value)) return false;
  const tagged = value;
  switch (tagged.kind) {
    case "null":
      return true;
    case "integer":
      return typeof tagged.value === "bigint";
    case "real":
      return typeof tagged.value === "number";
    case "text":
      return typeof tagged.value === "string";
    case "blob":
      return tagged.value instanceof Uint8Array;
    default:
      return false;
  }
}
function realBits(value) {
  const bits = new Uint8Array(8);
  new DataView(bits.buffer).setFloat64(0, value, false);
  return bits;
}
function sqlValueToCanonicalCbor(value) {
  switch (value.kind) {
    case "null":
      return [0n];
    case "integer":
      protocolInvariant(value.value >= MIN_INT64 && value.value <= MAX_INT64, "INTEGER_OUT_OF_RANGE", "SQL INTEGER must be signed 64-bit");
      return [1n, value.value];
    case "real":
      protocolInvariant(Number.isFinite(value.value), "SCHEMA_INVALID", "SQL REAL must be finite");
      return [2n, realBits(value.value)];
    case "text":
      utf82(value.value);
      return [3n, value.value];
    case "blob":
      return [4n, Uint8Array.from(value.value)];
  }
}
function sqlValueFromCanonicalCbor(value, name2 = "sql_value") {
  const tuple = expectArray(value, name2);
  const kind = expectUint64(tuple[0] ?? null, `${name2}.kind`);
  protocolInvariant(tuple.length === (kind === 0n ? 1 : 2), "SCHEMA_INVALID", `${name2} has invalid arity`);
  switch (kind) {
    case 0n:
      return { kind: "null" };
    case 1n:
      return { kind: "integer", value: expectInt64(tuple[1] ?? null, `${name2}.integer`) };
    case 2n: {
      const bits = expectBytes(tuple[1] ?? null, `${name2}.real`, 8);
      const real = new DataView(bits.buffer, bits.byteOffset, 8).getFloat64(0, false);
      protocolInvariant(Number.isFinite(real), "SCHEMA_INVALID", `${name2}.real must be finite`);
      return { kind: "real", value: real };
    }
    case 3n:
      return { kind: "text", value: expectString(tuple[1] ?? null, `${name2}.text`) };
    case 4n:
      return { kind: "blob", value: Uint8Array.from(expectBytes(tuple[1] ?? null, `${name2}.blob`)) };
    default:
      protocolInvariant(false, "SCHEMA_INVALID", `${name2} has unknown kind`);
  }
}
function bindingToCbor(binding) {
  if (binding.parameter.kind === "index") {
    const index = binding.parameter.index;
    protocolInvariant(Number.isSafeInteger(index) && index >= 1, "INTEGER_OUT_OF_RANGE", "SQL binding index must be a positive integer");
    return [[0n, BigInt(index)], sqlValueToCanonicalCbor(binding.value)];
  }
  protocolInvariant(/^[:@$].+/u.test(binding.parameter.name), "SCHEMA_INVALID", "Named SQL bindings must keep their SQLite prefix (:, @ or $)");
  return [[1n, binding.parameter.name], sqlValueToCanonicalCbor(binding.value)];
}
function bindingFromCbor(value, name2) {
  const tuple = expectArray(value, name2);
  protocolInvariant(tuple.length === 2, "SCHEMA_INVALID", `${name2} has invalid arity`);
  const parameter = expectArray(tuple[0] ?? null, `${name2}.parameter`);
  protocolInvariant(parameter.length === 2, "SCHEMA_INVALID", `${name2}.parameter has invalid arity`);
  const kind = expectUint64(parameter[0] ?? null, `${name2}.parameter.kind`);
  let decoded;
  if (kind === 0n) {
    const index = expectUint64(parameter[1] ?? null, `${name2}.parameter.index`);
    protocolInvariant(index >= 1n && index <= BigInt(MAX_SQL_STATEMENT_BINDINGS), "INTEGER_OUT_OF_RANGE", `${name2}.parameter.index is out of range`);
    decoded = { kind: "index", index: Number(index) };
  } else {
    protocolInvariant(kind === 1n, "SCHEMA_INVALID", `${name2}.parameter has unknown kind`);
    const parameterName = expectString(parameter[1] ?? null, `${name2}.parameter.name`);
    protocolInvariant(/^[:@$].+/u.test(parameterName), "SCHEMA_INVALID", `${name2}.parameter.name must keep its SQLite prefix`);
    decoded = { kind: "name", name: parameterName };
  }
  return { parameter: decoded, value: sqlValueFromCanonicalCbor(tuple[1] ?? null, `${name2}.value`) };
}
function parameterKey(parameter) {
  return parameter.kind === "index" ? `#${parameter.index}` : parameter.name;
}
function sqlStatementToCanonicalCbor(value) {
  protocolInvariant(typeof value.sql === "string" && value.sql.trim().length > 0, "SCHEMA_INVALID", "SQL statement source cannot be empty");
  protocolInvariant(!value.sql.includes("\0"), "SCHEMA_INVALID", "SQL statement source cannot contain U+0000");
  utf82(value.sql);
  protocolInvariant(value.bindings.length <= MAX_SQL_STATEMENT_BINDINGS, "SCHEMA_INVALID", "SQL statement has too many bindings");
  const seen = /* @__PURE__ */ new Set();
  for (const binding of value.bindings) {
    const key = parameterKey(binding.parameter);
    protocolInvariant(!seen.has(key), "SCHEMA_INVALID", "SQL statement binds a parameter twice");
    seen.add(key);
  }
  return integerMap([[0, value.sql], [1, value.bindings.map(bindingToCbor)]]);
}
function sqlStatementFromCanonicalCbor(value, name2 = "sql_statement") {
  const map = expectMap(value, name2);
  assertKnownIntegerKeys(map, [0, 1], name2);
  const statement = {
    sql: expectString(required(map, 0, `${name2}.sql`), `${name2}.sql`),
    bindings: expectArray(required(map, 1, `${name2}.bindings`), `${name2}.bindings`).map((binding, index) => bindingFromCbor(binding, `${name2}.bindings[${index}]`))
  };
  sqlStatementToCanonicalCbor(statement);
  return statement;
}
var DEFAULT_EXECUTION_LIMITS = Object.freeze({
  maxSqlBytes: 1e6,
  maxVmSteps: 1e6,
  maxValueBytes: 16 * 1024 * 1024
});

// packages/protocol/src/sealed.ts
var MAX_SEALED_READERS = 256;
var MAX_SEALED_NAME_BYTES = 128;
var MAX_SEALED_ROW_KEY_VALUES = 64;
var MAX_SEALED_PLAINTEXT_BYTES = 1024 * 1024;
var MAX_SEALED_ENVELOPE_BYTES = MAX_SEALED_PLAINTEXT_BYTES + MAX_SEALED_READERS * 192 + 1024;
var MAX_SEALED_VERSION = (1n << 63n) - 1n;
var SEALED_OP_CODES = Object.freeze({
  register_reader_key: 64n,
  reader_policy: 65n,
  sealed_put: 66n
});
function isSealedPlatformOp(value) {
  return typeof value === "object" && value !== null && "op" in value && typeof value.op === "string" && Object.hasOwn(SEALED_OP_CODES, value.op);
}
var sealedOp = Object.freeze({
  registerReaderKey: (publicKey) => checked({ op: "register_reader_key", publicKey: id(publicKey, "register_reader_key.public_key") }),
  readerPolicy: (input) => checked({
    op: "reader_policy",
    table: input.table,
    rowKey: input.rowKey.map(toSqlValue),
    expectedVersion: input.expectedVersion,
    ...input.expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(input.expectedPolicyId, "reader_policy.expected_policy_id") },
    readers: input.readers.map((reader) => id(reader, "reader_policy.reader")).sort(compareBytes)
  }),
  put: (input) => checked({
    op: "sealed_put",
    policyId: id(input.policyId, "sealed_put.policy_id"),
    expectedPolicyVersion: input.expectedPolicyVersion,
    expectedDataVersion: input.expectedDataVersion,
    slot: input.slot,
    envelope: decodeSealedEnvelope(encodeSealedEnvelope(input.envelope))
  })
});
function checked(op) {
  return sealedPlatformOpFromCanonicalCbor(sealedPlatformOpToCanonicalCbor(op));
}
function id(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === 32, "SCHEMA_INVALID", `${field} must contain 32 bytes`);
  return Uint8Array.from(value);
}
function name(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0 && !value.includes("\0"), "SCHEMA_INVALID", `${field} must be nonempty text without U+0000`);
  protocolInvariant(utf82(value).length <= MAX_SEALED_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function version(value, field, minimum = 1n, maximum = MAX_SEALED_VERSION) {
  const parsed = expectUint64(value, field);
  protocolInvariant(parsed >= minimum && parsed <= maximum, "INTEGER_OUT_OF_RANGE", `${field} is outside the supported version range`);
  return parsed;
}
var isList = (value) => Array.isArray(value);
function orderedReaders(readers, field) {
  protocolInvariant(isList(readers) && readers.length <= MAX_SEALED_READERS, "SCHEMA_INVALID", `${field} has too many readers or is not an array`);
  return readers.map((reader, index) => {
    const key = id(reader, field);
    if (index > 0) protocolInvariant(compareBytes(readers[index - 1], reader) < 0, "SCHEMA_INVALID", `${field} must be sorted and unique`);
    return key;
  });
}
function sealedContextToCanonicalCbor(value) {
  return integerMap([
    [0, 1n],
    [1, id(value.groupId, "sealed_context.group_id")],
    [2, id(value.policyId, "sealed_context.policy_id")],
    [3, version(value.policyVersion, "sealed_context.policy_version")],
    [4, name(value.slot, "sealed_context.slot")],
    [5, version(value.dataVersion, "sealed_context.data_version")]
  ]);
}
function sealedContextFromCanonicalCbor(value) {
  const map = expectMap(value, "sealed_context");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], "sealed_context");
  expectVersion(map, 1n, "sealed_context");
  const context = {
    groupId: id(expectBytes(required(map, 1, "group_id"), "group_id", 32), "group_id"),
    policyId: id(expectBytes(required(map, 2, "policy_id"), "policy_id", 32), "policy_id"),
    policyVersion: expectUint64(required(map, 3, "policy_version"), "policy_version"),
    slot: expectString(required(map, 4, "slot"), "slot"),
    dataVersion: expectUint64(required(map, 5, "data_version"), "data_version")
  };
  sealedContextToCanonicalCbor(context);
  return context;
}
function sealedEnvelopeToCanonicalCbor(value) {
  protocolInvariant(value.nonce instanceof Uint8Array && value.nonce.length === 12, "SCHEMA_INVALID", "sealed_envelope.nonce must contain 12 bytes");
  protocolInvariant(
    value.ciphertext instanceof Uint8Array && value.ciphertext.length >= 16 && value.ciphertext.length <= MAX_SEALED_PLAINTEXT_BYTES + 16,
    "SCHEMA_INVALID",
    "sealed_envelope.ciphertext has an invalid length"
  );
  protocolInvariant(isList(value.wraps), "SCHEMA_INVALID", "sealed_envelope.wraps must be an array");
  orderedReaders(value.wraps.map((wrap2) => wrap2.readerId), "sealed_envelope.wraps");
  return integerMap([
    [0, 1n],
    [1, sealedContextToCanonicalCbor(value.context)],
    [2, Uint8Array.from(value.nonce)],
    [3, Uint8Array.from(value.ciphertext)],
    [4, value.wraps.map((wrap2) => {
      protocolInvariant(wrap2.ciphertext instanceof Uint8Array && wrap2.ciphertext.length === 48, "SCHEMA_INVALID", "sealed_wrap.ciphertext must contain 48 bytes");
      return [
        id(wrap2.readerId, "sealed_wrap.reader_id"),
        id(wrap2.publicKey, "sealed_wrap.public_key"),
        id(wrap2.encapsulatedKey, "sealed_wrap.encapsulated_key"),
        Uint8Array.from(wrap2.ciphertext)
      ];
    })]
  ]);
}
function sealedEnvelopeFromCanonicalCbor(value) {
  const map = expectMap(value, "sealed_envelope");
  assertKnownIntegerKeys(map, [0, 1, 2, 3, 4], "sealed_envelope");
  expectVersion(map, 1n, "sealed_envelope");
  const envelope = {
    context: sealedContextFromCanonicalCbor(required(map, 1, "context")),
    nonce: Uint8Array.from(expectBytes(required(map, 2, "nonce"), "nonce", 12)),
    ciphertext: Uint8Array.from(expectBytes(required(map, 3, "ciphertext"), "ciphertext")),
    wraps: expectArray(required(map, 4, "wraps"), "wraps").map((entry) => {
      const fields = expectArray(entry, "sealed_wrap");
      protocolInvariant(fields.length === 4, "SCHEMA_INVALID", "sealed_wrap must contain four fields");
      return {
        readerId: id(expectBytes(fields[0], "reader_id", 32), "reader_id"),
        publicKey: id(expectBytes(fields[1], "public_key", 32), "public_key"),
        encapsulatedKey: id(expectBytes(fields[2], "encapsulated_key", 32), "encapsulated_key"),
        ciphertext: Uint8Array.from(expectBytes(fields[3], "wrapped_key", 48))
      };
    })
  };
  sealedEnvelopeToCanonicalCbor(envelope);
  return envelope;
}
function encodeSealedEnvelope(envelope) {
  return encodeCanonicalCbor(sealedEnvelopeToCanonicalCbor(envelope));
}
function decodeSealedEnvelope(bytes2) {
  protocolInvariant(bytes2.length <= MAX_SEALED_ENVELOPE_BYTES, "SCHEMA_INVALID", "sealed_envelope exceeds the encoded size limit");
  return sealedEnvelopeFromCanonicalCbor(assertCanonicalCbor2(bytes2));
}
function sealedPlatformOpToCanonicalCbor(op) {
  protocolInvariant(isSealedPlatformOp(op), "SCHEMA_INVALID", "Unknown sealed operation");
  const entries = [[0, SEALED_OP_CODES[op.op]]];
  switch (op.op) {
    case "register_reader_key":
      entries.push([1, id(op.publicKey, "register_reader_key.public_key")]);
      break;
    case "reader_policy": {
      const expected = version(op.expectedVersion, "reader_policy.expected_version", 0n, MAX_SEALED_VERSION - 1n);
      protocolInvariant(expected === 0n === (op.expectedPolicyId === void 0), "SCHEMA_INVALID", "reader_policy creation uses version 0 without an id; replacement requires an id and positive version");
      protocolInvariant(isList(op.rowKey) && op.rowKey.length >= 1 && op.rowKey.length <= MAX_SEALED_ROW_KEY_VALUES, "SCHEMA_INVALID", "reader_policy.row_key has an invalid length");
      entries.push(
        [1, name(op.table, "reader_policy.table")],
        [2, op.rowKey.map(sqlValueToCanonicalCbor)],
        [3, op.expectedPolicyId === void 0 ? void 0 : id(op.expectedPolicyId, "reader_policy.expected_policy_id")],
        [4, expected],
        [5, orderedReaders(op.readers, "reader_policy.readers")]
      );
      break;
    }
    case "sealed_put": {
      const policyId = id(op.policyId, "sealed_put.policy_id");
      const policyVersion = version(op.expectedPolicyVersion, "sealed_put.expected_policy_version");
      const dataVersion = version(op.expectedDataVersion, "sealed_put.expected_data_version", 0n, MAX_SEALED_VERSION - 1n);
      const slot = name(op.slot, "sealed_put.slot");
      const envelope = sealedEnvelopeToCanonicalCbor(op.envelope);
      protocolInvariant(
        equalBytes(op.envelope.context.policyId, policyId) && op.envelope.context.policyVersion === policyVersion && op.envelope.context.slot === slot && op.envelope.context.dataVersion === dataVersion + 1n,
        "SCHEMA_INVALID",
        "sealed_put envelope does not match its policy, slot or next data version"
      );
      entries.push([1, policyId], [2, policyVersion], [3, dataVersion], [4, slot], [5, envelope]);
      break;
    }
  }
  return integerMap(entries);
}
function sealedPlatformOpFromCanonicalCbor(value, field = "sealed_op") {
  const map = expectMap(value, field);
  const code = expectUint64(required(map, 0, `${field}.op`), `${field}.op`);
  let op;
  if (code === SEALED_OP_CODES.register_reader_key) {
    assertKnownIntegerKeys(map, [0, 1], field);
    op = { op: "register_reader_key", publicKey: id(expectBytes(required(map, 1, "public_key"), "public_key", 32), "public_key") };
  } else if (code === SEALED_OP_CODES.reader_policy) {
    assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], field);
    const expectedPolicyId = optional(map, 3);
    op = {
      op: "reader_policy",
      table: expectString(required(map, 1, "table"), "table"),
      rowKey: expectArray(required(map, 2, "row_key"), "row_key").map((item, index) => sqlValueFromCanonicalCbor(item, `row_key[${index}]`)),
      ...expectedPolicyId === void 0 ? {} : { expectedPolicyId: id(expectBytes(expectedPolicyId, "expected_policy_id", 32), "expected_policy_id") },
      expectedVersion: expectUint64(required(map, 4, "expected_version"), "expected_version"),
      readers: expectArray(required(map, 5, "readers"), "readers").map((reader) => id(expectBytes(reader, "reader", 32), "reader"))
    };
  } else if (code === SEALED_OP_CODES.sealed_put) {
    assertKnownIntegerKeys(map, [0, 1, 2, 3, 4, 5], field);
    op = {
      op: "sealed_put",
      policyId: id(expectBytes(required(map, 1, "policy_id"), "policy_id", 32), "policy_id"),
      expectedPolicyVersion: expectUint64(required(map, 2, "expected_policy_version"), "expected_policy_version"),
      expectedDataVersion: expectUint64(required(map, 3, "expected_data_version"), "expected_data_version"),
      slot: expectString(required(map, 4, "slot"), "slot"),
      envelope: sealedEnvelopeFromCanonicalCbor(required(map, 5, "envelope"))
    };
  } else {
    protocolInvariant(false, "SCHEMA_INVALID", `${field} has an unknown sealed operation`);
  }
  sealedPlatformOpToCanonicalCbor(op);
  return op;
}

// packages/protocol/src/platform.ts
var PLATFORM_ID_BYTES = 32;
var MAX_PLATFORM_NAME_BYTES = 128;
var MAX_PLATFORM_LIST_ENTRIES = 256;
var MAX_ROW_KEY_VALUES = 64;
var MAX_SEED_ROWS = 1e4;
var GROUP_COLLECTIVE_ID = new Uint8Array(PLATFORM_ID_BYTES);
var APPLICATION_COLLECTIVE_ID = hexToBytes2("d089b2593cdd5a4a10734f1f7253cea7b72501dffebfcadfed37be1d01557608");
var OP_CODES = [
  "grant",
  "revoke_grant",
  "create_collective",
  "accept_membership",
  "leave",
  "set_members",
  "transfer_offer",
  "transfer_accept",
  "seed_rows",
  "end_seeding",
  "transfer_cancel"
];
var OPERATION_BITS = { insert: 1n, update: 2n, delete: 4n };
var GRANT_OPERATIONS = ["insert", "update", "delete"];
function isPlatformOp(value) {
  return isSealedPlatformOp(value) || typeof value === "object" && value !== null && "op" in value && OP_CODES.includes(value.op);
}
var bytes = (value) => Uint8Array.from(value);
var rowKey = (values) => values.map(toSqlValue);
var platformOp = Object.freeze({
  ...sealedOp,
  grant: (input) => checked2({
    op: "grant",
    table: input.table,
    grantee: bytes(input.grantee),
    operations: [...input.operations],
    ...input.grantor === void 0 ? {} : { grantor: bytes(input.grantor) },
    ...input.rowKey === void 0 ? {} : { rowKey: rowKey(input.rowKey) },
    ...input.columns === void 0 ? {} : { columns: [...input.columns] }
  }),
  revokeGrant: (grantId) => checked2({ op: "revoke_grant", grantId: bytes(grantId) }),
  createCollective: (input) => checked2({ op: "create_collective", governance: { ...input.governance }, invitees: (input.invitees ?? []).map(bytes) }),
  acceptMembership: (collectiveId) => checked2({ op: "accept_membership", collectiveId: bytes(collectiveId) }),
  leave: (collectiveId) => checked2({ op: "leave", collectiveId: bytes(collectiveId) }),
  setMembers: (collectiveId, changes) => checked2({
    op: "set_members",
    collectiveId: bytes(collectiveId),
    changes: changes.map((change) => ({ member: bytes(change.member), role: change.role }))
  }),
  transferRow: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "row", table: input.table, rowKey: rowKey(input.rowKey) },
    toOwner: bytes(input.toOwner),
    carry: input.carry ?? false,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  transferAll: (input) => checked2({
    op: "transfer_offer",
    scope: { kind: "all" },
    toOwner: bytes(input.toOwner),
    carry: true,
    ...input.fromOwner === void 0 ? {} : { fromOwner: bytes(input.fromOwner) }
  }),
  acceptTransfer: (offerId) => checked2({ op: "transfer_accept", offerId: bytes(offerId) }),
  cancelTransfer: (offerId) => checked2({ op: "transfer_cancel", offerId: bytes(offerId) }),
  seedRows: (table, columns, rows) => checked2({ op: "seed_rows", table, columns: [...columns], rows: rows.map(rowKey) }),
  endSeeding: () => checked2({ op: "end_seeding" })
});
function checked2(op) {
  platformOpToCanonicalCbor(op);
  return op;
}
function nameToCbor(value, field) {
  protocolInvariant(typeof value === "string" && value.length > 0, "SCHEMA_INVALID", `${field} cannot be empty`);
  protocolInvariant(!value.includes("\0"), "SCHEMA_INVALID", `${field} cannot contain U+0000`);
  protocolInvariant(utf82(value).length <= MAX_PLATFORM_NAME_BYTES, "SCHEMA_INVALID", `${field} is too long`);
  return value;
}
function idToCbor(value, field) {
  protocolInvariant(value instanceof Uint8Array && value.length === PLATFORM_ID_BYTES, "SCHEMA_INVALID", `${field} must contain ${PLATFORM_ID_BYTES} bytes`);
  return Uint8Array.from(value);
}
function listToCbor(values, field, encode, minimum = 0) {
  protocolInvariant(isList2(values), "SCHEMA_INVALID", `${field} must be a list`);
  protocolInvariant(values.length >= minimum && values.length <= MAX_PLATFORM_LIST_ENTRIES, "SCHEMA_INVALID", `${field} has an invalid number of entries`);
  return values.map(encode);
}
function uniqueBy(values, key, field) {
  const seen = /* @__PURE__ */ new Set();
  for (const value of values) {
    const entry = key(value);
    protocolInvariant(!seen.has(entry), "SCHEMA_INVALID", `${field} contains a duplicate`);
    seen.add(entry);
  }
}
var hex = (value) => bytesToHex2(value);
var isList2 = (value) => Array.isArray(value);
function rowKeyToCbor(values, field) {
  protocolInvariant(isList2(values) && values.length >= 1 && values.length <= MAX_ROW_KEY_VALUES, "SCHEMA_INVALID", `${field} must have 1 to ${MAX_ROW_KEY_VALUES} values`);
  return values.map(sqlValueToCanonicalCbor);
}
function roleCode(role, field) {
  protocolInvariant(role === "member" || role === "admin", "SCHEMA_INVALID", `${field} must be member or admin`);
  return role === "member" ? 0n : 1n;
}
function roleFromCode(value, field) {
  const code = expectUint64(value, field);
  protocolInvariant(code <= 1n, "SCHEMA_INVALID", `${field} must be member or admin`);
  return code === 0n ? "member" : "admin";
}
function platformOpToCanonicalCbor(op) {
  if (isSealedPlatformOp(op)) return sealedPlatformOpToCanonicalCbor(op);
  const code = OP_CODES.indexOf(op.op);
  protocolInvariant(code >= 0, "SCHEMA_INVALID", "Unknown platform operation");
  const entries = [[0, BigInt(code)]];
  switch (op.op) {
    case "grant": {
      protocolInvariant(isList2(op.operations) && op.operations.length > 0, "SCHEMA_INVALID", "grant.operations cannot be empty");
      uniqueBy(op.operations, (value) => value, "grant.operations");
      let mask = 0n;
      for (const operation of op.operations) {
        protocolInvariant(GRANT_OPERATIONS.includes(operation), "SCHEMA_INVALID", "grant.operations has an unknown operation");
        mask |= OPERATION_BITS[operation];
      }
      protocolInvariant(
        GRANT_OPERATIONS.filter((operation) => op.operations.includes(operation)).every((operation, index) => op.operations[index] === operation),
        "SCHEMA_INVALID",
        "grant.operations must be in insert, update, delete order"
      );
      if (op.columns !== void 0) uniqueBy(op.columns, (value) => value, "grant.columns");
      entries.push(
        [1, nameToCbor(op.table, "grant.table")],
        [2, idToCbor(op.grantee, "grant.grantee")],
        [3, mask],
        [4, op.grantor === void 0 ? void 0 : idToCbor(op.grantor, "grant.grantor")],
        [5, op.rowKey === void 0 ? void 0 : rowKeyToCbor(op.rowKey, "grant.row_key")],
        [6, op.columns === void 0 ? void 0 : listToCbor(op.columns, "grant.columns", (column) => nameToCbor(column, "grant.columns"), 1)]
      );
      break;
    }
    case "revoke_grant":
      entries.push([1, idToCbor(op.grantId, "revoke_grant.grant_id")]);
      break;
    case "create_collective":
      uniqueBy(op.invitees, hex, "create_collective.invitees");
      entries.push(
        [1, integerMap([
          [0, roleCode(op.governance.insert, "governance.insert")],
          [1, roleCode(op.governance.update, "governance.update")],
          [2, roleCode(op.governance.delete, "governance.delete")]
        ])],
        [2, listToCbor(op.invitees, "create_collective.invitees", (key) => idToCbor(key, "create_collective.invitees"))]
      );
      break;
    case "accept_membership":
    case "leave":
      entries.push([1, idToCbor(op.collectiveId, `${op.op}.collective_id`)]);
      break;
    case "set_members":
      uniqueBy(op.changes, (change) => hex(change.member), "set_members.changes");
      entries.push(
        [1, idToCbor(op.collectiveId, "set_members.collective_id")],
        [2, listToCbor(op.changes, "set_members.changes", (change) => [
          idToCbor(change.member, "set_members.member"),
          change.role === "remove" ? 2n : roleCode(change.role, "set_members.role")
        ], 1)]
      );
      break;
    case "transfer_offer": {
      protocolInvariant(typeof op.carry === "boolean", "SCHEMA_INVALID", "transfer_offer.carry must be a boolean");
      let scope2;
      if (op.scope.kind === "all") {
        protocolInvariant(op.carry, "SCHEMA_INVALID", "A transfer of all rows always carries dependents");
        scope2 = [1n];
      } else {
        protocolInvariant(op.scope.kind === "row", "SCHEMA_INVALID", "transfer_offer.scope is unknown");
        scope2 = [0n, nameToCbor(op.scope.table, "transfer_offer.table"), rowKeyToCbor(op.scope.rowKey, "transfer_offer.row_key")];
      }
      entries.push(
        [1, scope2],
        [2, op.fromOwner === void 0 ? void 0 : idToCbor(op.fromOwner, "transfer_offer.from_owner")],
        [3, idToCbor(op.toOwner, "transfer_offer.to_owner")],
        [4, op.carry ? 1n : 0n]
      );
      break;
    }
    case "transfer_accept":
    case "transfer_cancel":
      entries.push([1, idToCbor(op.offerId, `${op.op}.offer_id`)]);
      break;
    case "seed_rows": {
      uniqueBy(op.columns, (value) => value.toLowerCase(), "seed_rows.columns");
      protocolInvariant(isList2(op.rows) && op.rows.length >= 1 && op.rows.length <= MAX_SEED_ROWS, "SCHEMA_INVALID", "seed_rows.rows has an invalid number of rows");
      entries.push(
        [1, nameToCbor(op.table, "seed_rows.table")],
        [2, listToCbor(op.columns, "seed_rows.columns", (column) => nameToCbor(column, "seed_rows.columns"), 1)],
        [3, op.rows.map((row) => {
          protocolInvariant(isList2(row) && row.length === op.columns.length, "SCHEMA_INVALID", "seed_rows row width must match its columns");
          return row.map(sqlValueToCanonicalCbor);
        })]
      );
      break;
    }
    case "end_seeding":
      break;
  }
  return integerMap(entries);
}
var KNOWN_KEYS = {
  grant: [0, 1, 2, 3, 4, 5, 6],
  revoke_grant: [0, 1],
  create_collective: [0, 1, 2],
  accept_membership: [0, 1],
  leave: [0, 1],
  set_members: [0, 1, 2],
  transfer_offer: [0, 1, 2, 3, 4],
  transfer_accept: [0, 1],
  transfer_cancel: [0, 1],
  seed_rows: [0, 1, 2, 3],
  end_seeding: [0]
};
function platformOpFromCanonicalCbor(value, name2 = "platform_op") {
  const map = expectMap(value, name2);
  const code = expectUint64(required(map, 0, `${name2}.op`), `${name2}.op`);
  if (code >= 64n) return sealedPlatformOpFromCanonicalCbor(value, name2);
  protocolInvariant(code < BigInt(OP_CODES.length), "SCHEMA_INVALID", `${name2} has an unknown operation`);
  const kind = OP_CODES[Number(code)];
  assertKnownIntegerKeys(map, KNOWN_KEYS[kind], name2);
  const text = (key, field) => expectString(required(map, key, `${name2}.${field}`), `${name2}.${field}`);
  const id2 = (key, field) => Uint8Array.from(expectBytes(required(map, key, `${name2}.${field}`), `${name2}.${field}`, PLATFORM_ID_BYTES));
  const optionalId = (key, field) => {
    const entry = optional(map, key);
    return entry === void 0 ? void 0 : Uint8Array.from(expectBytes(entry, `${name2}.${field}`, PLATFORM_ID_BYTES));
  };
  const values = (entry, field) => expectArray(entry, field).map((item, index) => sqlValueFromCanonicalCbor(item, `${field}[${index}]`));
  let op;
  switch (kind) {
    case "grant": {
      const mask = expectUint64(required(map, 3, `${name2}.operations`), `${name2}.operations`);
      protocolInvariant(mask >= 1n && mask <= 7n, "SCHEMA_INVALID", `${name2}.operations is invalid`);
      const grantor = optionalId(4, "grantor");
      const key = optional(map, 5);
      const columns = optional(map, 6);
      op = {
        op: kind,
        table: text(1, "table"),
        grantee: id2(2, "grantee"),
        operations: GRANT_OPERATIONS.filter((operation) => (mask & OPERATION_BITS[operation]) !== 0n),
        ...grantor === void 0 ? {} : { grantor },
        ...key === void 0 ? {} : { rowKey: values(key, `${name2}.row_key`) },
        ...columns === void 0 ? {} : { columns: expectArray(columns, `${name2}.columns`).map((column) => expectString(column, `${name2}.columns`)) }
      };
      break;
    }
    case "revoke_grant":
      op = { op: kind, grantId: id2(1, "grant_id") };
      break;
    case "create_collective": {
      const governance = expectMap(required(map, 1, `${name2}.governance`), `${name2}.governance`);
      assertKnownIntegerKeys(governance, [0, 1, 2], `${name2}.governance`);
      op = {
        op: kind,
        governance: {
          insert: roleFromCode(required(governance, 0, "governance.insert"), "governance.insert"),
          update: roleFromCode(required(governance, 1, "governance.update"), "governance.update"),
          delete: roleFromCode(required(governance, 2, "governance.delete"), "governance.delete")
        },
        invitees: expectArray(required(map, 2, `${name2}.invitees`), `${name2}.invitees`).map((key) => Uint8Array.from(expectBytes(key, `${name2}.invitees`, PLATFORM_ID_BYTES)))
      };
      break;
    }
    case "accept_membership":
    case "leave":
      op = { op: kind, collectiveId: id2(1, "collective_id") };
      break;
    case "set_members":
      op = {
        op: kind,
        collectiveId: id2(1, "collective_id"),
        changes: expectArray(required(map, 2, `${name2}.changes`), `${name2}.changes`).map((entry) => {
          const tuple = expectArray(entry, `${name2}.change`);
          protocolInvariant(tuple.length === 2, "SCHEMA_INVALID", `${name2}.change has invalid arity`);
          const role = expectUint64(tuple[1] ?? null, `${name2}.change.role`);
          protocolInvariant(role <= 2n, "SCHEMA_INVALID", `${name2}.change.role is unknown`);
          return {
            member: Uint8Array.from(expectBytes(tuple[0] ?? null, `${name2}.change.member`, PLATFORM_ID_BYTES)),
            role: role === 0n ? "member" : role === 1n ? "admin" : "remove"
          };
        })
      };
      break;
    case "transfer_offer": {
      const scope2 = expectArray(required(map, 1, `${name2}.scope`), `${name2}.scope`);
      const scopeKind = expectUint64(scope2[0] ?? null, `${name2}.scope.kind`);
      let decodedScope;
      if (scopeKind === 1n) {
        protocolInvariant(scope2.length === 1, "SCHEMA_INVALID", `${name2}.scope has invalid arity`);
        decodedScope = { kind: "all" };
      } else {
        protocolInvariant(scopeKind === 0n && scope2.length === 3, "SCHEMA_INVALID", `${name2}.scope is invalid`);
        decodedScope = {
          kind: "row",
          table: expectString(scope2[1] ?? null, `${name2}.scope.table`),
          rowKey: values(scope2[2] ?? null, `${name2}.scope.row_key`)
        };
      }
      const carry = expectUint64(required(map, 4, `${name2}.carry`), `${name2}.carry`);
      protocolInvariant(carry <= 1n, "SCHEMA_INVALID", `${name2}.carry must be 0 or 1`);
      const fromOwner = optionalId(2, "from_owner");
      op = {
        op: kind,
        scope: decodedScope,
        ...fromOwner === void 0 ? {} : { fromOwner },
        toOwner: id2(3, "to_owner"),
        carry: carry === 1n
      };
      break;
    }
    case "transfer_accept":
    case "transfer_cancel":
      op = { op: kind, offerId: id2(1, "offer_id") };
      break;
    case "seed_rows":
      op = {
        op: kind,
        table: text(1, "table"),
        columns: expectArray(required(map, 2, `${name2}.columns`), `${name2}.columns`).map((column) => expectString(column, `${name2}.columns`)),
        rows: expectArray(required(map, 3, `${name2}.rows`), `${name2}.rows`).map((row, index) => values(row, `${name2}.rows[${index}]`))
      };
      break;
    case "end_seeding":
      op = { op: kind };
      break;
  }
  platformOpToCanonicalCbor(op);
  return op;
}

// packages/protocol/src/program.ts
var MAX_PROGRAM_STEPS = 256;
var MAX_PROGRAM_BYTES = 262144;
var MAX_PROGRAM_EVENTS = 64;
var MAX_EVENT_BYTES = 16384;
var MAX_TOPIC_BYTES = 128;
function assertEventTopic(topic) {
  protocolInvariant(
    typeof topic === "string" && /^[A-Za-z0-9][A-Za-z0-9._/-]*$/u.test(topic) && utf82(topic).length <= MAX_TOPIC_BYTES,
    "SCHEMA_INVALID",
    "Event topic must be a bounded application label"
  );
}
function canonicalJson(payload, limits) {
  for (const bound of [limits.maxBytes, limits.maxNodes, limits.maxDepth]) protocolInvariant(Number.isSafeInteger(bound) && bound > 0, "SCHEMA_INVALID", "Invalid JSON limits");
  let nodes = 0;
  const visit = (value, depth) => {
    protocolInvariant(depth <= limits.maxDepth && ++nodes <= limits.maxNodes, "SCHEMA_INVALID", "JSON payload is too complex");
    if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      protocolInvariant(Number.isFinite(value), "SCHEMA_INVALID", "Event numbers must be finite");
      return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
      protocolInvariant(Reflect.ownKeys(value).length === value.length + 1, "SCHEMA_INVALID", "Event arrays cannot carry extra properties");
      const entries = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, i);
        protocolInvariant(
          descriptor !== void 0 && "value" in descriptor && descriptor.enumerable === true,
          "SCHEMA_INVALID",
          "Event arrays require dense data elements"
        );
        entries.push(visit(descriptor.value, depth + 1));
      }
      return `[${entries.join(",")}]`;
    }
    protocolInvariant(
      typeof value === "object" && value !== null && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null),
      "SCHEMA_INVALID",
      "Event payload must contain JSON values"
    );
    protocolInvariant(Reflect.ownKeys(value).length === Object.keys(value).length, "SCHEMA_INVALID", "Event objects require enumerable string keys");
    return `{${Object.keys(value).sort().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      protocolInvariant("value" in descriptor, "SCHEMA_INVALID", "Event payload cannot contain accessors");
      return `${JSON.stringify(key)}:${visit(descriptor.value, depth + 1)}`;
    }).join(",")}}`;
  };
  const encoded = visit(payload, 0);
  protocolInvariant(utf82(encoded).length <= limits.maxBytes, "SCHEMA_INVALID", "JSON payload is too large");
  return encoded;
}
function canonicalEventPayload(payload) {
  return canonicalJson(payload, { maxBytes: MAX_EVENT_BYTES, maxNodes: 4096, maxDepth: 32 });
}
function emit(topic, payload) {
  assertEventTopic(topic);
  return { op: "emit", topic, payload: JSON.parse(canonicalEventPayload(payload)) };
}
function isEmitStep(step) {
  return typeof step === "object" && step !== null && "op" in step && step.op === "emit";
}
function stepToCbor(step) {
  if (isEmitStep(step)) {
    protocolInvariant(Object.keys(step).every((key) => ["op", "topic", "payload"].includes(key)), "SCHEMA_INVALID", "Unknown emit field");
    assertEventTopic(step.topic);
    return [2n, step.topic, canonicalEventPayload(step.payload)];
  }
  return isPlatformOp(step) ? [1n, platformOpToCanonicalCbor(step)] : [0n, sqlStatementToCanonicalCbor(step)];
}
function stepFromCbor(value, name2) {
  const tuple = expectArray(value, name2);
  const kind = expectUint64(tuple[0] ?? null, `${name2}.kind`);
  if (kind === 2n) {
    protocolInvariant(tuple.length === 3, "SCHEMA_INVALID", `${name2} has invalid arity`);
    const encoded = expectString(tuple[2] ?? null, `${name2}.payload`);
    protocolInvariant(utf82(encoded).length <= MAX_EVENT_BYTES, "SCHEMA_INVALID", "Event payload is too large");
    let payload;
    try {
      payload = JSON.parse(encoded);
    } catch {
      throw new Error("EVENT_PAYLOAD_INVALID");
    }
    protocolInvariant(canonicalEventPayload(payload) === encoded, "SCHEMA_INVALID", "Event payload must be canonical");
    return emit(expectString(tuple[1] ?? null, `${name2}.topic`), payload);
  }
  protocolInvariant(tuple.length === 2, "SCHEMA_INVALID", `${name2} has invalid arity`);
  if (kind === 0n) return sqlStatementFromCanonicalCbor(tuple[1] ?? null, `${name2}.statement`);
  protocolInvariant(kind === 1n, "SCHEMA_INVALID", `${name2} has an unknown kind`);
  return platformOpFromCanonicalCbor(tuple[1] ?? null, `${name2}.platform_op`);
}
function assertValidChangeProgram(value) {
  protocolInvariant(value.version === 3, "UNSUPPORTED_VERSION", "Unsupported change program version");
  protocolInvariant(
    Array.isArray(value.steps) && value.steps.length > 0 && value.steps.length <= MAX_PROGRAM_STEPS,
    "SCHEMA_INVALID",
    "Change program requires a bounded nonempty step list"
  );
  protocolInvariant(value.steps.filter(isEmitStep).length <= MAX_PROGRAM_EVENTS, "SCHEMA_INVALID", "Too many emitted events");
  protocolInvariant(
    encodeCanonicalCbor(value.steps.map(stepToCbor)).length <= MAX_PROGRAM_BYTES,
    "SCHEMA_INVALID",
    "Change program is too large"
  );
}
function changeProgramFromCanonicalCbor(value) {
  const map = expectMap(value, "change_program");
  assertKnownIntegerKeys(map, [0, 1], "change_program");
  expectVersion(map, 3n, "change_program");
  const result = { version: 3, steps: expectArray(required(map, 1, "change_program.steps"), "change_program.steps").map((step, index) => stepFromCbor(step, `change_program.steps[${index}]`)) };
  assertValidChangeProgram(result);
  return result;
}
function decodeChangeProgram(bytes2) {
  return changeProgramFromCanonicalCbor(assertCanonicalCbor2(bytes2));
}

// packages/protocol/src/primitives.ts
var DOMAINS = {
  transaction: "chronolog/transaction-core/v1",
  materializedLog: "chronolog/materialized-log/v1",
  peerDescriptor: "chronolog/peer-generation/descriptor/v1",
  celldApplicationInvitation: "chronolog/celld/application-invitation/v1",
  celldWorkspacePublication: "chronolog/celld/workspace-publication/v1",
  peerSchema: "chronolog/peer-generation/schema/v1",
  peerPublication: "chronolog/publication/v1",
  peerControl: "chronolog/peer-generation/control/v1",
  peerGeneration: "chronolog/peer-generation/generation/v1",
  peerTransition: "chronolog/peer-generation/transition/v1",
  peerAttempt: "chronolog/peer-generation/attempt/v1",
  peerOrder: "chronolog/peer-generation/order/v1",
  peerCoverage: "chronolog/peer-generation/coverage/v1",
  peerConnection: "chronolog/peer-generation/connection/v1"
};
function domainSeparatedBytes2(domain, payload) {
  return concatBytes(utf82(domain), Uint8Array.of(0), payload);
}
var ED25519 = { name: "Ed25519" };
function bufferSource2(value) {
  return Uint8Array.from(value).buffer;
}
async function generateEd25519KeyPair(extractable = true) {
  const pair = await globalThis.crypto.subtle.generateKey(ED25519, extractable, ["sign", "verify"]);
  const publicKeyBytes = new Uint8Array(await globalThis.crypto.subtle.exportKey("raw", pair.publicKey));
  return { publicKey: pair.publicKey, privateKey: pair.privateKey, publicKeyBytes };
}
async function importEd25519PublicKey(raw) {
  protocolInvariant(raw.length === 32, "INVALID_KEY", "Ed25519 public key must contain 32 bytes");
  try {
    return await globalThis.crypto.subtle.importKey("raw", bufferSource2(raw), ED25519, true, ["verify"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 public key");
  }
}
async function importEd25519PrivateKey(pkcs8, extractable = true) {
  try {
    return await globalThis.crypto.subtle.importKey("pkcs8", bufferSource2(pkcs8), ED25519, extractable, ["sign"]);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to import Ed25519 private key");
  }
}
async function exportEd25519PrivateKey(privateKey) {
  try {
    return new Uint8Array(await globalThis.crypto.subtle.exportKey("pkcs8", privateKey));
  } catch {
    throw new ProtocolError("INVALID_KEY", "Ed25519 private key is not extractable");
  }
}
async function signDomain(domain, payload, privateKey) {
  try {
    const signature = await globalThis.crypto.subtle.sign(ED25519, privateKey, bufferSource2(domainSeparatedBytes2(domain, payload)));
    return new Uint8Array(signature);
  } catch {
    throw new ProtocolError("INVALID_KEY", "Unable to sign with Ed25519 key");
  }
}
async function verifyDomain(domain, payload, signature, publicKey) {
  if (signature.length !== 64) return false;
  try {
    const key = publicKey instanceof Uint8Array ? await importEd25519PublicKey(publicKey) : publicKey;
    return await globalThis.crypto.subtle.verify(
      ED25519,
      key,
      bufferSource2(signature),
      bufferSource2(domainSeparatedBytes2(domain, payload))
    );
  } catch {
    return false;
  }
}

// packages/peer-generation/src/codec.ts
var PeerGenerationError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "PeerGenerationError";
  }
  code;
};
function check(condition, code) {
  if (!condition) throw new PeerGenerationError(code);
}
function object(value, keys) {
  check(value !== null && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null), "PEER_RECORD_INVALID");
  const record = value;
  check(Object.keys(record).length === keys.length && keys.every((key) => Object.hasOwn(record, key)), "PEER_RECORD_FIELDS_INVALID");
  return record;
}
function boundedText(value, max = 512) {
  check(typeof value === "string" && value.length > 0 && value.length <= max && [...value].every((character) => character.charCodeAt(0) >= 32 && character.charCodeAt(0) !== 127), "PEER_TEXT_INVALID");
}
function hex2(value, bytes2 = 32) {
  check(typeof value === "string" && value.length === bytes2 * 2 && /^[0-9a-f]+$/u.test(value), "PEER_HEX_INVALID");
}
function uint(value, maximum = Number.MAX_SAFE_INTEGER) {
  check(Number.isSafeInteger(value) && value >= 0 && value <= maximum, "PEER_INTEGER_INVALID");
}
function canonical(value, depth) {
  check(depth <= 24, "PEER_RECORD_TOO_DEEP");
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") {
    check(Number.isSafeInteger(value), "PEER_INTEGER_INVALID");
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map((item) => canonical(item, depth + 1)).join(",")}]`;
  check(typeof value === "object" && value !== null && Object.getPrototypeOf(value) === Object.prototype, "PEER_RECORD_INVALID");
  const record = value;
  return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonical(record[key], depth + 1)}`).join(",")}}`;
}
function encodePeerValue(value) {
  const bytes2 = new TextEncoder().encode(canonical(value, 0));
  check(bytes2.length <= 32 * 1024 * 1024, "PEER_RECORD_TOO_LARGE");
  return bytes2;
}
function decodePeerValue(bytes2) {
  check(bytes2.length <= 32 * 1024 * 1024, "PEER_RECORD_TOO_LARGE");
  const value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes2));
  check(bytesToHex(encodePeerValue(value)) === bytesToHex(bytes2), "PEER_RECORD_NOT_CANONICAL");
  return value;
}
function samePeerValue(left, right) {
  return canonical(left, 0) === canonical(right, 0);
}
async function peerDigest(value) {
  return bytesToHex(await sha256(encodePeerValue(value)));
}
async function bytesDigest(value) {
  return bytesToHex(await sha256(value));
}
async function signPeerValue(domain, payload, identity) {
  const captured = structuredClone(payload);
  return { payload: captured, signature: bytesToHex(await signDomain(domain, encodePeerValue(captured), identity.privateKey)) };
}
async function verifyPeerValue(domain, value, publicKey) {
  object(value, ["payload", "signature"]);
  hex2(value.signature, 64);
  hex2(publicKey);
  check(await verifyDomain(domain, encodePeerValue(value.payload), hexToBytes(value.signature), hexToBytes(publicKey)), "PEER_SIGNATURE_INVALID");
}
async function createPeerIdentity() {
  const pair = await generateEd25519KeyPair();
  return { publicKey: bytesToHex(pair.publicKeyBytes), privateKey: pair.privateKey };
}
async function exportPeerIdentity(identity) {
  return { publicKey: identity.publicKey, privateKey: bytesToHex(await exportEd25519PrivateKey(identity.privateKey)) };
}
async function importPeerIdentity(value) {
  object(value, ["publicKey", "privateKey"]);
  hex2(value.publicKey);
  check(typeof value.privateKey === "string" && /^[0-9a-f]{96,512}$/u.test(value.privateKey), "PEER_PRIVATE_KEY_INVALID");
  const identity = { publicKey: value.publicKey, privateKey: await importEd25519PrivateKey(hexToBytes(value.privateKey)) };
  const test = new TextEncoder().encode("chronolog/peer-identity/check");
  const signature = await signDomain("chronolog/peer-generation/descriptor/v1", test, identity.privateKey);
  check(await verifyDomain("chronolog/peer-generation/descriptor/v1", test, signature, hexToBytes(identity.publicKey)), "PEER_IDENTITY_KEY_MISMATCH");
  return identity;
}
var Serial = class {
  #tail = Promise.resolve();
  async run(task) {
    const prior = this.#tail;
    let release;
    this.#tail = new Promise((resolve) => {
      release = resolve;
    });
    await prior;
    try {
      return await task();
    } finally {
      release();
    }
  }
};
function isArray(value) {
  return Array.isArray(value);
}

// packages/peer-generation/src/control-types.ts
var PEER_GENERATION_PROFILE = "peer-generation-v1";
var PEER_GENERATION_POLICY = "eligible-members-v1";
var PEER_MAX_RECORDS = 16384;
var PEER_MAX_HISTORY_BYTES = 128 * 1024 * 1024;
var PEER_GENERATION_CAPABILITIES = Object.freeze({
  ordering: "generation-sequence",
  applied: true,
  shared: true,
  finality: false,
  automaticExternalEffects: false,
  recovery: "selected-prefix"
});

// packages/peer-generation/src/definition.ts
function parseApplicationInput(schema, value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  const visit = (spec, item, path2) => {
    const invalid = () => {
      throw new Error(`APPLICATION_INPUT_INVALID:${path2}`);
    };
    if ("anyOf" in spec) {
      for (const option of spec.anyOf) {
        try {
          visit(option, item, path2);
          return;
        } catch {
        }
      }
      invalid();
    } else if (spec.type === "null") {
      if (item !== null) invalid();
    } else if (spec.type === "boolean") {
      if (typeof item !== "boolean") invalid();
    } else if (spec.type === "string") {
      if (typeof item !== "string") return invalid();
      const length = [...item].length;
      if (length < (spec.minLength ?? 0) || length > (spec.maxLength ?? 16384) || spec.enum !== void 0 && !spec.enum.includes(item)) invalid();
    } else if (spec.type === "number" || spec.type === "integer") {
      if (typeof item !== "number" || spec.type === "integer" && !Number.isSafeInteger(item) || item < (spec.minimum ?? -Infinity) || item > (spec.maximum ?? Infinity)) invalid();
    } else if (spec.type === "array") {
      if (!Array.isArray(item) || item.length < (spec.minItems ?? 0) || item.length > (spec.maxItems ?? 4096)) return invalid();
      const items = item;
      items.forEach((child, index) => visit(spec.items, child, `${path2}[${index}]`));
    } else if (spec.type === "object") {
      if (item === null || typeof item !== "object" || Array.isArray(item)) return invalid();
      const object2 = item;
      for (const name2 of spec.required ?? []) if (!Object.hasOwn(object2, name2)) invalid();
      for (const [name2, child] of Object.entries(object2)) {
        if (!Object.hasOwn(spec.properties, name2)) invalid();
        visit(spec.properties[name2], child, `${path2}.${name2}`);
      }
    }
  };
  visit(schema, copy, "$");
  return freeze(copy);
}
function checkedApplicationInputSchema(value) {
  const copy = JSON.parse(canonicalEventPayload(value));
  let nodes = 0;
  const visit = (schema, depth) => {
    if (++nodes > 256 || depth > 16 || schema === null || typeof schema !== "object" || Array.isArray(schema)) throw new Error("APPLICATION_SCHEMA_INVALID");
    const keys = /* @__PURE__ */ new Set(["description"]);
    const allow = (...names) => {
      for (const name2 of names) keys.add(name2);
    };
    const bound = (value2, max) => {
      if (value2 !== void 0 && (!Number.isSafeInteger(value2) || value2 < 0 || value2 > max)) throw new Error("APPLICATION_SCHEMA_INVALID");
    };
    if (schema.description !== void 0 && typeof schema.description !== "string") throw new Error("APPLICATION_SCHEMA_INVALID");
    if ("anyOf" in schema) {
      allow("anyOf");
      if (!Array.isArray(schema.anyOf) || schema.anyOf.length < 1 || schema.anyOf.length > 16) throw new Error("APPLICATION_SCHEMA_INVALID");
      const alternatives = schema.anyOf;
      alternatives.forEach((option) => visit(option, depth + 1));
    } else {
      allow("type");
      switch (schema.type) {
        case "string":
          allow("minLength", "maxLength", "enum");
          bound(schema.minLength, 16384);
          bound(schema.maxLength, 16384);
          if ((schema.minLength ?? 0) > (schema.maxLength ?? 16384) || schema.enum !== void 0 && (!Array.isArray(schema.enum) || schema.enum.length === 0 || schema.enum.length > 256 || schema.enum.some((item) => typeof item !== "string"))) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "number":
        case "integer":
          allow("minimum", "maximum");
          if ([schema.minimum, schema.maximum].some((value2) => value2 !== void 0 && !Number.isFinite(value2)) || (schema.minimum ?? -Infinity) > (schema.maximum ?? Infinity)) throw new Error("APPLICATION_SCHEMA_INVALID");
          break;
        case "boolean":
        case "null":
          break;
        case "array":
          allow("items", "minItems", "maxItems");
          bound(schema.minItems, 4096);
          bound(schema.maxItems, 4096);
          if ((schema.minItems ?? 0) > (schema.maxItems ?? 4096)) throw new Error("APPLICATION_SCHEMA_INVALID");
          visit(schema.items, depth + 1);
          break;
        case "object":
          allow("properties", "required", "additionalProperties");
          if (schema.properties === null || typeof schema.properties !== "object" || Array.isArray(schema.properties) || schema.additionalProperties !== void 0 && schema.additionalProperties !== false) throw new Error("APPLICATION_SCHEMA_INVALID");
          for (const child of Object.values(schema.properties)) visit(child, depth + 1);
          if (schema.required !== void 0 && (!Array.isArray(schema.required) || schema.required.some((name2) => typeof name2 !== "string" || !Object.hasOwn(schema.properties, name2)) || new Set(schema.required).size !== schema.required.length)) {
            throw new Error("APPLICATION_SCHEMA_INVALID");
          }
          Object.assign(schema, { additionalProperties: false });
          break;
        default:
          throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
      }
    }
    if (Object.keys(schema).some((key) => !keys.has(key))) throw new Error("APPLICATION_SCHEMA_UNSUPPORTED");
  };
  visit(copy, 0);
  return freeze(copy);
}
function freeze(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
function validateApplicationDescription(value) {
  const bytes2 = descriptionJson(value);
  check(new TextEncoder().encode(bytes2).length <= 262144, "APPLICATION_DESCRIPTION_TOO_LARGE");
  const copy = JSON.parse(bytes2);
  object(copy, ["id", "version", "schema", "commands", "queries"]);
  for (const text of [copy.id, copy.version]) check(typeof text === "string" && /^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(text), "APPLICATION_DEFINITION_ID_INVALID");
  if (copy.schema !== null) {
    check(typeof copy.schema === "string" && /^(?:[0-9a-f]{2})+$/u.test(copy.schema), "APPLICATION_SCHEMA_PROGRAM_INVALID");
    decodeChangeProgram(hexToBytes(copy.schema));
  }
  for (const entries of [copy.commands, copy.queries]) {
    check(isArray(entries) && entries.length <= 128, "APPLICATION_DEFINITION_TOO_LARGE");
    let previous = "";
    for (const entry of entries) {
      object(entry, ["name", "description", "input"]);
      check(typeof entry.name === "string" && /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(entry.name) && !["__proto__", "constructor", "prototype"].includes(entry.name) && entry.name > previous, "APPLICATION_DEFINITION_NAME_INVALID");
      previous = entry.name;
      check(typeof entry.description === "string" && entry.description.length <= 4096, "APPLICATION_DESCRIPTION_INVALID");
      const checked3 = checkedApplicationInputSchema(entry.input);
      check(canonicalEventPayload(entry.input) === canonicalEventPayload(checked3), "APPLICATION_SCHEMA_NOT_CANONICAL");
    }
  }
  return freeze(copy);
}
async function applicationDescriptionDigest(value) {
  const description = validateApplicationDescription(value);
  return bytesDigest(new TextEncoder().encode(descriptionJson(description)));
}
function assertCompatibleDefinitionEvolution(previous, next) {
  const prior = validateApplicationDescription(previous), updated = validateApplicationDescription(next);
  check(prior.id === updated.id, "APPLICATION_DEFINITION_ID_MISMATCH");
  check(prior.schema === null === (updated.schema === null), "APPLICATION_DEFINITION_PROFILE_MISMATCH");
  if (prior.schema !== null) check(prior.schema === updated.schema, "APPLICATION_DEFINITION_SCHEMA_CHANGED");
}
function descriptionJson(value) {
  return canonicalJson(value, { maxBytes: 262144, maxNodes: 65536, maxDepth: 32 });
}

// packages/peer-generation/src/schema.ts
function validateSchema(value) {
  object(value, ["applicationId", "definitionDigest", "executionManifestDigest", "program"]);
  hex2(value.applicationId);
  hex2(value.definitionDigest);
  hex2(value.executionManifestDigest);
  check(typeof value.program === "string" && value.program.length <= 2 * 262144 && /^(?:[0-9a-f]{2})+$/u.test(value.program), "PEER_SCHEMA_PROGRAM_INVALID");
  decodeChangeProgram(hexToBytes(value.program));
}
async function signApplicationSchema(payload, signer) {
  validateSchema(payload);
  return signPeerValue(DOMAINS.peerSchema, payload, signer);
}
async function verifyApplicationSchema(schema, descriptor) {
  validateSchema(schema.payload);
  check(schema.payload.applicationId === descriptor.applicationId && schema.payload.definitionDigest === descriptor.definitionDigest && schema.payload.executionManifestDigest === descriptor.executionManifestDigest && descriptor.schemaDigest === await peerDigest(schema), "PEER_SCHEMA_BINDING_MISMATCH");
  await verifyPeerValue(DOMAINS.peerSchema, schema, descriptor.schemaAdministrator);
  return decodeChangeProgram(hexToBytes(schema.payload.program));
}

// packages/peer-generation/src/participant.ts
var PARTICIPANT_PROTOCOL = "chronolog-participant-v1";
var PARTICIPANT_LIMITS = Object.freeze({
  pending: 4,
  depth: 32,
  bytes: Object.freeze({
    control: 16 * 1024 * 1024,
    publication: 12 * 1024 * 1024,
    discovery: 256 * 1024,
    ephemeral: 64 * 1024,
    database: 32 * 1024 * 1024,
    content: 512 * 1024
  })
});
function policy(role, actions) {
  return Object.freeze({ role, interests: Object.freeze(Object.entries(actions).flatMap(([facet, names]) => names.map((action) => Object.freeze({ facet, action })))) });
}
var CONTROL_PARTICIPANT_POLICY = policy("control", {
  control: ["read", "configure", "select", "administer"],
  publication: ["definition", "read", "publish"],
  discovery: ["read", "advertise", "withdraw"],
  ephemeral: ["invite"]
});
var PEER_PARTICIPANT_POLICY = policy("peer", {
  control: ["state", "keyShare"],
  publication: ["definition", "read"],
  database: ["open", "submit", "range", "coverage"],
  content: ["manifest", "chunk", "retained", "observeRetention"],
  ephemeral: ["signal", "hint"]
});
var ParticipantProtocolError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "ParticipantProtocolError";
  }
  code;
};
function requireParticipant(condition, code) {
  if (!condition) throw new ParticipantProtocolError(code);
}
function applicationId(value) {
  requireParticipant(typeof value === "string" && /^[0-9a-f]{64}$/u.test(value), "PEER_PARTICIPANT_SCOPE_INVALID");
}
function jsonValue(value, depth = 0) {
  requireParticipant(depth <= PARTICIPANT_LIMITS.depth, "PEER_PARTICIPANT_DEPTH_LIMIT");
  if (value === null || typeof value === "string" || typeof value === "boolean") return;
  if (typeof value === "number") {
    requireParticipant(Number.isFinite(value), "PEER_PARTICIPANT_PAYLOAD_INVALID");
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) jsonValue(item, depth + 1);
    return;
  }
  requireParticipant(
    value !== null && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype,
    "PEER_PARTICIPANT_PAYLOAD_INVALID"
  );
  for (const item of Object.values(value)) jsonValue(item, depth + 1);
}
function participantAccepts(policy2, interest) {
  return policy2.interests.some((value) => value.facet === interest.facet && value.action === interest.action);
}
function validateParticipantRequest(value, selected = CONTROL_PARTICIPANT_POLICY) {
  requireParticipant(
    value !== null && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype,
    "PEER_PARTICIPANT_ENVELOPE_INVALID"
  );
  const request = value;
  const fields = ["protocol", "applicationId", "requestId", "facet", "action", "payload"];
  requireParticipant(
    Object.keys(request).length === fields.length && fields.every((key) => Object.hasOwn(request, key)),
    "PEER_PARTICIPANT_ENVELOPE_INVALID"
  );
  requireParticipant(request.protocol === PARTICIPANT_PROTOCOL, "PEER_PARTICIPANT_PROTOCOL_UNSUPPORTED");
  applicationId(request.applicationId);
  requireParticipant(
    typeof request.requestId === "string" && /^[A-Za-z0-9_.:-]{1,128}$/u.test(request.requestId),
    "PEER_PARTICIPANT_REQUEST_INVALID"
  );
  requireParticipant(typeof request.facet === "string" && Object.hasOwn(PARTICIPANT_LIMITS.bytes, request.facet) && typeof request.action === "string" && /^[a-z][A-Za-z-]{0,47}$/u.test(request.action), "PEER_PARTICIPANT_INTEREST_INVALID");
  requireParticipant(participantAccepts(selected, request), "PEER_PARTICIPANT_FACET_FORBIDDEN");
  jsonValue(request.payload);
  requireParticipant(
    new TextEncoder().encode(JSON.stringify(request)).length <= PARTICIPANT_LIMITS.bytes[request.facet],
    "PEER_PARTICIPANT_SIZE_LIMIT"
  );
  return structuredClone(request);
}
function createParticipantRequest(input, selected = CONTROL_PARTICIPANT_POLICY) {
  return validateParticipantRequest({
    protocol: PARTICIPANT_PROTOCOL,
    applicationId: input.applicationId,
    requestId: input.requestId ?? crypto.randomUUID(),
    facet: input.facet,
    action: input.action,
    payload: input.payload
  }, selected);
}
function createParticipantResponse(request, payload, selected = CONTROL_PARTICIPANT_POLICY) {
  return validateParticipantRequest({ ...validateParticipantRequest(request, selected), payload }, selected);
}
function validateParticipantResponse(value, request, selected = CONTROL_PARTICIPANT_POLICY) {
  const response = validateParticipantRequest(value, selected);
  requireParticipant(response.applicationId === request.applicationId && response.requestId === request.requestId && response.facet === request.facet && response.action === request.action, "PEER_PARTICIPANT_RESPONSE_MISMATCH");
  return response;
}
function createParticipantTransport(options) {
  applicationId(options.applicationId);
  const scope2 = options.applicationId, dispatch = options.exchange;
  const selected = structuredClone(options.policy ?? CONTROL_PARTICIPANT_POLICY);
  let pending = 0;
  const exchange = async (input, inputOptions = {}) => {
    const request = validateParticipantRequest(input, selected);
    requireParticipant(request.applicationId === scope2, "PEER_PARTICIPANT_SCOPE_MISMATCH");
    inputOptions.signal?.throwIfAborted();
    requireParticipant(pending < PARTICIPANT_LIMITS.pending, "PEER_PARTICIPANT_BUSY");
    pending++;
    try {
      const response = await dispatch(request, inputOptions);
      inputOptions.signal?.throwIfAborted();
      return validateParticipantResponse(response, request, selected);
    } finally {
      pending--;
    }
  };
  return Object.freeze({
    applicationId: scope2,
    policy: policy(
      selected.role,
      Object.fromEntries([...new Set(selected.interests.map((value) => value.facet))].map((facet) => [facet, selected.interests.filter((value) => value.facet === facet).map((value) => value.action)]))
    ),
    exchange,
    async request(facet, action, payload, inputOptions = {}) {
      return (await exchange(createParticipantRequest({ applicationId: scope2, facet, action, payload }, selected), inputOptions)).payload;
    }
  });
}

// packages/peer-generation/src/publication.ts
var PUBLICATION_LIMITS = Object.freeze({
  files: 128,
  bytes: 8 * 1024 * 1024,
  manifestBytes: 256 * 1024,
  revisions: 256,
  historyBytes: 16 * 1024 * 1024
});
function path(value) {
  boundedText(value, 1024);
  check(
    !/[\\?#%]/u.test(value) && value.split("/").every((part) => part.length > 0 && part !== "." && part !== ".."),
    "PEER_PUBLICATION_PATH_INVALID"
  );
}
function validatePublicationManifest(input) {
  object(input, [
    "applicationId",
    "historyId",
    "profile",
    "controlRevision",
    "author",
    "operationId",
    "revision",
    "previous",
    "definitionDigest",
    "executionManifestDigest",
    "entry",
    "files"
  ]);
  const value = input;
  hex2(value.applicationId);
  boundedText(value.historyId, 128);
  hex2(value.author);
  boundedText(value.operationId, 128);
  check(value.profile === PEER_GENERATION_PROFILE, "PEER_PROFILE_UNSUPPORTED");
  uint(value.controlRevision);
  uint(value.revision, PUBLICATION_LIMITS.revisions - 1);
  if (value.previous !== null) hex2(value.previous);
  check(value.revision === 0 === (value.previous === null), "PEER_PUBLICATION_CHAIN_INVALID");
  hex2(value.definitionDigest);
  hex2(value.executionManifestDigest);
  path(value.entry);
  check(isArray(value.files) && value.files.length > 0 && value.files.length <= PUBLICATION_LIMITS.files, "PEER_PUBLICATION_FILES_LIMIT");
  let previous, total = 0;
  for (const file of value.files) {
    object(file, ["path", "hash", "size", "type"]);
    path(file.path);
    hex2(file.hash);
    uint(file.size, PUBLICATION_LIMITS.bytes);
    boundedText(file.type, 256);
    check(/^[a-z][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*(?:;[ -~]*)?$/iu.test(file.type), "PEER_PUBLICATION_TYPE_INVALID");
    check(previous === void 0 || previous < file.path, "PEER_PUBLICATION_FILES_NOT_ORDERED");
    previous = file.path;
    total += file.size;
  }
  check(total <= PUBLICATION_LIMITS.bytes, "PEER_PUBLICATION_BYTES_LIMIT");
  check(value.files.some((file) => file.path === value.entry), "PEER_PUBLICATION_ENTRY_MISSING");
  check(encodePeerValue(value).length <= PUBLICATION_LIMITS.manifestBytes, "PEER_PUBLICATION_MANIFEST_LIMIT");
  return structuredClone(value);
}
async function signPublicationManifest(input, signer) {
  const payload = validatePublicationManifest(input);
  check(payload.author === signer.publicKey, "PEER_PUBLICATION_AUTHOR_MISMATCH");
  const signed = await signPeerValue(DOMAINS.peerPublication, payload, signer);
  return { ...signed, id: await peerDigest(["chronolog/publication/v1", signed.payload]) };
}
async function verifyPublicationManifest(input, authority) {
  const publication = structuredClone(input);
  object(publication, ["payload", "signature", "id"]);
  hex2(publication.id);
  const value = validatePublicationManifest(publication.payload), descriptor = authority.descriptor;
  check(value.applicationId === descriptor.applicationId && value.historyId === descriptor.historyId && value.profile === descriptor.profile, "PEER_PUBLICATION_SCOPE_MISMATCH");
  check(
    value.definitionDigest === authority.definitionDigestAt(value.controlRevision) && value.executionManifestDigest === descriptor.executionManifestDigest,
    "PEER_PUBLICATION_SEMANTICS_MISMATCH"
  );
  check(authority.grant(value.author, value.controlRevision)?.publisher === true, "PEER_PUBLICATION_FORBIDDEN");
  check(publication.id === await peerDigest(["chronolog/publication/v1", value]), "PEER_PUBLICATION_ID_INVALID");
  await verifyPeerValue(DOMAINS.peerPublication, { payload: value, signature: publication.signature }, value.author);
}
async function authorizePublication(input, authority, previous) {
  const publication = structuredClone(input), head = structuredClone(previous);
  await verifyPublicationManifest(publication, authority);
  check(
    publication.payload.controlRevision === authority.control.payload.revision && authority.grant(publication.payload.author)?.publisher === true,
    "PEER_PUBLICATION_CONTROL_CHANGED"
  );
  if (head !== null) await verifyPublicationManifest(head, authority);
  check(
    publication.payload.previous === (head?.id ?? null) && publication.payload.revision === (head === null ? 0 : head.payload.revision + 1),
    "PEER_PUBLICATION_CONFLICT"
  );
}
async function verifyPublicationAsset(file, input) {
  object(file, ["path", "hash", "size", "type"]);
  path(file.path);
  hex2(file.hash);
  uint(file.size, PUBLICATION_LIMITS.bytes);
  const bytes2 = input.slice();
  check(bytes2.length === file.size && await bytesDigest(bytes2) === file.hash, "PEER_PUBLICATION_ASSET_MISMATCH");
}
var locks = /* @__PURE__ */ new WeakMap();
function publicationLock(store, key) {
  let keys = locks.get(store);
  if (keys === void 0) {
    keys = /* @__PURE__ */ new Map();
    locks.set(store, keys);
  }
  let lock = keys.get(key);
  if (lock === void 0) {
    lock = new Serial();
    keys.set(key, lock);
  }
  return lock;
}
async function createPublicationRegistry(options) {
  const store = options.store, readAuthority = options.authority;
  const initial = await verifyAuthorityBundle(await readAuthority()), descriptor = initial.bundle.descriptor;
  const key = `peer-generation/publications/${descriptor.payload.applicationId}`, lock = publicationLock(store, key);
  const authority = async () => verifyAuthorityBundle(await readAuthority(), descriptor);
  const read = async (verified) => {
    const bytes2 = await store.get(key);
    check(bytes2 !== null, "PEER_PUBLICATION_STATE_MISSING");
    check(bytes2.length <= PUBLICATION_LIMITS.historyBytes, "PEER_PUBLICATION_HISTORY_LIMIT");
    const values = decodePeerValue(bytes2);
    check(isArray(values) && values.length <= PUBLICATION_LIMITS.revisions, "PEER_PUBLICATION_HISTORY_LIMIT");
    const operations = /* @__PURE__ */ new Set();
    for (const [index, publication] of values.entries()) {
      await verifyPublicationManifest(publication, verified);
      check(publication.payload.revision === index && publication.payload.previous === (values[index - 1]?.id ?? null), "PEER_PUBLICATION_CHAIN_INVALID");
      check(!operations.has(publication.payload.operationId), "PEER_PUBLICATION_OPERATION_REUSED");
      operations.add(publication.payload.operationId);
    }
    return values;
  };
  await lock.run(async () => {
    if (await store.get(key) === null) {
      check(options.requireExisting !== true, "PEER_PUBLICATION_STATE_MISSING");
      await store.put(key, encodePeerValue([]));
    }
    await read(await authority());
  });
  return {
    read: () => lock.run(async () => structuredClone(await read(await authority()))),
    async publish(input) {
      const publication = structuredClone(input);
      return lock.run(async () => {
        const verified = await authority(), values = await read(verified);
        await verifyPublicationManifest(publication, verified);
        const retry = values.find((value) => value.payload.operationId === publication.payload.operationId);
        if (retry !== void 0) {
          check(samePeerValue(retry, publication), "PEER_PUBLICATION_OPERATION_REUSED");
          return structuredClone(retry);
        }
        await authorizePublication(publication, verified, values.at(-1) ?? null);
        check(values.length < PUBLICATION_LIMITS.revisions, "PEER_PUBLICATION_HISTORY_LIMIT");
        const bytes2 = encodePeerValue([...values, publication]);
        check(bytes2.length <= PUBLICATION_LIMITS.historyBytes, "PEER_PUBLICATION_HISTORY_LIMIT");
        const latest = await authority();
        assertAuthorityExtension(verified, latest);
        await authorizePublication(publication, latest, values.at(-1) ?? null);
        await store.put(key, bytes2);
        return structuredClone(publication);
      });
    }
  };
}

// packages/peer-generation/src/control.ts
function assertAuthorityExtension(previous, next) {
  const old = previous.bundle, current = next.bundle;
  check(samePeerValue(old.descriptor, current.descriptor), "PEER_DESCRIPTOR_MISMATCH");
  check(current.generations.length >= old.generations.length && current.controls.length >= old.controls.length, "PEER_AUTHORITY_REGRESSION");
  for (let index = 0; index < old.generations.length; index++) check(samePeerValue(old.generations[index], current.generations[index]), "PEER_CONTROL_EQUIVOCATION");
  for (let index = 0; index < old.controls.length; index++) check(samePeerValue(old.controls[index], current.controls[index]), "PEER_CONTROL_EQUIVOCATION");
}
function scope(value, descriptor) {
  check(value.applicationId === descriptor.applicationId && value.profile === PEER_GENERATION_PROFILE && (value.policy === void 0 || value.policy === descriptor.policy), "PEER_SCOPE_MISMATCH");
}
function validateDescriptor(value) {
  object(value, ["applicationId", "historyId", "profile", "policy", "controlPublicKey", "schemaAdministrator", "executionManifestDigest", "definitionDigest", "schemaDigest"]);
  hex2(value.applicationId);
  boundedText(value.historyId, 128);
  hex2(value.controlPublicKey);
  hex2(value.schemaAdministrator);
  hex2(value.executionManifestDigest);
  hex2(value.definitionDigest);
  if (value.schemaDigest !== null) hex2(value.schemaDigest);
  check(value.profile === PEER_GENERATION_PROFILE && value.policy === PEER_GENERATION_POLICY, "PEER_PROFILE_UNSUPPORTED");
}
function validateHistoryPoint(point) {
  object(point, ["generation", "sequence", "root"]);
  hex2(point.generation);
  uint(point.sequence);
  hex2(point.root);
}
function validateControl(value) {
  const controlFields = ["applicationId", "profile", "policy", "revision", "previous", "epoch", "keyDigest", "grants", "recoveryFloor"];
  if (value?.definitionDigest !== void 0) controlFields.push("definitionDigest");
  object(value, controlFields);
  hex2(value.applicationId);
  uint(value.revision);
  uint(value.epoch);
  hex2(value.keyDigest);
  if (value.previous !== null) hex2(value.previous);
  if (value.definitionDigest !== void 0) hex2(value.definitionDigest);
  check(isArray(value.grants) && value.grants.length > 0 && value.grants.length <= 1024, "PEER_GRANTS_INVALID");
  const keys = /* @__PURE__ */ new Set();
  for (const grant of value.grants) {
    const fields = ["publicKey", "reader", "writer", "coordinator", "recovery", "administrator", "publisher", "dataRole"];
    if (grant?.relay !== void 0) {
      fields.push("relay");
      check(grant.relay === true && grant.reader, "PEER_GRANT_INVALID");
    }
    object(grant, fields);
    hex2(grant.publicKey);
    for (const key of ["reader", "writer", "coordinator", "recovery", "administrator", "publisher"]) check(typeof grant[key] === "boolean", "PEER_GRANT_INVALID");
    check(!keys.has(grant.publicKey), "PEER_DUPLICATE_GRANT");
    keys.add(grant.publicKey);
    check(!grant.coordinator || grant.reader, "PEER_COORDINATOR_MUST_READ");
    check(grant.dataRole === null || grant.dataRole === "member" || grant.dataRole === "admin", "PEER_DATA_ROLE_INVALID");
  }
  check(value.grants.some((grant) => grant.administrator), "PEER_ADMINISTRATOR_REQUIRED");
  if (value.recoveryFloor !== null) validateHistoryPoint(value.recoveryFloor);
}
function validateRequest(value) {
  object(value, ["applicationId", "profile", "policy", "transitionId", "expectedGeneration", "coordinator", "requester", "controlRevision", "reason", "base"]);
  hex2(value.applicationId);
  boundedText(value.transitionId, 128);
  hex2(value.coordinator);
  hex2(value.requester);
  uint(value.controlRevision);
  if (value.expectedGeneration !== null) hex2(value.expectedGeneration);
  check(["create", "handover", "takeover", "control-change"].includes(value.reason), "PEER_TRANSITION_REASON_INVALID");
  if (value.base !== null) {
    object(value.base, ["point", "receipt", "bridge"]);
    validateHistoryPoint(value.base.point);
    check(isArray(value.base.bridge) && value.base.bridge.length <= 4096, "PEER_PREFIX_PROOF_TOO_LARGE");
  }
}
function validateGeneration(value) {
  object(value, ["applicationId", "profile", "policy", "number", "previous", "coordinator", "controlRevision", "controlDigest", "adopted", "recoveryFloor", "executionManifestDigest", "transition"]);
  hex2(value.applicationId);
  uint(value.number);
  hex2(value.coordinator);
  uint(value.controlRevision);
  hex2(value.controlDigest);
  hex2(value.executionManifestDigest);
  if (value.previous !== null) hex2(value.previous);
  if (value.adopted !== null) validateHistoryPoint(value.adopted);
  if (value.recoveryFloor !== null) validateHistoryPoint(value.recoveryFloor);
}
async function signApplicationDescriptor(payload, signer) {
  validateDescriptor(payload);
  check(payload.controlPublicKey === signer.publicKey, "PEER_CONTROL_KEY_MISMATCH");
  return signPeerValue(DOMAINS.peerDescriptor, payload, signer);
}
function participantGrant(publicKey, options = {}) {
  hex2(publicKey);
  return {
    publicKey,
    reader: true,
    writer: true,
    coordinator: true,
    recovery: true,
    administrator: options.administrator ?? false,
    publisher: options.publisher ?? false,
    ...options.relay === true ? { relay: true } : {},
    dataRole: options.dataRole === void 0 ? "member" : options.dataRole
  };
}
function controlParticipantGrant(publicKey) {
  hex2(publicKey);
  return { publicKey, reader: false, writer: false, coordinator: false, recovery: true, administrator: true, publisher: false, dataRole: null };
}
async function signControlRevision(payload, signer) {
  validateControl(payload);
  return signPeerValue(DOMAINS.peerControl, payload, signer);
}
async function signTransitionRequest(payload, signer) {
  validateRequest(payload);
  check(payload.requester === signer.publicKey, "PEER_REQUESTER_KEY_MISMATCH");
  return signPeerValue(DOMAINS.peerTransition, payload, signer);
}
async function generationStartRoot(generation) {
  return peerDigest(["chronolog/peer-generation/start/v1", generation.id, generation.payload.adopted]);
}
async function verifyOrderReceipt(receipt, generation, descriptor) {
  object(receipt, ["payload", "signature", "root"]);
  hex2(receipt.root);
  const value = receipt.payload;
  object(value, ["applicationId", "profile", "generation", "sequence", "previousRoot", "attemptId", "author", "operationId", "bodyHash", "bodyBytes"]);
  scope(value, descriptor);
  hex2(value.generation);
  uint(value.sequence);
  check(value.sequence > 0, "PEER_ORDER_POSITION_INVALID");
  hex2(value.previousRoot);
  hex2(value.attemptId);
  hex2(value.author);
  boundedText(value.operationId);
  hex2(value.bodyHash);
  uint(value.bodyBytes, 2 * 1024 * 1024);
  check(value.bodyBytes > 0 && value.generation === generation.id, "PEER_ORDER_GENERATION_MISMATCH");
  check(receipt.root === await peerDigest(["chronolog/peer-generation/order/v1", value]), "PEER_ORDER_ROOT_MISMATCH");
  await verifyPeerValue(DOMAINS.peerOrder, { payload: value, signature: receipt.signature }, generation.payload.coordinator);
}
var PeerAuthority = class _PeerAuthority {
  #bundle;
  #byId = /* @__PURE__ */ new Map();
  #transitions = /* @__PURE__ */ new Map();
  #depth = /* @__PURE__ */ new Map();
  #ancestors = /* @__PURE__ */ new Map();
  // Construction uses cloned wire data or an already verified private prefix.
  constructor(bundle) {
    this.#bundle = { ...bundle, controls: [...bundle.controls], generations: [...bundle.generations] };
  }
  get signedDescriptor() {
    return structuredClone(this.#bundle.descriptor);
  }
  get generationCount() {
    return this.#bundle.generations.length;
  }
  get controlCount() {
    return this.#bundle.controls.length;
  }
  generationAt(index) {
    return structuredClone(this.#bundle.generations[index] ?? null);
  }
  suffix(controls, generations) {
    uint(controls, this.controlCount);
    uint(generations, this.generationCount);
    return { controls: structuredClone(this.#bundle.controls.slice(controls)), generations: structuredClone(this.#bundle.generations.slice(generations)) };
  }
  transition(id2) {
    return structuredClone(this.#transitions.get(id2) ?? null);
  }
  get bundle() {
    return structuredClone(this.#bundle);
  }
  get descriptor() {
    return structuredClone(this.#bundle.descriptor.payload);
  }
  get current() {
    return structuredClone(this.#bundle.generations.at(-1) ?? null);
  }
  get control() {
    return structuredClone(this.#bundle.controls.at(-1));
  }
  generation(id2) {
    const value = this.#byId.get(id2);
    check(value !== void 0, "PEER_GENERATION_UNKNOWN");
    return structuredClone(value);
  }
  controlAt(revision) {
    const value = this.#bundle.controls[revision];
    check(value !== void 0, "PEER_CONTROL_UNKNOWN");
    return structuredClone(value);
  }
  definitionDigestAt(revision = this.control.payload.revision) {
    uint(revision, this.#bundle.controls.length - 1);
    for (let index = revision; index >= 0; index--) {
      const digest = this.#bundle.controls[index].payload.definitionDigest;
      if (digest !== void 0) return digest;
    }
    return this.#bundle.descriptor.payload.definitionDigest;
  }
  get currentDefinitionDigest() {
    return this.definitionDigestAt();
  }
  grant(publicKey, revision = this.control.payload.revision) {
    return structuredClone(this.controlAt(revision).payload.grants.find((grant) => grant.publicKey === publicKey) ?? null);
  }
  #append(generation) {
    const parent = generation.payload.adopted?.generation;
    const ancestors = parent === void 0 ? [] : [parent];
    for (let level = 1; ancestors[level - 1] !== void 0; level++) {
      const ancestor = this.#ancestors.get(ancestors[level - 1])?.[level - 1];
      if (ancestor === void 0) break;
      ancestors.push(ancestor);
    }
    this.#transitions.set(generation.payload.transition.payload.transitionId, generation);
    this.#byId.set(generation.id, generation);
    this.#depth.set(generation.id, parent === void 0 ? 0 : this.#depth.get(parent) + 1);
    this.#ancestors.set(generation.id, ancestors);
    this.#bundle.generations.push(generation);
  }
  #lift(id2, distance) {
    let current = id2;
    for (let level = 0; distance > 0 && current !== void 0; level++, distance = Math.floor(distance / 2)) {
      if (distance % 2 === 1) current = this.#ancestors.get(current)?.[level];
    }
    return current;
  }
  #segment(id2) {
    const current = this.#bundle.generations.at(-1), generation = this.#byId.get(id2);
    if (current === void 0 || generation === void 0) return void 0;
    if (id2 === current.id) return { generation, cutoff: null };
    const distance = this.#depth.get(current.id) - this.#depth.get(id2);
    if (distance < 1) return void 0;
    const child = this.#lift(current.id, distance - 1);
    const cutoff = child === void 0 ? void 0 : this.#byId.get(child).payload.adopted;
    return cutoff?.generation === id2 ? { generation, cutoff } : void 0;
  }
  selectedSegments() {
    const current = this.#bundle.generations.at(-1);
    if (current === void 0) return [];
    const reversed = [{ generation: current, cutoff: null }];
    let adopted = current.payload.adopted;
    while (adopted !== null) {
      const generation = this.#byId.get(adopted.generation);
      reversed.push({ generation, cutoff: adopted });
      adopted = generation.payload.adopted;
    }
    return structuredClone(reversed.reverse());
  }
  /** Structural inclusion; a complete replica additionally checks the local retained root. */
  contains(point) {
    validateHistoryPoint(point);
    const segment = this.#segment(point.generation);
    return segment !== void 0 && (segment.cutoff === null || point.sequence <= segment.cutoff.sequence && (point.sequence !== segment.cutoff.sequence || point.root === segment.cutoff.root));
  }
  async verifyPrefix(proof) {
    object(proof, ["point", "receipt", "bridge"]);
    validateHistoryPoint(proof.point);
    check(isArray(proof.bridge) && proof.bridge.length <= 4096, "PEER_PREFIX_PROOF_TOO_LARGE");
    const segment = this.#segment(proof.point.generation);
    check(segment !== void 0 && this.contains(proof.point), "PEER_PREFIX_EXCLUDED");
    const { point } = proof;
    if (point.sequence === 0) {
      check(proof.receipt === null && point.root === await generationStartRoot(segment.generation), "PEER_PREFIX_ROOT_MISMATCH");
    } else {
      check(proof.receipt !== null, "PEER_PREFIX_RECEIPT_REQUIRED");
      await verifyOrderReceipt(proof.receipt, segment.generation, this.descriptor);
      check(proof.receipt.payload.sequence === point.sequence && proof.receipt.root === point.root, "PEER_PREFIX_ROOT_MISMATCH");
    }
    let position = point.sequence, root = point.root;
    for (const receipt of proof.bridge) {
      await verifyOrderReceipt(receipt, segment.generation, this.descriptor);
      check(receipt.payload.sequence === position + 1 && receipt.payload.previousRoot === root, "PEER_PREFIX_BRIDGE_INVALID");
      position++;
      root = receipt.root;
    }
    if (segment.cutoff === null) check(proof.bridge.length === 0, "PEER_PREFIX_BRIDGE_UNNECESSARY");
    else check(position === segment.cutoff.sequence && root === segment.cutoff.root, "PEER_PREFIX_BRIDGE_INCOMPLETE");
  }
  /** Compare points on the selected history after their roots have been authenticated. */
  atOrAfter(point, floor) {
    const left = this.#segment(point.generation), right = this.#segment(floor.generation);
    return left !== void 0 && right !== void 0 && (left.generation.payload.number > right.generation.payload.number || point.generation === floor.generation && point.sequence >= floor.sequence);
  }
  async authorizeTransition(request, nextControl = this.control) {
    validateRequest(request.payload);
    scope(request.payload, this.descriptor);
    await verifyPeerValue(DOMAINS.peerTransition, request, request.payload.requester);
    const value = request.payload, current = this.current, currentControl = this.control;
    check(value.expectedGeneration === (current?.id ?? null), "PEER_GENERATION_CONFLICT");
    check(value.controlRevision === nextControl.payload.revision, "PEER_CONTROL_REVISION_MISMATCH");
    const requester = this.grant(value.requester, currentControl.payload.revision);
    const candidate = nextControl.payload.grants.find((grant) => grant.publicKey === value.coordinator);
    check(requester?.recovery === true, "PEER_RECOVERY_FORBIDDEN");
    check(candidate?.coordinator === true && candidate.reader, "PEER_COORDINATOR_FORBIDDEN");
    if (current === null) {
      check(value.reason === "create" && value.base === null && nextControl.payload.revision === 0, "PEER_INITIAL_SELECTION_INVALID");
    } else {
      check(value.reason !== "create" && value.base !== null, "PEER_RECOVERY_BASE_REQUIRED");
      await this.verifyPrefix(value.base);
      if (value.reason === "handover") check(value.requester === current.payload.coordinator, "PEER_HANDOVER_FORBIDDEN");
      if (nextControl.payload.revision !== currentControl.payload.revision) {
        check(value.reason === "control-change" && requester.administrator, "PEER_CONTROL_CHANGE_FORBIDDEN");
        await verifyNextControl(this.descriptor, currentControl, nextControl);
      } else check(value.reason !== "control-change", "PEER_CONTROL_CHANGE_REQUIRED");
      const previousFloor = currentControl.payload.recoveryFloor;
      const floor = nextControl.payload.recoveryFloor;
      if (previousFloor !== null) {
        check(floor !== null && this.contains(floor) && this.atOrAfter(floor, previousFloor), "PEER_RECOVERY_FLOOR_REGRESSION");
      }
      if (floor !== null) check(this.contains(floor) && this.atOrAfter(value.base.point, floor), "PEER_RECOVERY_FLOOR_UNAVAILABLE");
      if (floor !== null && !samePeerValue(floor, previousFloor)) check(samePeerValue(floor, value.base.point), "PEER_NEW_FLOOR_MUST_MATCH_BASE");
    }
  }
  /** Verify only new signed suffix records, preserving the verified prefix by reference. */
  async extend(inputControls, inputGenerations) {
    if (inputControls.length === 0 && inputGenerations.length === 0) return this;
    const controls = structuredClone(inputControls), generations = structuredClone(inputGenerations);
    check(this.controlCount + controls.length <= 4096 && this.generationCount + generations.length <= 4096, "PEER_AUTHORITY_LIMIT");
    const next = new _PeerAuthority(this.#bundle);
    for (const [id2, value] of this.#byId) next.#byId.set(id2, value);
    for (const [id2, value] of this.#depth) next.#depth.set(id2, value);
    for (const [id2, value] of this.#ancestors) next.#ancestors.set(id2, value);
    for (const [id2, value] of this.#transitions) next.#transitions.set(id2, value);
    const allControls = [...this.#bundle.controls, ...controls], descriptor = this.descriptor;
    for (let index = this.controlCount; index < allControls.length; index++) await verifyNextControl(descriptor, allControls[index - 1], allControls[index]);
    for (const generation of generations) {
      object(generation, ["payload", "signature", "id"]);
      hex2(generation.id);
      validateGeneration(generation.payload);
      const value = generation.payload;
      scope(value, descriptor);
      await verifyPeerValue(DOMAINS.peerGeneration, { payload: value, signature: generation.signature }, descriptor.controlPublicKey);
      check(generation.id === await peerDigest(["chronolog/peer-generation/generation/v1", value]), "PEER_GENERATION_ID_INVALID");
      check(value.number === next.generationCount && value.previous === (next.current?.id ?? null), "PEER_GENERATION_CHAIN_INVALID");
      const control = allControls[value.controlRevision];
      check(control !== void 0 && value.controlDigest === await peerDigest(control), "PEER_CONTROL_DIGEST_MISMATCH");
      check(value.controlRevision === next.controlCount - 1 || value.controlRevision === next.controlCount, "PEER_CONTROL_CHAIN_INVALID");
      await next.authorizeTransition(value.transition, control);
      check(value.coordinator === value.transition.payload.coordinator && samePeerValue(value.adopted, value.transition.payload.base?.point ?? null) && samePeerValue(value.recoveryFloor, control.payload.recoveryFloor) && value.executionManifestDigest === descriptor.executionManifestDigest, "PEER_DELEGATION_MISMATCH");
      check(!next.#transitions.has(value.transition.payload.transitionId), "PEER_TRANSITION_DUPLICATE");
      if (value.controlRevision === next.controlCount) next.#bundle.controls.push(control);
      next.#append(generation);
    }
    check(next.controlCount === allControls.length, "PEER_CONTROL_NOT_ACTIVATED");
    return next;
  }
  static async verify(input, pinned) {
    const bundle = structuredClone(input);
    object(bundle, ["descriptor", "controls", "generations"]);
    validateDescriptor(bundle.descriptor.payload);
    await verifyPeerValue(DOMAINS.peerDescriptor, bundle.descriptor, bundle.descriptor.payload.controlPublicKey);
    if (pinned !== void 0) check(samePeerValue(bundle.descriptor, pinned), "PEER_DESCRIPTOR_CHANGED");
    check(isArray(bundle.controls) && bundle.controls.length > 0 && bundle.controls.length <= 4096 && isArray(bundle.generations) && bundle.generations.length <= 4096, "PEER_AUTHORITY_LIMIT");
    const descriptor = bundle.descriptor.payload;
    for (const [index, control] of bundle.controls.entries()) {
      validateControl(control.payload);
      scope(control.payload, descriptor);
      await verifyPeerValue(DOMAINS.peerControl, control, descriptor.controlPublicKey);
      check(control.payload.revision === index, "PEER_CONTROL_CHAIN_INVALID");
      if (index === 0) check(control.payload.previous === null && control.payload.recoveryFloor === null, "PEER_INITIAL_CONTROL_INVALID");
      else await verifyNextControl(descriptor, bundle.controls[index - 1], control);
    }
    const verified = new _PeerAuthority({ descriptor: bundle.descriptor, controls: [bundle.controls[0]], generations: [] });
    const transitions = /* @__PURE__ */ new Set();
    for (const [number, generation] of bundle.generations.entries()) {
      object(generation, ["payload", "signature", "id"]);
      hex2(generation.id);
      validateGeneration(generation.payload);
      const value = generation.payload;
      scope(value, descriptor);
      await verifyPeerValue(DOMAINS.peerGeneration, { payload: value, signature: generation.signature }, descriptor.controlPublicKey);
      check(generation.id === await peerDigest(["chronolog/peer-generation/generation/v1", value]), "PEER_GENERATION_ID_INVALID");
      check(value.number === number && value.previous === (verified.current?.id ?? null), "PEER_GENERATION_CHAIN_INVALID");
      const control = bundle.controls[value.controlRevision];
      check(control !== void 0 && value.controlDigest === await peerDigest(control), "PEER_CONTROL_DIGEST_MISMATCH");
      check(value.controlRevision === verified.control.payload.revision || value.controlRevision === verified.control.payload.revision + 1, "PEER_CONTROL_CHAIN_INVALID");
      await verified.authorizeTransition(value.transition, control);
      check(value.coordinator === value.transition.payload.coordinator && samePeerValue(value.adopted, value.transition.payload.base?.point ?? null) && samePeerValue(value.recoveryFloor, control.payload.recoveryFloor) && value.executionManifestDigest === descriptor.executionManifestDigest, "PEER_DELEGATION_MISMATCH");
      check(!transitions.has(value.transition.payload.transitionId), "PEER_TRANSITION_DUPLICATE");
      transitions.add(value.transition.payload.transitionId);
      if (value.controlRevision >= verified.#bundle.controls.length) verified.#bundle.controls.push(control);
      verified.#append(generation);
    }
    check(verified.control.payload.revision === bundle.controls.length - 1, "PEER_CONTROL_NOT_ACTIVATED");
    return verified;
  }
};
async function verifyNextControl(descriptor, previous, next) {
  validateControl(next.payload);
  scope(next.payload, descriptor);
  await verifyPeerValue(DOMAINS.peerControl, next, descriptor.controlPublicKey);
  check(
    next.payload.revision === previous.payload.revision + 1 && next.payload.previous === await peerDigest(previous) && next.payload.epoch >= previous.payload.epoch,
    "PEER_CONTROL_CHAIN_INVALID"
  );
  const revokedReader = previous.payload.grants.some((old) => old.reader && !next.payload.grants.some((grant) => grant.publicKey === old.publicKey && grant.reader));
  if (revokedReader) check(next.payload.epoch > previous.payload.epoch && next.payload.keyDigest !== previous.payload.keyDigest, "PEER_REVOCATION_REQUIRES_KEY_ROTATION");
  if (next.payload.epoch === previous.payload.epoch) check(next.payload.keyDigest === previous.payload.keyDigest, "PEER_EPOCH_KEY_CHANGED");
}
function verifyAuthorityBundle(bundle, pinned) {
  return PeerAuthority.verify(bundle, pinned);
}
var registryLocks = /* @__PURE__ */ new WeakMap();
function registryLock(store, key) {
  let keys = registryLocks.get(store);
  if (keys === void 0) {
    keys = /* @__PURE__ */ new Map();
    registryLocks.set(store, keys);
  }
  let lock = keys.get(key);
  if (lock === void 0) {
    lock = new Serial();
    keys.set(key, lock);
  }
  return lock;
}
var registryCaches = /* @__PURE__ */ new WeakMap();
async function createGenerationRegistry(options) {
  const key = `peer-generation/registry/${options.descriptor.payload.applicationId}`, lock = registryLock(options.store, key);
  let caches = registryCaches.get(options.store);
  if (caches === void 0) {
    caches = /* @__PURE__ */ new Map();
    registryCaches.set(options.store, caches);
  }
  const cache = caches;
  check(options.signer.publicKey === options.descriptor.payload.controlPublicKey, "PEER_CONTROL_KEY_MISMATCH");
  const read = async () => {
    const bytes2 = await options.store.get(key);
    check(bytes2 !== null, "PEER_CONTROL_STATE_MISSING");
    const head = bytesToHex(bytes2), retained = cache.get(key);
    if (retained?.head === head) {
      check(samePeerValue(retained.authority.signedDescriptor, options.descriptor), "PEER_DESCRIPTOR_CHANGED");
      return retained.authority;
    }
    const decoded = decodePeerValue(bytes2);
    let bundle;
    if ("format" in decoded) {
      object(decoded, ["format", "length"]);
      check(decoded.format === "chronolog-authority-log-v1", "PEER_CONTROL_STATE_INVALID");
      uint(decoded.length, 4096);
      const base = await options.store.get(`${key}/base`);
      check(base !== null, "PEER_CONTROL_STATE_MISSING");
      bundle = decodePeerValue(base);
      check(bundle.generations.length <= decoded.length, "PEER_CONTROL_STATE_INVALID");
      const controls = [...bundle.controls], generations = [...bundle.generations];
      for (let index = generations.length; index < decoded.length; index++) {
        const raw = await options.store.get(`${key}/log/${index}`);
        check(raw !== null, "PEER_CONTROL_STATE_MISSING");
        const entry = decodePeerValue(raw);
        object(entry, ["generation", "control"]);
        generations.push(entry.generation);
        if (entry.control !== null) controls.push(entry.control);
      }
      bundle = { descriptor: bundle.descriptor, controls, generations };
    } else bundle = decoded;
    const authority = await verifyAuthorityBundle(bundle, options.descriptor);
    cache.set(key, { head, authority });
    return authority;
  };
  await lock.run(async () => {
    if (await options.store.get(key) === null) {
      check(options.requireExisting !== true, "PEER_CONTROL_STATE_MISSING");
      const initial = { descriptor: options.descriptor, controls: options.controls, generations: [] };
      await verifyAuthorityBundle(initial);
      await options.store.put(`${key}/base`, encodePeerValue(initial));
      await options.store.put(key, encodePeerValue({ format: "chronolog-authority-log-v1", length: 0 }));
    }
    await read();
  });
  return {
    read: () => lock.run(async () => (await read()).bundle),
    async select(input, inputOptions = {}) {
      const request = structuredClone(input), next = structuredClone(inputOptions.control);
      return lock.run(async () => {
        const authority = await read();
        validateRequest(request.payload);
        await verifyPeerValue(DOMAINS.peerTransition, request, request.payload.requester);
        const retry = authority.transition(request.payload.transitionId);
        if (retry !== null) {
          check(samePeerValue(retry.payload.transition, request), "PEER_TRANSITION_ID_REUSED");
          if (next !== void 0) check(samePeerValue(authority.controlAt(retry.payload.controlRevision), next), "PEER_TRANSITION_ID_REUSED");
          return retry;
        }
        const control = next ?? authority.control;
        await authority.authorizeTransition(request, control);
        const payload = {
          applicationId: authority.descriptor.applicationId,
          profile: PEER_GENERATION_PROFILE,
          policy: PEER_GENERATION_POLICY,
          number: authority.generationCount,
          previous: authority.current?.id ?? null,
          coordinator: request.payload.coordinator,
          controlRevision: control.payload.revision,
          controlDigest: await peerDigest(control),
          adopted: request.payload.base?.point ?? null,
          recoveryFloor: control.payload.recoveryFloor,
          executionManifestDigest: authority.descriptor.executionManifestDigest,
          transition: request
        };
        const signed = await signPeerValue(DOMAINS.peerGeneration, payload, options.signer);
        const generation = { ...signed, id: await peerDigest(["chronolog/peer-generation/generation/v1", payload]) };
        const updated = await authority.extend(next === void 0 ? [] : [next], [generation]);
        const currentBytes = await options.store.get(key);
        check(currentBytes !== null, "PEER_CONTROL_STATE_MISSING");
        if (!("format" in decodePeerValue(currentBytes))) {
          await options.store.put(`${key}/base`, encodePeerValue(authority.bundle));
        }
        await options.store.put(`${key}/log/${generation.payload.number}`, encodePeerValue({ generation, control: next ?? null }));
        const head = encodePeerValue({ format: "chronolog-authority-log-v1", length: updated.generationCount });
        await options.store.put(key, head);
        cache.set(key, { head: bytesToHex(head), authority: updated });
        return structuredClone(generation);
      });
    }
  };
}
export {
  CONTROL_PARTICIPANT_POLICY,
  PARTICIPANT_LIMITS,
  PARTICIPANT_PROTOCOL,
  PEER_GENERATION_CAPABILITIES,
  PEER_GENERATION_POLICY,
  PEER_GENERATION_PROFILE,
  PEER_MAX_HISTORY_BYTES,
  PEER_MAX_RECORDS,
  PEER_PARTICIPANT_POLICY,
  PUBLICATION_LIMITS,
  ParticipantProtocolError,
  PeerAuthority,
  PeerGenerationError,
  applicationDescriptionDigest,
  assertAuthorityExtension,
  assertCompatibleDefinitionEvolution,
  authorizePublication,
  bytesDigest,
  checkedApplicationInputSchema,
  controlParticipantGrant,
  createGenerationRegistry,
  createParticipantRequest,
  createParticipantResponse,
  createParticipantTransport,
  createPeerIdentity,
  createPublicationRegistry,
  decodePeerValue,
  encodePeerValue,
  exportPeerIdentity,
  generationStartRoot,
  importPeerIdentity,
  parseApplicationInput,
  participantAccepts,
  participantGrant,
  peerDigest,
  signApplicationDescriptor,
  signApplicationSchema,
  signControlRevision,
  signPublicationManifest,
  signTransitionRequest,
  validateApplicationDescription,
  validateHistoryPoint,
  validateParticipantRequest,
  validateParticipantResponse,
  validatePublicationManifest,
  verifyApplicationSchema,
  verifyAuthorityBundle,
  verifyOrderReceipt,
  verifyPublicationAsset,
  verifyPublicationManifest
};
