import type { EphemeralSignal, SignalSubscribeOptions, SignalSendOptions, SignalPayload } from '../../signals/src/index.js';
import type { JsonValue } from '../../protocol/src/index.js';
import type { ApplicationEndpointBinding as InlineApplicationEndpointBinding, ApplicationEndpointContext as InlineApplicationEndpointContext } from './owner-types.js';
import type { ApplicationDescription as InlineApplicationDescription, FinalityCheckpoint as InlineFinalityCheckpoint, ScheduledFinalityEntry, VerifiedFinalityV2 } from '../../authority/src/index.js';
import type { ApplicationPeerDiagnostics as InlineApplicationPeerDiagnostics } from './network.js';
import type { ApplicationWorkerEndpoint } from './worker-transport.js';
import type { CheckpointBootstrapSnapshot, SessionFacts as InlineSessionFacts } from './session.js';
import type { ApplicationChange, ApplicationEventOptions, ApplicationReadView, CommandOptions, MaterializedRevision, SessionStatus, WaitOptions } from './session-types.js';
import type { ApplicationSubmission, MaterializedOperation, OperationInspection, RetentionEvidence } from './operation.js';
import type { ContentReference, ContentUpload, ContentRetention } from './content.js';
import { type ContentPutBytesOptions, type ContentReadBytesOptions } from './content-bytes.js';
export interface WorkerApplicationReadView {
    readonly applicationId: string;
    readonly revision: MaterializedRevision;
    topic(name: string): Promise<JsonValue | null>;
    query(topic: string, input?: JsonValue): Promise<JsonValue>;
    readEvents(options?: ApplicationEventOptions): Promise<ReturnType<ApplicationReadView['readEvents']>>;
    release(): Promise<void>;
}
export declare class WorkerApplicationOperation {
    readonly id: string;
    readonly operationId: string;
    private readonly session;
    readonly stored = true;
    constructor(id: string, operationId: string, session: WorkerApplicationSession);
    inspect(): Promise<OperationInspection>;
    materialized(options?: WaitOptions): Promise<MaterializedOperation>;
    retained(options?: WaitOptions): Promise<readonly RetentionEvidence[]>;
    finalized(options?: WaitOptions): Promise<MaterializedOperation>;
}
/** Page facade owns bounded RPC and local UI state, never keys, SQL or ordering. */
export declare class WorkerApplicationSession {
    #private;
    applicationId: string;
    identity: {
        readonly publicKey: string;
    };
    constructor(endpoint: ApplicationWorkerEndpoint);
    get signal(): AbortSignal;
    get status(): SessionStatus;
    get endpoint(): InlineApplicationEndpointBinding | undefined;
    get attachmentState(): 'active' | 'suspended' | 'detached';
    describe(): InlineApplicationDescription;
    get boundedRequest(): {
        readonly startedAt: number;
        readonly deadline: number;
    } | null;
    request<T>(method: string, args: readonly unknown[], options?: WaitOptions): Promise<T>;
    initialize(options: {
        readonly applicationId: string;
        readonly context?: InlineApplicationEndpointContext;
    }): Promise<void>;
    suspendAttachment(): Promise<void>;
    suspend(): Promise<void>;
    resumeAttachment(): Promise<InlineApplicationEndpointBinding | null>;
    detach(): Promise<void>;
    submit(input: ApplicationSubmission): Promise<WorkerApplicationOperation>;
    command(name: string, input: unknown, options?: CommandOptions): Promise<WorkerApplicationOperation>;
    query(name: string, input?: unknown): Promise<{
        readonly applicationId: string;
        readonly revision: MaterializedRevision;
        readonly value: unknown;
    }>;
    topic(name: string): Promise<JsonValue | null>;
    readEvents(options?: ApplicationEventOptions & {
        readonly view?: 'local' | 'final';
    }): Promise<ReturnType<ApplicationReadView['readEvents']>>;
    wait<T>(id: string, fact: string, options?: WaitOptions): Promise<T>;
    readView(options?: {
        readonly view?: 'local' | 'final';
    }): Promise<WorkerApplicationReadView>;
    get operations(): {
        retry(id: string): Promise<WorkerApplicationOperation>;
        get(id: string): Promise<WorkerApplicationOperation | null>;
        subscribe(options: {
            readonly operationId: string;
            readonly signal?: AbortSignal;
        }): AsyncIterable<OperationInspection>;
    };
    onStatus(listener: (status: SessionStatus) => void): () => void;
    onChange(listener: (change: ApplicationChange) => void): () => void;
    changes(options?: {
        readonly signal?: AbortSignal;
    }): AsyncIterable<ApplicationChange>;
    diagnostics(): Promise<readonly InlineApplicationPeerDiagnostics[]>;
    endpoints(): Promise<readonly (InlineApplicationEndpointBinding & {
        readonly state: 'active' | 'suspended';
    })[]>;
    exportFacts(options?: {
        readonly includePrivateCas?: boolean;
        readonly includeGenesis?: boolean;
    }): Promise<InlineSessionFacts>;
    mergeFacts(facts: InlineSessionFacts): Promise<void>;
    readonly finality: {
        status: () => Promise<VerifiedFinalityV2 & {
            readonly schedule: readonly ScheduledFinalityEntry[];
        }>;
        createCheckpoint: (options: {
            readonly throughMs: bigint;
        }) => Promise<{
            readonly checkpoint: InlineFinalityCheckpoint;
            readonly snapshot: CheckpointBootstrapSnapshot;
        }>;
        submitCheckpoints: (checkpoints: readonly InlineFinalityCheckpoint[]) => Promise<void>;
    };
    readonly extensions: {
        call: <T = unknown>(name: string, args?: readonly unknown[], options?: WaitOptions) => Promise<T>;
        subscribe: (listener: (value: unknown) => void) => (() => void);
    };
    readonly signals: {
        delivery: "application";
        send: (topic: string, payload: SignalPayload, options?: SignalSendOptions) => Promise<EphemeralSignal>;
        subscribe: (options?: SignalSubscribeOptions) => AsyncIterable<EphemeralSignal>;
    };
    readonly content: {
        stage: (options: {
            readonly bytes: number;
            readonly mediaType?: string;
        }) => Promise<ContentUpload>;
        read: (reference: ContentReference, options?: {
            readonly signal?: AbortSignal;
        }) => AsyncIterable<Uint8Array>;
        putBytes: (bytes: Uint8Array, options?: ContentPutBytesOptions) => Promise<ContentReference>;
        readBytes: (reference: ContentReference, options: ContentReadBytesOptions) => Promise<Uint8Array>;
        retain: (reference: ContentReference, options?: {
            readonly signal?: AbortSignal;
        }) => Promise<ContentRetention>;
        retention: (reference: ContentReference, options?: {
            readonly signal?: AbortSignal;
        }) => Promise<readonly ContentRetention[]>;
        retained: (reference: ContentReference) => Promise<readonly ContentRetention[]>;
        discard: (reference: ContentReference) => Promise<void>;
    };
    close(): Promise<void>;
}
export declare function connectApplicationOwner(endpoint: ApplicationWorkerEndpoint & {
    start?(): void;
}, options: {
    readonly applicationId: string;
    readonly context?: InlineApplicationEndpointContext;
}): Promise<WorkerApplicationSession>;
