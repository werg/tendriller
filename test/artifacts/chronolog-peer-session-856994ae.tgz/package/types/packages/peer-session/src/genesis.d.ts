import { type GenesisBlock, type GenesisLimits, type JsonValue, type RuntimeManifest } from '../../protocol/src/index.js';
import type { ScheduledFinalityEntry } from '../../authority/src/index.js';
export interface EpochKeyBox {
    readonly encapsulatedKey: string;
    readonly ciphertext: string;
}
export declare function epochKeyCommitmentV2(epochKey: Uint8Array): string;
export declare function hpkeSealEpochKey(recipientWrapPublicKeyHex: string, epochKey: Uint8Array, chainIdHex: string, epoch: number): Promise<EpochKeyBox>;
export declare function hpkeOpenEpochKey(recipientWrapPrivateKey: CryptoKey, recipientWrapPublicKeyHex: string, box: EpochKeyBox, chainIdHex: string, epoch: number): Promise<Uint8Array>;
export interface ChainMemberSeed {
    readonly publicKey: string;
    readonly wrapKey?: string;
    readonly reader?: boolean;
    readonly writer?: boolean;
    readonly administrator?: boolean;
    readonly publisher?: boolean;
    readonly finalizer?: boolean;
}
export interface ChainTopicSeed {
    readonly module: string;
    readonly export?: string;
    readonly config?: JsonValue;
    readonly initialState?: JsonValue;
}
export interface CreateChainGenesisOptions {
    readonly creator: ChainMemberSeed;
    readonly members?: readonly ChainMemberSeed[];
    readonly privateChain?: boolean;
    /** When true, omits the `$reducers` reducer so topic bindings and import maps are permanently frozen. */
    readonly frozenReducers?: boolean;
    /** ES Module sources (specifier -> UTF-8 JS source) pinned into CAS and registered in `$reducers.imports`. */
    readonly imports?: Readonly<Record<string, string>>;
    /** Application topics to register in `$reducers.topics` alongside standard `$*` control topics. */
    readonly topics?: Readonly<Record<string, ChainTopicSeed>>;
    /** Optional host public key for `chronolog/permissions` Ed25519 admission attestations. */
    readonly hostPublicKey?: string;
    /** Initial `$finality` schedule (defaults to `finality: none`). */
    readonly finalitySchedule?: readonly ScheduledFinalityEntry[];
    readonly signalPolicy?: JsonValue;
    readonly runtime?: RuntimeManifest;
    readonly limits?: GenesisLimits;
    readonly salt?: Uint8Array;
    readonly epoch0Key?: Uint8Array;
}
export interface CreatedChainGenesis {
    readonly chainId: string;
    readonly genesis: GenesisBlock;
    readonly genesisBytes: Uint8Array;
    /** Public CAS nodes (standard + app ES module sources) that must accompany this genesis. */
    readonly casNodes: readonly {
        readonly hash: string;
        readonly bytes: Uint8Array;
        readonly partition: 'public';
    }[];
    /** Epoch 0 key if `privateChain` is true (undefined for public chains). */
    readonly epoch0Key?: Uint8Array;
}
/**
 * Create a Chronolog v2 genesis block with hash-pinned standard and application ES Modules.
 * When `privateChain` is true (the default), generates epoch 0 and seals HPKE lockboxes for
 * all initial readers that provide a `wrapKey` after deriving the deterministic `chainId`.
 */
export declare function createChainGenesis(options: CreateChainGenesisOptions): Promise<CreatedChainGenesis>;
