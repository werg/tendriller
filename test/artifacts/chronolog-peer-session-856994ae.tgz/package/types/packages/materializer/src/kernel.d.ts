import { type GenesisBlock, type JsonValue, type OperationCore, type OperationVisibility } from '../../protocol/src/index.js';
import type { ContentAddressedStore } from '../../records/src/index.js';
import { QuickJsSandbox, type QuickJsSandboxOptions } from './quickjs-sandbox.js';
export interface KernelOperationInput {
    readonly opId: Uint8Array;
    readonly core: OperationCore;
}
export interface EmittedKernelEvent {
    readonly opId: string;
    readonly eventOrdinal: number;
    readonly topic: string;
    readonly payload: JsonValue;
    readonly author: string;
    readonly operationId: string;
    readonly authorTimestampMs: bigint;
}
export interface KernelOperationOutcome {
    readonly opId: string;
    readonly author: string;
    readonly operationId: string;
    readonly authorTimestampMs: bigint;
    readonly visibility: OperationVisibility;
    readonly outcome: 'accepted' | 'rejected';
    readonly rejectionCode: string | null;
    readonly rejectionDetail?: string;
    readonly events: readonly EmittedKernelEvent[];
}
export interface KernelRevision {
    readonly stateRoot: string;
    readonly historyDigest: string;
    readonly digest: string;
    readonly view: 'local' | 'final';
    readonly orderLength: number;
}
export interface KernelSnapshot {
    readonly topics: Readonly<Record<string, JsonValue>>;
    readonly seenOps: ReadonlySet<string>;
    readonly seenOpsRoot: string;
    readonly historyDigest: string;
    readonly stateRoot: string;
    readonly orderLength: number;
}
export interface KernelMaterializeResult {
    readonly revision: KernelRevision;
    readonly outcomes: readonly KernelOperationOutcome[];
    readonly pendingDependencies: readonly string[];
    readonly skippedOpIds: readonly string[];
}
export interface TopicKernelOptions extends QuickJsSandboxOptions {
    readonly genesis: GenesisBlock | Uint8Array;
    readonly cas: ContentAddressedStore;
    /** When true (e.g. blind Cloudflare Worker), only public-control operations are replayed. */
    readonly blindHostMode?: boolean;
    readonly snapshotInterval?: number;
    readonly policyContextDigest?: string;
}
/**
 * Chronolog v2 Topic Kernel & Suffix-Replay Engine.
 * - Flat timestamp-ordered operation set: (authorTimestampMs, author, opId)
 * - Strict two-way public/encrypted control partition (blind-host equivalent)
 * - Scoped idempotency (visibility, author, operationId) in authenticated seenOpsRoot
 * - Rolling historyDigest + stateRoot + revision.digest
 * - Fresh QuickJSContext per call + uncatchable MissingDependency suspension
 */
export declare class TopicKernel {
    #private;
    readonly genesis: GenesisBlock;
    readonly genesisBytes: Uint8Array;
    readonly chainId: Uint8Array;
    readonly chainIdHex: string;
    readonly cas: ContentAddressedStore;
    readonly sandbox: QuickJsSandbox;
    readonly blindHostMode: boolean;
    constructor(options: TopicKernelOptions);
    get topics(): Readonly<Record<string, JsonValue>>;
    get seenOpsRoot(): string;
    snapshot(): {
        readonly topics: Readonly<Record<string, JsonValue>>;
        readonly seenOpsRoot: string;
        readonly historyDigest: string;
        readonly stateRoot: string;
    };
    topic(name: string): JsonValue | null;
    get outcomes(): readonly KernelOperationOutcome[];
    get pendingDependencies(): readonly string[];
    revision(view?: 'local' | 'final', policyContextDigest?: string): KernelRevision;
    /** Collect all CAS root hashes reachable from current state + retained suffix snapshots (for local GC). */
    gcRoots(): Set<string>;
    /**
     * Bootstrap kernel state directly from a verified FinalityCheckpoint snapshot.
     * Restores both topicsMap, seenOpsRoot (consumed handles), and rolling historyDigest
     * so subsequent suffix replay produces identical stateRoot AND revision.digest.
     */
    bootstrapFromCheckpoint(checkpoint: {
        readonly topics: Readonly<Record<string, JsonValue>>;
        readonly seenOpsRoot: string;
        readonly historyDigest: string;
        readonly stateRoot: string;
    }): Promise<void>;
    /**
     * Deterministically materialize an eligible operation set (arbitrary input order; sorted internally).
     * Rewinds only to the earliest snapshot before the first changed position (suffix replay).
     */
    materialize(inputs: readonly KernelOperationInput[]): Promise<KernelMaterializeResult>;
    /** Execute a pure read-only query against a topic's query() export (or return raw topic state if no query export). */
    query(topic: string, input?: JsonValue, topicsOverride?: Readonly<Record<string, JsonValue>>): Promise<JsonValue>;
    /** Collect exported command/query descriptions across all bound topics (for MCP & scoped tools). */
    describe(): Promise<Readonly<Record<string, JsonValue>>>;
    /** Evaluate signal authorization policy for the current stateRoot (cached by caller per stateRoot). */
    signalPolicy(): Promise<{
        readonly rules: readonly {
            readonly topicPattern: string;
            readonly allowedAuthors: readonly string[];
            readonly maxTtlMs: number;
            readonly allowRelay: boolean;
        }[];
    }>;
}
