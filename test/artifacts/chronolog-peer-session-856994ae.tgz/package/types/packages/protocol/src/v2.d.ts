import { type CborValue } from '../../canonical/src/index.js';
import { type ProtocolDomain } from './primitives.js';
export declare const V2_OP_DOMAIN: ProtocolDomain;
export declare const CONTROL_TOPICS: readonly ["$reducers", "$permissions", "$keys", "$finality", "$publications", "$signal_policy"];
export type OperationVisibility = 'public' | 'encrypted';
export type JsonValue = null | boolean | number | string | readonly JsonValue[] | {
    readonly [key: string]: JsonValue;
};
export type EventPayload = JsonValue;
export declare const MAX_EVENT_BYTES = 16384;
/** Bounded canonical JSON, shared by event bodies, attestations, and public application metadata. */
export declare function canonicalJson(payload: JsonValue, limits?: {
    readonly maxBytes: number;
    readonly maxNodes: number;
    readonly maxDepth: number;
}): string;
export declare function canonicalEventPayload(payload: EventPayload): string;
export interface RuntimeManifest {
    readonly js: string;
    readonly builtins: Readonly<Record<string, string>>;
}
export interface TopicBinding {
    readonly module: string;
    readonly export?: string;
    readonly config?: JsonValue;
}
export interface ReducersConfig {
    readonly runtime: RuntimeManifest;
    readonly imports: Readonly<Record<string, string>>;
    readonly topics: Readonly<Record<string, TopicBinding>>;
}
export interface GenesisLimits {
    readonly maxMemoryBytes: number;
    readonly maxTopicStateBytes: number;
    readonly maxUpdatesPerOp: number;
}
export interface GenesisBlock {
    readonly version: 1;
    readonly privateChain: boolean;
    readonly initialTopics: Readonly<Record<string, JsonValue>>;
    readonly limits: GenesisLimits;
    readonly salt: Uint8Array;
}
export interface TopicUpdate {
    readonly topic: string;
    readonly input: JsonValue;
}
export interface OperationCore {
    readonly version: 1;
    readonly chainId: Uint8Array;
    readonly author: Uint8Array;
    readonly operationId: string;
    readonly authorTimestampMs: bigint;
    readonly nonce: Uint8Array;
    readonly visibility: OperationVisibility;
    readonly updates: readonly TopicUpdate[];
}
export interface SignedOperation {
    readonly coreBytes: Uint8Array;
    readonly signature: Uint8Array;
}
export interface EncryptedOperationEnvelope {
    readonly version: 1;
    readonly chainId: Uint8Array;
    readonly opId: Uint8Array;
    readonly author: Uint8Array;
    readonly epoch: number;
    readonly nonce: Uint8Array;
    readonly ciphertext: Uint8Array;
}
export interface OperationOrderKey {
    readonly authorTimestampMs: bigint;
    readonly author: Uint8Array;
    readonly opId: Uint8Array;
}
export declare function isControlTopic(topic: string): boolean;
export declare function assertValidTopicName(topic: string): void;
/**
 * Strictly normalize any JS value into canonical JSON-compatible data (no undefined, NaN, Infinity, -0,
 * accessors, prototypes, or cycles) and convert cleanly to canonical CBOR for hashing & storage.
 */
export declare function normalizeJsonValue(value: unknown, limits?: {
    readonly maxDepth?: number;
    readonly maxNodes?: number;
}): JsonValue;
/** Encode a normalized JsonValue into deterministic CBOR (integers as bigint; non-integer floats as tagged canonical string map). */
export declare function jsonToCbor(value: JsonValue): CborValue;
export declare function cborToJson(value: CborValue): JsonValue;
export declare function encodeCanonicalJsonCbor(value: JsonValue): Uint8Array;
export declare function decodeCanonicalJsonCbor(bytes: Uint8Array): JsonValue;
export declare function assertValidReducersConfig(value: unknown): ReducersConfig;
export declare function encodeGenesisBlock(genesis: GenesisBlock): Uint8Array;
export declare function decodeGenesisBlock(bytes: Uint8Array): GenesisBlock;
export declare function genesisChainId(genesis: GenesisBlock | Uint8Array): Uint8Array;
export declare function encodeOperationCore(core: OperationCore): Uint8Array;
export declare function decodeOperationCore(bytes: Uint8Array): OperationCore;
export declare function operationIdDigest(coreOrBytes: OperationCore | Uint8Array): Uint8Array;
export declare function signOperationCore(core: OperationCore, privateKey: CryptoKey): Promise<SignedOperation>;
export declare function verifySignedOperation(op: SignedOperation): Promise<{
    readonly core: OperationCore;
    readonly opId: Uint8Array;
}>;
export declare function encodeSignedOperation(op: SignedOperation): Uint8Array;
export declare function decodeSignedOperation(bytes: Uint8Array): SignedOperation;
export declare function encodeEncryptedEnvelope(env: EncryptedOperationEnvelope): Uint8Array;
export declare function decodeEncryptedEnvelope(bytes: Uint8Array): EncryptedOperationEnvelope;
/** Envelope digest used for set reconciliation so decryptable rewraps sync past undecryptable old-epoch envelopes. */
export declare function encryptedEnvelopeDigest(env: EncryptedOperationEnvelope | Uint8Array): Uint8Array;
export declare function envelopeAad(chainId: Uint8Array, opId: Uint8Array, author: Uint8Array): Uint8Array;
export declare function compareOperationOrder(left: OperationOrderKey, right: OperationOrderKey): number;
export declare function assertHex32(value: string, label?: string): string;
export declare const DEFAULT_RUNTIME_MANIFEST: RuntimeManifest;
export declare const DEFAULT_GENESIS_LIMITS: GenesisLimits;
