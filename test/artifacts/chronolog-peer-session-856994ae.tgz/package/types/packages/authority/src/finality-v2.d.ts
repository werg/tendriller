import { type EventPayload } from '../../protocol/src/index.js';
import { type Signed, type SigningIdentity } from './codec.js';
export type FinalityPolicyV2 = {
    readonly kind: 'none';
} | {
    readonly kind: 'signed-frontier';
    readonly signer: string;
} | {
    readonly kind: 'fixed-validator';
    readonly validators: readonly string[];
    readonly threshold: number;
} | {
    readonly kind: 'blockchain-anchor';
    readonly chain: string;
    readonly anchorId: string;
};
export interface ScheduledFinalityEntry {
    readonly effectiveAfterMs: bigint;
    readonly policy: FinalityPolicyV2;
}
export interface FinalityInclusionV2 {
    readonly opId: string;
    readonly authorTimestampMs: bigint;
    readonly author: string;
}
export interface FinalityCheckpointPayload {
    readonly chainId: string;
    readonly policyScopeId: string;
    readonly closedThroughMs: bigint;
    readonly includedSetDigest: string;
    readonly historyDigest: string;
    readonly stateRoot: string;
    readonly inclusions: readonly FinalityInclusionV2[];
}
export type FinalityAttestation = {
    readonly kind: 'signatures';
    readonly signatures: readonly Signed<FinalityCheckpointPayload>[];
} | {
    readonly kind: 'blockchain';
    readonly blockHeight: number;
    readonly blockTimestampMs: bigint;
    readonly proofBytes: string;
};
export interface FinalityCheckpoint {
    readonly payload: FinalityCheckpointPayload;
    readonly attestation: FinalityAttestation;
}
export type BlockchainAnchorVerifier = (policy: Extract<FinalityPolicyV2, {
    readonly kind: 'blockchain-anchor';
}>, checkpoint: FinalityCheckpoint) => boolean | Promise<boolean>;
export interface VerifiedFinalityV2 {
    readonly closedThroughMs: bigint | null;
    readonly includedOpIds: ReadonlySet<string>;
    readonly excludedOpIds: ReadonlySet<string>;
    readonly latestCheckpoint: FinalityCheckpoint | null;
    readonly verifiedCheckpoints: readonly FinalityCheckpoint[];
}
export declare function policyScopeId(chainId: string, entry: ScheduledFinalityEntry): Promise<string>;
export declare function computeIncludedSetDigest(opIds: readonly string[]): string;
export declare function signFinalityCheckpoint(payload: FinalityCheckpointPayload, signer: SigningIdentity): Promise<Signed<FinalityCheckpointPayload>>;
export declare function parseFinalitySchedule(raw: unknown): readonly ScheduledFinalityEntry[];
/**
 * Verify finality checkpoints against the chain-governed $finality schedule.
 * - Enforces P0 -> P1 handoff at effectiveAfterMs = T1:
 *   * If P0 is a finalizing policy, P0 must have closed through >= T1 before P1 checkpoints are accepted.
 *   * If P0 is 'none', P1 itself attests its bootstrap closure at >= T1 as its first sealed frontier.
 * - Computes admitted/excluded opIds (proposals with authorTimestampMs <= closedThroughMs not in includedOpIds are excluded).
 */
export declare function verifyFinalityV2(options: {
    readonly chainId: string;
    readonly schedule: readonly ScheduledFinalityEntry[];
    readonly checkpoints: readonly FinalityCheckpoint[];
    readonly knownOps?: readonly {
        readonly opId: string;
        readonly authorTimestampMs: bigint;
    }[];
    readonly blockchainVerifier?: BlockchainAnchorVerifier;
}): Promise<VerifiedFinalityV2>;
/** Pure host-attestation helper matching chronolog/permissions's Ed25519 verification format. */
export declare function signHostAttestationV2<T extends EventPayload>(payload: T, hostIdentity: SigningIdentity): Promise<{
    readonly payload: T;
    readonly signature: string;
}>;
export declare function verifyHostAttestationV2<T extends EventPayload>(attestation: {
    readonly payload: T;
    readonly signature: string;
}, hostPublicKeyHex: string): Promise<boolean>;
