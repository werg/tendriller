import {
  createApplicationBackend
} from "./chunks/chunk-EVWM53NA.mjs";
import "./chunks/chunk-27JHKBJG.mjs";
import "./chunks/chunk-ICYUPG2X.mjs";
export {
  createApplicationBackend
};
