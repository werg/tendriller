import {
  connectApplicationWebRtc
} from "./chunks/chunk-KCZGOFMG.mjs";
import {
  WEBRTC_LIMITS,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
} from "./chunks/chunk-RHS64MZG.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-MCU2YKH4.mjs";
export {
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
