import type { ApplicationSession } from './session.js';
import type { FramedPeerConnection } from '../../records/src/index.js';
import type { SignalReceiveDiagnostics } from '../../signals/src/index.js';
export interface ApplicationPeerConnectOptions {
    readonly connection: FramedPeerConnection;
    readonly peerIdentity?: string;
    readonly signal?: AbortSignal;
    readonly handshakeTimeoutMs?: number;
}
export interface ApplicationPeerLiveDiagnostics {
    /** Signed live protocol-frame bytes; excludes channel encryption and transport overhead. */
    readonly sentLiveBytes: number;
    readonly receivedLiveBytes: number;
    readonly signalRejections: SignalReceiveDiagnostics;
}
export interface ApplicationPeerLinkStats extends Partial<ApplicationPeerLiveDiagnostics> {
    readonly sentBytes: number;
    readonly receivedBytes: number;
}
export interface ApplicationPeerLink {
    readonly peerIdentity: string;
    readonly signal: AbortSignal;
    readonly completion: Promise<void>;
    readonly stats: ApplicationPeerLinkStats;
    synchronize(): Promise<void>;
    close(): Promise<void>;
}
export interface ApplicationPeerDiagnostics extends Partial<ApplicationPeerLiveDiagnostics> {
    readonly connectionId: string;
    readonly peerId: string;
    readonly kind: 'unknown';
    readonly sentReliableBytes: number;
    readonly receivedReliableBytes: number;
}
export declare function applicationPeerDiagnostics(session: ApplicationSession): readonly ApplicationPeerDiagnostics[];
/** Physical feed counters only protect framing. Every proposal authenticates its own immutable authored order. */
export declare function connectApplicationPeer(session: ApplicationSession, options: ApplicationPeerConnectOptions): Promise<ApplicationPeerLink>;
