import type { BytesStore } from '../../records/src/index.js';
import { type HpkeCiphertext } from '../../crypto/src/index.js';
import { type SigningIdentity, type Signed, type AuthorityProvider, type AuthorityBundle } from '../../authority/src/index.js';
export interface ProvisioningRequest {
    readonly applicationId: string;
    readonly descriptorId: string;
    readonly requestId: string;
    readonly recipient: string;
    readonly agreementPublicKey: string;
}
export type SignedProvisioningRequest = Signed<ProvisioningRequest>;
export interface ProvisioningPackage {
    readonly request: SignedProvisioningRequest;
    readonly authority: AuthorityBundle;
    readonly encrypted: HpkeCiphertext;
}
export type SignedProvisioningPackage = Signed<ProvisioningPackage>;
export interface ApplicationProvisioning {
    createProvisioningRequest(): Promise<SignedProvisioningRequest>;
    exportProvisioning(request: SignedProvisioningRequest): Promise<SignedProvisioningPackage>;
    importProvisioning(value: SignedProvisioningPackage): Promise<void>;
}
/** Recipient agreement secrets stay in this owned private store, including across uncertain replies/restarts. */
export declare function createApplicationProvisioning(options: {
    readonly store: BytesStore;
    readonly authority: AuthorityProvider;
    readonly identity: SigningIdentity;
}): ApplicationProvisioning;
