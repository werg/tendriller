export { parseApplicationInput, checkedApplicationInputSchema, validateApplicationDescription, applicationDescriptionDigest, type ApplicationInputSchema, type ApplicationInput, type ApplicationDescription } from './definition.js';
import type { BytesStore } from '../../records/src/index.js';
import { type Signed, type SigningIdentity } from './codec.js';
export interface AdmissionScope {
    readonly id: string;
    readonly authorTimeAfterMs: bigint;
}
export type FinalityPolicy = {
    readonly kind: 'none';
} | {
    readonly kind: 'fixed-validator';
    readonly validators: readonly string[];
    readonly threshold: number;
    readonly scopes: readonly AdmissionScope[];
} | {
    readonly kind: 'signed-frontier';
    readonly signer: string;
    readonly scopes: readonly AdmissionScope[];
};
export interface AppDescriptor {
    readonly applicationId: string;
    readonly rootPrincipal: string;
    readonly authorityPublicKey: string;
    readonly executionManifestDigest: string;
    readonly finalityPolicy: FinalityPolicy;
}
export interface MemberGrant {
    readonly publicKey: string;
    readonly reader: boolean;
    readonly writer: boolean;
    readonly administrator: boolean;
    readonly publisher: boolean;
    readonly finalizer: boolean;
}
export interface Membership {
    readonly applicationId: string;
    readonly revision: number;
    /** Exclusive signed author-time activation floor; first revision starts at -1. */
    readonly authorTimeAfterMs: bigint;
    readonly previous: string | null;
    readonly members: readonly MemberGrant[];
    readonly epoch: number;
    readonly epochKeyDigest: string;
}
export type SignedAppDescriptor = Signed<AppDescriptor>;
export type SignedMembership = Signed<Membership>;
export interface AuthorityBundle {
    readonly descriptor: SignedAppDescriptor;
    readonly memberships: readonly SignedMembership[];
}
export interface AuthorityProvider {
    readonly descriptor: AppDescriptor;
    readonly descriptorId: string;
    readonly currentMembershipId: string;
    readonly currentMembership: Membership;
    bundle(): AuthorityBundle;
    grant(publicKey: string, membershipId?: string): MemberGrant | null;
    hasMembership(id: string): boolean;
    membership(id: string): Membership | null;
    epochKey(epoch: number): Uint8Array | null;
    installEpochKey(epoch: number, key: Uint8Array): Promise<void>;
    merge(bundle: AuthorityBundle): Promise<void>;
    subscribe(listener: () => void): () => void;
}
/** Portable pre-owner validation; no fabricated data-root descriptor or key is needed. */
export declare function validateFinalityPolicy(input: unknown): FinalityPolicy;
export declare function validateDescriptor(value: AppDescriptor): void;
export declare function signAppDescriptor(descriptor: AppDescriptor, signer: SigningIdentity): Promise<SignedAppDescriptor>;
export declare function signMembership(membership: Membership, signer: SigningIdentity): Promise<SignedMembership>;
export declare function verifyAuthorityBundle(input: AuthorityBundle, pinned?: SignedAppDescriptor): Promise<void>;
export declare function writerAuthorizedAt(authority: Pick<AuthorityProvider, 'membership' | 'bundle'>, publicKey: string, membershipId: string, authorTimestampMs: bigint, throughRevision?: number): boolean | null;
export declare function finalizerAuthorizedAt(authority: Pick<AuthorityProvider, 'membership' | 'bundle'>, publicKey: string, authorityHead: string, throughMs: bigint): boolean | null;
export declare function epochKeyCommitment(applicationId: string, epoch: number, key: Uint8Array): Promise<string>;
/** Local authority and keys reopen before any optional remote refresh; no remote fetch belongs to this port. */
export declare function createAuthorityProvider(options: {
    readonly store: BytesStore;
    readonly bundle?: AuthorityBundle;
    readonly applicationId?: string;
    readonly epochKeys?: ReadonlyMap<number, Uint8Array>;
}): Promise<AuthorityProvider>;
export interface EnrollmentRequest {
    readonly applicationId: string;
    readonly publicKey: string;
    readonly challenge: string;
    readonly epoch: number;
    readonly epochKeyDigest: string;
}
export type SignedEnrollmentRequest = Signed<EnrollmentRequest>;
export declare function signEnrollmentRequest(request: EnrollmentRequest, identity: SigningIdentity): Promise<SignedEnrollmentRequest>;
export declare function verifyEnrollmentRequest(request: SignedEnrollmentRequest): Promise<void>;
