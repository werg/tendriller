import {
  openWebRtcConnection
} from "./chunk-RHS64MZG.mjs";

// packages/peer-session/src/webrtc.ts
async function connectApplicationWebRtc(session, options) {
  const connection = await openWebRtcConnection({ ...options, signal: options.signal === void 0 ? session.signal : AbortSignal.any([session.signal, options.signal]) });
  try {
    const link = await session.connectPeer({
      connection,
      ...options.peerIdentity === void 0 ? {} : { peerIdentity: options.peerIdentity },
      ...options.signal === void 0 ? {} : { signal: options.signal },
      ...options.timeoutMs === void 0 ? {} : { handshakeTimeoutMs: options.timeoutMs }
    });
    await link.synchronize();
    return Object.assign(link, { rtc: connection.session });
  } catch (error) {
    await connection.close();
    throw error;
  }
}

export {
  connectApplicationWebRtc
};
