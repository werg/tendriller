import {
  connectApplicationWebRtc
} from "./chunks/chunk-YK4ZXGNV.mjs";
import {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
} from "./chunks/chunk-FJYIP47L.mjs";
import "./chunks/chunk-KSC4KBWO.mjs";
import "./chunks/chunk-OQYLKC3T.mjs";
import "./chunks/chunk-VRR2HFJY.mjs";
export {
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  WEBRTC_LIMITS,
  connectApplicationWebRtc,
  openWebRtcConnection,
  openWorkerWebRtcConnection,
  serveWorkerWebRtcConnections
};
