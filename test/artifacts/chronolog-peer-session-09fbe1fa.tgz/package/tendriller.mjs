import {
  createApplicationBackend
} from "./chunks/chunk-RP7LTXNV.mjs";
import "./chunks/chunk-3ELOKYCD.mjs";
import "./chunks/chunk-VRR2HFJY.mjs";
export {
  createApplicationBackend
};
