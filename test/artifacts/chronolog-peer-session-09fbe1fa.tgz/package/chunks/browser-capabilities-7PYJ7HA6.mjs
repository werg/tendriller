import {
  probeIndexedDbBytesStore
} from "./chunk-4QNBRVH7.mjs";
import "./chunk-VRR2HFJY.mjs";

// packages/peer-session/src/browser-capabilities.ts
async function ed25519() {
  try {
    const generated = await crypto.subtle.generateKey("Ed25519", true, ["sign", "verify"]);
    const exported = await crypto.subtle.exportKey("pkcs8", generated.privateKey);
    const signer = await crypto.subtle.importKey("pkcs8", exported, "Ed25519", false, ["sign"]);
    const bytes = Uint8Array.of(1, 2, 3);
    return crypto.subtle.verify("Ed25519", generated.publicKey, await crypto.subtle.sign("Ed25519", signer, bytes), bytes);
  } catch {
    return false;
  }
}
async function x25519() {
  try {
    const first = await crypto.subtle.generateKey("X25519", true, ["deriveBits"]);
    const second = await crypto.subtle.generateKey("X25519", true, ["deriveBits"]);
    const publicRaw = await crypto.subtle.exportKey("raw", second.publicKey);
    const publicKey = await crypto.subtle.importKey("raw", publicRaw, "X25519", false, []);
    const bits = await crypto.subtle.deriveBits({ name: "X25519", public: publicKey }, first.privateKey, 256);
    return bits.byteLength === 32;
  } catch {
    return false;
  }
}
async function probeBrowserCapabilities() {
  const secureContext = globalThis.isSecureContext === true;
  const dedicatedWorker = typeof document === "undefined" && typeof self !== "undefined" && typeof self.postMessage === "function";
  const sharedWorker = typeof document === "undefined" && typeof self !== "undefined" && "onconnect" in self;
  const ownerWorker = dedicatedWorker || sharedWorker;
  const webLocks = typeof navigator !== "undefined" && typeof navigator.locks?.request === "function";
  const indexedSupported = typeof indexedDB !== "undefined";
  const wasm = typeof WebAssembly !== "undefined";
  const [ed, x] = await Promise.all([ed25519(), x25519()]);
  let idbWritable = false, reason;
  try {
    if (indexedSupported) idbWritable = await probeIndexedDbBytesStore();
  } catch (error) {
    reason = error instanceof Error ? error.name + ": " + error.message : String(error);
  }
  const backend = reason === void 0 && idbWritable ? "indexeddb" : null;
  const supported = secureContext && ownerWorker && ed && x && backend !== null;
  const unavailable = reason ?? (!secureContext ? "Secure context required" : !ownerWorker ? "Dedicated owner Worker required" : !ed || !x ? "Required native WebCrypto algorithms unavailable" : !idbWritable ? "Writable IndexedDB is required for device and application storage" : void 0);
  const eligible = ownerWorker && wasm && idbWritable;
  return {
    secureContext,
    dedicatedWorker,
    sharedWorker,
    indexedDb: { supported: indexedSupported, writable: idbWritable },
    webLocks,
    crypto: { ed25519: ed, x25519: x },
    wasm,
    events: { supported, backend: supported ? backend : null, ...supported ? {} : { reason: unavailable ?? "Event prerequisites unavailable" } },
    sql: {
      apiEligible: eligible,
      qualified: eligible,
      reason: eligible ? "SQLite-CAS WASM over multi-tab IndexedDB is supported" : "SQLite-CAS requires a Worker, WebAssembly, and writable IndexedDB"
    }
  };
}
export {
  probeBrowserCapabilities
};
