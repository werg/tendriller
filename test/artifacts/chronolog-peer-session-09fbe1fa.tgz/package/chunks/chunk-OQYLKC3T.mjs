import {
  DEFAULT_DECODE_LIMITS,
  assertCanonicalCbor,
  bytesToHex,
  encodeCanonicalCbor,
  equalBytes,
  hashDomainSync,
  hexToBytes
} from "./chunk-VRR2HFJY.mjs";

// packages/records/src/bytes-store.ts
var MemoryBytesStore = class {
  #values = /* @__PURE__ */ new Map();
  #changelog = [];
  #seq = 0;
  #quotaBytes;
  #maxValueBytes;
  #usedBytes = 0;
  constructor(options = {}) {
    for (const limit of [options.quotaBytes, options.maxValueBytes]) {
      if (limit !== void 0 && (!Number.isSafeInteger(limit) || limit < 1)) throw new Error("BYTES_STORE_QUOTA_INVALID");
    }
    this.#quotaBytes = options.quotaBytes ?? Infinity;
    this.#maxValueBytes = options.maxValueBytes ?? Infinity;
  }
  #recordChange(key, deleted) {
    this.#changelog.push({ seq: ++this.#seq, key, deleted });
    if (this.#changelog.length > 16384) this.#changelog.splice(0, this.#changelog.length - 8192);
  }
  async get(key) {
    return this.#values.get(key)?.slice() ?? null;
  }
  async put(key, bytes) {
    if (!(bytes instanceof Uint8Array) || bytes.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    const used = this.#usedBytes - (this.#values.get(key)?.byteLength ?? 0) + bytes.byteLength;
    if (used > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    this.#values.set(key, Uint8Array.from(bytes));
    this.#usedBytes = used;
    this.#recordChange(key, false);
  }
  async putMany(entries) {
    if (entries.length === 0) return;
    const staged = /* @__PURE__ */ new Map();
    for (const entry of entries) {
      if (!(entry.value instanceof Uint8Array) || entry.value.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
      staged.set(entry.key, Uint8Array.from(entry.value));
    }
    let used = this.#usedBytes;
    for (const [key, value] of staged) used = used - (this.#values.get(key)?.byteLength ?? 0) + value.byteLength;
    if (used > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    for (const [key, value] of staged) {
      this.#values.set(key, value);
      this.#recordChange(key, false);
    }
    this.#usedBytes = used;
  }
  async delete(key) {
    if (this.#values.has(key)) {
      this.#usedBytes -= this.#values.get(key)?.byteLength ?? 0;
      this.#values.delete(key);
      this.#recordChange(key, true);
    }
  }
  async deleteMany(keys) {
    for (const key of keys) {
      if (this.#values.has(key)) {
        this.#usedBytes -= this.#values.get(key)?.byteLength ?? 0;
        this.#values.delete(key);
        this.#recordChange(key, true);
      }
    }
  }
  async putAllIfEmpty(entries) {
    const captured = entries.map((entry) => ({ key: entry.key, value: Uint8Array.from(entry.value) }));
    if (new Set(captured.map((entry) => entry.key)).size !== captured.length) throw new Error("BYTES_STORE_DUPLICATE_KEY");
    if (captured.some((entry) => entry.value.byteLength > this.#maxValueBytes)) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
    const bytes = captured.reduce((sum, entry) => sum + entry.value.byteLength, 0);
    if (bytes > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
    if (this.#values.size !== 0) return false;
    for (const entry of captured) {
      this.#values.set(entry.key, entry.value);
      this.#recordChange(entry.key, false);
    }
    this.#usedBytes = bytes;
    return true;
  }
  async *iterateEntries() {
    const snapshot = [...this.#values].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    for (const [key, value] of snapshot) yield { key, value: value.slice() };
  }
  async *iteratePrefix(prefix) {
    const snapshot = [...this.#values].filter(([k]) => k.startsWith(prefix)).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    for (const [key, value] of snapshot) yield { key, value: value.slice() };
  }
  async latestChangeSeq() {
    return this.#seq;
  }
  async readChangesSince(afterSeq) {
    return {
      latestSeq: this.#seq,
      changes: this.#changelog.filter((c) => c.seq > afterSeq)
    };
  }
  async putStreamIfEmpty(entries) {
    if (this.#values.size !== 0) return false;
    const staged = /* @__PURE__ */ new Map();
    let bytes = 0;
    for await (const entry of entries) {
      if (staged.has(entry.key)) throw new Error("BYTES_STORE_DUPLICATE_KEY");
      if (!(entry.value instanceof Uint8Array) || entry.value.byteLength > this.#maxValueBytes) throw new Error("BYTES_STORE_VALUE_TOO_LARGE");
      bytes += entry.value.length;
      if (bytes > this.#quotaBytes) throw new Error("BYTES_STORE_QUOTA_EXCEEDED");
      staged.set(entry.key, Uint8Array.from(entry.value));
    }
    if (this.#values.size !== 0) return false;
    for (const [key, value] of staged) {
      this.#values.set(key, value);
      this.#recordChange(key, false);
    }
    this.#usedBytes = bytes;
    return true;
  }
  async entries() {
    return [...this.#values.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, value]) => ({ key, value: value.slice() }));
  }
};
async function writeBytesMany(store, entries, options) {
  if (entries.length === 0) return;
  if (entries.length === 1) {
    await store.put(entries[0].key, entries[0].value, options);
    return;
  }
  if (store.putMany !== void 0) {
    await store.putMany(entries, options);
    return;
  }
  for (const entry of entries) await store.put(entry.key, entry.value, options);
}
async function deleteBytesMany(store, keys, options) {
  if (keys.length === 0) return;
  if (store.deleteMany !== void 0) {
    await store.deleteMany(keys, options);
    return;
  }
  if (store.delete === void 0) return;
  for (const key of keys) await store.delete(key, options);
}

// packages/records/src/cas.ts
var HEX32 = /^[0-9a-f]{64}$/u;
function assertHashHex(hash) {
  if (!HEX32.test(hash)) throw new Error(`CAS_HASH_INVALID: ${hash}`);
}
function encodeCasNode(bytes, links = []) {
  const unique = [...new Set(links)].sort();
  for (const hash of unique) assertHashHex(hash);
  const linkBytes = unique.map((h) => hexToBytes(h));
  return encodeCanonicalCbor([bytes, linkBytes]);
}
function decodeCasNode(encoded) {
  const decoded = assertCanonicalCbor(encoded, DEFAULT_DECODE_LIMITS);
  if (!Array.isArray(decoded) || decoded.length !== 2) throw new Error("CAS_NODE_INVALID");
  const [bytes, rawLinks] = decoded;
  if (!(bytes instanceof Uint8Array) || !Array.isArray(rawLinks)) throw new Error("CAS_NODE_INVALID");
  const links = [];
  for (const item of rawLinks) {
    if (!(item instanceof Uint8Array) || item.length !== 32) throw new Error("CAS_NODE_LINK_INVALID");
    links.push(bytesToHex(item));
  }
  return { bytes: bytes.slice(), links };
}
function hashCasNode(encoded) {
  return bytesToHex(hashDomainSync("cas", encoded));
}
function computeCasHash(bytes, links = []) {
  return hashCasNode(encodeCasNode(bytes, links));
}
var ContentAddressedStore = class {
  #store;
  #prefix;
  #maxCacheEntries;
  #maxChunkBytes;
  #cache = /* @__PURE__ */ new Map();
  #staged = /* @__PURE__ */ new Map();
  #known = /* @__PURE__ */ new Map();
  #pinned = /* @__PURE__ */ new Set();
  #inBatch = false;
  constructor(options) {
    this.#store = options.store;
    this.#prefix = options.prefix ?? "cas/";
    this.#maxCacheEntries = options.maxCacheEntries ?? 4096;
    this.#maxChunkBytes = options.maxChunkBytes ?? 4 * 1024 * 1024;
  }
  #key(partition, hash) {
    return `${this.#prefix}${partition === "public" ? "pub" : "priv"}/${hash}`;
  }
  #touchCache(hash, encoded, node, partition) {
    const existing = this.#cache.get(hash);
    if (existing !== void 0) {
      existing.partitions.add(partition);
      this.#cache.delete(hash);
      this.#cache.set(hash, existing);
      return;
    }
    this.#cache.set(hash, { encoded, node, partitions: /* @__PURE__ */ new Set([partition]) });
    while (this.#cache.size > this.#maxCacheEntries) {
      const oldest = this.#cache.keys().next().value;
      if (oldest === void 0) break;
      this.#cache.delete(oldest);
    }
  }
  /** Preload persisted CAS entries from BytesStore into the in-memory index/cache. */
  async preload() {
    if (this.#store.iteratePrefix !== void 0) {
      for await (const entry of this.#store.iteratePrefix(this.#prefix)) this.indexPersistedEntry(entry);
      return;
    }
    if (this.#store.iterateEntries !== void 0) {
      for await (const entry of this.#store.iterateEntries()) this.indexPersistedEntry(entry);
      return;
    }
    if (this.#store.entries !== void 0) {
      for (const entry of await this.#store.entries()) this.indexPersistedEntry(entry);
    }
  }
  /**
   * Index a single persisted BytesStore entry if it belongs to this CAS prefix.
   * Returns true if the key was a CAS entry (allowing single-pass hydration in ApplicationSession.open).
   */
  indexPersistedEntry(entry, options = {}) {
    if (!entry.key.startsWith(this.#prefix)) return false;
    const rest = entry.key.slice(this.#prefix.length);
    let partition;
    let hash;
    if (rest.startsWith("pub/")) {
      partition = "public";
      hash = rest.slice(4);
    } else if (rest.startsWith("priv/")) {
      partition = "private";
      hash = rest.slice(5);
    } else return true;
    if (!HEX32.test(hash)) return true;
    const verifyHash = options.verifyHash ?? true;
    if (verifyHash) {
      const verifiedHash = hashCasNode(entry.value);
      if (verifiedHash !== hash) throw new Error(`CAS_CORRUPT: ${hash}`);
    }
    const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
    parts.add(partition);
    this.#known.set(hash, parts);
    const shouldPreload = options.preloadCache ?? (partition === "public" || this.#cache.size < this.#maxCacheEntries);
    if (shouldPreload) {
      const node = decodeCasNode(entry.value);
      this.#touchCache(hash, entry.value, node, partition);
    }
    return true;
  }
  /** Begin a staged replay batch: synchronous puts stay in RAM until flushBatch(). */
  beginBatch() {
    if (this.#inBatch) throw new Error("CAS_BATCH_ALREADY_ACTIVE");
    this.#inBatch = true;
  }
  /** Discard all uncommitted staged writes from the active batch. */
  rollbackBatch() {
    this.#staged.clear();
    this.#inBatch = false;
  }
  /** Persist staged chunks (optionally filtered to a reachable set) to BytesStore in one flush. */
  async flushBatch(keepHashes) {
    if (!this.#inBatch) return;
    const entries = [];
    for (const [hash, item] of this.#staged) {
      if (keepHashes !== void 0 && !keepHashes.has(hash)) continue;
      const known = this.#known.get(hash);
      if (known?.has(item.partition)) continue;
      entries.push({ key: this.#key(item.partition, hash), value: item.encoded });
    }
    for (let i = 0; i < entries.length; i += 128) {
      await writeBytesMany(this.#store, entries.slice(i, i + 128), { durability: "relaxed" });
    }
    for (const [hash, item] of this.#staged) {
      if (keepHashes !== void 0 && !keepHashes.has(hash)) continue;
      const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
      parts.add(item.partition);
      this.#known.set(hash, parts);
      this.#touchCache(hash, item.encoded, item.node, item.partition);
    }
    this.#staged.clear();
    this.#inBatch = false;
  }
  /** Synchronous put into staged RAM (or cache) for deterministic reducer execution. */
  putSync(bytes, links = [], partition = "private") {
    if (bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
    const encoded = encodeCasNode(bytes, links);
    const hash = hashCasNode(encoded);
    const node = { bytes: bytes.slice(), links: [...new Set(links)].sort() };
    this.#staged.set(hash, { encoded, node, partition });
    this.#touchCache(hash, encoded, node, partition);
    return hash;
  }
  /** Async durable put (for seeding modules, syncing blobs from peers, or outside a batch). */
  async put(bytes, links = [], partition = "private") {
    if (bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
    const encoded = encodeCasNode(bytes, links);
    const hash = hashCasNode(encoded);
    const node = { bytes: bytes.slice(), links: [...new Set(links)].sort() };
    if (!this.#known.get(hash)?.has(partition)) {
      await this.#store.put(this.#key(partition, hash), encoded, { durability: "relaxed" });
      const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
      parts.add(partition);
      this.#known.set(hash, parts);
    }
    this.#touchCache(hash, encoded, node, partition);
    return hash;
  }
  /** Put raw pre-encoded canonical CAS node bytes (verifying digest matches expectedHash). */
  async putRaw(expectedHash, encoded, partition = "private") {
    assertHashHex(expectedHash);
    if (encoded.byteLength > this.#maxChunkBytes + 65536) throw new Error("CAS_CHUNK_TOO_LARGE");
    const actual = hashCasNode(encoded);
    if (actual !== expectedHash) throw new Error(`CAS_HASH_MISMATCH: expected ${expectedHash}, got ${actual}`);
    const node = decodeCasNode(encoded);
    if (!equalBytes(encodeCasNode(node.bytes, node.links), encoded)) throw new Error("CAS_NODE_NOT_CANONICAL");
    await this.#store.put(this.#key(partition, expectedHash), encoded, { durability: "relaxed" });
    const parts = this.#known.get(expectedHash) ?? /* @__PURE__ */ new Set();
    parts.add(partition);
    this.#known.set(expectedHash, parts);
    this.#touchCache(expectedHash, encoded, node, partition);
  }
  /** Batched put for peer/host CAS sync (single putMany per 128 chunks instead of N transactions). */
  async putManyVerified(items) {
    const toWrite = [];
    const stagedMeta = [];
    for (const item of items) {
      if (this.hasSync(item.hash, item.partition)) continue;
      assertHashHex(item.hash);
      let encoded;
      let node;
      if (hashCasNode(item.bytes) === item.hash) {
        if (item.bytes.byteLength > this.#maxChunkBytes + 65536) throw new Error("CAS_CHUNK_TOO_LARGE");
        node = decodeCasNode(item.bytes);
        if (!equalBytes(encodeCasNode(node.bytes, node.links), item.bytes)) throw new Error("CAS_NODE_NOT_CANONICAL");
        encoded = item.bytes.slice();
      } else if (computeCasHash(item.bytes, []) === item.hash) {
        if (item.bytes.byteLength > this.#maxChunkBytes) throw new Error("CAS_CHUNK_TOO_LARGE");
        encoded = encodeCasNode(item.bytes, []);
        node = { bytes: item.bytes.slice(), links: [] };
      } else {
        throw new Error(`CAS_NODE_HASH_MISMATCH:${item.hash}`);
      }
      toWrite.push({ key: this.#key(item.partition, item.hash), value: encoded });
      stagedMeta.push({ hash: item.hash, encoded, node, partition: item.partition });
    }
    if (toWrite.length === 0) return 0;
    for (let i = 0; i < toWrite.length; i += 128) {
      await writeBytesMany(this.#store, toWrite.slice(i, i + 128), { durability: "relaxed" });
    }
    for (const meta of stagedMeta) {
      const parts = this.#known.get(meta.hash) ?? /* @__PURE__ */ new Set();
      parts.add(meta.partition);
      this.#known.set(meta.hash, parts);
      this.#touchCache(meta.hash, meta.encoded, meta.node, meta.partition);
    }
    return stagedMeta.length;
  }
  /** Fault a known-on-disk CAS node back into the synchronous RAM LRU (demand paging for >16 MiB DBs). */
  async ensureLoaded(hash, allowedPartition = "any") {
    if (!HEX32.test(hash)) return false;
    if (this.getSync(hash, allowedPartition) !== null) return true;
    const loaded = await this.get(hash, allowedPartition);
    return loaded !== null;
  }
  /** Synchronous read from staged RAM + LRU cache (respecting partition visibility). */
  getSync(hash, allowedPartition = "any") {
    assertHashHex(hash);
    const staged = this.#staged.get(hash);
    if (staged !== void 0 && (allowedPartition === "any" || staged.partition === allowedPartition)) {
      return { bytes: staged.node.bytes.slice(), links: [...staged.node.links] };
    }
    const cached = this.#cache.get(hash);
    if (cached !== void 0 && (allowedPartition === "any" || cached.partitions.has(allowedPartition))) {
      this.#cache.delete(hash);
      this.#cache.set(hash, cached);
      return { bytes: cached.node.bytes.slice(), links: [...cached.node.links] };
    }
    return null;
  }
  /** Async read checking RAM cache first, then BytesStore (respecting partition visibility). */
  async get(hash, allowedPartition = "any") {
    const sync = this.getSync(hash, allowedPartition);
    if (sync !== null) return sync;
    const partitions = allowedPartition === "any" ? ["public", "private"] : [allowedPartition];
    for (const partition of partitions) {
      const raw = await this.#store.get(this.#key(partition, hash));
      if (raw === null) continue;
      if (hashCasNode(raw) !== hash) throw new Error(`CAS_CORRUPT: ${hash}`);
      const node = decodeCasNode(raw);
      const parts = this.#known.get(hash) ?? /* @__PURE__ */ new Set();
      parts.add(partition);
      this.#known.set(hash, parts);
      this.#touchCache(hash, raw, node, partition);
      return { bytes: node.bytes.slice(), links: [...node.links] };
    }
    return null;
  }
  /** Get raw canonical node bytes for peer replication. */
  async getRaw(hash, allowedPartition = "any") {
    assertHashHex(hash);
    const staged = this.#staged.get(hash);
    if (staged !== void 0 && (allowedPartition === "any" || staged.partition === allowedPartition)) {
      return staged.encoded.slice();
    }
    const cached = this.#cache.get(hash);
    if (cached !== void 0 && (allowedPartition === "any" || cached.partitions.has(allowedPartition))) {
      return cached.encoded.slice();
    }
    const partitions = allowedPartition === "any" ? ["public", "private"] : [allowedPartition];
    for (const partition of partitions) {
      const raw = await this.#store.get(this.#key(partition, hash));
      if (raw !== null) return raw;
    }
    return null;
  }
  hasSync(hash, allowedPartition = "any") {
    if (!HEX32.test(hash)) return false;
    const staged = this.#staged.get(hash);
    if (staged !== void 0 && (allowedPartition === "any" || staged.partition === allowedPartition)) return true;
    const cached = this.#cache.get(hash);
    if (cached !== void 0 && (allowedPartition === "any" || cached.partitions.has(allowedPartition))) return true;
    const known = this.#known.get(hash);
    if (known !== void 0 && (allowedPartition === "any" || known.has(allowedPartition))) return true;
    return false;
  }
  /** Walk all explicit DAG links reachable from rootHashes (in RAM or durable store). */
  async reachable(rootHashes) {
    const visited = /* @__PURE__ */ new Set();
    const queue = [];
    for (const hash of rootHashes) {
      if (HEX32.test(hash) && !visited.has(hash)) {
        visited.add(hash);
        queue.push(hash);
      }
    }
    while (queue.length > 0) {
      const current = queue.pop();
      const node = await this.get(current, "any");
      if (node === null) continue;
      for (const link of node.links) {
        if (!visited.has(link)) {
          visited.add(link);
          queue.push(link);
        }
      }
    }
    return visited;
  }
  /** Pin a CAS root hash locally so mark-and-sweep GC preserves it and its transitive links. */
  pin(hash) {
    assertHashHex(hash);
    this.#pinned.add(hash);
  }
  /** Remove a local pin from a CAS root hash. */
  unpin(hash) {
    this.#pinned.delete(hash);
  }
  isPinned(hash) {
    return this.#pinned.has(hash);
  }
  pinnedHashes() {
    return [...this.#pinned].sort();
  }
  /**
   * Collect a bounded CAS subgraph reachable from rootHashes for single-round-trip peer replication.
   * Respects partition visibility (e.g. 'public' for unprivileged peers / blind hosts).
   */
  async collectSubgraph(rootHashes, options = {}) {
    const allowed = options.allowedPartition ?? "any";
    const maxNodes = options.maxNodes ?? 256;
    const maxBytes = options.maxBytes ?? 8 * 1024 * 1024;
    const visited = /* @__PURE__ */ new Set();
    const queue = [];
    for (const hash of rootHashes) {
      if (HEX32.test(hash) && !visited.has(hash)) {
        visited.add(hash);
        queue.push(hash);
      }
    }
    const out = [];
    let totalBytes = 0;
    while (queue.length > 0 && out.length < maxNodes) {
      const current = queue.shift();
      const partitions = allowed === "any" ? ["public", "private"] : [allowed];
      let chosenPartition = null;
      let raw = null;
      for (const p of partitions) {
        const candidate = await this.getRaw(current, p);
        if (candidate !== null) {
          chosenPartition = p;
          raw = candidate;
          break;
        }
      }
      if (raw === null || chosenPartition === null) continue;
      if (out.length > 0 && totalBytes + raw.byteLength > maxBytes) break;
      out.push({ hash: current, bytes: raw, partition: chosenPartition });
      totalBytes += raw.byteLength;
      const node = decodeCasNode(raw);
      for (const link of node.links) {
        if (!visited.has(link)) {
          visited.add(link);
          queue.push(link);
        }
      }
    }
    return out;
  }
  /** Delete specific unpinned CAS nodes from a partition (used for lazy-bulk LRU cache eviction). */
  async deleteNodes(hashes, partition) {
    if (this.#inBatch) throw new Error("CAS_DELETE_DURING_BATCH");
    const keys = [];
    const dropped = [];
    for (const hash of hashes) {
      if (!HEX32.test(hash) || this.#pinned.has(hash)) continue;
      const parts = this.#known.get(hash);
      if (parts !== void 0 && parts.has(partition)) {
        keys.push(this.#key(partition, hash));
        dropped.push(hash);
      }
    }
    if (keys.length === 0) return 0;
    for (let i = 0; i < keys.length; i += 32) {
      await deleteBytesMany(this.#store, keys.slice(i, i + 32), { durability: "relaxed" });
    }
    for (const hash of dropped) {
      const parts = this.#known.get(hash);
      if (parts !== void 0) {
        parts.delete(partition);
        if (parts.size === 0) this.#known.delete(hash);
      }
      const cached = this.#cache.get(hash);
      if (cached !== void 0) {
        cached.partitions.delete(partition);
        if (cached.partitions.size === 0) this.#cache.delete(hash);
      }
    }
    return dropped.length;
  }
  /** Exact local mark-and-sweep GC preserving everything reachable from rootHashes + pinned roots, deleting in yielding batches. */
  async collectGarbage(rootHashes) {
    if (this.#inBatch) throw new Error("CAS_GC_DURING_BATCH");
    const allRoots = new Set(this.#pinned);
    for (const h of rootHashes) allRoots.add(h);
    const keep = await this.reachable(allRoots);
    const keysToDelete = [];
    const hashesToDrop = [];
    for (const [hash, partitions] of [...this.#known.entries()]) {
      if (keep.has(hash)) continue;
      for (const partition of partitions) {
        keysToDelete.push(this.#key(partition, hash));
      }
      hashesToDrop.push(hash);
    }
    for (let i = 0; i < keysToDelete.length; i += 32) {
      await deleteBytesMany(this.#store, keysToDelete.slice(i, i + 32), { durability: "relaxed" });
      if (i + 32 < keysToDelete.length) {
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    }
    for (const hash of hashesToDrop) {
      this.#known.delete(hash);
      this.#cache.delete(hash);
    }
    return { kept: keep.size, deleted: keysToDelete.length };
  }
  listKnownHashes(partition) {
    const out = /* @__PURE__ */ new Set();
    for (const [hash, parts] of this.#known) {
      if (partition === void 0 || parts.has(partition)) out.add(hash);
    }
    for (const [hash, item] of this.#staged) {
      if (partition === void 0 || item.partition === partition) out.add(hash);
    }
    return [...out].sort();
  }
};

// packages/records/src/cas-objects.ts
var HEX322 = /^[0-9a-f]{64}$/u;
var CAS_REF_RE = /^cas:sha256-([0-9a-f]{64})$/u;
var CAS_BLOB_CHUNK_BYTES = 65536;
var CAS_BLOB_FANOUT = 64;
var ALLOWED_BUILTINS = /* @__PURE__ */ new Set([
  "chronolog:crypto",
  "chronolog:cas",
  "chronolog:sqlite",
  "chronolog:wasm"
]);
function casRef(hash) {
  if (!HEX322.test(hash)) throw new Error(`CAS_HASH_INVALID:${hash}`);
  return `cas:sha256-${hash}`;
}
function parseCasRef(ref) {
  const match = CAS_REF_RE.exec(ref);
  if (match === null) throw new Error(`CAS_REF_INVALID:${ref}`);
  return match[1];
}
function tryParseCasRef(ref) {
  const match = CAS_REF_RE.exec(ref);
  return match === null ? null : match[1];
}
function normalizePosixPath(input) {
  if (typeof input !== "string" || input.length === 0 || input.length > 512) {
    throw new Error(`CAS_PATH_INVALID:${String(input)}`);
  }
  const normalized = input.replaceAll("\\", "/").replace(/^\.\//u, "");
  if (normalized.startsWith("/") || normalized.endsWith("/") || normalized.includes("\0")) {
    throw new Error(`CAS_PATH_INVALID:${input}`);
  }
  const parts = normalized.split("/");
  for (const part of parts) {
    if (part.length === 0 || part === "." || part === "..") {
      throw new Error(`CAS_PATH_INVALID:${input}`);
    }
  }
  return parts.join("/");
}
function resolvePackageRelativePath(baseFilePath, relativeSpecifier) {
  const baseParts = normalizePosixPath(baseFilePath).split("/");
  baseParts.pop();
  for (const seg of relativeSpecifier.split("/")) {
    if (seg === "" || seg === ".") continue;
    if (seg === "..") {
      if (baseParts.length === 0) throw new Error(`PACKAGE_PATH_ESCAPE:${baseFilePath}:${relativeSpecifier}`);
      baseParts.pop();
    } else {
      baseParts.push(seg);
    }
  }
  if (baseParts.length === 0) throw new Error(`PACKAGE_PATH_EMPTY:${baseFilePath}:${relativeSpecifier}`);
  return normalizePosixPath(baseParts.join("/"));
}
function unknownToCbor(value, depth = 0) {
  if (depth > 32) throw new Error("CAS_OBJECT_TOO_DEEP");
  if (value === null || typeof value === "boolean" || typeof value === "string") return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new Error("CAS_OBJECT_NON_FINITE_NUMBER");
    if (Number.isSafeInteger(value)) return BigInt(Object.is(value, -0) ? 0 : value);
    return /* @__PURE__ */ new Map([["$f", JSON.stringify(value)]]);
  }
  if (value instanceof Uint8Array) return value;
  if (Array.isArray(value)) return value.map((item) => unknownToCbor(item, depth + 1));
  if (typeof value === "object") {
    const rec = value;
    const map = /* @__PURE__ */ new Map();
    for (const k of Object.keys(rec).sort()) {
      const v = rec[k];
      if (v !== void 0) map.set(k, unknownToCbor(v, depth + 1));
    }
    return map;
  }
  throw new Error("CAS_OBJECT_UNSUPPORTED_VALUE");
}
function cborToUnknown(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return value;
  if (typeof value === "bigint") {
    if (value < BigInt(Number.MIN_SAFE_INTEGER) || value > BigInt(Number.MAX_SAFE_INTEGER)) {
      throw new Error("CAS_OBJECT_INTEGER_OUT_OF_RANGE");
    }
    return Number(value);
  }
  if (value instanceof Uint8Array) return value.slice();
  if (Array.isArray(value)) return value.map(cborToUnknown);
  if (value instanceof Map) {
    if (value.size === 1 && value.has("$f") && typeof value.get("$f") === "string") {
      const n = Number(value.get("$f"));
      if (!Number.isFinite(n)) throw new Error("CAS_OBJECT_NON_FINITE_NUMBER");
      return n;
    }
    const out = {};
    for (const [k, v] of value) {
      if (typeof k !== "string") throw new Error("CAS_OBJECT_KEY_INVALID");
      out[k] = cborToUnknown(v);
    }
    return out;
  }
  throw new Error("CAS_OBJECT_UNSUPPORTED_CBOR");
}
function encodeBlobTreeNode(node) {
  const childArr = node.children.map((c) => [c.hash, BigInt(c.bytes)]);
  const bytes = encodeCanonicalCbor(/* @__PURE__ */ new Map([
    ["bytes", BigInt(node.bytes)],
    ["children", childArr],
    ["format", "chronolog-blob/v1"]
  ]));
  const links = [...new Set(node.children.map((c) => c.hash))].sort();
  return { bytes, links };
}
function tryDecodeBlobTreeNode(rawBytes, links) {
  if (links.length === 0) return null;
  try {
    const decoded = assertCanonicalCbor(rawBytes, DEFAULT_DECODE_LIMITS);
    if (!(decoded instanceof Map)) return null;
    const map = decoded;
    if (map.get("format") !== "chronolog-blob/v1") return null;
    const totalBytes = map.get("bytes");
    const rawChildren = map.get("children");
    if (typeof totalBytes !== "bigint" || totalBytes < 0n || !Array.isArray(rawChildren) || rawChildren.length === 0) {
      return null;
    }
    const children = [];
    for (const item of rawChildren) {
      if (!Array.isArray(item) || item.length !== 2 || typeof item[0] !== "string" || typeof item[1] !== "bigint") {
        return null;
      }
      if (!HEX322.test(item[0]) || item[1] < 0n) return null;
      children.push({ hash: item[0], bytes: Number(item[1]) });
    }
    return { format: "chronolog-blob/v1", bytes: Number(totalBytes), children };
  } catch {
    return null;
  }
}
function computeBlobDagHash(bytes) {
  if (bytes.byteLength <= CAS_BLOB_CHUNK_BYTES) {
    return computeCasHash(bytes, []);
  }
  let level = [];
  for (let offset = 0; offset < bytes.byteLength; offset += CAS_BLOB_CHUNK_BYTES) {
    const slice = bytes.subarray(offset, Math.min(bytes.byteLength, offset + CAS_BLOB_CHUNK_BYTES));
    level.push({ hash: computeCasHash(slice, []), bytes: slice.byteLength });
  }
  while (level.length > 1) {
    const nextLevel = [];
    for (let i = 0; i < level.length; i += CAS_BLOB_FANOUT) {
      const group = level.slice(i, i + CAS_BLOB_FANOUT);
      const total = group.reduce((acc, item) => acc + item.bytes, 0);
      const encoded = encodeBlobTreeNode({ format: "chronolog-blob/v1", bytes: total, children: group });
      nextLevel.push({ hash: computeCasHash(encoded.bytes, encoded.links), bytes: total });
    }
    level = nextLevel;
  }
  return level[0].hash;
}
async function putBlobDag(cas, bytes, partition = "public") {
  if (bytes.byteLength <= CAS_BLOB_CHUNK_BYTES) {
    const hash = await cas.put(bytes, [], partition);
    return { hash, bytes: bytes.byteLength };
  }
  let level = [];
  for (let offset = 0; offset < bytes.byteLength; offset += CAS_BLOB_CHUNK_BYTES) {
    const slice = bytes.subarray(offset, Math.min(bytes.byteLength, offset + CAS_BLOB_CHUNK_BYTES));
    const hash = await cas.put(slice, [], partition);
    level.push({ hash, bytes: slice.byteLength });
  }
  while (level.length > 1) {
    const nextLevel = [];
    for (let i = 0; i < level.length; i += CAS_BLOB_FANOUT) {
      const group = level.slice(i, i + CAS_BLOB_FANOUT);
      const total = group.reduce((acc, item) => acc + item.bytes, 0);
      const encoded = encodeBlobTreeNode({ format: "chronolog-blob/v1", bytes: total, children: group });
      const hash = await cas.put(encoded.bytes, encoded.links, partition);
      nextLevel.push({ hash, bytes: total });
    }
    level = nextLevel;
  }
  return { hash: level[0].hash, bytes: bytes.byteLength };
}
async function statBlobDag(cas, rootHash, partition = "any") {
  const node = await cas.get(rootHash, partition);
  if (node === null) return null;
  const tree = tryDecodeBlobTreeNode(node.bytes, node.links);
  if (tree !== null) return { hash: rootHash, bytes: tree.bytes, chunked: true };
  return { hash: rootHash, bytes: node.bytes.byteLength, chunked: false };
}
async function readBlobDag(cas, rootHash, partition = "any", options = {}) {
  const root = await cas.get(rootHash, partition);
  if (root === null) return null;
  const tree = tryDecodeBlobTreeNode(root.bytes, root.links);
  if (tree === null) {
    if (options.maxBytes !== void 0 && root.bytes.byteLength > options.maxBytes) {
      throw new Error("CAS_BLOB_READ_LIMIT_EXCEEDED");
    }
    return root.bytes;
  }
  if (options.maxBytes !== void 0 && tree.bytes > options.maxBytes) {
    throw new Error("CAS_BLOB_READ_LIMIT_EXCEEDED");
  }
  const out = new Uint8Array(tree.bytes);
  let offset = 0;
  const walk = async (nodeHash) => {
    const node = await cas.get(nodeHash, partition);
    if (node === null) throw new Error(`CAS_BLOB_MISSING_NODE:${nodeHash}`);
    const sub = tryDecodeBlobTreeNode(node.bytes, node.links);
    if (sub === null) {
      if (offset + node.bytes.byteLength > out.byteLength) throw new Error("CAS_BLOB_SIZE_MISMATCH");
      out.set(node.bytes, offset);
      offset += node.bytes.byteLength;
      return;
    }
    for (const child of sub.children) {
      await walk(child.hash);
    }
  };
  for (const child of tree.children) {
    await walk(child.hash);
  }
  if (offset !== out.byteLength) throw new Error("CAS_BLOB_INCOMPLETE");
  return out;
}
function readBlobDagSync(cas, rootHash, partition, onMissing) {
  const root = cas.getSync(rootHash, partition);
  if (root === null) onMissing(rootHash);
  const tree = tryDecodeBlobTreeNode(root.bytes, root.links);
  if (tree === null) return root.bytes;
  const out = new Uint8Array(tree.bytes);
  let offset = 0;
  const stack = tree.children.map((c) => c.hash).reverse();
  while (stack.length > 0) {
    const h = stack.pop();
    const node = cas.getSync(h, partition);
    if (node === null) onMissing(h);
    const sub = tryDecodeBlobTreeNode(node.bytes, node.links);
    if (sub === null) {
      if (offset + node.bytes.byteLength > out.byteLength) throw new Error("CAS_BLOB_SIZE_MISMATCH");
      out.set(node.bytes, offset);
      offset += node.bytes.byteLength;
    } else {
      for (let i = sub.children.length - 1; i >= 0; i--) stack.push(sub.children[i].hash);
    }
  }
  if (offset !== out.byteLength) throw new Error("CAS_BLOB_INCOMPLETE");
  return out;
}
function encodeEncBlobManifest(manifest) {
  if (manifest.format !== "chronolog-enc-blob/v1") throw new Error("ENC_BLOB_FORMAT_INVALID");
  if (!HEX322.test(manifest.applicationId)) throw new Error("ENC_BLOB_APP_ID_INVALID");
  if (!Number.isSafeInteger(manifest.epoch) || manifest.epoch < 0) throw new Error("ENC_BLOB_EPOCH_INVALID");
  if (!Number.isSafeInteger(manifest.bytes) || manifest.bytes < 0) throw new Error("ENC_BLOB_BYTES_INVALID");
  if (typeof manifest.mediaType !== "string" || manifest.mediaType.length === 0 || manifest.mediaType.length > 256) {
    throw new Error("ENC_BLOB_MEDIA_TYPE_INVALID");
  }
  const chunkEntries = [];
  const linkSet = /* @__PURE__ */ new Set();
  for (const chunk of manifest.chunks) {
    if (!HEX322.test(chunk.hash) || !Number.isSafeInteger(chunk.bytes) || chunk.bytes <= 0 || !Number.isSafeInteger(chunk.plainBytes) || chunk.plainBytes <= 0) {
      throw new Error("ENC_BLOB_CHUNK_INVALID");
    }
    chunkEntries.push([chunk.hash, BigInt(chunk.bytes), BigInt(chunk.plainBytes)]);
    linkSet.add(chunk.hash);
  }
  const map = /* @__PURE__ */ new Map([
    ["applicationId", manifest.applicationId],
    ["bytes", BigInt(manifest.bytes)],
    ["chunks", chunkEntries],
    ["epoch", BigInt(manifest.epoch)],
    ["format", "chronolog-enc-blob/v1"],
    ["mediaType", manifest.mediaType]
  ]);
  if (manifest.stageId !== void 0) map.set("stageId", manifest.stageId);
  return { bytes: encodeCanonicalCbor(map), links: [...linkSet].sort() };
}
function assertValidPackageNode(pkg) {
  if (pkg.format !== "chronolog-pkg/v1") throw new Error("PKG_FORMAT_INVALID");
  if (pkg.runtime !== "esm-quickjs" && pkg.runtime !== "wasm-pure" && pkg.runtime !== "hybrid") {
    throw new Error(`PKG_RUNTIME_INVALID:${String(pkg.runtime)}`);
  }
  if (pkg.name !== void 0 && (typeof pkg.name !== "string" || pkg.name.length === 0 || pkg.name.length > 256)) {
    throw new Error("PKG_NAME_INVALID");
  }
  if (pkg.version !== void 0 && (typeof pkg.version !== "string" || pkg.version.length === 0 || pkg.version.length > 128)) {
    throw new Error("PKG_VERSION_INVALID");
  }
  const files = {};
  for (const [rawPath, ref] of Object.entries(pkg.files).sort(([a], [b]) => a.localeCompare(b))) {
    const path = normalizePosixPath(rawPath);
    files[path] = casRef(parseCasRef(ref));
  }
  if (Object.keys(files).length === 0) throw new Error("PKG_FILES_EMPTY");
  const exportsMap = {};
  for (const [subpath, target] of Object.entries(pkg.exports).sort(([a], [b]) => a.localeCompare(b))) {
    if (subpath !== "." && !subpath.startsWith("./")) throw new Error(`PKG_EXPORT_SUBPATH_INVALID:${subpath}`);
    const normTarget = normalizePosixPath(target);
    if (!Object.hasOwn(files, normTarget)) throw new Error(`PKG_EXPORT_MISSING_FILE:${subpath}:${normTarget}`);
    exportsMap[subpath] = normTarget;
  }
  if (pkg.runtime !== "wasm-pure" && Object.keys(exportsMap).length === 0) {
    throw new Error("PKG_EXPORTS_EMPTY");
  }
  const dependencies = {};
  for (const [spec, ref] of Object.entries(pkg.dependencies).sort(([a], [b]) => a.localeCompare(b))) {
    if (typeof spec !== "string" || spec.length === 0 || spec.length > 256 || spec.startsWith(".") || spec.startsWith("/")) {
      throw new Error(`PKG_DEPENDENCY_SPEC_INVALID:${spec}`);
    }
    dependencies[spec] = casRef(parseCasRef(ref));
  }
  const builtinsSet = /* @__PURE__ */ new Set();
  for (const b of pkg.builtins) {
    if (!ALLOWED_BUILTINS.has(b)) throw new Error(`PKG_BUILTIN_INVALID:${String(b)}`);
    builtinsSet.add(b);
  }
  const builtins = [...builtinsSet].sort();
  let wasm;
  if (pkg.wasm !== void 0) {
    const entry = normalizePosixPath(pkg.wasm.entry);
    if (!Object.hasOwn(files, entry)) throw new Error(`PKG_WASM_ENTRY_MISSING:${entry}`);
    if (pkg.wasm.abi !== "chronolog-wasm/v1") throw new Error(`PKG_WASM_ABI_INVALID:${String(pkg.wasm.abi)}`);
    wasm = { entry, abi: "chronolog-wasm/v1" };
  } else if (pkg.runtime === "wasm-pure") {
    throw new Error("PKG_WASM_ENTRY_REQUIRED");
  }
  const derivation = pkg.derivation === void 0 ? void 0 : casRef(parseCasRef(pkg.derivation));
  return {
    format: "chronolog-pkg/v1",
    ...pkg.name === void 0 ? {} : { name: pkg.name },
    ...pkg.version === void 0 ? {} : { version: pkg.version },
    runtime: pkg.runtime,
    files,
    exports: exportsMap,
    dependencies,
    builtins,
    ...wasm === void 0 ? {} : { wasm },
    ...derivation === void 0 ? {} : { derivation }
  };
}
function encodePackageNode(pkg) {
  const clean = assertValidPackageNode(pkg);
  const linkSet = /* @__PURE__ */ new Set();
  const filesMap = /* @__PURE__ */ new Map();
  for (const [p, ref] of Object.entries(clean.files)) {
    filesMap.set(p, ref);
    linkSet.add(parseCasRef(ref));
  }
  const exportsMap = /* @__PURE__ */ new Map();
  for (const [k, v] of Object.entries(clean.exports)) exportsMap.set(k, v);
  const depsMap = /* @__PURE__ */ new Map();
  for (const [k, ref] of Object.entries(clean.dependencies)) {
    depsMap.set(k, ref);
    linkSet.add(parseCasRef(ref));
  }
  const map = /* @__PURE__ */ new Map([
    ["builtins", [...clean.builtins]],
    ["dependencies", depsMap],
    ["exports", exportsMap],
    ["files", filesMap],
    ["format", "chronolog-pkg/v1"],
    ["runtime", clean.runtime]
  ]);
  if (clean.name !== void 0) map.set("name", clean.name);
  if (clean.version !== void 0) map.set("version", clean.version);
  if (clean.wasm !== void 0) {
    map.set("wasm", /* @__PURE__ */ new Map([
      ["abi", clean.wasm.abi],
      ["entry", clean.wasm.entry]
    ]));
  }
  if (clean.derivation !== void 0) map.set("derivation", clean.derivation);
  return { bytes: encodeCanonicalCbor(map), links: [...linkSet].sort() };
}
function tryDecodePackageNode(rawBytes) {
  if (rawBytes.byteLength === 0 || (rawBytes[0] & 224) !== 160) return null;
  try {
    const decoded = assertCanonicalCbor(rawBytes, DEFAULT_DECODE_LIMITS);
    if (!(decoded instanceof Map)) return null;
    const map = decoded;
    if (map.get("format") !== "chronolog-pkg/v1") return null;
    const runtime = map.get("runtime");
    const rawFiles = map.get("files");
    const rawExports = map.get("exports");
    const rawDeps = map.get("dependencies");
    const rawBuiltins = map.get("builtins");
    if (typeof runtime !== "string" || !(rawFiles instanceof Map) || !(rawExports instanceof Map) || !(rawDeps instanceof Map) || !Array.isArray(rawBuiltins)) {
      return null;
    }
    const toStringRecord = (m) => {
      const out = {};
      for (const [k, v] of m) {
        if (typeof k !== "string" || typeof v !== "string") throw new Error("PKG_MAP_INVALID");
        out[k] = v;
      }
      return out;
    };
    const builtins = rawBuiltins.map((item) => {
      if (typeof item !== "string") throw new Error("PKG_BUILTIN_INVALID");
      return item;
    });
    const name = map.get("name");
    const version = map.get("version");
    const derivation = map.get("derivation");
    const rawWasm = map.get("wasm");
    let wasm;
    if (rawWasm !== void 0) {
      if (!(rawWasm instanceof Map)) return null;
      const wasmMap = rawWasm;
      const entry = wasmMap.get("entry");
      const abi = wasmMap.get("abi");
      if (typeof entry !== "string" || abi !== "chronolog-wasm/v1") return null;
      wasm = { entry, abi };
    }
    return assertValidPackageNode({
      format: "chronolog-pkg/v1",
      ...typeof name === "string" ? { name } : {},
      ...typeof version === "string" ? { version } : {},
      runtime,
      files: toStringRecord(rawFiles),
      exports: toStringRecord(rawExports),
      dependencies: toStringRecord(rawDeps),
      builtins,
      ...wasm === void 0 ? {} : { wasm },
      ...typeof derivation === "string" ? { derivation } : {}
    });
  } catch {
    return null;
  }
}
function decodePackageNode(rawBytes) {
  const pkg = tryDecodePackageNode(rawBytes);
  if (pkg === null) throw new Error("PKG_NODE_INVALID");
  return pkg;
}
async function putPackageDag(cas, input, partition = "public") {
  const fileRefs = {};
  const enc = new TextEncoder();
  for (const [rawPath, content] of Object.entries(input.files).sort(([a], [b]) => a.localeCompare(b))) {
    const path = normalizePosixPath(rawPath);
    const bytes = typeof content === "string" ? enc.encode(content) : content;
    const stored = await putBlobDag(cas, bytes, partition);
    fileRefs[path] = casRef(stored.hash);
  }
  const runtime = input.runtime ?? (input.wasm !== void 0 && Object.keys(fileRefs).length === 1 ? "wasm-pure" : "esm-quickjs");
  const firstFile = Object.keys(fileRefs).sort()[0];
  const exportsMap = input.exports ?? (runtime === "wasm-pure" ? {} : firstFile === void 0 ? {} : { ".": firstFile });
  const manifest = assertValidPackageNode({
    format: "chronolog-pkg/v1",
    ...input.name === void 0 ? {} : { name: input.name },
    ...input.version === void 0 ? {} : { version: input.version },
    runtime,
    files: fileRefs,
    exports: exportsMap,
    dependencies: input.dependencies ?? {},
    builtins: input.builtins ?? [],
    ...input.wasm === void 0 ? {} : { wasm: input.wasm },
    ...input.derivation === void 0 ? {} : { derivation: input.derivation }
  });
  const encoded = encodePackageNode(manifest);
  const hash = await cas.put(encoded.bytes, encoded.links, partition);
  return { hash, ref: casRef(hash), manifest };
}
function encodeTreeNode(tree) {
  if (tree.format !== "chronolog-tree/v1") throw new Error("TREE_FORMAT_INVALID");
  const entriesMap = /* @__PURE__ */ new Map();
  const linkSet = /* @__PURE__ */ new Set();
  for (const [rawPath, ref] of Object.entries(tree.entries).sort(([a], [b]) => a.localeCompare(b))) {
    const path = normalizePosixPath(rawPath);
    const hash = parseCasRef(ref);
    entriesMap.set(path, casRef(hash));
    linkSet.add(hash);
  }
  const map = /* @__PURE__ */ new Map([
    ["entries", entriesMap],
    ["format", "chronolog-tree/v1"]
  ]);
  return { bytes: encodeCanonicalCbor(map), links: [...linkSet].sort() };
}
function decodeTreeNode(rawBytes) {
  const decoded = assertCanonicalCbor(rawBytes, DEFAULT_DECODE_LIMITS);
  if (!(decoded instanceof Map)) throw new Error("TREE_NODE_INVALID");
  const map = decoded;
  if (map.get("format") !== "chronolog-tree/v1") {
    throw new Error("TREE_NODE_INVALID");
  }
  const rawEntries = map.get("entries");
  if (!(rawEntries instanceof Map)) throw new Error("TREE_NODE_INVALID");
  const entries = {};
  for (const [k, v] of rawEntries) {
    if (typeof k !== "string" || typeof v !== "string") throw new Error("TREE_ENTRY_INVALID");
    entries[normalizePosixPath(k)] = casRef(parseCasRef(v));
  }
  return { format: "chronolog-tree/v1", entries };
}
async function putTreeDag(cas, files, partition = "public") {
  const entries = {};
  const enc = new TextEncoder();
  for (const [rawPath, content] of Object.entries(files).sort(([a], [b]) => a.localeCompare(b))) {
    const path = normalizePosixPath(rawPath);
    const bytes = typeof content === "string" ? enc.encode(content) : content;
    const stored = await putBlobDag(cas, bytes, partition);
    entries[path] = casRef(stored.hash);
  }
  const tree = { format: "chronolog-tree/v1", entries };
  const encoded = encodeTreeNode(tree);
  const hash = await cas.put(encoded.bytes, encoded.links, partition);
  return { hash, ref: casRef(hash), tree };
}
function assertValidDerivationNode(drv) {
  if (drv.format !== "chronolog-drv/v1") throw new Error("DRV_FORMAT_INVALID");
  if (drv.profile !== "quickjs-inline" && drv.profile !== "wasi-cas-v1") {
    throw new Error(`DRV_PROFILE_INVALID:${String(drv.profile)}`);
  }
  const builder = casRef(parseCasRef(drv.builder));
  const inputs = {};
  for (const [k, ref] of Object.entries(drv.inputs).sort(([a], [b]) => a.localeCompare(b))) {
    if (typeof k !== "string" || k.length === 0 || k.length > 256) throw new Error(`DRV_INPUT_KEY_INVALID:${k}`);
    inputs[k] = casRef(parseCasRef(ref));
  }
  if (drv.args === null || typeof drv.args !== "object" || Array.isArray(drv.args)) {
    throw new Error("DRV_ARGS_INVALID");
  }
  if (!Number.isSafeInteger(drv.limits.maxMemoryBytes) || drv.limits.maxMemoryBytes <= 0 || !Number.isSafeInteger(drv.limits.maxFuel) || drv.limits.maxFuel <= 0) {
    throw new Error("DRV_LIMITS_INVALID");
  }
  return {
    format: "chronolog-drv/v1",
    profile: drv.profile,
    builder,
    inputs,
    args: drv.args,
    limits: {
      maxMemoryBytes: drv.limits.maxMemoryBytes,
      maxFuel: drv.limits.maxFuel
    }
  };
}
function encodeDerivationNode(drv) {
  const clean = assertValidDerivationNode(drv);
  const linkSet = /* @__PURE__ */ new Set([parseCasRef(clean.builder)]);
  const inputsMap = /* @__PURE__ */ new Map();
  for (const [k, ref] of Object.entries(clean.inputs)) {
    inputsMap.set(k, ref);
    linkSet.add(parseCasRef(ref));
  }
  const map = /* @__PURE__ */ new Map([
    ["args", unknownToCbor(clean.args)],
    ["builder", clean.builder],
    ["format", "chronolog-drv/v1"],
    ["inputs", inputsMap],
    ["limits", /* @__PURE__ */ new Map([
      ["maxFuel", BigInt(clean.limits.maxFuel)],
      ["maxMemoryBytes", BigInt(clean.limits.maxMemoryBytes)]
    ])],
    ["profile", clean.profile]
  ]);
  return { bytes: encodeCanonicalCbor(map), links: [...linkSet].sort() };
}
function decodeDerivationNode(rawBytes) {
  const decoded = assertCanonicalCbor(rawBytes, DEFAULT_DECODE_LIMITS);
  if (!(decoded instanceof Map)) throw new Error("DRV_NODE_INVALID");
  const map = decoded;
  if (map.get("format") !== "chronolog-drv/v1") {
    throw new Error("DRV_NODE_INVALID");
  }
  const profile = map.get("profile");
  const builder = map.get("builder");
  const rawInputs = map.get("inputs");
  const rawArgs = map.get("args");
  const rawLimits = map.get("limits");
  if (typeof profile !== "string" || typeof builder !== "string" || !(rawInputs instanceof Map) || !(rawArgs instanceof Map) || !(rawLimits instanceof Map)) {
    throw new Error("DRV_NODE_INVALID");
  }
  const inputs = {};
  for (const [k, v] of rawInputs) {
    if (typeof k !== "string" || typeof v !== "string") throw new Error("DRV_INPUT_INVALID");
    inputs[k] = v;
  }
  const args = cborToUnknown(rawArgs);
  const limitsMap = rawLimits;
  const maxMemoryBytes = limitsMap.get("maxMemoryBytes");
  const maxFuel = limitsMap.get("maxFuel");
  if (typeof maxMemoryBytes !== "bigint" || typeof maxFuel !== "bigint") {
    throw new Error("DRV_LIMITS_INVALID");
  }
  return assertValidDerivationNode({
    format: "chronolog-drv/v1",
    profile,
    builder,
    inputs,
    args,
    limits: {
      maxMemoryBytes: Number(maxMemoryBytes),
      maxFuel: Number(maxFuel)
    }
  });
}
async function putDerivationNode(cas, drv, partition = "public") {
  const clean = assertValidDerivationNode(drv);
  const encoded = encodeDerivationNode(clean);
  const hash = await cas.put(encoded.bytes, encoded.links, partition);
  return { hash, ref: casRef(hash), derivation: clean };
}

// packages/records/src/live-channel.ts
var PEER_LIVE_MESSAGE_LIMITS = Object.freeze({ frameBytes: 16448, queueFrames: 64, bufferedBytes: 65536 });
function frameLiveMessageChannel(channel) {
  channel.binaryType = "arraybuffer";
  let closed = false, reading = false, failure = null;
  let sentBytes = 0, receivedBytes = 0, sentPackets = 0, receivedPackets = 0, queuedReceiveBytes = 0, droppedPackets = 0;
  let resolveReady, rejectReady;
  const ready = new Promise((resolve, reject) => {
    resolveReady = resolve;
    rejectReady = reject;
  });
  void ready.catch(() => void 0);
  const lifetime = new AbortController(), queue = [], waiters = /* @__PURE__ */ new Set();
  const listeners = [];
  const wake = () => {
    for (const resolve of waiters) resolve();
    waiters.clear();
  };
  const stop = (error) => {
    if (closed) return;
    closed = true;
    failure = error ?? null;
    rejectReady(error ?? new Error("PEER_MESSAGE_LIVE_CLOSED"));
    for (const [type, listener] of listeners) channel.removeEventListener(type, listener);
    queue.length = 0;
    queuedReceiveBytes = 0;
    lifetime.abort(error ?? new Error("PEER_MESSAGE_LIVE_CLOSED"));
    channel.close();
    wake();
  };
  const on = (type, listener) => {
    listeners.push([type, listener]);
    channel.addEventListener(type, listener);
  };
  on("open", () => resolveReady());
  on("close", () => stop(new Error("PEER_MESSAGE_LIVE_ENDED")));
  on("error", () => stop(new Error("PEER_MESSAGE_LIVE_ERROR")));
  on("message", (event) => {
    if (closed) return;
    const value = event.data;
    if (!(value instanceof ArrayBuffer) || value.byteLength < 1 || value.byteLength > PEER_LIVE_MESSAGE_LIMITS.frameBytes) {
      stop(new Error("PEER_MESSAGE_LIVE_FRAME_INVALID"));
      return;
    }
    receivedBytes += value.byteLength;
    receivedPackets += 1;
    if (queue.length === PEER_LIVE_MESSAGE_LIMITS.queueFrames) {
      queuedReceiveBytes -= queue.shift().length;
      droppedPackets += 1;
    }
    const bytes = new Uint8Array(value.slice(0));
    queue.push(bytes);
    queuedReceiveBytes += bytes.length;
    wake();
  });
  if (channel.readyState === "open") resolveReady();
  else if (channel.readyState !== "connecting") stop(new Error("PEER_MESSAGE_LIVE_CLOSED"));
  async function* read(signal) {
    if (reading) throw new Error("PEER_MESSAGE_LIVE_READER_EXISTS");
    reading = true;
    const abort = () => stop();
    signal.addEventListener("abort", abort, { once: true });
    try {
      if (signal.aborted) return;
      for (; ; ) {
        if (failure !== null) throw failure;
        if (closed) return;
        const bytes = queue.shift();
        if (bytes === void 0) {
          await new Promise((resolve) => {
            waiters.add(resolve);
          });
          continue;
        }
        queuedReceiveBytes -= bytes.length;
        yield bytes;
      }
    } finally {
      signal.removeEventListener("abort", abort);
      stop();
    }
  }
  return {
    ready,
    signal: lifetime.signal,
    get stats() {
      return {
        sentBytes,
        receivedBytes,
        sentPackets,
        receivedPackets,
        droppedPackets,
        queuedSendBytes: channel.bufferedAmount,
        queuedReceiveBytes,
        queuedReceiveFrames: queue.length
      };
    },
    async trySend(input, options = {}) {
      options.signal?.throwIfAborted();
      if (closed) throw failure ?? new Error("PEER_MESSAGE_LIVE_CLOSED");
      if (channel.readyState !== "open") throw new Error("PEER_MESSAGE_LIVE_NOT_OPEN");
      if (!(input instanceof Uint8Array) || input.length < 1 || input.length > PEER_LIVE_MESSAGE_LIMITS.frameBytes) throw new Error("PEER_MESSAGE_LIVE_FRAME_TOO_LARGE");
      if (channel.bufferedAmount + input.length > PEER_LIVE_MESSAGE_LIMITS.bufferedBytes) return false;
      channel.send(input.slice().buffer);
      sentBytes += input.length;
      sentPackets += 1;
      return true;
    },
    frames(signal) {
      return { [Symbol.asyncIterator]() {
        const controller = new AbortController();
        const iterator = read(signal === void 0 ? controller.signal : AbortSignal.any([controller.signal, signal]));
        return {
          next: () => iterator.next(),
          async return() {
            controller.abort();
            return iterator.return();
          },
          async throw(error) {
            controller.abort();
            return iterator.throw(error);
          }
        };
      } };
    },
    async close() {
      stop();
    }
  };
}

// packages/records/src/message-channel.ts
var PEER_MESSAGE_LIMITS = Object.freeze({
  frameBytes: 1048576 + 65536,
  packetBytes: 16 * 1024,
  queueBytes: 4 * 1024 * 1024,
  queueFrames: 16,
  bufferedBytes: 256 * 1024
});
var HEADER = 16;
var HELLO = 1;
var DATA = 2;
var CREDIT = 3;
function framePeerMessageChannels(channels, options = {}) {
  const reliable = frameMessageChannel(channels.reliable, options);
  let live;
  try {
    live = frameLiveMessageChannel(channels.live);
  } catch (error) {
    void reliable.close();
    channels.live.close();
    throw error;
  }
  const signal = AbortSignal.any([reliable.signal, live.signal]);
  const close = async () => {
    await Promise.all([reliable.close(), live.close()]);
  };
  signal.addEventListener("abort", () => {
    void close();
  }, { once: true });
  if (signal.aborted) void close();
  const ready = Promise.all([reliable.ready, live.ready]).then(() => void 0);
  void ready.catch(() => void 0);
  return {
    ready,
    signal,
    live,
    get stats() {
      const a = reliable.stats, b = live.stats;
      return {
        sentBytes: a.sentBytes + b.sentBytes,
        receivedBytes: a.receivedBytes + b.receivedBytes,
        sentPackets: a.sentPackets + b.sentPackets,
        receivedPackets: a.receivedPackets + b.receivedPackets,
        queuedSendBytes: a.queuedSendBytes + b.queuedSendBytes,
        queuedReceiveBytes: a.queuedReceiveBytes + b.queuedReceiveBytes,
        queuedReceiveFrames: a.queuedReceiveFrames + b.queuedReceiveFrames
      };
    },
    send: (bytes, sendOptions) => reliable.send(bytes, sendOptions),
    frames: (input) => reliable.frames(input),
    close
  };
}
function frameMessageChannel(channel, options = {}) {
  const maximum = options.maxFrameBytes ?? PEER_MESSAGE_LIMITS.frameBytes;
  const windowBytes = options.queueBytes ?? PEER_MESSAGE_LIMITS.queueBytes;
  const windowFrames = options.queueFrames ?? PEER_MESSAGE_LIMITS.queueFrames;
  const timeoutMs = options.sendTimeoutMs ?? 3e4;
  const helloTimeoutMs = options.helloTimeoutMs ?? 1e4;
  if (![maximum, windowBytes, windowFrames, timeoutMs, helloTimeoutMs].every(Number.isSafeInteger) || maximum < 1 || maximum > PEER_MESSAGE_LIMITS.frameBytes || windowBytes < maximum || windowBytes > PEER_MESSAGE_LIMITS.queueBytes || windowFrames < 1 || windowFrames > PEER_MESSAGE_LIMITS.queueFrames || timeoutMs < 1 || timeoutMs > 12e4 || helloTimeoutMs < 1 || helloTimeoutMs > 12e4) throw new Error("PEER_MESSAGE_BOUNDS_INVALID");
  channel.binaryType = "arraybuffer";
  channel.bufferedAmountLowThreshold = PEER_MESSAGE_LIMITS.bufferedBytes / 2;
  let closed = false, failure = null, opened = false, greeted = false, reading = false;
  let remoteMaximum = 0, remoteWindow = 0, remoteFrames = 0, creditBytes = 0, creditFrames = 0;
  let queuedSendBytes = 0, queuedSendFrames = 0, reservedBytes = 0, reservedFrames = 0;
  let assembling = null, received = 0;
  let sentBytes = 0, receivedBytes = 0, sentPackets = 0, receivedPackets = 0;
  const lifetime = new AbortController();
  const queue = [], waiters = /* @__PURE__ */ new Set();
  let tail = Promise.resolve();
  let helloTimer;
  let resolveReady, rejectReady;
  const ready = new Promise((resolve, reject) => {
    resolveReady = resolve;
    rejectReady = reject;
  });
  void ready.catch(() => void 0);
  const wake = () => {
    for (const resolve of waiters) resolve();
    waiters.clear();
  };
  const wait = () => new Promise((resolve) => {
    waiters.add(resolve);
  });
  const assertOpen = () => {
    if (closed) throw failure ?? new Error("PEER_MESSAGE_CONNECTION_CLOSED");
  };
  const listeners = [];
  const stop = (error) => {
    if (closed) return;
    closed = true;
    failure = error ?? null;
    clearTimeout(helloTimer);
    rejectReady(error ?? new Error("PEER_MESSAGE_CONNECTION_CLOSED"));
    for (const [type, listener] of listeners) channel.removeEventListener(type, listener);
    queue.length = 0;
    assembling = null;
    reservedBytes = 0;
    reservedFrames = 0;
    lifetime.abort(error ?? new Error("PEER_MESSAGE_CONNECTION_CLOSED"));
    channel.close();
    wake();
  };
  const fail = (error) => stop(error instanceof Error ? error : new Error(String(error)));
  const packet = (kind, a, b, c = 0, payload) => {
    assertOpen();
    const bytes = new Uint8Array(HEADER + (payload?.length ?? 0)), fields = new DataView(bytes.buffer);
    bytes.set([67, 82, 1, kind]);
    fields.setUint32(4, a);
    fields.setUint32(8, b);
    fields.setUint32(12, c);
    if (payload !== void 0) bytes.set(payload, HEADER);
    channel.send(bytes.buffer);
    sentPackets += 1;
  };
  const open = () => {
    if (opened || closed) return;
    try {
      packet(HELLO, maximum, windowBytes, windowFrames);
      opened = true;
      if (greeted) resolveReady();
      else helloTimer = setTimeout(() => fail(new Error("PEER_MESSAGE_HELLO_TIMEOUT")), helloTimeoutMs);
    } catch (error) {
      fail(error);
    }
  };
  const on = (type, listener) => {
    listeners.push([type, listener]);
    channel.addEventListener(type, listener);
  };
  on("open", open);
  on("bufferedamountlow", wake);
  on("close", () => fail(new Error(assembling === null ? "PEER_MESSAGE_CONNECTION_ENDED" : "PEER_MESSAGE_FRAME_TRUNCATED")));
  on("error", () => fail(new Error("PEER_MESSAGE_CHANNEL_ERROR")));
  on("message", (event) => {
    if (closed) return;
    try {
      const value = event.data;
      if (!(value instanceof ArrayBuffer) || value.byteLength < HEADER || value.byteLength > PEER_MESSAGE_LIMITS.packetBytes) throw new Error("PEER_MESSAGE_PACKET_INVALID");
      const bytes = new Uint8Array(value), fields = new DataView(value), kind = bytes[3];
      if (bytes[0] !== 67 || bytes[1] !== 82 || bytes[2] !== 1) throw new Error("PEER_MESSAGE_PROTOCOL_INVALID");
      const a = fields.getUint32(4), b = fields.getUint32(8), c = fields.getUint32(12);
      receivedPackets += 1;
      if (kind === HELLO) {
        if (greeted || bytes.length !== HEADER || a < 1 || a > PEER_MESSAGE_LIMITS.frameBytes || b < a || b > PEER_MESSAGE_LIMITS.queueBytes || c < 1 || c > PEER_MESSAGE_LIMITS.queueFrames) throw new Error("PEER_MESSAGE_HELLO_INVALID");
        greeted = true;
        remoteMaximum = a;
        remoteWindow = b;
        remoteFrames = c;
        creditBytes = b;
        creditFrames = c;
        if (opened) {
          clearTimeout(helloTimer);
          resolveReady();
        }
        wake();
        return;
      }
      if (!greeted) throw new Error("PEER_MESSAGE_HELLO_REQUIRED");
      if (kind === CREDIT) {
        if (bytes.length !== HEADER || a < 1 || b !== 1 || c !== 0 || creditBytes + a > remoteWindow || creditFrames + 1 > remoteFrames) {
          throw new Error("PEER_MESSAGE_CREDIT_INVALID");
        }
        creditBytes += a;
        creditFrames += 1;
        wake();
        return;
      }
      const length = bytes.length - HEADER;
      if (kind !== DATA || c !== 0 || a < 1 || a > maximum || b !== received || length < 1 || length > a - b || assembling !== null && assembling.length !== a) throw new Error("PEER_MESSAGE_FRAGMENT_INVALID");
      if (assembling === null) {
        if (reservedBytes + a > windowBytes || reservedFrames + 1 > windowFrames) throw new Error("PEER_MESSAGE_RECEIVE_CREDIT_EXCEEDED");
        assembling = new Uint8Array(a);
        reservedBytes += a;
        reservedFrames += 1;
      }
      assembling.set(bytes.subarray(HEADER), b);
      received += length;
      receivedBytes += length;
      if (received === a) {
        queue.push(assembling);
        assembling = null;
        received = 0;
        wake();
      }
    } catch (error) {
      fail(error);
    }
  });
  if (channel.readyState === "open") queueMicrotask(open);
  else if (channel.readyState !== "connecting") stop(new Error("PEER_MESSAGE_CONNECTION_CLOSED"));
  return {
    ready,
    signal: lifetime.signal,
    get stats() {
      return {
        sentBytes,
        receivedBytes,
        sentPackets,
        receivedPackets,
        queuedSendBytes,
        queuedReceiveBytes: reservedBytes,
        queuedReceiveFrames: reservedFrames
      };
    },
    send(input, sendOptions = {}) {
      if (closed) return Promise.reject(failure ?? new Error("PEER_MESSAGE_CONNECTION_CLOSED"));
      if (sendOptions.signal?.aborted === true) return Promise.reject(sendOptions.signal.reason);
      if (!(input instanceof Uint8Array) || input.length < 1 || input.length > maximum) return Promise.reject(new Error("PEER_MESSAGE_FRAME_TOO_LARGE"));
      if (queuedSendBytes + input.length > windowBytes || queuedSendFrames + 1 > windowFrames) return Promise.reject(new Error("PEER_MESSAGE_SEND_BACKPRESSURE"));
      const bytes = input.slice();
      queuedSendBytes += bytes.length;
      queuedSendFrames += 1;
      const task = tail.then(async () => {
        let dispatched = false;
        const assertSending = () => {
          assertOpen();
          sendOptions.signal?.throwIfAborted();
        };
        const cancelled = () => {
          wake();
        };
        sendOptions.signal?.addEventListener("abort", cancelled, { once: true });
        const timeout = setTimeout(() => fail(new Error("PEER_MESSAGE_SEND_TIMEOUT")), timeoutMs);
        try {
          await ready;
          assertSending();
          if (bytes.length > remoteMaximum) throw new Error("PEER_MESSAGE_REMOTE_FRAME_TOO_LARGE");
          while (creditBytes < bytes.length || creditFrames === 0) {
            assertSending();
            await wait();
          }
          assertSending();
          for (let offset = 0; offset < bytes.length; offset += PEER_MESSAGE_LIMITS.packetBytes - HEADER) {
            while (channel.bufferedAmount > PEER_MESSAGE_LIMITS.bufferedBytes - PEER_MESSAGE_LIMITS.packetBytes) {
              assertSending();
              await wait();
            }
            assertSending();
            if (!dispatched) {
              creditBytes -= bytes.length;
              creditFrames -= 1;
              dispatched = true;
            }
            const part = bytes.subarray(offset, offset + PEER_MESSAGE_LIMITS.packetBytes - HEADER);
            packet(DATA, bytes.length, offset, 0, part);
            sentBytes += part.length;
          }
        } catch (error) {
          if (dispatched || sendOptions.signal?.aborted !== true || error !== sendOptions.signal.reason) fail(error);
          throw error;
        } finally {
          clearTimeout(timeout);
          sendOptions.signal?.removeEventListener("abort", cancelled);
        }
      }).finally(() => {
        queuedSendBytes -= bytes.length;
        queuedSendFrames -= 1;
      });
      tail = task.catch(() => void 0);
      return task;
    },
    async *frames(signal) {
      if (reading) throw new Error("PEER_MESSAGE_READER_EXISTS");
      reading = true;
      const abort = () => stop();
      signal?.addEventListener("abort", abort, { once: true });
      try {
        if (signal?.aborted === true) return;
        await ready;
        for (; ; ) {
          if (failure !== null) throw failure;
          if (closed) return;
          const frame = queue.shift();
          if (frame === void 0) {
            await wait();
            continue;
          }
          yield frame;
          if (!closed) {
            reservedBytes -= frame.length;
            reservedFrames -= 1;
            packet(CREDIT, frame.length, 1);
          }
        }
      } finally {
        signal?.removeEventListener("abort", abort);
        stop();
      }
    },
    async close() {
      stop();
      await tail;
    }
  };
}

export {
  MemoryBytesStore,
  writeBytesMany,
  encodeCasNode,
  decodeCasNode,
  hashCasNode,
  computeCasHash,
  ContentAddressedStore,
  casRef,
  parseCasRef,
  tryParseCasRef,
  normalizePosixPath,
  resolvePackageRelativePath,
  computeBlobDagHash,
  putBlobDag,
  statBlobDag,
  readBlobDag,
  readBlobDagSync,
  encodeEncBlobManifest,
  encodePackageNode,
  tryDecodePackageNode,
  decodePackageNode,
  putPackageDag,
  encodeTreeNode,
  decodeTreeNode,
  putTreeDag,
  encodeDerivationNode,
  decodeDerivationNode,
  putDerivationNode,
  PEER_LIVE_MESSAGE_LIMITS,
  PEER_MESSAGE_LIMITS,
  framePeerMessageChannels
};
