import {
  awaitOwnedTask
} from "./chunk-KSC4KBWO.mjs";
import {
  applicationDescriptionDigest,
  checkedApplicationInputSchema,
  parseApplicationInput,
  validateApplicationDescription
} from "./chunk-N3WKGBTA.mjs";
import {
  normalizeJsonValue
} from "./chunk-3ELOKYCD.mjs";

// packages/peer-session/src/definition.ts
function defineCommand(options) {
  const input = checkedApplicationInputSchema(options.input);
  if (typeof options.description !== "string" || options.description.length > 4096 || typeof options.prepare !== "function") {
    throw new Error("APPLICATION_COMMAND_INVALID");
  }
  return Object.freeze({
    description: options.description,
    input,
    prepare(value) {
      const validated = parseApplicationInput(input, value);
      const prepared = options.prepare(validated);
      const list = Array.isArray(prepared) ? prepared : [prepared];
      return list.map((update) => ({
        topic: update.topic,
        input: normalizeJsonValue(update.input)
      }));
    }
  });
}
function defineQuery(options) {
  const input = checkedApplicationInputSchema(options.input);
  if (typeof options.description !== "string" || options.description.length > 4096 || typeof options.read !== "function") {
    throw new Error("APPLICATION_QUERY_INVALID");
  }
  return Object.freeze({
    description: options.description,
    input,
    read(view, value) {
      return options.read(view, parseApplicationInput(input, value));
    }
  });
}
function defineApplication(definition) {
  for (const value of [definition.id, definition.version]) {
    if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$/u.test(value)) throw new Error("APPLICATION_DEFINITION_ID_INVALID");
  }
  for (const entries of [definition.commands, definition.queries]) {
    const names = Object.keys(entries);
    if (names.length > 128) throw new Error("APPLICATION_DEFINITION_TOO_LARGE");
    for (const name of names) {
      if (!/^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(name) || ["__proto__", "constructor", "prototype"].includes(name)) {
        throw new Error("APPLICATION_DEFINITION_NAME_INVALID");
      }
      checkedApplicationInputSchema(entries[name].input);
    }
  }
  return Object.freeze({ ...definition, commands: Object.freeze({ ...definition.commands }), queries: Object.freeze({ ...definition.queries }) });
}
function describeApplication(definition) {
  const describe = (entries) => Object.keys(entries).sort().map((name) => ({ name, description: entries[name].description, input: entries[name].input }));
  return validateApplicationDescription({ id: definition.id, version: definition.version, commands: describe(definition.commands), queries: describe(definition.queries) });
}
async function applicationDefinitionDigest(definition) {
  return applicationDescriptionDigest(describeApplication(definition));
}

// packages/peer-session/src/content-bytes.ts
var CONTENT_CHUNK_BYTES = 65536;
var MAX_CONTENT_BYTES = 128 * 1024 * 1024;
var MAX_BLOB_BYTES = 16 * 1024 * 1024;
var MAX_BLOB_CHUNKS = MAX_BLOB_BYTES / CONTENT_CHUNK_BYTES;
function isPublicBlobReference(value) {
  return value !== null && typeof value === "object" && value.profile === "chronolog-blob-v2" && value.visibility === "public";
}
function isPrivateContentReference(value) {
  return value !== null && typeof value === "object" && value.profile === "authored-content-v1";
}
async function putContentBytes(content, bytes, options = {}) {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength > MAX_CONTENT_BYTES) throw new Error("CONTENT_RANGE_INVALID");
  const signal = options.signal ?? new AbortController().signal;
  signal.throwIfAborted();
  const staging = content.stage({ bytes: bytes.byteLength, ...options.mediaType === void 0 ? {} : { mediaType: options.mediaType } });
  let upload;
  try {
    upload = await awaitOwnedTask(signal, () => staging);
    for (let offset = 0; offset < bytes.byteLength; offset += CONTENT_CHUNK_BYTES) {
      signal.throwIfAborted();
      const chunk = Uint8Array.from(bytes.subarray(offset, offset + CONTENT_CHUNK_BYTES));
      await awaitOwnedTask(signal, () => upload.write(offset / CONTENT_CHUNK_BYTES, chunk));
    }
    const reference = await awaitOwnedTask(signal, () => upload.commit());
    signal.throwIfAborted();
    return reference;
  } catch (error) {
    void staging.then((value) => value.discard()).catch(() => void 0);
    throw error;
  }
}
async function readContentBytes(content, reference, options) {
  if (!Number.isSafeInteger(options?.maxBytes) || options.maxBytes < 0 || options.maxBytes > MAX_CONTENT_BYTES) throw new Error("CONTENT_READ_LIMIT_INVALID");
  if (reference === null || typeof reference !== "object" || !Number.isSafeInteger(reference.bytes) || reference.bytes < 0 || reference.bytes > MAX_CONTENT_BYTES) throw new Error("CONTENT_REFERENCE_INVALID");
  if (reference.bytes > options.maxBytes) throw new Error("CONTENT_READ_LIMIT_EXCEEDED");
  options.signal?.throwIfAborted();
  const result = new Uint8Array(reference.bytes);
  const signal = options.signal ?? new AbortController().signal;
  const iterator = content.read({ ...reference }, { signal })[Symbol.asyncIterator]();
  let offset = 0, chunks = 0;
  try {
    for (; ; ) {
      const next = await awaitOwnedTask(signal, () => iterator.next());
      if (next.done) break;
      const chunk = next.value;
      signal.throwIfAborted();
      if (!(chunk instanceof Uint8Array) || chunk.byteLength === 0 || chunk.byteLength > CONTENT_CHUNK_BYTES || ++chunks > MAX_CONTENT_BYTES / CONTENT_CHUNK_BYTES || offset + chunk.byteLength > result.byteLength) throw new Error("CONTENT_CHUNK_SIZE_INVALID");
      result.set(chunk, offset);
      offset += chunk.byteLength;
    }
    signal.throwIfAborted();
    if (offset !== result.byteLength) throw new Error("CONTENT_INCOMPLETE");
    return result;
  } finally {
    void iterator.return?.().catch(() => void 0);
  }
}

export {
  defineCommand,
  defineQuery,
  defineApplication,
  describeApplication,
  applicationDefinitionDigest,
  CONTENT_CHUNK_BYTES,
  MAX_CONTENT_BYTES,
  MAX_BLOB_BYTES,
  MAX_BLOB_CHUNKS,
  isPublicBlobReference,
  isPrivateContentReference,
  putContentBytes,
  readContentBytes
};
