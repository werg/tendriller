import {
  awaitOwnedTask
} from "./chunk-KSC4KBWO.mjs";
import {
  PEER_LIVE_MESSAGE_LIMITS,
  PEER_MESSAGE_LIMITS,
  framePeerMessageChannels
} from "./chunk-OQYLKC3T.mjs";

// packages/transport-webrtc/src/live.ts
function requireRtcLiveChannel(channel) {
  if (channel.ordered || channel.maxPacketLifeTime !== null || channel.maxRetransmits !== 0)
    throw new Error("WEBRTC_LIVE_CHANNEL_REQUIRED");
}

// packages/transport-webrtc/src/channel.ts
var WEBRTC_LIMITS = Object.freeze({ ...PEER_MESSAGE_LIMITS, sdpBytes: 64 * 1024, gatheringMs: 1e3 });
function requireReliable(channel) {
  if (!channel.ordered || channel.maxPacketLifeTime !== null || channel.maxRetransmits !== null)
    throw new Error("WEBRTC_RELIABLE_ORDERED_REQUIRED");
}
function frameRtcPeerChannels(channels, options = {}) {
  requireReliable(channels.reliable);
  requireRtcLiveChannel(channels.live);
  return framePeerMessageChannels(channels, options);
}

// packages/transport-webrtc/src/renegotiation.ts
var APP_STREAM_PREFIX = "app:";
var MAX_APP_STREAMS = 16;
var MAX_APP_STREAM_LABEL = 128;
var MAX_APP_STREAM_MESSAGE_BYTES = 1024 * 1024;
var MAX_APP_STREAM_QUEUE = 256;
var MAX_ICE_CANDIDATE_BYTES = 2048;
var RENEGOTIATION_TIMEOUT_MS = 5e3;
var ICE_RESTART_DEBOUNCE_MS = 2e3;
var utf8Bytes = (value) => new TextEncoder().encode(value).length;
function validatePeerDescription(value, expectedType) {
  if (typeof value !== "object" || value === null || !("type" in value) || !("sdp" in value)) {
    throw new Error("WEBRTC_DESCRIPTION_INVALID");
  }
  const type = value.type;
  const sdp = value.sdp;
  if (type !== "offer" && type !== "answer" || expectedType !== void 0 && type !== expectedType || typeof sdp !== "string" || sdp.length < 1 || utf8Bytes(sdp) > WEBRTC_LIMITS.sdpBytes) {
    throw new Error("WEBRTC_DESCRIPTION_INVALID");
  }
  return { type, sdp };
}
function validatePeerIceCandidate(value) {
  if (value === null) return null;
  if (typeof value !== "object" || Array.isArray(value)) throw new Error("WEBRTC_CANDIDATE_INVALID");
  const record = value;
  if (typeof record.candidate !== "string" || utf8Bytes(record.candidate) > MAX_ICE_CANDIDATE_BYTES) {
    throw new Error("WEBRTC_CANDIDATE_INVALID");
  }
  const sdpMid = record.sdpMid === void 0 || record.sdpMid === null ? null : typeof record.sdpMid === "string" && record.sdpMid.length <= 128 ? record.sdpMid : void 0;
  if (sdpMid === void 0) throw new Error("WEBRTC_CANDIDATE_INVALID");
  const sdpMLineIndex = record.sdpMLineIndex === void 0 || record.sdpMLineIndex === null ? null : typeof record.sdpMLineIndex === "number" && Number.isSafeInteger(record.sdpMLineIndex) && record.sdpMLineIndex >= 0 && record.sdpMLineIndex <= 1024 ? record.sdpMLineIndex : void 0;
  if (sdpMLineIndex === void 0) throw new Error("WEBRTC_CANDIDATE_INVALID");
  const usernameFragment = record.usernameFragment === void 0 || record.usernameFragment === null ? null : typeof record.usernameFragment === "string" && record.usernameFragment.length <= 256 ? record.usernameFragment : void 0;
  if (usernameFragment === void 0) throw new Error("WEBRTC_CANDIDATE_INVALID");
  return {
    candidate: record.candidate,
    ...sdpMid !== null ? { sdpMid } : {},
    ...sdpMLineIndex !== null ? { sdpMLineIndex } : {},
    ...usernameFragment !== null ? { usernameFragment } : {}
  };
}
function validateRtcSignalMessage(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) throw new Error("WEBRTC_SIGNAL_INVALID");
  const record = value;
  if (record.kind === "description") {
    return { kind: "description", description: validatePeerDescription(record.description) };
  }
  if (record.kind === "candidate") {
    return { kind: "candidate", candidate: validatePeerIceCandidate(record.candidate) };
  }
  throw new Error("WEBRTC_SIGNAL_INVALID");
}
function serializeIceCandidate(candidate) {
  if (candidate === null || candidate === void 0) return null;
  const raw = candidate;
  const source = typeof raw.toJSON === "function" ? raw.toJSON() : raw;
  if (typeof source.candidate !== "string") return null;
  return validatePeerIceCandidate({
    candidate: source.candidate,
    sdpMid: source.sdpMid ?? null,
    sdpMLineIndex: source.sdpMLineIndex ?? null,
    usernameFragment: source.usernameFragment ?? null
  });
}
function validStreamLabel(label) {
  if (typeof label !== "string" || !label.length || label.length > MAX_APP_STREAM_LABEL || !/^[A-Za-z0-9_.:/-]{1,128}$/u.test(label)) {
    throw new Error("WEBRTC_STREAM_LABEL_INVALID");
  }
  return label;
}
function wrapDataStream(channel, label, parentSignal, onClose) {
  try {
    channel.binaryType = "arraybuffer";
  } catch {
  }
  const controller = new AbortController();
  const signal = AbortSignal.any([controller.signal, parentSignal]);
  const queue = [];
  let wake;
  let reading = false;
  let closed = false;
  const finish = () => {
    if (closed) return;
    closed = true;
    controller.abort(new Error("WEBRTC_STREAM_CLOSED"));
    channel.removeEventListener("message", onMessage);
    channel.removeEventListener("close", onChannelClose);
    channel.removeEventListener("error", onChannelClose);
    parentSignal.removeEventListener("abort", onParentAbort);
    wake?.();
    wake = void 0;
    onClose();
  };
  const onParentAbort = () => {
    try {
      channel.close();
    } catch {
    }
    finish();
  };
  const onChannelClose = () => {
    finish();
  };
  const onMessage = (event) => {
    if (closed) return;
    const data = event.data;
    let item;
    if (typeof data === "string") {
      if (utf8Bytes(data) > MAX_APP_STREAM_MESSAGE_BYTES) return;
      item = data;
    } else if (data instanceof ArrayBuffer) {
      if (data.byteLength > MAX_APP_STREAM_MESSAGE_BYTES) return;
      item = new Uint8Array(data);
    } else if (ArrayBuffer.isView(data)) {
      if (data.byteLength > MAX_APP_STREAM_MESSAGE_BYTES) return;
      item = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    } else {
      return;
    }
    if (queue.length >= MAX_APP_STREAM_QUEUE) {
      if (!channel.ordered) queue.shift();
      else return;
    }
    queue.push(item);
    wake?.();
    wake = void 0;
  };
  channel.addEventListener("message", onMessage);
  channel.addEventListener("close", onChannelClose);
  channel.addEventListener("error", onChannelClose);
  parentSignal.addEventListener("abort", onParentAbort, { once: true });
  if (parentSignal.aborted || channel.readyState === "closed") onParentAbort();
  return {
    label,
    ordered: channel.ordered,
    get readyState() {
      return closed ? "closed" : channel.readyState;
    },
    get bufferedAmount() {
      return channel.bufferedAmount;
    },
    signal,
    send(data) {
      if (closed || channel.readyState !== "open") throw new Error("WEBRTC_STREAM_NOT_OPEN");
      if (typeof data === "string") {
        if (utf8Bytes(data) > MAX_APP_STREAM_MESSAGE_BYTES) throw new Error("WEBRTC_STREAM_MESSAGE_TOO_LARGE");
        channel.send(data);
      } else if (data instanceof Uint8Array) {
        if (data.byteLength > MAX_APP_STREAM_MESSAGE_BYTES) throw new Error("WEBRTC_STREAM_MESSAGE_TOO_LARGE");
        const copy = data.byteOffset === 0 && data.byteLength === data.buffer.byteLength && data.buffer instanceof ArrayBuffer ? data.buffer : data.slice().buffer;
        channel.send(copy);
      } else {
        throw new Error("WEBRTC_STREAM_PAYLOAD_INVALID");
      }
    },
    messages(readSignal) {
      return {
        async *[Symbol.asyncIterator]() {
          if (reading) throw new Error("WEBRTC_STREAM_READER_ACTIVE");
          reading = true;
          const combined = readSignal ? AbortSignal.any([signal, readSignal]) : signal;
          const onAbort = () => {
            wake?.();
            wake = void 0;
          };
          combined.addEventListener("abort", onAbort, { once: true });
          try {
            while (true) {
              if (queue.length > 0) {
                yield queue.shift();
                continue;
              }
              if (closed || combined.aborted) return;
              await new Promise((resolve) => {
                wake = resolve;
              });
            }
          } finally {
            combined.removeEventListener("abort", onAbort);
            reading = false;
          }
        }
      };
    },
    close() {
      try {
        channel.close();
      } catch {
      }
      finish();
    }
  };
}
function withTimeout(operation, ms, signal, code) {
  if (signal.aborted) {
    void operation.catch(() => void 0);
    return Promise.reject(signal.reason);
  }
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      cleanup();
      reject(new Error(code));
    }, ms);
    const onAbort = () => {
      cleanup();
      reject(signal.reason);
    };
    const cleanup = () => {
      clearTimeout(timer);
      signal.removeEventListener("abort", onAbort);
    };
    signal.addEventListener("abort", onAbort, { once: true });
    void operation.then((value) => {
      cleanup();
      resolve(value);
    }, (error) => {
      cleanup();
      reject(error);
    });
  });
}
function createPeerMediaAndStreams(connection, sessionSignal, options) {
  const activeStreams = /* @__PURE__ */ new Set();
  const streamListeners = /* @__PURE__ */ new Set();
  const trackListeners = /* @__PURE__ */ new Set();
  const activeTracks = /* @__PURE__ */ new Map();
  let inBand = null;
  let makingOffer = false;
  let ignoreOffer = false;
  let isSettingRemoteAnswerPending = false;
  let pendingCandidates = [];
  let negotiateTail = Promise.resolve();
  let restartTimer;
  let lastRestartAt = 0;
  let closed = false;
  const supportsMedia = typeof connection.addTrack === "function" && typeof connection.addTransceiver === "function";
  const reportError = (error) => {
    if (closed || sessionSignal.aborted) return;
    try {
      inBand?.onError?.(error);
    } catch {
    }
  };
  const runOffer = async (iceRestart = false) => {
    if (!inBand || closed || sessionSignal.aborted) return;
    makingOffer = true;
    let local;
    try {
      const offer = await withTimeout(
        connection.createOffer(iceRestart ? { iceRestart: true } : void 0),
        RENEGOTIATION_TIMEOUT_MS,
        sessionSignal,
        "WEBRTC_RENEGOTIATION_TIMEOUT"
      );
      if (closed || sessionSignal.aborted || !inBand) return;
      if (connection.signalingState !== void 0 && connection.signalingState !== "stable") return;
      await withTimeout(connection.setLocalDescription(offer), RENEGOTIATION_TIMEOUT_MS, sessionSignal, "WEBRTC_RENEGOTIATION_TIMEOUT");
      local = validatePeerDescription(connection.localDescription, "offer");
    } catch (error) {
      if (!closed && connection.signalingState === "have-local-offer") {
        try {
          await connection.setLocalDescription({ type: "rollback" });
        } catch {
        }
      }
      reportError(error);
      return;
    } finally {
      makingOffer = false;
    }
    if (local !== void 0 && inBand && !closed && !sessionSignal.aborted) {
      void withTimeout(inBand.send({ kind: "description", description: local }), RENEGOTIATION_TIMEOUT_MS, sessionSignal, "WEBRTC_RENEGOTIATION_TIMEOUT").catch(reportError);
    }
  };
  const enqueueOffer = (iceRestart = false) => {
    negotiateTail = negotiateTail.then(() => runOffer(iceRestart)).catch(reportError);
    return negotiateTail;
  };
  const flushPendingCandidates = async () => {
    if (typeof connection.addIceCandidate !== "function" || !pendingCandidates.length) return;
    const batch = pendingCandidates.splice(0);
    for (const candidate of batch) {
      if (closed || sessionSignal.aborted) return;
      try {
        await connection.addIceCandidate(candidate);
      } catch (error) {
        if (!ignoreOffer) reportError(error);
      }
    }
  };
  const handleIncomingSignal = async (raw) => {
    if (!inBand || closed || sessionSignal.aborted) return;
    const message2 = validateRtcSignalMessage(raw);
    if (message2.kind === "candidate") {
      if (typeof connection.addIceCandidate !== "function") return;
      if (connection.signalingState === "closed") return;
      try {
        await connection.addIceCandidate(message2.candidate);
      } catch (error) {
        if (!ignoreOffer) {
          if (pendingCandidates.length < 64) pendingCandidates.push(message2.candidate);
          else reportError(error);
        }
      }
      return;
    }
    const { description: description2 } = message2;
    const readyForOffer = !makingOffer && (connection.signalingState === void 0 || connection.signalingState === "stable" || isSettingRemoteAnswerPending);
    const offerCollision = description2.type === "offer" && !readyForOffer;
    ignoreOffer = !inBand.polite && offerCollision;
    if (ignoreOffer) return;
    isSettingRemoteAnswerPending = description2.type === "answer";
    try {
      if (offerCollision && inBand.polite && connection.signalingState === "have-local-offer") {
        try {
          await connection.setLocalDescription({ type: "rollback" });
        } catch {
        }
      }
      await withTimeout(connection.setRemoteDescription(description2), RENEGOTIATION_TIMEOUT_MS, sessionSignal, "WEBRTC_RENEGOTIATION_TIMEOUT");
      await flushPendingCandidates();
      if (description2.type === "offer") {
        const answer = await withTimeout(connection.createAnswer(), RENEGOTIATION_TIMEOUT_MS, sessionSignal, "WEBRTC_RENEGOTIATION_TIMEOUT");
        await withTimeout(connection.setLocalDescription(answer), RENEGOTIATION_TIMEOUT_MS, sessionSignal, "WEBRTC_RENEGOTIATION_TIMEOUT");
        const local = validatePeerDescription(connection.localDescription, "answer");
        await withTimeout(inBand.send({ kind: "description", description: local }), RENEGOTIATION_TIMEOUT_MS, sessionSignal, "WEBRTC_RENEGOTIATION_TIMEOUT");
      }
    } catch (error) {
      reportError(error);
    } finally {
      isSettingRemoteAnswerPending = false;
    }
  };
  const onNegotiationNeeded = () => {
    if (!inBand || closed || sessionSignal.aborted) return;
    void enqueueOffer(false);
  };
  const onIceCandidate = (event) => {
    if (!inBand || closed || sessionSignal.aborted) return;
    const raw = event.candidate;
    let candidate;
    try {
      candidate = serializeIceCandidate(raw);
    } catch {
      return;
    }
    void inBand.send({ kind: "candidate", candidate }).catch(reportError);
  };
  const onIceConnectionStateChange = () => {
    if (!inBand || closed || sessionSignal.aborted) return;
    const state = connection.iceConnectionState;
    if (state === "connected" || state === "completed") {
      if (restartTimer !== void 0) {
        clearTimeout(restartTimer);
        restartTimer = void 0;
      }
      return;
    }
    if (state === "disconnected" && restartTimer === void 0) {
      restartTimer = setTimeout(() => {
        restartTimer = void 0;
        if (!inBand || closed || sessionSignal.aborted || connection.iceConnectionState !== "disconnected") return;
        if (Date.now() - lastRestartAt < ICE_RESTART_DEBOUNCE_MS) return;
        lastRestartAt = Date.now();
        try {
          connection.restartIce?.();
        } catch {
        }
        void enqueueOffer(true);
      }, ICE_RESTART_DEBOUNCE_MS);
      if (typeof restartTimer === "object" && "unref" in restartTimer) restartTimer.unref();
    }
  };
  const onDataChannel = (event) => {
    const channel = event.channel;
    if (!channel) return;
    if (!inBand) {
      options.onUnexpectedPreAuthChannel(channel);
      return;
    }
    if (closed || !channel.label.startsWith(APP_STREAM_PREFIX) || activeStreams.size >= MAX_APP_STREAMS) {
      try {
        channel.close();
      } catch {
      }
      return;
    }
    const stripped = channel.label.slice(APP_STREAM_PREFIX.length);
    try {
      validStreamLabel(stripped);
    } catch {
      try {
        channel.close();
      } catch {
      }
      return;
    }
    const stream = wrapDataStream(channel, stripped, sessionSignal, () => {
      activeStreams.delete(stream);
    });
    activeStreams.add(stream);
    for (const listener of streamListeners) {
      try {
        listener(stream);
      } catch {
      }
    }
  };
  const onTrack = (event) => {
    if (closed || sessionSignal.aborted) return;
    const raw = event;
    if (!raw.track) return;
    const trackEvent = Object.freeze({
      track: raw.track,
      streams: Object.freeze(Array.isArray(raw.streams) ? [...raw.streams] : []),
      ...raw.transceiver !== void 0 ? { transceiver: raw.transceiver } : {}
    });
    activeTracks.set(raw.track, trackEvent);
    const maybeTrack = raw.track;
    maybeTrack.addEventListener?.("ended", () => {
      activeTracks.delete(raw.track);
    }, { once: true });
    if (!inBand) return;
    for (const listener of trackListeners) {
      try {
        listener(trackEvent);
      } catch {
      }
    }
  };
  connection.addEventListener("datachannel", onDataChannel);
  connection.addEventListener("track", onTrack);
  connection.addEventListener("negotiationneeded", onNegotiationNeeded);
  connection.addEventListener("icecandidate", onIceCandidate);
  connection.addEventListener("iceconnectionstatechange", onIceConnectionStateChange);
  const close = () => {
    if (closed) return;
    closed = true;
    inBand = null;
    if (restartTimer !== void 0) {
      clearTimeout(restartTimer);
      restartTimer = void 0;
    }
    connection.removeEventListener("datachannel", onDataChannel);
    connection.removeEventListener("track", onTrack);
    connection.removeEventListener("negotiationneeded", onNegotiationNeeded);
    connection.removeEventListener("icecandidate", onIceCandidate);
    connection.removeEventListener("iceconnectionstatechange", onIceConnectionStateChange);
    for (const stream of [...activeStreams]) stream.close();
    activeStreams.clear();
    activeTracks.clear();
    streamListeners.clear();
    trackListeners.clear();
    pendingCandidates = [];
  };
  sessionSignal.addEventListener("abort", close, { once: true });
  const media = {
    get available() {
      return !closed && !sessionSignal.aborted && supportsMedia;
    },
    get unavailableReason() {
      if (closed || sessionSignal.aborted) return "closed";
      return supportsMedia ? void 0 : "unsupported";
    },
    addTrack(track, ...streams2) {
      if (!this.available || !inBand) throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
      return connection.addTrack(track, ...streams2);
    },
    removeTrack(sender) {
      if (!this.available || !inBand) throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
      connection.removeTrack(sender);
    },
    addTransceiver(kindOrTrack, init) {
      if (!this.available || !inBand) throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
      return connection.addTransceiver(kindOrTrack, init);
    },
    getTransceivers() {
      return connection.getTransceivers?.() ?? [];
    },
    onTrack(listener) {
      trackListeners.add(listener);
      if (inBand) {
        for (const existing of activeTracks.values()) {
          try {
            listener(existing);
          } catch {
          }
        }
      }
      return () => {
        trackListeners.delete(listener);
      };
    },
    async restartIce() {
      if (closed || sessionSignal.aborted || !inBand) throw new Error("WEBRTC_MEDIA_UNAVAILABLE");
      lastRestartAt = Date.now();
      try {
        connection.restartIce?.();
      } catch {
      }
      await enqueueOffer(true);
    }
  };
  const streams = {
    get available() {
      return !closed && !sessionSignal.aborted;
    },
    get unavailableReason() {
      return closed || sessionSignal.aborted ? "closed" : void 0;
    },
    open(label, streamOptions = {}) {
      if (closed || sessionSignal.aborted || !inBand) throw new Error("WEBRTC_STREAMS_UNAVAILABLE");
      if (activeStreams.size >= MAX_APP_STREAMS) throw new Error("WEBRTC_STREAM_LIMIT");
      const clean = validStreamLabel(label);
      const ordered = streamOptions.ordered ?? true;
      const channel = connection.createDataChannel(`${APP_STREAM_PREFIX}${clean}`, {
        ordered,
        negotiated: false,
        protocol: "chronolog.app.v1",
        ...streamOptions.maxRetransmits !== void 0 ? { maxRetransmits: streamOptions.maxRetransmits } : {},
        ...streamOptions.maxPacketLifeTime !== void 0 ? { maxPacketLifeTime: streamOptions.maxPacketLifeTime } : {}
      });
      const stream = wrapDataStream(channel, clean, sessionSignal, () => {
        activeStreams.delete(stream);
      });
      activeStreams.add(stream);
      return stream;
    },
    onStream(listener) {
      streamListeners.add(listener);
      return () => {
        streamListeners.delete(listener);
      };
    }
  };
  return {
    media,
    streams,
    attachInBandSignaling(binding) {
      if (closed || sessionSignal.aborted) throw new Error("WEBRTC_CONNECTION_CLOSED");
      if (inBand !== null) throw new Error("WEBRTC_INBAND_ALREADY_ATTACHED");
      inBand = binding;
      for (const existing of activeTracks.values()) {
        for (const listener of trackListeners) {
          try {
            listener(existing);
          } catch {
          }
        }
      }
      return {
        receive(message2) {
          negotiateTail = negotiateTail.then(() => handleIncomingSignal(message2)).catch(reportError);
          return negotiateTail;
        },
        close() {
          if (inBand === binding) inBand = null;
        }
      };
    },
    close
  };
}

// packages/transport-webrtc/src/route.ts
async function observeWebRtcRoute(connection) {
  const unknown = { route: "unknown", localCandidateType: null, remoteCandidateType: null };
  if (connection.connectionState !== "connected" || connection.getStats === void 0) return unknown;
  try {
    const report = await connection.getStats(), stats = /* @__PURE__ */ new Map();
    report.forEach((value) => {
      if (typeof value === "object" && value !== null && "id" in value && typeof value.id === "string") {
        stats.set(value.id, value);
      }
    });
    const selected = [...stats.values()].filter((value) => value.type === "transport" && typeof value.selectedCandidatePairId === "string");
    let pair;
    if (selected.length === 1) pair = stats.get(selected[0].selectedCandidatePairId);
    else if (selected.length === 0) {
      const pairs = [...stats.values()].filter((value) => value.type === "candidate-pair" && value.selected === true);
      if (pairs.length === 1) pair = pairs[0];
    }
    if (connection.connectionState !== "connected" || pair?.type !== "candidate-pair" || pair.state !== "succeeded") return unknown;
    const local = typeof pair.localCandidateId === "string" ? stats.get(pair.localCandidateId) : void 0;
    const remote = typeof pair.remoteCandidateId === "string" ? stats.get(pair.remoteCandidateId) : void 0;
    const localCandidateType = local?.type === "local-candidate" ? candidateType(local.candidateType) : null;
    const remoteCandidateType = remote?.type === "remote-candidate" ? candidateType(remote.candidateType) : null;
    const route2 = localCandidateType === "relay" || remoteCandidateType === "relay" ? "relay" : localCandidateType !== null && remoteCandidateType !== null ? "direct" : "unknown";
    return { route: route2, localCandidateType, remoteCandidateType };
  } catch {
    return unknown;
  }
}
function candidateType(value) {
  return value === "host" || value === "srflx" || value === "prflx" || value === "relay" ? value : null;
}

// packages/transport-webrtc/src/negotiation.ts
var PROTOCOL = "chronolog.peer.v2";
var MAX_INITIAL_TRICKLE_CANDIDATES = 32;
function isDescription(value) {
  return typeof value === "object" && value !== null && "type" in value && "sdp" in value;
}
async function negotiateWebRtc(options) {
  const timeoutMs = options.timeoutMs ?? 3e4;
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 12e4) throw new Error("WEBRTC_TIMEOUT_INVALID");
  const gatheringMs = options.gatheringTimeoutMs ?? Math.min(WEBRTC_LIMITS.gatheringMs, timeoutMs);
  if (!Number.isSafeInteger(gatheringMs) || gatheringMs < 1 || gatheringMs > timeoutMs) throw new Error("WEBRTC_GATHERING_TIMEOUT_INVALID");
  let connection;
  try {
    options.signal?.throwIfAborted();
    const factory = options.createPeerConnection ?? ((configuration) => new RTCPeerConnection(configuration));
    connection = factory(structuredClone(options.configuration ?? {}));
  } catch (error) {
    void Promise.resolve().then(() => options.signaling.close()).catch(() => void 0);
    throw error;
  }
  const controller = new AbortController(), signal = controller.signal;
  const useTrickle = options.trickle !== false && typeof connection.addIceCandidate === "function";
  let negotiationFailed = false;
  let closing, outcome;
  let negotiationError;
  let sentMessages = 0, receivedMessages = 0, sentBytes = 0, receivedBytes = 0;
  let bootstrapActive = true;
  let localDescriptionSent = false;
  let sentCandidates = 0;
  const bufferedLocalCandidates = [];
  let remoteDescriptionSet = false;
  const bufferedRemoteCandidates = [];
  const mediaAndStreams = createPeerMediaAndStreams(connection, signal, {
    onUnexpectedPreAuthChannel(unexpected) {
      try {
        unexpected.close();
      } catch {
      }
      controller.abort(new Error("WEBRTC_CHANNEL_UNEXPECTED"));
      void close().catch(() => void 0);
    }
  });
  const close = () => {
    if (closing !== void 0) return closing;
    bootstrapActive = false;
    controller.abort(new Error("WEBRTC_CONNECTION_CLOSED"));
    options.signal?.removeEventListener("abort", abort);
    connection.removeEventListener("connectionstatechange", failed);
    connection.removeEventListener("icecandidate", onBootstrapCandidate);
    mediaAndStreams.close();
    closing = Promise.resolve().then(() => connection.close());
    return closing;
  };
  const abort = () => {
    controller.abort(options.signal?.reason);
    void close().catch(() => void 0);
  };
  options.signal?.addEventListener("abort", abort, { once: true });
  const failed = () => {
    if (["failed", "closed"].includes(connection.connectionState)) {
      controller.abort(new Error("WEBRTC_CONNECTION_FAILED"));
      void close().catch(() => void 0);
    }
  };
  connection.addEventListener("connectionstatechange", failed);
  const sendLocalCandidate = (candidate) => {
    if (!bootstrapActive || signal.aborted || sentCandidates >= MAX_INITIAL_TRICKLE_CANDIDATES) return;
    sentCandidates += 1;
    sentMessages += 1;
    sentBytes += candidate ? new TextEncoder().encode(candidate.candidate).length : 4;
    void Promise.resolve(options.signaling.send({ kind: "candidate", candidate })).catch(() => void 0);
  };
  const onBootstrapCandidate = (event) => {
    if (!useTrickle || !bootstrapActive || signal.aborted) return;
    const raw = event.candidate;
    let candidate;
    try {
      candidate = serializeIceCandidate(raw);
    } catch {
      return;
    }
    if (!localDescriptionSent) {
      if (bufferedLocalCandidates.length < MAX_INITIAL_TRICKLE_CANDIDATES) bufferedLocalCandidates.push(candidate);
      return;
    }
    sendLocalCandidate(candidate);
  };
  if (useTrickle) connection.addEventListener("icecandidate", onBootstrapCandidate);
  if (options.signal?.aborted === true) abort();
  const timeout = setTimeout(() => controller.abort(new Error("WEBRTC_NEGOTIATION_TIMEOUT")), timeoutMs);
  let messages;
  const applyRemoteCandidate = async (candidate) => {
    if (typeof connection.addIceCandidate !== "function") return;
    if (!remoteDescriptionSet) {
      if (bufferedRemoteCandidates.length < MAX_INITIAL_TRICKLE_CANDIDATES + 4) {
        bufferedRemoteCandidates.push(candidate);
      }
      return;
    }
    try {
      await connection.addIceCandidate(candidate);
    } catch {
    }
  };
  const flushBufferedCandidates = async () => {
    remoteDescriptionSet = true;
    if (typeof connection.addIceCandidate !== "function") return;
    for (const candidate of bufferedRemoteCandidates.splice(0)) {
      if (signal.aborted) return;
      try {
        await connection.addIceCandidate(candidate);
      } catch {
      }
    }
  };
  const receivedDescription = async (type) => {
    while (true) {
      const item = await interruptible(messages.next(), signal);
      if (item.done) throw new Error("WEBRTC_SIGNALING_ENDED");
      const value = item.value;
      if (isDescription(value)) {
        const description2 = validatePeerDescription(value, type);
        receivedMessages += 1;
        receivedBytes += new TextEncoder().encode(description2.sdp).length;
        return description2;
      }
      if (useTrickle && typeof value === "object" && value !== null && "kind" in value && value.kind === "candidate") {
        const candidate = validatePeerIceCandidate(value.candidate);
        receivedMessages += 1;
        receivedBytes += candidate ? new TextEncoder().encode(candidate.candidate).length : 4;
        await applyRemoteCandidate(candidate);
        continue;
      }
      throw new Error("WEBRTC_DESCRIPTION_INVALID");
    }
  };
  const publish = async (type) => {
    if (!useTrickle) {
      const complete = await gatherBatch(connection, gatheringMs, signal);
      const description3 = validatePeerDescription(connection.localDescription, type);
      if (!complete && !usableCandidate(description3.sdp, options.configuration?.iceTransportPolicy)) throw new Error("WEBRTC_ICE_CANDIDATES_UNAVAILABLE");
      await interruptible(options.signaling.send(description3), signal);
      sentMessages += 1;
      sentBytes += new TextEncoder().encode(description3.sdp).length;
      return;
    }
    const description2 = validatePeerDescription(connection.localDescription, type);
    await interruptible(options.signaling.send(description2), signal);
    sentMessages += 1;
    sentBytes += new TextEncoder().encode(description2.sdp).length;
    localDescriptionSent = true;
    for (const candidate of bufferedLocalCandidates.splice(0)) sendLocalCandidate(candidate);
  };
  let trickleDrain;
  try {
    const channels = {
      reliable: connection.createDataChannel("chronolog.reliable", { negotiated: true, id: 0, ordered: true, protocol: PROTOCOL }),
      live: connection.createDataChannel("chronolog.live", { negotiated: true, id: 1, ordered: false, maxRetransmits: 0, protocol: PROTOCOL })
    };
    const returned = options.onDataChannels(channels);
    if (typeof returned === "object" && returned !== null && "then" in returned) {
      void Promise.resolve(returned).catch(() => void 0);
      throw new Error("WEBRTC_CHANNEL_HANDOFF_MUST_BE_SYNCHRONOUS");
    }
    messages = options.signaling.messages[Symbol.asyncIterator]();
    if (options.role === "offerer") {
      await interruptible(connection.setLocalDescription(await interruptible(connection.createOffer(), signal)), signal);
      await publish("offer");
      await interruptible(connection.setRemoteDescription(await receivedDescription("answer")), signal);
      await flushBufferedCandidates();
    } else {
      await interruptible(connection.setRemoteDescription(await receivedDescription("offer")), signal);
      await flushBufferedCandidates();
      await interruptible(connection.setLocalDescription(await interruptible(connection.createAnswer(), signal)), signal);
      await publish("answer");
    }
    if (useTrickle) {
      trickleDrain = (async () => {
        let receivedCandidates = 0;
        while (bootstrapActive && !signal.aborted && receivedCandidates <= MAX_INITIAL_TRICKLE_CANDIDATES + 4) {
          const item = await messages.next();
          if (item.done || !bootstrapActive) break;
          const value = item.value;
          if (typeof value === "object" && value !== null && "kind" in value && value.kind === "candidate") {
            receivedCandidates += 1;
            const candidate = validatePeerIceCandidate(value.candidate);
            receivedMessages += 1;
            receivedBytes += candidate ? new TextEncoder().encode(candidate.candidate).length : 4;
            await applyRemoteCandidate(candidate);
          }
        }
      })().catch(() => void 0);
    }
    await waitFor(connection, "connectionstatechange", () => connection.connectionState === "connected", signal);
    signal.throwIfAborted();
    bootstrapActive = false;
    connection.removeEventListener("icecandidate", onBootstrapCandidate);
    if (useTrickle) {
      void Promise.resolve(options.signaling.send({ kind: "connected" })).catch(() => void 0);
    }
    outcome = {
      connection,
      signal,
      signaling: { sentMessages, receivedMessages, sentBytes, receivedBytes },
      media: mediaAndStreams.media,
      streams: mediaAndStreams.streams,
      attachInBandSignaling: (binding) => mediaAndStreams.attachInBandSignaling(binding),
      getRoute: () => observeWebRtcRoute(connection),
      close
    };
  } catch (error) {
    negotiationFailed = true;
    negotiationError = error;
    await close().catch(() => void 0);
  }
  bootstrapActive = false;
  connection.removeEventListener("icecandidate", onBootstrapCandidate);
  try {
    await interruptible(Promise.resolve().then(() => options.signaling.close()), signal);
  } catch (error) {
    await close().catch(() => void 0);
    if (!negotiationFailed) {
      negotiationFailed = true;
      negotiationError = error;
    }
  }
  clearTimeout(timeout);
  void trickleDrain;
  void Promise.resolve().then(() => messages?.return?.()).catch(() => void 0);
  if (negotiationFailed) throw negotiationError;
  if (outcome === void 0) throw new Error("WEBRTC_NEGOTIATION_INCOMPLETE");
  return outcome;
}
async function openWebRtcConnection(options) {
  const deadline = Date.now() + (options.timeoutMs ?? 3e4);
  let framed;
  const session = await negotiateWebRtc({ ...options, onDataChannels(channels) {
    framed = frameRtcPeerChannels(channels);
  } });
  if (framed === void 0) {
    await session.close();
    throw new Error("WEBRTC_CHANNEL_MISSING");
  }
  const selected = framed;
  const retire = () => {
    void session.close().catch(() => void 0);
  };
  selected.signal.addEventListener("abort", retire, { once: true });
  if (selected.signal.aborted) retire();
  const handshake = new AbortController();
  const timer = setTimeout(() => handshake.abort(new Error("WEBRTC_HANDSHAKE_TIMEOUT")), Math.max(1, deadline - Date.now()));
  try {
    await interruptible(selected.ready, AbortSignal.any([handshake.signal, session.signal]));
  } catch (error) {
    await selected.close();
    await session.close();
    throw error;
  } finally {
    clearTimeout(timer);
  }
  return {
    ready: selected.ready,
    signal: selected.signal,
    session,
    live: selected.live,
    get stats() {
      return selected.stats;
    },
    send: (bytes, sendOptions) => selected.send(bytes, sendOptions),
    frames: (signal) => selected.frames(signal),
    async close() {
      await selected.close();
      await session.close();
    }
  };
}
function interruptible(operation, signal) {
  if (signal.aborted) {
    void operation.catch(() => void 0);
    return Promise.reject(signal.reason);
  }
  return new Promise((resolve, reject) => {
    const abort = () => {
      reject(signal.reason);
    };
    signal.addEventListener("abort", abort, { once: true });
    void operation.then(resolve, reject).finally(() => {
      signal.removeEventListener("abort", abort);
    });
  });
}
function waitFor(connection, event, complete, signal) {
  signal.throwIfAborted();
  if (complete()) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      connection.removeEventListener(event, check);
      signal.removeEventListener("abort", abort);
    };
    const check = () => {
      if (complete()) {
        cleanup();
        resolve();
      }
    };
    const abort = () => {
      cleanup();
      reject(signal.reason);
    };
    connection.addEventListener(event, check);
    signal.addEventListener("abort", abort, { once: true });
    check();
  });
}
function gatherBatch(connection, budgetMs, signal) {
  signal.throwIfAborted();
  if (connection.iceGatheringState === "complete") return Promise.resolve(true);
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      clearTimeout(timer);
      connection.removeEventListener("icegatheringstatechange", check);
      signal.removeEventListener("abort", abort);
    };
    const finish = () => {
      cleanup();
      resolve(connection.iceGatheringState === "complete");
    };
    const check = () => {
      if (connection.iceGatheringState === "complete") finish();
    };
    const abort = () => {
      cleanup();
      reject(signal.reason);
    };
    const timer = setTimeout(finish, budgetMs);
    connection.addEventListener("icegatheringstatechange", check);
    signal.addEventListener("abort", abort, { once: true });
    check();
  });
}
function usableCandidate(sdp, policy) {
  return sdp.split(/\r?\n/u).some((line) => {
    const fields = line.trim().split(/\s+/u), port = Number(fields[5]);
    return fields[0]?.startsWith("a=candidate:") === true && fields[6] === "typ" && ["udp", "tcp"].includes(fields[2]?.toLowerCase() ?? "") && Number.isInteger(port) && port > 0 && port <= 65535 && fields[4] !== void 0 && !["0.0.0.0", "::", "0:0:0:0:0:0:0:0"].includes(fields[4]) && ["host", "srflx", "prflx", "relay"].includes(fields[7] ?? "") && (policy !== "relay" || fields[7] === "relay");
  });
}

// packages/transport-webrtc/src/http.ts
var WEBRTC_HTTP_LIMITS = Object.freeze({ messageBytes: 128 * 1024, pending: 8, connections: 32, timeoutMs: 3e4 });

// packages/peer-session/src/worker-transport-lanes.ts
var bounds = (lane) => lane === "reliable" ? { frame: PEER_MESSAGE_LIMITS.frameBytes, bytes: PEER_MESSAGE_LIMITS.queueBytes, count: PEER_MESSAGE_LIMITS.queueFrames } : { frame: PEER_LIVE_MESSAGE_LIMITS.frameBytes, bytes: PEER_LIVE_MESSAGE_LIMITS.bufferedBytes, count: PEER_LIVE_MESSAGE_LIMITS.queueFrames };
function workerRtcLanes(post, lifetime, fail, timeoutMs, consume) {
  const lanes = ["reliable", "live"].map((lane) => {
    const limit = bounds(lane), queue = [];
    const pending = /* @__PURE__ */ new Map();
    let sequence = 0, received = 0, credited = 0, queuedBytes = 0, outgoingBytes = 0, reading = false, pumping = false;
    let wake;
    const requireOpen = () => lifetime.throwIfAborted();
    const validBytes = (bytes) => bytes instanceof Uint8Array && bytes.length > 0 && bytes.length <= limit.frame;
    const abort = () => {
      queue.length = 0;
      queuedBytes = 0;
      for (const held of pending.values()) {
        clearTimeout(held.timer);
        held.reject(lifetime.reason);
      }
      pending.clear();
      outgoingBytes = 0;
      wake?.();
      wake = void 0;
    };
    lifetime.addEventListener("abort", abort, { once: true });
    const acknowledge = (entry, accepted) => {
      requireOpen();
      queuedBytes -= entry.bytes.length;
      credited = entry.sequence;
      post({ action: "ack", lane, sequence: entry.sequence, accepted });
    };
    const pump = async () => {
      if (pumping || consume === void 0) return;
      pumping = true;
      try {
        while (queue.length && !lifetime.aborted) {
          const entry = queue[0];
          const accepted = await awaitOwnedTask(lifetime, () => consume(lane, entry.bytes));
          requireOpen();
          queue.shift();
          acknowledge(entry, accepted);
        }
      } catch (error) {
        if (!lifetime.aborted) fail(error);
      } finally {
        pumping = false;
      }
    };
    const send = async (bytes, signal) => {
      signal?.throwIfAborted();
      requireOpen();
      if (!validBytes(bytes)) throw new Error("APPLICATION_WORKER_FRAME_INVALID");
      if (pending.size >= limit.count || outgoingBytes + bytes.length > limit.bytes) {
        if (lane === "live") return false;
        throw new Error("APPLICATION_WORKER_SEND_LIMIT");
      }
      if (!Number.isSafeInteger(sequence + 1)) throw new Error("APPLICATION_WORKER_SEQUENCE_EXHAUSTED");
      const id = ++sequence;
      const accepted = new Promise((resolve, reject) => {
        const timer = setTimeout(() => fail(new Error("APPLICATION_WORKER_FRAME_TIMEOUT")), timeoutMs);
        pending.set(id, { bytes: bytes.length, resolve, reject, timer });
        outgoingBytes += bytes.length;
        try {
          post({ action: "frame", lane, sequence: id, bytes: bytes.slice() });
        } catch (error) {
          fail(error);
        }
      });
      const owned = signal === void 0 ? lifetime : AbortSignal.any([signal, lifetime]);
      try {
        return await awaitOwnedTask(owned, () => accepted);
      } catch (error) {
        if (!lifetime.aborted) fail(error);
        throw error;
      }
    };
    const frames = (signal) => ({ [Symbol.asyncIterator]() {
      const controller = new AbortController(), owned = AbortSignal.any([lifetime, controller.signal, ...[signal].filter((s) => s !== void 0)]);
      const cancelled = () => {
        wake?.();
        wake = void 0;
      };
      async function* read() {
        if (reading || consume !== void 0) throw new Error("APPLICATION_WORKER_READER_EXISTS");
        reading = true;
        owned.addEventListener("abort", cancelled, { once: true });
        try {
          for (; ; ) {
            owned.throwIfAborted();
            const entry = queue.shift();
            if (entry === void 0) {
              await new Promise((resolve) => {
                wake = resolve;
              });
              continue;
            }
            yield entry.bytes;
            acknowledge(entry, true);
          }
        } finally {
          reading = false;
          owned.removeEventListener("abort", cancelled);
          if (!lifetime.aborted) fail(new Error("APPLICATION_WORKER_READER_CLOSED"));
        }
      }
      const iterator = read();
      return {
        next: () => iterator.next(),
        async return() {
          controller.abort();
          return iterator.return();
        },
        async throw(error) {
          controller.abort(error);
          return iterator.throw(error);
        }
      };
    } });
    return { lane, send, frames, receive(value) {
      requireOpen();
      if (!Number.isSafeInteger(value.sequence) || Number(value.sequence) < 1) throw new Error("APPLICATION_WORKER_SEQUENCE_INVALID");
      if (value.action === "ack") {
        const first = pending.entries().next().value;
        if (first === void 0 || first[0] !== value.sequence || typeof value.accepted !== "boolean" || lane === "reliable" && !value.accepted)
          throw new Error("APPLICATION_WORKER_CREDIT_INVALID");
        pending.delete(first[0]);
        clearTimeout(first[1].timer);
        outgoingBytes -= first[1].bytes;
        first[1].resolve(value.accepted);
      } else {
        if (value.sequence !== received + 1 || !validBytes(value.bytes)) throw new Error("APPLICATION_WORKER_FRAME_INVALID");
        if (received - credited >= limit.count || queuedBytes + value.bytes.length > limit.bytes) throw new Error("APPLICATION_WORKER_RECEIVE_LIMIT");
        received++;
        queuedBytes += value.bytes.length;
        queue.push({ sequence: received, bytes: value.bytes.slice() });
        wake?.();
        wake = void 0;
        void pump();
      }
    } };
  });
  return { reliable: lanes[0], live: lanes[1], receive(value) {
    if (value.lane !== "reliable" && value.lane !== "live") throw new Error("APPLICATION_WORKER_LANE_INVALID");
    if (value.action !== "frame" && value.action !== "ack") throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
    const expected = value.action === "frame" ? ["action", "lane", "sequence", "bytes"] : ["action", "lane", "sequence", "accepted"];
    if (Object.keys(value).some((key) => !expected.includes(key))) throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
    lanes[value.lane === "reliable" ? 0 : 1].receive(value);
  } };
}

// packages/peer-session/src/worker-transport.ts
var PROTOCOL2 = "chronolog/peer-session/rtc-endpoint/v1";
var MAX_CONNECTIONS = 16;
var MAX_BOOTSTRAP_CANDIDATES = 40;
var clients = /* @__PURE__ */ new WeakMap();
var validId = (id) => typeof id === "string" && /^[0-9a-f-]{36}$/u.test(id);
var validPeerId = (id) => typeof id === "string" && /^[0-9a-f]{64}$/u.test(id);
var payload = ({ type: _type, id: _id, from: _from, ...value }) => value;
var envelope = (data, from) => {
  const value = message(data);
  return value?.type === PROTOCOL2 && value.from === from && validId(value.id) ? value : null;
};
function signalingQueue(signal) {
  const items = [];
  let wake;
  let ended = false;
  let failure;
  const stop = (error) => {
    if (ended) return;
    ended = true;
    if (error !== void 0) failure = error;
    wake?.();
    wake = void 0;
  };
  signal.addEventListener("abort", () => stop(signal.reason), { once: true });
  return {
    push(value) {
      if (ended) return;
      items.push(value);
      wake?.();
      wake = void 0;
    },
    end: stop,
    messages: {
      async *[Symbol.asyncIterator]() {
        while (true) {
          if (items.length > 0) {
            yield items.shift();
            continue;
          }
          if (ended) {
            if (failure !== void 0) throw failure instanceof Error ? failure : new Error(errorMessage(failure));
            return;
          }
          await new Promise((resolve) => {
            wake = resolve;
          });
        }
      }
    }
  };
}
function serveWorkerWebRtcConnections(endpoint, options = {}) {
  const active = /* @__PURE__ */ new Map();
  const authenticatedPeers = /* @__PURE__ */ new Map();
  const peerListeners = /* @__PURE__ */ new Set();
  let closing, closed = false;
  const post = (id, value) => endpoint.postMessage({ ...value, type: PROTOCOL2, id, from: "page" });
  const notifyPeer = (type, peer) => {
    for (const listener of peerListeners) {
      try {
        listener({ type, peer });
      } catch {
      }
    }
  };
  const receive = (event) => {
    const data = envelope(event.data, "worker");
    if (data === null || closed) return;
    const id = data.id, existing = active.get(id);
    if (existing !== void 0) {
      existing.receive(payload(data));
      return;
    }
    if (data.action !== "open") return;
    if (active.size >= MAX_CONNECTIONS) {
      post(id, { action: "ended", error: "APPLICATION_PEER_LIMIT" });
      return;
    }
    if (!["offerer", "answerer"].includes(String(data.role)) || !validTimeout(data.timeoutMs) || !validGatheringTimeout(data.gatheringTimeoutMs, data.timeoutMs) || !validConfiguration(data.configuration)) {
      post(id, { action: "ended", error: "APPLICATION_WORKER_OPTIONS_INVALID" });
      return;
    }
    const lifetime = new AbortController(), incoming = signalingQueue(lifetime.signal);
    const sent = deferred(), signalingClosed = deferred();
    let rtc, stopping;
    let inBand, peerHandle;
    let remoteDescriptionSeen = false, remoteCandidates = 0, sendRequested = false, sendAcknowledged = false, closeRequested = false, closeAcknowledged = false;
    let lastRoute = 0, routePending = false;
    const end = (reason = new Error("APPLICATION_RTC_CLOSED")) => {
      if (stopping !== void 0) return stopping;
      stopping = Promise.resolve().then(async () => {
        await rtc?.close();
      });
      void stopping.catch(() => void 0);
      inBand?.close();
      inBand = void 0;
      if (peerHandle !== void 0) {
        const retired = peerHandle;
        peerHandle = void 0;
        if (authenticatedPeers.get(retired.peerId)?.connectionId === id) {
          authenticatedPeers.delete(retired.peerId);
        }
        notifyPeer("disconnected", retired);
      }
      lifetime.abort(reason);
      incoming.end(reason);
      sent.reject(reason);
      signalingClosed.reject(reason);
      active.delete(id);
      try {
        post(id, { action: "ended", error: errorMessage(reason) });
      } catch {
      }
      return stopping;
    };
    const lanes = workerRtcLanes(
      (value) => post(id, value),
      lifetime.signal,
      (error) => {
        void end(error);
      },
      data.timeoutMs,
      async (lane, bytes) => {
        if (rtc === void 0) throw new Error("APPLICATION_WORKER_NOT_READY");
        if (lane === "live") return rtc.live.trySend(bytes, { signal: lifetime.signal });
        await rtc.send(bytes, { signal: lifetime.signal });
        return true;
      }
    );
    const request = (input) => {
      try {
        if (input.action === "close") {
          void end();
          return;
        }
        if (input.action === "frame" || input.action === "ack") {
          lanes.receive(input);
          return;
        }
        if (input.action === "description" && !remoteDescriptionSeen) {
          remoteDescriptionSeen = true;
          incoming.push(description(input.description, data.role === "offerer" ? "answer" : "offer"));
          return;
        }
        if (input.action === "candidate" && remoteCandidates < MAX_BOOTSTRAP_CANDIDATES) {
          remoteCandidates += 1;
          incoming.push({ kind: "candidate", candidate: validatePeerIceCandidate(input.candidate) });
          return;
        }
        if (input.action === "sent" && sendRequested && !sendAcknowledged) {
          sendAcknowledged = true;
          sent.resolve();
          return;
        }
        if (input.action === "signaling-closed" && closeRequested && !closeAcknowledged) {
          closeAcknowledged = true;
          signalingClosed.resolve();
          return;
        }
        if (input.action === "authenticated" && rtc !== void 0 && inBand === void 0 && validPeerId(input.peerId) && typeof input.polite === "boolean") {
          const peerId = input.peerId;
          inBand = rtc.session.attachInBandSignaling({
            polite: input.polite,
            async send(rtcMessage) {
              lifetime.signal.throwIfAborted();
              post(id, { action: "rtc", message: rtcMessage });
            }
          });
          peerHandle = Object.freeze({
            peerId,
            connectionId: id,
            transportKind: "direct",
            media: rtc.session.media,
            streams: rtc.session.streams,
            signal: lifetime.signal
          });
          authenticatedPeers.set(peerId, peerHandle);
          notifyPeer("connected", peerHandle);
          return;
        }
        if (input.action === "rtc" && inBand !== void 0) {
          void inBand.receive(validateRtcSignalMessage(input.message)).catch(() => void 0);
          return;
        }
        if (input.action === "route" && rtc !== void 0 && !routePending && Number.isSafeInteger(input.request) && Number(input.request) > lastRoute) {
          lastRoute = Number(input.request);
          routePending = true;
          void awaitOwnedTask(lifetime.signal, () => rtc.session.getRoute()).then((value) => {
            lifetime.signal.throwIfAborted();
            post(id, { action: "route", request: input.request, value: route(value) });
          }, (error) => {
            if (!lifetime.signal.aborted) post(id, { action: "route", request: input.request, error: errorMessage(error) });
          }).catch((error) => {
            void end(error);
          }).finally(() => {
            routePending = false;
          });
          return;
        }
        throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
      } catch (error) {
        void end(error);
      }
    };
    active.set(id, { receive: request, close: end });
    void (async () => {
      try {
        const candidate = await openWebRtcConnection({
          role: data.role,
          ...data.configuration === void 0 ? {} : { configuration: data.configuration },
          ...options.createPeerConnection === void 0 ? {} : { createPeerConnection: options.createPeerConnection },
          timeoutMs: data.timeoutMs,
          signal: lifetime.signal,
          ...data.gatheringTimeoutMs === void 0 ? {} : { gatheringTimeoutMs: data.gatheringTimeoutMs },
          ...typeof data.trickle === "boolean" ? { trickle: data.trickle } : {},
          signaling: {
            messages: incoming.messages,
            async send(value) {
              lifetime.signal.throwIfAborted();
              if ("type" in value) {
                if (sendRequested) throw new Error("APPLICATION_WORKER_DESCRIPTION_REPEATED");
                sendRequested = true;
                post(id, { action: "send", description: value });
                await awaitOwnedTask(lifetime.signal, () => sent.promise);
              } else if (value.kind === "candidate") {
                post(id, { action: "candidate", candidate: value.candidate });
              } else if (value.kind === "connected") {
                post(id, { action: "connected" });
              }
            },
            async close() {
              lifetime.signal.throwIfAborted();
              if (!closeRequested) {
                closeRequested = true;
                post(id, { action: "close-signaling" });
              }
              await awaitOwnedTask(lifetime.signal, () => signalingClosed.promise);
            }
          }
        });
        rtc = candidate;
        if (lifetime.signal.aborted) {
          await candidate.close();
          return;
        }
        candidate.signal.addEventListener("abort", () => {
          void end(candidate.signal.reason);
        }, { once: true });
        candidate.session.signal.addEventListener("abort", () => {
          void end(candidate.session.signal.reason);
        }, { once: true });
        if (candidate.signal.aborted || candidate.session.signal.aborted) {
          await end(candidate.signal.reason ?? candidate.session.signal.reason);
          return;
        }
        post(id, { action: "ready" });
        const forward = async (lane) => {
          const source = lane === "reliable" ? candidate : candidate.live;
          for await (const bytes of source.frames(lifetime.signal)) {
            lifetime.signal.throwIfAborted();
            await lanes[lane].send(bytes, lifetime.signal);
          }
          if (!lifetime.signal.aborted) await end(new Error("APPLICATION_RTC_ENDED"));
        };
        void forward("reliable").catch((error) => {
          void end(error);
        });
        void forward("live").catch((error) => {
          void end(error);
        });
      } catch (error) {
        await end(error);
      }
    })().catch(() => void 0);
  };
  const abort = () => {
    void close();
  };
  const close = () => {
    if (closing !== void 0) return closing;
    closed = true;
    endpoint.removeEventListener("message", receive);
    options.signal?.removeEventListener("abort", abort);
    closing = Promise.allSettled([...active.values()].map((value) => value.close(new Error("APPLICATION_WORKER_CLOSED")))).then(() => {
      authenticatedPeers.clear();
      peerListeners.clear();
    });
    return closing;
  };
  endpoint.addEventListener("message", receive);
  options.signal?.addEventListener("abort", abort, { once: true });
  if (options.signal?.aborted === true) abort();
  return {
    getPeer: (peerId) => authenticatedPeers.get(peerId),
    peers: () => [...authenticatedPeers.values()],
    onPeer(listener) {
      peerListeners.add(listener);
      for (const peer of authenticatedPeers.values()) {
        try {
          listener({ type: "connected", peer });
        } catch {
        }
      }
      return () => {
        peerListeners.delete(listener);
      };
    },
    close
  };
}
async function openWorkerWebRtcConnection(endpoint, options) {
  const timeoutMs = options.timeoutMs ?? 3e4;
  if (!validTimeout(timeoutMs) || !validGatheringTimeout(options.gatheringTimeoutMs, timeoutMs) || !["offerer", "answerer"].includes(options.role) || !validConfiguration(options.configuration)) throw new Error("APPLICATION_WORKER_OPTIONS_INVALID");
  options.signal?.throwIfAborted();
  let owned = clients.get(endpoint);
  if (owned === void 0) clients.set(endpoint, owned = /* @__PURE__ */ new Set());
  if (owned.size >= MAX_CONNECTIONS) throw new Error("APPLICATION_PEER_LIMIT");
  const id = crypto.randomUUID(), lifetime = new AbortController(), negotiated = deferred();
  owned.add(id);
  const post = (value) => endpoint.postMessage({ ...value, type: PROTOCOL2, id, from: "worker" });
  let closing, signalingClose;
  let sendSeen = false, closeSeen = false, readySeen = false, outgoingCandidates = 0;
  let inBandSend;
  let routeId = 0, routePending;
  const stopSignaling = () => {
    signalingClose ??= Promise.resolve().then(() => options.signaling.close());
    void signalingClose.catch(() => void 0);
    return signalingClose;
  };
  const close = (reason = new Error("APPLICATION_RTC_CLOSED")) => {
    if (closing !== void 0) return closing;
    closing = Promise.resolve();
    inBandSend = void 0;
    lifetime.abort(reason);
    clearTimeout(timer);
    options.signal?.removeEventListener("abort", abort);
    negotiated.reject(reason);
    owned.delete(id);
    if (!owned.size) clients.delete(endpoint);
    if (routePending !== void 0) {
      clearTimeout(routePending.timer);
      routePending.result.reject(reason);
      routePending = void 0;
    }
    try {
      post({ action: "close" });
    } catch {
    }
    endpoint.removeEventListener("message", receive);
    void stopSignaling();
    return closing;
  };
  const fail = (error) => {
    void close(error);
  };
  const lanes = workerRtcLanes(post, lifetime.signal, fail, timeoutMs);
  const abort = () => fail(options.signal?.reason);
  const receive = (event) => {
    const value = envelope(event.data, "page");
    if (value?.id !== id || lifetime.signal.aborted) return;
    try {
      if (value.action === "ended") throw new Error(errorMessage(value.error ?? "APPLICATION_RTC_CLOSED"));
      if (value.action === "frame" || value.action === "ack") {
        if (!readySeen) throw new Error("APPLICATION_WORKER_NOT_READY");
        lanes.receive(payload(value));
        return;
      }
      if (value.action === "send" && !sendSeen) {
        sendSeen = true;
        const outgoing = description(value.description, options.role === "offerer" ? "offer" : "answer");
        void awaitOwnedTask(lifetime.signal, () => options.signaling.send(outgoing)).then(() => {
          lifetime.signal.throwIfAborted();
          post({ action: "sent" });
        }).catch(fail);
        return;
      }
      if (value.action === "candidate" && !closeSeen && outgoingCandidates < MAX_BOOTSTRAP_CANDIDATES) {
        outgoingCandidates += 1;
        const candidate = validatePeerIceCandidate(value.candidate);
        void Promise.resolve(options.signaling.send({ kind: "candidate", candidate })).catch(() => void 0);
        return;
      }
      if (value.action === "connected" && !closeSeen) {
        void Promise.resolve(options.signaling.send({ kind: "connected" })).catch(() => void 0);
        return;
      }
      if (value.action === "close-signaling" && !closeSeen && sendSeen) {
        closeSeen = true;
        void awaitOwnedTask(lifetime.signal, stopSignaling).then(() => {
          lifetime.signal.throwIfAborted();
          post({ action: "signaling-closed" });
        }).catch(fail);
        return;
      }
      if (value.action === "ready" && !readySeen && closeSeen && sendSeen) {
        readySeen = true;
        negotiated.resolve();
        return;
      }
      if (value.action === "rtc" && readySeen && inBandSend !== void 0) {
        const rtcMessage = validateRtcSignalMessage(value.message);
        void inBandSend(rtcMessage).catch(() => void 0);
        return;
      }
      if (value.action === "route" && routePending !== void 0 && value.request === routePending.id) {
        const pending = routePending, selected = value.error === void 0 ? route(value.value) : void 0;
        routePending = void 0;
        clearTimeout(pending.timer);
        if (selected !== void 0) pending.result.resolve(selected);
        else pending.result.reject(new Error(errorMessage(value.error)));
        return;
      }
      throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
    } catch (error) {
      fail(error);
    }
  };
  const timer = setTimeout(() => fail(new Error("APPLICATION_WORKER_CONNECTION_TIMEOUT")), timeoutMs);
  endpoint.addEventListener("message", receive);
  options.signal?.addEventListener("abort", abort, { once: true });
  let remoteMessages;
  try {
    remoteMessages = options.signaling.messages[Symbol.asyncIterator]();
    lifetime.signal.throwIfAborted();
    post({
      action: "open",
      role: options.role,
      timeoutMs,
      configuration: options.configuration,
      gatheringTimeoutMs: options.gatheringTimeoutMs,
      ...options.trickle === void 0 ? {} : { trickle: options.trickle }
    });
    void (async () => {
      let seenDescription = false, seenCandidates = 0;
      while (!lifetime.signal.aborted && !closeSeen) {
        const item = await awaitOwnedTask(lifetime.signal, () => remoteMessages.next());
        if (item.done) {
          if (!seenDescription) throw new Error("APPLICATION_WORKER_SIGNALING_ENDED");
          return;
        }
        const incoming = item.value;
        if (typeof incoming === "object" && incoming !== null && "type" in incoming && "sdp" in incoming) {
          if (seenDescription) throw new Error("APPLICATION_WORKER_DESCRIPTION_INVALID");
          seenDescription = true;
          post({ action: "description", description: description(incoming, options.role === "offerer" ? "answer" : "offer") });
        } else if (typeof incoming === "object" && incoming !== null && "kind" in incoming && incoming.kind === "candidate") {
          if (seenCandidates < MAX_BOOTSTRAP_CANDIDATES) {
            seenCandidates += 1;
            post({ action: "candidate", candidate: validatePeerIceCandidate(incoming.candidate) });
          }
        }
      }
    })().catch(fail);
    await awaitOwnedTask(lifetime.signal, () => negotiated.promise);
    lifetime.signal.throwIfAborted();
    clearTimeout(timer);
    return {
      signal: lifetime.signal,
      send: async (bytes, sendOptions) => {
        await lanes.reliable.send(bytes, sendOptions?.signal);
      },
      frames: (signal) => lanes.reliable.frames(signal),
      close: () => close(),
      live: {
        signal: lifetime.signal,
        trySend: (bytes, sendOptions) => lanes.live.send(bytes, sendOptions?.signal),
        frames: (signal) => lanes.live.frames(signal),
        close: () => close()
      },
      attachInBandSignaling(binding) {
        if (lifetime.signal.aborted) throw new Error("APPLICATION_RTC_CLOSED");
        if (!validPeerId(binding.peerId)) throw new Error("APPLICATION_WORKER_MESSAGE_INVALID");
        inBandSend = binding.send;
        post({ action: "authenticated", peerId: binding.peerId, polite: binding.polite });
        return {
          async receive(rtcMessage) {
            if (lifetime.signal.aborted) return;
            post({ action: "rtc", message: validateRtcSignalMessage(rtcMessage) });
          },
          close() {
            inBandSend = void 0;
          }
        };
      },
      getRoute() {
        lifetime.signal.throwIfAborted();
        if (routePending !== void 0) return routePending.result.promise;
        const request = ++routeId;
        if (!Number.isSafeInteger(request)) throw new Error("APPLICATION_WORKER_REQUEST_ID_EXHAUSTED");
        const result = deferred(), routeTimer = setTimeout(() => fail(new Error("APPLICATION_WORKER_ROUTE_TIMEOUT")), timeoutMs);
        routePending = { id: request, result, timer: routeTimer };
        try {
          post({ action: "route", request });
        } catch (error) {
          fail(error);
        }
        return result.promise;
      }
    };
  } catch (error) {
    await close(error);
    throw error;
  } finally {
    void Promise.resolve().then(() => remoteMessages?.return?.()).catch(() => void 0);
  }
}
function validTimeout(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 1 && value <= 12e4;
}
function validConfiguration(value) {
  if (value === void 0) return true;
  try {
    return value !== null && typeof value === "object" && !Array.isArray(value) && JSON.stringify(value).length <= 16384;
  } catch {
    return false;
  }
}
function message(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function description(value, expected) {
  try {
    return validatePeerDescription(value, expected);
  } catch {
    throw new Error("APPLICATION_WORKER_DESCRIPTION_INVALID");
  }
}
function route(value) {
  const input = message(value), candidates = [null, "host", "srflx", "prflx", "relay"];
  if (input === null || !["direct", "relay", "unknown"].includes(String(input.route)) || !candidates.includes(input.localCandidateType) || !candidates.includes(input.remoteCandidateType)) {
    throw new Error("APPLICATION_WORKER_ROUTE_INVALID");
  }
  return {
    route: input.route,
    localCandidateType: input.localCandidateType,
    remoteCandidateType: input.remoteCandidateType
  };
}
function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => {
    resolve = yes;
    reject = no;
  });
  void promise.catch(() => void 0);
  return { promise, resolve, reject };
}
function errorMessage(error) {
  return (error instanceof Error ? error.message : String(error)).slice(0, 256);
}
function validGatheringTimeout(value, timeoutMs) {
  return value === void 0 || validTimeout(value) && value <= timeoutMs;
}

export {
  WEBRTC_LIMITS,
  APP_STREAM_PREFIX,
  MAX_APP_STREAMS,
  openWebRtcConnection,
  serveWorkerWebRtcConnections,
  openWorkerWebRtcConnection
};
