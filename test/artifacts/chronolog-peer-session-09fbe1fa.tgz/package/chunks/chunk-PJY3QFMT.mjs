import {
  createOverlayCas,
  createSqliteCasDriver,
  diffMerkleDbRoots
} from "./chunk-7LI7BAA2.mjs";
import {
  ContentAddressedStore,
  MemoryBytesStore
} from "./chunk-OQYLKC3T.mjs";

// packages/peer-session/src/sql-extensions.ts
function quoteIdent(name) {
  return `"${name.replace(/"/g, '""')}"`;
}
function listUserTables(db) {
  const res = db.query(
    "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_rls_%' AND name NOT LIKE '_chronolog_%' ORDER BY name",
    []
  );
  return res.rows.map((r) => typeof r[0] === "string" ? r[0] : "");
}
function readTableSnapshot(db, table) {
  const qTable = quoteIdent(table);
  const res = db.query(`SELECT * FROM ${qTable}`, []);
  const cols = res.columns;
  const pkCols = [];
  try {
    const info = db.query(`PRAGMA table_info(${qTable})`, []);
    const pkEntries = info.rows.filter((r) => Number(r[5]) > 0).sort((a, b) => Number(a[5]) - Number(b[5])).map((r) => typeof r[1] === "string" ? r[1] : "");
    pkCols.push(...pkEntries);
  } catch {
  }
  const keyCols = pkCols.length > 0 ? pkCols : cols.length > 0 ? [cols[0]] : [];
  const rows = res.rows.map((row) => {
    const obj = {};
    for (let i = 0; i < cols.length; i++) obj[cols[i]] = row[i] ?? null;
    return obj;
  });
  return { columns: cols, pkColumns: keyCols, rows };
}
function openSqlBranch(options) {
  const overlayCas = createOverlayCas(options.cas);
  const recordedStatements = [];
  let closed = false;
  let currentBranchRoot = options.baseRoot;
  let db = null;
  const openCurrentDb = () => {
    if (db === null) {
      db = options.driver.openDb({
        dbRoot: currentBranchRoot,
        cas: overlayCas,
        partition: options.partition,
        actor: options.actor,
        opId: "0".repeat(64),
        opTimeMs: BigInt(Date.now()),
        readOnly: false,
        onMissingCas: (hash) => {
          throw new Error(`SQL_BRANCH_MISSING_CAS:${hash}`);
        }
      });
    }
    return db;
  };
  const ensureOpen = () => {
    if (closed) throw new Error("SQL_BRANCH_CLOSED");
  };
  const commitBranch = () => {
    ensureOpen();
    if (db !== null) {
      currentBranchRoot = db.commit();
      db = null;
    }
    return currentBranchRoot ?? "";
  };
  const computeDiff = () => {
    ensureOpen();
    const branchRoot = commitBranch() || null;
    const merkle = diffMerkleDbRoots(overlayCas, options.baseRoot, branchRoot, "any");
    if (merkle.totalChangedPages === 0) {
      return { baseRoot: options.baseRoot, branchRoot, merkle, tables: [] };
    }
    const baseDb = options.driver.openDb({
      dbRoot: options.baseRoot,
      cas: options.cas,
      partition: options.partition,
      actor: options.actor,
      opId: "0".repeat(64),
      opTimeMs: 0n,
      readOnly: true,
      onMissingCas: (hash) => {
        throw new Error(`SQL_BRANCH_MISSING_CAS:${hash}`);
      }
    });
    const branchDb = options.driver.openDb({
      dbRoot: branchRoot,
      cas: overlayCas,
      partition: options.partition,
      actor: options.actor,
      opId: "0".repeat(64),
      opTimeMs: 0n,
      readOnly: true,
      onMissingCas: (hash) => {
        throw new Error(`SQL_BRANCH_MISSING_CAS:${hash}`);
      }
    });
    try {
      const baseTables = new Set(options.baseRoot === null ? [] : listUserTables(baseDb));
      const branchTables = new Set(branchRoot === null ? [] : listUserTables(branchDb));
      const allTables = [.../* @__PURE__ */ new Set([...baseTables, ...branchTables])].sort();
      const tableDiffs = [];
      for (const table of allTables) {
        const beforeSnap = baseTables.has(table) ? readTableSnapshot(baseDb, table) : { columns: [], pkColumns: [], rows: [] };
        const afterSnap = branchTables.has(table) ? readTableSnapshot(branchDb, table) : { columns: [], pkColumns: [], rows: [] };
        const keyColumns = afterSnap.pkColumns.length > 0 ? afterSnap.pkColumns : beforeSnap.pkColumns;
        const keyFor = (row) => JSON.stringify(keyColumns.map((k) => row[k] ?? null));
        const keyObjFor = (row) => {
          const out = {};
          for (const k of keyColumns) out[k] = row[k] ?? null;
          return out;
        };
        const beforeMap = /* @__PURE__ */ new Map();
        for (const r of beforeSnap.rows) beforeMap.set(keyFor(r), r);
        const afterMap = /* @__PURE__ */ new Map();
        for (const r of afterSnap.rows) afterMap.set(keyFor(r), r);
        const inserted = [];
        const updated = [];
        const deleted = [];
        for (const [k, afterRow] of afterMap) {
          const beforeRow = beforeMap.get(k);
          if (beforeRow === void 0) {
            inserted.push(afterRow);
          } else if (JSON.stringify(beforeRow) !== JSON.stringify(afterRow)) {
            updated.push({ key: keyObjFor(afterRow), before: beforeRow, after: afterRow });
          }
        }
        for (const [k, beforeRow] of beforeMap) {
          if (!afterMap.has(k)) deleted.push(beforeRow);
        }
        if (inserted.length > 0 || updated.length > 0 || deleted.length > 0) {
          tableDiffs.push({ table, keyColumns, inserted, updated, deleted });
        }
      }
      return { baseRoot: options.baseRoot, branchRoot, merkle, tables: tableDiffs };
    } finally {
      baseDb.close();
      branchDb.close();
    }
  };
  return {
    topic: options.topic,
    baseRoot: options.baseRoot,
    exec(sql, params = [], execOptions = { mode: "user" }) {
      ensureOpen();
      const res = openCurrentDb().exec(sql, params, execOptions);
      recordedStatements.push({ sql, params: params.slice() });
      return res;
    },
    query(sql, params = []) {
      ensureOpen();
      return openCurrentDb().query(sql, params);
    },
    commitBranch,
    diff: computeDiff,
    toProposal(proposalOpts = {}) {
      const diff = computeDiff();
      const preconditions = [];
      if (proposalOpts.withRowGuards !== false) {
        for (const tbl of diff.tables) {
          for (const upd of tbl.updated) {
            if (typeof upd.before._last_op_id === "string") {
              preconditions.push({
                kind: "based_on_row",
                table: tbl.table,
                where: upd.key,
                lastOpId: upd.before._last_op_id
              });
            } else {
              preconditions.push({
                kind: "row_matches",
                table: tbl.table,
                where: upd.key,
                expect: upd.before
              });
            }
          }
          for (const del of tbl.deleted) {
            const where = {};
            for (const k of tbl.keyColumns) where[k] = del[k] ?? null;
            if (typeof del._last_op_id === "string") {
              preconditions.push({
                kind: "based_on_row",
                table: tbl.table,
                where,
                lastOpId: del._last_op_id
              });
            }
          }
        }
      }
      return {
        topic: options.topic,
        baseRoot: options.baseRoot,
        branchRoot: diff.branchRoot,
        statements: recordedStatements.slice(),
        preconditions,
        diff
      };
    },
    close() {
      if (closed) return;
      closed = true;
      if (db !== null) {
        db.close();
        db = null;
      }
    }
  };
}
async function queryFederatedSql(sources, sql, params = [], options = {}) {
  const driver = options.driver ?? await createSqliteCasDriver();
  const cas = new ContentAddressedStore({ store: new MemoryBytesStore() });
  const db = driver.openDb({
    dbRoot: null,
    cas,
    partition: "private",
    actor: "0".repeat(64),
    opId: "0".repeat(64),
    opTimeMs: 0n,
    readOnly: false,
    onMissingCas: (h) => {
      throw new Error(`FEDERATED_SQL_MISSING:${h}`);
    }
  });
  const mountedTables = [];
  try {
    for (const [alias, src] of Object.entries(sources)) {
      if (!/^[A-Za-z][A-Za-z0-9_]*$/u.test(alias)) {
        throw new Error(`FEDERATED_SQL_INVALID_ALIAS:${alias}`);
      }
      let tableNames;
      if (src.tables !== void 0 && src.tables.length > 0) {
        tableNames = [...src.tables];
      } else {
        const listed = (await src.session.query(src.topic, { kind: "tables" })).value;
        tableNames = (listed?.tables ?? []).filter((t) => t.type === "table").map((t) => t.name);
      }
      for (const tbl of tableNames) {
        if (!/^[A-Za-z_][A-Za-z0-9_]*$/u.test(tbl)) continue;
        const data = (await src.session.query(src.topic, {
          sql: `SELECT * FROM ${quoteIdent(tbl)}`
        })).value;
        if (!data || !Array.isArray(data.columns) || data.columns.length === 0) continue;
        const mountedName = `${alias}__${tbl}`;
        const colDefs = data.columns.map((c) => quoteIdent(c)).join(", ");
        db.exec(`CREATE TABLE ${quoteIdent(mountedName)} (${colDefs})`, [], { mode: "admin" });
        if (data.rows.length > 0) {
          const placeholders = data.columns.map(() => "?").join(", ");
          const insertSql = `INSERT INTO ${quoteIdent(mountedName)} VALUES (${placeholders})`;
          for (const row of data.rows) {
            db.exec(insertSql, row, { mode: "admin" });
          }
        }
        mountedTables.push(mountedName);
      }
    }
    const res = db.query(sql, params);
    if (options.format === "objects") {
      const objRows = res.rows.map((row) => {
        const obj = {};
        for (let i = 0; i < res.columns.length; i++) obj[res.columns[i]] = row[i] ?? null;
        return obj;
      });
      return { columns: res.columns, rows: objRows, mountedTables };
    }
    return { columns: res.columns, rows: res.rows, mountedTables };
  } finally {
    db.close();
  }
}

export {
  openSqlBranch,
  queryFederatedSql
};
