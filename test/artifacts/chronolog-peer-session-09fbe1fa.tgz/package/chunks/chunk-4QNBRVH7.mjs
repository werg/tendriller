import {
  DEFAULT_DECODE_LIMITS,
  assertCanonicalCbor,
  encodeCanonicalCbor,
  equalBytes,
  sha256Sync
} from "./chunk-VRR2HFJY.mjs";

// packages/records/src/record-envelope.ts
var MAX_RECORD_VALUE_BYTES = 128 * 1024 * 1024;
var MAX_RECORD_ENVELOPE_BYTES = MAX_RECORD_VALUE_BYTES + 8192;
function assertRecordKey(key) {
  if (typeof key !== "string" || key.length === 0 || key.length > 4096) throw new Error("OPFS_KEY_INVALID");
}
function encodeRecordValueSync(key, bytes) {
  assertRecordKey(key);
  if (bytes.length > MAX_RECORD_VALUE_BYTES) throw new Error("BYTES_STORE_VALUE_LIMIT");
  const raw = encodeCanonicalCbor([1n, key, bytes, sha256Sync(bytes)]);
  if (raw.length > MAX_RECORD_ENVELOPE_BYTES) throw new Error("BYTES_STORE_VALUE_LIMIT");
  return raw;
}
function decodeRecordEntrySync(raw, corruptionCode) {
  if (raw.length === 0 || raw.length > MAX_RECORD_ENVELOPE_BYTES) throw new Error(corruptionCode);
  try {
    const decoded = assertCanonicalCbor(raw, {
      ...DEFAULT_DECODE_LIMITS,
      maxBytes: MAX_RECORD_ENVELOPE_BYTES,
      maxBlobBytes: MAX_RECORD_VALUE_BYTES
    });
    if (!Array.isArray(decoded) || decoded.length !== 4 || decoded[0] !== 1n || typeof decoded[1] !== "string" || !(decoded[2] instanceof Uint8Array) || !(decoded[3] instanceof Uint8Array) || !equalBytes(decoded[3], sha256Sync(decoded[2]))) throw new Error(corruptionCode);
    assertRecordKey(decoded[1]);
    return { key: decoded[1], value: decoded[2].slice() };
  } catch {
    throw new Error(corruptionCode);
  }
}
function decodeRecordValueSync(key, raw, corruptionCode) {
  assertRecordKey(key);
  const entry = decodeRecordEntrySync(raw, corruptionCode);
  if (entry.key !== key) throw new Error(corruptionCode);
  return entry.value;
}

// packages/records/src/indexeddb-bytes-store.ts
var TABLE = "values";
var STAGING = "checkpoint-staging";
var CHANGELOG = "changelog";
var VERSION = 3;
var IndexedDbBytesStore = class _IndexedDbBytesStore {
  #database;
  #pending = Promise.resolve();
  #closing;
  #closed = false;
  #invalid;
  constructor(database) {
    this.#database = database;
    database.onversionchange = () => {
      this.#invalid = new Error("INDEXEDDB_STORE_VERSION_CHANGED");
      database.close();
    };
  }
  static open(name, { create = true } = {}) {
    if (typeof indexedDB === "undefined") return Promise.reject(new Error("BROWSER_STORAGE_BACKEND_UNSUPPORTED"));
    return new Promise((resolve, reject) => {
      let blocked = false, missing = false;
      const request = indexedDB.open("chronolog-data:" + name, VERSION);
      request.onupgradeneeded = (event) => {
        if (blocked) {
          request.transaction?.abort();
          return;
        }
        if (!create && event.oldVersion === 0) {
          missing = true;
          request.transaction?.abort();
          return;
        }
        if (!request.result.objectStoreNames.contains(TABLE)) request.result.createObjectStore(TABLE);
        if (!request.result.objectStoreNames.contains(STAGING)) request.result.createObjectStore(STAGING);
        if (!request.result.objectStoreNames.contains(CHANGELOG)) {
          request.result.createObjectStore(CHANGELOG, { autoIncrement: true });
        }
      };
      request.onerror = () => {
        reject(missing ? new Error("APPLICATION_DATA_STORAGE_MISSING") : request.error ?? new Error("INDEXEDDB_STORE_OPEN_FAILED"));
      };
      request.onblocked = () => {
        blocked = true;
        reject(new Error("INDEXEDDB_STORE_BLOCKED"));
      };
      request.onsuccess = () => {
        if (blocked) request.result.close();
        else resolve(new _IndexedDbBytesStore(request.result));
      };
    });
  }
  async get(key) {
    assertRecordKey(key);
    return this.#enqueue(async () => {
      const raw = await this.#readTx(TABLE, (table) => {
        const request = table.get(key);
        return () => request.result;
      });
      if (raw === void 0) return null;
      if (!(raw instanceof Uint8Array) || raw.length > MAX_RECORD_ENVELOPE_BYTES) throw new Error("INDEXEDDB_VALUE_CORRUPT");
      return decodeRecordValueSync(key, raw, "INDEXEDDB_VALUE_CORRUPT");
    });
  }
  getMany(keys) {
    const captured = [...keys];
    if (captured.length > 128) return Promise.reject(new Error("BYTES_STORE_BATCH_LIMIT"));
    for (const key of captured) assertRecordKey(key);
    return this.#enqueue(async () => {
      const raw = await this.#readTx(TABLE, (table) => {
        const requests = captured.map((key) => table.get(key));
        return () => requests.map((request) => request.result);
      });
      return raw.map((value, index) => {
        if (value === void 0) return null;
        if (!(value instanceof Uint8Array) || value.length > MAX_RECORD_ENVELOPE_BYTES) throw new Error("INDEXEDDB_VALUE_CORRUPT");
        return decodeRecordValueSync(captured[index], value, "INDEXEDDB_VALUE_CORRUPT");
      });
    });
  }
  async put(key, input, options) {
    assertRecordKey(key);
    if (input.length > MAX_RECORD_VALUE_BYTES) return Promise.reject(new Error("BYTES_STORE_VALUE_LIMIT"));
    const raw = encodeRecordValueSync(key, input);
    const durability = options?.durability ?? "relaxed";
    return this.#enqueue(async () => {
      await this.#writeTx([TABLE, CHANGELOG], durability, (tx) => {
        tx.objectStore(TABLE).put(raw, key);
        tx.objectStore(CHANGELOG).add({ key, deleted: false });
        return () => void 0;
      });
    });
  }
  async putMany(entries, options) {
    if (entries.length === 0) return;
    if (entries.length > 128) return Promise.reject(new Error("BYTES_STORE_BATCH_LIMIT"));
    const encoded = [];
    const seen = /* @__PURE__ */ new Map();
    for (const entry of entries) {
      assertRecordKey(entry.key);
      if (entry.value.length > MAX_RECORD_VALUE_BYTES) return Promise.reject(new Error("BYTES_STORE_VALUE_LIMIT"));
      const raw = encodeRecordValueSync(entry.key, entry.value);
      const prevIdx = seen.get(entry.key);
      if (prevIdx !== void 0) {
        encoded[prevIdx] = { key: entry.key, value: raw };
      } else {
        seen.set(entry.key, encoded.length);
        encoded.push({ key: entry.key, value: raw });
      }
    }
    const durability = options?.durability ?? "relaxed";
    return this.#enqueue(async () => {
      await this.#writeTx([TABLE, CHANGELOG], durability, (tx) => {
        const table = tx.objectStore(TABLE);
        const log = tx.objectStore(CHANGELOG);
        for (const entry of encoded) {
          table.put(entry.value, entry.key);
          log.add({ key: entry.key, deleted: false });
        }
        return () => void 0;
      });
    });
  }
  async delete(key, options) {
    assertRecordKey(key);
    const durability = options?.durability ?? "relaxed";
    return this.#enqueue(() => this.#writeTx([TABLE, CHANGELOG], durability, (tx) => {
      tx.objectStore(TABLE).delete(key);
      tx.objectStore(CHANGELOG).add({ key, deleted: true });
      return () => void 0;
    }));
  }
  async deleteMany(keys, options) {
    if (keys.length === 0) return;
    const unique = [...new Set(keys)];
    for (const key of unique) assertRecordKey(key);
    const durability = options?.durability ?? "relaxed";
    return this.#enqueue(async () => {
      for (let i = 0; i < unique.length; i += 128) {
        const chunk = unique.slice(i, i + 128);
        await this.#writeTx([TABLE, CHANGELOG], durability, (tx) => {
          const table = tx.objectStore(TABLE);
          const log = tx.objectStore(CHANGELOG);
          for (const key of chunk) {
            table.delete(key);
            log.add({ key, deleted: true });
          }
          return () => void 0;
        });
      }
    });
  }
  async putAllIfEmpty(entries) {
    const encoded = [];
    const seen = /* @__PURE__ */ new Set();
    for (const entry of entries) {
      assertRecordKey(entry.key);
      if (entry.value.length > MAX_RECORD_VALUE_BYTES) throw new Error("BYTES_STORE_VALUE_LIMIT");
      if (seen.has(entry.key)) throw new Error("BYTES_STORE_DUPLICATE_KEY");
      seen.add(entry.key);
      encoded.push({ key: entry.key, value: encodeRecordValueSync(entry.key, entry.value) });
    }
    return this.#enqueue(() => this.#writeTx([TABLE, CHANGELOG], "strict", (tx) => {
      const table = tx.objectStore(TABLE);
      const log = tx.objectStore(CHANGELOG);
      let initialized = false;
      const count = table.count();
      count.onsuccess = () => {
        if (count.result !== 0) return;
        for (const entry of encoded) {
          table.add(entry.value, entry.key);
          log.add({ key: entry.key, deleted: false });
        }
        initialized = true;
      };
      return () => initialized;
    }));
  }
  async *iteratePrefix(prefix) {
    const upper = prefix + "\uFFFF";
    let after;
    for (; ; ) {
      const items = await this.#enqueue(() => this.#readTx(TABLE, (table) => {
        const entries = [];
        let failure, bytes = 0;
        const range = after === void 0 ? IDBKeyRange.bound(prefix, upper, false, true) : IDBKeyRange.bound(after, upper, true, true);
        const request = table.openCursor(range);
        request.onsuccess = () => {
          const cursor = request.result;
          if (cursor === null) return;
          const key = cursor.key, raw = cursor.value;
          if (typeof key !== "string" || !(raw instanceof Uint8Array) || raw.length > MAX_RECORD_ENVELOPE_BYTES) {
            failure = new Error("INDEXEDDB_VALUE_CORRUPT");
            return;
          }
          entries.push({ key, value: raw });
          bytes += raw.length;
          if (entries.length < 128 && bytes < 2 * 1024 * 1024) cursor.continue();
        };
        return () => {
          if (failure !== void 0) throw failure;
          return entries;
        };
      }));
      if (items.length === 0) break;
      for (const entry of items) {
        after = entry.key;
        yield { key: entry.key, value: decodeRecordValueSync(entry.key, entry.value, "INDEXEDDB_VALUE_CORRUPT") };
      }
    }
  }
  async *iterateEntries() {
    let release, started;
    const held = new Promise((resolve) => {
      release = resolve;
    }), ready = new Promise((resolve) => {
      started = resolve;
    });
    const owner = this.#enqueue(async () => {
      started();
      await held;
    });
    await Promise.race([ready, owner]);
    try {
      let after;
      for (; ; ) {
        const items = await this.#readTx(TABLE, (table) => {
          const entries = [];
          let failure, bytes = 0;
          const request = table.openCursor(after === void 0 ? void 0 : IDBKeyRange.lowerBound(after, true));
          request.onsuccess = () => {
            const cursor = request.result;
            if (cursor === null) return;
            const key = cursor.key, raw = cursor.value;
            if (typeof key !== "string" || !(raw instanceof Uint8Array) || raw.length > MAX_RECORD_ENVELOPE_BYTES) {
              failure = new Error("INDEXEDDB_VALUE_CORRUPT");
              return;
            }
            entries.push({ key, value: raw });
            bytes += raw.length;
            if (entries.length < 128 && bytes < 2 * 1024 * 1024) cursor.continue();
          };
          return () => {
            if (failure !== void 0) throw failure;
            return entries;
          };
        });
        if (items.length === 0) break;
        for (const entry of items) {
          after = entry.key;
          yield { key: entry.key, value: decodeRecordValueSync(entry.key, entry.value, "INDEXEDDB_VALUE_CORRUPT") };
        }
      }
    } finally {
      release();
      await owner;
    }
  }
  async latestChangeSeq() {
    return this.#enqueue(() => this.#readTx(CHANGELOG, (log) => {
      let latest = 0;
      const req = log.openKeyCursor(null, "prev");
      req.onsuccess = () => {
        const cursor = req.result;
        if (cursor !== null && typeof cursor.key === "number") latest = cursor.key;
      };
      return () => latest;
    }));
  }
  async readChangesSince(afterSeq) {
    return this.#enqueue(() => this.#readTx(CHANGELOG, (log) => {
      const changes = [];
      let latestSeq = afterSeq;
      const range = afterSeq > 0 ? IDBKeyRange.lowerBound(afterSeq, true) : void 0;
      const req = log.openCursor(range);
      req.onsuccess = () => {
        const cursor = req.result;
        if (cursor === null) return;
        const seq = typeof cursor.key === "number" ? cursor.key : 0;
        const val = cursor.value;
        if (seq > latestSeq) latestSeq = seq;
        if (val && typeof val.key === "string") {
          changes.push({ seq, key: val.key, deleted: val.deleted === true });
        }
        if (changes.length < 4096) cursor.continue();
      };
      return () => ({ latestSeq, changes });
    }));
  }
  async entries() {
    const entries = [];
    for await (const entry of this.iterateEntries()) entries.push(entry);
    return entries.sort((a, b) => a.key < b.key ? -1 : a.key > b.key ? 1 : 0);
  }
  putStreamIfEmpty(entries) {
    return this.#enqueue(async () => {
      const empty = await this.#readTx(TABLE, (table) => {
        const count = table.count();
        return () => count.result === 0;
      });
      if (!empty) return false;
      const clear = () => this.#writeTx([STAGING], "relaxed", (tx) => {
        tx.objectStore(STAGING).clear();
        return () => void 0;
      });
      await clear();
      try {
        for await (const entry of entries) {
          assertRecordKey(entry.key);
          const raw = encodeRecordValueSync(entry.key, entry.value);
          await this.#writeTx([STAGING], "relaxed", (tx) => {
            tx.objectStore(STAGING).add(raw, entry.key);
            return () => void 0;
          });
        }
        return await this.#writeTx([TABLE, STAGING, CHANGELOG], "strict", (tx) => {
          const table = tx.objectStore(TABLE), staging = tx.objectStore(STAGING), log = tx.objectStore(CHANGELOG);
          let initialized = false;
          const count = table.count();
          count.onsuccess = () => {
            if (count.result !== 0) return;
            initialized = true;
            const cursor = staging.openCursor();
            cursor.onsuccess = () => {
              const entry = cursor.result;
              if (entry === null) {
                staging.clear();
                return;
              }
              table.add(entry.value, entry.key);
              if (typeof entry.key === "string") log.add({ key: entry.key, deleted: false });
              entry.continue();
            };
          };
          return () => initialized;
        });
      } finally {
        await clear();
      }
    });
  }
  close() {
    if (this.#closing !== void 0) return this.#closing;
    this.#closed = true;
    this.#closing = this.#pending.then(() => {
      this.#database.close();
    });
    return this.#closing;
  }
  #enqueue(work) {
    if (this.#closed) return Promise.reject(new Error("INDEXEDDB_STORE_CLOSED"));
    if (this.#invalid !== void 0) return Promise.reject(this.#invalid);
    const task = this.#pending.then(() => {
      if (this.#invalid !== void 0) throw this.#invalid;
      return work();
    });
    this.#pending = task.then(() => void 0, () => void 0);
    return task;
  }
  #readTx(storeName, enqueue) {
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.#database.transaction(storeName, "readonly");
      } catch (error) {
        reject(error);
        return;
      }
      let value;
      try {
        value = enqueue(transaction.objectStore(storeName));
      } catch (error) {
        try {
          transaction.abort();
        } catch {
        }
        reject(error);
        return;
      }
      transaction.oncomplete = () => {
        try {
          resolve(value());
        } catch (error) {
          reject(error);
        }
      };
      transaction.onabort = () => {
        reject(transaction.error ?? new Error("INDEXEDDB_TRANSACTION_ABORTED"));
      };
      transaction.onerror = () => {
      };
    });
  }
  #writeTx(storeNames, durability, enqueue) {
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.#database.transaction([...storeNames], "readwrite", { durability });
      } catch (error) {
        reject(error);
        return;
      }
      let value;
      try {
        value = enqueue(transaction);
      } catch (error) {
        try {
          transaction.abort();
        } catch {
        }
        reject(error);
        return;
      }
      transaction.oncomplete = () => {
        try {
          resolve(value());
        } catch (error) {
          reject(error);
        }
      };
      transaction.onabort = () => {
        reject(transaction.error ?? new Error("INDEXEDDB_TRANSACTION_ABORTED"));
      };
      transaction.onerror = () => {
      };
    });
  }
};
async function probeIndexedDbBytesStore() {
  if (typeof indexedDB === "undefined") return false;
  const name = "probe-" + crypto.randomUUID();
  let store;
  try {
    store = await IndexedDbBytesStore.open(name);
    await store.put("probe", Uint8Array.of(0, 255));
    await store.close();
    store = void 0;
    const reopened = await IndexedDbBytesStore.open(name);
    store = reopened;
    const bytes = await reopened.get("probe");
    if (bytes?.length !== 2 || bytes[0] !== 0 || bytes[1] !== 255) throw new Error("INDEXEDDB_PROBE_FAILED");
    return true;
  } finally {
    await store?.close();
    await new Promise((resolve, reject) => {
      const request = indexedDB.deleteDatabase("chronolog-data:" + name);
      request.onsuccess = () => {
        resolve();
      };
      request.onerror = () => {
        reject(request.error ?? new Error("INDEXEDDB_PROBE_CLEANUP_FAILED"));
      };
      request.onblocked = () => {
        reject(new Error("INDEXEDDB_PROBE_CLEANUP_BLOCKED"));
      };
    });
  }
}
function inspectExistingIndexedDbRecords(name) {
  if (typeof indexedDB === "undefined") return Promise.resolve(false);
  if (typeof indexedDB.databases === "function") {
    return indexedDB.databases().then((databases) => databases.some((database) => database.name === "chronolog-data:" + name));
  }
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("chronolog-data:" + name);
    let absent = false;
    request.onupgradeneeded = (event) => {
      if (event.oldVersion === 0) {
        absent = true;
        request.transaction?.abort();
      }
    };
    request.onerror = () => {
      if (absent && request.error?.name === "AbortError") resolve(false);
      else reject(request.error ?? new Error("INDEXEDDB_INSPECTION_FAILED"));
    };
    request.onblocked = () => {
      reject(new Error("INDEXEDDB_INSPECTION_BLOCKED"));
    };
    request.onsuccess = () => {
      request.result.close();
      resolve(true);
    };
  });
}

export {
  IndexedDbBytesStore,
  probeIndexedDbBytesStore,
  inspectExistingIndexedDbRecords
};
