export declare const MAX_RECORD_VALUE_BYTES: number;
export declare const MAX_RECORD_ENVELOPE_BYTES: number;
export declare function assertRecordKey(key: string): void;
export declare function recordFilenameSync(key: string): string;
export declare function recordFilename(key: string): Promise<string>;
/** Synchronous authenticated logical record envelope (zero async WebCrypto IPC overhead). */
export declare function encodeRecordValueSync(key: string, bytes: Uint8Array): Uint8Array;
export declare function encodeRecordValue(key: string, bytes: Uint8Array): Promise<Uint8Array>;
export declare function decodeRecordEntrySync(raw: Uint8Array, corruptionCode: string): {
    key: string;
    value: Uint8Array;
};
export declare function decodeRecordValueSync(key: string, raw: Uint8Array, corruptionCode: string): Uint8Array;
export declare function decodeRecordValue(key: string, raw: Uint8Array, corruptionCode: string): Promise<Uint8Array>;
export declare function decodeRecordEntry(raw: Uint8Array, corruptionCode: string): Promise<{
    key: string;
    value: Uint8Array;
}>;
